"use client";

import { useState } from "react";
import Image from "next/image";
import {
  Image as ImageIcon,
  Search,
  Copy,
  Check,
  Upload,
  ExternalLink,
  Filter,
  X,
  FileImage,
} from "lucide-react";

interface MediaAsset {
  filename: string;
  url: string;
  category: "Gallery" | "Icon" | "Product" | "Hero";
  dimensions?: string;
  size?: string;
}

export default function AdminMediaLibraryPage() {
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [activeCategory, setActiveCategory] = useState<string>("ALL");
  const [selectedAsset, setSelectedAsset] = useState<MediaAsset | null>(null);

  // Core public media assets available in SHADEIT
  const mediaList: MediaAsset[] = [
    { filename: "gallery_1.png", url: "/gallery_1.png", category: "Gallery", size: "810 KB" },
    { filename: "gallery_2.png", url: "/gallery_2.png", category: "Gallery", size: "750 KB" },
    { filename: "gallery_3.png", url: "/gallery_3.png", category: "Gallery", size: "982 KB" },
    { filename: "gallery_4.png", url: "/gallery_4.png", category: "Gallery", size: "842 KB" },
    { filename: "hero_banner.png", url: "/hero_banner.png", category: "Hero", size: "857 KB" },
    { filename: "hero_closeup_1786043315815.png", url: "/hero_closeup_1786043315815.png", category: "Hero", size: "928 KB" },
    { filename: "monsoon_blinds.jpg", url: "/monsoon_blinds.jpg", category: "Product", size: "978 KB" },
    { filename: "roman_blinds.jpg", url: "/roman_blinds.jpg", category: "Product", size: "793 KB" },
    { filename: "pergola.jpg", url: "/pergola.jpg", category: "Product", size: "845 KB" },
    { filename: "canopy.jpg", url: "/canopy.jpg", category: "Product", size: "929 KB" },
    { filename: "timber_venetian_blinds.jpg", url: "/timber_venetian_blinds.jpg", category: "Product", size: "993 KB" },
    { filename: "vertical_blinds.jpg", url: "/vertical_blinds.jpg", category: "Product", size: "775 KB" },
    { filename: "outdoor_teak_sunbed.jpg", url: "/outdoor_teak_sunbed.jpg", category: "Product", size: "1 MB" },
    { filename: "outdoor_fabric.jpg", url: "/outdoor_fabric.jpg", category: "Product", size: "896 KB" },
    { filename: "outdoor_uv_clear_pvc.jpg", url: "/outdoor_uv_clear_pvc.jpg", category: "Product", size: "928 KB" },
    { filename: "icon_blinds_1786042796413.png", url: "/icon_blinds_1786042796413.png", category: "Icon", size: "767 KB" },
    { filename: "icon_curtains_1786042819663.png", url: "/icon_curtains_1786042819663.png", category: "Icon", size: "827 KB" },
    { filename: "icon_outdoor_1786042845349.png", url: "/icon_outdoor_1786042845349.png", category: "Icon", size: "944 KB" },
    { filename: "icon_awnings_1786042874286.png", url: "/icon_awnings_1786042874286.png", category: "Icon", size: "945 KB" },
  ];

  const filteredMedia = mediaList.filter((m) => {
    const matchesCat = activeCategory === "ALL" || m.category === activeCategory;
    const matchesSearch = m.filename.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleCopyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedUrl(url);
    setTimeout(() => setCopiedUrl(null), 2000);
  };

  return (
    <div className="space-y-6 w-full pb-16">
      {/* Header */}
      <div className="bg-white dark:bg-black p-6 sm:p-7 rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 px-2.5 py-0.5 rounded-none">
              ASSETS & MEDIA
            </span>
            <span className="text-xs text-neutral-400 dark:text-neutral-500">• High Resolution Media Library</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white tracking-tight">
            Media Asset Library
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Browse, copy image URLs, and inspect photography for your CMS pages and catalogs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold bg-neutral-100 dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300 px-3 py-1.5 rounded-none border border-[#E5E5E0] dark:border-neutral-800">
            {mediaList.length} Verified Media Files
          </span>
        </div>
      </div>

      {/* Category Pills & Search */}
      <div className="bg-white dark:bg-black p-4 rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 scrollbar-none">
          {["ALL", "Product", "Gallery", "Hero", "Icon"].map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-none text-xs font-bold transition-all whitespace-nowrap cursor-pointer border ${
                activeCategory === cat
                  ? "bg-amber-500 text-slate-950 border-amber-600 shadow-xs"
                  : "bg-neutral-50 dark:bg-neutral-950 hover:bg-neutral-100 dark:hover:bg-neutral-900 text-neutral-600 dark:text-neutral-300 border-[#E5E5E0] dark:border-neutral-800"
              }`}
            >
              {cat === "ALL" ? `All Media (${mediaList.length})` : `${cat}s`}
            </button>
          ))}
        </div>

        <div className="relative w-full md:w-64">
          <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-500 pointer-events-none" />
          <input
            type="text"
            placeholder="Search filename..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 dark:placeholder:text-neutral-500 outline-hidden font-medium"
          />
        </div>
      </div>

      {/* Media Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {filteredMedia.map((asset) => (
          <div
            key={asset.url}
            onClick={() => setSelectedAsset(asset)}
            className="group relative bg-white dark:bg-black rounded-none border border-[#E5E5E0] dark:border-neutral-800 overflow-hidden shadow-2xs hover:shadow-md hover:border-amber-400/60 dark:hover:border-amber-400/60 transition-all cursor-pointer flex flex-col"
          >
            <div className="relative aspect-4/3 w-full bg-neutral-100 dark:bg-neutral-950 overflow-hidden">
              <Image
                src={asset.url}
                alt={asset.filename}
                fill
                sizes="240px"
                className="object-cover group-hover:scale-105 transition-transform duration-300"
                unoptimized
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleCopyUrl(asset.url);
                  }}
                  className="p-2 rounded-none bg-white/90 dark:bg-neutral-900/90 hover:bg-white dark:hover:bg-neutral-800 text-slate-950 dark:text-white shadow-md text-xs font-bold"
                  title="Copy URL"
                >
                  {copiedUrl === asset.url ? <Check size={14} className="text-emerald-600 dark:text-emerald-400" /> : <Copy size={14} />}
                </button>
              </div>
            </div>

            <div className="p-3">
              <p className="text-xs font-bold text-neutral-900 dark:text-white truncate">{asset.filename}</p>
              <div className="flex items-center justify-between text-[10px] text-neutral-400 dark:text-neutral-500 mt-1">
                <span>{asset.category}</span>
                <span>{asset.size}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Asset Inspection Modal */}
      {selectedAsset && (
        <div className="fixed inset-0 z-50 bg-neutral-950/80 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-black w-full max-w-lg rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-2xl overflow-hidden flex flex-col">
            <div className="px-5 py-4 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
                  MEDIA ASSET
                </span>
                <h3 className="text-sm font-bold text-neutral-900 dark:text-white mt-0.5">
                  {selectedAsset.filename}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedAsset(null)}
                className="p-1.5 rounded-none text-neutral-400 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-900 cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            <div className="relative aspect-16/10 w-full bg-neutral-900">
              <Image
                src={selectedAsset.url}
                alt={selectedAsset.filename}
                fill
                className="object-contain"
                unoptimized
              />
            </div>

            <div className="p-5 space-y-4 text-xs bg-neutral-50 dark:bg-neutral-950">
              <div>
                <label className="block font-bold text-neutral-600 dark:text-neutral-400 mb-1">Image URL (Copy to use in CMS)</label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={selectedAsset.url}
                    className="w-full px-3 py-2 bg-white dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 rounded-none font-mono text-xs text-neutral-900 dark:text-neutral-100"
                  />
                  <button
                    type="button"
                    onClick={() => handleCopyUrl(selectedAsset.url)}
                    className="px-3.5 py-2 rounded-none bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shrink-0 cursor-pointer"
                  >
                    {copiedUrl === selectedAsset.url ? "Copied!" : "Copy"}
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 text-neutral-600 dark:text-neutral-400">
                <div className="bg-white dark:bg-black p-3 rounded-none border border-[#E5E5E0] dark:border-neutral-800">
                  <span className="text-[10px] font-bold uppercase text-neutral-400 dark:text-neutral-500 block mb-0.5">Category</span>
                  <span className="font-bold text-neutral-900 dark:text-white">{selectedAsset.category}</span>
                </div>
                <div className="bg-white dark:bg-black p-3 rounded-none border border-[#E5E5E0] dark:border-neutral-800">
                  <span className="text-[10px] font-bold uppercase text-neutral-400 dark:text-neutral-500 block mb-0.5">File Size</span>
                  <span className="font-bold text-neutral-900 dark:text-white">{selectedAsset.size}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
