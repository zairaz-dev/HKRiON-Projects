import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { stockAdjustmentService } from "@/services/stock-adjustment-service";
import { queryKeys } from "@/lib/query-keys";

export function useStockAdjustmentsQuery(
  businessId: string,
  filters: {
    branchId?: string;
    type?: 'ADDITION' | 'SUBTRACTION';
    search?: string;
    page?: number;
    limit?: number;
  },
) {
  return useQuery({
    queryKey: queryKeys.stockAdjustments.list(
      businessId,
      filters.branchId,
      filters.type,
      filters.search,
      filters.page,
      filters.limit,
    ),
    queryFn: () => stockAdjustmentService.getStockAdjustments(businessId, filters),
    enabled: !!businessId,
  });
}

export function useCreateStockAdjustmentMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: Parameters<typeof stockAdjustmentService.createStockAdjustment>[0]) =>
      stockAdjustmentService.createStockAdjustment(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.stockAdjustments.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.purchases.all });
    },
  });
}

export function useStockAdjustmentDetailQuery(id: string, businessId: string) {
  return useQuery({
    queryKey: queryKeys.stockAdjustments.detail(id),
    queryFn: () => stockAdjustmentService.getStockAdjustmentById(id, businessId),
    enabled: !!id && !!businessId,
  });
}
