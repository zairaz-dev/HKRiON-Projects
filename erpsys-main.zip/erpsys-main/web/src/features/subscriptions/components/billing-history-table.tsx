"use strict";
"use client";

import React, { useState } from 'react';
import { SubscriptionInvoice } from '../types';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { getFullAssetUrl } from '@/lib/utils';
import { Receipt, CheckCircle, Clock, AlertCircle, Eye, Printer, FileText } from 'lucide-react';
import { InvoiceReceiptModal } from './invoice-receipt-modal';

interface BillingHistoryTableProps {
  invoices: SubscriptionInvoice[];
  businessName?: string;
  planName?: string;
}

export function BillingHistoryTable({
  invoices,
  businessName = 'Your Business',
  planName = 'SaaS Subscription',
}: BillingHistoryTableProps) {
  const [selectedInvoice, setSelectedInvoice] = useState<SubscriptionInvoice | null>(null);

  if (!invoices || invoices.length === 0) {
    return (
      <Card className="bg-card/40 backdrop-blur-md border-border/50">
        <CardContent className="p-8 text-center space-y-2">
          <Receipt className="w-8 h-8 text-muted-foreground mx-auto opacity-50" />
          <h4 className="text-sm font-semibold text-foreground">No Billing History Yet</h4>
          <p className="text-xs text-muted-foreground">
            Invoices generated for your subscription upgrades and renewals will appear here.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="bg-card/40 backdrop-blur-md border-border/60 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-border bg-background/50 text-[10px] font-mono uppercase text-muted-foreground">
                <th className="p-4 font-bold">Invoice #</th>
                <th className="p-4 font-bold">Date</th>
                <th className="p-4 font-bold">Description</th>
                <th className="p-4 font-bold">Payment Method</th>
                <th className="p-4 font-bold">Amount</th>
                <th className="p-4 font-bold">Status</th>
                <th className="p-4 font-bold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/50 font-medium">
              {invoices.map((inv) => {
                const isPaid = inv.paymentStatus === 'PAID';
                const isPending = inv.paymentStatus === 'PENDING';

                return (
                  <tr key={inv.id} className="hover:bg-accent/30 transition-colors">
                    <td className="p-4 font-mono font-bold text-foreground">{inv.invoiceNumber}</td>
                    <td className="p-4 text-muted-foreground font-mono">
                      {new Date(inv.createdAt).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                      })}
                    </td>
                    <td className="p-4 text-foreground">{inv.notes || 'Subscription Payment'}</td>
                    <td className="p-4 text-muted-foreground">
                      <div className="flex items-center gap-1.5">
                        <span>{inv.paymentMethod || 'Online'}</span>
                        {inv.proofUrl && (
                          <a
                            href={getFullAssetUrl(inv.proofUrl) || "#"}
                            target="_blank"
                            rel="noreferrer"
                            className="text-primary hover:underline text-[10px] font-mono"
                          >
                            [Slip]
                          </a>
                        )}
                      </div>
                    </td>
                    <td className="p-4 font-mono font-bold text-foreground">
                      {inv.currency === 'USD' ? '$' : 'Rs.'} {inv.totalAmount.toLocaleString()}
                    </td>
                    <td className="p-4">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold font-mono ${
                          isPaid
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : isPending
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        }`}
                      >
                        {isPaid ? (
                          <CheckCircle className="w-3 h-3" />
                        ) : isPending ? (
                          <Clock className="w-3 h-3" />
                        ) : (
                          <AlertCircle className="w-3 h-3" />
                        )}
                        {inv.paymentStatus}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedInvoice(inv)}
                        className="h-7 text-[11px] px-2.5 flex items-center gap-1.5 hover:border-primary/50"
                      >
                        <FileText className="w-3 h-3 text-primary" /> View / Print
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Printable Invoice Modal */}
      <InvoiceReceiptModal
        invoice={selectedInvoice}
        businessName={businessName}
        planName={planName}
        isOpen={!!selectedInvoice}
        onClose={() => setSelectedInvoice(null)}
      />
    </>
  );
}
