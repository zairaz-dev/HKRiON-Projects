"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import Image from "next/image";
import { Role } from "@prisma/client";
import { deleteEmployee } from "@/actions/employees";
import { 
  Plus, 
  Edit2, 
  Trash2, 
  AlertTriangle, 
  Users, 
  Search, 
  Briefcase, 
  Shield, 
  UserCheck, 
  LayoutGrid, 
  List, 
  Phone, 
  Mail, 
  X, 
  UserPlus,
  User,
  ShieldCheck,
  Crown
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Modal } from "@/components/ui/modal";
import { PageHeader } from "@/components/ui/page-header";
import { Select } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { toast } from "sonner";

type User = {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string | null;
  role: Role;
  positionId: number | null;
  managerId: number | null;
  profileImage?: string | null;
  position?: { id: number; title: string } | null;
  manager?: { id: number; firstName: string; lastName: string; profileImage?: string | null } | null;
};

type Position = {
  id: number;
  title: string;
};

type Manager = {
  id: number;
  firstName: string;
  lastName: string;
  role: string;
};

type EmployeeClientProps = {
  employees: User[];
  positions: Position[];
  managers: Manager[];
  isAdmin?: boolean;
};

export default function EmployeeClient({
  employees,
  positions,
  isAdmin = false,
}: EmployeeClientProps) {
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deletingEmployeeId, setDeletingEmployeeId] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // View mode: 'table' or 'grid'
  const [viewMode, setViewMode] = useState<"table" | "grid">("table");

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("ALL");
  const [positionFilter, setPositionFilter] = useState("ALL");
  const [sortBy, setSortBy] = useState("name-asc");

  // Filtered & Sorted employees
  const filteredEmployees = useMemo(() => {
    return employees
      .filter((emp) => {
        const query = searchQuery.toLowerCase().trim();
        const matchesSearch = !query || 
          `${emp.firstName} ${emp.lastName}`.toLowerCase().includes(query) ||
          emp.email.toLowerCase().includes(query) ||
          (emp.phone && emp.phone.toLowerCase().includes(query)) ||
          (emp.position?.title && emp.position.title.toLowerCase().includes(query));

        const matchesRole = roleFilter === "ALL" || emp.role === roleFilter;
        const matchesPosition = positionFilter === "ALL" || emp.positionId?.toString() === positionFilter;

        return matchesSearch && matchesRole && matchesPosition;
      })
      .sort((a, b) => {
        if (sortBy === "name-asc") return `${a.firstName} ${a.lastName}`.localeCompare(`${b.firstName} ${b.lastName}`);
        if (sortBy === "name-desc") return `${b.firstName} ${b.lastName}`.localeCompare(`${a.firstName} ${a.lastName}`);
        if (sortBy === "role") return a.role.localeCompare(b.role);
        if (sortBy === "position") return (a.position?.title || "").localeCompare(b.position?.title || "");
        return 0;
      });
  }, [employees, searchQuery, roleFilter, positionFilter, sortBy]);

  const hasActiveFilters = searchQuery !== "" || roleFilter !== "ALL" || positionFilter !== "ALL";

  const clearFilters = () => {
    setSearchQuery("");
    setRoleFilter("ALL");
    setPositionFilter("ALL");
    setSortBy("name-asc");
  };

  const confirmDelete = (id: number) => {
    setDeletingEmployeeId(id);
    setIsDeleteModalOpen(true);
  };

  const handleDelete = async () => {
    if (!deletingEmployeeId) return;
    setIsLoading(true);
    const res = await deleteEmployee(deletingEmployeeId);
    if (res.error) {
      toast.error(res.error);
    } else {
      setIsDeleteModalOpen(false);
      setDeletingEmployeeId(null);
      toast.success("Employee deleted successfully!");
    }
    setIsLoading(false);
  };

  const deletingEmployee = employees.find((e) => e.id === deletingEmployeeId);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <PageHeader 
        title="Employees Directory"
        description="Manage your organization's team members, job roles, contact details, and reporting structure."
        badge={
          <Badge variant="secondary" className="font-mono text-xs">
            {employees.length} Members
          </Badge>
        }
        actions={
          isAdmin ? (
            <Link href="/dashboard/employees/create">
              <Button className="gap-2 shadow-sm font-semibold cursor-pointer">
                <UserPlus className="h-4 w-4" />
                <span>Add Employee</span>
              </Button>
            </Link>
          ) : null
        }
      />

      {/* Search, Filters & View Mode Toolbar */}
      <div className="flex flex-col lg:flex-row gap-3 items-stretch lg:items-center justify-between bg-surface-secondary/40 p-3 rounded-xl border border-border">
        {/* Search Bar */}
        <div className="relative flex-1 min-w-[240px]">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-text-muted" />
          <Input
            type="text"
            placeholder="Search by name, email, phone, or job title..."
            className="pl-10 pr-9 bg-surface text-sm h-10 border-border/80"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary transition-colors cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Role Filter */}
          <div className="w-36 sm:w-40">
            <Select
              size="sm"
              value={roleFilter}
              onValueChange={setRoleFilter}
              options={[
                { value: "ALL", label: "All Roles" },
                { value: "MANAGER", label: "Manager" },
                { value: "EMPLOYEE", label: "Employee" },
              ]}
            />
          </div>

          {/* Position Filter */}
          <div className="w-40 sm:w-44">
            <Select
              size="sm"
              value={positionFilter}
              onValueChange={setPositionFilter}
              options={[
                { value: "ALL", label: "All Positions" },
                ...positions.map((p) => ({
                  value: p.id.toString(),
                  label: p.title,
                })),
              ]}
            />
          </div>

          {/* Sort Dropdown */}
          <div className="w-40 sm:w-44">
            <Select
              size="sm"
              value={sortBy}
              onValueChange={setSortBy}
              options={[
                { value: "name-asc", label: "Name (A → Z)" },
                { value: "name-desc", label: "Name (Z → A)" },
                { value: "role", label: "Sort: Role" },
                { value: "position", label: "Sort: Position" },
              ]}
            />
          </div>

          {/* Reset Filters Button */}
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearFilters}
              className="text-xs text-text-muted hover:text-text-primary gap-1 h-9 px-2.5 cursor-pointer"
            >
              <X className="h-3.5 w-3.5" />
              <span>Reset</span>
            </Button>
          )}

          {/* View Mode Toggle (Table / Grid) */}
          <div className="flex items-center bg-surface rounded-lg p-1 border border-border ml-auto lg:ml-2">
            <button
              onClick={() => setViewMode("grid")}
              title="Grid / Card View"
              className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                viewMode === "grid"
                  ? "bg-primary text-white shadow-xs"
                  : "text-text-muted hover:text-text-primary hover:bg-surface-secondary"
              }`}
            >
              <LayoutGrid className="h-4 w-4" />
            </button>
            <button
              onClick={() => setViewMode("table")}
              title="Table View"
              className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                viewMode === "table"
                  ? "bg-primary text-white shadow-xs"
                  : "text-text-muted hover:text-text-primary hover:bg-surface-secondary"
              }`}
            >
              <List className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Results Count Banner */}
      <div className="flex items-center justify-between text-xs text-text-secondary px-1">
        <p>
          Showing <strong className="text-text-primary">{filteredEmployees.length}</strong> of{" "}
          <strong className="text-text-primary">{employees.length}</strong> employees
        </p>
        {hasActiveFilters && (
          <span className="text-primary font-medium">Filtered results</span>
        )}
      </div>

      {/* VIEW 1: GRID / CARD VIEW */}
      {viewMode === "grid" && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredEmployees.length === 0 ? (
            <div className="col-span-full py-16 text-center bg-surface rounded-xl border border-border">
              <div className="p-3 rounded-full bg-surface-secondary inline-block mb-3">
                <Users className="h-8 w-8 text-text-muted" />
              </div>
              <p className="font-semibold text-text-primary text-sm">No employees match your search</p>
              <p className="text-xs text-text-muted mt-1 max-w-sm mx-auto">
                Try adjusting your search query, role filter, or position filter.
              </p>
              {hasActiveFilters && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={clearFilters}
                  className="mt-4 text-xs cursor-pointer"
                >
                  Clear all filters
                </Button>
              )}
            </div>
          ) : (
            filteredEmployees.map((employee) => (
              <Card 
                key={employee.id} 
                className="bg-surface border-border hover:border-primary/40 transition-all duration-200 shadow-2xs hover:shadow-md flex flex-col justify-between h-full overflow-hidden group"
              >
                {/* Card Header & Profile Avatar */}
                <div className="p-5 pb-4 space-y-4">
                  {/* Top Row: Role Badge & ID */}
                  <div className="flex items-center justify-between">
                    <Badge 
                      variant={
                        employee.role === 'SUPER_ADMIN' ? 'default' :
                        employee.role === 'MANAGER' ? 'secondary' :
                        'outline'
                      }
                      className="text-[10px] font-semibold tracking-wide"
                    >
                      {employee.role.replace('_', ' ')}
                    </Badge>
                  </div>

                  {/* Centered Avatar, Full Name & Position */}
                  <div className="flex flex-col items-center text-center">
                    <div className="relative flex h-18 w-18 items-center justify-center rounded-full bg-primary-soft text-primary font-bold text-lg border-2 border-border shadow-xs overflow-hidden mb-3 group-hover:scale-105 transition-transform">
                      {employee.profileImage ? (
                        <Image src={employee.profileImage} alt="Profile" fill className="object-cover" />
                      ) : (
                        `${employee.firstName.charAt(0)}${employee.lastName.charAt(0)}`
                      )}
                    </div>

                    <h3 className="font-bold text-base text-text-primary group-hover:text-primary transition-colors truncate max-w-full">
                      {employee.firstName} {employee.lastName}
                    </h3>

                    <div className="flex items-center gap-1.5 text-xs text-text-secondary mt-1">
                      <Briefcase className="h-3.5 w-3.5 text-text-muted shrink-0" />
                      <span className="font-medium truncate max-w-[200px]">
                        {employee.position?.title || "No Position Assigned"}
                      </span>
                    </div>
                  </div>

                  {/* Information Details List */}
                  <div className="space-y-2 pt-3 border-t border-border/70 text-xs">
                    {/* Email Row */}
                    <div className="flex items-center justify-between gap-2 p-2 rounded-lg bg-surface-secondary/50 font-mono text-[11px]">
                      <span className="flex items-center gap-1.5 text-text-muted shrink-0">
                        <Mail className="h-3.5 w-3.5" />
                        <span>Email:</span>
                      </span>
                      <a 
                        href={`mailto:${employee.email}`} 
                        className="font-medium text-text-primary hover:text-primary transition-colors truncate"
                        title={employee.email}
                      >
                        {employee.email}
                      </a>
                    </div>

                    {/* Phone Row */}
                    <div className="flex items-center justify-between gap-2 p-2 rounded-lg bg-surface-secondary/50 font-mono text-[11px]">
                      <span className="flex items-center gap-1.5 text-text-muted shrink-0">
                        <Phone className="h-3.5 w-3.5" />
                        <span>Phone:</span>
                      </span>
                      {employee.phone ? (
                        <a 
                          href={`tel:${employee.phone}`} 
                          className="font-medium text-text-primary hover:text-primary transition-colors truncate"
                          title={employee.phone}
                        >
                          {employee.phone}
                        </a>
                      ) : (
                        <span className="text-text-muted italic">Not set</span>
                      )}
                    </div>

                    {/* Manager Row */}
                    <div className="flex items-center justify-between gap-2 p-2 rounded-lg bg-surface-secondary/50 text-[11px]">
                      <span className="flex items-center gap-1.5 text-text-muted shrink-0">
                        <UserCheck className="h-3.5 w-3.5" />
                        <span>Manager:</span>
                      </span>
                      {employee.manager ? (
                        <div className="flex items-center gap-1.5 font-medium text-text-primary truncate">
                          <div className="relative h-4.5 w-4.5 rounded-full bg-primary-soft text-primary flex items-center justify-center text-[9px] font-bold overflow-hidden shrink-0">
                            {employee.manager.profileImage ? (
                              <Image src={employee.manager.profileImage} alt="Mgr" fill className="object-cover" />
                            ) : (
                              employee.manager.firstName.charAt(0)
                            )}
                          </div>
                          <span className="truncate">{employee.manager.firstName} {employee.manager.lastName}</span>
                        </div>
                      ) : (
                        <span className="text-text-muted italic">Direct Report</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Card Action Footer */}
                {isAdmin && (
                  <div className="p-3 bg-surface-secondary/30 border-t border-border flex items-center gap-2">
                    <Link href={`/dashboard/employees/${employee.id}/edit`} className="flex-1">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full gap-1.5 text-xs font-semibold h-8 cursor-pointer hover:bg-surface hover:border-primary/50"
                      >
                        <Edit2 className="h-3.5 w-3.5 text-text-muted" />
                        <span>Edit Profile</span>
                      </Button>
                    </Link>

                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => confirmDelete(employee.id)} 
                      title="Delete Employee" 
                      className="h-8 px-2.5 text-text-muted hover:text-error hover:bg-error-bg cursor-pointer"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                )}
              </Card>
            ))
          )}
        </div>
      )}

      {/* VIEW 2: TABLE VIEW */}
      {viewMode === "table" && (
        <Table>
          <TableHeader>
          <TableRow>
            <TableHead className="w-[300px]">Employee</TableHead>
            <TableHead className="hidden md:table-cell">Contact Info</TableHead>
            <TableHead>Role</TableHead>
            <TableHead className="hidden lg:table-cell">Position</TableHead>
            <TableHead className="hidden xl:table-cell">Reports To</TableHead>
            {isAdmin && <TableHead className="text-right">Actions</TableHead>}
          </TableRow>
        </TableHeader>
        <TableBody>
              {filteredEmployees.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-48 text-center">
                    <div className="flex flex-col items-center justify-center text-text-secondary">
                      <div className="p-3 rounded-full bg-surface-secondary mb-3">
                        <Users className="h-8 w-8 text-text-muted" />
                      </div>
                      <p className="font-semibold text-text-primary text-sm">No employees match your search</p>
                      <p className="text-xs text-text-muted mt-1 max-w-sm">
                        Try adjusting your keywords, role filter, or position filter.
                      </p>
                      {hasActiveFilters && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={clearFilters}
                          className="mt-4 text-xs cursor-pointer"
                        >
                          Clear all filters
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                filteredEmployees.map((employee) => (
                  <TableRow key={employee.id}>
                    <TableCell>
                      <div className="flex items-center gap-4">
                        <div className="relative flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-primary-soft to-primary-100 dark:from-primary-900 dark:to-primary-800 text-primary font-bold text-sm border-2 border-primary/20 overflow-hidden shrink-0 shadow-sm group-hover:scale-105 group-hover:border-primary/50 transition-all duration-300">
                          {employee.profileImage ? (
                            <Image src={employee.profileImage} alt="Profile" fill className="object-cover" />
                          ) : (
                            `${employee.firstName.charAt(0)}${employee.lastName.charAt(0)}`
                          )}
                        </div>
                        <div className="min-w-0">
                          <div className="font-semibold text-sm text-text-primary truncate">
                            {employee.firstName} {employee.lastName}
                          </div>
                          <div className="text-xs text-text-muted truncate font-mono">
                            {employee.email}
                          </div>
                          {employee.phone && (
                            <div className="text-[11px] text-text-muted md:hidden font-mono mt-0.5">
                              {employee.phone}
                            </div>
                          )}
                        </div>
                      </div>
                    </TableCell>

                    <TableCell className="hidden md:table-cell text-xs font-mono">
                      <div className="space-y-1">
                        <a 
                          href={`mailto:${employee.email}`} 
                          className="flex items-center gap-1.5 text-text-secondary hover:text-primary transition-colors truncate"
                        >
                          <Mail className="h-3.5 w-3.5 text-text-muted shrink-0" />
                          <span className="truncate">{employee.email}</span>
                        </a>
                        {employee.phone ? (
                          <a 
                            href={`tel:${employee.phone}`} 
                            className="flex items-center gap-1.5 text-text-muted hover:text-primary transition-colors truncate"
                          >
                            <Phone className="h-3.5 w-3.5 text-text-muted shrink-0" />
                            <span>{employee.phone}</span>
                          </a>
                        ) : (
                          <span className="text-text-disabled text-[11px]">—</span>
                        )}
                      </div>
                    </TableCell>

                    <TableCell>
                      <Badge 
                        variant={
                          employee.role === 'SUPER_ADMIN' ? 'default' :
                          employee.role === 'MANAGER' ? 'secondary' :
                          'outline'
                        }
                        className="text-[11px] font-medium"
                      >
                        {employee.role.replace('_', ' ')}
                      </Badge>
                    </TableCell>

                    <TableCell className="hidden lg:table-cell text-sm text-text-secondary">
                      {employee.position ? (
                        <div className="flex items-center gap-1.5">
                          <Briefcase className="h-3.5 w-3.5 text-text-muted shrink-0" />
                          <span className="font-medium text-text-primary text-xs">{employee.position.title}</span>
                        </div>
                      ) : (
                        <span className="text-text-muted text-xs">Unassigned</span>
                      )}
                    </TableCell>

                    <TableCell className="hidden xl:table-cell">
                      {employee.manager ? (
                        <div className="flex items-center gap-2 text-xs text-text-secondary">
                          <div className="relative h-6 w-6 rounded-full bg-surface-secondary flex items-center justify-center text-[10px] font-semibold text-text-primary border border-border overflow-hidden shrink-0">
                            {employee.manager.profileImage ? (
                              <Image src={employee.manager.profileImage} alt="Manager" fill className="object-cover" />
                            ) : (
                              employee.manager.firstName.charAt(0)
                            )}
                          </div>
                          <span className="font-medium truncate">{employee.manager.firstName} {employee.manager.lastName}</span>
                        </div>
                      ) : (
                        <span className="text-text-muted text-xs">—</span>
                      )}
                    </TableCell>

                    {isAdmin && (
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Link href={`/dashboard/employees/${employee.id}/edit`}>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              title="Edit Employee" 
                              className="h-8 w-8 text-text-secondary hover:text-text-primary hover:bg-surface-secondary cursor-pointer"
                            >
                              <Edit2 className="h-3.5 w-3.5" />
                            </Button>
                          </Link>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => confirmDelete(employee.id)} 
                            title="Delete Employee" 
                            className="h-8 w-8 text-text-secondary hover:text-error hover:bg-error-bg cursor-pointer"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
      )}

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        size="sm"
      >
        <div className="text-center py-2">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-error-bg mb-4 border border-error-border">
            <AlertTriangle className="h-6 w-6 text-error" />
          </div>
          <h3 className="text-lg font-bold text-text-primary mb-2">Delete Employee?</h3>
          <p className="text-xs text-text-secondary mb-6 leading-relaxed">
            Are you sure you want to permanently remove <strong className="text-text-primary">{deletingEmployee?.firstName} {deletingEmployee?.lastName}</strong>? This will revoke access and remove their account records.
          </p>
          <div className="flex gap-3 justify-center">
            <Button variant="outline" onClick={() => setIsDeleteModalOpen(false)} disabled={isLoading} className="cursor-pointer">
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete} disabled={isLoading} className="min-w-[90px] font-semibold cursor-pointer">
              {isLoading ? "Deleting..." : "Delete"}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
