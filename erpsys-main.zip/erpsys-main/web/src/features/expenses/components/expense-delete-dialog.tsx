import React from "react";
import { AlertCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { User } from "@hkr/types";
import { ExpenseItem } from "../types";
import { useDeleteExpenseMutation } from "../hooks/use-expenses";
import { useCurrency } from "@/hooks/use-currency";

interface ExpenseDeleteDialogProps {
  isOpen: boolean;
  onClose: () => void;
  expense: ExpenseItem | null;
  currentUser: User;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

export function ExpenseDeleteDialog({
  isOpen,
  onClose,
  expense,
  currentUser,
  onSuccess,
  onError,
}: ExpenseDeleteDialogProps) {
  const { format } = useCurrency(currentUser.businessId);
  const deleteMutation = useDeleteExpenseMutation();

  const handleDelete = async () => {
    if (!expense || !currentUser.businessId) return;

    try {
      await deleteMutation.mutateAsync({
        id: expense.id,
        businessId: currentUser.businessId,
      });
      onSuccess("Expense deleted successfully!");
      onClose();
    } catch (err: any) {
      onError(err.message || "Failed to delete expense.");
    }
  };

  const isLoading = deleteMutation.isPending;

  if (!isOpen || !expense) return null;

  return (
    <Dialog
      isOpen={isOpen}
      onClose={onClose}
      size="sm"
      title={
        <>
          <AlertCircle className="h-5 w-5 text-destructive shrink-0" />
          Delete Expense?
        </>
      }
    >
      <div className="space-y-4">
        <p className="text-xs text-muted-foreground">
          Are you sure you want to delete the expense <strong className="text-foreground">"{expense.refNo || expense.id}"</strong> for <strong className="text-foreground">{format(expense.amount)}</strong>? This action cannot be undone.
        </p>
        <div className="flex items-center justify-end space-x-3 pt-3 border-t border-border/40">
          <Button
            variant="outline"
            onClick={onClose}
            disabled={isLoading}
            className="h-8.5 text-xs px-3.5"
          >
            Cancel
          </Button>
          <Button
            variant="destructive"
            onClick={handleDelete}
            disabled={isLoading}
            className="h-8.5 text-xs px-3.5 flex items-center gap-1.5"
          >
            {isLoading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            Delete Expense
          </Button>
        </div>
      </div>
    </Dialog>
  );
}
