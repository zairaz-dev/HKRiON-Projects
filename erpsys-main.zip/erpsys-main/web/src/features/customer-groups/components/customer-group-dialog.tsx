import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { X, Users, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { User } from "@hkr/types";
import { customerGroupFormSchema, CustomerGroupFormSchema } from "../schema";
import { CustomerGroupItem, BranchItem } from "../types";
import {
  useCreateCustomerGroupMutation,
  useUpdateCustomerGroupMutation,
  useSellingPriceGroupsQuery,
} from "../hooks/use-customer-groups";

interface CustomerGroupDialogProps {
  isOpen: boolean;
  onClose: () => void;
  customerGroup?: CustomerGroupItem | null;
  branches: BranchItem[];
  currentUser: User;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

export function CustomerGroupDialog({
  isOpen,
  onClose,
  customerGroup,
  branches,
  currentUser,
  onSuccess,
  onError,
}: CustomerGroupDialogProps) {
  const isEditMode = !!customerGroup;
  const createMutation = useCreateCustomerGroupMutation();
  const updateMutation = useUpdateCustomerGroupMutation();

  // Fetch Selling Price Groups for the dropdown
  const { data: sellingPriceGroups = [] } = useSellingPriceGroupsQuery(currentUser.businessId || "");

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<CustomerGroupFormSchema>({
    resolver: zodResolver(customerGroupFormSchema),
    defaultValues: {
      name: "",
      percentageDiscount: 0,
      sellingPriceGroupId: "",
      branchIds: [],
      isActive: true,
    },
  });

  const watchBranchIds = watch("branchIds") || [];

  // Populate form in edit mode
  useEffect(() => {
    if (customerGroup) {
      const assignedBranchIds = customerGroup.branches?.map((cb) => cb.branch.id) || [];
      reset({
        name: customerGroup.name,
        percentageDiscount: customerGroup.percentageDiscount,
        sellingPriceGroupId: customerGroup.sellingPriceGroupId || "",
        branchIds: assignedBranchIds,
        isActive: customerGroup.isActive,
      });
    } else {
      reset({
        name: "",
        percentageDiscount: 0,
        sellingPriceGroupId: "",
        branchIds: [],
        isActive: true,
      });
    }
  }, [customerGroup, reset, isOpen]);

  const handleToggleBranch = (branchId: string) => {
    if (watchBranchIds.includes(branchId)) {
      setValue(
        "branchIds",
        watchBranchIds.filter((id) => id !== branchId),
        { shouldValidate: true }
      );
    } else {
      setValue("branchIds", [...watchBranchIds, branchId], {
        shouldValidate: true,
      });
    }
  };

  const onSubmit = async (data: CustomerGroupFormSchema) => {
    if (!currentUser.businessId) return;

    const payload = {
      name: data.name.trim(),
      percentageDiscount: data.percentageDiscount,
      sellingPriceGroupId: data.sellingPriceGroupId || null,
      branchIds: data.branchIds,
      isActive: data.isActive,
      businessId: currentUser.businessId,
      createdById: isEditMode ? undefined : currentUser.id,
      updatedById: isEditMode ? currentUser.id : undefined,
    };

    try {
      if (isEditMode && customerGroup) {
        await updateMutation.mutateAsync({ id: customerGroup.id, data: payload });
        onSuccess("Customer group updated successfully!");
      } else {
        await createMutation.mutateAsync(payload);
        onSuccess("Customer group created successfully!");
      }
      onClose();
    } catch (err: any) {
      onError(err.message || "Failed to save customer group.");
    }
  };

  const isLoading = createMutation.isPending || updateMutation.isPending;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
      <div className="w-full max-w-lg rounded-xl border border-border/50 bg-card p-6 shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between border-b border-border/50 pb-3 mb-4">
          <h3 className="text-lg font-bold flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            {isEditMode ? "Edit Customer Group" : "Create Customer Group"}
          </h3>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="h-8 w-8 rounded-full"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          {/* Name */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase">
              Group Name <span className="text-destructive">*</span>
            </label>
            <Input
              placeholder="e.g., Retail, Wholesale, VIP"
              {...register("name")}
              disabled={isLoading}
            />
            {errors.name && (
              <span className="text-xs text-rose-500">{errors.name.message}</span>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            {/* Selling Price Group */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-muted-foreground uppercase">
                Selling Price Group
              </label>
              <select
                {...register("sellingPriceGroupId")}
                disabled={isLoading}
                className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-xs shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              >
                <option value="">None (Use Percentage Discount)</option>
                {sellingPriceGroups.map((spg: any) => (
                  <option key={spg.id} value={spg.id}>
                    {spg.name}
                  </option>
                ))}
              </select>
              {errors.sellingPriceGroupId && (
                <span className="text-xs text-rose-500">{errors.sellingPriceGroupId.message}</span>
              )}
            </div>

            {/* Percentage Discount */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-muted-foreground uppercase">
                Percentage Discount (%) <span className="text-destructive">*</span>
              </label>
              <Input
                type="number"
                step="any"
                placeholder="e.g., 5, 10"
                {...register("percentageDiscount", { valueAsNumber: true })}
                disabled={isLoading}
              />
              {errors.percentageDiscount && (
                <span className="text-xs text-rose-500">{errors.percentageDiscount.message}</span>
              )}
            </div>
          </div>

          {/* Branch Scope */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase block">
              Branch Mapping (Optional - Leave empty for Global)
            </label>
            <div className="grid grid-cols-2 gap-2 max-h-24 overflow-y-auto border border-border/40 rounded-md p-2 bg-background/50">
              {branches.map((branch) => {
                const isChecked = watchBranchIds.includes(branch.id);
                return (
                  <div
                    key={branch.id}
                    onClick={() => handleToggleBranch(branch.id)}
                    className={`flex items-center space-x-2 p-1.5 rounded-md cursor-pointer border text-xs font-medium transition-all ${
                      isChecked
                        ? "bg-primary/10 border-primary/30 text-primary"
                        : "bg-transparent border-transparent hover:bg-secondary/40 text-muted-foreground"
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => {}} // Handled by onClick on div
                      className="rounded text-primary focus:ring-0 cursor-pointer"
                    />
                    <span className="truncate">{branch.name}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Status */}
          <div className="flex items-center space-x-2 py-1">
            <input
              type="checkbox"
              id="isActive"
              {...register("isActive")}
              disabled={isLoading}
              className="rounded text-primary focus:ring-0 cursor-pointer h-4 w-4"
            />
            <label htmlFor="isActive" className="text-xs font-semibold cursor-pointer select-none">
              Active (Allow using this customer group)
            </label>
          </div>

          {/* Form Buttons */}
          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-border/50">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isLoading}
              className="h-9 px-4 text-xs"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isLoading}
              className="h-9 px-4 text-xs flex items-center gap-1.5"
            >
              {isLoading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
              {isEditMode ? "Save Changes" : "Create Group"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
