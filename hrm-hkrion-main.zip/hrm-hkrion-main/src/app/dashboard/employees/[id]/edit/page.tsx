import { getEmployeeById, getPotentialManagers } from "@/actions/employees";
import { getPositions } from "@/actions/positions";
import { getSession } from "@/lib/session";
import { Role } from "@prisma/client";
import { redirect, notFound } from "next/navigation";
import EditEmployeeClient from "./edit-employee-client";

export default async function EditEmployeePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const session = await getSession();

  if (!session || session.role === Role.EMPLOYEE) {
    redirect("/dashboard/employees");
  }

  const { id: idParam } = await params;
  const employeeId = parseInt(idParam, 10);

  if (isNaN(employeeId)) {
    notFound();
  }

  const [employeeRes, positionsRes, managersRes] = await Promise.all([
    getEmployeeById(employeeId),
    getPositions(),
    getPotentialManagers(),
  ]);

  if (employeeRes.error || !employeeRes.data) {
    redirect("/dashboard/employees");
  }

  const isSuperAdmin = session.role === Role.SUPER_ADMIN;

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-24">
      <EditEmployeeClient 
        employee={employeeRes.data}
        positions={positionsRes.data || []}
        managers={managersRes.data || []}
        isSuperAdmin={isSuperAdmin}
        currentUserId={session.userId}
      />
    </div>
  );
}
