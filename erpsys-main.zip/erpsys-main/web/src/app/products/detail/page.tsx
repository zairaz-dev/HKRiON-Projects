"use client";

import React, { useEffect, useState, Suspense, useMemo } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import {
  ArrowLeft,
  Package,
  Layers,
  Tag,
  Scale,
  ShieldCheck,
  Building2,
  Globe,
  DollarSign,
  Coins,
  Ban,
  AlertCircle,
  Edit,
  Loader2,
  Printer,
  Barcode,
  TrendingUp,
  Percent,
  ShoppingBag,
  ShoppingCart,
  SlidersHorizontal,
  ArrowRightLeft,
  Calendar,
  User as UserIcon,
  Clock,
  Search,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Copy,
  Check,
  Smartphone,
  History,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { Button } from "@/components/ui/button";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";
import { LoadingSession } from "@/components/ui/loading-session";
import { getFullAssetUrl, cn } from "@/lib/utils";
import {
  useProductByIdQuery,
  useSpgQuery,
  useBranchesQuery,
  ProductDialog,
  BarcodeLabelModal,
} from "@/features/products";
import { useCurrency } from "@/hooks/use-currency";
import { useQuery } from "@tanstack/react-query";
import { imeiService } from "@/services/imei-service";
import "react-quill/dist/quill.snow.css";

function SvgBarcodeDisplay({ value }: { value: string }) {
  const text = value || "00000000";
  const bars: boolean[] = [];
  bars.push(true, false, true, false);
  for (let i = 0; i < text.length; i++) {
    const charCode = text.charCodeAt(i);
    const pattern = [
      (charCode & 1) === 1,
      (charCode & 2) === 2,
      (charCode & 4) === 4,
      (charCode & 8) === 8,
      (charCode & 16) === 16,
    ];
    pattern.forEach((p) => {
      bars.push(p);
      bars.push(!p);
    });
  }
  bars.push(true, true, false, true, false, true, true);

  return (
    <div className="flex flex-col items-center bg-white p-2 rounded-sm border border-border/60">
      <svg
        className="w-full h-6 max-w-[160px]"
        viewBox={`0 0 ${bars.length * 2.2} 24`}
        preserveAspectRatio="none"
      >
        {bars.map((isBar, idx) =>
          isBar ? (
            <rect
              key={idx}
              x={idx * 2.2}
              y="0"
              width="1.8"
              height="24"
              fill="#000000"
            />
          ) : null
        )}
      </svg>
      <span className="text-[9px] font-mono tracking-widest text-black mt-0.5 font-bold">
        {value}
      </span>
    </div>
  );
}

// Compact ERP Pagination Control
function PaginationControl({
  currentPage,
  pageSize,
  totalItems,
  onPageChange,
  onPageSizeChange,
  pageSizeOptions = [5, 10, 25, 50],
}: {
  currentPage: number;
  pageSize: number;
  totalItems: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (size: number) => void;
  pageSizeOptions?: number[];
}) {
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  const startItem = totalItems === 0 ? 0 : (currentPage - 1) * pageSize + 1;
  const endItem = Math.min(totalItems, currentPage * pageSize);

  if (totalItems === 0) return null;

  return (
    <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pt-2 px-1 text-[11px] text-muted-foreground select-none border-t border-border/30">
      <div className="flex items-center gap-2">
        <span>
          Showing <span className="font-bold text-foreground font-mono">{startItem}</span> to{" "}
          <span className="font-bold text-foreground font-mono">{endItem}</span> of{" "}
          <span className="font-bold text-foreground font-mono">{totalItems}</span> records
        </span>
        <div className="flex items-center gap-1 ml-2">
          <span>Rows:</span>
          <select
            value={pageSize}
            onChange={(e) => onPageSizeChange(Number(e.target.value))}
            className="bg-background border border-border/60 rounded px-1.5 py-0.5 text-[10px] text-foreground outline-none focus:ring-1 focus:ring-primary cursor-pointer"
          >
            {pageSizeOptions.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="flex items-center gap-1">
        <Button
          variant="outline"
          size="sm"
          disabled={currentPage <= 1}
          onClick={() => onPageChange(currentPage - 1)}
          className="h-6 px-2 text-[10px] font-medium"
        >
          <ChevronLeft className="h-3 w-3 mr-0.5" />
          Prev
        </Button>

        <span className="px-2 py-0.5 font-mono text-[10px] font-bold text-foreground bg-secondary/50 rounded">
          {currentPage} / {totalPages}
        </span>

        <Button
          variant="outline"
          size="sm"
          disabled={currentPage >= totalPages}
          onClick={() => onPageChange(currentPage + 1)}
          className="h-6 px-2 text-[10px] font-medium"
        >
          Next
          <ChevronRight className="h-3 w-3 ml-0.5" />
        </Button>
      </div>
    </div>
  );
}

function ProductDetailContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const id = searchParams.get("id") || "";

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Modals state
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isLabelModalOpen, setIsLabelModalOpen] = useState(false);

  // Copy state
  const [copiedSku, setCopiedSku] = useState(false);

  // Main unified tabs & IMEI search / filter
  const [mainTab, setMainTab] = useState<"ledger" | "imei" | "branches">("ledger");
  const [imeiSearch, setImeiSearch] = useState("");
  const [imeiStatusFilter, setImeiStatusFilter] = useState<string>("ALL");
  const [activeLedgerTab, setActiveLedgerTab] = useState<
    "purchases" | "sales" | "adjustments" | "transfers"
  >("purchases");
  const [ledgerSearch, setLedgerSearch] = useState("");

  // Pagination states
  const [imeiPage, setImeiPage] = useState(1);
  const [imeiPageSize, setImeiPageSize] = useState(10);

  const [purchasesPage, setPurchasesPage] = useState(1);
  const [purchasesPageSize, setPurchasesPageSize] = useState(5);

  const [salesPage, setSalesPage] = useState(1);
  const [salesPageSize, setSalesPageSize] = useState(5);

  const [adjustmentsPage, setAdjustmentsPage] = useState(1);
  const [adjustmentsPageSize, setAdjustmentsPageSize] = useState(5);

  const [transfersPage, setTransfersPage] = useState(1);
  const [transfersPageSize, setTransfersPageSize] = useState(5);

  // Auto reset IMEI page on search or filter change
  useEffect(() => {
    setImeiPage(1);
  }, [imeiSearch, imeiStatusFilter]);

  // Auto reset Ledger pages on search or sub-tab change
  useEffect(() => {
    setPurchasesPage(1);
    setSalesPage(1);
    setAdjustmentsPage(1);
    setTransfersPage(1);
  }, [ledgerSearch, activeLedgerTab]);

  // Auth check
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  const businessId = currentUser?.businessId || "";
  const { symbol, format } = useCurrency(businessId);

  // Queries
  const {
    data: product,
    isLoading: productLoading,
    error: productError,
    refetch,
  } = useProductByIdQuery(id, businessId);
  const { data: spgList = [] } = useSpgQuery(businessId);
  const { data: branchesList = [] } = useBranchesQuery(businessId);

  // Dedicated query for IMEIs of this product using the active imeiService
  const { data: imeiData } = useQuery({
    queryKey: ["product-imeis", id, businessId],
    queryFn: () => imeiService.getImeis({ businessId, productId: id, limit: 300 }),
    enabled: !!id && !!businessId,
  });

  const productImeisList = useMemo(() => {
    if (imeiData?.items && imeiData.items.length > 0) {
      return imeiData.items;
    }
    return product?.productImeis || [];
  }, [imeiData, product?.productImeis]);

  // Stock calculations
  const {
    totalStock,
    purchasePrice,
    sellingPrice,
    inventoryValue,
    retailValue,
    potentialProfit,
    marginPercent,
    markupPercent,
    isLowStock,
  } = useMemo(() => {
    if (!product) {
      return {
        totalStock: 0,
        purchasePrice: 0,
        sellingPrice: 0,
        inventoryValue: 0,
        retailValue: 0,
        potentialProfit: 0,
        marginPercent: 0,
        markupPercent: 0,
        isLowStock: false,
      };
    }

    let tStock = 0;
    let invVal = 0;
    let retVal = 0;

    product.variants.forEach((v) => {
      let vQty = 0;
      v.purchaseLines?.forEach((pl) => {
        vQty += pl.quantityRemaining;
      });
      tStock += vQty;
      invVal += vQty * (v.purchasePrice || 0);
      retVal += vQty * (v.sellingPrice || 0);
    });

    const pPrice = product.variants[0]?.purchasePrice || 0;
    const sPrice = product.variants[0]?.sellingPrice || 0;
    const pMargin = sPrice > 0 ? ((sPrice - pPrice) / sPrice) * 100 : 0;
    const pMarkup = pPrice > 0 ? ((sPrice - pPrice) / pPrice) * 100 : 0;
    const lowStock =
      product.enableStock &&
      product.alertQuantity !== null &&
      tStock <= product.alertQuantity;

    return {
      totalStock: tStock,
      purchasePrice: pPrice,
      sellingPrice: sPrice,
      inventoryValue: invVal,
      retailValue: retVal,
      potentialProfit: retVal - invVal,
      marginPercent: pMargin,
      markupPercent: pMarkup,
      isLowStock: lowStock,
    };
  }, [product]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSku(true);
    setTimeout(() => setCopiedSku(false), 2000);
  };

  // Filtered IMEIs
  const filteredImeis = useMemo(() => {
    if (!productImeisList || productImeisList.length === 0) return [];
    let list = productImeisList;
    if (imeiStatusFilter !== "ALL") {
      list = list.filter((item) => item.status === imeiStatusFilter);
    }
    if (!imeiSearch.trim()) return list;
    const q = imeiSearch.toLowerCase().trim();
    return list.filter(
      (item) =>
        item.imeiNumber.toLowerCase().includes(q) ||
        item.status.toLowerCase().includes(q) ||
        (item.branch?.name && item.branch.name.toLowerCase().includes(q))
    );
  }, [productImeisList, imeiSearch, imeiStatusFilter]);

  // Movement histories gathered across variants
  const { allPurchases, allSales, allAdjustments, allTransfers } = useMemo(() => {
    if (!product) {
      return {
        allPurchases: [],
        allSales: [],
        allAdjustments: [],
        allTransfers: [],
      };
    }

    const purchases: any[] = [];
    const rawSales: any[] = [];
    const adjustments: any[] = [];
    const transfers: any[] = [];

    product.variants.forEach((v) => {
      v.purchaseLines?.forEach((pl) => {
        purchases.push({
          ...pl,
          variantName: v.name,
          sku: v.sku,
          variantPurchasePrice: v.purchasePrice,
        });
      });
      v.saleLines?.forEach((sl) => {
        rawSales.push({ ...sl, variantName: v.name, sku: v.sku });
      });
      v.stockAdjustmentLines?.forEach((al) => {
        adjustments.push({ ...al, variantName: v.name, sku: v.sku });
      });
      v.stockTransferLines?.forEach((tl) => {
        transfers.push({ ...tl, variantName: v.name, sku: v.sku });
      });
    });

    // Group sales that belong to the same sale / invoice
    const salesMap = new Map<string, any>();
    rawSales.forEach((sl) => {
      const saleKey = sl.saleId || sl.sale?.id || sl.sale?.invoiceNumber || sl.id;
      if (!salesMap.has(saleKey)) {
        salesMap.set(saleKey, {
          ...sl,
          quantity: Number(sl.quantity) || 0,
          subtotal: Number(sl.subtotal) || 0,
          linesCount: 1,
        });
      } else {
        const existing = salesMap.get(saleKey);
        const addedQty = Number(sl.quantity) || 0;
        const addedSubtotal = Number(sl.subtotal) || 0;
        existing.quantity += addedQty;
        existing.subtotal += addedSubtotal;
        if (existing.quantity > 0) {
          existing.unitPrice = existing.subtotal / existing.quantity;
        }
        existing.linesCount = (existing.linesCount || 1) + 1;
      }
    });
    const sales = Array.from(salesMap.values());

    purchases.sort(
      (a, b) =>
        new Date(b.createdAt || 0).getTime() -
        new Date(a.createdAt || 0).getTime()
    );
    sales.sort(
      (a, b) =>
        new Date(b.sale?.saleDate || b.sale?.createdAt || b.createdAt || 0).getTime() -
        new Date(a.sale?.saleDate || a.sale?.createdAt || a.createdAt || 0).getTime()
    );
    adjustments.sort(
      (a, b) =>
        new Date(b.createdAt || 0).getTime() -
        new Date(a.createdAt || 0).getTime()
    );
    transfers.sort(
      (a, b) =>
        new Date(b.createdAt || 0).getTime() -
        new Date(a.createdAt || 0).getTime()
    );

    return {
      allPurchases: purchases,
      allSales: sales,
      allAdjustments: adjustments,
      allTransfers: transfers,
    };
  }, [product]);

  // Filtered Ledger Arrays based on ledgerSearch
  const filteredPurchases = useMemo(() => {
    if (!allPurchases || allPurchases.length === 0) return [];
    if (!ledgerSearch.trim()) return allPurchases;
    const q = ledgerSearch.toLowerCase().trim();
    return allPurchases.filter((p) => {
      const refNumber = (
        p.purchase?.purchaseNumber ||
        (p.batchNumber
          ? p.batchNumber.startsWith("RESTORE")
            ? "Stock Restored"
            : p.batchNumber
          : "Opening Stock")
      ).toLowerCase();
      const supplier = (
        p.purchase?.supplier?.name ||
        (p.batchNumber?.startsWith("RESTORE")
          ? "System Restore"
          : "Direct Entry")
      ).toLowerCase();
      const branch = (
        p.branch?.name ||
        p.purchase?.branch?.name ||
        branchesList.find((b: any) => b.id === p.branchId)?.name ||
        ""
      ).toLowerCase();
      const date = (
        p.purchase?.purchaseDate
          ? new Date(p.purchase.purchaseDate).toLocaleDateString()
          : p.createdAt
          ? new Date(p.createdAt).toLocaleDateString()
          : ""
      ).toLowerCase();
      return (
        refNumber.includes(q) ||
        supplier.includes(q) ||
        branch.includes(q) ||
        date.includes(q)
      );
    });
  }, [allPurchases, ledgerSearch, branchesList]);

  const filteredSales = useMemo(() => {
    if (!allSales || allSales.length === 0) return [];
    if (!ledgerSearch.trim()) return allSales;
    const q = ledgerSearch.toLowerCase().trim();
    return allSales.filter((s) => {
      const invoice = (s.sale?.invoiceNumber || "POS Sale").toLowerCase();
      const customer = (s.sale?.customer?.name || "Walk-in Customer").toLowerCase();
      const branch = (s.branch?.name || s.sale?.branch?.name || "").toLowerCase();
      const date = (
        s.sale?.saleDate
          ? new Date(s.sale.saleDate).toLocaleDateString()
          : s.createdAt
          ? new Date(s.createdAt).toLocaleDateString()
          : ""
      ).toLowerCase();
      return (
        invoice.includes(q) ||
        customer.includes(q) ||
        branch.includes(q) ||
        date.includes(q)
      );
    });
  }, [allSales, ledgerSearch]);

  const filteredAdjustments = useMemo(() => {
    if (!allAdjustments || allAdjustments.length === 0) return [];
    if (!ledgerSearch.trim()) return allAdjustments;
    const q = ledgerSearch.toLowerCase().trim();
    return allAdjustments.filter((a) => {
      const adjNum = (
        a.stockAdjustment?.adjustmentNumber || "Manual Adj"
      ).toLowerCase();
      const reason = (a.stockAdjustment?.reason || "").toLowerCase();
      const type = (a.stockAdjustment?.type || "").toLowerCase();
      const branch = (
        a.branch?.name ||
        a.stockAdjustment?.branch?.name ||
        ""
      ).toLowerCase();
      const date = (
        a.stockAdjustment?.adjustmentDate
          ? new Date(a.stockAdjustment.adjustmentDate).toLocaleDateString()
          : a.createdAt
          ? new Date(a.createdAt).toLocaleDateString()
          : ""
      ).toLowerCase();
      return (
        adjNum.includes(q) ||
        reason.includes(q) ||
        type.includes(q) ||
        branch.includes(q) ||
        date.includes(q)
      );
    });
  }, [allAdjustments, ledgerSearch]);

  const filteredTransfers = useMemo(() => {
    if (!allTransfers || allTransfers.length === 0) return [];
    if (!ledgerSearch.trim()) return allTransfers;
    const q = ledgerSearch.toLowerCase().trim();
    return allTransfers.filter((t) => {
      const trNum = (
        t.stockTransfer?.transferNumber || "Direct Transfer"
      ).toLowerCase();
      const fromBranch = (t.stockTransfer?.fromBranch?.name || "").toLowerCase();
      const toBranch = (t.stockTransfer?.toBranch?.name || "").toLowerCase();
      const status = (t.stockTransfer?.status || "").toLowerCase();
      const date = (
        t.stockTransfer?.transferDate
          ? new Date(t.stockTransfer.transferDate).toLocaleDateString()
          : t.createdAt
          ? new Date(t.createdAt).toLocaleDateString()
          : ""
      ).toLowerCase();
      return (
        trNum.includes(q) ||
        fromBranch.includes(q) ||
        toBranch.includes(q) ||
        status.includes(q) ||
        date.includes(q)
      );
    });
  }, [allTransfers, ledgerSearch]);

  // Paginated Slices
  const paginatedImeis = useMemo(() => {
    const start = (imeiPage - 1) * imeiPageSize;
    return filteredImeis.slice(start, start + imeiPageSize);
  }, [filteredImeis, imeiPage, imeiPageSize]);

  const paginatedPurchases = useMemo(() => {
    const start = (purchasesPage - 1) * purchasesPageSize;
    return filteredPurchases.slice(start, start + purchasesPageSize);
  }, [filteredPurchases, purchasesPage, purchasesPageSize]);

  const paginatedSales = useMemo(() => {
    const start = (salesPage - 1) * salesPageSize;
    return filteredSales.slice(start, start + salesPageSize);
  }, [filteredSales, salesPage, salesPageSize]);

  const paginatedAdjustments = useMemo(() => {
    const start = (adjustmentsPage - 1) * adjustmentsPageSize;
    return filteredAdjustments.slice(start, start + adjustmentsPageSize);
  }, [filteredAdjustments, adjustmentsPage, adjustmentsPageSize]);

  const paginatedTransfers = useMemo(() => {
    const start = (transfersPage - 1) * transfersPageSize;
    return filteredTransfers.slice(start, start + transfersPageSize);
  }, [filteredTransfers, transfersPage, transfersPageSize]);

  if (isAuthenticated === null || currentUser === null) {
    return <LoadingSession />;
  }

  if (isAuthenticated === false) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="text-center space-y-3 p-6 bg-card border border-border rounded-sm max-w-sm shadow-lg">
          <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
          <p className="text-sm text-muted-foreground">Redirecting to login...</p>
        </div>
      </div>
    );
  }

  if (productLoading) {
    return (
      <div className="flex h-screen bg-background">
        <Sidebar activePath="/products" />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Navbar title="Product Details" />
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center space-y-2">
              <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
              <p className="text-sm text-muted-foreground">
                Loading product details...
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (productError || !product) {
    return (
      <div className="flex h-screen bg-background">
        <Sidebar activePath="/products" />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Navbar title="Product Details" />
          <div className="flex-1 flex items-center justify-center p-6">
            <div className="text-center space-y-4 max-w-md p-6 bg-destructive/10 border border-destructive/20 rounded-sm">
              <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
              <div>
                <h3 className="font-bold text-foreground">Failed to load product</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  {productError?.message ||
                    "The requested product could not be found or you do not have permission to view it."}
                </p>
              </div>
              <Button
                onClick={() => router.push("/products")}
                variant="outline"
                className="w-full"
              >
                Back to Products List
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const primaryVariant = product.variants[0];
  const primarySku = primaryVariant?.sku || "N/A";
  const primaryBarcode = primaryVariant?.barcode || primaryVariant?.sku || "";

  return (
    <div className="flex h-screen bg-background">
      <Sidebar activePath="/products" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Product Details" />
        <main className="flex-1 overflow-y-auto p-3.5 md:p-5 space-y-3.5">
          {/* Header & Quick Action Toolbar */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-b border-border/40 pb-3">
            <div className="flex items-center gap-2.5">
              <Button
                variant="outline"
                size="icon"
                onClick={() => router.push("/products")}
                className="h-8 w-8 rounded-full shrink-0"
              >
                <ArrowLeft className="h-3.5 w-3.5" />
              </Button>
              <div>
                <div className="flex flex-wrap items-center gap-1.5">
                  <h1 className="text-lg md:text-xl font-black text-foreground uppercase tracking-tight">
                    {product.name}
                  </h1>
                  <span
                    className={cn(
                      "px-2 py-0.5 rounded-sm text-[9px] font-bold border uppercase tracking-wider",
                      product.isActive
                        ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
                        : "bg-destructive/10 text-destructive border-destructive/20"
                    )}
                  >
                    {product.isActive ? "Active" : "Inactive"}
                  </span>
                  <span className="px-2 py-0.5 rounded-sm text-[9px] font-bold bg-secondary border border-border/60 text-secondary-foreground uppercase tracking-wider">
                    {product.type}
                  </span>
                  {product.notForSelling && (
                    <span className="bg-amber-500/10 text-amber-500 border border-amber-500/20 px-2 py-0.5 rounded-sm text-[9px] font-bold uppercase tracking-wider flex items-center gap-1">
                      <Ban className="h-2.5 w-2.5" /> Not For Sale
                    </span>
                  )}
                  {(product.isImei || product.enableImei) && (
                    <span className="bg-primary/10 text-primary border border-primary/20 px-2 py-0.5 rounded-sm text-[9px] font-bold uppercase tracking-wider flex items-center gap-1">
                      <Smartphone className="h-2.5 w-2.5" /> IMEI
                    </span>
                  )}
                </div>
                <div className="flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground mt-0.5">
                  <span>
                    SKU: <strong className="text-foreground">{primarySku}</strong>
                  </span>
                  <span>•</span>
                  <span>
                    Business ID:{" "}
                    <span className="font-mono text-[10px] text-muted-foreground">
                      {product.businessId}
                    </span>
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Actions Toolbar */}
            <div className="flex flex-wrap items-center gap-1.5">
              {/* Print Labels Button */}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsLabelModalOpen(true)}
                className="h-8 font-semibold text-xs flex items-center gap-1 border-border/80 hover:border-primary/50 rounded-sm"
              >
                <Printer className="h-3.5 w-3.5 text-primary" /> Print Labels
              </Button>

              {/* Add Purchase Button */}
              <Button
                variant="outline"
                size="sm"
                onClick={() => router.push("/purchases/create")}
                className="h-8 font-semibold text-xs flex items-center gap-1 border-border/80 hover:border-emerald-500/50 hover:text-emerald-500 rounded-sm"
              >
                <ShoppingBag className="h-3.5 w-3.5 text-emerald-500" /> Add Purchase
              </Button>

              {/* Adjust Stock Button */}
              <Button
                variant="outline"
                size="sm"
                onClick={() => router.push("/stock-adjustments")}
                className="h-8 font-semibold text-xs flex items-center gap-1 border-border/80 hover:border-amber-500/50 rounded-sm"
              >
                <SlidersHorizontal className="h-3.5 w-3.5 text-amber-500" /> Adjust Stock
              </Button>

              {/* Transfer Stock Button */}
              <Button
                variant="outline"
                size="sm"
                onClick={() => router.push("/stock-transfers")}
                className="h-8 font-semibold text-xs flex items-center gap-1 border-border/80 hover:border-blue-500/50 rounded-sm"
              >
                <ArrowRightLeft className="h-3.5 w-3.5 text-blue-500" /> Transfer Stock
              </Button>

              {/* Edit Product Button */}
              <Button
                onClick={() => setIsEditModalOpen(true)}
                className="h-8 font-bold flex items-center gap-1.5 text-xs bg-primary text-primary-foreground shadow-sm rounded-sm"
              >
                <Edit className="h-3.5 w-3.5" /> Edit Product
              </Button>
            </div>
          </div>

          {/* Metric Dashboard / Compact Stock Valuation Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Total Stock Available */}
            <div className="p-3 rounded-sm border border-border border-t-2 border-t-primary bg-card space-y-0.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                  Available Stock
                </span>
                <Package className="h-3.5 w-3.5 text-primary" />
              </div>
              <div className="flex items-baseline gap-1.5 mt-0.5">
                <span
                  className={cn(
                    "text-lg font-black",
                    totalStock === 0
                      ? "text-destructive"
                      : isLowStock
                      ? "text-amber-500"
                      : "text-foreground"
                  )}
                >
                  {totalStock}
                </span>
                <span className="text-[11px] text-muted-foreground font-semibold">
                  {product.unit?.code || "units"}
                </span>
              </div>
              <div className="text-[9px] font-medium text-muted-foreground truncate">
                {totalStock === 0 ? (
                  <span className="text-destructive font-bold">Out of stock</span>
                ) : isLowStock ? (
                  <span className="text-amber-500 font-bold">
                    Low stock (≤ {product.alertQuantity})
                  </span>
                ) : (
                  <span className="text-emerald-500 font-bold">Healthy inventory level</span>
                )}
              </div>
            </div>

            {/* Inventory Cost Value */}
            <div className="p-3 rounded-sm border border-border border-t-2 border-t-blue-500 bg-card space-y-0.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                  Total Cost Value
                </span>
                <DollarSign className="h-3.5 w-3.5 text-blue-500" />
              </div>
              <div className="mt-0.5">
                <span className="text-lg font-black text-foreground">
                  {format(inventoryValue)}
                </span>
              </div>
              <p className="text-[9px] text-muted-foreground truncate">
                Total purchase cost
              </p>
            </div>

            {/* Potential Retail Value */}
            <div className="p-3 rounded-sm border border-border border-t-2 border-t-emerald-500 bg-card space-y-0.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                  Potential Retail Value
                </span>
                <ShoppingCart className="h-3.5 w-3.5 text-emerald-500" />
              </div>
              <div className="mt-0.5">
                <span className="text-lg font-black text-emerald-500">
                  {format(retailValue)}
                </span>
              </div>
              <p className="text-[9px] text-muted-foreground truncate">
                Estimated revenue
              </p>
            </div>

            {/* Estimated Gross Profit */}
            <div className="p-3 rounded-sm border border-border border-t-2 border-t-primary bg-card space-y-0.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                  Projected Gross Profit
                </span>
                <TrendingUp className="h-3.5 w-3.5 text-primary" />
              </div>
              <div className="mt-0.5 flex items-baseline gap-1.5">
                <span className="text-lg font-black text-primary">
                  {format(potentialProfit)}
                </span>
                {marginPercent > 0 && (
                  <span className="text-[10px] font-bold text-emerald-500 bg-emerald-500/10 px-1 py-0.2 rounded">
                    {marginPercent.toFixed(1)}% margin
                  </span>
                )}
              </div>
              <p className="text-[9px] text-muted-foreground truncate">
                Gross profit on full sellout
              </p>
            </div>
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3.5">
            {/* Left Column - Gallery, Attributes, Barcode & Audit */}
            <div className="space-y-3.5">
              {/* Product Image Card */}
              <div className="p-3 rounded-sm border border-border border-t-2 border-t-primary bg-card flex flex-col items-center justify-center min-h-[160px] relative overflow-hidden group">
                {product.imageUrl ? (
                  <img
                    src={getFullAssetUrl(product.imageUrl) || ""}
                    alt={product.name}
                    className="max-h-40 object-contain rounded transition-transform group-hover:scale-105 duration-300"
                  />
                ) : (
                  <div className="text-center space-y-1">
                    <Package className="h-12 w-12 text-muted-foreground/30 mx-auto" />
                    <p className="text-[11px] text-muted-foreground/60 font-medium">
                      No Image Uploaded
                    </p>
                  </div>
                )}
              </div>

              {/* Barcode & SKU Card */}
              <div className="p-3 rounded-sm border border-border border-t-2 border-t-primary bg-card space-y-2.5">
                <div className="flex items-center justify-between border-b border-border/40 pb-1.5">
                  <h3 className="text-[11px] font-black text-foreground uppercase tracking-wider flex items-center gap-1">
                    <Barcode className="h-3.5 w-3.5 text-primary" /> SKU & Barcode
                  </h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsLabelModalOpen(true)}
                    className="h-6 text-[10px] font-bold text-primary hover:text-primary px-1.5"
                  >
                    <Printer className="h-3 w-3 mr-1" /> Print
                  </Button>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between p-2 rounded-sm bg-secondary/15 border border-border/40">
                    <div>
                      <span className="text-[8px] font-bold uppercase tracking-wider text-muted-foreground block">
                        SKU Number
                      </span>
                      <span className="text-xs font-mono font-bold text-foreground">
                        {primarySku}
                      </span>
                    </div>
                    <button
                      onClick={() => copyToClipboard(primarySku)}
                      className="p-1 text-muted-foreground hover:text-foreground rounded transition hover:bg-secondary"
                      title="Copy SKU"
                    >
                      {copiedSku ? (
                        <Check className="h-3 w-3 text-emerald-500" />
                      ) : (
                        <Copy className="h-3 w-3" />
                      )}
                    </button>
                  </div>

                  {primaryBarcode && (
                    <div className="p-2 rounded-sm bg-secondary/15 border border-border/40">
                      <span className="text-[8px] font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                        Barcode Scannable Preview
                      </span>
                      <SvgBarcodeDisplay value={primaryBarcode} />
                    </div>
                  )}
                </div>
              </div>

              {/* Key Attributes Card */}
              <div className="p-3 rounded-sm border border-border border-t-2 border-t-primary bg-card space-y-3">
                <h3 className="text-[11px] font-black text-foreground uppercase tracking-wider border-b border-border/40 pb-1.5">
                  Key Attributes
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-0.5">
                    <span className="text-[9px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                      <Layers className="h-2.5 w-2.5" /> Category
                    </span>
                    <span className="text-xs font-semibold text-foreground block">
                      {product.category?.name || "None"}
                    </span>
                  </div>
                  <div className="space-y-0.5">
                    <span className="text-[9px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                      <Tag className="h-2.5 w-2.5" /> Brand
                    </span>
                    <span className="text-xs font-semibold text-foreground block">
                      {product.brand?.name || "None"}
                    </span>
                  </div>
                  <div className="space-y-0.5">
                    <span className="text-[9px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                      <Scale className="h-2.5 w-2.5" /> Unit
                    </span>
                    <span className="text-xs font-semibold text-foreground block">
                      {product.unit
                        ? `${product.unit.name} (${product.unit.code})`
                        : "None"}
                    </span>
                  </div>
                  <div className="space-y-0.5">
                    <span className="text-[9px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                      <ShieldCheck className="h-2.5 w-2.5" /> Warranty
                    </span>
                    <span className="text-xs font-semibold text-foreground block">
                      {product.warranty?.name || "No Warranty"}
                    </span>
                  </div>
                  <div className="space-y-0.5">
                    <span className="text-[9px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                      <Scale className="h-2.5 w-2.5" /> Weight
                    </span>
                    <span className="text-xs font-semibold text-foreground block">
                      {product.weight !== null
                        ? `${product.weight} ${product.unit?.code || ""}`
                        : "None"}
                    </span>
                  </div>
                  <div className="space-y-0.5">
                    <span className="text-[9px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                      <Globe className="h-2.5 w-2.5" /> Scope
                    </span>
                    <span className="text-xs font-semibold text-foreground block">
                      {!product.branches || product.branches.length === 0
                        ? "Global (All Branches)"
                        : "Restricted Branches"}
                    </span>
                  </div>
                </div>
              </div>

              {/* Stock Control Status */}
              <div className="p-3 rounded-sm border border-border border-t-2 border-t-primary bg-card space-y-2.5">
                <h3 className="text-[11px] font-black text-foreground uppercase tracking-wider border-b border-border/40 pb-1.5">
                  Stock Control Status
                </h3>
                <div className="space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Inventory Tracking</span>
                    <span className="font-bold uppercase text-foreground">
                      {product.enableStock ? "Enabled" : "Disabled"}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">IMEI / Serial Tracking</span>
                    <span
                      className={`font-bold uppercase ${
                        product.isImei || product.enableImei
                          ? "text-primary"
                          : "text-muted-foreground"
                      }`}
                    >
                      {product.isImei || product.enableImei ? "Active" : "Disabled"}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Alert Quantity</span>
                    <span className="font-semibold text-foreground">
                      {product.alertQuantity} {product.unit?.code || "units"}
                    </span>
                  </div>
                  <div className="flex items-center justify-between border-t border-border/30 pt-1.5">
                    <span className="text-muted-foreground font-semibold">
                      Total Remaining
                    </span>
                    <span className="font-black text-xs text-foreground">
                      {totalStock} {product.unit?.code || "units"}
                    </span>
                  </div>
                </div>
              </div>

              {/* Audit Information Card */}
              <div className="p-3 rounded-sm border border-border border-t-2 border-t-primary bg-card space-y-2.5">
                <h3 className="text-[11px] font-black text-foreground uppercase tracking-wider border-b border-border/40 pb-1.5 flex items-center gap-1">
                  <Clock className="h-3 w-3 text-muted-foreground" /> Audit &
                  System Info
                </h3>
                <div className="space-y-2 text-[11px]">
                  <div className="space-y-0.5">
                    <span className="text-[8px] font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1">
                      <UserIcon className="h-2.5 w-2.5" /> Created By
                    </span>
                    <span className="text-foreground font-medium block">
                      {product.createdBy?.name || "System"}{" "}
                      {product.createdAt && (
                        <span className="text-muted-foreground text-[10px]">
                          on {new Date(product.createdAt).toLocaleDateString()}
                        </span>
                      )}
                    </span>
                  </div>

                  <div className="space-y-0.5">
                    <span className="text-[8px] font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1">
                      <History className="h-2.5 w-2.5" /> Last Modified
                    </span>
                    <span className="text-foreground font-medium block">
                      {product.updatedBy?.name || "System"}{" "}
                      {product.updatedAt && (
                        <span className="text-muted-foreground text-[10px]">
                          on {new Date(product.updatedAt).toLocaleDateString()}
                        </span>
                      )}
                    </span>
                  </div>

                  <div className="space-y-0.5 pt-1 border-t border-border/30">
                    <span className="text-[8px] font-bold uppercase tracking-wider text-muted-foreground block">
                      System Product ID
                    </span>
                    <span className="font-mono text-[9px] text-muted-foreground break-all select-all">
                      {product.id}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column - Pricing, Margin, Branches, IMEIs, Ledger History */}
            <div className="lg:col-span-2 space-y-3.5">
              {/* Product Description */}
              <div className="p-3.5 rounded-sm border border-border border-t-2 border-t-primary bg-card space-y-2">
                <h3 className="text-[11px] font-black text-foreground uppercase tracking-wider border-b border-border/40 pb-1.5">
                  Product Description
                </h3>
                <div className="ql-snow">
                  <div
                    className="ql-editor !p-0 !min-h-0 text-xs text-foreground/90 leading-relaxed rich-text-display"
                    dangerouslySetInnerHTML={{
                      __html:
                        product.description ||
                        "<i>No description available for this product.</i>",
                    }}
                  />
                </div>
              </div>

              {/* Pricing & Profit Margin Analysis */}
              {product.type === "SINGLE" && (
                <div className="p-3.5 rounded-sm border border-border border-t-2 border-t-primary bg-card space-y-3">
                  <div className="flex items-center justify-between border-b border-border/40 pb-1.5">
                    <h3 className="text-[11px] font-black text-foreground uppercase tracking-wider flex items-center gap-1">
                      <DollarSign className="h-3.5 w-3.5 text-emerald-500" /> Pricing & Profit
                      Margin Analysis
                    </h3>
                    <span
                      className={cn(
                        "text-[9px] font-black uppercase px-2 py-0.5 rounded-sm border",
                        marginPercent >= 25
                          ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
                          : marginPercent >= 10
                          ? "bg-blue-500/10 text-blue-500 border-blue-500/20"
                          : "bg-amber-500/10 text-amber-500 border-amber-500/20"
                      )}
                    >
                      {marginPercent >= 25
                        ? "High Margin"
                        : marginPercent >= 10
                        ? "Standard Margin"
                        : "Low Margin"}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    {/* Purchase Cost */}
                    <div className="p-2.5 rounded-sm bg-secondary/15 border border-border/40 space-y-0.5">
                      <span className="text-[9px] font-bold text-muted-foreground uppercase block">
                        Cost Price
                      </span>
                      <span className="text-sm sm:text-base font-black text-foreground block">
                        {format(purchasePrice)}
                      </span>
                    </div>

                    {/* Selling Price */}
                    <div className="p-2.5 rounded-sm bg-emerald-500/5 border border-emerald-500/20 space-y-0.5">
                      <span className="text-[9px] font-bold text-emerald-500 uppercase block">
                        Selling Price
                      </span>
                      <span className="text-sm sm:text-base font-black text-emerald-500 block">
                        {format(sellingPrice)}
                      </span>
                    </div>

                    {/* Unit Profit */}
                    <div className="p-2.5 rounded-sm bg-primary/5 border border-primary/20 space-y-0.5">
                      <span className="text-[9px] font-bold text-primary uppercase block">
                        Gross Profit / Unit
                      </span>
                      <span className="text-sm sm:text-base font-black text-primary block">
                        {format(sellingPrice - purchasePrice)}
                      </span>
                    </div>

                    {/* Profit Margin % */}
                    <div className="p-2.5 rounded-sm bg-secondary/15 border border-border/40 space-y-0.5">
                      <span className="text-[9px] font-bold text-muted-foreground uppercase block">
                        Margin / Markup
                      </span>
                      <div className="flex items-baseline gap-1">
                        <span className="text-sm sm:text-base font-black text-foreground">
                          {marginPercent.toFixed(1)}%
                        </span>
                        <span className="text-[9px] text-muted-foreground font-semibold">
                          ({markupPercent.toFixed(0)}% MU)
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Selling Price Groups */}
                  {primaryVariant?.groupPrices &&
                    primaryVariant.groupPrices.length > 0 && (
                      <div className="space-y-1.5 pt-1.5 border-t border-border/30">
                        <span className="text-[9px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                          <Coins className="h-3 w-3 text-primary" /> Selling Price
                          Groups (Tiered Pricing)
                        </span>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                          {primaryVariant.groupPrices.map((gp) => {
                            const matchingSpg = spgList.find(
                              (s: any) => s.id === gp.sellingPriceGroupId
                            );
                            return (
                              <div
                                key={gp.sellingPriceGroupId}
                                className="p-2 bg-secondary/15 border border-border/40 rounded-sm"
                              >
                                <span className="text-[9px] font-bold text-muted-foreground block truncate">
                                  {matchingSpg?.name || "Group"}
                                </span>
                                <span className="text-xs font-extrabold text-foreground block">
                                  {format(gp.price)}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                </div>
              )}

              {/* Variable Products Matrix (if VARIABLE) */}
              {product.type === "VARIABLE" && (
                <div className="p-3.5 rounded-sm border border-border border-t-2 border-t-primary bg-card space-y-3">
                  <h3 className="text-[11px] font-black text-foreground uppercase tracking-wider border-b border-border/40 pb-1.5">
                    Configured Variants Matrix ({product.variants.length} Variants)
                  </h3>
                  <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
                    {product.variants.map((variant) => {
                      let vStock = 0;
                      variant.purchaseLines?.forEach((pl) => {
                        vStock += pl.quantityRemaining;
                      });
                      const vMargin =
                        variant.sellingPrice > 0
                          ? ((variant.sellingPrice - variant.purchasePrice) /
                              variant.sellingPrice) *
                            100
                          : 0;

                      return (
                        <div
                          key={variant.id}
                          className="p-3 border border-border/50 rounded-sm bg-secondary/10 space-y-2 hover:border-primary/40 transition"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-1.5 border-b border-border/30 pb-1.5">
                            <span className="text-xs font-black text-foreground">
                              {variant.name}
                            </span>
                            <div className="flex items-center gap-1.5">
                              <span className="text-[9px] font-mono text-muted-foreground bg-secondary px-1.5 py-0.5 rounded-sm">
                                SKU: {variant.sku}
                              </span>
                              {variant.barcode && (
                                <span className="text-[9px] font-mono text-muted-foreground bg-secondary px-1.5 py-0.5 rounded-sm">
                                  BC: {variant.barcode}
                                </span>
                              )}
                            </div>
                          </div>

                          <div className="grid grid-cols-4 gap-2">
                            <div>
                              <span className="text-[8px] font-bold text-muted-foreground uppercase block">
                                Cost
                              </span>
                              <span className="text-xs font-bold text-foreground">
                                {format(variant.purchasePrice)}
                              </span>
                            </div>
                            <div>
                              <span className="text-[8px] font-bold text-emerald-500 uppercase block">
                                Selling Price
                              </span>
                              <span className="text-xs font-black text-emerald-500">
                                {format(variant.sellingPrice)}
                              </span>
                            </div>
                            <div>
                              <span className="text-[8px] font-bold text-primary uppercase block">
                                Margin
                              </span>
                              <span className="text-xs font-bold text-primary">
                                {vMargin.toFixed(1)}%
                              </span>
                            </div>
                            <div>
                              <span className="text-[8px] font-bold text-muted-foreground uppercase block">
                                In Stock
                              </span>
                              <span
                                className={cn(
                                  "text-xs font-black",
                                  vStock === 0 ? "text-destructive" : "text-foreground"
                                )}
                              >
                                {vStock} {product.unit?.code || "units"}
                              </span>
                            </div>
                          </div>

                          {/* Branch wise stock */}
                          {product.enableStock && (
                            <div className="p-1.5 rounded-sm bg-background/50 border border-border/40 text-[9px] grid grid-cols-2 gap-1.5">
                              {branchesList.map((branch: any) => {
                                let bStock = 0;
                                variant.purchaseLines?.forEach((pl) => {
                                  if (pl.branchId === branch.id) {
                                    bStock += pl.quantityRemaining;
                                  }
                                });
                                return (
                                  <div
                                    key={branch.id}
                                    className="flex items-center justify-between text-muted-foreground"
                                  >
                                    <span className="truncate">{branch.name}:</span>
                                    <span className="font-bold text-foreground">
                                      {bStock}
                                    </span>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Unified 3-in-1 Tabbed Card: Branch Stock | IMEI Tracker | Movement Ledger */}
              <div className="p-3.5 rounded-sm border border-border border-t-2 border-t-primary bg-card space-y-3">
                {/* Main Tabs Navigation (Elevated Master Tab Bar) */}
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border/50 pb-2">
                  <div className="flex flex-wrap items-center gap-1 p-1 bg-secondary/40 dark:bg-secondary/20 rounded-md border border-border/60">
                    {/* Tab 1: Stock Movement & Ledger */}
                    <button
                      type="button"
                      onClick={() => setMainTab("ledger")}
                      className={cn(
                        "flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-sm transition cursor-pointer select-none",
                        mainTab === "ledger"
                          ? "bg-card text-foreground shadow-xs border border-border/80 ring-1 ring-border/40 font-extrabold"
                          : "text-muted-foreground hover:text-foreground hover:bg-card/50 border border-transparent"
                      )}
                    >
                      <History className={cn("h-3.5 w-3.5", mainTab === "ledger" ? "text-indigo-600 dark:text-indigo-400" : "text-muted-foreground")} />
                      <span>Stock Movement & Ledger</span>
                      <span className={cn(
                        "text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold",
                        mainTab === "ledger"
                          ? "bg-secondary text-foreground"
                          : "bg-secondary/60 text-muted-foreground"
                      )}>
                        {allPurchases.length + allSales.length + allAdjustments.length + allTransfers.length}
                      </span>
                    </button>

                    {/* Tab 2: IMEI / Serial Numbers */}
                    {(product.isImei ||
                      product.enableImei ||
                      productImeisList.length > 0) && (
                      <button
                        type="button"
                        onClick={() => setMainTab("imei")}
                        className={cn(
                          "flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-sm transition cursor-pointer select-none",
                          mainTab === "imei"
                            ? "bg-card text-foreground shadow-xs border border-border/80 ring-1 ring-border/40 font-extrabold"
                            : "text-muted-foreground hover:text-foreground hover:bg-card/50 border border-transparent"
                        )}
                      >
                        <Smartphone className={cn("h-3.5 w-3.5", mainTab === "imei" ? "text-cyan-600 dark:text-cyan-400" : "text-muted-foreground")} />
                        <span>IMEI / Serial Numbers</span>
                        <span className={cn(
                          "text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold",
                          mainTab === "imei"
                            ? "bg-secondary text-foreground"
                            : "bg-secondary/60 text-muted-foreground"
                        )}>
                          {productImeisList.length}
                        </span>
                      </button>
                    )}

                    {/* Tab 3: Branch Stock */}
                    {product.enableStock && (
                      <button
                        type="button"
                        onClick={() => setMainTab("branches")}
                        className={cn(
                          "flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-sm transition cursor-pointer select-none",
                          mainTab === "branches"
                            ? "bg-card text-foreground shadow-xs border border-border/80 ring-1 ring-border/40 font-extrabold"
                            : "text-muted-foreground hover:text-foreground hover:bg-card/50 border border-transparent"
                        )}
                      >
                        <Building2 className={cn("h-3.5 w-3.5", mainTab === "branches" ? "text-emerald-600 dark:text-emerald-400" : "text-muted-foreground")} />
                        <span>Branch Stock</span>
                        <span className={cn(
                          "text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold",
                          mainTab === "branches"
                            ? "bg-secondary text-foreground"
                            : "bg-secondary/60 text-muted-foreground"
                        )}>
                          {branchesList.length}
                        </span>
                      </button>
                    )}
                  </div>

                  {/* Header Quick Action */}
                  {mainTab === "branches" && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => router.push("/stock-transfers")}
                      className="h-6 text-[10px] font-bold text-blue-500 hover:text-blue-500 px-1.5"
                    >
                      <ArrowRightLeft className="h-3 w-3 mr-1" /> Transfer Stock
                    </Button>
                  )}
                </div>

                {/* Tab 1 Content: Branch Stock Breakdown */}
                {mainTab === "branches" && product.enableStock && (
                  <div className="divide-y divide-border/40">
                    {branchesList.map((branch: any) => {
                      const isScoped =
                        !product.branches ||
                        product.branches.length === 0 ||
                        product.branches.some((pb) => pb.branchId === branch.id);
                      if (!isScoped) return null;

                      let qty = 0;
                      product.variants.forEach((v) => {
                        v.purchaseLines?.forEach((pl) => {
                          if (pl.branchId === branch.id) {
                            qty += pl.quantityRemaining;
                          }
                        });
                      });

                      const branchCostValue = qty * purchasePrice;

                      return (
                        <div
                          key={branch.id}
                          className="flex items-center justify-between py-1.5"
                        >
                          <div className="flex items-center gap-2">
                            <Building2 className="h-3.5 w-3.5 text-muted-foreground" />
                            <div>
                              <span className="text-xs font-bold text-foreground block">
                                {branch.name}
                              </span>
                              <span className="text-[9px] text-muted-foreground">
                                Value: {format(branchCostValue)}
                              </span>
                            </div>
                          </div>
                          <span
                            className={cn(
                              "text-[11px] font-bold px-2 py-0.5 rounded-sm",
                              qty === 0
                                ? "bg-destructive/10 text-destructive border border-destructive/20"
                                : qty <= (product.alertQuantity || 0)
                                ? "bg-amber-500/10 text-amber-500 border border-amber-500/20"
                                : "bg-secondary text-secondary-foreground"
                            )}
                          >
                            {qty} {product.unit?.code || "units"}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Tab 2 Content: IMEI / Serial Numbers Tracker */}
                {mainTab === "imei" && (
                  <div className="space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      {/* Summary badges (Clickable Filters) */}
                      {productImeisList.length > 0 ? (
                        <div className="flex flex-wrap items-center gap-1.5 text-[10px]">
                          <button
                            type="button"
                            onClick={() => setImeiStatusFilter("ALL")}
                            className={cn(
                              "px-2.5 py-1 rounded-sm font-bold transition flex items-center gap-1 cursor-pointer select-none",
                              imeiStatusFilter === "ALL"
                                ? "bg-secondary text-secondary-foreground ring-1 ring-border shadow-xs"
                                : "bg-secondary/40 text-muted-foreground hover:bg-secondary/70 hover:text-foreground"
                            )}
                            title="Show all IMEIs"
                          >
                            <span>Total:</span>
                            <span className="font-mono">{productImeisList.length}</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setImeiStatusFilter("IN_STOCK")}
                            className={cn(
                              "px-2.5 py-1 rounded-sm font-bold transition flex items-center gap-1 cursor-pointer select-none",
                              imeiStatusFilter === "IN_STOCK"
                                ? "bg-emerald-100 text-emerald-900 border border-emerald-300 dark:bg-emerald-950/70 dark:text-emerald-300 dark:border-emerald-600/60 ring-1 ring-emerald-500/30 shadow-xs"
                                : "bg-emerald-50 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-950/30 dark:text-emerald-400 dark:hover:bg-emerald-950/60"
                            )}
                            title="Filter by In Stock"
                          >
                            <span>In Stock:</span>
                            <span className="font-mono">
                              {
                                productImeisList.filter(
                                  (i) => i.status === "IN_STOCK"
                                ).length
                              }
                            </span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setImeiStatusFilter("SOLD")}
                            className={cn(
                              "px-2.5 py-1 rounded-sm font-bold transition flex items-center gap-1 cursor-pointer select-none",
                              imeiStatusFilter === "SOLD"
                                ? "bg-blue-100 text-blue-900 border border-blue-300 dark:bg-blue-950/70 dark:text-blue-300 dark:border-blue-600/60 ring-1 ring-blue-500/30 shadow-xs"
                                : "bg-blue-50 text-blue-700 hover:bg-blue-100 dark:bg-blue-950/30 dark:text-blue-400 dark:hover:bg-blue-950/60"
                            )}
                            title="Filter by Sold"
                          >
                            <span>Sold:</span>
                            <span className="font-mono">
                              {
                                productImeisList.filter((i) => i.status === "SOLD")
                                  .length
                              }
                            </span>
                          </button>
                          {productImeisList.some((i) => i.status === "DEFECTIVE") && (
                            <button
                              type="button"
                              onClick={() => setImeiStatusFilter("DEFECTIVE")}
                              className={cn(
                                "px-2.5 py-1 rounded-sm font-bold transition flex items-center gap-1 cursor-pointer select-none",
                                imeiStatusFilter === "DEFECTIVE"
                                  ? "bg-rose-100 text-rose-900 border border-rose-300 dark:bg-rose-950/70 dark:text-rose-300 dark:border-rose-600/60 ring-1 ring-rose-500/30 shadow-xs"
                                  : "bg-rose-50 text-rose-700 hover:bg-rose-100 dark:bg-rose-950/30 dark:text-rose-400 dark:hover:bg-rose-950/60"
                              )}
                              title="Filter by Defective"
                            >
                              <span>Defective:</span>
                              <span className="font-mono">
                                {
                                  productImeisList.filter(
                                    (i) => i.status === "DEFECTIVE"
                                  ).length
                                }
                              </span>
                            </button>
                          )}
                        </div>
                      ) : (
                        <div />
                      )}

                      <div className="relative w-full sm:w-56">
                        <Search className="h-3 w-3 absolute left-2 top-2 text-muted-foreground" />
                        <input
                          type="text"
                          placeholder="Search IMEI / Serial..."
                          value={imeiSearch}
                          onChange={(e) => setImeiSearch(e.target.value)}
                          className="w-full pl-7 pr-2.5 py-1 bg-background border border-border rounded-sm text-[11px] outline-none focus:ring-1 focus:ring-primary text-foreground"
                        />
                      </div>
                    </div>

                    {/* IMEI List Table */}
                    <div className="overflow-x-auto rounded-sm border border-border/40">
                      <table className="w-full text-xs text-left">
                        <thead className="bg-secondary/30 text-muted-foreground uppercase text-[8px] font-bold">
                          <tr>
                            <th className="p-2">IMEI / Serial Number</th>
                            <th className="p-2">Branch</th>
                            <th className="p-2">Status</th>
                            <th className="p-2">Purchase Date</th>
                            <th className="p-2">Warranty</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-border/30 text-[11px]">
                          {paginatedImeis.length > 0 ? (
                            paginatedImeis.map((imei) => (
                              <tr
                                key={imei.id}
                                className="hover:bg-secondary/15 transition"
                              >
                                <td className="p-2 font-mono font-bold text-foreground">
                                  {imei.imeiNumber}
                                </td>
                                <td className="p-2 text-muted-foreground">
                                  {imei.branch?.name || "Main Branch"}
                                </td>
                                <td className="p-2">
                                  <span
                                    className={cn(
                                      "px-1.5 py-0.5 rounded-sm text-[9px] font-bold uppercase",
                                      imei.status === "IN_STOCK"
                                        ? "bg-emerald-500/10 text-emerald-500"
                                        : imei.status === "SOLD"
                                        ? "bg-blue-500/10 text-blue-500"
                                        : "bg-destructive/10 text-destructive"
                                    )}
                                  >
                                    {imei.status.replace("_", " ")}
                                  </span>
                                </td>
                                <td className="p-2 text-muted-foreground">
                                  {imei.purchaseDate
                                    ? new Date(imei.purchaseDate).toLocaleDateString()
                                    : "—"}
                                </td>
                                <td className="p-2 text-muted-foreground">
                                  {imei.warrantyExpires
                                    ? new Date(imei.warrantyExpires).toLocaleDateString()
                                    : "—"}
                                </td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td
                                colSpan={5}
                                className="p-3 text-center text-muted-foreground italic text-xs"
                              >
                                No IMEI / Serial number records found for this product.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>

                    <PaginationControl
                      currentPage={imeiPage}
                      pageSize={imeiPageSize}
                      totalItems={filteredImeis.length}
                      onPageChange={setImeiPage}
                      onPageSizeChange={(size) => {
                        setImeiPageSize(size);
                        setImeiPage(1);
                      }}
                      pageSizeOptions={[5, 10, 25, 50]}
                    />
                  </div>
                )}

                {/* Tab 3 Content: Stock Movement & Ledger */}
                {mainTab === "ledger" && (
                  <div className="space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      {/* Sub-tabs switch with distinct high-contrast colors */}
                      <div className="flex flex-wrap gap-1.5 p-1 rounded-sm bg-secondary/30 dark:bg-secondary/20 border border-border/60">
                        {/* 1. Purchases Tab */}
                        <button
                          type="button"
                          onClick={() => setActiveLedgerTab("purchases")}
                          className={cn(
                            "flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-bold rounded-sm transition border cursor-pointer select-none",
                            activeLedgerTab === "purchases"
                              ? "bg-emerald-100 text-emerald-950 border-emerald-300 dark:bg-emerald-950/70 dark:text-emerald-300 dark:border-emerald-600/60 shadow-xs ring-1 ring-emerald-500/30"
                              : "text-muted-foreground hover:text-emerald-700 dark:hover:text-emerald-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 border-transparent"
                          )}
                        >
                          <ShoppingBag className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
                          <span>Purchases</span>
                          <span
                            className={cn(
                              "text-[9px] px-1.5 py-0.2 rounded-full font-mono font-bold",
                              activeLedgerTab === "purchases"
                                ? "bg-emerald-200/90 text-emerald-950 dark:bg-emerald-500/30 dark:text-emerald-200"
                                : "bg-secondary text-muted-foreground"
                            )}
                          >
                            {allPurchases.length}
                          </span>
                        </button>

                        {/* 2. Sales Tab */}
                        <button
                          type="button"
                          onClick={() => setActiveLedgerTab("sales")}
                          className={cn(
                            "flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-bold rounded-sm transition border cursor-pointer select-none",
                            activeLedgerTab === "sales"
                              ? "bg-blue-100 text-blue-950 border-blue-300 dark:bg-blue-950/70 dark:text-blue-300 dark:border-blue-600/60 shadow-xs ring-1 ring-blue-500/30"
                              : "text-muted-foreground hover:text-blue-700 dark:hover:text-blue-300 hover:bg-blue-50 dark:hover:bg-blue-950/30 border-transparent"
                          )}
                        >
                          <ShoppingCart className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
                          <span>Sales</span>
                          <span
                            className={cn(
                              "text-[9px] px-1.5 py-0.2 rounded-full font-mono font-bold",
                              activeLedgerTab === "sales"
                                ? "bg-blue-200/90 text-blue-950 dark:bg-blue-500/30 dark:text-blue-200"
                                : "bg-secondary text-muted-foreground"
                            )}
                          >
                            {allSales.length}
                          </span>
                        </button>

                        {/* 3. Adjustments Tab */}
                        <button
                          type="button"
                          onClick={() => setActiveLedgerTab("adjustments")}
                          className={cn(
                            "flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-bold rounded-sm transition border cursor-pointer select-none",
                            activeLedgerTab === "adjustments"
                              ? "bg-amber-100 text-amber-950 border-amber-300 dark:bg-amber-950/70 dark:text-amber-300 dark:border-amber-600/60 shadow-xs ring-1 ring-amber-500/30"
                              : "text-muted-foreground hover:text-amber-700 dark:hover:text-amber-300 hover:bg-amber-50 dark:hover:bg-amber-950/30 border-transparent"
                          )}
                        >
                          <SlidersHorizontal className="h-3.5 w-3.5 text-amber-600 dark:text-amber-400" />
                          <span>Adjustments</span>
                          <span
                            className={cn(
                              "text-[9px] px-1.5 py-0.2 rounded-full font-mono font-bold",
                              activeLedgerTab === "adjustments"
                                ? "bg-amber-200/90 text-amber-950 dark:bg-amber-500/30 dark:text-amber-200"
                                : "bg-secondary text-muted-foreground"
                            )}
                          >
                            {allAdjustments.length}
                          </span>
                        </button>

                        {/* 4. Transfers Tab */}
                        <button
                          type="button"
                          onClick={() => setActiveLedgerTab("transfers")}
                          className={cn(
                            "flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-bold rounded-sm transition border cursor-pointer select-none",
                            activeLedgerTab === "transfers"
                              ? "bg-purple-100 text-purple-950 border-purple-300 dark:bg-purple-950/70 dark:text-purple-300 dark:border-purple-600/60 shadow-xs ring-1 ring-purple-500/30"
                              : "text-muted-foreground hover:text-purple-700 dark:hover:text-purple-300 hover:bg-purple-50 dark:hover:bg-purple-950/30 border-transparent"
                          )}
                        >
                          <ArrowRightLeft className="h-3.5 w-3.5 text-purple-600 dark:text-purple-400" />
                          <span>Transfers</span>
                          <span
                            className={cn(
                              "text-[9px] px-1.5 py-0.2 rounded-full font-mono font-bold",
                              activeLedgerTab === "transfers"
                                ? "bg-purple-200/90 text-purple-950 dark:bg-purple-500/30 dark:text-purple-200"
                                : "bg-secondary text-muted-foreground"
                            )}
                          >
                            {allTransfers.length}
                          </span>
                        </button>
                      </div>

                      {/* Ledger Search Box */}
                      <div className="relative w-full sm:w-56">
                        <Search className="h-3 w-3 absolute left-2 top-2 text-muted-foreground" />
                        <input
                          type="text"
                          placeholder={`Search ${activeLedgerTab}...`}
                          value={ledgerSearch}
                          onChange={(e) => setLedgerSearch(e.target.value)}
                          className="w-full pl-7 pr-2.5 py-1 bg-background border border-border rounded-sm text-[11px] outline-none focus:ring-1 focus:ring-primary text-foreground"
                        />
                      </div>
                    </div>

                    {/* Sub-tab 1: Purchases */}
                    {activeLedgerTab === "purchases" && (
                      <div className="space-y-2">
                        <div className="overflow-x-auto rounded-sm border border-border/40">
                          <table className="w-full text-xs text-left">
                            <thead className="bg-secondary/30 text-muted-foreground uppercase text-[8px] font-bold">
                              <tr>
                                <th className="p-2">Purchase #</th>
                                <th className="p-2">Date</th>
                                <th className="p-2">Supplier</th>
                                <th className="p-2">Branch</th>
                                <th className="p-2 text-right">Qty Received</th>
                                <th className="p-2 text-right">Remaining</th>
                                <th className="p-2 text-right">Unit Cost</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-border/30 text-[11px]">
                              {paginatedPurchases.length > 0 ? (
                                paginatedPurchases.map((p, idx) => {
                                  const branchName =
                                    p.branch?.name ||
                                    p.purchase?.branch?.name ||
                                    branchesList.find((b: any) => b.id === p.branchId)?.name ||
                                    "—";
                                  const unitCost =
                                    p.purchasePrice !== undefined && p.purchasePrice !== null && p.purchasePrice > 0
                                      ? p.purchasePrice
                                      : p.variantPurchasePrice || purchasePrice || 0;
                                  const refNumber =
                                    p.purchase?.purchaseNumber ||
                                    (p.batchNumber ? (p.batchNumber.startsWith("RESTORE") ? "Stock Restored" : p.batchNumber) : "Opening Stock");

                                  return (
                                    <tr key={idx} className="hover:bg-secondary/15 transition">
                                      <td className="p-2 font-bold text-foreground">
                                        {refNumber}
                                      </td>
                                      <td className="p-2 text-muted-foreground">
                                        {p.purchase?.purchaseDate
                                          ? new Date(p.purchase.purchaseDate).toLocaleDateString()
                                          : p.createdAt
                                          ? new Date(p.createdAt).toLocaleDateString()
                                          : "—"}
                                      </td>
                                      <td className="p-2 text-foreground font-medium">
                                        {p.purchase?.supplier?.name || (p.batchNumber?.startsWith("RESTORE") ? "System Restore" : "Direct Entry")}
                                      </td>
                                      <td className="p-2 text-muted-foreground">
                                        {branchName}
                                      </td>
                                      <td className="p-2 text-right font-semibold text-foreground">
                                        {p.quantityPurchased ?? p.quantityRemaining}
                                      </td>
                                      <td className="p-2 text-right font-bold text-emerald-500">
                                        {p.quantityRemaining}
                                      </td>
                                      <td className="p-2 text-right font-mono font-bold text-foreground">
                                        {format(unitCost)}
                                      </td>
                                    </tr>
                                  );
                                })
                              ) : (
                                <tr>
                                  <td
                                    colSpan={7}
                                    className="p-3 text-center text-muted-foreground italic text-xs"
                                  >
                                    No purchase records found for this product yet.
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>

                        <PaginationControl
                          currentPage={purchasesPage}
                          pageSize={purchasesPageSize}
                          totalItems={filteredPurchases.length}
                          onPageChange={setPurchasesPage}
                          onPageSizeChange={(size) => {
                            setPurchasesPageSize(size);
                            setPurchasesPage(1);
                          }}
                          pageSizeOptions={[5, 10, 20, 50]}
                        />
                      </div>
                    )}

                    {/* Sub-tab 2: Sales */}
                    {activeLedgerTab === "sales" && (
                      <div className="space-y-2">
                        <div className="overflow-x-auto rounded-sm border border-border/40">
                          <table className="w-full text-xs text-left">
                            <thead className="bg-secondary/30 text-muted-foreground uppercase text-[8px] font-bold">
                              <tr>
                                <th className="p-2">Invoice #</th>
                                <th className="p-2">Date</th>
                                <th className="p-2">Customer</th>
                                <th className="p-2">Branch</th>
                                <th className="p-2 text-right">Sold Qty</th>
                                <th className="p-2 text-right">Unit Price</th>
                                <th className="p-2 text-right">Subtotal</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-border/30 text-[11px]">
                              {paginatedSales.length > 0 ? (
                                paginatedSales.map((s, idx) => (
                                  <tr key={idx} className="hover:bg-secondary/15 transition">
                                    <td className="p-2 font-bold text-foreground">
                                      {s.sale?.invoiceNumber || "POS Sale"}
                                    </td>
                                    <td className="p-2 text-muted-foreground">
                                      {s.sale?.saleDate
                                        ? new Date(s.sale.saleDate).toLocaleDateString()
                                        : new Date(s.createdAt).toLocaleDateString()}
                                    </td>
                                    <td className="p-2 text-foreground font-medium">
                                      {s.sale?.customer?.name || "Walk-in Customer"}
                                    </td>
                                    <td className="p-2 text-muted-foreground">
                                      {s.branch?.name || s.sale?.branch?.name || "—"}
                                    </td>
                                    <td className="p-2 text-right font-bold text-foreground">
                                      {s.quantity}
                                    </td>
                                    <td className="p-2 text-right font-mono text-foreground">
                                      {format(s.unitPrice)}
                                    </td>
                                    <td className="p-2 text-right font-mono font-black text-emerald-500">
                                      {format(s.subtotal)}
                                    </td>
                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td
                                    colSpan={7}
                                    className="p-3 text-center text-muted-foreground italic text-xs"
                                  >
                                    No recent sales records found for this product.
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>

                        <PaginationControl
                          currentPage={salesPage}
                          pageSize={salesPageSize}
                          totalItems={filteredSales.length}
                          onPageChange={setSalesPage}
                          onPageSizeChange={(size) => {
                            setSalesPageSize(size);
                            setSalesPage(1);
                          }}
                          pageSizeOptions={[5, 10, 20, 50]}
                        />
                      </div>
                    )}

                    {/* Sub-tab 3: Adjustments */}
                    {activeLedgerTab === "adjustments" && (
                      <div className="space-y-2">
                        <div className="overflow-x-auto rounded-sm border border-border/40">
                          <table className="w-full text-xs text-left">
                            <thead className="bg-secondary/30 text-muted-foreground uppercase text-[8px] font-bold">
                              <tr>
                                <th className="p-2">Adjustment #</th>
                                <th className="p-2">Date</th>
                                <th className="p-2">Branch</th>
                                <th className="p-2">Type</th>
                                <th className="p-2">Reason</th>
                                <th className="p-2 text-right">Adjusted Qty</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-border/30 text-[11px]">
                              {paginatedAdjustments.length > 0 ? (
                                paginatedAdjustments.map((a, idx) => (
                                  <tr key={idx} className="hover:bg-secondary/15 transition">
                                    <td className="p-2 font-bold text-foreground">
                                      {a.stockAdjustment?.adjustmentNumber || "Manual Adj"}
                                    </td>
                                    <td className="p-2 text-muted-foreground">
                                      {a.stockAdjustment?.adjustmentDate
                                        ? new Date(
                                            a.stockAdjustment.adjustmentDate
                                          ).toLocaleDateString()
                                        : new Date(a.createdAt).toLocaleDateString()}
                                    </td>
                                    <td className="p-2 text-muted-foreground">
                                      {a.branch?.name ||
                                        a.stockAdjustment?.branch?.name ||
                                        "—"}
                                    </td>
                                    <td className="p-2">
                                      <span
                                        className={cn(
                                          "px-1.5 py-0.5 rounded-sm text-[9px] font-bold uppercase",
                                          a.stockAdjustment?.type === "ADDITION"
                                            ? "bg-emerald-500/10 text-emerald-500"
                                            : "bg-destructive/10 text-destructive"
                                        )}
                                      >
                                        {a.stockAdjustment?.type || "SUBTRACTION"}
                                      </span>
                                    </td>
                                    <td className="p-2 text-muted-foreground">
                                      {a.stockAdjustment?.reason || "Physical count adjustment"}
                                    </td>
                                    <td className="p-2 text-right font-bold text-foreground">
                                      {a.quantity}
                                    </td>
                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td
                                    colSpan={6}
                                    className="p-3 text-center text-muted-foreground italic text-xs"
                                  >
                                    No stock adjustment history found.
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>

                        <PaginationControl
                          currentPage={adjustmentsPage}
                          pageSize={adjustmentsPageSize}
                          totalItems={filteredAdjustments.length}
                          onPageChange={setAdjustmentsPage}
                          onPageSizeChange={(size) => {
                            setAdjustmentsPageSize(size);
                            setAdjustmentsPage(1);
                          }}
                          pageSizeOptions={[5, 10, 20, 50]}
                        />
                      </div>
                    )}

                    {/* Sub-tab 4: Transfers */}
                    {activeLedgerTab === "transfers" && (
                      <div className="space-y-2">
                        <div className="overflow-x-auto rounded-sm border border-border/40">
                          <table className="w-full text-xs text-left">
                            <thead className="bg-secondary/30 text-muted-foreground uppercase text-[8px] font-bold">
                              <tr>
                                <th className="p-2">Transfer #</th>
                                <th className="p-2">Date</th>
                                <th className="p-2">From Branch</th>
                                <th className="p-2">To Branch</th>
                                <th className="p-2">Status</th>
                                <th className="p-2 text-right">Transfer Qty</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-border/30 text-[11px]">
                              {paginatedTransfers.length > 0 ? (
                                paginatedTransfers.map((t, idx) => (
                                  <tr key={idx} className="hover:bg-secondary/15 transition">
                                    <td className="p-2 font-bold text-foreground">
                                      {t.stockTransfer?.transferNumber || "Direct Transfer"}
                                    </td>
                                    <td className="p-2 text-muted-foreground">
                                      {t.stockTransfer?.transferDate
                                        ? new Date(
                                            t.stockTransfer.transferDate
                                          ).toLocaleDateString()
                                        : new Date(t.createdAt).toLocaleDateString()}
                                    </td>
                                    <td className="p-2 text-foreground font-medium">
                                      {t.stockTransfer?.fromBranch?.name || "Main Branch"}
                                    </td>
                                    <td className="p-2 text-foreground font-medium">
                                      {t.stockTransfer?.toBranch?.name || "Target Branch"}
                                    </td>
                                    <td className="p-2">
                                      <span className="px-1.5 py-0.5 rounded-sm text-[9px] font-bold uppercase bg-blue-500/10 text-blue-500">
                                        {t.stockTransfer?.status || "COMPLETED"}
                                      </span>
                                    </td>
                                    <td className="p-2 text-right font-bold text-foreground">
                                      {t.quantity}
                                    </td>
                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td
                                    colSpan={6}
                                    className="p-3 text-center text-muted-foreground italic text-xs"
                                  >
                                    No inter-branch transfer records found.
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>

                        <PaginationControl
                          currentPage={transfersPage}
                          pageSize={transfersPageSize}
                          totalItems={filteredTransfers.length}
                          onPageChange={setTransfersPage}
                          onPageSizeChange={(size) => {
                            setTransfersPageSize(size);
                            setTransfersPage(1);
                          }}
                          pageSizeOptions={[5, 10, 20, 50]}
                        />
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Edit Product Dialog */}
          <ProductDialog
            isOpen={isEditModalOpen}
            onClose={() => setIsEditModalOpen(false)}
            product={product}
            businessId={businessId}
            userId={currentUser?.id || ""}
            onSuccessMessage={(msg) => {
              refetch();
              setIsEditModalOpen(false);
            }}
            onErrorMessage={(msg) => alert(msg)}
          />

          {/* Barcode Label Print Modal */}
          <BarcodeLabelModal
            isOpen={isLabelModalOpen}
            onClose={() => setIsLabelModalOpen(false)}
            product={product}
            currencySymbol={symbol}
            formatPrice={format}
          />
        </main>
      </div>
    </div>
  );
}

export default function ProductDetailPage() {
  return (
    <Suspense
      fallback={
        <div className="flex h-screen bg-background items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      }
    >
      <ProductDetailContent />
    </Suspense>
  );
}
