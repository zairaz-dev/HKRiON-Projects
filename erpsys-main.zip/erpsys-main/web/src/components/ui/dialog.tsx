import * as React from "react"
import { createPortal } from "react-dom"
import { X } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "./button"

/**
 * ==========================================================================
 * DialogProps Interface
 * ==========================================================================
 */
export interface DialogProps {
  /**
   * Controlled state of the dialog open/close.
   */
  isOpen: boolean;
  /**
   * Callback fired when closing the dialog is requested (Escape, Close Button, Backdrop Click).
   */
  onClose: () => void;
  /**
   * Optional header title. Can be text string or a React component with icons.
   */
  title?: React.ReactNode;
  /**
   * Optional header accessory displayed on the right, next to the close button.
   */
  headerAccessory?: React.ReactNode;
  /**
   * Body content of the dialog.
   */
  children: React.ReactNode;
  /**
   * Max width layout constraint for the dialog container.
   */
  size?: "sm" | "md" | "lg" | "xl" | "2xl" | "3xl" | "4xl" | "5xl" | "full";
  /**
   * If true, clicking on the dark background overlay will close the dialog.
   */
  closeOnOutsideClick?: boolean;
  /**
   * Additional class names for the outer dialog frame.
   */
  className?: string;
  /**
   * Additional class names for the backdrop overlay background.
   */
  overlayClassName?: string;
  /**
   * Additional class names for the internal content body.
   */
  contentClassName?: string;
}

const sizeClasses = {
  sm: "max-w-sm",
  md: "max-w-md",
  lg: "max-w-lg",
  xl: "max-w-xl",
  "2xl": "max-w-2xl",
  "3xl": "max-w-3xl",
  "4xl": "max-w-4xl",
  "5xl": "max-w-5xl",
  full: "max-w-[95vw] md:max-w-[90vw] h-[90vh]",
};

/**
 * ==========================================================================
 * Reusable Dialog Component
 * ==========================================================================
 * 
 * A premium, responsive modal dialog window designed with glassmorphism, 
 * overlay blur, and smooth scaling slide animations. 
 * Mounts via React Portals directly on document.body for clean layout isolation.
 */
export function Dialog({
  isOpen,
  onClose,
  title,
  headerAccessory,
  children,
  size = "md",
  closeOnOutsideClick = true,
  className,
  overlayClassName,
  contentClassName,
}: DialogProps) {
  const [mounted, setMounted] = React.useState(false);
  const [renderDialog, setRenderDialog] = React.useState(isOpen);
  const [isClosing, setIsClosing] = React.useState(false);

  React.useEffect(() => {
    setMounted(true);
    return () => setMounted(false);
  }, []);

  React.useEffect(() => {
    if (isOpen) {
      setRenderDialog(true);
      setIsClosing(false);
    } else if (renderDialog) {
      // Smooth exit animation
      setIsClosing(true);
      const timer = setTimeout(() => {
        setRenderDialog(false);
        setIsClosing(false);
      }, 180);
      return () => clearTimeout(timer);
    }
  }, [isOpen, renderDialog]);

  React.useEffect(() => {
    if (!renderDialog) return;

    // Handle ESC keyboard press to close dialog
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    
    // Prevent document body scrolling
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = originalOverflow;
    };
  }, [renderDialog, onClose]);

  if (!renderDialog || !mounted) return null;

  const dialogContent = (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 overflow-hidden"
      onClick={closeOnOutsideClick ? onClose : undefined}
    >
      {/* Backdrop Overlay */}
      <div 
        className={cn(
          "fixed inset-0 bg-black/65 backdrop-blur-sm -z-10",
          isClosing ? "animate-overlay-exit" : "animate-overlay-enter",
          overlayClassName
        )}
      />

      {/* Dialog Frame Container */}
      <div
        className={cn(
          "relative z-10 w-full rounded-sm border border-primary/25 bg-card pt-6 pb-6 pl-6 pr-0 shadow-[0_25px_50px_-12px_rgba(0,0,0,0.5),_0_0_30px_rgba(34,197,94,0.15)] flex flex-col max-h-[90vh] overflow-hidden will-change-transform",
          isClosing ? "animate-dialog-exit" : "animate-dialog-enter",
          sizeClasses[size],
          className
        )}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Section */}
        {(title || headerAccessory) && (
          <div className="flex items-center justify-between border-b border-border/40 pb-3 mb-4 shrink-0 pr-6">
            {title && (
              <h3 className="text-md font-bold text-foreground flex items-center gap-2">
                {title}
              </h3>
            )}
            <div className="flex items-center gap-3">
              {headerAccessory}
              {onClose && (
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={onClose}
                  className="h-8 w-8 rounded-full text-muted-foreground hover:text-foreground hover:bg-secondary/60 transition"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        )}

        {/* Dialog Body Content */}
        <div className={cn("flex-1 overflow-y-auto pl-2 pr-6 text-sm text-muted-foreground", contentClassName)}>
          {children}
        </div>
      </div>
    </div>
  );

  return createPortal(dialogContent, document.body);
}

