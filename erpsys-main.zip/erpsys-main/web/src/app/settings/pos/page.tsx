"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Monitor,
  ChevronLeft,
  Loader2,
  CheckCircle,
  Save,
  Info,
  Building2,
  Volume2,
  Printer,
  Zap,
  ShoppingBag,
  Keyboard,
  ShieldCheck,
  RotateCcw,
  Sparkles,
  CreditCard,
  User,
  SlidersHorizontal,
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { authService } from "@/services/auth-service";
import { branchService } from "@/services/branch-service";
import { customerService } from "@/services/customer-service";
import { paymentMethodService } from "@/services/payment-method-service";
import {
  posSettingsService,
  PosSettingsData,
} from "@/services/pos-settings-service";

export default function PosSettingsPage() {
  const router = useRouter();

  const [currentUser, setCurrentUser] = useState<any>(null);
  const [businessId, setBusinessId] = useState<string>("");
  const [branches, setBranches] = useState<any[]>([]);
  const [selectedBranchId, setSelectedBranchId] = useState<string>("all");

  const [customers, setCustomers] = useState<any[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<any[]>([]);

  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);

  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  const defaultFormState: PosSettingsData = {
    enableExpressCheckout: true,
    autoPrintInvoice: false,
    showProductSuggestions: true,
    allowOverSelling: true,
    enableDiscount: true,
    enableHoldOrders: true,
    enableSoundEffects: true,
    defaultCustomerId: "",
    defaultPaymentMethodId: "",
    searchShortcut: "F1",
    checkoutShortcut: "F2",
    cashShortcut: "F4",
    cardShortcut: "F8",
    holdShortcut: "F6",
    cancelShortcut: "Escape",
  };

  const [posForm, setPosForm] = useState<PosSettingsData>(defaultFormState);

  useEffect(() => {
    const authed = authService.isAuthenticated();
    if (!authed) {
      router.push("/login");
      return;
    }

    const init = async () => {
      let user = authService.getCurrentUser();
      // Try to refresh user from backend to get updated businessId
      try {
        const refreshed = await authService.refreshCurrentUser();
        if (refreshed) user = refreshed;
      } catch (e) {
        // ignore
      }

      let bId = user?.businessId;

      if (!bId) {
        const savedBizId = typeof window !== "undefined" ? localStorage.getItem("hkr_selected_business_id") : null;
        if (savedBizId) {
          bId = savedBizId;
        } else {
          try {
            const bizList = await authService.getBusinesses();
            if (bizList && bizList.length > 0) {
              bId = bizList[0].id;
              if (bId && typeof window !== "undefined") {
                localStorage.setItem("hkr_selected_business_id", bId);
              }
            }
          } catch (e) {
            console.error("Failed to load fallback business", e);
          }
        }
      }

      setCurrentUser(user);
      setBusinessId(bId || "");

      if (bId) {
        loadInitialData(bId);
      } else {
        setLoading(false);
      }
    };

    init();
  }, [router]);

  const loadInitialData = async (bId: string) => {
    setLoading(true);
    setError("");
    try {
      // Load branches, customers, payment methods in parallel
      const [branchRes, customerRes, pmRes, settingsRes] = await Promise.all([
        branchService.getBranches(bId).catch(() => []),
        customerService.getCustomers(bId).catch(() => []),
        paymentMethodService.getPaymentMethods(bId).catch(() => []),
        posSettingsService.getSettings(bId, selectedBranchId === "all" ? null : selectedBranchId).catch(() => null),
      ]);

      setBranches(branchRes || []);
      setCustomers(customerRes || []);
      setPaymentMethods(pmRes || []);
      if (settingsRes) {
        setPosForm({
          ...defaultFormState,
          ...settingsRes,
          defaultCustomerId: settingsRes.defaultCustomerId || "",
          defaultPaymentMethodId: settingsRes.defaultPaymentMethodId || "",
        });
      } else {
        setPosForm(defaultFormState);
      }
    } catch (err: any) {
      setError(err.message || "Failed to load POS settings.");
    } finally {
      setLoading(false);
    }
  };

  const handleBranchChange = async (newBranchId: string) => {
    setSelectedBranchId(newBranchId);
    setLoading(true);
    setError("");
    try {
      const data = await posSettingsService.getSettings(
        businessId,
        newBranchId === "all" ? null : newBranchId
      ).catch(() => null);
      if (data) {
        setPosForm({
          ...defaultFormState,
          ...data,
          defaultCustomerId: data.defaultCustomerId || "",
          defaultPaymentMethodId: data.defaultPaymentMethodId || "",
        });
      }
    } catch (err: any) {
      setError(err.message || "Failed to load branch settings.");
    } finally {
      setLoading(false);
    }
  };

  const showSuccess = (msg: string) => {
    setSuccessMessage(msg);
    setTimeout(() => setSuccessMessage(""), 4000);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      await posSettingsService.updateSettings({
        ...posForm,
        businessId,
        branchId: selectedBranchId === "all" ? null : selectedBranchId,
        defaultCustomerId: posForm.defaultCustomerId || null,
        defaultPaymentMethodId: posForm.defaultPaymentMethodId || null,
      });
      showSuccess(
        selectedBranchId === "all"
          ? "Default POS settings updated successfully for all branches!"
          : "Branch-specific POS settings updated successfully!"
      );
    } catch (err: any) {
      setError(err.message || "Failed to save POS settings.");
    } finally {
      setSaving(false);
    }
  };

  const handleResetDefaults = () => {
    setPosForm(defaultFormState);
    showSuccess("Reset to system default recommendations.");
  };

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/settings" />
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Glowing Orbs Background */}
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-primary/5 blur-[120px] pointer-events-none z-0" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[550px] h-[550px] rounded-full bg-primary/5 blur-[130px] pointer-events-none z-0" />

        <Navbar title="POS Settings" className="relative z-10" />

        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 relative z-10">
          <div className="max-w-4xl mx-auto space-y-6">

            {/* Top Bar Header & Branch Filter */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <button
                  onClick={() => router.push("/settings")}
                  className="inline-flex items-center text-xs font-semibold text-muted-foreground hover:text-primary mb-2 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4 mr-1" /> Back to Settings
                </button>
                <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                  <Monitor className="h-7 w-7 text-primary" /> POS Settings
                </h1>
                <p className="text-sm text-muted-foreground mt-1">
                  Customize Point of Sale behavior, express checkout, auto-printing, and keyboard shortcuts.
                </p>
              </div>

              {/* Branch Selector */}
              <div className="flex items-center gap-2 bg-card/60 border border-border/60 p-1.5 px-3 rounded-xl backdrop-blur-md shadow-sm">
                <Building2 className="w-4 h-4 text-primary shrink-0" />
                <div className="flex flex-col">
                  <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">
                    Target Branch
                  </label>
                  <select
                    value={selectedBranchId}
                    onChange={(e) => handleBranchChange(e.target.value)}
                    className="bg-transparent text-xs font-bold text-foreground focus:outline-none cursor-pointer"
                  >
                    <option value="all" className="bg-background text-foreground">
                      🌐 All Branches (Default)
                    </option>
                    {branches.map((b) => (
                      <option key={b.id} value={b.id} className="bg-background text-foreground">
                        🏢 {b.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Notifications */}
            {successMessage && (
              <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 p-3 rounded-lg text-sm flex items-center gap-2 animate-in fade-in">
                <CheckCircle className="w-4 h-4 shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}

            {error && (
              <div className="bg-destructive/10 border border-destructive/30 text-destructive p-3 rounded-lg text-sm flex items-center gap-2 animate-in fade-in">
                <Info className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {loading ? (
              <div className="flex items-center justify-center py-16 text-muted-foreground">
                <Loader2 className="w-6 h-6 animate-spin mr-2 text-primary" /> Loading POS configurations...
              </div>
            ) : (
              <form onSubmit={handleSave} className="space-y-6 pb-16">

                {/* Section 1: Checkout Preferences */}
                <Card className="border border-border/50 bg-card/30 backdrop-blur-md">
                  <CardContent className="p-5 space-y-4">
                    <div className="flex items-center gap-2 border-b border-border/40 pb-3">
                      <div className="p-1.5 rounded-lg bg-primary/10 text-primary">
                        <Zap className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-sm font-bold text-foreground">Checkout & Display Preferences</h2>
                        <p className="text-xs text-muted-foreground">Manage screen behavior and default selections.</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
                      {/* Default Customer */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-primary" /> Default Walk-in Customer
                        </label>
                        <select
                          value={posForm.defaultCustomerId || ""}
                          onChange={(e) =>
                            setPosForm({ ...posForm, defaultCustomerId: e.target.value })
                          }
                          className="w-full h-10 px-3 rounded-md bg-background/80 border border-border/60 text-xs focus:ring-1 focus:ring-primary focus:outline-none"
                        >
                          <option value="">-- System Default (Walk-in) --</option>
                          {customers.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.name} {c.phone ? `(${c.phone})` : ""}
                            </option>
                          ))}
                        </select>
                        <p className="text-[10px] text-muted-foreground">
                          Automatically selected customer when starting a new sale.
                        </p>
                      </div>

                      {/* Default Payment Method */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <CreditCard className="w-3.5 h-3.5 text-primary" /> Default Payment Method
                        </label>
                        <select
                          value={posForm.defaultPaymentMethodId || ""}
                          onChange={(e) =>
                            setPosForm({ ...posForm, defaultPaymentMethodId: e.target.value })
                          }
                          className="w-full h-10 px-3 rounded-md bg-background/80 border border-border/60 text-xs focus:ring-1 focus:ring-primary focus:outline-none"
                        >
                          <option value="">-- Cash (Default) --</option>
                          {paymentMethods.map((pm) => (
                            <option key={pm.id} value={pm.id}>
                              {pm.name}
                            </option>
                          ))}
                        </select>
                        <p className="text-[10px] text-muted-foreground">
                          Pre-selected payment method on checkout modal.
                        </p>
                      </div>
                    </div>

                    {/* Toggles Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                      {/* Express Checkout */}
                      <div className="flex items-center justify-between p-3 rounded-lg border border-border/40 bg-background/50">
                        <div className="space-y-0.5">
                          <span className="text-xs font-bold flex items-center gap-1.5">
                            <Zap className="w-3.5 h-3.5 text-amber-500" /> Express Cash Button
                          </span>
                          <p className="text-[10px] text-muted-foreground">
                            1-click instant cash sale button on POS screen.
                          </p>
                        </div>
                        <input
                          type="checkbox"
                          checked={posForm.enableExpressCheckout}
                          onChange={(e) =>
                            setPosForm({ ...posForm, enableExpressCheckout: e.target.checked })
                          }
                          className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                        />
                      </div>

                      {/* Auto Print */}
                      <div className="flex items-center justify-between p-3 rounded-lg border border-border/40 bg-background/50">
                        <div className="space-y-0.5">
                          <span className="text-xs font-bold flex items-center gap-1.5">
                            <Printer className="w-3.5 h-3.5 text-primary" /> Auto-Print Receipt
                          </span>
                          <p className="text-[10px] text-muted-foreground">
                            Automatically open print dialog after checkout.
                          </p>
                        </div>
                        <input
                          type="checkbox"
                          checked={posForm.autoPrintInvoice}
                          onChange={(e) =>
                            setPosForm({ ...posForm, autoPrintInvoice: e.target.checked })
                          }
                          className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                        />
                      </div>

                      {/* Sound Effects */}
                      <div className="flex items-center justify-between p-3 rounded-lg border border-border/40 bg-background/50">
                        <div className="space-y-0.5">
                          <span className="text-xs font-bold flex items-center gap-1.5">
                            <Volume2 className="w-3.5 h-3.5 text-indigo-400" /> Sound Effects & Beep
                          </span>
                          <p className="text-[10px] text-muted-foreground">
                            Play sound audio on barcode scan and sale completion.
                          </p>
                        </div>
                        <input
                          type="checkbox"
                          checked={posForm.enableSoundEffects}
                          onChange={(e) =>
                            setPosForm({ ...posForm, enableSoundEffects: e.target.checked })
                          }
                          className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                        />
                      </div>

                      {/* Product Suggestions */}
                      <div className="flex items-center justify-between p-3 rounded-lg border border-border/40 bg-background/50">
                        <div className="space-y-0.5">
                          <span className="text-xs font-bold flex items-center gap-1.5">
                            <ShoppingBag className="w-3.5 h-3.5 text-emerald-500" /> Product Grid & Images
                          </span>
                          <p className="text-[10px] text-muted-foreground">
                            Display product image cards on the POS screen.
                          </p>
                        </div>
                        <input
                          type="checkbox"
                          checked={posForm.showProductSuggestions}
                          onChange={(e) =>
                            setPosForm({ ...posForm, showProductSuggestions: e.target.checked })
                          }
                          className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Section 2: Sales & Stock Controls */}
                <Card className="border border-border/50 bg-card/30 backdrop-blur-md">
                  <CardContent className="p-5 space-y-4">
                    <div className="flex items-center gap-2 border-b border-border/40 pb-3">
                      <div className="p-1.5 rounded-lg bg-primary/10 text-primary">
                        <ShieldCheck className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-sm font-bold text-foreground">Sales & Stock Controls</h2>
                        <p className="text-xs text-muted-foreground">Permissions and validations for cashiers.</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
                      {/* Allow Over-selling */}
                      <div className="p-3 rounded-lg border border-border/40 bg-background/50 space-y-2 flex flex-col justify-between">
                        <div className="space-y-0.5">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold">Allow Over-Selling</span>
                            <input
                              type="checkbox"
                              checked={posForm.allowOverSelling}
                              onChange={(e) =>
                                setPosForm({ ...posForm, allowOverSelling: e.target.checked })
                              }
                              className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                            />
                          </div>
                          <p className="text-[10px] text-muted-foreground">
                            Permit billing even if product stock is 0 or negative.
                          </p>
                        </div>
                      </div>

                      {/* Enable Discount */}
                      <div className="p-3 rounded-lg border border-border/40 bg-background/50 space-y-2 flex flex-col justify-between">
                        <div className="space-y-0.5">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold">Cart Discounts</span>
                            <input
                              type="checkbox"
                              checked={posForm.enableDiscount}
                              onChange={(e) =>
                                setPosForm({ ...posForm, enableDiscount: e.target.checked })
                              }
                              className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                            />
                          </div>
                          <p className="text-[10px] text-muted-foreground">
                            Allow cashier to apply custom discounts on orders.
                          </p>
                        </div>
                      </div>

                      {/* Hold Orders */}
                      <div className="p-3 rounded-lg border border-border/40 bg-background/50 space-y-2 flex flex-col justify-between">
                        <div className="space-y-0.5">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold">Hold / Draft Orders</span>
                            <input
                              type="checkbox"
                              checked={posForm.enableHoldOrders}
                              onChange={(e) =>
                                setPosForm({ ...posForm, enableHoldOrders: e.target.checked })
                              }
                              className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                            />
                          </div>
                          <p className="text-[10px] text-muted-foreground">
                            Enable suspending current cart to serve another customer.
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Section 3: Keyboard Shortcuts */}
                <Card className="border border-border/50 bg-card/30 backdrop-blur-md">
                  <CardContent className="p-5 space-y-4">
                    <div className="flex items-center justify-between border-b border-border/40 pb-3">
                      <div className="flex items-center gap-2">
                        <div className="p-1.5 rounded-lg bg-primary/10 text-primary">
                          <Keyboard className="w-5 h-5" />
                        </div>
                        <div>
                          <h2 className="text-sm font-bold text-foreground">Cashier Keyboard Shortcuts</h2>
                          <p className="text-xs text-muted-foreground">
                            Speed up transactions with customizable keyboard hotkeys.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4 pt-1">
                      {/* Search */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-semibold text-muted-foreground">
                          Search Product
                        </label>
                        <Input
                          type="text"
                          value={posForm.searchShortcut}
                          onChange={(e) =>
                            setPosForm({ ...posForm, searchShortcut: e.target.value })
                          }
                          className="font-mono text-center font-bold text-xs h-9"
                          placeholder="e.g. F1"
                        />
                      </div>

                      {/* Checkout */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-semibold text-muted-foreground">
                          Pay / Checkout
                        </label>
                        <Input
                          type="text"
                          value={posForm.checkoutShortcut}
                          onChange={(e) =>
                            setPosForm({ ...posForm, checkoutShortcut: e.target.value })
                          }
                          className="font-mono text-center font-bold text-xs h-9"
                          placeholder="e.g. F2"
                        />
                      </div>

                      {/* Cash */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-semibold text-muted-foreground">
                          Direct Cash Pay
                        </label>
                        <Input
                          type="text"
                          value={posForm.cashShortcut}
                          onChange={(e) =>
                            setPosForm({ ...posForm, cashShortcut: e.target.value })
                          }
                          className="font-mono text-center font-bold text-xs h-9"
                          placeholder="e.g. F4"
                        />
                      </div>

                      {/* Card */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-semibold text-muted-foreground">
                          Direct Card Pay
                        </label>
                        <Input
                          type="text"
                          value={posForm.cardShortcut}
                          onChange={(e) =>
                            setPosForm({ ...posForm, cardShortcut: e.target.value })
                          }
                          className="font-mono text-center font-bold text-xs h-9"
                          placeholder="e.g. F8"
                        />
                      </div>

                      {/* Hold */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-semibold text-muted-foreground">
                          Hold / Suspend
                        </label>
                        <Input
                          type="text"
                          value={posForm.holdShortcut}
                          onChange={(e) =>
                            setPosForm({ ...posForm, holdShortcut: e.target.value })
                          }
                          className="font-mono text-center font-bold text-xs h-9"
                          placeholder="e.g. F6"
                        />
                      </div>

                      {/* Cancel */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-semibold text-muted-foreground">
                          Clear / Cancel
                        </label>
                        <Input
                          type="text"
                          value={posForm.cancelShortcut}
                          onChange={(e) =>
                            setPosForm({ ...posForm, cancelShortcut: e.target.value })
                          }
                          className="font-mono text-center font-bold text-xs h-9"
                          placeholder="e.g. Escape"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Bottom Action Buttons */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-border/60">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleResetDefaults}
                    className="text-xs text-muted-foreground hover:text-foreground gap-1.5"
                  >
                    <RotateCcw className="w-3.5 h-3.5" /> Reset Defaults
                  </Button>

                  <Button
                    type="submit"
                    disabled={saving}
                    className="gap-2 min-w-[160px] shadow-md shadow-primary/10"
                  >
                    {saving ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Save className="w-4 h-4" />
                    )}
                    Save POS Settings
                  </Button>
                </div>

              </form>
            )}

          </div>
        </main>
      </div>
    </div>
  );
}
