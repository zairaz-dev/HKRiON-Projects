package com.hkr.ionerp;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
