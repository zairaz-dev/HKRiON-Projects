// Isolated security probes: real application code, synthetic Prisma records.
// No production database, credentials, external payments, email, or SMS are used.
// Run from the repository root: node docs/security-audit-2026-09-14/reproduce.cjs
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const http = require('node:http');
const crypto = require('node:crypto');
const { createRequire } = require('node:module');
const root = path.resolve(__dirname, '../..');
const dep = createRequire(path.join(root, 'backend/package.json'));
const ts = dep('typescript');
dep('reflect-metadata');
require.extensions['.ts'] = (module, filename) => {
  module._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022,
      experimentalDecorators: true, emitDecoratorMetadata: true, esModuleInterop: true },
    fileName: filename,
  }).outputText, filename);
};
const src = (p, name) => require(path.join(root, 'backend/src', p))[name];
const { Test } = dep('@nestjs/testing');
const { Reflector } = dep('@nestjs/core');
const { JwtService } = dep('@nestjs/jwt');
const { PassportModule } = dep('@nestjs/passport');
const bcrypt = dep('bcryptjs');
const AuthService = src('modules/auth/auth.service.ts', 'AuthService');
const AuthController = src('modules/auth/auth.controller.ts', 'AuthController');
const BusinessService = src('modules/business/business.service.ts', 'BusinessService');
const BusinessController = src('modules/business/business.controller.ts', 'BusinessController');
const RolesService = src('modules/roles/roles.service.ts', 'RolesService');
const RolesController = src('modules/roles/roles.controller.ts', 'RolesController');
const CategoriesService = src('modules/categories/categories.service.ts', 'CategoriesService');
const CategoriesController = src('modules/categories/categories.controller.ts', 'CategoriesController');
const ImeiService = src('modules/imei/imei.service.ts', 'ImeiService');
const ImeiController = src('modules/imei/imei.controller.ts', 'ImeiController');
const EmailSettingsService = src('modules/email-settings/email-settings.service.ts', 'EmailSettingsService');
const EmailSettingsController = src('modules/email-settings/email-settings.controller.ts', 'EmailSettingsController');
const SmsSettingsService = src('modules/sms-settings/sms-settings.service.ts', 'SmsSettingsService');
const SmsSettingsController = src('modules/sms-settings/sms-settings.controller.ts', 'SmsSettingsController');
const PosService = src('modules/pos/pos.service.ts', 'PosService');
const PosController = src('modules/pos/pos.controller.ts', 'PosController');
const SearchService = src('modules/search/search.service.ts', 'SearchService');
const SearchController = src('modules/search/search.controller.ts', 'SearchController');
const SubscriptionsService = src('modules/subscriptions/subscriptions.service.ts', 'SubscriptionsService');
const JwtStrategy = src('modules/auth/jwt.strategy.ts', 'JwtStrategy');
const JwtAuthGuard = src('common/guards/jwt-auth.guard.ts', 'JwtAuthGuard');
const RolesGuard = src('common/guards/roles.guard.ts', 'RolesGuard');
const PermissionsGuard = src('common/guards/permissions.guard.ts', 'PermissionsGuard');
const TenantInterceptor = src('common/interceptors/tenant.interceptor.ts', 'TenantInterceptor');
const upload = require(path.join(root, 'backend/src/common/utils/upload.util.ts'));
const role = (id, slug, permissions) => ({ id, role: slug, businessId: null,
  rolePermissions: permissions.map(permissionId => ({ permissionId })) });
const roles = [role('role-admin', 'admin', ['users:manage_permissions', 'inventory:add_product', 'inventory:edit_product', 'inventory:delete_product', 'pos:view', 'pos:create_transaction']),
  role('role-super', 'super-admin', []), role('role-employee', 'employee', []),
  role('role-cashier', 'cashier', ['pos:view', 'pos:create_transaction'])];
const passwordHash = bcrypt.hashSync('synthetic-test-password', 4);
const users = ['admin', 'employee', 'cashier'].map(slug => ({ id: slug, email: `${slug}@audit.invalid`, name: slug,
  role: roles.find(r => r.role === slug), roleId: `role-${slug}`, businessId: 'business-A', isActive: true,
  passwordHash, createdAt: new Date(), branches: [], lastLoginAt: null }));
users.push({ ...users[0], id: 'disabled', email: 'disabled@audit.invalid', isActive: false });
const businesses = [{ id: 'business-A', name: 'Synthetic A', isActive: true },
  { id: 'business-B', name: 'Synthetic B', isActive: true }];
const categories = [];
const imeis = [{ id: 'imei-B', businessId: 'business-B', status: 'IN_STOCK' }];
const calls = [];
const sales = [];
const lines = [];
const settings = { email: { businessId: 'business-A', mailPassword: 'SYNTHETIC-SMTP-SECRET' },
  sms: { businessId: 'business-A', apiKey: 'SYNTHETIC-SMS-SECRET' } };
const scalarMatch = (value, filter) => filter === undefined || value === filter ||
  (filter && typeof filter === 'object' && (filter.equals === value || filter.in?.includes(value)));
const prisma = {
  user: {
    findUnique: async ({ where }) => users.find(u => where.id ? u.id === where.id : u.email === where.email) || null,
    findFirst: async ({ where }) => users.find(u => scalarMatch(u.id, where.id) && scalarMatch(u.businessId, where.businessId)) || null,
    findMany: async ({ where } = {}) => users.filter(u => !where?.businessId || u.businessId === where.businessId),
    create: async ({ data }) => { const u = { ...data, id: `user-${users.length}`, role: roles.find(r => r.id === data.roleId), createdAt: new Date(), branches: [] }; users.push(u); return u; },
    update: async ({ where, data }) => Object.assign(users.find(u => u.id === where.id), data),
    count: async () => 0,
  },
  role: {
    findFirst: async ({ where }) => { calls.push({ op: 'role.findFirst', where }); return roles.find(r => scalarMatch(r.role, where.role) && (!where.OR || where.OR.some(o => scalarMatch(r.businessId, o.businessId)))) || null; },
    findUnique: async ({ where }) => roles.find(r => r.id === where.id),
    create: async ({ data }) => { const r = { ...data, id: `role-${roles.length}`, rolePermissions: [] }; roles.push(r); return r; },
    update: async ({ where, data }) => Object.assign(roles.find(r => r.id === where.id), data),
    delete: async ({ where }) => { const i = roles.findIndex(r => r.id === where.id); return roles.splice(i, 1)[0]; },
  },
  rolePermission: { create: async ({ data }) => data, deleteMany: async () => ({ count: 0 }) },
  userBranch: { createMany: async () => ({ count: 0 }), findMany: async () => [{ branchId: 'branch-A' }] },
  business: { findUnique: async ({ where }) => businesses.find(b => b.id === where.id),
    update: async ({ where, data }) => Object.assign(businesses.find(b => b.id === where.id), Object.fromEntries(Object.entries(data).filter(([,v]) => v !== undefined))) },
  branch: { findMany: async () => [], findFirst: async () => null },
  category: { findFirst: async () => null, create: async ({ data }) => { const c = { id: `cat-${categories.length}`, ...data }; categories.push(c); return c; } },
  productImei: { update: async ({ where, data }) => { calls.push({ op: 'imei.update', where }); return Object.assign(imeis.find(i => i.id === where.id), data); } },
  emailSettings: { findUnique: async () => settings.email, upsert: async ({ update }) => Object.assign(settings.email, update) },
  smsSettings: { findUnique: async () => settings.sms, upsert: async ({ update }) => Object.assign(settings.sms, update) },
  product: { findMany: async () => [] },
  purchase: { findMany: async () => [{ id: 'purchase-A', purchaseNumber: 'PRIVATE-PURCHASE', grandTotal: 900, status: 'RECEIVED', purchaseDate: new Date(), supplier: { name: 'Synthetic supplier' } }] },
  supplier: { findMany: async () => [] },
  customer: { findMany: async () => [], findUnique: async ({ where }) => ({ id: where.id, businessId: where.id === 'customer-B' ? 'business-B' : 'business-A', isActive: true, allowCredit: false }) },
  purchaseLine: { findMany: async (args) => { calls.push({ op: 'stock.read', ...args }); return [{ id: 'batch-B', businessId: 'business-B', quantityRemaining: 10 }]; },
    update: async (args) => { calls.push({ op: 'stock.update', ...args }); return args.data; } },
  sale: { create: async ({ data }) => { const sale = { id: `sale-${sales.length}`, ...data }; sales.push(sale); return sale; },
    update: async ({ where, data }) => Object.assign(sales.find(s => s.id === where.id), data),
    findMany: async () => [],
    findFirst: async ({ where }) => { calls.push({ op: 'sale.read', where }); return { id: where.id, businessId: 'business-A', branchId: 'branch-not-assigned', saleLines: [] }; } },
  saleLine: { create: async ({ data }) => { lines.push(data); return { id: `line-${lines.length}`, ...data }; } },
  $transaction: async work => typeof work === 'function' ? work(prisma) : Promise.all(work),
};
const service = (Type, extra = {}) => Object.assign(Object.create(Type.prototype), { prisma, ...extra });
const testKey = crypto.randomBytes(32).toString('hex');
process.env.JWT_SECRET = testKey;
const jwtService = new JwtService({ secret: testKey, signOptions: { expiresIn: '1h' } });
const types = [[AuthController, AuthService], [BusinessController, BusinessService], [RolesController, RolesService],
  [CategoriesController, CategoriesService], [ImeiController, ImeiService], [EmailSettingsController, EmailSettingsService],
  [SmsSettingsController, SmsSettingsService], [PosController, PosService], [SearchController, SearchService]];
const results = [];
async function check(id, title, run, kind = 'reproduced') {
  try { const evidence = await run(); results.push({ id, kind, title, passed: true, evidence }); console.log(`PASS ${id}: ${title}`); }
  catch (e) { results.push({ id, kind, title, passed: false, error: e.message }); console.log(`FAIL ${id}: ${title}: ${e.message}`); }
}
async function main() {
  const module = await Test.createTestingModule({ imports: [PassportModule], controllers: types.map(t => t[0]),
    providers: [...types.map(([,Type]) => ({ provide: Type, useValue: service(Type, Type === AuthService ? { jwtService } : {}) }))],
  }).compile();
  const app = module.createNestApplication({ logger: false });
  const reflector = new Reflector();
  new JwtStrategy(prisma);
  app.useGlobalGuards(new JwtAuthGuard(reflector), new RolesGuard(reflector), new PermissionsGuard(reflector));
  app.useGlobalInterceptors(new TenantInterceptor());
  await app.listen(0, '127.0.0.1');
  const base = await app.getUrl();
  const request = async (route, user = 'employee', body, method = 'GET') => {
    const headers = {};
    if (user) headers.Authorization = `Bearer ${jwtService.sign({ sub: user })}`;
    if (body && !(body instanceof FormData)) headers['Content-Type'] = 'application/json';
    const res = await fetch(`${base}${route}`, { method, headers, body: body ? body instanceof FormData ? body : JSON.stringify(body) : undefined });
    return { status: res.status, body: await res.json() };
  };
  try {
    await check('C01', 'Unauthenticated protected request is rejected', async () => {
      assert.equal((await request('/auth/business/business-B', null)).status, 401); return '401';
    }, 'control');
    await check('C02', 'Literal super-admin assignment is rejected', async () => {
      assert.equal((await request('/auth/users', 'admin', { role: 'super-admin' }, 'POST')).status, 403); return '403';
    }, 'control');
    await check('S01', 'Object-valued role filter bypasses super-admin creation restriction', async () => {
      const r = await request('/auth/users', 'admin', { email: 'created@audit.invalid', name: 'Fixture', password: 'synthetic-password', role: { equals: 'super-admin' } }, 'POST');
      assert.equal(r.status, 201); assert.equal(r.body.role, 'super-admin');
      assert.deepEqual(calls.find(c => c.op === 'role.findFirst').where.role, { equals: 'super-admin' });
      return { status: r.status, createdRole: r.body.role, originalActor: 'tenant admin' };
    });
    await check('S02', 'Employee can read and edit another business', async () => {
      const get = await request('/auth/business/business-B'); assert.equal(get.status, 200);
      const patch = await request('/auth/business/business-B', 'employee', { name: 'Changed by foreign employee' }, 'PATCH');
      assert.equal(patch.status, 200); assert.equal(businesses[1].name, 'Changed by foreign employee'); return 'GET 200; PATCH 200';
    });
    await check('C03', 'JSON category creation enforces tenant override', async () => {
      const r = await request('/categories', 'admin', { name: 'JSON control', businessId: 'business-B' }, 'POST');
      assert.equal(r.status, 201); assert.equal(r.body.businessId, 'business-A'); return 'business-A';
    }, 'control');
    await check('S03', 'Multipart parser overwrites tenant injection', async () => {
      const form = new FormData(); form.set('name', 'Multipart probe'); form.set('businessId', 'business-B');
      const r = await request('/categories', 'admin', form, 'POST');
      assert.equal(r.status, 201); assert.equal(r.body.businessId, 'business-B'); return { status: r.status, writtenTenant: r.body.businessId };
    });
    await check('S04', 'Disabled user retains authenticated access', async () => {
      const r = await request('/auth/business/business-A', 'disabled'); assert.equal(r.status, 200); return 'disabled account token returns 200';
    });
    await check('S05', 'Disabled business does not revoke existing sessions', async () => {
      businesses[0].isActive = false;
      const r = await request('/auth/business/business-A', 'employee'); businesses[0].isActive = true;
      assert.equal(r.status, 200); return 'disabled business token returns 200';
    });
    await check('S06', 'Employee without permissions can retrieve mail/SMS secrets', async () => {
      const email = await request('/email-settings'); const sms = await request('/sms-settings');
      assert.equal(email.status, 200); assert.equal(sms.status, 200);
      assert.equal(email.body.mailPassword, settings.email.mailPassword); assert.equal(sms.body.apiKey, settings.sms.apiKey);
      return 'synthetic plaintext mailPassword and apiKey returned';
    });
    await check('S07', 'Employee can change settings and make an SSRF request to loopback', async () => {
      const internal = http.createServer((req, res) => res.end('SYNTHETIC-PRIVATE-RESPONSE'));
      await new Promise(resolve => internal.listen(0, '127.0.0.1', resolve));
      try {
        const url = `http://127.0.0.1:${internal.address().port}/private-fixture`;
        assert.equal((await request('/sms-settings', 'employee', { gatewayUrl: url, httpMethod: 'GET' }, 'PUT')).status, 200);
        const r = await request('/sms-settings/test', 'employee', { mobileNumber: 'synthetic', message: 'local fixture only' }, 'POST');
        assert.equal(r.body.response, 'SYNTHETIC-PRIVATE-RESPONSE'); return 'unprivileged loopback fetch; response reflected';
      } finally { await new Promise(resolve => internal.close(resolve)); }
    });
    await check('S08', 'Employee can mutate another tenant IMEI by ID', async () => {
      const r = await request('/imei/imei-B/status', 'employee', { status: 'SOLD' }, 'PATCH');
      assert.equal(r.status, 200); assert.equal(imeis[0].status, 'SOLD');
      assert.deepEqual(calls.find(c => c.op === 'imei.update').where, { id: 'imei-B' }); return 'business-B IMEI updated by business-A employee';
    });
    await check('S09', 'Tenant admin can update another tenant custom role', async () => {
      roles.push({ id: 'custom-B', role: 'custom', businessId: 'business-B', name: 'Original', rolePermissions: [] });
      const r = await request('/auth/roles/custom-B', 'admin', { name: 'Changed', permissions: [] }, 'PUT');
      assert.equal(r.status, 200); assert.equal(roles.find(r => r.id === 'custom-B').name, 'Changed'); return 'cross-tenant role update 200';
    });
    await check('S10', 'Checkout accepts zero bill total despite positive line value', async () => {
      const r = await request('/pos/checkout', 'cashier', { invoiceNumber: 'AUDIT-ZERO', customerId: 'customer-A', branchId: 'branch-A',
        saleLines: [{ variantId: 'variant-A', quantity: 1, unitPrice: 1000 }], grandTotal: 0, payments: [] }, 'POST');
      assert.equal(r.status, 201); assert.equal(r.body.paymentStatus, 'PAID'); assert.equal(lines.at(-1).subtotal, 1000);
      return 'line subtotal=1000; grandTotal=0; amountPaid=0; status=PAID';
    });
    await check('S11', 'Checkout accepts negative quantity and skips stock deduction', async () => {
      const before = calls.filter(c => c.op === 'stock.read').length;
      const r = await request('/pos/checkout', 'cashier', { invoiceNumber: 'AUDIT-NEGATIVE', customerId: 'customer-A', branchId: 'branch-A',
        saleLines: [{ variantId: 'variant-A', quantity: -1, unitPrice: 1000 }], grandTotal: -1000, payments: [] }, 'POST');
      assert.equal(r.status, 201); assert.equal(lines.at(-1).quantity, -1);
      assert.equal(calls.filter(c => c.op === 'stock.read').length, before); return 'negative quantity persisted; inventory deduction skipped';
    });
    await check('S12', 'Checkout accepts foreign branch/variant/customer IDs', async () => {
      const r = await request('/pos/checkout', 'cashier', { invoiceNumber: 'AUDIT-CROSS', customerId: 'customer-B', branchId: 'branch-B',
        saleLines: [{ variantId: 'variant-B', quantity: 1, unitPrice: 1000 }], grandTotal: 0, payments: [] }, 'POST');
      assert.equal(r.status, 201); const read = calls.filter(c => c.op === 'stock.read').at(-1);
      assert.equal(read.where.branchId, 'branch-B'); assert.equal(read.where.businessId, undefined);
      return 'business-A sale references business-B customer/branch/variant; foreign stock write reached';
    });
    await check('S13', 'Sale detail bypasses assigned branch filtering', async () => {
      const r = await request('/pos/sales/synthetic-foreign-branch-sale', 'cashier');
      assert.equal(r.status, 200); assert.equal(r.body.branchId, 'branch-not-assigned');
      assert.equal(calls.filter(c => c.op === 'sale.read').at(-1).where.branchId, undefined); return 'unassigned branch sale detail returned';
    });
    await check('S14', 'Global search returns purchases to employee without purchase permission', async () => {
      const r = await request('/search/global?q=PRIVATE'); assert.equal(r.status, 200);
      assert.equal(r.body.purchases[0].purchaseNumber, 'PRIVATE-PURCHASE'); return 'purchase number and grandTotal returned';
    });
    await check('S15', 'Upload filter accepts HTML filename with forged image MIME', async () => {
      const file = { originalname: 'probe.html', mimetype: 'image/png' };
      const accepted = await new Promise((resolve, reject) => upload.imageFileFilter({}, file, (err, ok) => err ? reject(err) : resolve(ok)));
      assert.equal(accepted, true);
      const filename = await new Promise((resolve, reject) => upload.createImageStorage('audit').getFilename({}, file, (err, name) => err ? reject(err) : resolve(name)));
      assert.match(filename, /\.html$/); return 'HTML filename accepted and preserved; content bytes never checked';
    });
    await check('C04', 'Upload filter rejects explicitly non-image MIME', async () => {
      let rejected = false; upload.imageFileFilter({}, { mimetype: 'text/html' }, err => { rejected = !!err; });
      assert.equal(rejected, true); return 'text/html MIME rejected';
    }, 'control');
    await check('S16', 'Login endpoint does not throttle repeated failed attempts', async () => {
      const statuses = [];
      for (let i = 0; i < 12; i++) statuses.push((await request('/auth/login', null, { email: 'employee@audit.invalid', password: 'wrong' }, 'POST')).status);
      assert.ok(statuses.every(s => s === 401)); return '12 failed attempts all 401; no 429 or account lock';
    });
  } finally { await app.close(); }
  await check('S17', 'Category image path can delete outside uploads (only synthetic temp file)', async () => {
    const sentinel = path.join(__dirname, 'disposable-sentinel.txt'); fs.writeFileSync(sentinel, 'AUDIT ONLY');
    try {
      const imageUrl = '/uploads/../docs/security-audit-2026-09-14/disposable-sentinel.txt';
      const controller = new CategoriesController({ getCategoryById: async () => ({ imageUrl }), deleteCategory: async () => ({ success: true }) });
      await controller.deleteCategory('synthetic-category', 'business-A'); assert.equal(fs.existsSync(sentinel), false);
      return 'synthetic file outside uploads deleted by controller cleanup';
    } finally { if (fs.existsSync(sentinel)) fs.unlinkSync(sentinel); }
  });
  await check('S18', 'Valid PayHere notification replay extends subscription twice', async () => {
    const secret = 'synthetic-payhere-secret';
    const sub = { id: 'sub-test', status: 'ACTIVE', endDate: new Date('2030-01-01T00:00:00Z'), planId: 'plan-test', billingInterval: 'MONTHLY' };
    const invoice = { id: 'invoice-test', invoiceNumber: 'AUDIT-ORDER', businessId: 'business-A', planId: 'plan-test', billingInterval: 'MONTHLY', amount: 100, currency: 'LKR', paymentStatus: 'PENDING', subscription: sub };
    const svc = service(SubscriptionsService, { prisma: {
      superPlatformSetting: { findFirst: async () => ({ payhereMerchantSecret: secret }) },
      subscriptionInvoice: { findUnique: async () => invoice, update: async ({ data }) => Object.assign(invoice, data) },
      plan: { findUnique: async () => ({ id: 'plan-test' }) },
      subscription: { update: async ({ data }) => Object.assign(sub, data) },
      $transaction: async values => Promise.all(values),
    } });
    const data = { merchant_id: 'synthetic', order_id: 'AUDIT-ORDER', payhere_amount: '100.00', payhere_currency: 'LKR', status_code: '2', payment_id: 'fixture-payment' };
    const md5 = x => crypto.createHash('md5').update(x).digest('hex').toUpperCase();
    data.md5sig = md5(`${data.merchant_id}${data.order_id}${data.payhere_amount}${data.payhere_currency}${data.status_code}${md5(secret)}`);
    const originalLog = console.log; console.log = () => {};
    try { await svc.processPayHereNotification(data); const first = sub.endDate.toISOString();
      await svc.processPayHereNotification(data); assert.ok(sub.endDate.toISOString() > first);
      return { afterFirst: first, afterReplay: sub.endDate.toISOString() };
    } finally { console.log = originalLog; }
  });
  const output = { date: '2026-09-14', environment: 'isolated Nest HTTP app; real source; mocked Prisma; localhost-only fetch',
    scope: 'No live database writes or external provider requests', results };
  fs.writeFileSync(path.join(__dirname, 'test-results.json'), JSON.stringify(output, null, 2) + '\n');
  console.log(`\n${results.filter(r => r.passed).length}/${results.length} probes passed; ${results.filter(r => r.passed && r.kind === 'reproduced').length} vulnerability scenarios reproduced.`);
  if (results.some(r => !r.passed)) process.exitCode = 1;
}
main().catch(e => { console.error(e); process.exitCode = 1; });
