import { NextResponse } from "next/server";
import { writeFile, readFile, mkdir } from "fs/promises";
import path from "path";
import dns from "dns/promises";
import net from "net";
import sharp from "sharp";
import { requireAdmin } from "@/lib/require-admin";

const MAX_FILE_SIZE = 25 * 1024 * 1024; // 25MB limit

function isPrivateOrReservedIP(ip: string): boolean {
  if (!ip) return true;
  let normalized = ip.trim();

  // Strip IPv4-mapped IPv6 prefix (::ffff:)
  if (normalized.startsWith("::ffff:")) {
    normalized = normalized.substring(7);
  }

  if (net.isIPv4(normalized)) {
    const parts = normalized.split(".").map(Number);
    if (parts.length !== 4 || parts.some((p) => isNaN(p) || p < 0 || p > 255)) return true;

    // 0.0.0.0/8 (Current network)
    if (parts[0] === 0) return true;
    // 127.0.0.0/8 (Loopback)
    if (parts[0] === 127) return true;
    // 10.0.0.0/8 (Private)
    if (parts[0] === 10) return true;
    // 172.16.0.0/12 (Private: 172.16.0.0 to 172.31.255.255)
    if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return true;
    // 192.168.0.0/16 (Private)
    if (parts[0] === 192 && parts[1] === 168) return true;
    // 169.254.0.0/16 (Link-local / Cloud metadata: 169.254.169.254)
    if (parts[0] === 169 && parts[1] === 254) return true;
    // 100.64.0.0/10 (Carrier-grade NAT)
    if (parts[0] === 100 && parts[1] >= 64 && parts[1] <= 127) return true;
    // 198.18.0.0/15 (Benchmarking)
    if (parts[0] === 198 && (parts[1] === 18 || parts[1] === 19)) return true;
    // 224.0.0.0/4 (Multicast) and 240.0.0.0/4 (Reserved)
    if (parts[0] >= 224) return true;

    return false;
  }

  if (net.isIPv6(normalized)) {
    const lower = normalized.toLowerCase();
    // ::1 (Loopback)
    if (lower === "::1" || lower === "0:0:0:0:0:0:0:1") return true;
    // :: (Unspecified)
    if (lower === "::" || lower === "0:0:0:0:0:0:0:0") return true;
    // Unique local (fc00::/7 -> starts with fc or fd)
    if (lower.startsWith("fc") || lower.startsWith("fd")) return true;
    // Link-local (fe80::/10)
    if (
      lower.startsWith("fe80:") ||
      lower.startsWith("fe9") ||
      lower.startsWith("fea") ||
      lower.startsWith("feb")
    ) return true;

    return false;
  }

  return true; // Not a valid public IP
}

const ALLOWED_MIME_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/avif",
  "image/gif",
  "application/pdf",
  "video/mp4",
  "video/x-m4v",
  "video/m4v",
  "application/mp4",
  "video/webm",
  "video/quicktime",
  "video/ogg",
  "video/x-matroska",
]);

// POST /api/admin/upload — Admin only
export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const category = (formData.get("category") as string) || "gemstones";

    // Enforce admin authorization strictly on all admin upload operations
    const authError = await requireAdmin();
    if (authError) return authError;

    const file = formData.get("file") as File | null;
    const imageUrl = formData.get("imageUrl") as string | null;
    const cropJson = formData.get("crop") as string | null;

    let buffer: Buffer;
    let mimeType = "image/jpeg";
    let originalName = "uploaded-image";

    if (file) {
      if (file.size > MAX_FILE_SIZE) {
        return NextResponse.json(
          { error: "File exceeds 25MB limit" },
          { status: 400 }
        );
      }

      // Check MIME type and normalize for videos or images
      let detectedMime = file.type;
      const lowerName = file.name.toLowerCase();

      // Normalize common MP4 and video extensions when browser MIME type is missing or generic
      if (!detectedMime || detectedMime === "application/octet-stream") {
        if (lowerName.endsWith(".mp4") || lowerName.endsWith(".m4v")) {
          detectedMime = "video/mp4";
        } else if (lowerName.endsWith(".webm")) {
          detectedMime = "video/webm";
        } else if (lowerName.endsWith(".mov")) {
          detectedMime = "video/quicktime";
        } else if (lowerName.endsWith(".jpg") || lowerName.endsWith(".jpeg")) {
          detectedMime = "image/jpeg";
        } else if (lowerName.endsWith(".png")) {
          detectedMime = "image/png";
        } else if (lowerName.endsWith(".webp")) {
          detectedMime = "image/webp";
        } else if (lowerName.endsWith(".pdf")) {
          detectedMime = "application/pdf";
        }
      }

      if (!ALLOWED_MIME_TYPES.has(detectedMime)) {
        return NextResponse.json(
          { error: `Unsupported file type: ${detectedMime || "unknown"}. Allowed formats: MP4, WEBM, MOV, JPEG, PNG, WEBP, AVIF, GIF, PDF.` },
          { status: 400 }
        );
      }

      const bytes = await file.arrayBuffer();
      buffer = Buffer.from(bytes);
      mimeType = detectedMime;
      originalName = file.name;
    } else if (imageUrl) {
      const cleanUrl = imageUrl.trim();

      // Check if this is a local path (e.g. /uploads/gemstones/... or uploads/...)
      const isLocalRelative = cleanUrl.startsWith("/") || cleanUrl.startsWith("uploads/");
      let localPathCandidate: string | null = null;
      const publicRoot = path.resolve(process.cwd(), "public");

      if (isLocalRelative) {
        const rel = cleanUrl.startsWith("/") ? cleanUrl.slice(1) : cleanUrl;
        const candidate = path.resolve(publicRoot, rel);
        // Prevent directory traversal: candidate must stay strictly inside publicRoot
        if (!candidate.startsWith(publicRoot + path.sep)) {
          return NextResponse.json(
            { error: "Access denied: Local path traversal detected." },
            { status: 403 }
          );
        }
        localPathCandidate = candidate;
      } else if (cleanUrl.startsWith("http://") || cleanUrl.startsWith("https://")) {
        try {
          const parsed = new URL(cleanUrl);
          if (parsed.pathname.startsWith("/uploads/")) {
            const candidate = path.resolve(publicRoot, parsed.pathname.slice(1));
            if (candidate.startsWith(publicRoot + path.sep)) {
              localPathCandidate = candidate;
            }
          }
        } catch {
          // Ignore URL parse error
        }
      }

      if (localPathCandidate) {
        try {
          buffer = await readFile(localPathCandidate);
          originalName = path.basename(localPathCandidate);
          const ext = path.extname(localPathCandidate).toLowerCase();
          if (ext === ".png") mimeType = "image/png";
          else if (ext === ".webp") mimeType = "image/webp";
          else if (ext === ".avif") mimeType = "image/avif";
          else if (ext === ".gif") mimeType = "image/gif";
          else mimeType = "image/jpeg";
        } catch (readErr) {
          console.error("Local file not found on disk:", localPathCandidate, readErr);
          return NextResponse.json(
            { error: `Image not found on server: ${cleanUrl}` },
            { status: 404 }
          );
        }
      } else {
        // Fetch external image from URL with SSRF Protection
        try {
          const urlObj = new URL(cleanUrl);

          // Restrict protocol strictly to HTTP/HTTPS
          if (urlObj.protocol !== "https:" && urlObj.protocol !== "http:") {
            return NextResponse.json(
              { error: "Only http: and https: protocols are permitted." },
              { status: 400 }
            );
          }

          const hostname = urlObj.hostname.toLowerCase();

          // Resolve all IP addresses via DNS to prevent DNS rebinding, alternative encodings, and host spoofing
          let resolvedIPs: string[] = [];
          try {
            const lookups = await dns.lookup(hostname, { all: true });
            resolvedIPs = lookups.map((l) => l.address);
          } catch {
            return NextResponse.json(
              { error: "Could not resolve hostname for remote image." },
              { status: 400 }
            );
          }

          // Block if DNS returned no IPs or any IP falls within private, loopback, or cloud metadata CIDRs
          if (resolvedIPs.length === 0 || resolvedIPs.some(isPrivateOrReservedIP)) {
            return NextResponse.json(
              { error: "Forbidden: Fetching internal, private, or loopback network addresses is prohibited." },
              { status: 403 }
            );
          }

          const res = await fetch(cleanUrl, {
            redirect: "error", // Prevent HTTP redirects from circumventing internal IP blocklists
            signal: AbortSignal.timeout(10000), // 10s fetch timeout
            headers: {
              "User-Agent": "FaizanGems-ImageFetcher/1.0",
            },
          });

          if (!res.ok) {
            return NextResponse.json(
              { error: `Failed to fetch image from URL (${res.status}): ${res.statusText}` },
              { status: 400 }
            );
          }

          const contentLength = res.headers.get("content-length");
          if (contentLength && parseInt(contentLength, 10) > MAX_FILE_SIZE) {
            return NextResponse.json(
              { error: "Remote image exceeds 25MB limit" },
              { status: 400 }
            );
          }

          const bytes = await res.arrayBuffer();
          if (bytes.byteLength > MAX_FILE_SIZE) {
            return NextResponse.json(
              { error: "Remote image exceeds 25MB limit" },
              { status: 400 }
            );
          }

          buffer = Buffer.from(bytes);
          const ct = res.headers.get("content-type");
          if (ct) mimeType = ct;
          originalName = path.basename(urlObj.pathname) || "remote-gem.jpg";
        } catch (fetchErr: unknown) {
          const msg = fetchErr instanceof Error ? fetchErr.message : "Invalid URL";
          return NextResponse.json(
            { error: `Invalid or unreachable image URL: ${msg}` },
            { status: 400 }
          );
        }
      }
    } else {
      return NextResponse.json({ error: "No file or imageUrl provided" }, { status: 400 });
    }

    // Target upload directory
    const targetCategory = category === "certificates"
      ? "certificates"
      : category === "branding"
      ? "branding"
      : category === "banners" || category === "hero"
      ? "banners"
      : category === "slips" || category === "receipts"
      ? "slips"
      : "gemstones";
    const uploadDir = path.join(process.cwd(), "public", "uploads", targetCategory);
    await mkdir(uploadDir, { recursive: true });

    const timestamp = Date.now();
    const randomSuffix = Math.random().toString(36).substring(2, 8);
    const prefix = targetCategory === "certificates"
      ? "cert"
      : targetCategory === "branding"
      ? "logo"
      : targetCategory === "banners"
      ? "hero"
      : targetCategory === "slips"
      ? "slip"
      : "gem";

    // If PDF (certificate), write directly
    if (mimeType === "application/pdf") {
      const fileName = `${prefix}-${timestamp}-${randomSuffix}.pdf`;
      const filePath = path.join(uploadDir, fileName);
      await writeFile(filePath, buffer);
      return NextResponse.json({
        success: true,
        url: `/uploads/${targetCategory}/${fileName}`,
        fileName,
        originalName,
        mimeType,
        category: targetCategory,
      });
    }

    // If Video, save directly to gemstone videos directory
    const isVideo =
      mimeType.startsWith("video/") ||
      mimeType === "application/mp4" ||
      originalName.toLowerCase().endsWith(".mp4") ||
      originalName.toLowerCase().endsWith(".m4v") ||
      originalName.toLowerCase().endsWith(".mov") ||
      originalName.toLowerCase().endsWith(".webm");

    if (isVideo) {
      const lowerName = originalName.toLowerCase();
      let ext = "mp4";
      if (lowerName.endsWith(".webm") || mimeType === "video/webm") {
        ext = "webm";
      } else if (lowerName.endsWith(".mov") || mimeType === "video/quicktime") {
        ext = "mov";
      } else {
        ext = "mp4";
      }

      const videoCategory = targetCategory === "gemstones" ? "gemstones/videos" : targetCategory;
      const videoUploadDir = path.join(process.cwd(), "public", "uploads", videoCategory);
      await mkdir(videoUploadDir, { recursive: true });

      const fileName = `gem-video-${timestamp}-${randomSuffix}.${ext}`;
      const filePath = path.join(videoUploadDir, fileName);
      await writeFile(filePath, buffer);
      return NextResponse.json({
        success: true,
        url: `/uploads/${videoCategory}/${fileName}`,
        fileName,
        originalName,
        mimeType: ext === "mp4" ? "video/mp4" : mimeType,
        category: videoCategory,
        size: buffer.length,
      });
    }

    // Process Image with Sharp (rotate() auto-orients based on EXIF)
    const baseSharp = sharp(buffer).rotate();
    const metadata = await baseSharp.metadata();

    if (!metadata.width || !metadata.height) {
      return NextResponse.json(
        { error: "Invalid image format or unreadable dimensions" },
        { status: 400 }
      );
    }

    let finalBuffer: Buffer;
    let isCropped = false;
    let finalWidth = metadata.width;
    let finalHeight = metadata.height;

    // Detect if PNG preservation is desired (especially for logos/branding)
    const isPng = mimeType === "image/png" || originalName.toLowerCase().endsWith(".png");
    const outputFormat = (targetCategory === "branding" && isPng) ? "png" : "webp";

    if (cropJson) {
      try {
        const crop = JSON.parse(cropJson);
        let left = 0;
        let top = 0;
        let width = metadata.width;
        let height = metadata.height;

        if (crop.isPercentage) {
          left = Math.round(((crop.x || 0) / 100) * metadata.width);
          top = Math.round(((crop.y || 0) / 100) * metadata.height);
          width = Math.round(((crop.width || 100) / 100) * metadata.width);
          height = Math.round(((crop.height || 100) / 100) * metadata.height);
        } else {
          left = Math.round(crop.x ?? crop.left ?? 0);
          top = Math.round(crop.y ?? crop.top ?? 0);
          width = Math.round(crop.width ?? metadata.width);
          height = Math.round(crop.height ?? metadata.height);
        }

        // Safety against NaN / Infinity
        if (isNaN(left) || !isFinite(left)) left = 0;
        if (isNaN(top) || !isFinite(top)) top = 0;
        if (isNaN(width) || !isFinite(width) || width <= 0) width = metadata.width;
        if (isNaN(height) || !isFinite(height) || height <= 0) height = metadata.height;

        // Clamp safely to image boundaries
        left = Math.max(0, Math.min(metadata.width - 1, left));
        top = Math.max(0, Math.min(metadata.height - 1, top));
        width = Math.max(1, Math.min(metadata.width - left, width));
        height = Math.max(1, Math.min(metadata.height - top, height));

        finalWidth = width;
        finalHeight = height;
        isCropped = true;

        const cropInstance = sharp(buffer).rotate();
        if (outputFormat === "png") {
          finalBuffer = await cropInstance
            .extract({ left, top, width, height })
            .png({ compressionLevel: 9 })
            .toBuffer();
        } else {
          finalBuffer = await cropInstance
            .extract({ left, top, width, height })
            .webp({ quality: 92, effort: 4 })
            .toBuffer();
        }
      } catch (err) {
        console.warn("Invalid crop data passed, falling back to full image optimization:", err);
        const fallbackInstance = sharp(buffer).rotate();
        if (outputFormat === "png") {
          finalBuffer = await fallbackInstance.png({ compressionLevel: 9 }).toBuffer();
        } else {
          finalBuffer = await fallbackInstance.webp({ quality: 90 }).toBuffer();
        }
      }
    } else {
      // Optimize image without crop (preserve transparent PNG for logos)
      const fullInstance = sharp(buffer).rotate();
      if (outputFormat === "png") {
        finalBuffer = await fullInstance.png({ compressionLevel: 9 }).toBuffer();
      } else {
        finalBuffer = await fullInstance.webp({ quality: 90 }).toBuffer();
      }
    }

    const ext = outputFormat === "png" ? "png" : "webp";
    const fileName = `${prefix}-${isCropped ? "cropped-" : ""}${timestamp}-${randomSuffix}.${ext}`;
    const filePath = path.join(uploadDir, fileName);
    await writeFile(filePath, finalBuffer);

    const publicUrl = `/uploads/${targetCategory}/${fileName}`;

    return NextResponse.json({
      success: true,
      url: publicUrl,
      fileName,
      originalName,
      width: finalWidth,
      height: finalHeight,
      size: finalBuffer.length,
      mimeType: outputFormat === "png" ? "image/png" : "image/webp",
      category: targetCategory,
      cropped: isCropped,
    });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : String(error);
    console.error("File upload/crop error:", msg, error);
    return NextResponse.json(
      { error: `Internal error processing image: ${msg}` },
      { status: 500 }
    );
  }
}
