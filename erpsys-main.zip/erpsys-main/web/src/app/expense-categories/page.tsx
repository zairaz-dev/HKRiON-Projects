"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import {
  Plus,
  Edit2,
  Trash2,
  Loader2,
  CheckCircle,
  AlertCircle,
  Building2,
  Globe,
  FolderTree
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { DataTable, ColumnDef, ActionsDropdown } from "@/components/ui/table";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";

import { Select } from "@/components/ui/select";

import {
  ExpenseCategoryItem,
  ExpenseCategoryDialog,
  ExpenseCategoryDeleteDialog,
  useExpenseCategoriesQuery,
  useBranchesQuery
} from "@/features/expense-categories";

function ExpenseCategoriesPageContent() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Notifications
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Dialog States
  const [isDialogOpen, setIsDialogOpen] = useState<boolean>(false);
  const [editingCategory, setEditingCategory] = useState<ExpenseCategoryItem | null>(null);
  const [categoryToDelete, setCategoryToDelete] = useState<ExpenseCategoryItem | null>(null);

  // URL-driven Branch Filter
  const selectedBranchFilter = searchParams.get("branchId") || "all";

  const setSelectedBranchFilter = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value === "all") {
      params.delete("branchId");
    } else {
      params.set("branchId", value);
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  // Authenticate
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  // Fetch Data via React Query
  const businessId = currentUser?.businessId || "";
  const { data: categories = [], isLoading: categoriesLoading, error: categoriesError } = useExpenseCategoriesQuery(businessId);
  const { data: branchesList = [], isLoading: branchesLoading } = useBranchesQuery(businessId, currentUser?.id);

  // Handle Query Errors
  useEffect(() => {
    if (categoriesError) {
      setError(categoriesError.message || "Failed to load expense categories.");
    }
  }, [categoriesError]);

  // Auto-dismiss notifications
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  const handleOpenCreateModal = () => {
    setEditingCategory(null);
    setIsDialogOpen(true);
  };

  const handleOpenEditModal = (category: ExpenseCategoryItem) => {
    setEditingCategory(category);
    setIsDialogOpen(true);
  };

  // Filter Logic
  const getFilteredCategories = () => {
    let list = categories;

    if (selectedBranchFilter !== "all") {
      if (selectedBranchFilter === "global") {
        list = list.filter((c) => !c.branches || c.branches.length === 0);
      } else {
        list = list.filter((c) =>
          c.branches?.some((cb) => cb.branch.id === selectedBranchFilter)
        );
      }
    }

    return list;
  };

  const filteredList = getFilteredCategories();

  // Columns Definition
  const columns: ColumnDef<ExpenseCategoryItem>[] = [
    {
      header: "Category Name",
      searchable: true,
      render: (cat) => (
        <span className="font-semibold text-foreground">{cat.name}</span>
      ),
    },
    {
      header: "Parent Category",
      render: (cat) => (
        <span className="text-xs font-medium text-foreground/80">
          {cat.parent ? (
            <span className="inline-flex items-center gap-1">
              <FolderTree className="h-3.5 w-3.5 text-muted-foreground/60" />
              {cat.parent.name}
            </span>
          ) : (
            <span className="text-muted-foreground italic">None (Main Category)</span>
          )}
        </span>
      ),
    },
    {
      header: "Category Code",
      render: (cat) => (
        <span className="text-xs font-mono">
          {cat.code || <span className="text-muted-foreground italic">None</span>}
        </span>
      ),
    },
    {
      header: "Description",
      render: (cat) => (
        <span className="text-xs text-muted-foreground max-w-[200px] truncate block">
          {cat.description || <span className="italic">No description</span>}
        </span>
      ),
    },
    {
      header: "Branch Scope",
      render: (cat) => {
        if (!cat.branches || cat.branches.length === 0) {
          return (
            <span className="inline-flex items-center gap-1 text-xs text-muted-foreground font-medium">
              <Globe className="h-3.5 w-3.5 text-muted-foreground/60" />
              Global
            </span>
          );
        }
        if (cat.branches.length === 1) {
          return (
            <span className="inline-flex items-center gap-1 text-xs text-foreground/80 font-medium">
              <Building2 className="h-3.5 w-3.5 text-muted-foreground/60" />
              {cat.branches[0].branch.name}
            </span>
          );
        }
        return (
          <span className="inline-flex items-center gap-1 text-xs text-primary font-medium">
            <Building2 className="h-3.5 w-3.5 text-primary/60" />
            {cat.branches.length} Branches
          </span>
        );
      },
    },
    {
      header: "Status",
      render: (cat) => (
        <span
          className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${
            cat.isActive
              ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
              : "bg-destructive/10 text-destructive border-destructive/20"
          }`}
        >
          {cat.isActive ? "Active" : "Inactive"}
        </span>
      ),
    },
    {
      header: "Actions",
      render: (cat) => (
        <ActionsDropdown
          actions={[
            {
              label: "Edit",
              onClick: () => handleOpenEditModal(cat),
              icon: <Edit2 className="h-3.5 w-3.5" />,
            },
            {
              label: "Delete",
              onClick: () => setCategoryToDelete(cat),
              icon: <Trash2 className="h-3.5 w-3.5" />,
              variant: "destructive",
            },
          ]}
        />
      ),
    },
  ];

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3 p-6 max-w-sm border border-border/40 rounded-xl bg-card/60 backdrop-blur-sm">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <h2 className="text-lg font-bold">Unauthorized Access</h2>
          <p className="text-sm text-muted-foreground">
            You need to be logged in to view this page. Redirecting to login...
          </p>
          <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
        </div>
      </div>
    );
  }

  const isLoading = categoriesLoading || branchesLoading;

  const customFilters = (
    <div className="space-y-1.5 min-w-[200px]">
      <label className="text-[10px] font-bold text-muted-foreground uppercase">
        Branch Filter
      </label>
      <Select
        value={selectedBranchFilter}
        onValueChange={setSelectedBranchFilter}
        className="h-9 text-xs"
      >
        <option value="all">All Branches</option>
        <option value="global">Global (No Branch)</option>
        {branchesList.map((b) => (
          <option key={b.id} value={b.id}>
            {b.name}
          </option>
        ))}
      </Select>
    </div>
  );

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/expense-categories" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Expense Categories" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <FolderTree className="h-7 w-7 text-primary" /> Expense Categories
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Manage your business expense categories, sub-categories, codes, and branch mappings.
              </p>
            </div>
          </div>

          {/* Banner Notifications */}
          {successMessage && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 animate-in fade-in slide-in-from-top-4 duration-300">
              <CheckCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive animate-in fade-in slide-in-from-top-4 duration-300">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          {/* Main Table Card */}
          {isLoading ? (
            <div className="flex h-64 items-center justify-center">
              <div className="text-center space-y-2">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
                <span className="text-sm text-muted-foreground block">Loading categories...</span>
              </div>
            </div>
          ) : (
            <DataTable
              data={filteredList}
              columns={columns}
              searchKeys={["name", "code"]}
              actionButton={{
                label: "Add Category",
                onClick: handleOpenCreateModal,
                icon: <Plus className="h-4 w-4" />
              }}
              customFilters={customFilters}
              reportTitle="Expense Categories Report"
            />
          )}
        </main>
      </div>

      {/* Create / Edit Modal Dialog */}
      {currentUser && (
        <ExpenseCategoryDialog
          isOpen={isDialogOpen}
          onClose={() => {
            setIsDialogOpen(false);
            setEditingCategory(null);
          }}
          category={editingCategory}
          branches={branchesList}
          currentUser={currentUser}
          onSuccess={setSuccessMessage}
          onError={setError}
        />
      )}

      {/* Delete Confirmation Dialog */}
      {currentUser && categoryToDelete && (
        <ExpenseCategoryDeleteDialog
          isOpen={!!categoryToDelete}
          onClose={() => setCategoryToDelete(null)}
          category={categoryToDelete}
          currentUser={currentUser}
          onSuccess={setSuccessMessage}
          onError={setError}
        />
      )}
    </div>
  );
}

export default function ExpenseCategoriesPage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen w-screen items-center justify-center bg-[#121216]">
        <div className="flex flex-col items-center gap-2">
          <div className="w-8 h-8 border-4 border-zinc-700 border-t-emerald-500 rounded-full animate-spin" />
          <p className="text-sm text-zinc-400">Loading...</p>
        </div>
      </div>
    }>
      <ExpenseCategoriesPageContent />
    </Suspense>
  );
}
