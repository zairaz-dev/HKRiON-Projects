import { Injectable, UnauthorizedException, BadRequestException, ForbiddenException, NotFoundException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import { User } from '../../types';
import { PrismaService } from '../prisma/prisma.service';
import { OAuth2Client } from 'google-auth-library';
import { Role } from '../../common/enums/role.enum';

@Injectable()
export class AuthService {
  constructor(
    private readonly jwtService: JwtService,
    private readonly prisma: PrismaService,
  ) {
    this.initDatabase();
  }

  private async initDatabase() {
    await this.seedDefaultUser();
  }

  private async seedDefaultUser() {
    const adminEmail = 'admin@hkr.com';
    const superAdminEmail = 'superadmin@hkr.com';
    try {
      // Ensure default geographic data exists for linking
      let country = await this.prisma.country.findFirst();
      if (!country) {
        country = await this.prisma.country.create({
          data: { code: 'IN', name: 'India' }
        });
      }
      let currency = await this.prisma.currency.findFirst();
      if (!currency) {
        currency = await this.prisma.currency.create({
          data: { code: 'INR', symbol: '₹', name: 'Indian Rupee' }
        });
      }
      let phoneCode = await this.prisma.phoneCode.findFirst();
      if (!phoneCode) {
        phoneCode = await this.prisma.phoneCode.create({
          data: { code: '+91', name: 'India (+91)' }
        });
      }

      // Ensure default business & branch exist for linking
      let defaultBusiness = await this.prisma.business.findFirst({
        where: { name: 'HKR System Business' }
      });
      if (!defaultBusiness) {
        defaultBusiness = await this.prisma.business.create({
          data: {
            name: 'HKR System Business',
            industry: 'ERP Systems',
            phone: '1234567890',
            countryId: country.id,
            currencyId: currency.id,
            phoneCodeId: phoneCode.id,
          }
        });
      }

      let defaultBranch = await this.prisma.branch.findFirst({
        where: { businessId: defaultBusiness.id }
      });
      if (!defaultBranch) {
        defaultBranch = await this.prisma.branch.create({
          data: {
            name: 'Main Branch',
            businessId: defaultBusiness.id,
            isActive: true,
          }
        });
      }

      // Ensure default payment methods exist for the default business
      const defaultPMs = [
        { name: 'Cash', code: 'cash', sortOrder: 1 },
        { name: 'Card', code: 'card', sortOrder: 2 },
        { name: 'Bank Transfer', code: 'bank_transfer', sortOrder: 3 },
        { name: 'Cheque', code: 'cheque', sortOrder: 4 },
      ];

      for (const pm of defaultPMs) {
        let paymentMethod = await this.prisma.paymentMethod.findFirst({
          where: {
            code: pm.code,
            businessId: defaultBusiness.id,
          },
        });

        if (!paymentMethod) {
          paymentMethod = await this.prisma.paymentMethod.create({
            data: {
              name: pm.name,
              code: pm.code,
              sortOrder: pm.sortOrder,
              isSystem: true,
              businessId: defaultBusiness.id,
            },
          });
        }

        const branchPaymentMethod = await this.prisma.branchPaymentMethod.findUnique({
          where: {
            branchId_paymentMethodId: {
              branchId: defaultBranch.id,
              paymentMethodId: paymentMethod.id,
            },
          },
        });

        if (!branchPaymentMethod) {
          await this.prisma.branchPaymentMethod.create({
            data: {
              branchId: defaultBranch.id,
              paymentMethodId: paymentMethod.id,
              isActive: true,
            },
          });
        }
      }


      // 1. Seed Admin
      const existingAdmin = await this.prisma.user.findUnique({
        where: { email: adminEmail },
      });

      if (!existingAdmin) {
        let adminRole = await (this.prisma).role.findFirst({
          where: { role: 'admin', businessId: null }
        });

        if (!adminRole) {
          adminRole = await (this.prisma).role.create({
            data: {
              role: 'admin',
              name: 'Admin',
              description: 'Full system access and control',
              businessId: null,
            }
          });
        }

        const passwordHash = await bcrypt.hash('admin123', 10);
        await this.prisma.user.create({
          data: {
            email: adminEmail,
            name: 'HKR Admin',
            roleId: adminRole.id,
            passwordHash,
            businessId: defaultBusiness.id,
            branches: {
              create: {
                branchId: defaultBranch.id,
              },
            },
          },
        });
        console.log('Default user seeded: admin@hkr.com / admin123');
      }

      // 2. Seed Super Admin
      const existingSuperAdmin = await this.prisma.user.findUnique({
        where: { email: superAdminEmail },
      });

      if (!existingSuperAdmin) {
        let superAdminRole = await (this.prisma).role.findFirst({
          where: { role: 'super-admin', businessId: null }
        });

        if (!superAdminRole) {
          superAdminRole = await (this.prisma).role.create({
            data: {
              role: 'super-admin',
              name: 'Super Admin',
              description: 'Global platform administrator',
              businessId: null,
            }
          });
        }

        const passwordHash = await bcrypt.hash('superadmin123', 10);
        await this.prisma.user.create({
          data: {
            email: superAdminEmail,
            name: 'HKR Super Admin',
            roleId: superAdminRole.id,
            passwordHash,
            // Super admin is a global platform user, not bound to any single business.
            businessId: null,
          },
        });
        console.log('Default super admin seeded: superadmin@hkr.com / superadmin123');
      }
    } catch (error) {
      console.error('Error seeding default users:', error);
    }
  }

  async register(
    email: string,
    password: string,
    name: string,
    role: string,
    businessId?: string,
    branchIds?: string[],
    createdById?: string,
    phone?: string,
    avatar?: string,
    address?: string,
    isActive?: boolean,
  ): Promise<User> {
    const existingUser = await this.prisma.user.findUnique({
      where: { email },
    });
    if (existingUser) {
      throw new BadRequestException('User with this email already exists');
    }

    if (role !== undefined && role !== null && typeof role !== 'string') {
      throw new BadRequestException('Role must be a valid string');
    }
    const targetRole = (typeof role === 'string' ? role.trim() : null) || Role.ADMIN;
    // Prefer a business-specific role; fall back to the global (businessId: null) role.
    const roleRecord = await (this.prisma).role.findFirst({
      where: {
        role: targetRole,
        OR: [
          { businessId: businessId ?? null },
          { businessId: null },
        ],
      },
      orderBy: { businessId: 'desc' },
    });

    if (!roleRecord) {
      throw new BadRequestException(`Role ${targetRole} not found.`);
    }

    if (roleRecord.role !== Role.ADMIN && roleRecord.role !== Role.SUPER_ADMIN) {
      if (!branchIds || branchIds.length === 0) {
        throw new BadRequestException('Branch selection is mandatory. Please select at least one branch for this user.');
      }
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const newUser = await this.prisma.user.create({
      data: {
        email,
        name,
        roleId: roleRecord.id,
        passwordHash,
        businessId: businessId || null,
        createdById: createdById || null,
        phone: phone || null,
        avatar: avatar || null,
        address: address || null,
        isActive: isActive !== undefined ? isActive : true,
      },
      include: {
        role: true
      }
    });

    const roleSlug = newUser.role.role as User['role'];

    // If branchIds are provided and user is not admin, associate branches
    if (branchIds && branchIds.length > 0 && roleSlug !== Role.ADMIN && roleSlug !== Role.SUPER_ADMIN) {
      await this.prisma.userBranch.createMany({
        data: branchIds.map((branchId) => ({
          userId: newUser.id,
          branchId,
        })),
      });
    }

    // Fetch user with branches & rolePermissions to return
    const createdUser = await this.prisma.user.findUnique({
      where: { id: newUser.id },
      include: {
        role: {
          include: {
            rolePermissions: true,
          },
        },
        branches: {
          include: {
            branch: true,
          },
        },
      },
    });

    if (!createdUser) {
      throw new BadRequestException('Failed to retrieve created user');
    }

    const { passwordHash: _, ...userWithoutHash } = createdUser;
    
    let userBranches: any[] = [];
    if (roleSlug === 'admin' || roleSlug === 'super-admin') {
      if (businessId) {
        userBranches = await this.prisma.branch.findMany({
          where: { businessId },
        });
      }
    } else {
      userBranches = createdUser.branches.map((ub) => ub.branch);
    }

    const permissions =
      (createdUser.role as any)?.rolePermissions?.map((rp: any) => rp.permissionId) || [];

    return {
      ...userWithoutHash,
      role: roleSlug,
      branches: userBranches,
      phone: createdUser.phone || undefined,
      isActive: createdUser.isActive,
      avatar: createdUser.avatar || undefined,
      address: createdUser.address || undefined,
      lastLoginAt: createdUser.lastLoginAt ? createdUser.lastLoginAt.toISOString() : undefined,
      lastLoginIp: createdUser.lastLoginIp || undefined,
      createdAt: userWithoutHash.createdAt.toISOString(),
      permissions,
    };
  }

  async login(email: string, password: string, clientIp?: string): Promise<{ token: string; user: User }> {
    const user = await this.prisma.user.findUnique({
      where: { email },
      include: {
        role: {
          include: {
            rolePermissions: true,
          },
        },
        business: true,
      }
    });
    if (!user) {
      throw new UnauthorizedException('Invalid email or password');
    }

    const isPasswordValid = await bcrypt.compare(password, user.passwordHash);
    if (!isPasswordValid) {
      throw new UnauthorizedException('Invalid email or password');
    }

    if (user.isActive === false) {
      throw new ForbiddenException('Your user account has been deactivated. Please contact your administrator.');
    }

    const roleSlug = (user.role as any)?.role || Role.ADMIN;

    // Super admins are global and can always log in.
    // All other users are blocked if their business has been deactivated.
    if (roleSlug !== Role.SUPER_ADMIN && user.businessId) {
      const business = await this.prisma.business.findUnique({
        where: { id: user.businessId },
        select: { isActive: true },
      });
      if (business && business.isActive === false) {
        throw new ForbiddenException('Your business account has been deactivated. Please contact support.');
      }
    }

    // Record login timestamp & client IP
    const updatedUser = await this.prisma.user.update({
      where: { id: user.id },
      data: {
        lastLoginAt: new Date(),
        ...(clientIp ? { lastLoginIp: clientIp } : {}),
      },
    });

    const payload = { sub: user.id, email: user.email, role: roleSlug };
    const token = this.jwtService.sign(payload);

    const { passwordHash: _, business, ...userWithoutHash } = user;
    const businessObj = business ? {
      ...business,
      createdAt: business.createdAt.toISOString(),
      updatedAt: business.updatedAt.toISOString(),
    } : undefined;

    const permissions =
      (user.role as any)?.rolePermissions?.map((rp: any) => rp.permissionId) || [];

    return {
      token,
      user: {
        ...userWithoutHash,
        business: businessObj,
        role: roleSlug as User['role'],
        phone: user.phone || undefined,
        isActive: user.isActive,
        avatar: user.avatar || undefined,
        address: user.address || undefined,
        lastLoginAt: updatedUser.lastLoginAt ? updatedUser.lastLoginAt.toISOString() : undefined,
        lastLoginIp: updatedUser.lastLoginIp || undefined,
        createdAt: userWithoutHash.createdAt.toISOString(),
        permissions,
      },
    };
  }

  async getUsers(businessId?: string): Promise<User[]> {
    const whereClause = businessId ? { businessId } : {};
    const users = await this.prisma.user.findMany({
      where: whereClause,
      include: { 
        role: {
          include: {
            rolePermissions: true,
          },
        },
        branches: {
          include: {
            branch: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    const allBranches = await this.prisma.branch.findMany();

    return users.map((user) => {
      const { passwordHash: _, ...userWithoutHash } = user;
      const roleSlug = (user.role as any)?.role || Role.ADMIN;

      let userBranches: any[] = [];
      if (roleSlug === Role.ADMIN || roleSlug === Role.SUPER_ADMIN) {
        userBranches = user.businessId
          ? allBranches.filter((b) => b.businessId === user.businessId)
          : allBranches;
      } else {
        userBranches = user.branches.map((ub) => ub.branch);
      }

      const permissions =
        (user.role as any)?.rolePermissions?.map((rp: any) => rp.permissionId) || [];

      return {
        ...userWithoutHash,
        role: roleSlug as User['role'],
        branches: userBranches,
        phone: user.phone || undefined,
        isActive: user.isActive,
        avatar: user.avatar || undefined,
        address: user.address || undefined,
        lastLoginAt: user.lastLoginAt ? user.lastLoginAt.toISOString() : undefined,
        lastLoginIp: user.lastLoginIp || undefined,
        createdAt: userWithoutHash.createdAt.toISOString(),
        permissions,
      };
    });
  }

  async getUserById(id: string, businessId?: string): Promise<any> {
    const whereClause: any = { id };
    if (businessId) {
      whereClause.businessId = businessId;
    }

    const user = await this.prisma.user.findFirst({
      where: whereClause,
      include: {
        role: {
          include: {
            rolePermissions: {
              include: {
                permission: true,
              },
            },
          },
        },
        branches: {
          include: {
            branch: true,
          },
        },
        business: true,
      },
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    const { passwordHash: _, business, ...userWithoutHash } = user;
    const roleSlug = (user.role as any)?.role || Role.ADMIN;

    let userBranches: any[] = [];
    if (roleSlug === Role.ADMIN || roleSlug === Role.SUPER_ADMIN) {
      userBranches = user.businessId
        ? await this.prisma.branch.findMany({ where: { businessId: user.businessId } })
        : await this.prisma.branch.findMany();
    } else {
      userBranches = user.branches.map((ub) => ub.branch);
    }

    const permissions =
      (user.role as any)?.rolePermissions?.map((rp: any) => rp.permissionId) || [];

    return {
      ...userWithoutHash,
      role: roleSlug as User['role'],
      branches: userBranches,
      business: business
        ? {
            id: business.id,
            name: business.name,
            industry: business.industry,
          }
        : undefined,
      phone: user.phone || undefined,
      isActive: user.isActive,
      avatar: user.avatar || undefined,
      address: user.address || undefined,
      lastLoginAt: user.lastLoginAt ? user.lastLoginAt.toISOString() : undefined,
      lastLoginIp: user.lastLoginIp || undefined,
      createdAt: userWithoutHash.createdAt.toISOString(),
      permissions,
    };
  }

  async updateUser(
    id: string,
    data: {
      email?: string;
      name?: string;
      role?: string;
      password?: string;
      branchIds?: string[];
      updatedById?: string;
      businessId?: string | null;
      phone?: string;
      avatar?: string;
      address?: string;
      isActive?: boolean;
    },
  ): Promise<User> {
    const existingUser = await this.prisma.user.findUnique({
      where: { id },
      include: { role: true }
    });
    if (!existingUser) {
      throw new BadRequestException('User not found');
    }

    const updateData: any = {};
    if (data.updatedById !== undefined) {
      updateData.updatedById = data.updatedById;
    }
    if (data.businessId !== undefined) {
      updateData.businessId = data.businessId;
    }
    if (data.phone !== undefined) updateData.phone = data.phone;
    if (data.avatar !== undefined) updateData.avatar = data.avatar;
    if (data.address !== undefined) updateData.address = data.address;
    if (data.isActive !== undefined) updateData.isActive = data.isActive;

    if (data.email) {
      const emailExists = await this.prisma.user.findUnique({
        where: { email: data.email },
      });
      if (emailExists && emailExists.id !== id) {
        throw new BadRequestException('User with this email already exists');
      }
      updateData.email = data.email;
    }
    if (data.name) updateData.name = data.name;
    
    let finalRoleSlug = (existingUser.role as any)?.role || Role.ADMIN;

    if (data.role) {
      if (typeof data.role !== 'string') {
        throw new BadRequestException('Role must be a valid string');
      }
      const roleName = data.role.trim();
      const roleRecord = await (this.prisma).role.findFirst({
        where: {
          role: roleName,
          OR: [
            { businessId: existingUser.businessId || null },
            { businessId: null }
          ]
        },
        orderBy: { businessId: 'desc' }
      });
      if (!roleRecord) {
        throw new BadRequestException(`Role ${roleName} not found.`);
      }
      updateData.roleId = roleRecord.id;
      finalRoleSlug = roleRecord.role;
    }
    
    if (data.password) {
      updateData.passwordHash = await bcrypt.hash(data.password, 10);
    }

    // Handle branch association updates
    if (data.branchIds !== undefined) {
      if (finalRoleSlug !== 'admin' && finalRoleSlug !== 'super-admin' && data.branchIds.length === 0) {
        throw new BadRequestException('Branch selection is mandatory. Please select at least one branch for this user.');
      }

      // Delete existing mappings first
      await this.prisma.userBranch.deleteMany({
        where: { userId: id },
      });

      // Only create new mappings if user is not admin
      if (finalRoleSlug !== 'admin' && finalRoleSlug !== 'super-admin' && data.branchIds.length > 0) {
        await this.prisma.userBranch.createMany({
          data: data.branchIds.map((branchId) => ({
            userId: id,
            branchId,
          })),
        });
      }
    } else if (data.role && (finalRoleSlug === 'admin' || finalRoleSlug === 'super-admin')) {
      // If role changed to admin/super-admin, clean up branch mappings
      await this.prisma.userBranch.deleteMany({
        where: { userId: id },
      });
    }

    const updatedUser = await this.prisma.user.update({
      where: { id },
      data: updateData,
      include: { 
        role: {
          include: {
            rolePermissions: true,
          },
        },
        branches: {
          include: {
            branch: true,
          },
        },
      }
    });

    const { passwordHash: _, ...userWithoutHash } = updatedUser;
    
    let userBranches: any[] = [];
    if (finalRoleSlug === 'admin' || finalRoleSlug === 'super-admin') {
      const bizId = updatedUser.businessId;
      if (bizId) {
        userBranches = await this.prisma.branch.findMany({
          where: { businessId: bizId },
        });
      }
    } else {
      userBranches = updatedUser.branches.map((ub) => ub.branch);
    }

    const permissions =
      (updatedUser.role as any)?.rolePermissions?.map((rp: any) => rp.permissionId) || [];

    return {
      ...userWithoutHash,
      role: finalRoleSlug as User['role'],
      branches: userBranches,
      phone: updatedUser.phone || undefined,
      isActive: updatedUser.isActive,
      avatar: updatedUser.avatar || undefined,
      address: updatedUser.address || undefined,
      lastLoginAt: updatedUser.lastLoginAt ? updatedUser.lastLoginAt.toISOString() : undefined,
      lastLoginIp: updatedUser.lastLoginIp || undefined,
      createdAt: userWithoutHash.createdAt.toISOString(),
      permissions,
    };
  }

  async googleLogin(token: string, clientIp?: string): Promise<any> {
    if (process.env.ENABLE_GOOGLE_LOGIN === 'false') {
      throw new ForbiddenException('Google login is currently disabled by administrator');
    }
    const googleClientId = process.env.GOOGLE_CLIENT_ID;
    if (!googleClientId) {
      throw new BadRequestException('Google Client ID is not configured on the backend server');
    }
    const client = new OAuth2Client(googleClientId);

    let email: string;
    let name: string;
    let googleId: string;

    // Detect if the token is an ID token (JWT format with exactly 3 parts split by dots) or access token
    if (token.split('.').length === 3) {
      try {
        const ticket = await client.verifyIdToken({
          idToken: token,
          audience: googleClientId,
        });
        const payload = ticket.getPayload();
        if (!payload || !payload.email) {
          throw new UnauthorizedException('Invalid Google token payload');
        }
        email = payload.email.toLowerCase();
        name = payload.name || 'Google User';
        googleId = payload.sub;
      } catch (error) {
        throw new UnauthorizedException('Invalid Google ID token');
      }
    } else {
      // Access token verification via Google OAuth UserInfo endpoint
      try {
        const response = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!response.ok) {
          throw new UnauthorizedException('Invalid Google access token');
        }
        const payload = await response.json();
        if (!payload || !payload.email) {
          throw new UnauthorizedException('Invalid Google access token payload');
        }
        email = payload.email.toLowerCase();
        name = payload.name || 'Google User';
        googleId = payload.sub;
      } catch (error) {
        throw new UnauthorizedException('Failed to verify Google access token');
      }
    }

    const user = await this.prisma.user.findUnique({
      where: { email },
      include: {
        role: {
          include: {
            rolePermissions: true,
          },
        },
      }
    });

    if (!user) {
      return {
        isNewUser: true,
        email,
        name,
      };
    }

    if (user.isActive === false) {
      throw new ForbiddenException('Your user account has been deactivated. Please contact your administrator.');
    }

    const roleSlug = (user.role as any)?.role || Role.ADMIN;

    // Super admins are global and can always log in.
    // All other users are blocked if their business has been deactivated.
    if (roleSlug !== Role.SUPER_ADMIN && user.businessId) {
      const business = await this.prisma.business.findUnique({
        where: { id: user.businessId },
        select: { isActive: true },
      });
      if (business && business.isActive === false) {
        throw new ForbiddenException('Your business account has been deactivated. Please contact support.');
      }
    }

    // Link account with Google provider if not already set & record login tracking
    const updatedUser = await this.prisma.user.update({
      where: { id: user.id },
      data: {
        lastLoginAt: new Date(),
        ...(clientIp ? { lastLoginIp: clientIp } : {}),
        ...(!user.provider || !user.providerId ? { provider: 'GOOGLE', providerId: googleId } : {}),
      }
    });

    const jwtPayload = { sub: user.id, email: user.email, role: roleSlug };
    const jwtToken = this.jwtService.sign(jwtPayload);

    const { passwordHash: _, ...userWithoutHash } = user;
    const permissions =
      (user.role as any)?.rolePermissions?.map((rp: any) => rp.permissionId) || [];

    return {
      token: jwtToken,
      user: {
        ...userWithoutHash,
        role: roleSlug as User['role'],
        phone: user.phone || undefined,
        isActive: user.isActive,
        avatar: user.avatar || undefined,
        address: user.address || undefined,
        lastLoginAt: updatedUser.lastLoginAt ? updatedUser.lastLoginAt.toISOString() : undefined,
        lastLoginIp: updatedUser.lastLoginIp || undefined,
        createdAt: userWithoutHash.createdAt.toISOString(),
        permissions,
      },
    };
  }

  async deleteUser(id: string): Promise<{ success: boolean }> {
    const existingUser = await this.prisma.user.findUnique({
      where: { id },
    });
    if (!existingUser) {
      throw new BadRequestException('User not found');
    }

    await this.prisma.user.delete({
      where: { id },
    });
    return { success: true };
  }

  /**
   * Returns true if the user identified by `id` is the last remaining super-admin.
   * Used to prevent locking the platform out of super-admin access.
   */
  async isLastSuperAdmin(id: string): Promise<boolean> {
    const superAdminRole = await (this.prisma).role.findFirst({
      where: { role: Role.SUPER_ADMIN, businessId: null },
    });
    if (!superAdminRole) {
      return false;
    }
    const count = await this.prisma.user.count({
      where: { roleId: superAdminRole.id },
    });
    return count <= 1;
  }
}
