import { Controller, Get, Query, UseGuards, Req } from '@nestjs/common';
import { SearchService } from './search.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('search')
export class SearchController {
  constructor(private readonly searchService: SearchService) {}

  @Get('global')
  async searchGlobal(
    @Req() req: any,
    @Query('query') query?: string,
    @Query('q') q?: string,
    @Query('businessId') queryBusinessId?: string,
    @Query('branchId') branchId?: string,
    @Query('limit') limit?: string,
  ) {
    const user = req.user;
    const businessId = (user && user.role !== 'super-admin' ? user.businessId : null) || queryBusinessId || user?.businessId;
    const searchTerm = query || q || '';
    const canViewPurchases = Boolean(
      user?.role === 'super-admin' ||
      user?.role === 'admin' ||
      user?.permissions?.includes('purchases:view')
    );

    return this.searchService.searchGlobal(
      searchTerm,
      businessId,
      branchId,
      limit ? parseInt(limit, 10) : 5,
      canViewPurchases,
    );
  }
}
