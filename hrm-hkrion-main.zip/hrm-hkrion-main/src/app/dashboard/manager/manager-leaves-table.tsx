"use client";

import { useState } from "react";
import { updateLeaveStatus } from "@/actions/leaves";
import { LeaveStatus } from "@prisma/client";
import { Check, X, CalendarOff } from "lucide-react";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Button } from "@/components/ui/button";

type LeaveRequest = {
  id: number;
  userId: number;
  startDate: Date;
  endDate: Date;
  reason: string | null;
  status: LeaveStatus;
  createdAt: Date;
  user: {
    firstName: string;
    lastName: string;
    email: string;
  };
};

export default function ManagerLeavesTable({ leaves }: { leaves: LeaveRequest[] }) {
  const [actionLoadingId, setActionLoadingId] = useState<number | null>(null);

  const handleUpdateStatus = async (id: number, newStatus: LeaveStatus) => {
    setActionLoadingId(id);
    await updateLeaveStatus(id, newStatus);
    setActionLoadingId(null);
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("en-US", { month: 'short', day: 'numeric' });
  };

  if (leaves.length === 0) {
    return (
      <div className="p-6">
        <div className="text-center py-8 text-text-muted flex flex-col items-center">
          <CalendarOff className="h-8 w-8 mb-2 opacity-50" />
          <p>No pending leave requests from your team.</p>
        </div>
      </div>
    );
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Employee</TableHead>
          <TableHead>Dates</TableHead>
          <TableHead>Reason</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {leaves.map((record) => (
          <TableRow key={record.id}>
            <TableCell className="whitespace-nowrap">
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-bg text-primary font-medium text-xs border border-primary/10">
                    {record.user.firstName.charAt(0)}{record.user.lastName.charAt(0)}
                  </div>
                  <div>
                    <div className="font-medium text-text-primary">{record.user.firstName} {record.user.lastName}</div>
                  </div>
                </div>
              </TableCell>
            <TableCell className="whitespace-nowrap">
              <div className="text-text-primary">{formatDate(record.startDate)} - {formatDate(record.endDate)}</div>
            </TableCell>
            <TableCell>
                <p className="max-w-[200px] truncate text-text-secondary" title={record.reason || ""}>
                  {record.reason || "—"}
                </p>
            </TableCell>
            <TableCell className="text-right">
              <div className="flex justify-end gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleUpdateStatus(record.id, 'APPROVED')}
                    disabled={actionLoadingId === record.id}
                    className="text-success hover:bg-success-bg hover:text-success h-8 w-8"
                    title="Approve"
                  >
                    <Check className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleUpdateStatus(record.id, 'REJECTED')}
                    disabled={actionLoadingId === record.id}
                    className="text-error hover:bg-error-bg hover:text-error h-8 w-8"
                    title="Reject"
                  >
                    <X className="h-4 w-4" />
                  </Button>
              </div>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
