'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import DashboardSidebar from '@/components/DashboardSidebar';
import {
  CheckCircle2, Clock, MessageSquare, Users,
  RefreshCw, Search, Shield, Briefcase, Plus, UserCheck
} from 'lucide-react';

interface Inquiry {
  id: string;
  name: string;
  email: string;
  phone: string;
  service: string;
  message: string;
  status: string;
  assignedTo?: { id: string; name: string; email: string } | null;
  createdAt: string;
}

export default function AdminDashboard() {
  const router = useRouter();
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('inquiries');

  const fetchInquiries = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/inquiries');
      if (res.status === 401 || res.status === 403) {
        router.push('/login');
        return;
      }
      const data = await res.json();
      if (data.inquiries) {
        setInquiries(data.inquiries);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    fetchInquiries();
  }, [fetchInquiries]);

  const handleStatusChange = async (id: string, newStatus: string) => {
    setUpdatingId(id);
    try {
      const res = await fetch('/api/admin/inquiries', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status: newStatus }),
      });
      if (res.ok) {
        setInquiries((prev) =>
          prev.map((item) => (item.id === id ? { ...item, status: newStatus } : item))
        );
      }
    } catch (err) {
      console.error(err);
    } finally {
      setUpdatingId(null);
    }
  };

  const filteredInquiries = inquiries.filter(
    (item) =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.service.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalInquiries = inquiries.length;
  const pendingCount = inquiries.filter((i) => i.status === 'PENDING').length;
  const inProgressCount = inquiries.filter((i) => i.status === 'IN_PROGRESS' || i.status === 'CONTACTED').length;
  const resolvedCount = inquiries.filter((i) => i.status === 'RESOLVED').length;

  return (
    <div className="min-h-screen bg-black text-white radial-bg flex">
      {/* Left Sidebar */}
      <DashboardSidebar
        userRole="ADMIN"
        userName="HKRION Admin"
        userEmail="admin@hkrion.com"
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Main Content Area */}
      <div className="flex-1 lg:ml-64 flex flex-col min-w-0 min-h-screen">
        
        {/* Top Navbar Header */}
        <header className="border-b border-[#1ABE56]/20 bg-black/80 backdrop-blur-md sticky top-0 z-30 px-6 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold font-mono tracking-wide text-white flex items-center gap-2">
              HKRION <span className="text-[#1ABE56]">Admin Console</span>
            </h1>
            <p className="text-xs text-neutral-400">Master Operations & Client Inquiries Management</p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={fetchInquiries}
              className="px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-[#1ABE56]/40 text-neutral-300 hover:text-white text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-[#1ABE56]' : ''}`} />
              Refresh
            </button>
          </div>
        </header>

        {/* Tab Content */}
        <main className="p-6 sm:p-8 space-y-8 flex-1">
          
          {activeTab === 'inquiries' && (
            <>
              {/* Metric Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="glass-card p-5 rounded-2xl border border-[#1ABE56]/30 bg-black/80 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-[#1ABE56]/20 flex items-center justify-center shrink-0">
                    <MessageSquare className="w-6 h-6 text-[#1ABE56]" />
                  </div>
                  <div>
                    <p className="text-xs font-mono uppercase text-neutral-400">Total Inquiries</p>
                    <h3 className="text-2xl font-bold text-white">{totalInquiries}</h3>
                  </div>
                </div>

                <div className="glass-card p-5 rounded-2xl border border-yellow-500/30 bg-black/80 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-yellow-500/20 flex items-center justify-center shrink-0">
                    <Clock className="w-6 h-6 text-yellow-400" />
                  </div>
                  <div>
                    <p className="text-xs font-mono uppercase text-neutral-400">Pending Review</p>
                    <h3 className="text-2xl font-bold text-white">{pendingCount}</h3>
                  </div>
                </div>

                <div className="glass-card p-5 rounded-2xl border border-blue-500/30 bg-black/80 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center shrink-0">
                    <Users className="w-6 h-6 text-blue-400" />
                  </div>
                  <div>
                    <p className="text-xs font-mono uppercase text-neutral-400">In Progress</p>
                    <h3 className="text-2xl font-bold text-white">{inProgressCount}</h3>
                  </div>
                </div>

                <div className="glass-card p-5 rounded-2xl border border-emerald-500/30 bg-black/80 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center shrink-0">
                    <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                  </div>
                  <div>
                    <p className="text-xs font-mono uppercase text-neutral-400">Resolved</p>
                    <h3 className="text-2xl font-bold text-white">{resolvedCount}</h3>
                  </div>
                </div>
              </div>

              {/* Action Controls & Filter */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="relative w-full sm:w-80">
                  <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    placeholder="Search by client name, email, or service..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-500 focus:outline-none focus:border-[#1ABE56] text-xs transition-colors"
                  />
                </div>

                <div className="text-xs text-neutral-400 font-mono">
                  Showing {filteredInquiries.length} of {inquiries.length} submissions
                </div>
              </div>

              {/* Submissions Table */}
              <div className="glass-card rounded-2xl border border-[#1ABE56]/20 bg-black/90 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-neutral-900/90 text-neutral-400 uppercase font-mono border-b border-neutral-800">
                      <tr>
                        <th className="px-6 py-4">Client Name & Contact</th>
                        <th className="px-6 py-4">Requested Service</th>
                        <th className="px-6 py-4">Project Message</th>
                        <th className="px-6 py-4">Assigned To</th>
                        <th className="px-6 py-4">Status</th>
                        <th className="px-6 py-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-800/60">
                      {filteredInquiries.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="px-6 py-12 text-center text-neutral-500">
                            No inquiries found matching your filters.
                          </td>
                        </tr>
                      ) : (
                        filteredInquiries.map((inquiry) => (
                          <tr key={inquiry.id} className="hover:bg-neutral-900/40 transition-colors">
                            <td className="px-6 py-4">
                              <div className="font-semibold text-white">{inquiry.name}</div>
                              <div className="text-neutral-400 font-mono">{inquiry.email}</div>
                              {inquiry.phone && <div className="text-neutral-500">{inquiry.phone}</div>}
                            </td>
                            <td className="px-6 py-4">
                              <span className="px-2.5 py-1 rounded-lg bg-[#1ABE56]/10 text-[#1ABE56] font-medium border border-[#1ABE56]/30">
                                {inquiry.service}
                              </span>
                            </td>
                            <td className="px-6 py-4 max-w-xs truncate text-neutral-300">
                              {inquiry.message}
                            </td>
                            <td className="px-6 py-4 text-neutral-400 font-mono">
                              {inquiry.assignedTo ? inquiry.assignedTo.name : 'Unassigned'}
                            </td>
                            <td className="px-6 py-4">
                              <select
                                value={inquiry.status}
                                disabled={updatingId === inquiry.id}
                                onChange={(e) => handleStatusChange(inquiry.id, e.target.value)}
                                className={`px-3 py-1.5 rounded-lg text-xs font-semibold border bg-black focus:outline-none transition-colors cursor-pointer ${
                                  inquiry.status === 'RESOLVED'
                                    ? 'border-emerald-500/50 text-emerald-400 bg-emerald-500/10'
                                    : inquiry.status === 'IN_PROGRESS' || inquiry.status === 'CONTACTED'
                                    ? 'border-blue-500/50 text-blue-400 bg-blue-500/10'
                                    : 'border-yellow-500/50 text-yellow-400 bg-yellow-500/10'
                                }`}
                              >
                                <option value="PENDING">PENDING</option>
                                <option value="CONTACTED">CONTACTED</option>
                                <option value="IN_PROGRESS">IN PROGRESS</option>
                                <option value="RESOLVED">RESOLVED</option>
                              </select>
                            </td>
                            <td className="px-6 py-4 text-right">
                              <span className="text-[10px] text-neutral-500 font-mono">
                                {new Date(inquiry.createdAt).toLocaleDateString()}
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}

          {activeTab === 'users' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-white">System Users & Access Control</h2>
                  <p className="text-xs text-neutral-400 mt-1">Manage system administrators, engineers, and client portal users.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="glass-card p-6 rounded-2xl border border-emerald-500/30 bg-black/80 space-y-2">
                  <div className="flex items-center gap-3 text-emerald-400">
                    <Shield className="w-5 h-5" />
                    <h3 className="font-bold text-sm text-white">Administrator</h3>
                  </div>
                  <p className="text-xs text-neutral-400">admin@hkrion.com</p>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 inline-block">Role: ADMIN</span>
                </div>

                <div className="glass-card p-6 rounded-2xl border border-blue-500/30 bg-black/80 space-y-2">
                  <div className="flex items-center gap-3 text-blue-400">
                    <Briefcase className="w-5 h-5" />
                    <h3 className="font-bold text-sm text-white">Senior Engineer</h3>
                  </div>
                  <p className="text-xs text-neutral-400">employee@hkrion.com</p>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-blue-500/20 text-blue-400 border border-blue-500/30 inline-block">Role: EMPLOYEE</span>
                </div>

                <div className="glass-card p-6 rounded-2xl border border-purple-500/30 bg-black/80 space-y-2">
                  <div className="flex items-center gap-3 text-purple-400">
                    <UserCheck className="w-5 h-5" />
                    <h3 className="font-bold text-sm text-white">Valued Client</h3>
                  </div>
                  <p className="text-xs text-neutral-400">customer@hkrion.com</p>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-purple-500/20 text-purple-400 border border-purple-500/30 inline-block">Role: CUSTOMER</span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'services' && (
            <div className="glass-card p-8 rounded-2xl border border-[#1ABE56]/20 bg-black/80 space-y-4">
              <h2 className="text-xl font-bold text-white">HKRION Service Offerings Overview</h2>
              <p className="text-xs text-neutral-400">Manage available ERP, Cloud, AI, and Software Development service packages.</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-4">
                {['Enterprise ERP & Business Systems', 'Custom Web & Mobile Development', 'Cloud Infrastructure & DevOps', 'AI & Workflow Automation', 'MySQL & Database Solutions', 'Cybersecurity & Code Auditing'].map((svc, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 text-xs font-semibold text-[#1ABE56] flex items-center justify-between">
                    <span>{svc}</span>
                    <span className="text-[10px] font-mono text-neutral-500">Active</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="glass-card p-8 rounded-2xl border border-[#1ABE56]/20 bg-black/80 space-y-4">
              <h2 className="text-xl font-bold text-white">System Settings & MySQL Status</h2>
              <div className="space-y-3 text-xs">
                <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 flex justify-between items-center">
                  <span className="text-neutral-300">Database Engine:</span>
                  <span className="font-mono text-[#1ABE56]">MySQL 8.0 / Prisma ORM v5.22</span>
                </div>
                <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 flex justify-between items-center">
                  <span className="text-neutral-300">Database Connection:</span>
                  <span className="font-mono text-emerald-400">CONNECTED (127.0.0.1:3306)</span>
                </div>
                <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 flex justify-between items-center">
                  <span className="text-neutral-300">JWT Token Expiry:</span>
                  <span className="font-mono text-neutral-400">7 Days (HTTP-Only Secure Cookie)</span>
                </div>
              </div>
            </div>
          )}

        </main>
      </div>
    </div>
  );
}
