import { Module } from '@nestjs/common';
import { ProfitLossController } from './profit-loss.controller';
import { ProfitLossService } from './profit-loss.service';
import { PrismaModule } from '../../prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [ProfitLossController],
  providers: [ProfitLossService],
  exports: [ProfitLossService],
})
export class ProfitLossModule {}
