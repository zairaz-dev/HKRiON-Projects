"use strict";
"use client";

import React, { useEffect, useState, useMemo } from "react";
import { 
  Layers, 
  Cpu, 
  ShoppingBag, 
  Smartphone,
  Building2,
  CreditCard,
  BarChart3,
  Check, 
  Star, 
  ArrowRight, 
  Play, 
  Sparkles,
  ChevronDown,
  Globe,
  Loader2,
  ShieldCheck,
  Zap,
  Settings,
  Database,
  Mail,
  FileText,
  ChevronRight,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { authService } from "@/services/auth-service";
import { cmsService, PublicLandingContent } from "@/services/cms-service";
import { subscriptionService } from "@/services/subscription-service";
import { Plan } from "@/features/subscriptions/types";
import { User } from "@hkr/types";
import { ContactSalesDialog } from "@/components/contact-sales-dialog";
import { useUserCountry } from "@/hooks/use-user-country";

export default function Home() {
  const router = useRouter();
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [bootingModule, setBootingModule] = useState<string | null>(null);
  const [bootProgress, setBootProgress] = useState(0);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  const [cms, setCms] = useState<PublicLandingContent | null>(null);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [billingInterval, setBillingInterval] = useState<"monthly" | "yearly">("monthly");
  const [isLoading, setIsLoading] = useState(true);
  const [isContactSalesOpen, setIsContactSalesOpen] = useState(false);
  const { isSriLanka } = useUserCountry();
  const currency: "LKR" | "USD" = isSriLanka ? "LKR" : "USD";

  // Dynamically calculate savings percentage based on active plans
  const maxSavingsPercent = useMemo(() => {
    let maxPercent = 0;
    plans.forEach((plan) => {
      const monthly = currency === "USD" ? (plan.priceMonthlyUsd || 0) : plan.priceMonthly;
      const yearly = currency === "USD" ? (plan.priceYearlyUsd || 0) : plan.priceYearly;
      if (monthly > 0 && yearly > 0) {
        const fullYear = monthly * 12;
        if (fullYear > yearly) {
          const percent = Math.round(((fullYear - yearly) / fullYear) * 100);
          if (percent > maxPercent) {
            maxPercent = percent;
          }
        }
      }
    });
    return maxPercent > 0 ? maxPercent : 17;
  }, [plans, currency]);

  useEffect(() => {
    setCurrentUser(authService.getCurrentUser());
    loadAllPublicData();
  }, []);

  const loadAllPublicData = async () => {
    setIsLoading(true);
    try {
      const [cmsData, plansData] = await Promise.all([
        cmsService.getPublicContent().catch(() => null),
        subscriptionService.getPlans().catch(() => []),
      ]);

      if (cmsData) setCms(cmsData);
      if (plansData) {
        setPlans(plansData.filter((p) => p.isActive !== false));
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const triggerBootSequence = (moduleName: string, targetPath: string) => {
    if (bootingModule) return;
    setBootingModule(moduleName);
    setBootProgress(0);

    const steps = [15, 35, 55, 75, 90, 100];
    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        setBootProgress(steps[currentStep]);
        currentStep++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          setBootingModule(null);
          setBootProgress(0);
          router.push(targetPath);
        }, 300);
      }
    }, 150);
  };

  const statsList = (() => {
    try {
      return cms?.hero?.statsJson ? JSON.parse(cms.hero.statsJson) : [];
    } catch {
      return [];
    }
  })();

  const hero = cms?.hero;
  const features = cms?.features || [];
  const spotlights = cms?.spotlights || [];
  const faqs = cms?.faqs || [];
  const testimonials = cms?.testimonials || [];

  const [activeSpotlightKey, setActiveSpotlightKey] = useState<string>("pos");

  const currentSpotlight = spotlights.find((s) => s.tabKey === activeSpotlightKey) || spotlights[0] || {
    tabKey: "pos",
    tabLabel: "Point of Sale (POS)",
    title: "Lightning-Fast Touch & Barcode POS Billing",
    subtitle: "Serve retail customers in under 3 seconds. Connect thermal printers, barcode scanners, and accept all Sri Lankan payment gateways seamlessly.",
    badge: "RETAIL & STORE CHECKOUT",
    iconName: "ShoppingBag",
    imageUrl: "/images/pos-terminal.jpg",
    bulletPointsJson: JSON.stringify([
      { icon: "ShoppingBag", title: "Hardware Ready Out-of-the-Box", description: "Connect USB/Bluetooth barcode scanners, cash drawers, and 80mm/58mm thermal printers instantly." },
      { icon: "CreditCard", title: "Sri Lankan Payment Gateways", description: "Accept PayHere.lk QR codes, Visa, Mastercard, Genie, FriMi, eZ Cash, and Split Cash payments." },
      { icon: "Sparkles", title: "Offline Resilient & Draft Sales", description: "Never stop ringing sales during network drops with local queue sync." },
    ]),
    ctaText: "Start 14-Day Free Trial",
    ctaLink: "/register",
  };

  const getSpotlightBulletIcon = (iconName?: string) => {
    switch ((iconName || "").toLowerCase()) {
      case "shoppingbag": return <ShoppingBag className="w-4 h-4 text-primary shrink-0 mt-0.5" />;
      case "smartphone": return <Smartphone className="w-4 h-4 text-primary shrink-0 mt-0.5" />;
      case "building2": return <Building2 className="w-4 h-4 text-primary shrink-0 mt-0.5" />;
      case "layers": return <Layers className="w-4 h-4 text-primary shrink-0 mt-0.5" />;
      case "creditcard": return <CreditCard className="w-4 h-4 text-primary shrink-0 mt-0.5" />;
      case "barchart3": return <BarChart3 className="w-4 h-4 text-primary shrink-0 mt-0.5" />;
      case "shieldcheck": return <ShieldCheck className="w-4 h-4 text-primary shrink-0 mt-0.5" />;
      case "sparkles": return <Sparkles className="w-4 h-4 text-primary shrink-0 mt-0.5" />;
      default: return <Check className="w-4 h-4 text-primary shrink-0 mt-0.5" />;
    }
  };

  const spotlightBullets: Array<{ icon?: string; title: string; description: string }> = (() => {
    try {
      return currentSpotlight.bulletPointsJson ? JSON.parse(currentSpotlight.bulletPointsJson) : [];
    } catch {
      return [];
    }
  })();

  const getFeatureIcon = (feat: any, idx: number) => {
    const iconName = (feat.icon || "").toLowerCase();
    const title = (feat.title || "").toLowerCase();
    const category = (feat.category || "").toLowerCase();

    if (iconName.includes("pos") || iconName.includes("shopping") || title.includes("pos") || title.includes("billing") || category.includes("pos")) {
      return <ShoppingBag className="w-5 h-5" />;
    }
    if (iconName.includes("imei") || iconName.includes("phone") || title.includes("imei") || title.includes("serial") || category.includes("inventory")) {
      return <Smartphone className="w-5 h-5" />;
    }
    if (iconName.includes("branch") || iconName.includes("building") || title.includes("branch") || title.includes("warehouse") || category.includes("branch")) {
      return <Building2 className="w-5 h-5" />;
    }
    if (iconName.includes("account") || iconName.includes("ledger") || title.includes("accounting") || title.includes("ledger") || category.includes("finance")) {
      return <Layers className="w-5 h-5" />;
    }
    if (iconName.includes("tax") || iconName.includes("payhere") || iconName.includes("card") || title.includes("tax") || title.includes("payhere") || category.includes("payment")) {
      return <CreditCard className="w-5 h-5" />;
    }
    if (iconName.includes("analytic") || iconName.includes("report") || iconName.includes("chart") || title.includes("analytic") || title.includes("report")) {
      return <BarChart3 className="w-5 h-5" />;
    }

    switch (idx % 6) {
      case 0: return <ShoppingBag className="w-5 h-5" />;
      case 1: return <Smartphone className="w-5 h-5" />;
      case 2: return <Building2 className="w-5 h-5" />;
      case 3: return <Layers className="w-5 h-5" />;
      case 4: return <CreditCard className="w-5 h-5" />;
      case 5: return <BarChart3 className="w-5 h-5" />;
      default: return <ShoppingBag className="w-5 h-5" />;
    }
  };

  return (
    <main className="min-h-screen relative bg-transparent text-foreground font-sans">

      {/* Booting Module Screen Overlay */}
      {bootingModule && (
        <div className="fixed inset-0 bg-background/85 backdrop-blur-md z-50 flex flex-col items-center justify-center gap-6 animate-in fade-in duration-350">
          <div className="relative">
            <div className="w-20 h-20 rounded-sm bg-primary flex items-center justify-center shadow-[0_0_50px_rgba(var(--primary),0.3)] animate-pulse">
              <Cpu className="w-10 h-10 text-primary-foreground animate-spin" style={{ animationDuration: "6s" }} />
            </div>
            <div className="absolute -inset-1.5 rounded-sm bg-primary blur opacity-40 animate-ping" />
          </div>
          <div className="space-y-2 text-center">
            <h3 className="text-xl font-bold tracking-tight text-white">Mounting Workspace</h3>
            <p className="text-xs text-primary font-mono tracking-wider">LOADING {bootingModule.toUpperCase()} // {bootProgress}%</p>
          </div>
          <div className="w-64 h-1.5 bg-card rounded-sm overflow-hidden border border-border/80">
            <div className="h-full bg-primary transition-all duration-150" style={{ width: `${bootProgress}%` }} />
          </div>
        </div>
      )}

      <div className="relative z-10">
        {/* 🌟 HERO SECTION (MATCHING SCREENSHOT LAYOUT & STYLING) */}
        <section className="relative w-full max-w-7xl mx-auto px-6 sm:px-10 pt-20 sm:pt-24 pb-14">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-6 items-center min-h-[520px]">
            
            {/* Left Column: Heading, Subtitle & Action CTAs */}
            <div className="lg:col-span-6 text-left space-y-7 z-10">
              {/* Discount / Announcement Pill Badge */}
              <div>
                <Link href={hero?.announcementLink || "/pricing"}>
                  <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-emerald-500/30 dark:border-emerald-500/40 bg-emerald-50/80 dark:bg-emerald-950/40 backdrop-blur-md shadow-sm dark:shadow-[0_0_20px_rgba(16,185,129,0.2)] text-xs text-emerald-800 dark:text-emerald-300 hover:border-emerald-500/60 hover:bg-emerald-100/80 dark:hover:bg-emerald-900/50 transition-all cursor-pointer group">
                    <span className="font-semibold uppercase tracking-wider text-[10px] sm:text-[11px]">
                      {hero?.announcementText || "INTELLIGENT CLOUD ERP SUITE • MULTI-BRANCH READY"}
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 group-hover:translate-x-0.5 transition-transform" />
                  </div>
                </Link>
              </div>

              {/* Main Headline */}
              <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-[54px] font-extrabold tracking-[-0.03em] text-foreground leading-[1.1] font-sans">
                {hero?.heroTitle || "The Complete Intelligent ERP Platform Built For Growth"}
              </h1>

              {/* Subtitle */}
              <p className="text-sm sm:text-base text-muted-foreground max-w-lg leading-relaxed font-normal">
                {hero?.heroSubtitle || "Streamline multi-branch point of sale, inventory tracking with IMEI verification, customer accounting, and automated Sri Lankan tax invoicing in one ultra-fast system."}
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                {currentUser ? (
                  <Button 
                    onClick={() => triggerBootSequence("System Workspace", "/dashboard")}
                    className="bg-foreground text-background hover:bg-foreground/90 font-bold h-12 px-8 rounded-full shadow-lg transition-all text-sm gap-2"
                  >
                    <span>Go to Workspace</span>
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                ) : (
                  <Link href={hero?.primaryCtaLink || "/register"}>
                    <Button className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold h-12 px-8 rounded-full shadow-lg shadow-primary/25 transition-all text-sm gap-2">
                      <span>{hero?.primaryCtaText || "Start 14-Day Free Trial"}</span>
                      <ArrowRight className="w-4 h-4" />
                    </Button>
                  </Link>
                )}

                <a 
                  href={hero?.secondaryCtaLink || "#features"} 
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-border bg-card/80 hover:bg-muted text-sm font-semibold text-foreground shadow-sm transition-all group"
                >
                  <Play className="w-3.5 h-3.5 fill-current text-primary" />
                  <span>{hero?.secondaryCtaText || "Explore Features"}</span>
                </a>
              </div>
            </div>

            {/* Right Column: Connected AI Process Node Diagram */}
            <div className="lg:col-span-6 relative w-full flex items-center justify-center">
              <div className="relative w-[460px] h-[360px] shrink-0">
                {/* Radiant back glow */}
                <div className="absolute inset-0 bg-primary/10 blur-[90px] rounded-full pointer-events-none" />

                {/* Inner Dotted Matrix Layer for the Diagram */}
                <div className="absolute inset-0 bg-[radial-gradient(rgba(16,185,129,0.25)_1.5px,transparent_1.5px)] dark:bg-[radial-gradient(rgba(16,185,129,0.3)_1.5px,transparent_1.5px)] [background-size:18px_18px] [mask-image:radial-gradient(ellipse_75%_75%_at_60%_50%,#000_60%,transparent_100%)] opacity-90 pointer-events-none" />

                {/* SVG Circuit Connector Dashed Lines */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none z-0" viewBox="0 0 460 360" fill="none">
                  {/* Line 1: From left of "Live Cloud Sync..." -> goes left -> goes down into ERP card */}
                  <path
                    d="M 240 32 L 126 32 L 126 98"
                    stroke="rgba(16, 185, 129, 0.45)"
                    strokeWidth="1.5"
                    strokeDasharray="4 4"
                  />
                  {/* Line 2: From right of "Live Cloud Sync..." -> goes right -> wraps down -> left to 99.9% -> down into Sparkle card */}
                  <path
                    d="M 390 32 L 420 32 L 420 178 L 332 178 L 332 218"
                    stroke="rgba(16, 185, 129, 0.45)"
                    strokeWidth="1.5"
                    strokeDasharray="4 4"
                  />
                  {/* Line 3: From bottom of ERP card -> goes down -> turns right into File Document icon */}
                  <path
                    d="M 126 210 L 126 274 L 155 274"
                    stroke="rgba(16, 185, 129, 0.45)"
                    strokeWidth="1.5"
                    strokeDasharray="4 4"
                  />
                </svg>

                {/* Node 1: "Live Cloud Sync..." Pill (Top-Right) */}
                <div 
                  className="absolute z-10"
                  style={{ top: "14px", left: "240px" }}
                >
                  <div className="px-3.5 py-2 rounded-xl bg-card/95 border border-primary/40 backdrop-blur-xl shadow-lg flex items-center gap-2 hover:border-primary/70 transition-all duration-300">
                    <div className="w-5 h-5 rounded-full bg-primary/15 flex items-center justify-center">
                      <Settings className="w-3.5 h-3.5 text-primary animate-spin" style={{ animationDuration: "16s" }} />
                    </div>
                    <span className="text-xs font-semibold text-foreground tracking-wide">Live Cloud Sync...</span>
                  </div>
                </div>

                {/* Node 2: 3-Icon Pill (Globe, Database, POS) */}
                <div 
                  className="absolute z-10"
                  style={{ top: "68px", left: "240px" }}
                >
                  <div className="px-3.5 py-1.5 rounded-xl bg-card/95 border border-primary/40 backdrop-blur-xl shadow-lg flex items-center gap-3 hover:border-primary/70 transition-all duration-300">
                    <Globe className="w-4 h-4 text-primary hover:scale-110 transition-transform cursor-pointer" />
                    <Database className="w-4 h-4 text-primary hover:scale-110 transition-transform cursor-pointer" />
                    <ShoppingBag className="w-4 h-4 text-primary hover:scale-110 transition-transform cursor-pointer" />
                  </div>
                </div>

                {/* Node 3: Center Large "ERP" Glass Card */}
                <div 
                  className="absolute z-20"
                  style={{ top: "98px", left: "70px" }}
                >
                  <div className="w-[112px] h-[112px] rounded-3xl bg-card/95 border border-primary/50 backdrop-blur-2xl shadow-[0_12px_35px_rgba(16,185,129,0.2)] dark:shadow-[0_0_45px_rgba(16,185,129,0.4),inset_0_0_20px_rgba(16,185,129,0.25)] flex flex-col items-center justify-center group hover:scale-105 transition-all duration-300">
                    <span className="text-3xl font-extrabold text-primary tracking-tight drop-shadow-[0_0_12px_rgba(16,185,129,0.4)]">
                      ERP
                    </span>
                    <span className="text-[9px] font-mono uppercase tracking-widest text-primary/80 font-bold">
                      ENGINE
                    </span>
                  </div>
                </div>

                {/* Node 4: "99.9%" Uptime Circuit Badge */}
                <div 
                  className="absolute z-20"
                  style={{ top: "164px", left: "318px" }}
                >
                  <div className="w-8 h-8 rounded-full bg-card border border-primary/50 shadow-md flex items-center justify-center text-[9px] font-mono font-bold text-primary">
                    99.9%
                  </div>
                </div>

                {/* Node 5: Bottom-Left Document / Invoicing Icon */}
                <div 
                  className="absolute z-20"
                  style={{ top: "250px", left: "155px" }}
                >
                  <div className="w-12 h-12 rounded-2xl bg-card/95 border border-primary/50 backdrop-blur-xl shadow-lg flex items-center justify-center group hover:scale-110 transition-all duration-300">
                    <FileText className="w-5 h-5 text-primary fill-primary/20 drop-shadow-[0_0_10px_rgba(16,185,129,0.4)]" />
                  </div>
                </div>

                {/* Node 6: Bottom-Right Sparkle AI Star Glass Card */}
                <div 
                  className="absolute z-20"
                  style={{ top: "218px", left: "284px" }}
                >
                  <div className="w-[96px] h-[96px] rounded-3xl bg-card/95 border border-primary/50 backdrop-blur-2xl shadow-lg dark:shadow-[0_0_40px_rgba(16,185,129,0.4),inset_0_0_20px_rgba(16,185,129,0.25)] flex items-center justify-center group hover:scale-105 transition-all duration-300">
                    <svg className="w-9 h-9 text-primary drop-shadow-[0_0_14px_rgba(16,185,129,0.5)]" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M12 0L14.59 9.41L24 12L14.59 14.59L12 24L9.41 14.59L0 12L9.41 9.41L12 0Z" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Stats Bar */}
          {statsList.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto pt-10">
              {statsList.map((stat: any, idx: number) => (
                <div key={idx} className="bg-card/70 dark:bg-emerald-950/20 border border-border/80 dark:border-emerald-500/20 shadow-sm dark:shadow-none backdrop-blur-md rounded-sm p-4 text-center hover:border-emerald-500/40 transition duration-300">
                  <p className="text-2xl font-black text-foreground dark:text-white tracking-tight font-mono">{stat.value}</p>
                  <p className="text-[10px] text-muted-foreground dark:text-zinc-400 uppercase tracking-wider mt-1 font-mono">{stat.label}</p>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* 🌟 INTERACTIVE TABBED PRODUCT SHOWCASE (DATABASE-DRIVEN) */}
        <section className="w-full max-w-7xl mx-auto px-4 py-20 space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-[10px] font-mono uppercase font-bold text-primary tracking-widest">
              INTERACTIVE SUITE
            </span>
            <h2 className="text-2xl sm:text-4xl md:text-5xl font-bold tracking-tight text-foreground font-heading">
              Enterprise Modules in Action
            </h2>
            <p className="text-muted-foreground text-xs md:text-sm leading-relaxed">
              Explore how each core module powers your day-to-day point of sale, warehouse inventory, and business finance.
            </p>
          </div>

          {/* Interactive Navigation Tabs */}
          {spotlights.length > 0 && (
            <div className="flex items-center justify-center gap-2 overflow-x-auto pb-2">
              <div className="bg-card/70 backdrop-blur-md p-1.5 rounded-sm border border-border/80 inline-flex items-center gap-1.5 shadow-lg">
                {spotlights.map((spot) => {
                  const isActive = spot.tabKey === (currentSpotlight?.tabKey || activeSpotlightKey);
                  return (
                    <button
                      key={spot.tabKey || spot.id}
                      type="button"
                      onClick={() => setActiveSpotlightKey(spot.tabKey)}
                      className={`px-4 py-2 rounded-sm text-xs font-mono font-bold transition-all duration-300 flex items-center gap-2 ${
                        isActive
                          ? "bg-primary text-primary-foreground shadow-md shadow-primary/20 scale-[1.02]"
                          : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
                      }`}
                    >
                      {getFeatureIcon(spot, 0)}
                      <span>{spot.tabLabel}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Active Tab Spotlight Content */}
          <div className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-6 lg:p-10 shadow-2xl transition-all duration-500">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
              {/* Left: Showcase Mockup Image */}
              <div className="lg:col-span-7 relative group">
                <div className="relative rounded-sm p-1.5 bg-gradient-to-tr from-primary/30 via-border/80 to-card border border-primary/30 shadow-2xl shadow-primary/10 overflow-hidden">
                  <img
                    src={currentSpotlight.imageUrl || "/images/hero-dashboard.jpg"}
                    alt={currentSpotlight.title}
                    className="w-full h-auto rounded-sm object-cover group-hover:scale-[1.01] transition-transform duration-500"
                  />
                  {currentSpotlight.badge && (
                    <div className="absolute bottom-4 left-4 bg-background/90 backdrop-blur-md border border-border/80 px-3 py-1.5 rounded-sm shadow-lg text-[10px] font-mono text-primary font-bold flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 animate-pulse" /> {currentSpotlight.badge}
                    </div>
                  )}
                </div>
              </div>

              {/* Right: Module Details & Bullet Points */}
              <div className="lg:col-span-5 space-y-6">
                <div className="space-y-2">
                  {currentSpotlight.badge && (
                    <span className="text-[10px] font-mono uppercase font-bold text-primary tracking-widest block">
                      {currentSpotlight.badge}
                    </span>
                  )}
                  <h3 className="text-2xl sm:text-3xl font-bold tracking-tight text-foreground leading-snug font-heading">
                    {currentSpotlight.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
                    {currentSpotlight.subtitle}
                  </p>
                </div>

                {/* Bullet Points from Database JSON */}
                <div className="space-y-3">
                  {spotlightBullets.map((bullet, bIdx) => (
                    <div
                      key={bIdx}
                      className="flex items-start gap-3 p-3 rounded-sm bg-card/60 border border-border/60 hover:border-primary/40 transition duration-300"
                    >
                      {getSpotlightBulletIcon(bullet.icon)}
                      <div className="space-y-0.5 text-xs text-muted-foreground">
                        <strong className="text-foreground block font-mono text-[11px]">
                          {bullet.title}
                        </strong>
                        <span className="leading-relaxed">{bullet.description}</span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Module Action CTA */}
                <div className="pt-2">
                  <Link href={currentSpotlight.ctaLink || "/register"}>
                    <Button className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold h-10 px-6 rounded-sm shadow-md shadow-primary/20 transition duration-300 gap-2 text-xs">
                      {currentSpotlight.ctaText || "Start 14-Day Free Trial"} <ArrowRight className="w-4 h-4" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FEATURES SHOWCASE */}
        {features.length > 0 && (
          <section id="features" className="w-full max-w-7xl mx-auto px-4 py-16 space-y-12">
            <div className="text-center max-w-2xl mx-auto space-y-2">
              <span className="text-[10px] font-mono uppercase font-bold text-primary tracking-widest">
                POWERFUL ARCHITECTURE
              </span>
              <h2 className="text-2xl sm:text-4xl md:text-5xl font-bold tracking-tight text-foreground font-heading">
                Intelligent Core Modules
              </h2>
              <p className="text-muted-foreground text-xs md:text-sm leading-relaxed">
                Designed from the ground up for busy retailers, multi-branch outlets, and growing enterprises.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {features.map((feat, idx) => (
                <Card
                  key={feat.id || idx}
                  className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-6 flex flex-col justify-between hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 transition-all duration-300"
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="w-10 h-10 rounded-sm bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                        {getFeatureIcon(feat, idx)}
                      </div>
                      {feat.badge && (
                        <span className="text-[9px] font-mono font-extrabold bg-primary/15 text-primary px-2 py-0.5 rounded-sm border border-primary/20">
                          {feat.badge}
                        </span>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <h3 className="text-base font-bold text-foreground font-heading">{feat.title}</h3>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        {feat.description}
                      </p>
                    </div>
                  </div>

                  <div className="pt-4 mt-4 border-t border-border/40 flex items-center justify-between text-[11px] font-mono text-muted-foreground">
                    <span>{feat.category || "Core Feature"}</span>
                    <span className="text-primary font-bold">Active ✓</span>
                  </div>
                </Card>
              ))}
            </div>
          </section>
        )}

        {/* PRICING PLANS (DYNAMIC FROM DATABASE) */}
        <section id="pricing" className="w-full max-w-7xl mx-auto px-4 py-16 space-y-12">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-[10px] font-mono uppercase font-bold text-primary tracking-widest">
              TRANSPARENT BILLING
            </span>
            <h2 className="text-2xl sm:text-4xl md:text-5xl font-bold tracking-tight text-foreground font-heading">
              Simple, Scalable Plans
            </h2>
            <p className="text-muted-foreground text-xs md:text-sm leading-relaxed">
              {isSriLanka
                ? "Start with a 14-day free trial. Upgrade or cancel anytime with PayHere or Direct Bank Transfer."
                : "Start with a 14-day free trial. Upgrade or cancel anytime with secure international checkout."}
            </p>

            {/* Billing Interval Toggle (Centered) */}
            <div className="flex items-center justify-center pt-4">
              <div className="bg-card/60 p-1 rounded-sm border border-border inline-flex items-center shadow-sm">
                <button
                  type="button"
                  onClick={() => setBillingInterval("monthly")}
                  className={`px-4 py-1.5 rounded-sm text-xs font-mono font-bold transition-all ${
                    billingInterval === "monthly"
                      ? "bg-primary text-primary-foreground shadow"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  Monthly Billing
                </button>
                <button
                  type="button"
                  onClick={() => setBillingInterval("yearly")}
                  className={`px-4 py-1.5 rounded-sm text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                    billingInterval === "yearly"
                      ? "bg-primary text-primary-foreground shadow"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  Yearly Billing
                  <span
                    className={`text-[9px] px-1.5 py-0.5 rounded-sm font-mono font-extrabold border transition-colors ${
                      billingInterval === "yearly"
                        ? "bg-black/25 text-black border-black/30 shadow-sm"
                        : "bg-primary/20 text-primary border-primary/30"
                    }`}
                  >
                    SAVE {maxSavingsPercent}%
                  </span>
                </button>
              </div>
            </div>
          </div>

          {isLoading ? (
            <div className="p-12 text-center text-muted-foreground">
              <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-primary" />
              <p className="text-xs font-mono">Loading pricing plans...</p>
            </div>
          ) : plans.length === 0 ? (
            <div className="p-8 text-center text-xs text-muted-foreground border border-dashed border-border rounded-sm max-w-md mx-auto font-mono">
              No active subscription plans published yet.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 max-w-7xl mx-auto items-stretch">
              {plans.map((plan) => {
                const isPopular = plan.isPopular;
                const price = currency === "USD"
                  ? (billingInterval === "yearly"
                      ? (plan.priceYearlyUsd || (plan.priceMonthlyUsd || 0) * 10)
                      : (plan.priceMonthlyUsd || 0))
                  : (billingInterval === "yearly"
                      ? plan.priceYearly || plan.priceMonthly * 10
                      : plan.priceMonthly);
                const currencyPrefix = currency === "USD" ? "$" : "Rs.";

                return (
                  <Card
                    key={plan.id}
                    className={`bg-card/40 backdrop-blur-md rounded-sm p-5 sm:p-6 flex flex-col justify-between space-y-5 transition-all duration-300 ${
                      isPopular
                        ? "border-2 border-primary shadow-xl shadow-primary/10 relative lg:-translate-y-2 bg-card/60"
                        : "border border-border/70"
                    }`}
                  >
                    {isPopular && (
                      <div className="absolute top-0 right-6 -translate-y-1/2 bg-primary text-primary-foreground text-[9px] font-mono font-bold uppercase px-2.5 py-0.5 rounded-sm shadow">
                        POPULAR
                      </div>
                    )}

                    <div className="space-y-4">
                      <div>
                        <h3 className="text-base font-bold text-foreground font-heading">{plan.name}</h3>
                        <p className="text-xs text-muted-foreground mt-0.5 min-h-[32px] line-clamp-2">
                          {plan.description || "Comprehensive enterprise cloud features."}
                        </p>
                      </div>

                      {/* Price */}
                      <div className="pt-1">
                        {plan.slug === "enterprise" ? (
                          <div>
                            <div className="text-2xl sm:text-3xl font-extrabold font-mono text-foreground">
                              Custom
                            </div>
                            <p className="text-[10px] text-muted-foreground font-mono mt-0.5">
                              Tailored quote for your scale
                            </p>
                          </div>
                        ) : (
                          <div>
                            {currency === "USD" && !Number.isInteger(price) ? (
                              <div className="flex items-start font-mono tracking-tight">
                                <span className="text-4xl sm:text-5xl font-black text-foreground leading-none">
                                  {Math.floor(price)}
                                </span>
                                <div className="flex flex-col justify-between self-stretch ml-0.5 py-0.5 select-none font-mono">
                                  <span className="text-lg sm:text-xl font-black text-foreground leading-none">
                                    .{Number((price % 1).toFixed(2)).toFixed(2).split(".")[1]}
                                  </span>
                                  <span className="text-[10px] sm:text-[11px] font-bold text-muted-foreground leading-none mt-1">
                                    $/ {billingInterval === "yearly" ? "year" : "month"}
                                  </span>
                                </div>
                              </div>
                            ) : (
                              <div className="flex items-baseline gap-1 font-mono">
                                <span className="text-xs font-bold text-muted-foreground">
                                  {currencyPrefix}
                                </span>
                                <span className="text-2xl sm:text-3xl font-extrabold text-foreground">
                                  {price.toLocaleString(undefined, { minimumFractionDigits: currency === 'USD' && !Number.isInteger(price) ? 2 : 0, maximumFractionDigits: 2 })}
                                </span>
                                <span className="text-xs text-muted-foreground">
                                  /{billingInterval === "yearly" ? "year" : "mo"}
                                </span>
                              </div>
                            )}
                            {billingInterval === "yearly" && (
                              <p className="text-[10px] text-primary font-mono mt-0.5">
                                Billed annually (2 months free)
                              </p>
                            )}
                          </div>
                        )}
                      </div>

                      <ul className="space-y-2.5 text-xs text-muted-foreground">
                        <li className="flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-primary shrink-0" />
                          <span>
                            <strong>{plan.maxBranches <= 0 ? "Unlimited" : plan.maxBranches}</strong> Branches & Warehouses
                          </span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-primary shrink-0" />
                          <span>
                            <strong>{plan.maxUsers <= 0 ? "Unlimited" : plan.maxUsers}</strong> User Accounts
                          </span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-primary shrink-0" />
                          <span>
                            <strong>{plan.maxProducts <= 0 ? "Unlimited" : plan.maxProducts.toLocaleString()}</strong> Inventory SKUs
                          </span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-primary shrink-0" />
                          <span>
                            <strong>{plan.maxInvoicesMonthly <= 0 ? "Unlimited" : plan.maxInvoicesMonthly.toLocaleString()}</strong> Monthly Invoices
                          </span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-primary shrink-0" />
                          <span>IMEI & Barcode Tracking</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-primary shrink-0" />
                          <span>PayHere & Bank Slip Upload</span>
                        </li>
                      </ul>
                    </div>

                    <div className="w-full pt-2">
                      {plan.slug === "enterprise" ? (
                        <Button
                          type="button"
                          onClick={() => setIsContactSalesOpen(true)}
                          className="w-full text-xs font-bold h-9 rounded-sm border border-primary/40 bg-primary/10 hover:bg-primary text-foreground hover:text-primary-foreground shadow-sm flex items-center justify-center gap-1.5"
                        >
                          <span>Contact Sales</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </Button>
                      ) : (
                        <Link href={`/register?plan=${plan.id}`} className="w-full block">
                          <Button
                            className={`w-full text-xs font-bold h-9 rounded-sm ${
                              isPopular
                                ? "bg-primary hover:bg-primary/90 text-primary-foreground shadow-md shadow-primary/20"
                                : "border border-border bg-secondary/50 hover:bg-secondary text-foreground"
                            }`}
                          >
                            {plan.slug === "trial" ? "Get Started" : "Start a Free Trial"}
                          </Button>
                        </Link>
                      )}
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </section>

        {/* TESTIMONIALS */}
        {testimonials.length > 0 && (
          <section id="testimonials" className="w-full max-w-7xl mx-auto px-4 py-16 space-y-12">
            <div className="text-center max-w-2xl mx-auto space-y-2">
              <span className="text-[10px] font-mono uppercase font-bold text-primary tracking-widest">
                VERIFIED CUSTOMERS
              </span>
              <h2 className="text-2xl sm:text-4xl md:text-5xl font-bold tracking-tight text-foreground font-heading">
                Trusted by Businesses
              </h2>
              <p className="text-muted-foreground text-xs md:text-sm leading-relaxed">
                See how Sri Lankan retail operators scale their daily transactions with HKRION ERP.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {testimonials.map((t, idx) => (
                <Card
                  key={t.id || idx}
                  className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-6 flex flex-col justify-between space-y-4 hover:border-primary/40 transition-all duration-300"
                >
                  <div className="flex gap-1 text-amber-400">
                    {Array.from({ length: t.rating || 5 }).map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-current" />
                    ))}
                  </div>

                  <p className="text-xs text-foreground/90 leading-relaxed italic">
                    &quot;{t.content}&quot;
                  </p>

                  <div className="pt-3 border-t border-border/40 flex items-center gap-2.5">
                    {t.avatarUrl ? (
                      <img
                        src={t.avatarUrl}
                        alt={t.clientName}
                        className="w-8 h-8 rounded-full object-cover"
                      />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-primary/20 text-primary font-bold font-mono text-xs flex items-center justify-center">
                        {t.clientName.charAt(0)}
                      </div>
                    )}
                    <div>
                      <h4 className="text-xs font-bold text-foreground font-heading">{t.clientName}</h4>
                      <p className="text-[10px] text-muted-foreground">{t.businessName}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </section>
        )}

        {/* FAQS ACCORDION */}
        {faqs.length > 0 && (
          <section id="faqs" className="w-full max-w-4xl mx-auto px-4 py-16 space-y-8">
            <div className="text-center space-y-2">
              <span className="text-[10px] font-mono uppercase font-bold text-primary tracking-widest">
                GOT QUESTIONS?
              </span>
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight text-foreground font-heading">
                Frequently Asked Questions
              </h2>
            </div>

            <div className="space-y-3">
              {faqs.map((faq, idx) => {
                const isOpen = openFaqIndex === idx;
                return (
                  <div
                    key={faq.id || idx}
                    className="border border-border/70 bg-card/40 backdrop-blur-md rounded-sm overflow-hidden transition-colors"
                  >
                    <button
                      onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                      className="w-full p-4 text-left flex items-center justify-between text-xs md:text-sm font-bold text-foreground hover:text-primary transition-colors"
                    >
                      <span>{faq.question}</span>
                      <ChevronDown
                        className={`w-4 h-4 text-muted-foreground transition-transform duration-200 ${
                          isOpen ? "rotate-180 text-primary" : ""
                        }`}
                      />
                    </button>
                    {isOpen && (
                      <div className="px-4 pb-4 text-xs text-muted-foreground leading-relaxed animate-fadeIn">
                        {faq.answer}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        )}
      </div>

      <ContactSalesDialog
        isOpen={isContactSalesOpen}
        onClose={() => setIsContactSalesOpen(false)}
        defaultPlanName="Enterprise Plan"
      />
    </main>
  );
}
