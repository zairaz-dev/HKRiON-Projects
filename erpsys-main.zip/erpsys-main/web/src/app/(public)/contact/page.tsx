"use strict";
"use client";

import React, { useEffect, useState } from "react";
import {
  Mail,
  Phone,
  MapPin,
  Clock,
  Send,
  Loader2,
  CheckCircle2,
  AlertCircle,
  MessageSquare,
  MessageCircle,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cmsService } from "@/services/cms-service";

export default function ContactUsPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const [contactData, setContactData] = useState({
    badge: "Get In Touch",
    headline: "Contact Our Support Team",
    subtitle: "Have questions about HKRiON ERP? We're here to help. Send us a message and we will respond as soon as possible.",
    email: "support@hkrion.com",
    phone: "+94 11 234 5678",
    whatsapp: "+94 77 123 4567",
    address: "Level 14, World Trade Center, Echelon Square, Colombo 00100, Sri Lanka",
    workingHours: "Monday - Friday: 8:30 AM - 6:30 PM (IST)\n24/7 Emergency Hotline for Active Subscribers",
    whatsappLink: "https://wa.me/94771234567",
  });

  useEffect(() => {
    cmsService.getPageBySlug("contact")
      .then((page) => {
        if (page?.content) {
          try {
            const parsed = JSON.parse(page.content);
            if (parsed && typeof parsed === "object") {
              setContactData((prev) => ({ ...prev, ...parsed }));
            }
          } catch {
            // markdown content
          }
        }
      })
      .catch(() => {});
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess(false);

    if (!name || !email || !subject || !message) {
      setError("Please fill in all fields.");
      return;
    }

    setLoading(true);

    try {
      await new Promise((resolve) => setTimeout(resolve, 1500));
      setSuccess(true);
      setName("");
      setEmail("");
      setSubject("");
      setMessage("");
    } catch (err) {
      setError("Something went wrong. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-transparent text-foreground flex flex-col items-center justify-center p-4 sm:p-6 relative">
      <div className="w-full max-w-5xl mt-6 relative z-10 space-y-8 pb-16">
        {/* Header Section */}
        <div className="text-center space-y-2 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-sm bg-primary/10 border border-primary/20 text-primary text-[10px] font-bold tracking-wider uppercase font-mono">
            <MessageSquare className="w-3.5 h-3.5" /> {contactData.badge}
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-foreground tracking-tight">
            {contactData.headline}
          </h1>
          <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
            {contactData.subtitle}
          </p>
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Contact Info Panel (5 cols) */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            <Card className="bg-card/40 border-border/80 backdrop-blur-md flex-1 flex flex-col justify-between p-6 rounded-sm">
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-foreground tracking-wider uppercase font-mono">Direct Channels</h3>
                  <p className="text-[11px] text-muted-foreground mt-1">Reach our Sri Lanka support desk and billing team.</p>
                </div>

                <div className="space-y-4">
                  {/* Email */}
                  <div className="flex items-start gap-3 group">
                    <div className="p-2.5 rounded-sm bg-primary/10 text-primary border border-primary/20 group-hover:border-primary/40 transition-colors">
                      <Mail className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-[10px] font-semibold text-muted-foreground font-mono uppercase tracking-wider">Email Us</p>
                      <a href={`mailto:${contactData.email}`} className="text-xs text-foreground font-bold hover:text-primary transition-colors mt-0.5 block font-mono">
                        {contactData.email}
                      </a>
                    </div>
                  </div>

                  {/* Phone */}
                  <div className="flex items-start gap-3 group">
                    <div className="p-2.5 rounded-sm bg-primary/10 text-primary border border-primary/20 group-hover:border-primary/40 transition-colors">
                      <Phone className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-[10px] font-semibold text-muted-foreground font-mono uppercase tracking-wider">Direct Hotline</p>
                      <a href={`tel:${contactData.phone}`} className="text-xs text-foreground font-bold hover:text-primary transition-colors mt-0.5 block font-mono">
                        {contactData.phone}
                      </a>
                    </div>
                  </div>

                  {/* WhatsApp */}
                  {contactData.whatsapp && (
                    <div className="flex items-start gap-3 group">
                      <div className="p-2.5 rounded-sm bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 group-hover:border-emerald-500/40 transition-colors">
                        <MessageCircle className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-[10px] font-semibold text-muted-foreground font-mono uppercase tracking-wider">WhatsApp Support</p>
                        <a
                          href={contactData.whatsappLink || `https://wa.me/${contactData.whatsapp.replace(/[^0-9]/g, "")}`}
                          target="_blank"
                          rel="noreferrer"
                          className="text-xs text-emerald-400 font-bold hover:underline mt-0.5 block font-mono"
                        >
                          {contactData.whatsapp}
                        </a>
                      </div>
                    </div>
                  )}

                  {/* Location */}
                  <div className="flex items-start gap-3 group">
                    <div className="p-2.5 rounded-sm bg-primary/10 text-primary border border-primary/20 group-hover:border-primary/40 transition-colors">
                      <MapPin className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-[10px] font-semibold text-muted-foreground font-mono uppercase tracking-wider">Headquarters</p>
                      <p className="text-xs text-foreground font-medium mt-0.5 leading-relaxed">
                        {contactData.address}
                      </p>
                    </div>
                  </div>

                  {/* Hours */}
                  <div className="flex items-start gap-3 group">
                    <div className="p-2.5 rounded-sm bg-primary/10 text-primary border border-primary/20 group-hover:border-primary/40 transition-colors">
                      <Clock className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-[10px] font-semibold text-muted-foreground font-mono uppercase tracking-wider">Operating Hours</p>
                      <p className="text-xs text-muted-foreground mt-0.5 whitespace-pre-line leading-relaxed font-mono">
                        {contactData.workingHours}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Status footer pill */}
              <div className="pt-6 border-t border-border/60 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[11px] font-mono font-bold text-foreground">Support Online</span>
                </div>
                <span className="text-[10px] font-mono text-muted-foreground">Response &lt; 2 hrs</span>
              </div>
            </Card>
          </div>

          {/* Contact Form (7 cols) */}
          <div className="lg:col-span-7">
            <Card className="bg-card/40 border-border/80 backdrop-blur-md p-6 sm:p-8 rounded-sm">
              <div className="space-y-6">
                <div>
                  <h3 className="text-base font-bold text-foreground">Send Us a Direct Inquiry</h3>
                  <p className="text-xs text-muted-foreground mt-1">Our ERP specialists will reply to your registered email address.</p>
                </div>

                {success && (
                  <div className="p-4 rounded-sm bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs flex items-center gap-2 animate-fadeIn">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>Your message has been sent successfully! Our team will contact you shortly.</span>
                  </div>
                )}

                {error && (
                  <div className="p-4 rounded-sm bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-2 animate-fadeIn">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-muted-foreground font-mono">Your Full Name *</label>
                      <Input
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="John Doe"
                        className="h-10 text-xs bg-secondary/30 rounded-sm"
                        disabled={loading}
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-muted-foreground font-mono">Business Email *</label>
                      <Input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="john@company.com"
                        className="h-10 text-xs bg-secondary/30 rounded-sm"
                        disabled={loading}
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-muted-foreground font-mono">Inquiry Subject *</label>
                    <Input
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      placeholder="e.g. Enterprise Multi-Branch Demo / Quotation"
                      className="h-10 text-xs bg-secondary/30 rounded-sm"
                      disabled={loading}
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-muted-foreground font-mono">Message Details *</label>
                    <textarea
                      rows={5}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Describe your store requirements or question in detail..."
                      className="w-full p-3 text-xs rounded-sm bg-secondary/30 border border-border text-foreground focus:ring-1 focus:ring-primary outline-none"
                      disabled={loading}
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold h-11 text-xs rounded-sm shadow-md shadow-primary/20 flex items-center justify-center gap-2"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" /> Sending Message...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" /> Submit Inquiry
                      </>
                    )}
                  </Button>
                </form>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
