"use client";

import React from "react";
import { useCurrency } from "@/features/currency/context/CurrencyContext";

interface LuxuryPriceProps {
  amount: number;
  className?: string;
  symbolClassName?: string;
  valueClassName?: string;
  size?: "xs" | "sm" | "md" | "lg" | "xl" | "2xl" | "3xl" | "4xl";
  color?: "charcoal" | "gold" | "white" | "inherit";
  weight?: "normal" | "medium" | "semibold" | "bold" | "extrabold";
  showSymbol?: boolean;
  symbol?: string;
}

const SIZE_CLASSES = {
  xs: "text-xs",
  sm: "text-xs sm:text-sm",
  md: "text-sm sm:text-base",
  lg: "text-base sm:text-lg",
  xl: "text-xl sm:text-2xl",
  "2xl": "text-2xl sm:text-3xl",
  "3xl": "text-3xl sm:text-4xl lg:text-5xl",
  "4xl": "text-4xl sm:text-5xl lg:text-6xl",
};

const COLOR_CLASSES = {
  charcoal: "text-[#0D0D11]",
  gold: "text-[#C5A880]",
  white: "text-white",
  inherit: "",
};

const SYMBOL_COLOR_CLASSES = {
  charcoal: "text-[#9A7B4F]",
  gold: "text-[#E0CFA9]",
  white: "text-[#C5A880]",
  inherit: "opacity-80",
};

const WEIGHT_CLASSES = {
  normal: "font-normal",
  medium: "font-medium",
  semibold: "font-semibold",
  bold: "font-bold",
  extrabold: "font-extrabold",
};

export function LuxuryPrice({
  amount,
  className = "",
  symbolClassName = "",
  valueClassName = "",
  size = "md",
  color = "charcoal",
  weight = "semibold",
  showSymbol = true,
  symbol = "$",
}: LuxuryPriceProps) {
  const { convertPrice } = useCurrency();
  const converted = convertPrice(amount);
  const formattedNumber = converted.toLocaleString("en-US");

  return (
    <span
      className={`inline-flex items-baseline font-price tracking-tight ${SIZE_CLASSES[size]} ${COLOR_CLASSES[color]} ${WEIGHT_CLASSES[weight]} ${className}`}
    >
      {showSymbol && (
        <span
          className={`font-mono text-[0.85em] font-medium tracking-tight mr-0.5 select-none ${SYMBOL_COLOR_CLASSES[color]} ${symbolClassName}`}
        >
          {symbol}
        </span>
      )}
      <span
        className={`font-mono font-number ${WEIGHT_CLASSES[weight]} tracking-[-0.02em] tabular-nums ${valueClassName}`}
      >
        {formattedNumber}
      </span>
    </span>
  );
}
