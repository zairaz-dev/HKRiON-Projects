"use client";

import { useState, useEffect } from "react";
import { submitLeaveRequest, updateLeaveStatus } from "@/actions/leaves";
import { LeaveStatus } from "@prisma/client";
import { format } from "date-fns";
import { CalendarOff, Plus, Check, X, AlertTriangle, Search, Filter, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import Papa from "papaparse";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Modal } from "@/components/ui/modal";
import { PageHeader } from "@/components/ui/page-header";
import { Select } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { toast } from "sonner";

type LeaveRequest = {
  id: number;
  userId: number;
  startDate: Date;
  endDate: Date;
  reason: string | null;
  status: LeaveStatus;
  createdAt: Date;
  user: {
    firstName: string;
    lastName: string;
    email: string;
  };
};

type LeavesClientProps = {
  records: LeaveRequest[];
  currentUserId: number;
  isAdmin: boolean;
};

export default function LeavesClient({
  records,
  currentUserId,
  isAdmin,
}: LeavesClientProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [actionLoadingId, setActionLoadingId] = useState<number | null>(null);
  const [mounted, setMounted] = useState(false);

  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [sortBy, setSortBy] = useState("date-desc");

  useEffect(() => {
    setMounted(true);
  }, []);

  const filteredRecords = records
    .filter((record) => {
      const matchesSearch = `${record.user.firstName} ${record.user.lastName}`.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === "ALL" || record.status === statusFilter;
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      if (sortBy === "date-desc") return new Date(b.startDate).getTime() - new Date(a.startDate).getTime();
      if (sortBy === "date-asc") return new Date(a.startDate).getTime() - new Date(b.startDate).getTime();
      if (sortBy === "status") return a.status.localeCompare(b.status);
      return 0;
    });

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    const formData = new FormData(e.currentTarget);
    const res = await submitLeaveRequest(formData);

    if (res.error) {
      setError(res.error);
      toast.error(res.error);
    } else {
      setIsModalOpen(false);
      toast.success("Leave requested successfully!");
    }
    setIsLoading(false);
  };

  const handleUpdateStatus = async (id: number, newStatus: LeaveStatus) => {
    setActionLoadingId(id);
    setError(null);
    const res = await updateLeaveStatus(id, newStatus);
    if (res.error) {
      setError(res.error);
      toast.error(res.error);
    } else {
      toast.success(`Leave ${newStatus.toLowerCase()} successfully!`);
    }
    setActionLoadingId(null);
  };

  const formatDate = (date: Date) => {
    if (!mounted) return "";
    return format(new Date(date), 'MMM do, yyyy');
  };

  const handleExportCSV = () => {
    if (!filteredRecords.length) {
      toast.error("No records to export.");
      return;
    }

    const data = filteredRecords.map(record => ({
      EmployeeName: `${record.user.firstName} ${record.user.lastName}`,
      Email: record.user.email,
      StartDate: formatDate(record.startDate),
      EndDate: formatDate(record.endDate),
      Reason: record.reason || "",
      Status: record.status
    }));

    const csv = Papa.unparse(data);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `Leaves_Export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success("Leaves exported successfully!");
  };

  return (
    <div className="space-y-6">
      <PageHeader 
        title="Leaves"
        description="Review and manage employee leave requests."
        actions={
          <>
            <Button onClick={handleExportCSV} variant="outline" className="hidden sm:flex">
              <Download className="mr-2 h-4 w-4" />
              Export CSV
            </Button>
            <Button onClick={() => setIsModalOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Request Leave
            </Button>
          </>
        }
      />

      {error && !isModalOpen && (
        <div className="p-3 rounded-md bg-error-bg border border-error-border text-error text-sm flex items-start gap-2">
          <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-4 mb-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-text-secondary" />
          <Input
            type="text"
            placeholder="Search by employee name..."
            className="pl-9 bg-surface"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="w-36">
            <Select
              size="sm"
              value={statusFilter}
              onValueChange={setStatusFilter}
              options={[
                { value: "ALL", label: "All Statuses" },
                { value: "PENDING", label: "Pending" },
                { value: "APPROVED", label: "Approved" },
                { value: "REJECTED", label: "Rejected" },
              ]}
            />
          </div>
          <div className="w-44">
            <Select
              size="sm"
              value={sortBy}
              onValueChange={setSortBy}
              options={[
                { value: "date-desc", label: "Sort: Date (Newest)" },
                { value: "date-asc", label: "Sort: Date (Oldest)" },
                { value: "status", label: "Sort: Status" },
              ]}
            />
          </div>
        </div>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Employee</TableHead>
            <TableHead>Dates</TableHead>
            <TableHead className="hidden md:table-cell">Reason</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredRecords.length === 0 ? (
            <TableRow>
              <TableCell colSpan={5} className="h-32 text-center">
                <div className="flex flex-col items-center justify-center text-text-secondary">
                  <CalendarOff className="h-10 w-10 mb-3 text-border" />
                  <p className="font-medium text-text-primary">No leave requests</p>
                  <p className="text-sm mt-1">Try adjusting your search or filter.</p>
                </div>
              </TableCell>
            </TableRow>
          ) : (
            filteredRecords.map((record) => {
              const canAct = isAdmin || record.userId !== currentUserId;
              const isActionLoading = actionLoadingId === record.id;

              return (
                <TableRow key={record.id}>
                  <TableCell className="whitespace-nowrap">
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary-bg text-primary font-medium text-sm border border-primary/10">
                        {record.user.firstName.charAt(0)}{record.user.lastName.charAt(0)}
                      </div>
                      <div>
                        <div className="font-medium text-text-primary">{record.user.firstName} {record.user.lastName}</div>
                        <div className="text-xs text-text-secondary">{record.user.email}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="whitespace-nowrap">
                    <div className="text-text-primary">{formatDate(record.startDate)}</div>
                    <div className="text-xs text-text-secondary">to {formatDate(record.endDate)}</div>
                  </TableCell>
                  <TableCell className="hidden md:table-cell">
                    <p className="max-w-xs truncate text-text-secondary" title={record.reason || ""}>
                      {record.reason || "—"}
                    </p>
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant={
                        record.status === 'APPROVED' ? 'success' :
                        record.status === 'REJECTED' ? 'error' :
                        'warning'
                      }
                    >
                      {record.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    {canAct && record.status === 'PENDING' ? (
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleUpdateStatus(record.id, 'APPROVED')}
                          disabled={isActionLoading}
                          className="text-success hover:bg-success-bg hover:text-success h-8 w-8 cursor-pointer"
                          title="Approve"
                        >
                          <Check className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleUpdateStatus(record.id, 'REJECTED')}
                          disabled={isActionLoading}
                          className="text-error hover:bg-error-bg hover:text-error h-8 w-8 cursor-pointer"
                          title="Reject"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ) : (
                      <span className="text-text-disabled text-xs">—</span>
                    )}
                  </TableCell>
                </TableRow>
              );
            })
          )}
        </TableBody>
      </Table>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Request Leave"
      >
        {error && (
          <div className="mb-5 p-3 rounded-md bg-error-bg border border-error-border text-error text-sm flex items-start gap-2">
            <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-text-primary">Start Date <span className="text-error">*</span></label>
              <Input
                type="date"
                name="startDate"
                required
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-text-primary">End Date <span className="text-error">*</span></label>
              <Input
                type="date"
                name="endDate"
                required
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-sm font-medium text-text-primary">Reason <span className="text-error">*</span></label>
            <textarea
              name="reason"
              required
              rows={4}
              className="flex w-full rounded-md border border-border bg-surface px-3 py-2 text-sm text-text-primary placeholder:text-text-secondary focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary resize-none"
              placeholder="Briefly describe the reason for your leave request..."
            ></textarea>
          </div>

          <div className="pt-6 flex gap-3 justify-end border-t border-border mt-6">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setIsModalOpen(false);
                setError(null);
              }}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isLoading}
              className="min-w-[80px]"
            >
              {isLoading ? "Submitting..." : "Submit"}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
