'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import DashboardSidebar from '@/components/DashboardSidebar';
import {
  ShieldCheck,
  Shield,
  Plus,
  RefreshCw,
  Search,
  Edit2,
  Trash2,
  Users,
  Key,
  CheckCircle,
  AlertCircle,
  X,
  Lock,
  Sparkles,
  Info
} from 'lucide-react';

interface Permission {
  id: string;
  name: string;
  description: string | null;
}

interface Role {
  id: string;
  name: string;
  description: string | null;
  isSystem: boolean;
  userCount: number;
  permissions: Permission[];
  createdAt?: string;
}

export default function RoleManagementPage() {
  const router = useRouter();
  const [roles, setRoles] = useState<Role[]>([]);
  const [allPermissions, setAllPermissions] = useState<Permission[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<'ALL' | 'SYSTEM' | 'CUSTOM'>('ALL');

  // Modal States
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRole, setEditingRole] = useState<Role | null>(null);
  const [roleName, setRoleName] = useState('');
  const [roleDescription, setRoleDescription] = useState('');
  const [selectedPermissionIds, setSelectedPermissionIds] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Delete Confirmation Modal
  const [deletingRole, setDeletingRole] = useState<Role | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  // Notification Toast
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      // Fetch Roles
      const rolesRes = await fetch('/api/admin/roles');
      if (rolesRes.status === 401 || rolesRes.status === 403) {
        router.push('/login');
        return;
      }
      const rolesData = await rolesRes.json();
      if (rolesData.roles) {
        setRoles(rolesData.roles);
      }

      // Fetch Permissions
      const permsRes = await fetch('/api/admin/permissions');
      const permsData = await permsRes.json();
      if (permsData.permissions) {
        setAllPermissions(permsData.permissions);
      }
    } catch (err) {
      console.error('Error fetching roles/permissions:', err);
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleOpenCreateModal = () => {
    setEditingRole(null);
    setRoleName('');
    setRoleDescription('');
    setSelectedPermissionIds([]);
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (role: Role) => {
    setEditingRole(role);
    setRoleName(role.name);
    setRoleDescription(role.description || '');
    setSelectedPermissionIds(role.permissions.map((p) => p.id));
    setFormError(null);
    setIsModalOpen(true);
  };

  const togglePermission = (permId: string) => {
    setSelectedPermissionIds((prev) =>
      prev.includes(permId) ? prev.filter((id) => id !== permId) : [...prev, permId]
    );
  };

  const handleSelectAllPermissions = () => {
    if (selectedPermissionIds.length === allPermissions.length) {
      setSelectedPermissionIds([]);
    } else {
      setSelectedPermissionIds(allPermissions.map((p) => p.id));
    }
  };

  const handleSaveRole = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!roleName.trim()) {
      setFormError('Role Name is required');
      return;
    }

    setSubmitting(true);
    try {
      const isEdit = !!editingRole;
      const url = '/api/admin/roles';
      const method = isEdit ? 'PUT' : 'POST';
      const body = isEdit
        ? { id: editingRole.id, name: roleName, description: roleDescription, permissionIds: selectedPermissionIds }
        : { name: roleName, description: roleDescription, permissionIds: selectedPermissionIds };

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await res.json();

      if (!res.ok || data.error) {
        setFormError(data.error || 'Failed to save role');
        return;
      }

      setIsModalOpen(false);
      showToast(isEdit ? 'Role successfully updated!' : 'New Role successfully created!');
      fetchData();
    } catch (err) {
      setFormError('An error occurred while saving the role.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteRole = async () => {
    if (!deletingRole) return;
    setSubmitting(true);
    setDeleteError(null);

    try {
      const res = await fetch(`/api/admin/roles?id=${deletingRole.id}`, {
        method: 'DELETE',
      });
      const data = await res.json();

      if (!res.ok || data.error) {
        setDeleteError(data.error || 'Failed to delete role');
        return;
      }

      setDeletingRole(null);
      showToast('Role deleted successfully');
      fetchData();
    } catch (err) {
      setDeleteError('Failed to delete role.');
    } finally {
      setSubmitting(false);
    }
  };

  const filteredRoles = roles.filter((role) => {
    const matchesSearch =
      role.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (role.description && role.description.toLowerCase().includes(searchTerm.toLowerCase())) ||
      role.permissions.some((p) => p.name.toLowerCase().includes(searchTerm.toLowerCase()));

    if (roleFilter === 'SYSTEM') return matchesSearch && role.isSystem;
    if (roleFilter === 'CUSTOM') return matchesSearch && !role.isSystem;
    return matchesSearch;
  });

  const totalRolesCount = roles.length;
  const systemRolesCount = roles.filter((r) => r.isSystem).length;
  const customRolesCount = roles.filter((r) => !r.isSystem).length;
  const totalAssignedUsers = roles.reduce((sum, r) => sum + r.userCount, 0);

  return (
    <div className="min-h-screen bg-black text-white radial-bg flex">
      {/* Sidebar */}
      <DashboardSidebar
        userRole="ADMIN"
        userName="HKRION Admin"
        userEmail="admin@hkrion.com"
        activeTab="roles"
      />

      {/* Main Content */}
      <div className="flex-1 lg:ml-64 flex flex-col min-w-0 min-h-screen">
        {/* Toast Notification */}
        {toastMessage && (
          <div
            className={`fixed top-5 right-5 z-50 px-4 py-3 rounded-xl border flex items-center gap-3 shadow-2xl backdrop-blur-md animate-fade-in ${
              toastMessage.type === 'success'
                ? 'bg-emerald-950/90 border-emerald-500/50 text-emerald-300'
                : 'bg-red-950/90 border-red-500/50 text-red-300'
            }`}
          >
            {toastMessage.type === 'success' ? (
              <CheckCircle className="w-5 h-5 text-emerald-400" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-400" />
            )}
            <span className="text-xs font-semibold">{toastMessage.text}</span>
          </div>
        )}

        {/* Top Navbar Header */}
        <header className="border-b border-[#1ABE56]/20 bg-black/80 backdrop-blur-md sticky top-0 z-30 px-6 py-4 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold font-mono tracking-wide text-white flex items-center gap-2">
              <ShieldCheck className="w-6 h-6 text-[#1ABE56]" />
              Role & <span className="text-[#1ABE56]">Access Management</span>
            </h1>
            <p className="text-xs text-neutral-400">
              Configure system roles, assign permissions, and restrict access scopes
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={fetchData}
              className="px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-[#1ABE56]/40 text-neutral-300 hover:text-white text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-[#1ABE56]' : ''}`} />
              Refresh
            </button>

            <button
              onClick={handleOpenCreateModal}
              className="glow-btn px-4 py-2.5 rounded-xl text-xs font-semibold text-white flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create New Role</span>
            </button>
          </div>
        </header>

        {/* Dashboard Body */}
        <main className="p-6 sm:p-8 space-y-8 flex-1">
          {/* Key Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="glass-card p-5 rounded-2xl border border-[#1ABE56]/30 bg-black/80 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-[#1ABE56]/20 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-6 h-6 text-[#1ABE56]" />
              </div>
              <div>
                <p className="text-xs font-mono uppercase text-neutral-400">Total Configured Roles</p>
                <h3 className="text-2xl font-bold text-white">{totalRolesCount}</h3>
              </div>
            </div>

            <div className="glass-card p-5 rounded-2xl border border-blue-500/30 bg-black/80 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center shrink-0">
                <Lock className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <p className="text-xs font-mono uppercase text-neutral-400">Core System Roles</p>
                <h3 className="text-2xl font-bold text-white">{systemRolesCount}</h3>
              </div>
            </div>

            <div className="glass-card p-5 rounded-2xl border border-purple-500/30 bg-black/80 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center shrink-0">
                <Sparkles className="w-6 h-6 text-purple-400" />
              </div>
              <div>
                <p className="text-xs font-mono uppercase text-neutral-400">Custom User Roles</p>
                <h3 className="text-2xl font-bold text-white">{customRolesCount}</h3>
              </div>
            </div>

            <div className="glass-card p-5 rounded-2xl border border-emerald-500/30 bg-black/80 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center shrink-0">
                <Users className="w-6 h-6 text-emerald-400" />
              </div>
              <div>
                <p className="text-xs font-mono uppercase text-neutral-400">Assigned Account Members</p>
                <h3 className="text-2xl font-bold text-white">{totalAssignedUsers}</h3>
              </div>
            </div>
          </div>

          {/* Search, Filters & Stats bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  placeholder="Search by role name or permission..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-500 focus:outline-none focus:border-[#1ABE56] text-xs transition-colors"
                />
              </div>

              {/* Filter Tabs */}
              <div className="flex items-center p-1 rounded-xl bg-neutral-900 border border-neutral-800 text-xs">
                <button
                  onClick={() => setRoleFilter('ALL')}
                  className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                    roleFilter === 'ALL'
                      ? 'bg-[#1ABE56]/20 text-[#1ABE56] font-semibold border border-[#1ABE56]/40'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  All ({roles.length})
                </button>
                <button
                  onClick={() => setRoleFilter('SYSTEM')}
                  className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                    roleFilter === 'SYSTEM'
                      ? 'bg-blue-500/20 text-blue-400 font-semibold border border-blue-500/40'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  System ({systemRolesCount})
                </button>
                <button
                  onClick={() => setRoleFilter('CUSTOM')}
                  className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                    roleFilter === 'CUSTOM'
                      ? 'bg-purple-500/20 text-purple-400 font-semibold border border-purple-500/40'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  Custom ({customRolesCount})
                </button>
              </div>
            </div>

            <div className="text-xs text-neutral-400 font-mono">
              Showing {filteredRoles.length} of {roles.length} Roles
            </div>
          </div>

          {/* Roles Cards Grid */}
          {filteredRoles.length === 0 ? (
            <div className="glass-card p-12 text-center rounded-2xl border border-neutral-800 bg-black/80 space-y-3">
              <Shield className="w-12 h-12 text-neutral-600 mx-auto" />
              <h3 className="text-base font-semibold text-neutral-300">No Roles Found</h3>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                No matching role records found for &quot;{searchTerm}&quot;. Try adjusting your search query or create a new role.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredRoles.map((role) => (
                <div
                  key={role.id}
                  className={`glass-card p-6 rounded-2xl border transition-all duration-300 bg-black/90 flex flex-col justify-between space-y-5 hover:shadow-xl hover:shadow-[#1ABE56]/10 ${
                    role.isSystem
                      ? 'border-neutral-800 hover:border-blue-500/40'
                      : 'border-[#1ABE56]/30 hover:border-[#1ABE56]/60'
                  }`}
                >
                  <div className="space-y-4">
                    {/* Header */}
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-2.5">
                          <h3 className="text-lg font-bold text-white font-mono tracking-wide">
                            {role.name}
                          </h3>
                          {role.isSystem ? (
                            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-semibold bg-blue-500/20 text-blue-400 border border-blue-500/30 flex items-center gap-1">
                              <Lock className="w-3 h-3" /> System Role
                            </span>
                          ) : (
                            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-semibold bg-[#1ABE56]/20 text-[#1ABE56] border border-[#1ABE56]/30 flex items-center gap-1">
                              <Sparkles className="w-3 h-3" /> Custom Role
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-neutral-400 mt-2 line-clamp-2 leading-relaxed">
                          {role.description || 'No description provided for this role.'}
                        </p>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          onClick={() => handleOpenEditModal(role)}
                          className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white transition-colors cursor-pointer"
                          title="Edit Role & Permissions"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        {!role.isSystem && (
                          <button
                            onClick={() => {
                              setDeletingRole(role);
                              setDeleteError(null);
                            }}
                            className="p-2 rounded-xl bg-neutral-900 hover:bg-red-950/60 border border-neutral-800 hover:border-red-500/40 text-neutral-400 hover:text-red-400 transition-colors cursor-pointer"
                            title="Delete Role"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Member Count & Stats */}
                    <div className="flex items-center gap-4 py-2 border-y border-neutral-900 text-xs">
                      <div className="flex items-center gap-1.5 text-neutral-300">
                        <Users className="w-4 h-4 text-[#1ABE56]" />
                        <span className="font-bold text-white">{role.userCount}</span> Active Members
                      </div>
                      <div className="flex items-center gap-1.5 text-neutral-400 font-mono">
                        <Key className="w-3.5 h-3.5 text-neutral-500" />
                        <span>{role.permissions.length} Permissions</span>
                      </div>
                    </div>

                    {/* Permissions Badges */}
                    <div className="space-y-2">
                      <p className="text-[11px] font-mono text-neutral-500 uppercase tracking-wider">
                        Assigned Module Permissions:
                      </p>
                      {role.permissions.length === 0 ? (
                        <p className="text-xs text-neutral-500 italic">No permissions assigned.</p>
                      ) : (
                        <div className="flex flex-wrap gap-1.5">
                          {role.permissions.map((perm) => (
                            <span
                              key={perm.id}
                              className="px-2.5 py-1 rounded-lg text-[11px] font-mono bg-neutral-900/90 text-neutral-300 border border-neutral-800 hover:border-[#1ABE56]/40 transition-colors"
                              title={perm.description || perm.name}
                            >
                              <span className="text-[#1ABE56] mr-1">✓</span>
                              {perm.name}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </main>
      </div>

      {/* CREATE / EDIT ROLE MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="bg-neutral-950 border border-[#1ABE56]/40 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl space-y-0">
            {/* Modal Header */}
            <div className="p-6 border-b border-neutral-900 flex items-center justify-between bg-black/40">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#1ABE56]/20 border border-[#1ABE56]/40 flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5 text-[#1ABE56]" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white font-mono">
                    {editingRole ? `Edit Role: ${editingRole.name}` : 'Create New System Role'}
                  </h3>
                  <p className="text-xs text-neutral-400">
                    Define role identifier and toggle module access permissions
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-2 rounded-xl text-neutral-400 hover:text-white bg-neutral-900 border border-neutral-800 hover:border-neutral-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body / Form */}
            <form onSubmit={handleSaveRole} className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
              {formError && (
                <div className="p-4 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 text-xs flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 shrink-0 text-red-400" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Role Name */}
              <div className="space-y-2">
                <label className="text-xs font-mono text-neutral-300 uppercase font-semibold">
                  Role Name / Identifier <span className="text-[#1ABE56]">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. PROJECT_MANAGER, SUPPORT_ENGINEER"
                  value={roleName}
                  disabled={editingRole?.isSystem}
                  onChange={(e) => setRoleName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-500 focus:outline-none focus:border-[#1ABE56] text-xs font-mono disabled:opacity-60"
                />
                {editingRole?.isSystem && (
                  <p className="text-[11px] text-yellow-500/90 flex items-center gap-1 mt-1">
                    <Info className="w-3.5 h-3.5" />
                    System Role names cannot be renamed to maintain API integrity.
                  </p>
                )}
              </div>

              {/* Description */}
              <div className="space-y-2">
                <label className="text-xs font-mono text-neutral-300 uppercase font-semibold">
                  Role Description
                </label>
                <textarea
                  rows={2}
                  placeholder="Describe the responsibility and scope of this role..."
                  value={roleDescription}
                  onChange={(e) => setRoleDescription(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-500 focus:outline-none focus:border-[#1ABE56] text-xs"
                />
              </div>

              {/* Permissions Header & Bulk Selection */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-mono text-neutral-300 uppercase font-semibold flex items-center gap-2">
                    <Key className="w-4 h-4 text-[#1ABE56]" />
                    Assign System Permissions ({selectedPermissionIds.length} Selected)
                  </label>
                  <button
                    type="button"
                    onClick={handleSelectAllPermissions}
                    className="text-[11px] text-[#1ABE56] hover:underline font-mono cursor-pointer"
                  >
                    {selectedPermissionIds.length === allPermissions.length ? 'Deselect All' : 'Select All'}
                  </button>
                </div>

                {/* Permissions Checkbox Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  {allPermissions.map((perm) => {
                    const isChecked = selectedPermissionIds.includes(perm.id);
                    return (
                      <div
                        key={perm.id}
                        onClick={() => togglePermission(perm.id)}
                        className={`p-3.5 rounded-xl border cursor-pointer transition-all duration-200 flex items-start gap-3 ${
                          isChecked
                            ? 'bg-[#1ABE56]/10 border-[#1ABE56]/50 shadow-md shadow-[#1ABE56]/5'
                            : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}} // handled by parent onClick
                          className="mt-0.5 accent-[#1ABE56] h-4 w-4 rounded cursor-pointer"
                        />
                        <div className="space-y-0.5 min-w-0">
                          <p className="text-xs font-mono font-semibold text-white truncate">
                            {perm.name}
                          </p>
                          <p className="text-[11px] text-neutral-400 leading-tight">
                            {perm.description || 'Access permission module'}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Form Action Footer */}
              <div className="pt-4 border-t border-neutral-900 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-neutral-300 text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="glow-btn px-6 py-2.5 rounded-xl text-xs font-semibold text-white flex items-center gap-2 cursor-pointer disabled:opacity-60"
                >
                  {submitting && <RefreshCw className="w-4 h-4 animate-spin" />}
                  <span>{editingRole ? 'Save Changes' : 'Create Role'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {deletingRole && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="bg-neutral-950 border border-red-500/40 rounded-2xl w-full max-w-md p-6 space-y-6 shadow-2xl">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-red-950/80 border border-red-500/40 flex items-center justify-center shrink-0">
                <AlertCircle className="w-6 h-6 text-red-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-mono">
                  Delete Role &quot;{deletingRole.name}&quot;?
                </h3>
                <p className="text-xs text-neutral-400 mt-1">
                  This action is permanent and will remove permission definitions.
                </p>
              </div>
            </div>

            {deleteError && (
              <div className="p-3 rounded-xl bg-red-950/80 border border-red-500/50 text-red-300 text-xs">
                {deleteError}
              </div>
            )}

            {deletingRole.userCount > 0 && (
              <div className="p-3 rounded-xl bg-yellow-950/60 border border-yellow-500/40 text-yellow-300 text-xs flex items-center gap-2">
                <Info className="w-4 h-4 shrink-0 text-yellow-400" />
                <span>
                  Warning: There are {deletingRole.userCount} active users assigned to this role. You must reassign users first.
                </span>
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setDeletingRole(null)}
                className="px-4 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteRole}
                disabled={submitting}
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-semibold flex items-center gap-2 cursor-pointer disabled:opacity-60"
              >
                {submitting && <RefreshCw className="w-4 h-4 animate-spin" />}
                <span>Confirm Delete</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
