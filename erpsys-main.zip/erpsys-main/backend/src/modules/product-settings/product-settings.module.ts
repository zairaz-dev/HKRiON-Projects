import { Module } from '@nestjs/common';
import { ProductSettingsController } from './product-settings.controller';
import { ProductSettingsService } from './product-settings.service';
import { PrismaModule } from '../prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [ProductSettingsController],
  providers: [ProductSettingsService],
  exports: [ProductSettingsService],
})
export class ProductSettingsModule {}
