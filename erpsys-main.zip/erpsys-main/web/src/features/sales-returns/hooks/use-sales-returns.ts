import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { salesReturnService } from "@/services/sales-return-service";
import { queryKeys } from "@/lib/query-keys";

export function useSalesReturnsQuery(
  businessId: string,
  filters: {
    branchId?: string;
    customerId?: string;
    search?: string;
    page?: number;
    limit?: number;
  },
) {
  return useQuery({
    queryKey: queryKeys.salesReturns.list(
      businessId,
      filters.branchId,
      filters.customerId,
      filters.search,
      filters.page,
      filters.limit,
    ),
    queryFn: () => salesReturnService.getSalesReturns(businessId, filters),
    enabled: !!businessId,
  });
}

export function useCreateSalesReturnMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: Parameters<typeof salesReturnService.createSalesReturn>[0]) =>
      salesReturnService.createSalesReturn(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.salesReturns.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.pos.all });
    },
  });
}

export function useSalesReturnDetailQuery(id: string, businessId: string) {
  return useQuery({
    queryKey: queryKeys.salesReturns.detail(id),
    queryFn: () => salesReturnService.getSalesReturnById(id, businessId),
    enabled: !!id && !!businessId,
  });
}
