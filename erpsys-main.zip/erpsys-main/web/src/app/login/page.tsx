"use strict";
"use client";

import React, { useState, useEffect } from "react";
import { Layers, Lock, Mail, Eye, EyeOff, Loader2, ArrowLeft, Github } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import Link from "next/link";
import { authService } from "@/services/auth-service";
import { PageContainer } from "@/components/ui/page-container";
import { useGoogleLogin } from "@react-oauth/google";

const isGoogleEnabled = process.env.NEXT_PUBLIC_ENABLE_GOOGLE_LOGIN !== 'false' && !!process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID;

function GoogleLoginBtn({ onSuccess, onError, disabled }: { onSuccess: (token: string) => void; onError: (errMsg?: string) => void; disabled: boolean }) {
  const loginWithGoogle = useGoogleLogin({
    onSuccess: async (tokenResponse) => {
      onSuccess(tokenResponse.access_token);
    },
    onError: () => {
      onError("Google Sign-In failed. Please try again.");
    }
  });

  return (
    <Button 
      type="button" 
      variant="outline" 
      onClick={() => loginWithGoogle()}
      disabled={disabled}
      className="border-border hover:bg-accent text-xs gap-2 h-9 text-foreground bg-card/40"
    >
      <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
        <path fill="#ea4335" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
        <path fill="#fbbc05" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
        <path fill="#4285f4" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
        <path fill="#34a853" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
      </svg>
      Google
    </Button>
  );
}

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const [isElectron, setIsElectron] = useState(false);

  const handleGoogleSuccess = async (accessToken: string) => {
    setIsLoading(true);
    setError("");
    try {
      const data = await authService.loginWithGoogle(accessToken);
      if (data.isNewUser) {
        window.location.href = `/register?google_token=${encodeURIComponent(accessToken)}&email=${encodeURIComponent(data.email)}&name=${encodeURIComponent(data.name)}`;
        return;
      }
      if ((data.user.role as string) === "super-admin") {
        window.location.href = "/super";
      } else {
        window.location.href = "/dashboard";
      }
    } catch (err: any) {
      setError(err.message || "Google Login failed. Account may not be registered.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (authService.isAuthenticated()) {
      window.location.href = "/dashboard";
    }
    // Detect if running inside Electron
    if (typeof window !== "undefined" && window.navigator.userAgent.toLowerCase().includes("electron")) {
      setIsElectron(true);
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!email || !password) {
      setError("Please fill in all fields.");
      return;
    }

    setIsLoading(true);

    try {
      const data = await authService.login(email, password);
      if ((data.user.role as string) === "super-admin") {
        window.location.href = "/super";
      } else {
        window.location.href = "/dashboard";
      }
    } catch (err: any) {
      setError(err.message || "Invalid email or password. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <PageContainer size="sm" className="items-center justify-center min-h-[calc(100vh-4rem)]">
      {/* Login Card */}
      <div className="relative z-10 w-full max-w-md">
        <Card className="glass border-border shadow-2xl relative">
          {/* Back to Home Icon Button */}
          {!isElectron && (
            <div className="absolute top-4 left-4">
              <Link href="/">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="w-8 h-8 rounded-lg text-muted-foreground hover:bg-accent hover:text-foreground transition-all duration-200"
                  aria-label="Back to Home"
                >
                  <ArrowLeft className="w-4 h-4" />
                </Button>
              </Link>
            </div>
          )}

          <CardHeader className="space-y-2 text-center pt-8">
            <div className="mx-auto w-12 h-12 flex items-center justify-center mb-2">
              <img src="/logo.png" alt="HKRiON ERP Logo" className="w-full h-full object-contain" />
            </div>
            <CardTitle className="text-2xl font-bold tracking-tight text-foreground">
              Welcome Back
            </CardTitle>
            <CardDescription className="text-muted-foreground text-sm">
              Enter your credentials to access your ERP dashboard
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Error Message */}
              {error && (
                <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-xs text-red-400 font-medium text-center animate-shake">
                  {error}
                </div>
              )}

              {/* Email Field */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground font-mono uppercase tracking-wider">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/60" />
                  <Input 
                    type="email" 
                    placeholder="name@company.com" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10"
                    disabled={isLoading}
                  />
                </div>
              </div>

              {/* Password Field */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-muted-foreground font-mono uppercase tracking-wider">
                    Password
                  </label>
                  <a href="#" className="text-xs text-primary hover:underline">
                    Forgot password?
                  </a>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/60" />
                  <Input 
                    type={showPassword ? "text" : "password"} 
                    placeholder="••••••••" 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 pr-10"
                    disabled={isLoading}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground focus:outline-none"
                    disabled={isLoading}
                  >
                    {showPassword ? (
                       <EyeOff className="w-4 h-4" />
                    ) : (
                       <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              {/* Remember Me Checkbox */}
              <div className="flex items-center space-x-2 py-1">
                <Checkbox 
                  id="remember" 
                />
                <label 
                  htmlFor="remember" 
                  className="text-xs text-muted-foreground cursor-pointer select-none"
                >
                  Remember this device for 30 days
                </label>
              </div>

              {/* Submit Button */}
              <Button 
                type="submit" 
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium h-10 mt-2 shadow-lg shadow-primary/20 transition duration-300"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Signing In...
                  </>
                ) : (
                  "Sign In"
                )}
              </Button>

            </form>

            {/* Social Login Divider */}
            <div className="flex items-center my-5">
              <div className="flex-1 border-t border-border" />
              <span className="px-3 text-[10px] uppercase font-mono text-muted-foreground/60 tracking-wider">
                Or continue with
              </span>
              <div className="flex-1 border-t border-border" />
            </div>

            {/* Social Login Buttons */}
            <div className={isGoogleEnabled ? "grid grid-cols-2 gap-3" : "grid grid-cols-1 gap-3"}>
              {isGoogleEnabled && (
                <GoogleLoginBtn 
                  onSuccess={handleGoogleSuccess} 
                  onError={(err) => setError(err || "Google Sign-In failed.")} 
                  disabled={isLoading} 
                />
              )}
              <Button 
                type="button" 
                variant="outline" 
                disabled={isLoading}
                className="border-border hover:bg-accent text-xs gap-2 h-9 text-foreground bg-card/40"
              >
                <Github className="w-3.5 h-3.5 text-foreground" />
                GitHub
              </Button>
            </div>
          </CardContent>

          <CardFooter className="flex flex-col space-y-4 border-t border-border pt-4 pb-6">
            <p className="text-xs text-muted-foreground text-center">
              Don't have an account?{" "}
              <Link href="/register" className="text-primary hover:underline font-medium">
                Create an account
              </Link>
            </p>
          </CardFooter>
        </Card>
      </div>
    </PageContainer>
  );
}
