"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export interface ModalProps extends React.HTMLAttributes<HTMLDivElement> {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  description?: string;
  size?: "sm" | "md" | "lg" | "xl" | "2xl" | "full";
  showCloseButton?: boolean;
}

const sizeClasses = {
  sm: "max-w-sm",
  md: "max-w-md",
  lg: "max-w-lg",
  xl: "max-w-xl",
  "2xl": "max-w-2xl",
  full: "max-w-[95vw] md:max-w-4xl",
};

export function Modal({ 
  isOpen, 
  onClose, 
  title, 
  description, 
  size = "md",
  showCloseButton = true,
  className, 
  children, 
  ...props 
}: ModalProps) {
  // Handle ESC key press
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        onClose();
      }
    };
    if (isOpen) {
      document.body.style.overflow = "hidden";
      window.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      document.body.style.overflow = "unset";
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [isOpen, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
          {/* Backdrop overlay */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
            onClick={onClose}
          />

          {/* Modal Container */}
          <motion.div 
            initial={{ scale: 0.96, opacity: 0, y: 8 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.96, opacity: 0, y: 8 }}
            transition={{ type: "spring", bounce: 0.15, duration: 0.25 }}
            className={cn(
              "relative w-full flex flex-col rounded-2xl bg-surface border border-border text-text-primary shadow-2xl max-h-[calc(100dvh-1.5rem)] sm:max-h-[calc(100dvh-3rem)] overflow-hidden z-10 my-auto",
              sizeClasses[size],
              className
            )}
            {...props as any}
          >
            {/* Header (Sticky, always visible) */}
            {(title || description || showCloseButton) && (
              <div className="shrink-0 border-b border-border px-5 py-4 sm:px-6 flex items-center justify-between bg-surface/95 backdrop-blur-xs gap-3 z-10">
                <div className="min-w-0 flex-1">
                  {title && (
                    <h2 className="text-base sm:text-lg font-bold text-text-primary truncate">
                      {title}
                    </h2>
                  )}
                  {description && (
                    <p className="text-xs sm:text-sm text-text-secondary mt-0.5 leading-relaxed">
                      {description}
                    </p>
                  )}
                </div>

                {showCloseButton && (
                  <button 
                    type="button"
                    onClick={onClose}
                    className="shrink-0 text-text-muted hover:text-text-primary hover:bg-surface-secondary p-1.5 rounded-xl transition-colors cursor-pointer"
                    aria-label="Close dialog"
                  >
                    <X className="h-4.5 w-4.5" />
                  </button>
                )}
              </div>
            )}

            {/* Scrollable Modal Content */}
            <div className="flex-1 overflow-y-auto p-5 sm:p-6 custom-scrollbar">
              {children}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
