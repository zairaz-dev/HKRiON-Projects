export const CreateBranchBodySchema = {
  type: 'object',
  properties: {
    name: { type: 'string', example: 'HKRION London Branch' },
    address: { type: 'string', example: '123 Baker Street' },
    phone: { type: 'string', example: '+447890123456' },
    email: { type: 'string', example: 'london@hkrion.com' },
    businessId: { type: 'string', example: 'business-uuid-123' },
    createdById: { type: 'string', example: 'user-uuid-123' }
  },
  required: ['name', 'businessId']
};

export const UpdateBranchBodySchema = {
  type: 'object',
  properties: {
    name: { type: 'string', example: 'HKRION London Head Office' },
    address: { type: 'string', example: '123 Baker Street, London' },
    phone: { type: 'string', example: '+447890123456' },
    email: { type: 'string', example: 'london.office@hkrion.com' },
    isActive: { type: 'boolean', example: true },
    businessId: { type: 'string', example: 'business-uuid-123' },
    updatedById: { type: 'string', example: 'user-uuid-123' }
  },
  required: ['businessId']
};

export const AssignUserBranchBodySchema = {
  type: 'object',
  properties: {
    userId: { type: 'string', example: 'user-uuid-abc' },
    branchId: { type: 'string', example: 'branch-uuid-123' },
    businessId: { type: 'string', example: 'business-uuid-123' }
  },
  required: ['userId', 'branchId', 'businessId']
};

export const BranchResponseSchema = {
  type: 'object',
  properties: {
    id: { type: 'string', example: 'branch-uuid-123' },
    name: { type: 'string', example: 'HKRION London Branch' },
    address: { type: 'string', example: '123 Baker Street' },
    phone: { type: 'string', example: '+447890123456' },
    email: { type: 'string', example: 'london@hkrion.com' },
    isActive: { type: 'boolean', example: true },
    businessId: { type: 'string', example: 'business-uuid-123' }
  }
};
