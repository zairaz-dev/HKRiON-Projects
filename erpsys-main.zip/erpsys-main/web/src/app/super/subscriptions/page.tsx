"use strict";
"use client";

import React, { useEffect, useState, useMemo } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { authService } from "@/services/auth-service";
import { LoadingSession } from "@/components/ui/loading-session";
import { User } from "@hkr/types";
import {
  useSuperSubscriptionsQuery,
  usePlansQuery,
  useUpdateSubscriptionStatusMutation,
  SuperSubscriptionItem,
  Plan,
  BankTransferRequestItem,
  SaasBankSetting,
} from "@/features/subscriptions";
import { PlanDialog, PlanDeleteDialog } from "@/features/plans";
import { subscriptionService } from "@/services/subscription-service";
import { getFullAssetUrl } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Globe,
  Layers,
  Sparkles,
  Search,
  Plus,
  Edit2,
  Trash2,
  Clock,
  ShieldCheck,
  AlertCircle,
  Building2,
  DollarSign,
  Users,
  CheckCircle,
  X,
  Loader2,
  Landmark,
  FileImage,
  ExternalLink,
  Check,
  Lock,
  Ban,
  Save,
} from "lucide-react";

export default function SuperSubscriptionsPage() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  const [activeTab, setActiveTab] = useState<
    "subscriptions" | "bank_requests" | "plans"
  >("subscriptions");
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  // Plan modal state
  const [isPlanModalOpen, setIsPlanModalOpen] = useState(false);
  const [selectedPlanForEdit, setSelectedPlanForEdit] = useState<Plan | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedPlanForDelete, setSelectedPlanForDelete] = useState<Plan | null>(null);

  // Subscription Status Edit modal state
  const [statusEditSub, setStatusEditSub] = useState<SuperSubscriptionItem | null>(null);
  const [newStatus, setNewStatus] = useState<string>("ACTIVE");
  const [newEndDate, setNewEndDate] = useState<string>("");
  const [newPlanId, setNewPlanId] = useState<string>("");

  // Bank Transfer Requests State
  const [bankRequests, setBankRequests] = useState<BankTransferRequestItem[]>([]);
  const [isBankRequestsLoading, setIsBankRequestsLoading] = useState(false);
  const [selectedSlipUrl, setSelectedSlipUrl] = useState<string | null>(null);
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);
  const [rejectModalItem, setRejectModalItem] = useState<BankTransferRequestItem | null>(null);
  const [rejectReason, setRejectReason] = useState("");
  const [isCustomPlanMode, setIsCustomPlanMode] = useState(false);

  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 1500);
    }
  }, []);

  const {
    data: subscriptions = [],
    isLoading: isSubsLoading,
    refetch: refetchSubs,
  } = useSuperSubscriptionsQuery();

  const {
    data: plans = [],
    isLoading: isPlansLoading,
    refetch: refetchPlans,
  } = usePlansQuery(true);

  const updateStatusMutation = useUpdateSubscriptionStatusMutation();

  // Eligible plans for the tenant being edited in the status modal (must be at top level before early returns)
  const availablePlansForSub = useMemo(() => {
    if (!statusEditSub) return [];

    return plans.filter((p) => {
      // 1. Generic placeholder Enterprise plan (slug: enterprise) is a quote template, never an assignable standard plan!
      if (p.slug === "enterprise" || (p.name?.toLowerCase().includes("enterprise") && !p.isCustom)) {
        return false;
      }

      // 2. Custom plan only shows if it specifically belongs to this tenant
      if (p.isCustom) {
        return p.businessId === statusEditSub.businessId;
      }

      // 3. Standard public self-serve plans (Free Trial, Pro, Business)
      return true;
    });
  }, [plans, statusEditSub]);

  const loadBankRequests = async () => {
    setIsBankRequestsLoading(true);
    try {
      const data = await subscriptionService.getBankTransferRequests();
      setBankRequests(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsBankRequestsLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === "bank_requests") {
      loadBankRequests();
    }
  }, [activeTab]);

  const handleApproveBankTransfer = async (id: string) => {
    setActionLoadingId(id);
    try {
      await subscriptionService.approveBankTransfer(id);
      await loadBankRequests();
      refetchSubs();
    } catch (err: any) {
      alert(err.message || "Failed to approve bank transfer");
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleRejectBankTransfer = async () => {
    if (!rejectModalItem) return;
    setActionLoadingId(rejectModalItem.id);
    try {
      await subscriptionService.rejectBankTransfer(rejectModalItem.id, rejectReason);
      setRejectModalItem(null);
      setRejectReason("");
      await loadBankRequests();
      refetchSubs();
    } catch (err: any) {
      alert(err.message || "Failed to reject bank transfer");
    } finally {
      setActionLoadingId(null);
    }
  };

  if (isAuthenticated === null || (isAuthenticated && !currentUser)) {
    return <LoadingSession />;
  }

  if (currentUser?.role !== "super-admin") {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4 text-center">
        <h2 className="text-xl font-bold text-foreground">Access Restricted</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Super Admin privileges are required to access this portal.
        </p>
      </div>
    );
  }

  // Filter subscriptions
  const filteredSubscriptions = subscriptions.filter((sub) => {
    const matchesSearch =
      sub.businessName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sub.ownerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sub.ownerEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sub.planName.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus =
      statusFilter === "all" || sub.status.toLowerCase() === statusFilter.toLowerCase();

    return matchesSearch && matchesStatus;
  });

  // Filter bank requests
  const filteredBankRequests = bankRequests.filter((req) => {
    const matchesSearch =
      req.businessName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      req.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (req.transactionId && req.transactionId.toLowerCase().includes(searchQuery.toLowerCase())) ||
      req.planName.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus =
      statusFilter === "all" || req.paymentStatus.toLowerCase() === statusFilter.toLowerCase();

    return matchesSearch && matchesStatus;
  });

  const pendingBankRequestsCount = bankRequests.filter(
    (r) => r.paymentStatus === "PENDING"
  ).length;

  const totalTenants = subscriptions.length;
  const activeTenants = subscriptions.filter((s) => s.status === "ACTIVE").length;
  const trialTenants = subscriptions.filter((s) => s.status === "TRIAL").length;
  const expiredTenants = subscriptions.filter((s) => s.status === "EXPIRED").length;


  const handleOpenStatusEdit = (sub: SuperSubscriptionItem) => {
    setStatusEditSub(sub);
    setNewStatus(sub.status);
    setNewEndDate(sub.endDate ? new Date(sub.endDate).toISOString().split("T")[0] : "");

    // Determine eligible plans for this tenant (generic enterprise is never an assignable standard plan)
    const finalPlans = plans.filter((p) => {
      if (p.slug === "enterprise" || (p.name?.toLowerCase().includes("enterprise") && !p.isCustom)) {
        return false;
      }
      if (p.isCustom) {
        return p.businessId === sub.businessId;
      }
      return true;
    });

    const currentPlanMatch = finalPlans.find((p) => p.name === sub.planName || p.id === (sub as any).planId);
    const customPlan = finalPlans.find((p) => p.isCustom);
    setNewPlanId(currentPlanMatch?.id || customPlan?.id || finalPlans[0]?.id || "");
  };

  const handleSaveStatusEdit = async () => {
    if (!statusEditSub) return;
    try {
      await updateStatusMutation.mutateAsync({
        id: statusEditSub.id,
        data: {
          status: newStatus as any,
          endDate: newEndDate || undefined,
          planId: newPlanId || undefined,
        },
      });
      setStatusEditSub(null);
    } catch (err: any) {
      alert(err.message || "Failed to update subscription");
    }
  };

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/super/subscriptions" />

      <div className="flex-1 flex flex-col overflow-hidden relative">
        <Navbar title="SaaS Subscriptions & Plans" className="relative z-10" />

        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 relative z-10">
          {/* Header & Overview Stats */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-black tracking-tight font-mono text-foreground flex items-center gap-2">
                <Globe className="w-6 h-6 text-primary" /> SaaS Subscription Management
              </h1>
              <p className="text-xs text-muted-foreground mt-0.5">
                Oversee tenant subscription health, verify bank transfers, manage pricing tiers, and override limits.
              </p>
            </div>
            {activeTab === "plans" && (
              <Button
                onClick={() => {
                  setSelectedPlanForEdit(null);
                  setIsPlanModalOpen(true);
                }}
                className="text-xs h-9 font-bold shadow-lg shadow-primary/20 flex items-center gap-1.5 rounded-sm"
              >
                <Plus className="w-4 h-4" /> Create New SaaS Plan
              </Button>
            )}
          </div>

          {/* Quick Metrics Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="bg-card/40 backdrop-blur-md border-border/50">
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-[11px] font-mono uppercase text-muted-foreground font-bold">
                    Total Tenants
                  </p>
                  <p className="text-2xl font-black text-foreground font-mono mt-1">
                    {totalTenants}
                  </p>
                </div>
                <Building2 className="w-7 h-7 text-primary/60" />
              </CardContent>
            </Card>

            <Card className="bg-card/40 backdrop-blur-md border-border/50">
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-[11px] font-mono uppercase text-muted-foreground font-bold">
                    Active Subscriptions
                  </p>
                  <p className="text-2xl font-black text-emerald-400 font-mono mt-1">
                    {activeTenants}
                  </p>
                </div>
                <ShieldCheck className="w-7 h-7 text-emerald-400/60" />
              </CardContent>
            </Card>

            <Card className="bg-card/40 backdrop-blur-md border-border/50">
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-[11px] font-mono uppercase text-muted-foreground font-bold">
                    Free Trials
                  </p>
                  <p className="text-2xl font-black text-amber-400 font-mono mt-1">
                    {trialTenants}
                  </p>
                </div>
                <Clock className="w-7 h-7 text-amber-400/60" />
              </CardContent>
            </Card>

            <Card className="bg-card/40 backdrop-blur-md border-border/50">
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-[11px] font-mono uppercase text-muted-foreground font-bold">
                    Pending Bank Approvals
                  </p>
                  <p className="text-2xl font-black text-primary font-mono mt-1">
                    {pendingBankRequestsCount}
                  </p>
                </div>
                <Landmark className="w-7 h-7 text-primary/60" />
              </CardContent>
            </Card>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-2 border-b border-border pb-1 overflow-x-auto">
            <button
              onClick={() => setActiveTab("subscriptions")}
              className={`px-4 py-2 text-xs font-bold font-mono transition-all rounded-t-sm flex items-center gap-2 ${
                activeTab === "subscriptions"
                  ? "border-b-2 border-primary text-primary bg-primary/10"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Users className="w-4 h-4" /> Tenant Subscriptions ({subscriptions.length})
            </button>

            <button
              onClick={() => setActiveTab("bank_requests")}
              className={`px-4 py-2 text-xs font-bold font-mono transition-all rounded-t-sm flex items-center gap-2 relative ${
                activeTab === "bank_requests"
                  ? "border-b-2 border-primary text-primary bg-primary/10"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Landmark className="w-4 h-4" /> Bank Transfer Requests
              {pendingBankRequestsCount > 0 && (
                <span className="bg-primary text-primary-foreground text-[10px] font-extrabold px-1.5 py-0.2 rounded-sm">
                  {pendingBankRequestsCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab("plans")}
              className={`px-4 py-2 text-xs font-bold font-mono transition-all rounded-t-sm flex items-center gap-2 ${
                activeTab === "plans"
                  ? "border-b-2 border-primary text-primary bg-primary/10"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Layers className="w-4 h-4" /> SaaS Pricing Plans ({plans.length})
            </button>
          </div>

          {/* TAB 1: TENANT SUBSCRIPTIONS */}
          {activeTab === "subscriptions" && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
                <div className="relative w-full sm:w-80">
                  <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search tenant or plan..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9 h-9 text-xs"
                  />
                </div>
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="h-9 px-3 text-xs rounded-sm bg-secondary/50 border border-border text-foreground font-mono"
                  >
                    <option value="all">All Statuses</option>
                    <option value="ACTIVE">Active</option>
                    <option value="TRIAL">Trial</option>
                    <option value="EXPIRED">Expired</option>
                    <option value="CANCELLED">Cancelled</option>
                  </select>
                </div>
              </div>

              <Card className="bg-card/40 backdrop-blur-md border-border/60 overflow-hidden shadow-sm">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-border bg-background/50 text-[10px] font-mono uppercase text-muted-foreground">
                        <th className="p-4 font-bold">Business / Owner</th>
                        <th className="p-4 font-bold">Current Plan</th>
                        <th className="p-4 font-bold">Billing Cycle</th>
                        <th className="p-4 font-bold">Status</th>
                        <th className="p-4 font-bold">Expiry / Renewal</th>
                        <th className="p-4 font-bold text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border/50 font-medium">
                      {isSubsLoading ? (
                        <tr>
                          <td colSpan={6} className="p-8 text-center text-muted-foreground">
                            <Loader2 className="w-5 h-5 animate-spin mx-auto mb-2" /> Loading subscriptions...
                          </td>
                        </tr>
                      ) : filteredSubscriptions.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="p-8 text-center text-muted-foreground">
                            No subscription records found matching your filters.
                          </td>
                        </tr>
                      ) : (
                        filteredSubscriptions.map((sub) => {
                          const isActive = sub.status === "ACTIVE";
                          const isTrial = sub.status === "TRIAL";
                          const isExpired = sub.status === "EXPIRED";

                          return (
                            <tr key={sub.id} className="hover:bg-accent/30 transition-colors">
                              <td className="p-4">
                                <div className="font-bold text-foreground">{sub.businessName}</div>
                                <div className="text-muted-foreground text-[11px]">
                                  {sub.ownerName} ({sub.ownerEmail})
                                </div>
                              </td>
                              <td className="p-4 font-mono font-semibold text-foreground">
                                <span className="bg-secondary px-2 py-0.5 rounded-sm text-xs">
                                  {sub.planName}
                                </span>
                              </td>
                              <td className="p-4 font-mono text-muted-foreground">
                                {sub.billingInterval}
                              </td>
                              <td className="p-4">
                                <span
                                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-sm text-[10px] font-semibold font-mono ${
                                    isActive
                                      ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                                      : isTrial
                                      ? "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                                      : isExpired
                                      ? "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                                      : "bg-secondary text-muted-foreground"
                                  }`}
                                >
                                  {isActive ? (
                                    <CheckCircle className="w-3 h-3" />
                                  ) : isTrial ? (
                                    <Clock className="w-3 h-3" />
                                  ) : (
                                    <AlertCircle className="w-3 h-3" />
                                  )}
                                  {sub.status}
                                </span>
                              </td>
                              <td className="p-4 font-mono text-muted-foreground text-[11px]">
                                {new Date(sub.endDate).toLocaleDateString("en-US", {
                                  year: "numeric",
                                  month: "short",
                                  day: "numeric",
                                })}
                              </td>
                              <td className="p-4 text-right">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleOpenStatusEdit(sub)}
                                  className="h-7 text-[11px] px-2.5 flex items-center gap-1 ml-auto"
                                >
                                  <Edit2 className="w-3 h-3" /> Manage
                                </Button>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </Card>
            </div>
          )}

          {/* TAB 2: BANK TRANSFER REQUESTS */}
          {activeTab === "bank_requests" && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
                <div className="relative w-full sm:w-80">
                  <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search invoice #, ref # or tenant..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9 h-9 text-xs"
                  />
                </div>
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="h-9 px-3 text-xs rounded-sm bg-secondary/50 border border-border text-foreground font-mono"
                  >
                    <option value="all">All Request Statuses</option>
                    <option value="PENDING">Pending Verification</option>
                    <option value="PAID">Approved (Paid)</option>
                    <option value="FAILED">Rejected / Failed</option>
                  </select>
                </div>
              </div>

              <Card className="bg-card/40 backdrop-blur-md border-border/60 overflow-hidden shadow-sm">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-border bg-background/50 text-[10px] font-mono uppercase text-muted-foreground">
                        <th className="p-4 font-bold">Invoice #</th>
                        <th className="p-4 font-bold">Business</th>
                        <th className="p-4 font-bold">Plan & Interval</th>
                        <th className="p-4 font-bold">Total (LKR)</th>
                        <th className="p-4 font-bold">Deposit Slip</th>
                        <th className="p-4 font-bold">Ref / UTR #</th>
                        <th className="p-4 font-bold">Status</th>
                        <th className="p-4 font-bold text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border/50 font-medium">
                      {isBankRequestsLoading ? (
                        <tr>
                          <td colSpan={8} className="p-8 text-center text-muted-foreground">
                            <Loader2 className="w-5 h-5 animate-spin mx-auto mb-2" /> Loading bank transfer requests...
                          </td>
                        </tr>
                      ) : filteredBankRequests.length === 0 ? (
                        <tr>
                          <td colSpan={8} className="p-8 text-center text-muted-foreground">
                            No bank transfer requests found.
                          </td>
                        </tr>
                      ) : (
                        filteredBankRequests.map((req) => {
                          const isPending = req.paymentStatus === "PENDING";
                          const isPaid = req.paymentStatus === "PAID";
                          const isFailed = req.paymentStatus === "FAILED";

                          return (
                            <tr key={req.id} className="hover:bg-accent/30 transition-colors">
                              <td className="p-4 font-mono font-bold text-foreground">
                                {req.invoiceNumber}
                              </td>
                              <td className="p-4">
                                <div className="font-bold text-foreground">{req.businessName}</div>
                                <div className="text-muted-foreground text-[11px]">
                                  {req.businessEmail} | {req.businessPhone}
                                </div>
                              </td>
                              <td className="p-4">
                                <div className="font-bold text-foreground">{req.planName}</div>
                                <div className="text-[10px] font-mono text-muted-foreground">
                                  {req.billingInterval}
                                </div>
                              </td>
                              <td className="p-4 font-mono font-bold text-foreground">
                                Rs. {req.totalAmount.toLocaleString()}
                              </td>
                              <td className="p-4">
                                {req.proofUrl ? (
                                  <button
                                    type="button"
                                    onClick={() => setSelectedSlipUrl(req.proofUrl || null)}
                                    className="inline-flex items-center gap-1.5 text-xs text-primary font-bold hover:underline bg-primary/10 px-2 py-1 rounded-sm"
                                  >
                                    <FileImage className="w-3.5 h-3.5" /> View Slip
                                  </button>
                                ) : (
                                  <span className="text-muted-foreground text-[11px] italic">
                                    No Slip
                                  </span>
                                )}
                              </td>
                              <td className="p-4 font-mono text-xs text-muted-foreground">
                                {req.transactionId || "N/A"}
                              </td>
                              <td className="p-4">
                                <span
                                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-sm text-[10px] font-semibold font-mono ${
                                    isPaid
                                      ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                                      : isPending
                                      ? "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                                      : "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                                  }`}
                                >
                                  {isPaid ? (
                                    <CheckCircle className="w-3 h-3" />
                                  ) : isPending ? (
                                    <Clock className="w-3 h-3" />
                                  ) : (
                                    <AlertCircle className="w-3 h-3" />
                                  )}
                                  {req.paymentStatus}
                                </span>
                              </td>
                              <td className="p-4 text-right">
                                {isPending ? (
                                  <div className="flex items-center justify-end gap-1.5">
                                    <Button
                                      type="button"
                                      size="sm"
                                      disabled={actionLoadingId === req.id}
                                      onClick={() => handleApproveBankTransfer(req.id)}
                                      className="h-7 text-[11px] px-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1"
                                    >
                                      {actionLoadingId === req.id ? (
                                        <Loader2 className="w-3 h-3 animate-spin" />
                                      ) : (
                                        <Check className="w-3 h-3" />
                                      )}
                                      Approve
                                    </Button>

                                    <Button
                                      type="button"
                                      variant="outline"
                                      size="sm"
                                      disabled={actionLoadingId === req.id}
                                      onClick={() => setRejectModalItem(req)}
                                      className="h-7 text-[11px] px-2 text-rose-400 border-rose-500/30 hover:bg-rose-500/10"
                                    >
                                      <Ban className="w-3 h-3" /> Reject
                                    </Button>
                                  </div>
                                ) : (
                                  <span className="text-[11px] text-muted-foreground font-mono">
                                    {isPaid ? "Activated" : "Closed"}
                                  </span>
                                )}
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </Card>
            </div>
          )}

          {/* TAB 3: SAAS PRICING PLANS */}
          {activeTab === "plans" && (
            <div className="space-y-8">
              {/* Section 1: Standard Public SaaS Plans */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-sm font-bold text-foreground font-mono uppercase tracking-wide">
                      Standard Public SaaS Plans
                    </h2>
                    <p className="text-xs text-muted-foreground">
                      Core pricing tiers displayed on the public website and standard client portals.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {isPlansLoading ? (
                    <div className="col-span-full p-8 text-center text-muted-foreground">
                      <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" /> Loading plans...
                    </div>
                  ) : (
                    plans
                      .filter((p) => !p.isCustom)
                      .map((plan) => (
                        <Card
                          key={plan.id}
                          className={`bg-card/40 backdrop-blur-md border rounded-sm overflow-hidden flex flex-col justify-between ${
                            plan.isPopular ? "border-primary/50 shadow-lg shadow-primary/10" : "border-border/60"
                          }`}
                        >
                          <div className="p-5 space-y-4">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-mono font-bold uppercase text-primary">
                                {plan.slug}
                              </span>
                              <div className="flex items-center gap-1.5">
                                {plan.isPopular && (
                                  <span className="bg-primary/20 text-primary text-[9px] font-bold px-2 py-0.5 rounded-sm font-mono">
                                    POPULAR
                                  </span>
                                )}
                              </div>
                            </div>

                            <div>
                              <h3 className="text-lg font-bold text-foreground">{plan.name}</h3>
                              <p className="text-xs text-muted-foreground line-clamp-2 mt-1">
                                {plan.description || "Full access to HKRION ERP cloud modules."}
                              </p>
                            </div>

                            {plan.slug === "enterprise" ? (
                              <div className="pt-2 border-t border-border/50">
                                <div className="text-xl font-extrabold text-foreground font-mono">
                                  Custom Quote
                                </div>
                                <p className="text-xs text-muted-foreground font-mono mt-0.5">
                                  Contact Sales (Bespoke Pricing)
                                </p>
                              </div>
                            ) : (
                              <div className="pt-2 border-t border-border/50">
                                <div className="flex items-baseline justify-between">
                                  <div className="text-xl font-extrabold text-foreground font-mono">
                                    Rs. {plan.priceMonthly.toLocaleString()}
                                    <span className="text-xs font-normal text-muted-foreground"> /mo</span>
                                  </div>
                                  <span className="text-xs font-mono font-semibold text-primary">
                                    ${Number(plan.priceMonthlyUsd || 0).toLocaleString(undefined, { minimumFractionDigits: Number.isInteger(Number(plan.priceMonthlyUsd || 0)) ? 0 : 2, maximumFractionDigits: 2 })}/mo
                                  </span>
                                </div>
                                <div className="flex items-center justify-between text-xs text-muted-foreground font-mono mt-0.5">
                                  <span>Rs. {plan.priceYearly.toLocaleString()} /yr</span>
                                  <span>${Number(plan.priceYearlyUsd || 0).toLocaleString(undefined, { minimumFractionDigits: Number.isInteger(Number(plan.priceYearlyUsd || 0)) ? 0 : 2, maximumFractionDigits: 2 })} /yr</span>
                                </div>
                              </div>
                            )}

                            {/* Feature Limits List */}
                            <div className="space-y-1.5 text-xs text-muted-foreground border-t border-border/50 pt-3">
                              <div className="flex justify-between">
                                <span>Max Branches:</span>
                                <span className="font-mono font-bold text-foreground">
                                  {plan.maxBranches === -1 ? "Unlimited" : plan.maxBranches}
                                </span>
                              </div>
                              <div className="flex justify-between">
                                <span>Max Users:</span>
                                <span className="font-mono font-bold text-foreground">
                                  {plan.maxUsers === -1 ? "Unlimited" : plan.maxUsers}
                                </span>
                              </div>
                              <div className="flex justify-between">
                                <span>Max Products:</span>
                                <span className="font-mono font-bold text-foreground">
                                  {plan.maxProducts === -1 ? "Unlimited" : plan.maxProducts.toLocaleString()}
                                </span>
                              </div>
                              <div className="flex justify-between">
                                <span>Monthly Invoices:</span>
                                <span className="font-mono font-bold text-foreground">
                                  {plan.maxInvoicesMonthly === -1 ? "Unlimited" : plan.maxInvoicesMonthly.toLocaleString()}
                                </span>
                              </div>
                            </div>
                          </div>

                          <div className="p-4 bg-background/50 border-t border-border/50 flex items-center justify-between gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedPlanForEdit(plan);
                                setIsCustomPlanMode(false);
                                setIsPlanModalOpen(true);
                              }}
                              className="text-xs h-8 flex-1 flex items-center justify-center gap-1.5 rounded-sm"
                            >
                              <Edit2 className="w-3.5 h-3.5" /> Edit
                            </Button>
                            {['trial', 'starter', 'pro', 'business', 'enterprise'].includes(plan.slug) ? (
                              <div
                                className="text-[10px] font-mono text-muted-foreground bg-secondary/60 px-2.5 py-1.5 rounded-sm border border-border flex items-center gap-1 shrink-0 select-none cursor-default"
                                title="Core system default package cannot be deleted"
                              >
                                <Lock className="w-3 h-3 text-primary" /> System Plan
                              </div>
                            ) : (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  setSelectedPlanForDelete(plan);
                                  setIsDeleteModalOpen(true);
                                }}
                                className="text-xs h-8 text-rose-400 hover:text-rose-300 hover:border-rose-500/40 p-2 rounded-sm"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </Button>
                            )}
                          </div>
                        </Card>
                      ))
                  )}
                </div>
              </div>

              {/* Section 2: Custom Enterprise Client Contracts */}
              <div className="space-y-4 pt-6 border-t border-border/60">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-sm font-bold text-foreground font-mono uppercase tracking-wide">
                        🏢 Custom Enterprise Client Contracts
                      </h2>
                      <span className="bg-amber-500/20 text-amber-400 border border-amber-500/30 text-[10px] font-bold px-2 py-0.5 rounded-sm font-mono">
                        {plans.filter((p) => p.isCustom).length} Exclusive Deals
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      Bespoke enterprise contracts strictly bound to specific business tenants. Only visible in that client&apos;s billing portal.
                    </p>
                  </div>
                  <Button
                    onClick={() => {
                      setSelectedPlanForEdit(null);
                      setIsCustomPlanMode(true);
                      setIsPlanModalOpen(true);
                    }}
                    className="text-xs h-8 font-bold bg-amber-500 hover:bg-amber-600 text-black shadow-lg shadow-amber-500/20 flex items-center gap-1.5 rounded-sm shrink-0"
                  >
                    <Building2 className="w-3.5 h-3.5" /> + Create Enterprise Deal for Client
                  </Button>
                </div>

                <Card className="bg-card/40 backdrop-blur-md border-border/60 overflow-hidden shadow-sm">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-border bg-background/50 text-[10px] font-mono uppercase text-muted-foreground">
                          <th className="p-4 font-bold">Client Business</th>
                          <th className="p-4 font-bold">Contract Plan Name</th>
                          <th className="p-4 font-bold">Negotiated Fee</th>
                          <th className="p-4 font-bold">Allocated Limits</th>
                          <th className="p-4 font-bold">Enabled Modules</th>
                          <th className="p-4 font-bold">Status</th>
                          <th className="p-4 font-bold text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border/50 font-medium">
                        {plans.filter((p) => p.isCustom).length === 0 ? (
                          <tr>
                            <td colSpan={7} className="p-8 text-center text-muted-foreground">
                              No custom enterprise deals created yet. Click <strong>&quot;+ Create Enterprise Deal for Client&quot;</strong> to set up a bespoke contract for a business.
                            </td>
                          </tr>
                        ) : (
                          plans
                            .filter((p) => p.isCustom)
                            .map((cPlan) => (
                              <tr key={cPlan.id} className="hover:bg-accent/30 transition-colors">
                                <td className="p-4">
                                  <div className="font-bold text-foreground flex items-center gap-1.5">
                                    <Building2 className="w-3.5 h-3.5 text-amber-400" />
                                    {cPlan.business?.name || "Unassigned"}
                                  </div>
                                  <div className="text-muted-foreground text-[11px] font-mono">
                                    {cPlan.business?.phone || cPlan.business?.email || cPlan.businessId}
                                  </div>
                                </td>
                                <td className="p-4">
                                  <div className="font-bold text-foreground font-mono">{cPlan.name}</div>
                                  <div className="text-[10px] text-muted-foreground font-mono">{cPlan.slug}</div>
                                </td>
                                <td className="p-4 font-mono">
                                  <div className="font-bold text-foreground">
                                    Rs. {cPlan.priceMonthly.toLocaleString()} /mo
                                  </div>
                                  <div className="text-[11px] text-primary">
                                    ${Number(cPlan.priceMonthlyUsd || 0)} /mo
                                  </div>
                                </td>
                                <td className="p-4 text-xs font-mono space-y-0.5">
                                  <div>Branches: <span className="font-bold text-foreground">{cPlan.maxBranches === -1 ? "Unlimited" : cPlan.maxBranches}</span></div>
                                  <div>Users: <span className="font-bold text-foreground">{cPlan.maxUsers === -1 ? "Unlimited" : cPlan.maxUsers}</span></div>
                                  <div>Products: <span className="font-bold text-foreground">{cPlan.maxProducts === -1 ? "Unlimited" : cPlan.maxProducts.toLocaleString()}</span></div>
                                </td>
                                <td className="p-4">
                                  <div className="flex flex-wrap gap-1 max-w-[180px]">
                                    {cPlan.enablePos && <span className="text-[9px] font-mono bg-primary/10 text-primary px-1.5 py-0.5 rounded-sm">POS</span>}
                                    {cPlan.enableImei && <span className="text-[9px] font-mono bg-primary/10 text-primary px-1.5 py-0.5 rounded-sm">IMEI</span>}
                                    {cPlan.enableAccounting && <span className="text-[9px] font-mono bg-primary/10 text-primary px-1.5 py-0.5 rounded-sm">ACCOUNTS</span>}
                                    {cPlan.enableSms && <span className="text-[9px] font-mono bg-primary/10 text-primary px-1.5 py-0.5 rounded-sm">SMS</span>}
                                  </div>
                                </td>
                                <td className="p-4">
                                  {cPlan.subscriptions?.some((s) => s.status === "ACTIVE" && s.businessId === cPlan.businessId) ? (
                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-sm text-[10px] font-bold font-mono bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                                      <CheckCircle className="w-3 h-3" /> PAID &amp; ACTIVE
                                    </span>
                                  ) : (
                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-sm text-[10px] font-bold font-mono bg-amber-500/15 text-amber-400 border border-amber-500/30">
                                      <Clock className="w-3 h-3" /> AWAITING PAYMENT
                                    </span>
                                  )}
                                  <span className="text-[10px] text-muted-foreground block font-mono mt-1">
                                    Plan: {cPlan.isActive ? "Available" : "Disabled"}
                                  </span>
                                </td>
                                <td className="p-4 text-right">
                                  <div className="flex items-center justify-end gap-1.5">
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => {
                                        setSelectedPlanForEdit(cPlan);
                                        setIsCustomPlanMode(true);
                                        setIsPlanModalOpen(true);
                                      }}
                                      className="h-7 text-[11px] px-2.5 rounded-sm"
                                    >
                                      <Edit2 className="w-3 h-3 mr-1" /> Edit Deal
                                    </Button>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => {
                                        setSelectedPlanForDelete(cPlan);
                                        setIsDeleteModalOpen(true);
                                      }}
                                      className="h-7 text-[11px] px-2 text-rose-400 hover:text-rose-300 rounded-sm"
                                    >
                                      <Trash2 className="w-3 h-3" />
                                    </Button>
                                  </div>
                                </td>
                              </tr>
                            ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </Card>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Slip Preview Modal */}
      {selectedSlipUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="max-w-2xl w-full bg-card border border-border rounded-sm p-4 space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-between border-b border-border pb-2">
              <span className="text-xs font-bold text-foreground font-mono flex items-center gap-1.5">
                <FileImage className="w-4 h-4 text-primary" /> Deposit Proof Slip
              </span>
              <button
                onClick={() => setSelectedSlipUrl(null)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="max-h-[70vh] overflow-auto flex items-center justify-center bg-black/40 rounded-sm p-2">
              <img
                src={getFullAssetUrl(selectedSlipUrl) || selectedSlipUrl}
                alt="Bank Transfer Proof"
                className="max-h-[65vh] object-contain rounded-sm"
              />
            </div>
            <div className="flex justify-end">
              <a
                href={getFullAssetUrl(selectedSlipUrl) || "#"}
                target="_blank"
                rel="noreferrer"
                className="text-xs text-primary hover:underline flex items-center gap-1 font-bold"
              >
                Open in new tab <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Reject Reason Modal */}
      {rejectModalItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="max-w-md w-full bg-card border border-border rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-border pb-2">
              <h3 className="text-sm font-bold text-rose-400 flex items-center gap-1.5">
                <Ban className="w-4 h-4" /> Reject Bank Transfer Request
              </h3>
              <button
                onClick={() => setRejectModalItem(null)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-muted-foreground">
              Rejecting request for <strong>{rejectModalItem.businessName}</strong> ({rejectModalItem.invoiceNumber}).
            </p>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono">
                Rejection Reason (Will be shown to tenant)
              </label>
              <Input
                placeholder="e.g. Deposit slip was unclear / Amount mismatch"
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                className="text-xs h-9"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-border">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setRejectModalItem(null)}
                className="text-xs h-8"
              >
                Cancel
              </Button>
              <Button
                size="sm"
                onClick={handleRejectBankTransfer}
                disabled={actionLoadingId === rejectModalItem.id}
                className="text-xs h-8 bg-rose-600 hover:bg-rose-500 text-white font-bold"
              >
                {actionLoadingId === rejectModalItem.id ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  "Confirm Rejection"
                )}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Plan Dialogs */}
      <PlanDialog
        isOpen={isPlanModalOpen}
        onClose={() => setIsPlanModalOpen(false)}
        plan={selectedPlanForEdit}
        defaultCustom={isCustomPlanMode}
        onSuccess={() => refetchPlans()}
      />

      <PlanDeleteDialog
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        plan={selectedPlanForDelete}
        onSuccess={() => refetchPlans()}
      />

      {/* Subscription Manual Override Dialog */}
      {statusEditSub && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-card border border-border rounded-sm p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <h3 className="text-sm font-bold text-foreground font-mono">
                Manage Tenant Subscription
              </h3>
              <button
                onClick={() => setStatusEditSub(null)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="text-xs space-y-3">
              <div>
                <span className="text-muted-foreground">Tenant Business: </span>
                <span className="font-bold text-foreground">{statusEditSub.businessName}</span>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono">
                  Subscription Status
                </label>
                <select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value)}
                  className="w-full h-9 px-3 text-xs rounded-sm bg-secondary/50 border border-border text-foreground font-mono"
                >
                  <option value="ACTIVE">ACTIVE</option>
                  <option value="TRIAL">TRIAL</option>
                  <option value="PAST_DUE">PAST_DUE</option>
                  <option value="EXPIRED">EXPIRED</option>
                  <option value="CANCELLED">CANCELLED</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono">
                  Assigned SaaS Plan
                </label>
                <select
                  value={newPlanId}
                  onChange={(e) => setNewPlanId(e.target.value)}
                  className="w-full h-9 px-3 text-xs rounded-sm bg-secondary/50 border border-border text-foreground font-mono"
                >
                  {availablePlansForSub.map((p) => {
                    const isTrial = p.slug === "trial" || (p.priceMonthly === 0 && !p.isCustom && p.slug !== "enterprise");
                    const label = isTrial
                      ? "(Free / 14-Day Trial)"
                      : p.isCustom
                      ? `(Custom Deal - Rs. ${p.priceMonthly.toLocaleString()}/mo)`
                      : p.slug === "enterprise"
                      ? "(Custom / Enterprise Quote)"
                      : `(Rs. ${p.priceMonthly.toLocaleString()}/mo)`;

                    return (
                      <option key={p.id} value={p.id}>
                        {p.name} {label}
                      </option>
                    );
                  })}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono">
                  Subscription Expiry Date
                </label>
                <Input
                  type="date"
                  value={newEndDate}
                  onChange={(e) => setNewEndDate(e.target.value)}
                  className="h-9 text-xs font-mono"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-border">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setStatusEditSub(null)}
                className="text-xs h-8"
              >
                Cancel
              </Button>
              <Button
                size="sm"
                onClick={handleSaveStatusEdit}
                disabled={updateStatusMutation.isPending}
                className="text-xs h-8 font-bold"
              >
                {updateStatusMutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
