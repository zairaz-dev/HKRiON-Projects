import { AboutService } from "@/services/about.service";
import {
  Sparkles,
  Save,
  Globe,
  Award,
  BookOpen,
  Target,
  CheckCircle2,
  ExternalLink,
  Zap,
  Image as ImageIcon,
  Compass,
} from "lucide-react";
import Link from "next/link";
import ImageUploadInput from "@/components/admin/ImageUploadInput";

export const dynamic = "force-dynamic";

interface AdminAboutPageProps {
  searchParams?: Promise<{ tab?: string; success?: string; error?: string }>;
}

export default async function AdminAboutPageCMS({ searchParams }: AdminAboutPageProps) {
  const params = await searchParams;
  const activeTab = params?.tab || "hero";
  const content = await AboutService.getContent();

  const tabs = [
    { id: "hero", label: "Hero Banner", icon: Compass, count: "4 fields" },
    { id: "statement", label: "Brand Statement", icon: Sparkles, count: "3 fields" },
    { id: "story", label: "Our Story & Stats", icon: BookOpen, count: "11 fields" },
    { id: "mission", label: "Mission & Vision", icon: Target, count: "4 fields" },
    { id: "why", label: "Why ShadeIt & CTA", icon: CheckCircle2, count: "8 fields" },
  ];

  return (
    <div className="space-y-6 w-full pb-20">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-black p-6 sm:p-8 rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-none bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 text-amber-700 dark:text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
            <Award size={14} /> Live Site CMS
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white tracking-tight">
            About Page Content Editor
          </h1>
          <p className="text-neutral-500 dark:text-neutral-400 text-xs sm:text-sm mt-1">
            Edit your brand heritage, story narrative, mission & vision, verified stats, and company pillars in real-time.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/admin/cms"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-none bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-900 dark:hover:bg-neutral-850 text-neutral-800 dark:text-neutral-200 border border-[#E5E5E0] dark:border-neutral-800 text-xs font-bold transition-all"
          >
            <span>← Back to CMS Hub</span>
          </Link>
          <Link
            href="/about"
            target="_blank"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-none bg-purple-50 dark:bg-purple-500/10 hover:bg-purple-100 dark:hover:bg-purple-500/20 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-500/30 text-xs font-bold transition-all"
          >
            <Globe size={15} />
            <span>View About Page</span>
            <ExternalLink size={13} className="text-purple-500 dark:text-purple-400" />
          </Link>
        </div>
      </div>

      {/* Main CMS Form */}
      <form method="POST" action="/api/admin/about" className="space-y-6">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <Link
                key={tab.id}
                href={`/admin/about?tab=${tab.id}`}
                scroll={false}
                className={`flex items-center gap-2.5 px-5 py-3 rounded-none text-xs font-bold transition-all whitespace-nowrap border shrink-0 ${
                  isActive
                    ? "bg-amber-500 text-slate-950 border-amber-600 shadow-xs"
                    : "bg-white dark:bg-black text-neutral-600 dark:text-neutral-400 border-[#E5E5E0] dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-900 hover:text-neutral-900 dark:hover:text-white"
                }`}
              >
                <Icon size={16} className={isActive ? "text-slate-950" : "text-neutral-400 dark:text-neutral-500"} />
                <span>{tab.label}</span>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-none font-medium ${
                    isActive ? "bg-slate-950/20 text-slate-950" : "bg-neutral-100 dark:bg-neutral-950 text-neutral-500 dark:text-neutral-500"
                  }`}
                >
                  {tab.count}
                </span>
              </Link>
            );
          })}
        </div>

        {/* TAB 1: HERO BANNER */}
        {activeTab === "hero" && (
          <div className="bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none p-6 sm:p-8 space-y-6 shadow-xs">
            <div className="border-b border-neutral-100 dark:border-neutral-800 pb-4">
              <h2 className="text-lg font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                <Compass className="text-amber-500" size={18} />
                <span>About Page Hero Banner</span>
              </h2>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                The top full-height cinematic banner introducing the brand ethos.
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                Top Pill Badge
              </label>
              <input
                type="text"
                name="heroBadge"
                defaultValue={content.heroBadge}
                placeholder="ABOUT SHADEIT BLINDS"
                className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 font-medium"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Headline Line 1 (Standard)
                </label>
                <input
                  type="text"
                  name="heroTitleLine1"
                  defaultValue={content.heroTitleLine1}
                  placeholder="We Shape Light."
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 mb-1.5">
                  Headline Line 2 (Glowing Gold Text)
                </label>
                <input
                  type="text"
                  name="heroTitleHighlight"
                  defaultValue={content.heroTitleHighlight}
                  placeholder="We Create Comfort."
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-amber-400/50 focus:border-amber-400 rounded-none px-4 py-2.5 text-amber-700 dark:text-amber-300 text-sm font-semibold focus:outline-none focus:ring-1 focus:ring-amber-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                Hero Subtitle / Description
              </label>
              <textarea
                name="heroSubtitle"
                rows={3}
                defaultValue={content.heroSubtitle}
                placeholder="Premium window covering and outdoor shade solutions..."
                className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none p-4 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 resize-none font-medium"
              />
            </div>
          </div>
        )}

        {/* TAB 2: BRAND STATEMENT */}
        {activeTab === "statement" && (
          <div className="bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none p-6 sm:p-8 space-y-6 shadow-xs">
            <div className="border-b border-neutral-100 dark:border-neutral-800 pb-4">
              <h2 className="text-lg font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                <Sparkles className="text-amber-500" size={18} />
                <span>Editorial Brand Statement</span>
              </h2>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                The full-width typography statement section directly following the hero.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Statement Line 1
                </label>
                <input
                  type="text"
                  name="statementPrefix"
                  defaultValue={content.statementPrefix}
                  placeholder="More Than Blinds."
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 mb-1.5">
                  Statement Line 2 (Glowing Gold)
                </label>
                <input
                  type="text"
                  name="statementHighlight"
                  defaultValue={content.statementHighlight}
                  placeholder="We Transform Spaces."
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-amber-400/50 focus:border-amber-400 rounded-none px-4 py-2.5 text-amber-700 dark:text-amber-300 text-sm font-semibold focus:outline-none focus:ring-1 focus:ring-amber-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                Statement Paragraph Description
              </label>
              <textarea
                name="statementDescription"
                rows={3}
                defaultValue={content.statementDescription}
                placeholder="From elegant interiors to functional outdoor spaces..."
                className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none p-4 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 resize-none font-medium"
              />
            </div>
          </div>
        )}

        {/* TAB 3: OUR STORY & STATS */}
        {activeTab === "story" && (
          <div className="bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none p-6 sm:p-8 space-y-6 shadow-xs">
            <div className="border-b border-neutral-100 dark:border-neutral-800 pb-4">
              <h2 className="text-lg font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                <BookOpen className="text-amber-500" size={18} />
                <span>Our Story Narrative & Heritage</span>
              </h2>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                The split-layout section detailing your company journey, images, and milestones.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Section Pill Badge
                </label>
                <input
                  type="text"
                  name="storyBadge"
                  defaultValue={content.storyBadge}
                  placeholder="OUR STORY"
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Story Image URL
                </label>
                <ImageUploadInput
                  name="storyImageUrl"
                  defaultValue={content.storyImageUrl}
                  placeholder="/gallery_1.png"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                Story Headline
              </label>
              <input
                type="text"
                name="storyTitle"
                defaultValue={content.storyTitle}
                placeholder="Designed Around The Way You Live."
                className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 font-medium"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Narrative Paragraph 1
                </label>
                <textarea
                  name="storyPara1"
                  rows={4}
                  defaultValue={content.storyPara1}
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none p-4 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 resize-none font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Narrative Paragraph 2
                </label>
                <textarea
                  name="storyPara2"
                  rows={4}
                  defaultValue={content.storyPara2}
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none p-4 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 resize-none font-medium"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 border-t border-neutral-100 dark:border-neutral-800/80">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Image Overlay Tag
                </label>
                <input
                  type="text"
                  name="storyCardTag"
                  defaultValue={content.storyCardTag}
                  placeholder="Established Excellence"
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 rounded-none px-3.5 py-2 text-neutral-900 dark:text-white text-sm focus:border-amber-400 focus:outline-none font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Image Overlay Title
                </label>
                <input
                  type="text"
                  name="storyCardTitle"
                  defaultValue={content.storyCardTitle}
                  placeholder="Custom Automated Window Systems"
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 rounded-none px-3.5 py-2 text-neutral-900 dark:text-white text-sm focus:border-amber-400 focus:outline-none font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Image Overlay Years Pill
                </label>
                <input
                  type="text"
                  name="storyCardYears"
                  defaultValue={content.storyCardYears}
                  placeholder="10+ Yrs"
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 rounded-none px-3.5 py-2 text-neutral-900 dark:text-white text-sm focus:border-amber-400 focus:outline-none font-medium"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
              <div className="p-4 rounded-none bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 space-y-3">
                <p className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">Story Stat 1</p>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-neutral-500 dark:text-neutral-400 mb-1">Number</label>
                    <input
                      type="number"
                      name="storyStat1Value"
                      defaultValue={content.storyStat1Value}
                      className="w-full bg-white dark:bg-black border border-neutral-200 dark:border-neutral-800 rounded-none px-3 py-2 text-neutral-900 dark:text-white font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-neutral-500 dark:text-neutral-400 mb-1">Label</label>
                    <input
                      type="text"
                      name="storyStat1Label"
                      defaultValue={content.storyStat1Label}
                      className="w-full bg-white dark:bg-black border border-neutral-200 dark:border-neutral-800 rounded-none px-3 py-2 text-neutral-900 dark:text-white text-xs font-semibold"
                    />
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-none bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 space-y-3">
                <p className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">Story Stat 2</p>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-neutral-500 dark:text-neutral-400 mb-1">Number</label>
                    <input
                      type="number"
                      name="storyStat2Value"
                      defaultValue={content.storyStat2Value}
                      className="w-full bg-white dark:bg-black border border-neutral-200 dark:border-neutral-800 rounded-none px-3 py-2 text-neutral-900 dark:text-white font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-neutral-500 dark:text-neutral-400 mb-1">Label</label>
                    <input
                      type="text"
                      name="storyStat2Label"
                      defaultValue={content.storyStat2Label}
                      className="w-full bg-white dark:bg-black border border-neutral-200 dark:border-neutral-800 rounded-none px-3 py-2 text-neutral-900 dark:text-white text-xs font-semibold"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: MISSION & VISION */}
        {activeTab === "mission" && (
          <div className="bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none p-6 sm:p-8 space-y-6 shadow-xs">
            <div className="border-b border-neutral-100 dark:border-neutral-800 pb-4">
              <h2 className="text-lg font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                <Target className="text-amber-500" size={18} />
                <span>Mission & Vision Statements</span>
              </h2>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                The two large card blocks presenting your corporate goals and future vision.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Mission */}
              <div className="p-6 rounded-none bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 space-y-4">
                <span className="text-amber-600 dark:text-amber-400 text-xs font-bold uppercase tracking-wider block">Mission Card</span>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                    Mission Headline
                  </label>
                  <input
                    type="text"
                    name="missionTitle"
                    defaultValue={content.missionTitle}
                    className="w-full bg-white dark:bg-black border border-neutral-200 dark:border-neutral-800 focus:border-amber-400 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:outline-none font-medium"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                    Mission Description
                  </label>
                  <textarea
                    name="missionDescription"
                    rows={4}
                    defaultValue={content.missionDescription}
                    className="w-full bg-white dark:bg-black border border-neutral-200 dark:border-neutral-800 focus:border-amber-400 rounded-none p-4 text-neutral-900 dark:text-white text-sm focus:outline-none resize-none font-medium"
                  />
                </div>
              </div>

              {/* Vision */}
              <div className="p-6 rounded-none bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 space-y-4">
                <span className="text-amber-600 dark:text-amber-400 text-xs font-bold uppercase tracking-wider block">Vision Card</span>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                    Vision Headline
                  </label>
                  <input
                    type="text"
                    name="visionTitle"
                    defaultValue={content.visionTitle}
                    className="w-full bg-white dark:bg-black border border-neutral-200 dark:border-neutral-800 focus:border-amber-400 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:outline-none font-medium"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                    Vision Description
                  </label>
                  <textarea
                    name="visionDescription"
                    rows={4}
                    defaultValue={content.visionDescription}
                    className="w-full bg-white dark:bg-black border border-neutral-200 dark:border-neutral-800 focus:border-amber-400 rounded-none p-4 text-neutral-900 dark:text-white text-sm focus:outline-none resize-none font-medium"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: WHY SHADEIT & CTA */}
        {activeTab === "why" && (
          <div className="bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none p-6 sm:p-8 space-y-6 shadow-xs">
            <div className="border-b border-neutral-100 dark:border-neutral-800 pb-4">
              <h2 className="text-lg font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                <CheckCircle2 className="text-amber-500" size={18} />
                <span>Why ShadeIt Points & Closing CTA</span>
              </h2>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                The 5-badge checklist strip and the closing consultation banner.
              </p>
            </div>

            <div className="space-y-4">
              <p className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">Why ShadeIt Checklist Strip</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                    Section Top Badge
                  </label>
                  <input
                    type="text"
                    name="whyBadge"
                    defaultValue={content.whyBadge}
                    placeholder="WHY SHADEIT"
                    className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:border-amber-400 focus:outline-none font-medium"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                    Checklist Points (Comma Separated)
                  </label>
                  <input
                    type="text"
                    name="whyPoints"
                    defaultValue={content.whyPoints}
                    placeholder="Custom Fit, Premium Fabrics, Professional Fitting, Residential & Commercial, Outdoor Expertise"
                    className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:border-amber-400 focus:outline-none font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Why ShadeIt Main Title
                </label>
                <input
                  type="text"
                  name="whyTitle"
                  defaultValue={content.whyTitle}
                  placeholder="Thoughtfully Designed. Professionally Installed. Built to Last."
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:border-amber-400 focus:outline-none font-medium"
                />
              </div>
            </div>

            <div className="space-y-4 pt-6 border-t border-neutral-100 dark:border-neutral-800/80">
              <p className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">Closing CTA Banner</p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                    CTA Badge
                  </label>
                  <input
                    type="text"
                    name="ctaBadge"
                    defaultValue={content.ctaBadge}
                    placeholder="Elevate Your Space"
                    className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:border-amber-400 focus:outline-none font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                    CTA Title
                  </label>
                  <input
                    type="text"
                    name="ctaTitle"
                    defaultValue={content.ctaTitle}
                    placeholder="Ready to Transform Your Space?"
                    className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:border-amber-400 focus:outline-none font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  CTA Subtitle
                </label>
                <textarea
                  name="ctaSubtitle"
                  rows={3}
                  defaultValue={content.ctaSubtitle}
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 rounded-none p-4 text-neutral-900 dark:text-white text-sm focus:border-amber-400 focus:outline-none resize-none font-medium"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                    Button Label
                  </label>
                  <input
                    type="text"
                    name="ctaButtonText"
                    defaultValue={content.ctaButtonText}
                    placeholder="Get Free Consultation"
                    className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:border-amber-400 focus:outline-none font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                    Button Link
                  </label>
                  <input
                    type="text"
                    name="ctaButtonLink"
                    defaultValue={content.ctaButtonLink}
                    placeholder="/contact"
                    className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white font-mono text-xs focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Floating Action Bar / Save Button */}
        <div className="sticky bottom-6 z-30 p-4 rounded-none bg-white/95 dark:bg-black/95 backdrop-blur-xl border border-[#E5E5E0] dark:border-neutral-800 shadow-2xl flex items-center justify-between gap-4">
          <div className="hidden sm:flex items-center gap-3">
            <div className="w-9 h-9 rounded-none bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 flex items-center justify-center text-amber-700 dark:text-amber-400">
              <Zap size={18} />
            </div>
            <div>
              <p className="text-xs font-bold text-neutral-900 dark:text-white">Live Site Sync</p>
              <p className="text-[10px] text-neutral-500 dark:text-neutral-400">Updates will reflect immediately on the About Page</p>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
            <button
              type="submit"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3 rounded-none bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold text-sm transition-all shadow-xs active:scale-95 cursor-pointer"
            >
              <Save size={16} />
              <span>Save About Page Changes</span>
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
