import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Country } from '../../types';

@Injectable()
export class CountryService {
  constructor(private readonly prisma: PrismaService) {}

  async findAll(): Promise<Country[]> {
    const countries = await this.prisma.country.findMany({
      where: { isActive: true },
      orderBy: { name: 'asc' },
    });
    return countries.map((c) => ({
      ...c,
      createdAt: c.createdAt.toISOString(),
    }));
  }
}
