# WhatsApp SaaS Platform (Evolution API + Next.js 14)

A complete, production-ready WhatsApp SaaS platform architecture for group contact extraction, bulk messaging, and CRM data pipeline built using **Evolution API** and **Next.js 14**.

---

## 📁 Directory Structure

```
whatsapp_new/
├── backend/          # Evolution API Node.js / Baileys REST API Gateway
│   ├── src/          # Evolution API source code
│   └── .env.example  # Environment configuration template
└── frontend/         # Next.js 14 SaaS Dashboard
    ├── app/          # Next.js App Router & Pages
    ├── components/   # UI Components (Sidebar, QR Modal, Extractor, Messenger)
    └── lib/          # Evolution API integration client
```

---

## 🚀 How to Run

### 1. Run Evolution API Backend
```bash
cd backend
npm install
npm run build
npm start
```
*Evolution API runs by default on `http://localhost:8080` with API Key `429683C4C977415CAAFCCE10F7D57E11`.*

### 2. Run Next.js SaaS Frontend
```bash
cd frontend
npm install
npm run dev
```
*Frontend runs on `http://localhost:3000`.*

---

## ⚡ Features Built-In
- **Live WhatsApp QR Scanner**: Connect WhatsApp instances via Evolution API REST endpoints.
- **Group Contact Scraper**: Extract all group members, calculate unique contacts, and auto-generate Google CSV files.
- **Live Messenger**: Send direct text messages via Baileys API endpoints.
- **Downloads Hub**: One-click download for Part 1 & Part 2 Google Contacts CSV files.
- **Configurable API Endpoint**: Easily switch between local Evolution API or remote VPS / Cloud deployments.
# whatsapp_bot
# whatsapp_bot
