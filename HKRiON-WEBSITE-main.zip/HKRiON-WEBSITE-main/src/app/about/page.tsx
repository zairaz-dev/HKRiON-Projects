import Navbar from '@/components/Navbar';
import About from '@/components/About';
import Team from '@/components/Team';
import WhyChooseUs from '@/components/WhyChooseUs';
import Testimonials from '@/components/Testimonials';
import Footer from '@/components/Footer';
import FloatingWidgets from '@/components/FloatingWidgets';
import { Target, Lightbulb } from 'lucide-react';

export const metadata = {
  title: 'About Us | HKRION (Pvt) Ltd',
  description: 'Learn about HKRION (Pvt) Ltd, our operational philosophy, software development standards, and mission to empower Sri Lankan and global businesses.',
};

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-black text-neutral-100 flex flex-col font-sans">
      <Navbar />
      <main className="grow pt-24">
        
        {/* Dedicated About Header Banner */}
        <section className="py-20 relative bg-neutral-950 border-b border-[#1ABE56]/30 overflow-hidden">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#1ABE56]/15 blur-[150px] rounded-full pointer-events-none" />
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-4">
            
            <h1 className="text-4xl sm:text-6xl font-extrabold text-white">
              About <span className="gradient-text">HKRION (Pvt) Ltd</span>
            </h1>
            <p className="text-neutral-300 max-w-2xl mx-auto text-base sm:text-lg leading-relaxed">
              We are an enterprise software engineering firm building intelligent ERP platforms, smart IoT systems, high-speed web apps, and cloud infrastructures.
            </p>
          </div>
        </section>

        {/* Mission & Vision Grid */}
        <section className="py-16 bg-black">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="glass-card p-8 rounded-3xl border border-[#1ABE56]/30 bg-black/90 space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-[#1ABE56]/20 flex items-center justify-center">
                <Target className="w-6 h-6 text-[#1ABE56]" />
              </div>
              <h3 className="text-2xl font-bold text-white">Our Mission</h3>
              <p className="text-neutral-300 text-sm leading-relaxed">
                To empower startups and growing enterprise corporations with bank-grade software solutions, high-speed automated workflows, and robust MySQL/Cloud architectures.
              </p>
            </div>
            <div className="glass-card p-8 rounded-3xl border border-[#1ABE56]/30 bg-black/90 space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-[#1ABE56]/20 flex items-center justify-center">
                <Lightbulb className="w-6 h-6 text-[#1ABE56]" />
              </div>
              <h3 className="text-2xl font-bold text-white">Our Vision</h3>
              <p className="text-neutral-300 text-sm leading-relaxed">
                To become Sri Lanka and South Asia&apos;s premier technology powerhouse for Next-Gen ERP systems, IoT telemetry automation, and full-stack cloud engineering.
              </p>
            </div>
          </div>
        </section>

        <About />
        <Team />
        <WhyChooseUs />
        <Testimonials />
      </main>
      <Footer />
      <FloatingWidgets />
    </div>
  );
}
