import { useQuery, useMutation, useQueryClient, keepPreviousData } from "@tanstack/react-query";
import { categoryService } from "@/services/category-service";
import { queryKeys } from "@/lib/query-keys";

export function useCategoriesQuery(
  businessId: string,
  options: {
    branchId?: string;
    page?: number;
    limit?: number;
    search?: string;
    type?: string;
  } = {}
) {
  return useQuery({
    queryKey: queryKeys.categories.list(
      businessId,
      options.branchId,
      options.page,
      options.limit,
      options.search,
      options.type
    ),
    queryFn: () => categoryService.getCategories(businessId, options),
    enabled: !!businessId,
    placeholderData: keepPreviousData,
  });
}

export function useCreateCategoryMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: {
      name: string;
      description?: string;
      imageUrl?: string;
      imageFile?: File | null;
      businessId: string;
      branchIds?: string[];
      parentId?: string | null;
      isActive?: boolean;
      createdById?: string;
    }) => categoryService.createCategory(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.categories.all });
    },
  });
}

export function useUpdateCategoryMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      data,
    }: {
      id: string;
      data: {
        name?: string;
        description?: string;
        imageUrl?: string;
        imageFile?: File | null;
        isActive?: boolean;
        branchIds?: string[];
        parentId?: string | null;
        businessId: string;
        updatedById?: string;
      };
    }) => categoryService.updateCategory(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.categories.all });
    },
  });
}

export function useDeleteCategoryMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, businessId }: { id: string; businessId: string }) =>
      categoryService.deleteCategory(id, businessId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.categories.all });
    },
  });
}
