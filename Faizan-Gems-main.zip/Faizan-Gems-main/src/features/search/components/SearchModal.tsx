"use client";

import React, { useState, useEffect, useMemo } from "react";
import Image from "next/image";
import Link from "next/link";
import { useSearch } from "@/features/search/context/SearchContext";
import { useCurrency } from "@/features/currency/context/CurrencyContext";
import { Gemstone } from "@/types/gemstone";
import { COLLECTIONS } from "@/lib/data/collections";
import {
  CloseIcon,
  SearchIcon,
  CertificateShieldIcon,
  SparklesIcon,
  ChevronRightIcon
} from "@/components/ui/LuxuryIcons";
import { LuxuryPrice } from "@/components/ui/LuxuryPrice";

export function SearchModal() {
  const { isSearchOpen, closeSearch } = useSearch();
  const { formatPrice } = useCurrency();
  const [query, setQuery] = useState("");
  const [gemstonesList, setGemstonesList] = useState<Gemstone[]>([]);

  // Prevent background scrolling when search modal is open
  useEffect(() => {
    if (isSearchOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isSearchOpen]);

  // Escape key to close search modal
  useEffect(() => {
    if (!isSearchOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeSearch();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isSearchOpen, closeSearch]);

  useEffect(() => {
    let isMounted = true;
    fetch("/api/gemstones")
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (isMounted && Array.isArray(data)) {
          setGemstonesList(data);
        }
      })
      .catch(() => {});
    return () => {
      isMounted = false;
    };
  }, []);

  const trimmed = query.trim().toLowerCase();

  // Search Results
  const matchingGemstones = useMemo(() => {
    if (!trimmed) return [];
    return gemstonesList.filter((gem) =>
      gem.name.toLowerCase().includes(trimmed) ||
      gem.type.toLowerCase().includes(trimmed) ||
      gem.origin.toLowerCase().includes(trimmed) ||
      gem.color.toLowerCase().includes(trimmed) ||
      gem.cut.toLowerCase().includes(trimmed) ||
      gem.treatment.toLowerCase().includes(trimmed)
    ).slice(0, 4);
  }, [trimmed, gemstonesList]);

  const matchingCollections = useMemo(() => {
    if (!trimmed) return [];
    return COLLECTIONS.filter((col) =>
      col.title.toLowerCase().includes(trimmed) ||
      col.description.toLowerCase().includes(trimmed) ||
      col.tagline.toLowerCase().includes(trimmed)
    ).slice(0, 2);
  }, [trimmed]);

  const hasResults = matchingGemstones.length > 0 || matchingCollections.length > 0;

  const quickTags = [
    "Ceylon Royal Blue",
    "Unheated Ruby",
    "Muzo Emerald",
    "Padparadscha",
    "Alexandrite",
    "GIA Certified",
    "Oil-Free Emerald"
  ];

  if (!isSearchOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-black/70 backdrop-blur-md animate-luxury-backdrop"
      onClick={closeSearch}
    >
      <div
        className="w-full max-w-3xl bg-white border border-[#C5A880]/40 shadow-2xl overflow-hidden flex flex-col max-h-[80vh] animate-luxury-modal"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="relative p-4 sm:p-6 border-b border-[#E8E4DC] flex items-center gap-3">
          <SearchIcon className="w-6 h-6 text-[#C5A880] flex-shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search unheated sapphires, rubies, origins (e.g. Ceylon, Burma, Muzo), or lab certs..."
            className="w-full font-serif text-lg sm:text-xl text-[#18181D] placeholder:text-[#9C9488] focus:outline-none bg-transparent"
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              className="text-xs text-[#8C867D] hover:text-[#18181D] uppercase font-mono px-2"
            >
              Clear
            </button>
          )}
          <button
            onClick={closeSearch}
            aria-label="Close search"
            className="w-8 h-8 rounded-full bg-[#FAF8F5] text-[#8C867D] hover:text-[#18181D] flex items-center justify-center border border-[#E8E4DC]"
          >
            <CloseIcon className="w-4 h-4" />
          </button>
        </div>

        {/* Results / Suggestions Container */}
        <div className="overflow-y-auto p-6 space-y-6 flex-1">
          {!trimmed ? (
            <div>
              <span className="text-[11px] font-sans uppercase tracking-wider text-[#8C867D] block mb-3">
                Connoisseur Suggested Searches
              </span>
              <div className="flex flex-wrap gap-2">
                {quickTags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setQuery(tag)}
                    className="px-3 py-1.5 bg-[#FAF8F5] hover:bg-[#18181D] text-[#554F47] hover:text-white border border-[#E8E4DC] text-xs font-sans transition-colors"
                  >
                    {tag}
                  </button>
                ))}
              </div>

              {/* Curated highlights */}
              <div className="mt-8 pt-6 border-t border-[#F2EFE9]">
                <span className="text-[11px] font-sans uppercase tracking-wider text-[#8C867D] block mb-3">
                  Featured Acquisitions
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {gemstonesList.slice(0, 2).map((gem) => (
                    <Link
                      key={gem.id}
                      href={`/gemstones/${gem.id}`}
                      onClick={closeSearch}
                      className="flex items-center gap-3 p-2.5 border border-[#F2EFE9] hover:border-[#C5A880] transition-colors"
                    >
                      <div className="relative w-14 h-14 flex-shrink-0 bg-[#F7F5F1] overflow-hidden">
                        <Image
                          src={gem.images?.[0] || (gem as any).imageUrl || "/uploads/gemstones/gem-1789652077476-hwzsqu.webp"}
                          alt={gem.name}
                          fill
                          unoptimized={Boolean((gem.images?.[0] || (gem as any).imageUrl)?.startsWith("/uploads"))}
                          className="object-cover"
                        />
                      </div>
                      <div className="min-w-0">
                        <span className="font-serif text-sm text-[#18181D] block truncate">{gem.name}</span>
                        <div className="mt-0.5">
                          <LuxuryPrice amount={gem.price} size="xs" color="gold" />
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          ) : !hasResults ? (
            <div className="text-center py-12">
              <p className="font-serif text-xl text-[#18181D]">No specimens found for &ldquo;{query}&rdquo;</p>
              <p className="text-xs text-[#8C867D] font-sans mt-2">
                Try searching by mineral variety, carat range, origin country, or lab name (GIA, GRS, Gübelin).
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Gemstone Results */}
              {matchingGemstones.length > 0 && (
                <div>
                  <span className="text-[11px] font-sans uppercase tracking-wider text-[#9A7B4F] block mb-3 font-medium">
                    Certified Gemstones ({matchingGemstones.length})
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {matchingGemstones.map((gem) => (
                      <Link
                        key={gem.id}
                        href={`/gemstones/${gem.id}`}
                        onClick={closeSearch}
                        className="flex items-center gap-3.5 p-3 border border-[#E8E4DC] hover:border-[#C5A880] bg-[#FAF8F5]/40 hover:bg-white transition-all group"
                      >
                        <div className="relative w-16 h-16 flex-shrink-0 bg-[#F7F5F1] border border-[#E8E4DC] overflow-hidden">
                          <Image
                            src={gem.images?.[0] || (gem as any).imageUrl || "/uploads/gemstones/gem-1789652077476-hwzsqu.webp"}
                            alt={gem.name}
                            fill
                            unoptimized={Boolean((gem.images?.[0] || (gem as any).imageUrl)?.startsWith("/uploads"))}
                            className="object-cover"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1 text-[10px] uppercase font-sans text-[#8C867D]">
                            <span>{gem.carat.toFixed(2)} ct</span>
                            <span>•</span>
                            <span className="text-[#C5A880]">{gem.cut}</span>
                          </div>
                          <h4 className="font-serif text-sm text-[#18181D] group-hover:text-[#9A7B4F] truncate">
                            {gem.name}
                          </h4>
                          <div className="mt-0.5">
                            <LuxuryPrice amount={gem.price} size="sm" weight="semibold" />
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Collections Results */}
              {matchingCollections.length > 0 && (
                <div className="pt-4 border-t border-[#F2EFE9]">
                  <span className="text-[11px] font-sans uppercase tracking-wider text-[#9A7B4F] block mb-3 font-medium">
                    Curated Collections
                  </span>
                  <div className="space-y-2">
                    {matchingCollections.map((col) => (
                      <Link
                        key={col.id}
                        href={`/collections/${col.slug}`}
                        onClick={closeSearch}
                        className="flex items-center justify-between p-3 border border-[#E8E4DC] hover:border-[#C5A880] hover:bg-[#FAF8F5] transition-colors group"
                      >
                        <div>
                          <h4 className="font-serif text-base text-[#18181D] group-hover:text-[#9A7B4F]">
                            {col.title}
                          </h4>
                          <p className="text-xs text-[#8C867D] font-sans">{col.tagline}</p>
                        </div>
                        <ChevronRightIcon className="w-4 h-4 text-[#C5A880] group-hover:translate-x-1 transition-transform" />
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 bg-[#FAF8F5] border-t border-[#E8E4DC] text-center text-[11px] text-[#8C867D] font-sans flex items-center justify-between px-6">
          <span>Press <kbd className="px-1.5 py-0.5 bg-white border border-[#E8E4DC] font-mono text-[10px]">ESC</kbd> to close</span>
          <Link href="/shop" onClick={closeSearch} className="text-[#9A7B4F] hover:underline">
            View All Gemstones In Vault &rarr;
          </Link>
        </div>
      </div>
    </div>
  );
}
