// AUTH_SECRET must be set in .env — no hardcoded fallback allowed
const AUTH_SECRET = process.env.AUTH_SECRET;
if (!AUTH_SECRET) {
  throw new Error("SECURITY ERROR: AUTH_SECRET environment variable is not set.");
}

export const SESSION_COOKIE_NAME = "faizan_admin_session";

export interface AdminSessionUser {
  jti?: string;
  email: string;
  name: string;
  role: "ADMIN";
  issuedAt: number;
  expiresAt: number;
}

/**
 * Pure Web Crypto token verification compatible with Next.js Edge / Proxy Middleware
 */
export async function verifySessionTokenEdge(
  token: string,
  secretOverride?: string
): Promise<AdminSessionUser | null> {
  try {
    const [payloadBase64, signatureBase64] = token.split(".");
    if (!payloadBase64 || !signatureBase64) return null;

    const secret = secretOverride || AUTH_SECRET!;
    const enc = new TextEncoder();
    const key = await globalThis.crypto.subtle.importKey(
      "raw",
      enc.encode(secret),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["verify"]
    );

    // Convert base64url to Uint8Array
    const base64 = signatureBase64.replace(/-/g, "+").replace(/_/g, "/");
    const pad = base64.length % 4;
    const padded = pad ? base64 + "=".repeat(4 - pad) : base64;
    const binary = atob(padded);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }

    const isValid = await globalThis.crypto.subtle.verify(
      "HMAC",
      key,
      bytes,
      enc.encode(payloadBase64)
    );

    if (!isValid) return null;

    const json = atob(payloadBase64.replace(/-/g, "+").replace(/_/g, "/"));
    const payload: AdminSessionUser = JSON.parse(json);

    if (payload.role !== "ADMIN" || Date.now() > payload.expiresAt) {
      return null;
    }

    return payload;
  } catch {
    return null;
  }
}

export const CUSTOMER_SESSION_COOKIE_NAME = "faizan_customer_session";

export interface CustomerSessionUser {
  id: string;
  email: string;
  name: string;
  phone?: string;
  role: "CUSTOMER";
  issuedAt: number;
  expiresAt: number;
}

export async function verifyCustomerSessionTokenEdge(
  token: string,
  secretOverride?: string
): Promise<CustomerSessionUser | null> {
  try {
    const [payloadBase64, signatureBase64] = token.split(".");
    if (!payloadBase64 || !signatureBase64) return null;

    const secret = secretOverride || AUTH_SECRET!;
    const enc = new TextEncoder();
    const key = await globalThis.crypto.subtle.importKey(
      "raw",
      enc.encode(secret),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["verify"]
    );

    const base64 = signatureBase64.replace(/-/g, "+").replace(/_/g, "/");
    const pad = base64.length % 4;
    const padded = pad ? base64 + "=".repeat(4 - pad) : base64;
    const binary = atob(padded);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }

    const isValid = await globalThis.crypto.subtle.verify(
      "HMAC",
      key,
      bytes,
      enc.encode(payloadBase64)
    );

    if (!isValid) return null;

    const json = atob(payloadBase64.replace(/-/g, "+").replace(/_/g, "/"));
    const payload: CustomerSessionUser = JSON.parse(json);

    if (payload.role !== "CUSTOMER" || Date.now() > payload.expiresAt) {
      return null;
    }

    return payload;
  } catch {
    return null;
  }
}
