"use client";

import { useState, useMemo } from "react";
import Image from "next/image";
import { toast } from "sonner";
import { format } from "date-fns";
import { 
  Banknote, 
  FileText, 
  Search, 
  DollarSign, 
  Briefcase, 
  Edit2, 
  UserPlus
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/page-header";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

import { generatePayslipsForMonth } from "@/actions/payroll";
import EditSalaryModal from "./edit-salary-modal";

type Compensation = {
  id: number;
  baseSalary: any; // Decimal from Prisma
  currency: string;
  effectiveDate: Date;
};

type Employee = {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  profileImage?: string | null;
  position?: { id: number; title: string } | null;
  compensations: Compensation[];
};

type PayrollClientProps = {
  employees: Employee[];
  totalPayroll: number;
  isAdmin: boolean;
};

export default function PayrollClient({
  employees,
  totalPayroll,
  isAdmin,
}: PayrollClientProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);

  const filteredEmployees = useMemo(() => {
    return employees.filter(emp => 
      `${emp.firstName} ${emp.lastName}`.toLowerCase().includes(searchQuery.toLowerCase()) ||
      emp.email.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [employees, searchQuery]);

  const handleGeneratePayroll = async () => {
    setIsGenerating(true);
    const date = new Date();
    const month = date.getMonth() + 1; // 1-12
    const year = date.getFullYear();

    const res = await generatePayslipsForMonth(month, year);
    if (res.error) {
      toast.error(res.error);
    } else {
      toast.success(`Generated ${res.generatedCount} payslips for ${format(date, "MMMM yyyy")}!`);
    }
    setIsGenerating(false);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <PageHeader 
        title="Payroll Management"
        description="Manage employee compensation and generate monthly payslips."
        actions={
          isAdmin ? (
            <Button 
              onClick={handleGeneratePayroll}
              disabled={isGenerating}
              className="gap-2 shadow-sm font-semibold cursor-pointer"
            >
              <FileText className="h-4 w-4" />
              <span>{isGenerating ? "Generating..." : "Generate Monthly Payslips"}</span>
            </Button>
          ) : null
        }
      />

      {/* Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-5 border-border bg-surface flex flex-col justify-between">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="h-5 w-5 text-primary" />
            <h3 className="font-semibold text-text-primary">Total Payroll Cost</h3>
          </div>
          <div className="text-3xl font-bold font-mono tracking-tight text-text-primary mt-2">
            {new Intl.NumberFormat('en-LK', { style: 'currency', currency: 'LKR' }).format(totalPayroll)}
          </div>
          <p className="text-xs text-text-muted mt-2">Estimated base pay for all active employees this month.</p>
        </Card>
      </div>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between bg-surface-secondary/40 p-3 rounded-xl border border-border">
        <div className="relative flex-1 min-w-[240px] max-w-sm">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-text-muted" />
          <Input
            type="text"
            placeholder="Search employees..."
            className="pl-10 bg-surface text-sm h-10 border-border/80"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {/* Data Table */}
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Employee</TableHead>
              <TableHead>Position</TableHead>
              <TableHead>Base Salary</TableHead>
              <TableHead>Effective Since</TableHead>
              {isAdmin && <TableHead className="text-right">Actions</TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
                {filteredEmployees.length ? (
                  filteredEmployees.map((emp) => {
                    const activeComp = emp.compensations[0];
                    
                    return (
                      <TableRow key={emp.id}>
                        <TableCell>
                        <div className="flex items-center gap-4">
                          <div className="relative flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-primary-soft to-primary-100 dark:from-primary-900 dark:to-primary-800 text-primary font-bold text-sm border-2 border-primary/20 overflow-hidden shrink-0 shadow-sm group-hover:scale-105 group-hover:border-primary/50 transition-all duration-300">
                            {emp.profileImage ? (
                              <Image src={emp.profileImage} alt="Profile" fill className="object-cover" />
                            ) : (
                              `${emp.firstName.charAt(0)}${emp.lastName.charAt(0)}`
                            )}
                          </div>
                          <div className="min-w-0">
                            <div className="font-semibold text-sm text-text-primary truncate">
                              {emp.firstName} {emp.lastName}
                            </div>
                            <div className="text-xs text-text-muted truncate font-mono">
                              {emp.email}
                            </div>
                          </div>
                        </div>
                        </TableCell>
                        <TableCell>
                        {emp.position ? (
                          <div className="flex items-center gap-1.5">
                            <Briefcase className="h-3.5 w-3.5 text-text-muted shrink-0" />
                            <span className="font-medium text-text-primary text-xs">{emp.position.title}</span>
                          </div>
                        ) : (
                          <span className="text-text-muted text-xs">Unassigned</span>
                        )}
                        </TableCell>
                        <TableCell>
                        {!activeComp ? (
                          <Badge variant="outline" className="text-xs">Not Set</Badge>
                        ) : (
                          <div className="font-mono text-sm font-semibold text-text-primary">
                            {new Intl.NumberFormat('en-LK', { style: 'currency', currency: activeComp.currency }).format(Number(activeComp.baseSalary))}
                            <span className="text-text-muted text-xs font-sans font-normal ml-1">/mo</span>
                          </div>
                        )}
                        </TableCell>
                        <TableCell>
                        {!activeComp ? (
                          <span className="text-text-muted">—</span>
                        ) : (
                          <span className="text-xs text-text-secondary">
                            {format(new Date(activeComp.effectiveDate), "MMM dd, yyyy")}
                          </span>
                        )}
                        </TableCell>
                        {isAdmin && (
                          <TableCell className="text-right">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => setSelectedEmployee(emp)}
                            className="gap-1.5 h-8 text-xs cursor-pointer transition-all duration-300 hover:bg-surface hover:border-primary/50 shadow-sm"
                          >
                            <Edit2 className="h-3.5 w-3.5" />
                            <span>Update Salary</span>
                          </Button>
                          </TableCell>
                        )}
                      </TableRow>
                    );
                  })
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="h-24 text-center text-text-muted">
                      No employees found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>

      {/* Edit Salary Modal */}
      {selectedEmployee && (
        <EditSalaryModal 
          employee={selectedEmployee} 
          onClose={() => setSelectedEmployee(null)} 
        />
      )}
    </div>
  );
}
