"use client";

import React, { useRef } from "react";
import { Printer, X, ShoppingCart, ArrowRight, FileText, Calendar, Building, User, CheckCircle2, Clock, AlertTriangle, Ban } from "lucide-react";
import { Dialog } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { QuotationItem } from "../types";
import { useCurrency } from "@/hooks/use-currency";
import { cn } from "@/lib/utils";

interface QuotationPreviewDialogProps {
  isOpen: boolean;
  onClose: () => void;
  quotation: QuotationItem | null;
  onConvert?: (quotation: QuotationItem) => void;
  canConvert?: boolean;
}

export function QuotationPreviewDialog({
  isOpen,
  onClose,
  quotation,
  onConvert,
  canConvert = true,
}: QuotationPreviewDialogProps) {
  const printRef = useRef<HTMLDivElement>(null);
  const { format } = useCurrency(quotation?.businessId || "");

  if (!quotation) return null;

  const handlePrint = () => {
    window.print();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "CONVERTED":
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-sm bg-emerald-500/15 text-emerald-400 text-xs font-bold border border-emerald-500/30">
            <CheckCircle2 className="h-3.5 w-3.5" /> Converted to Sale
          </span>
        );
      case "EXPIRED":
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-sm bg-rose-500/15 text-rose-400 text-xs font-bold border border-rose-500/30">
            <AlertTriangle className="h-3.5 w-3.5" /> Expired
          </span>
        );
      case "CANCELLED":
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-sm bg-destructive/15 text-destructive text-xs font-bold border border-destructive/30">
            <Ban className="h-3.5 w-3.5" /> Cancelled
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-sm bg-amber-500/15 text-amber-400 text-xs font-bold border border-amber-500/30">
            <Clock className="h-3.5 w-3.5" /> Pending
          </span>
        );
    }
  };

  return (
    <Dialog isOpen={isOpen} onClose={onClose} title={`Quotation ${quotation.quotationNumber}`} size="3xl">
      <div className="space-y-4 py-2">
        {/* Top Actions Bar (Hidden on print) */}
        <div className="flex items-center justify-between pb-3 border-b border-border print:hidden">
          <div className="flex items-center gap-2">
            {getStatusBadge(quotation.status)}
            {quotation.convertedSale && (
              <span className="text-xs text-muted-foreground">
                Invoice: <strong className="text-foreground">{quotation.convertedSale.invoiceNumber}</strong>
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handlePrint}
              className="h-8 text-xs flex items-center gap-1.5 rounded-sm border-border hover:bg-secondary"
            >
              <Printer className="h-3.5 w-3.5" />
              Print Quotation
            </Button>

            {canConvert && quotation.status === "PENDING" && onConvert && (
              <Button
                type="button"
                size="sm"
                onClick={() => onConvert(quotation)}
                className="h-8 text-xs font-bold bg-primary text-black hover:bg-primary/90 flex items-center gap-1.5 rounded-sm"
              >
                <ShoppingCart className="h-3.5 w-3.5" />
                Convert to Sale
              </Button>
            )}
          </div>
        </div>

        {/* Printable Document Container */}
        <div
          ref={printRef}
          className="bg-card print:bg-white text-card-foreground print:text-black p-6 sm:p-8 rounded-sm border border-border print:border-none shadow-sm space-y-6"
        >
          {/* Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4 border-b border-border/80 pb-6">
            <div>
              <span className="text-2xl font-black tracking-tight text-primary print:text-black">
                {quotation.branch?.name || "Store"}
              </span>
              <p className="text-xs text-muted-foreground print:text-gray-600 mt-1 max-w-sm">
                {quotation.branch?.address || "Main Branch"}
              </p>
              {quotation.branch?.phone && (
                <p className="text-xs text-muted-foreground print:text-gray-600">
                  Phone: {quotation.branch.phone}
                </p>
              )}
            </div>

            <div className="text-left sm:text-right space-y-1">
              <span className="text-xl font-black uppercase tracking-wider text-foreground print:text-black block">
                PRICE ESTIMATE / QUOTATION
              </span>
              <p className="text-sm font-mono font-bold text-primary print:text-black">
                {quotation.quotationNumber}
              </p>
              <div className="text-xs text-muted-foreground print:text-gray-600 space-y-0.5 pt-1 font-mono">
                <div>Date: {new Date(quotation.date).toLocaleDateString()}</div>
                {quotation.createdBy?.name && (
                  <div>By: {quotation.createdBy.name}</div>
                )}
                {quotation.expiryDate && (
                  <div className="text-amber-500 print:text-black font-semibold">
                    Valid Until: {new Date(quotation.expiryDate).toLocaleDateString()}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Customer Details */}
          <div className="p-4 rounded-sm bg-muted/30 print:bg-gray-50 border border-border/60 print:border-gray-200">
            <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground print:text-gray-500 block mb-1">
              Quotation Issued To:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div>
                <strong className="text-sm font-bold text-foreground print:text-black block">
                  {quotation.customer?.name}
                </strong>
                {quotation.customer?.address && (
                  <p className="text-muted-foreground print:text-gray-600 mt-0.5">{quotation.customer.address}</p>
                )}
              </div>
              <div className="sm:text-right space-y-0.5 text-muted-foreground print:text-gray-600">
                {quotation.customer?.phone && <div>Phone: {quotation.customer.phone}</div>}
                {quotation.customer?.email && <div>Email: {quotation.customer.email}</div>}
                {quotation.customer?.taxNumber && <div>Tax ID / GST: {quotation.customer.taxNumber}</div>}
              </div>
            </div>
          </div>

          {/* Line Items Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b-2 border-border print:border-gray-400 font-bold uppercase text-muted-foreground print:text-gray-700">
                  <th className="py-2.5 pl-2 w-8">#</th>
                  <th className="py-2.5">Item Description</th>
                  <th className="py-2.5 text-right">Qty</th>
                  <th className="py-2.5 text-right">Unit Price</th>
                  {quotation.discountAmount > 0 && <th className="py-2.5 text-right">Discount</th>}
                  <th className="py-2.5 pr-2 text-right">Subtotal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50 print:divide-gray-200">
                {quotation.quotationLines.map((line, idx) => (
                  <tr key={idx} className="hover:bg-muted/10 print:hover:bg-transparent">
                    <td className="py-3 pl-2 text-muted-foreground font-mono">{idx + 1}</td>
                    <td className="py-3 font-medium">
                      <div className="text-foreground print:text-black font-semibold">
                        {line.variant?.product?.name || line.variant?.name || "Product"}
                      </div>
                      {line.variant?.sku && (
                        <span className="text-[10px] text-muted-foreground print:text-gray-500 font-mono">
                          SKU: {line.variant.sku}
                        </span>
                      )}
                    </td>
                    <td className="py-3 text-right font-mono font-semibold">{line.quantity}</td>
                    <td className="py-3 text-right font-mono">{format(line.unitPrice)}</td>
                    {quotation.discountAmount > 0 && (
                      <td className="py-3 text-right font-mono text-muted-foreground">
                        {line.discountAmount ? format(line.discountAmount) : "-"}
                      </td>
                    )}
                    <td className="py-3 pr-2 text-right font-mono font-bold text-foreground print:text-black">
                      {format(line.subtotal)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals Summary */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pt-4 border-t border-border">
            {/* Notes & Terms */}
            <div className="space-y-3 max-w-md text-xs">
              {quotation.termsAndConditions && (
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground print:text-gray-600 block">
                    Terms & Conditions:
                  </span>
                  <p className="text-muted-foreground print:text-gray-700 whitespace-pre-line mt-1">
                    {quotation.termsAndConditions}
                  </p>
                </div>
              )}
              {quotation.notes && (
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground print:text-gray-600 block">
                    Notes / Remarks:
                  </span>
                  <p className="text-muted-foreground print:text-gray-700 whitespace-pre-line mt-1">
                    {quotation.notes}
                  </p>
                </div>
              )}
            </div>

            {/* Calculations Box */}
            <div className="w-full sm:w-72 space-y-2 text-xs font-medium">
              <div className="flex justify-between py-1 border-b border-border/50 text-muted-foreground print:text-gray-700">
                <span>Total Items:</span>
                <span className="font-mono font-bold text-foreground print:text-black">
                  {quotation.quotationLines.reduce((acc, l) => acc + l.quantity, 0)}
                </span>
              </div>
              {quotation.discountAmount > 0 && (
                <div className="flex justify-between py-1 border-b border-border/50 text-emerald-500">
                  <span>Discount:</span>
                  <span className="font-mono font-bold">-{format(quotation.discountAmount)}</span>
                </div>
              )}
              {quotation.taxAmount > 0 && (
                <div className="flex justify-between py-1 border-b border-border/50 text-muted-foreground print:text-gray-700">
                  <span>Tax:</span>
                  <span className="font-mono font-bold">+{format(quotation.taxAmount)}</span>
                </div>
              )}
              <div className="flex justify-between py-2 border-t-2 border-border print:border-black text-base font-black">
                <span className="text-foreground print:text-black">Grand Total:</span>
                <span className="text-primary print:text-black font-mono">{format(quotation.grandTotal)}</span>
              </div>
            </div>
          </div>

          {/* Signatures */}
          <div className="grid grid-cols-2 gap-8 pt-10 mt-6 border-t border-dashed border-border/80 text-xs text-muted-foreground print:text-gray-600 text-center">
            <div>
              <div className="border-b border-border print:border-gray-400 w-40 mx-auto mb-1.5 h-10" />
              <span>Customer Signature / Acceptance</span>
            </div>
            <div>
              <div className="border-b border-border print:border-gray-400 w-40 mx-auto mb-1.5 h-10" />
              <span>Authorized Store Signatory</span>
            </div>
          </div>
        </div>
      </div>
    </Dialog>
  );
}
