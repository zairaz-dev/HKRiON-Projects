export interface BranchItem {
  id: string;
  name: string;
}

export interface CategoryItem {
  id: string;
  name: string;
}

export interface BrandItem {
  id: string;
  name: string;
}

export interface UnitItem {
  id: string;
  name: string;
  code: string;
}

export interface WarrantyItem {
  id: string;
  name: string;
  duration: number;
  durationType: string;
}

export interface SPGItem {
  id: string;
  name: string;
}

export interface VariationValueItem {
  id: string;
  value: string;
}

export interface VariationItem {
  id: string;
  name: string;
  values: VariationValueItem[];
}

export interface ProductBranchItem {
  branchId: string;
  branch: BranchItem;
}

export interface GroupPriceItem {
  sellingPriceGroupId: string;
  price: number;
  sellingPriceGroup?: SPGItem;
}

export interface VariantValueMapItem {
  valueId: string;
  value: VariationValueItem;
}

export interface PurchaseLineItem {
  id?: string;
  quantityRemaining: number;
  branchId: string;
  batchNumber?: string | null;
  quantityPurchased?: number;
  purchasePrice?: number;
  sellingPrice?: number;
  createdAt?: string;
  branch?: BranchItem;
  purchase?: {
    id: string;
    purchaseNumber: string;
    purchaseDate: string;
    supplier?: { id: string; name: string };
    branch?: BranchItem;
  };
}

export interface SaleLineHistoryItem {
  id: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
  imeiNumber?: string | null;
  createdAt: string;
  branch?: BranchItem;
  sale?: {
    id: string;
    invoiceNumber: string;
    saleDate: string;
    customer?: { id: string; name: string };
    branch?: BranchItem;
  };
}

export interface StockAdjustmentHistoryItem {
  id: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
  createdAt: string;
  branch?: BranchItem;
  stockAdjustment?: {
    id: string;
    adjustmentNumber: string;
    adjustmentDate: string;
    type: string;
    reason?: string;
    branch?: BranchItem;
  };
}

export interface StockTransferHistoryItem {
  id: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
  createdAt: string;
  stockTransfer?: {
    id: string;
    transferNumber: string;
    transferDate: string;
    status: string;
    fromBranch?: BranchItem;
    toBranch?: BranchItem;
  };
}

export interface ProductImeiItem {
  id: string;
  imeiNumber: string;
  status: string; // 'IN_STOCK' | 'SOLD' | 'RETURNED' | 'DEFECTIVE'
  branchId: string;
  branch?: BranchItem;
  purchaseDate?: string | null;
  soldDate?: string | null;
  warrantyExpires?: string | null;
  notes?: string | null;
  createdAt: string;
}

export interface ProductVariantItem {
  id?: string;
  name: string;
  sku: string;
  barcode: string | null;
  purchasePrice: number;
  sellingPrice: number;
  valueMaps?: VariantValueMapItem[];
  groupPrices?: GroupPriceItem[];
  purchaseLines?: PurchaseLineItem[];
  saleLines?: SaleLineHistoryItem[];
  stockAdjustmentLines?: StockAdjustmentHistoryItem[];
  stockTransferLines?: StockTransferHistoryItem[];
  openingStock?: number;
  openingStockBranchId?: string;
  // Temporary fields for form state
  valueIds?: string[];
}

export interface ProductItem {
  id: string;
  name: string;
  description: string | null;
  imageUrl: string | null;
  type: "SINGLE" | "VARIABLE";
  isActive: boolean;
  enableStock: boolean;
  enableImei?: boolean;
  isImei?: boolean;
  alertQuantity: number;
  notForSelling: boolean;
  weight: number | null;
  businessId: string;
  categoryId: string | null;
  brandId: string | null;
  unitId: string | null;
  warrantyId: string | null;
  category?: CategoryItem | null;
  brand?: BrandItem | null;
  unit?: UnitItem | null;
  warranty?: WarrantyItem | null;
  branches?: ProductBranchItem[];
  variants: ProductVariantItem[];
  productImeis?: ProductImeiItem[];
  createdBy?: { id: string; name: string; email: string } | null;
  updatedBy?: { id: string; name: string; email: string } | null;
  createdAt?: string;
  updatedAt?: string;
}
