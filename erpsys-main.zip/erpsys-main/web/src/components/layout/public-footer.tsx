"use strict";
"use client";

import React from "react";
import { Layers, Github, Twitter, Linkedin, Mail, Heart, Sparkles } from "lucide-react";
import Link from "next/link";

export function PublicFooter() {
  const currentYear = new Date().getFullYear();

  const erpModuleLinks = [
    { name: "Point of Sale (POS)", href: "/#features" },
    { name: "IMEI & Serial Tracking", href: "/#features" },
    { name: "Multi-Branch Sync", href: "/#features" },
    { name: "Pricing & Plans", href: "/pricing" },
  ];

  const companyLinks = [
    { name: "About Us", href: "/about" },
    { name: "Contact Support", href: "/contact" },
    { name: "Changelog & Releases", href: "/posts" },
    { name: "Partner Program", href: "/contact" },
  ];

  const legalLinks = [
    { name: "Privacy Policy", href: "/privacy" },
    { name: "Terms of Service", href: "/terms" },
    { name: "Refund Policy", href: "/refund" },
    { name: "Data Security & SLA", href: "/privacy" },
  ];

  return (
    <footer className="relative z-10 border-t border-border bg-card/40 backdrop-blur-md pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Upper Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-border/60">
          
          {/* Brand Column (5 cols) */}
          <div className="md:col-span-5 space-y-4">
            <Link href="/">
              <div className="flex items-center gap-2.5 group cursor-pointer">
                <div className="w-8 h-8 flex items-center justify-center group-hover:scale-105 transition-transform duration-200 shrink-0">
                  <img
                    src="/logo.png"
                    alt="HKRiON ERP Logo"
                    className="w-full h-full object-contain"
                  />
                </div>
                <span className="text-sm font-extrabold tracking-tight text-foreground font-mono">
                  HKRiON <span className="text-primary">ERP</span>
                </span>
              </div>
            </Link>
            <p className="text-xs text-muted-foreground max-w-sm leading-relaxed">
              An ultra-performance, modular ERP architecture designed for retail, wholesale, and multi-branch inventory excellence. Built for Sri Lankan and Global enterprises.
            </p>
            {/* Social Icons */}
            <div className="flex items-center gap-4 pt-2">
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Github className="w-4 h-4" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Linkedin className="w-4 h-4" />
              </a>
              <a href="mailto:support@hkrion.com" className="text-muted-foreground hover:text-primary transition-colors">
                <Mail className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Links Columns (7 cols) */}
          <div className="md:col-span-7 grid grid-cols-3 gap-6">
            
            {/* ERP Modules Column */}
            <div className="space-y-3">
              <h4 className="text-[10px] font-bold text-foreground/80 uppercase tracking-wider font-mono">
                ERP Modules
              </h4>
              <ul className="space-y-2 text-xs">
                {erpModuleLinks.map((link, idx) => (
                  <li key={idx}>
                    <Link href={link.href}>
                      <span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">
                        {link.name}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Company Column */}
            <div className="space-y-3">
              <h4 className="text-[10px] font-bold text-foreground/80 uppercase tracking-wider font-mono">
                Company
              </h4>
              <ul className="space-y-2 text-xs">
                {companyLinks.map((link, idx) => (
                  <li key={idx}>
                    <Link href={link.href}>
                      <span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">
                        {link.name}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Legal Column */}
            <div className="space-y-3">
              <h4 className="text-[10px] font-bold text-foreground/80 uppercase tracking-wider font-mono">
                Legal
              </h4>
              <ul className="space-y-2 text-xs">
                {legalLinks.map((link, idx) => (
                  <li key={idx}>
                    <Link href={link.href}>
                      <span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">
                        {link.name}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

          </div>
        </div>

        {/* Lower Footer (Copyright) */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-8 text-xs text-muted-foreground">
          <p className="font-mono flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            &copy; {currentYear} HKR ION ERP. All systems operational.
          </p>
          <p className="flex items-center gap-1">
            Made with <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 mx-0.5" /> by{" "}
            <a
              href="https://hkrion.com/"
              target="_blank"
              rel="noopener noreferrer"
              className="font-bold text-foreground hover:text-primary transition-colors underline-offset-4 hover:underline"
            >
              HKRiON
            </a>
            .
          </p>
        </div>

      </div>
    </footer>
  );
}
