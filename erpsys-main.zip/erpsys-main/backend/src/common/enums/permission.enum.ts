export enum Permission {
  // Inventory & Products
  PRODUCT_VIEW = 'inventory:view',
  PRODUCT_CREATE = 'inventory:add_product',
  PRODUCT_UPDATE = 'inventory:edit_product',
  PRODUCT_DELETE = 'inventory:delete_product',
  STOCK_ADJUST = 'inventory:adjust_stock',
  STOCK_TRANSFER = 'inventory:transfer_stock',

  // Categories & Brands
  CATEGORY_VIEW = 'inventory:view',
  CATEGORY_CREATE = 'inventory:add_product',
  CATEGORY_UPDATE = 'inventory:edit_product',
  CATEGORY_DELETE = 'inventory:delete_product',

  BRAND_VIEW = 'inventory:view',
  BRAND_CREATE = 'inventory:add_product',
  BRAND_UPDATE = 'inventory:edit_product',
  BRAND_DELETE = 'inventory:delete_product',

  // Contacts (Customers & Suppliers)
  CUSTOMER_VIEW = 'contacts:view',
  CUSTOMER_CREATE = 'contacts:create',
  CUSTOMER_UPDATE = 'contacts:edit',
  CUSTOMER_DELETE = 'contacts:delete',

  SUPPLIER_VIEW = 'contacts:view',
  SUPPLIER_CREATE = 'contacts:create',
  SUPPLIER_UPDATE = 'contacts:edit',
  SUPPLIER_DELETE = 'contacts:delete',

  // Purchases & Procurement
  PURCHASE_VIEW = 'purchases:view',
  PURCHASE_CREATE = 'purchases:create',
  PURCHASE_UPDATE = 'purchases:edit',
  PURCHASE_DELETE = 'purchases:delete',

  // Point of Sale & Sales
  SALE_VIEW = 'pos:view',
  SALE_CREATE = 'pos:create_transaction',
  SALE_VOID = 'pos:void_transaction',
  SALE_REFUND = 'pos:refund',
  POS_EDIT_PRICE = 'pos:edit_price',
  POS_APPLY_DISCOUNT = 'pos:apply_discount',
  POS_CREDIT_SALE = 'pos:credit_sale',
  POS_HOLD_SALE = 'pos:hold_sale',
  POS_DRAFT_SALE = 'pos:hold_sale',
  POS_QUICK_ADD_PRODUCT = 'pos:quick_add_product',
  POS_CLOSE_REGISTER = 'pos:close_register',
  POS_REPRINT_RECEIPT = 'pos:reprint_receipt',

  // Quotations (Estimates)
  QUOTATION_VIEW = 'quotations:view',
  QUOTATION_CREATE = 'quotations:create',
  QUOTATION_EDIT = 'quotations:edit',
  QUOTATION_DELETE = 'quotations:delete',

  // Finance & Accounting
  LEDGER_VIEW = 'finance:view_ledger',
  EXPENSE_ADD = 'finance:add_expense',
  REPORT_VIEW = 'finance:view_reports',

  // System & Store Settings
  SETTINGS_VIEW = 'settings:view',
  SETTINGS_EDIT = 'settings:edit',

  // User & HR Management
  USER_VIEW = 'users:view',
  USER_CREATE = 'users:create',
  USER_UPDATE = 'users:edit',
  USER_DELETE = 'users:delete',
  USER_MANAGE = 'users:manage_permissions',

  // Super Admin
  SUPER_MANAGE_BUSINESSES = 'super:manage_businesses',
  SUPER_VIEW_ANALYTICS = 'super:view_analytics',
  SUPER_MANAGE_SUBSCRIPTIONS = 'super:manage_subscriptions',
}

