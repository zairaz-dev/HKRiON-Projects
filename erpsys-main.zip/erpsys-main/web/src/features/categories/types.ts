export interface BranchItem {
  id: string;
  name: string;
}

export interface CategoryBranchItem {
  branchId: string;
  branch: {
    id: string;
    name: string;
  };
}

export interface CategoryItem {
  id: string;
  name: string;
  description: string | null;
  imageUrl: string | null;
  color?: string | null;
  isActive: boolean;
  parentId: string | null;
  businessId: string;
  createdAt: string;
  updatedAt: string;
  parent?: CategoryItem | null;
  subCategories?: CategoryItem[];
  branches?: CategoryBranchItem[];
}
