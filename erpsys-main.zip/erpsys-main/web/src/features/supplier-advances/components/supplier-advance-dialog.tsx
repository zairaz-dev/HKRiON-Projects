import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { X, Loader2, Coins } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { User } from "@hkr/types";
import { SupplierItem } from "@/features/suppliers/types";
import { useCreateSupplierAdvanceMutation } from "../hooks/use-supplier-advances";
import { usePaymentMethodsQuery } from "@/features/payment-methods/hooks/use-payment-methods";
import { useBranchesQuery } from "@/features/suppliers/hooks/use-suppliers";
import { useCurrency } from "@/hooks/use-currency";

interface SupplierAdvanceDialogProps {
  isOpen: boolean;
  onClose: () => void;
  supplier: SupplierItem;
  currentUser: User;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

export function SupplierAdvanceDialog({
  isOpen,
  onClose,
  supplier,
  currentUser,
  onSuccess,
  onError,
}: SupplierAdvanceDialogProps) {
  const { symbol } = useCurrency(currentUser?.businessId);
  const createMutation = useCreateSupplierAdvanceMutation();
  const [selectedBranchId, setSelectedBranchId] = useState<string>("");

  // Query branches
  const { data: branches = [], isLoading: branchesLoading } = useBranchesQuery(
    currentUser?.businessId || "",
    currentUser?.id
  );

  // Query payment methods for selected branch
  const { data: paymentMethods = [], isLoading: methodsLoading } = usePaymentMethodsQuery(
    currentUser?.businessId || "",
    selectedBranchId || undefined,
    true
  );

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { errors },
  } = useForm({
    defaultValues: {
      amount: 0,
      advanceDate: new Date().toISOString().split("T")[0],
      paymentMethodId: "",
      transactionNo: "",
      notes: "",
    },
  });

  // Prefill default branch
  useEffect(() => {
    if (branches.length > 0 && !selectedBranchId) {
      setSelectedBranchId(branches[0].id);
    }
  }, [branches, selectedBranchId]);

  // Set default values when dialog opens
  useEffect(() => {
    if (isOpen) {
      reset({
        amount: 0,
        advanceDate: new Date().toISOString().split("T")[0],
        paymentMethodId: paymentMethods[0]?.id || "",
        transactionNo: "",
        notes: "",
      });
    }
  }, [isOpen, reset, paymentMethods]);

  // Update paymentMethodId once payment methods load
  useEffect(() => {
    if (paymentMethods.length > 0) {
      setValue("paymentMethodId", paymentMethods[0].id);
    }
  }, [paymentMethods, setValue]);

  if (!isOpen) return null;

  const onSubmit = async (data: any) => {
    if (!currentUser.businessId) return;
    if (!selectedBranchId) {
      onError("Please select a branch.");
      return;
    }

    const payload = {
      amount: Number(data.amount),
      advanceDate: new Date(data.advanceDate).toISOString(),
      supplierId: supplier.id,
      paymentMethodId: data.paymentMethodId,
      branchId: selectedBranchId,
      businessId: currentUser.businessId,
      transactionNo: data.transactionNo?.trim() || undefined,
      notes: data.notes?.trim() || undefined,
      createdById: currentUser.id,
    };

    try {
      await createMutation.mutateAsync(payload);
      onSuccess("Supplier advance payment recorded successfully!");
      onClose();
    } catch (err: any) {
      onError(err.message || "Failed to record advance payment.");
    }
  };

  const isLoading = createMutation.isPending || branchesLoading || methodsLoading;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-card border border-border rounded-sm shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between border-b border-border p-5 bg-background/40">
          <h2 className="text-lg font-bold text-foreground flex items-center gap-2">
            <Coins className="h-5 w-5 text-primary" /> Record Supplier Advance
          </h2>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-5 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Supplier details info */}
          <div className="p-3 bg-secondary/50 rounded-sm border border-border/40 text-xs">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Supplier Name:</span>
              <span className="font-semibold">{supplier.name}</span>
            </div>
            <div className="flex justify-between mt-1">
              <span className="text-muted-foreground">Outstanding Due:</span>
              <span className="font-bold text-rose-500">{symbol}{(supplier.outstandingDue || 0).toFixed(2)}</span>
            </div>
          </div>

          {/* Branch Select */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide">Select Branch</label>
            <select
              value={selectedBranchId}
              onChange={(e) => setSelectedBranchId(e.target.value)}
              className="w-full bg-background border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
            >
              {branches.map((b: any) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </select>
          </div>

          {/* Amount input */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide">Advance Amount ({symbol})</label>
            <Input
              type="number"
              step="0.01"
              placeholder="0.00"
              {...register("amount", { required: true, min: 0.01 })}
              className="w-full"
            />
            {errors.amount && (
              <p className="text-[10px] text-destructive font-semibold">Please enter a valid amount greater than zero.</p>
            )}
          </div>

          {/* Date Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide">Advance Date</label>
            <Input
              type="date"
              {...register("advanceDate", { required: true })}
              className="w-full"
            />
          </div>

          {/* Payment Method Select */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide">Payment Method</label>
            <select
              {...register("paymentMethodId", { required: true })}
              className="w-full bg-background border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
            >
              {paymentMethods.map((pm: any) => (
                <option key={pm.id} value={pm.id}>
                  {pm.name}
                </option>
              ))}
            </select>
            {paymentMethods.length === 0 && !methodsLoading && (
              <p className="text-[10px] text-amber-500 font-semibold">No active payment methods found for this branch.</p>
            )}
          </div>

          {/* Transaction Number */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide">Reference / Trans No</label>
            <Input
              placeholder="e.g. UPI / Cheque Number"
              {...register("transactionNo")}
              className="w-full"
            />
          </div>

          {/* Notes */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide">Notes / Description</label>
            <textarea
              placeholder="Write any additional details..."
              rows={2}
              {...register("notes")}
              className="w-full bg-background border border-border rounded p-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
            />
          </div>

          {/* Footer Action buttons */}
          <div className="flex justify-end gap-2 border-t border-border pt-4 mt-2">
            <Button
              type="button"
              variant="ghost"
              onClick={onClose}
              className="text-xs font-bold"
              disabled={createMutation.isPending}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="text-xs font-bold px-4"
              disabled={isLoading || paymentMethods.length === 0}
            >
              {createMutation.isPending ? (
                <>
                  <Loader2 className="h-3 w-3 animate-spin mr-1.5" /> Recording...
                </>
              ) : (
                "Save Advance"
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
