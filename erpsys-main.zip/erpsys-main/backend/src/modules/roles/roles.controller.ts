import { Controller, Post, Body, Get, Put, Delete, Query, Param, UseGuards, Req } from '@nestjs/common';
import { RolesService } from './roles.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';
import { ApiTags, ApiOperation, ApiBody, ApiResponse, ApiBearerAuth, ApiQuery, ApiParam } from '@nestjs/swagger';
import {
  GetPermissionsResponseSchema,
  SavePermissionsBodySchema,
  CreateRoleBodySchema,
  UpdateRoleBodySchema,
  RoleResponseSchema,
  RolesListResponseSchema,
  DeleteRoleResponseSchema,
} from '../../docs/roles.docs';

@ApiTags('Auth')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Permissions(Permission.USER_MANAGE)
@Controller('auth')
export class RolesController {
  constructor(private readonly rolesService: RolesService) {}

  @Get('permissions')
  @ApiOperation({ summary: 'Get role permissions map for business' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiResponse({
    status: 200,
    description: 'Permissions retrieved successfully',
    schema: GetPermissionsResponseSchema,
  })
  async getPermissions(
    @Req() req: any,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.rolesService.getRolePermissions(bId);
  }

  @Post('permissions')
  @ApiOperation({ summary: 'Save / update role permissions' })
  @ApiBody({ schema: SavePermissionsBodySchema })
  @ApiResponse({
    status: 201,
    description: 'Role permissions saved successfully',
  })
  async savePermissions(
    @Req() req: any,
    @Body() body: { permissions: any; businessId?: string },
  ) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }
    return this.rolesService.saveRolePermissions(body.permissions, body.businessId);
  }

  @Get('roles')
  @ApiOperation({ summary: 'Get all custom & system roles' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiResponse({
    status: 200,
    description: 'Roles retrieved successfully',
    schema: RolesListResponseSchema,
  })
  async getRoles(
    @Req() req: any,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.rolesService.getRoles(bId);
  }

  @Post('roles')
  @ApiOperation({ summary: 'Create custom business role' })
  @ApiBody({ schema: CreateRoleBodySchema })
  @ApiResponse({
    status: 201,
    description: 'Role created successfully',
    schema: RoleResponseSchema,
  })
  async createRole(
    @Req() req: any,
    @Body() body: { role: string; name: string; description?: string; permissions: string[]; businessId?: string; createdById?: string },
  ) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }
    if (!body.createdById) {
      body.createdById = user.id;
    }
    return this.rolesService.createRole(body, body.businessId);
  }

  @Put('roles/:id')
  @ApiOperation({ summary: 'Update custom role details & permissions' })
  @ApiParam({ name: 'id', description: 'Role UUID' })
  @ApiBody({ schema: UpdateRoleBodySchema })
  @ApiResponse({
    status: 200,
    description: 'Role updated successfully',
    schema: RoleResponseSchema,
  })
  async updateRole(
    @Req() req: any,
    @Param('id') id: string,
    @Body() body: { name?: string; description?: string; permissions?: string[]; businessId?: string; updatedById?: string },
  ) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }
    if (!body.updatedById) {
      body.updatedById = user.id;
    }
    return this.rolesService.updateRole(id, body, body.businessId);
  }

  @Delete('roles/:id')
  @ApiOperation({ summary: 'Delete custom role' })
  @ApiParam({ name: 'id', description: 'Role UUID' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiResponse({
    status: 200,
    description: 'Role deleted successfully',
    schema: DeleteRoleResponseSchema,
  })
  async deleteRole(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.rolesService.deleteRole(id, bId);
  }
}
