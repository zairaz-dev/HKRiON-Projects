"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Percent,
  ChevronLeft,
  Loader2,
  CheckCircle,
  AlertCircle,
  Plus,
  Edit2,
  Trash2,
  Settings,
  Layers,
  Save
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";

// Business feature hooks & schemas for general settings tab
import { useBusinessQuery, useUpdateBusinessMutation } from "@/features/business";

// Taxes feature hooks, types and dialogs
import {
  TaxRateItem,
  TaxGroupItem,
  useTaxRatesQuery,
  useTaxGroupsQuery,
  TaxRateDialog,
  TaxGroupDialog,
  TaxDeleteDialog
} from "@/features/taxes";

function TaxSettingsPageContent() {
  const router = useRouter();
  
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Notifications
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Tabs
  const [activeTab, setActiveTab] = useState<"general" | "rates" | "groups">("general");

  // Dialog states
  const [isRateDialogOpen, setIsRateDialogOpen] = useState(false);
  const [selectedRate, setSelectedRate] = useState<TaxRateItem | null>(null);

  const [isGroupDialogOpen, setIsGroupDialogOpen] = useState(false);
  const [selectedGroup, setSelectedGroup] = useState<TaxGroupItem | null>(null);

  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [deleteItem, setDeleteItem] = useState<TaxRateItem | TaxGroupItem | null>(null);
  const [deleteType, setDeleteType] = useState<"rate" | "group">("rate");

  // Authenticate user
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  const businessId = currentUser?.businessId || "";

  // Queries & Mutations
  const { data: businessData, isLoading: isBusinessLoading } = useBusinessQuery(businessId);
  const updateBusinessMutation = useUpdateBusinessMutation();

  const { data: taxRates = [], isLoading: isRatesLoading } = useTaxRatesQuery(businessId);
  const { data: taxGroups = [], isLoading: isGroupsLoading } = useTaxGroupsQuery(businessId);

  // Form for General Settings
  const {
    register: registerGeneral,
    handleSubmit: handleSubmitGeneral,
    setValue: setGeneralValue,
    reset: resetGeneral,
    watch: watchGeneral,
  } = useForm({
    defaultValues: {
      taxNumber: "",
      taxName: "",
      isTaxEnabled: true,
    },
  });

  const isTaxEnabledWatch = watchGeneral("isTaxEnabled");

  // Populate general tax settings from business info
  useEffect(() => {
    if (businessData) {
      resetGeneral({
        taxNumber: businessData.taxNumber || "",
        taxName: businessData.taxName || "",
        isTaxEnabled: (businessData as any).isTaxEnabled ?? true,
      });
    }
  }, [businessData, resetGeneral]);

  // Success/Error auto-dismiss timers
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  const handleGeneralSubmit = async (data: any) => {
    if (!businessId || !currentUser) return;

    try {
      await updateBusinessMutation.mutateAsync({
        id: businessId,
        data: {
          taxNumber: data.taxNumber.trim() || null,
          taxName: data.taxName.trim() || null,
          isTaxEnabled: Boolean(data.isTaxEnabled),
          updatedById: currentUser.id,
        } as any,
      });
      setSuccessMessage("General tax settings updated successfully!");
    } catch (err: any) {
      setError(err.message || "Failed to update general settings.");
    }
  };

  const showSuccess = (msg: string) => setSuccessMessage(msg);
  const showError = (msg: string) => setError(msg);

  if (isAuthenticated === null || !currentUser) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/settings" />
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Decorative background glow */}
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-primary/5 blur-[120px] pointer-events-none z-0" />

        <Navbar title="Tax Settings" className="relative z-10" />

        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 relative z-10">
          <div className="max-w-4xl mx-auto space-y-6">
            
            {/* Header & Back Navigation */}
            <div className="flex flex-col gap-4">
              <button
                onClick={() => router.push("/settings")}
                className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-primary transition-colors w-fit font-medium"
              >
                <ChevronLeft className="h-4 w-4" /> Back to Settings
              </button>

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                    <Percent className="h-7 w-7 text-primary" /> Tax Settings
                  </h1>
                  <p className="text-sm text-muted-foreground mt-1">
                    Manage business tax registration info, tax rates, and split tax groups.
                  </p>
                </div>
                
                {/* Actions depending on active tab */}
                {activeTab === "rates" && (
                  <Button
                    onClick={() => {
                      setSelectedRate(null);
                      setIsRateDialogOpen(true);
                    }}
                    className="text-xs px-4 py-2 gap-1.5 h-9 w-fit"
                  >
                    <Plus className="h-4 w-4" /> Add Tax Rate
                  </Button>
                )}

                {activeTab === "groups" && (
                  <Button
                    onClick={() => {
                      setSelectedGroup(null);
                      setIsGroupDialogOpen(true);
                    }}
                    className="text-xs px-4 py-2 gap-1.5 h-9 w-fit"
                  >
                    <Plus className="h-4 w-4" /> Add Tax Group
                  </Button>
                )}
              </div>
            </div>

            {/* Notifications */}
            {successMessage && (
              <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 p-4 rounded-sm flex items-center gap-3 text-sm animate-in fade-in duration-200">
                <CheckCircle className="h-5 w-5 flex-shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}
            {error && (
              <div className="bg-rose-500/10 border border-rose-500/30 text-rose-500 p-4 rounded-sm flex items-center gap-3 text-sm animate-in fade-in duration-200">
                <AlertCircle className="h-5 w-5 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Tabs Selector */}
            <div className="flex border-b border-border/40 gap-6">
              <button
                onClick={() => setActiveTab("general")}
                className={`pb-3 text-sm font-semibold tracking-wide transition-all border-b-2 flex items-center gap-1.5 ${
                  activeTab === "general"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <Settings className="h-4 w-4" /> General Settings
              </button>
              <button
                onClick={() => setActiveTab("rates")}
                className={`pb-3 text-sm font-semibold tracking-wide transition-all border-b-2 flex items-center gap-1.5 ${
                  activeTab === "rates"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <Percent className="h-4 w-4" /> Tax Rates
              </button>
              <button
                onClick={() => setActiveTab("groups")}
                className={`pb-3 text-sm font-semibold tracking-wide transition-all border-b-2 flex items-center gap-1.5 ${
                  activeTab === "groups"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <Layers className="h-4 w-4" /> Tax Groups
              </button>
            </div>

            {/* Content Cards */}
            <Card className="border border-border/40 bg-card/25 backdrop-blur-md overflow-hidden shadow-xl">
              <CardContent className="p-6 md:p-8">
                
                {/* 1. General Settings Tab */}
                {activeTab === "general" && (
                  isBusinessLoading ? (
                    <div className="py-12 flex flex-col items-center justify-center text-muted-foreground">
                      <Loader2 className="h-8 w-8 animate-spin text-primary mb-3" />
                      <p className="text-sm">Loading general tax settings...</p>
                    </div>
                  ) : (
                    <form onSubmit={handleSubmitGeneral(handleGeneralSubmit)} className="space-y-6">
                      <div className="flex items-center justify-between pb-4 border-b border-border/40">
                        <div className="space-y-0.5">
                          <label className="text-sm font-semibold text-foreground">Enable Tax Calculation</label>
                          <p className="text-xs text-muted-foreground">Toggle tax calculation logic system-wide during transactions.</p>
                        </div>
                        <input
                          type="checkbox"
                          {...registerGeneral("isTaxEnabled")}
                          className="h-5 w-5 rounded border-input text-primary focus:ring-primary bg-background cursor-pointer"
                        />
                      </div>

                      {isTaxEnabledWatch && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in duration-300">
                          {/* Tax Display Label */}
                          <div className="space-y-1.5">
                            <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Tax Label Name</label>
                            <Input
                              {...registerGeneral("taxName")}
                              placeholder="e.g. GST, VAT, Sales Tax"
                            />
                            <p className="text-[10px] text-muted-foreground">The display title printed on invoices and sales dashboards.</p>
                          </div>

                          {/* Tax Number */}
                          <div className="space-y-1.5">
                            <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Business Tax Number</label>
                            <Input
                              {...registerGeneral("taxNumber")}
                              placeholder="e.g. 29GGGGG1234R9Z1, VAT87654"
                            />
                            <p className="text-[10px] text-muted-foreground">The registration number used for taxation reports and billing.</p>
                          </div>
                        </div>
                      )}

                      <div className="flex justify-end pt-4 border-t border-border/40">
                        <Button
                          type="submit"
                          disabled={updateBusinessMutation.isPending}
                          className="text-xs gap-1.5 h-10 px-6"
                        >
                          {updateBusinessMutation.isPending ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <Save className="h-4 w-4" />
                          )}
                          Save Changes
                        </Button>
                      </div>
                    </form>
                  )
                )}

                {/* 2. Tax Rates Tab */}
                {activeTab === "rates" && (
                  isRatesLoading ? (
                    <div className="py-12 flex flex-col items-center justify-center text-muted-foreground">
                      <Loader2 className="h-8 w-8 animate-spin text-primary mb-3" />
                      <p className="text-sm">Loading tax rates...</p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse text-left">
                        <thead>
                          <tr className="border-b border-border/40 text-xs font-bold text-muted-foreground uppercase tracking-wider">
                            <th className="py-3 px-4">Tax Name</th>
                            <th className="py-3 px-4">Rate (%)</th>
                            <th className="py-3 px-4">Status</th>
                            <th className="py-3 px-4 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-border/30 text-sm">
                          {taxRates.map((rate) => (
                            <tr key={rate.id} className="hover:bg-primary/5 transition-colors">
                              <td className="py-4 px-4 font-medium text-foreground">{rate.name}</td>
                              <td className="py-4 px-4 text-muted-foreground font-mono">{rate.rate}%</td>
                              <td className="py-4 px-4">
                                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  rate.isActive ? "bg-emerald-500/10 text-emerald-500" : "bg-muted text-muted-foreground"
                                }`}>
                                  {rate.isActive ? "Active" : "Inactive"}
                                </span>
                              </td>
                              <td className="py-4 px-4 text-right">
                                <div className="flex justify-end gap-2.5">
                                  <button
                                    onClick={() => {
                                      setSelectedRate(rate);
                                      setIsRateDialogOpen(true);
                                    }}
                                    className="p-1.5 text-muted-foreground hover:text-primary hover:bg-primary/10 rounded-sm transition-all"
                                    title="Edit"
                                  >
                                    <Edit2 className="h-3.5 w-3.5" />
                                  </button>
                                  <button
                                    onClick={() => {
                                      setDeleteItem(rate);
                                      setDeleteType("rate");
                                      setIsDeleteDialogOpen(true);
                                    }}
                                    className="p-1.5 text-muted-foreground hover:text-rose-500 hover:bg-rose-500/10 rounded-sm transition-all"
                                    title="Delete"
                                  >
                                    <Trash2 className="h-3.5 w-3.5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                          {taxRates.length === 0 && (
                            <tr>
                              <td colSpan={4} className="py-12 text-center text-muted-foreground text-xs">
                                No tax rates created yet. Click "Add Tax Rate" to create one.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  )
                )}

                {/* 3. Tax Groups Tab */}
                {activeTab === "groups" && (
                  isGroupsLoading ? (
                    <div className="py-12 flex flex-col items-center justify-center text-muted-foreground">
                      <Loader2 className="h-8 w-8 animate-spin text-primary mb-3" />
                      <p className="text-sm">Loading tax groups...</p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse text-left">
                        <thead>
                          <tr className="border-b border-border/40 text-xs font-bold text-muted-foreground uppercase tracking-wider">
                            <th className="py-3 px-4">Group Name</th>
                            <th className="py-3 px-4">Member Taxes</th>
                            <th className="py-3 px-4">Total Combined Rate</th>
                            <th className="py-3 px-4 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-border/30 text-sm">
                          {taxGroups.map((group) => {
                            const totalRate = group.members.reduce((acc, m) => acc + m.taxRate.rate, 0);
                            return (
                              <tr key={group.id} className="hover:bg-primary/5 transition-colors">
                                <td className="py-4 px-4 font-medium text-foreground">{group.name}</td>
                                <td className="py-4 px-4">
                                  <div className="flex flex-wrap gap-1.5">
                                    {group.members.map((m) => (
                                      <span key={m.taxRateId} className="inline-flex items-center px-2 py-0.5 rounded-sm bg-primary/10 text-primary text-[10px] font-medium">
                                        {m.taxRate.name} ({m.taxRate.rate}%)
                                      </span>
                                    ))}
                                  </div>
                                </td>
                                <td className="py-4 px-4 text-muted-foreground font-mono font-semibold">{totalRate}%</td>
                                <td className="py-4 px-4 text-right">
                                  <div className="flex justify-end gap-2.5">
                                    <button
                                      onClick={() => {
                                        setSelectedGroup(group);
                                        setIsGroupDialogOpen(true);
                                      }}
                                      className="p-1.5 text-muted-foreground hover:text-primary hover:bg-primary/10 rounded-sm transition-all"
                                      title="Edit"
                                    >
                                      <Edit2 className="h-3.5 w-3.5" />
                                    </button>
                                    <button
                                      onClick={() => {
                                        setDeleteItem(group);
                                        setDeleteType("group");
                                        setIsDeleteDialogOpen(true);
                                      }}
                                      className="p-1.5 text-muted-foreground hover:text-rose-500 hover:bg-rose-500/10 rounded-sm transition-all"
                                      title="Delete"
                                    >
                                      <Trash2 className="h-3.5 w-3.5" />
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                          {taxGroups.length === 0 && (
                            <tr>
                              <td colSpan={4} className="py-12 text-center text-muted-foreground text-xs">
                                No tax groups created yet. Click "Add Tax Group" to combine multiple rates.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  )
                )}

              </CardContent>
            </Card>
          </div>
        </main>
      </div>

      {/* Dialog Modals */}
      <TaxRateDialog
        isOpen={isRateDialogOpen}
        onClose={() => {
          setIsRateDialogOpen(false);
          setSelectedRate(null);
        }}
        taxRate={selectedRate}
        currentUser={currentUser}
        onSuccess={showSuccess}
        onError={showError}
      />

      <TaxGroupDialog
        isOpen={isGroupDialogOpen}
        onClose={() => {
          setIsGroupDialogOpen(false);
          setSelectedGroup(null);
        }}
        taxGroup={selectedGroup}
        taxRates={taxRates.filter((r) => r.isActive)}
        currentUser={currentUser}
        onSuccess={showSuccess}
        onError={showError}
      />

      <TaxDeleteDialog
        isOpen={isDeleteDialogOpen}
        onClose={() => {
          setIsDeleteDialogOpen(false);
          setDeleteItem(null);
        }}
        item={deleteItem}
        type={deleteType}
        currentUser={currentUser}
        onSuccess={showSuccess}
        onError={showError}
      />
    </div>
  );
}

export default function TaxSettingsPage() {
  return (
    <Suspense
      fallback={
        <div className="flex h-screen items-center justify-center bg-background">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      }
    >
      <TaxSettingsPageContent />
    </Suspense>
  );
}
