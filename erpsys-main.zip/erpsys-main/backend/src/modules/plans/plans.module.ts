import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PlansService } from './plans.service';
import { PlansController } from './plans.controller';
import { PrismaModule } from '../prisma/prisma.module';

@Module({
  imports: [
    PrismaModule,
    JwtModule.register({
      secret: process.env.JWT_SECRET || 'HKR_SUPER_SECRET_KEY_2026_ERP_SECURE_TOKEN_AUTH',
    }),
  ],
  controllers: [PlansController],
  providers: [PlansService],
  exports: [PlansService],
})
export class PlansModule {}
