'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import DashboardSidebar from '@/components/DashboardSidebar';
import {
  Briefcase,
  Plus,
  RefreshCw,
  Search,
  Edit2,
  Trash2,
  MapPin,
  Clock,
  DollarSign,
  CheckCircle,
  AlertCircle,
  X,
  ToggleLeft,
  ToggleRight,
  Layers,
  Sparkles
} from 'lucide-react';

interface JobItem {
  id: string;
  title: string;
  department: string;
  location: string;
  type: string;
  salary: string;
  badge: string;
  description: string;
  requirements: string[];
  responsibilities: string[];
  status: 'ACTIVE' | 'CLOSED' | string;
  createdAt?: string;
}

export default function AdminJobsPage() {
  const router = useRouter();
  const [jobs, setJobs] = useState<JobItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'CLOSED'>('ALL');

  // Modal States
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingJob, setEditingJob] = useState<JobItem | null>(null);

  // Form Fields
  const [title, setTitle] = useState('');
  const [department, setDepartment] = useState('engineering');
  const [location, setLocation] = useState('Remote / Colombo');
  const [type, setType] = useState('Full-Time');
  const [salary, setSalary] = useState('LKR 250,000 - 400,000 / mo');
  const [badge, setBadge] = useState('Urgent Hiring');
  const [description, setDescription] = useState('');
  const [requirementsText, setRequirementsText] = useState('');
  const [responsibilitiesText, setResponsibilitiesText] = useState('');
  const [jobStatus, setJobStatus] = useState<'ACTIVE' | 'CLOSED'>('ACTIVE');

  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [togglingId, setTogglingId] = useState<string | null>(null);

  // Delete Confirmation Modal
  const [deletingJob, setDeletingJob] = useState<JobItem | null>(null);

  // Toast Notification
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  const fetchJobs = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/jobs');
      if (res.status === 401 || res.status === 403) {
        router.push('/login');
        return;
      }
      const data = await res.json();
      if (data.jobs) {
        setJobs(data.jobs);
      }
    } catch (err) {
      console.error('Error fetching admin jobs:', err);
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    fetchJobs();
  }, [fetchJobs]);

  const handleOpenCreateModal = () => {
    setEditingJob(null);
    setTitle('');
    setDepartment('engineering');
    setLocation('Remote / Colombo');
    setType('Full-Time');
    setSalary('LKR 250,000 - 400,000 / mo');
    setBadge('Urgent Hiring');
    setDescription('');
    setRequirementsText('');
    setResponsibilitiesText('');
    setJobStatus('ACTIVE');
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (job: JobItem) => {
    setEditingJob(job);
    setTitle(job.title);
    setDepartment(job.department);
    setLocation(job.location);
    setType(job.type);
    setSalary(job.salary);
    setBadge(job.badge);
    setDescription(job.description || '');
    setRequirementsText(Array.isArray(job.requirements) ? job.requirements.join('\n') : '');
    setResponsibilitiesText(Array.isArray(job.responsibilities) ? job.responsibilities.join('\n') : '');
    setJobStatus(job.status === 'CLOSED' ? 'CLOSED' : 'ACTIVE');
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleToggleStatus = async (job: JobItem) => {
    const nextStatus = job.status === 'ACTIVE' ? 'CLOSED' : 'ACTIVE';
    setTogglingId(job.id);
    try {
      const res = await fetch('/api/admin/jobs', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: job.id, status: nextStatus }),
      });
      const data = await res.json();

      if (res.ok && data.success) {
        setJobs((prev) =>
          prev.map((j) => (j.id === job.id ? { ...j, status: nextStatus } : j))
        );
        showToast(`Job status set to ${nextStatus}`);
      } else {
        showToast(data.error || 'Failed to toggle status', 'error');
      }
    } catch {
      showToast('Error toggling status', 'error');
    } finally {
      setTogglingId(null);
    }
  };

  const handleSaveJob = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!title.trim() || !salary.trim() || !location.trim()) {
      setFormError('Title, Location, and Salary Range are required.');
      return;
    }

    setSubmitting(true);
    try {
      const isEdit = !!editingJob;
      const method = isEdit ? 'PUT' : 'POST';
      const body = {
        ...(isEdit ? { id: editingJob.id } : {}),
        title,
        department,
        location,
        type,
        salary,
        badge,
        description,
        requirements: requirementsText.split('\n').filter(Boolean),
        responsibilities: responsibilitiesText.split('\n').filter(Boolean),
        status: jobStatus,
      };

      const res = await fetch('/api/admin/jobs', {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await res.json();

      if (!res.ok || data.error) {
        setFormError(data.error || 'Failed to save job opening');
        return;
      }

      setIsModalOpen(false);
      showToast(isEdit ? 'Job opening updated successfully!' : 'New Job opening created successfully!');
      fetchJobs();
    } catch {
      setFormError('An error occurred while saving job opening.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteJob = async () => {
    if (!deletingJob) return;
    setSubmitting(true);

    try {
      const res = await fetch(`/api/admin/jobs?id=${deletingJob.id}`, {
        method: 'DELETE',
      });
      const data = await res.json();

      if (!res.ok || data.error) {
        showToast(data.error || 'Failed to delete job', 'error');
        return;
      }

      setDeletingJob(null);
      showToast('Job opening deleted successfully');
      fetchJobs();
    } catch {
      showToast('Error deleting job opening', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const filteredJobs = jobs.filter((j) => {
    const matchesSearch =
      j.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      j.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
      j.location.toLowerCase().includes(searchTerm.toLowerCase());

    if (statusFilter === 'ALL') return matchesSearch;
    return matchesSearch && j.status.toUpperCase() === statusFilter;
  });

  const totalCount = jobs.length;
  const activeCount = jobs.filter((j) => j.status === 'ACTIVE').length;
  const closedCount = jobs.filter((j) => j.status === 'CLOSED').length;
  const deptCount = new Set(jobs.map((j) => j.department)).size;

  return (
    <div className="min-h-screen bg-black text-white radial-bg flex">
      {/* Sidebar */}
      <DashboardSidebar
        userRole="ADMIN"
        userName="HKRION Admin"
        userEmail="admin@hkrion.com"
        activeTab="jobs"
      />

      {/* Main Content Area */}
      <div className="flex-1 lg:ml-64 flex flex-col min-w-0 min-h-screen">
        {/* Toast */}
        {toastMessage && (
          <div
            className={`fixed top-5 right-5 z-50 px-4 py-3 rounded-xl border flex items-center gap-3 shadow-2xl backdrop-blur-md animate-fade-in ${
              toastMessage.type === 'success'
                ? 'bg-emerald-950/90 border-emerald-500/50 text-emerald-300'
                : 'bg-red-950/90 border-red-500/50 text-red-300'
            }`}
          >
            {toastMessage.type === 'success' ? (
              <CheckCircle className="w-5 h-5 text-emerald-400" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-400" />
            )}
            <span className="text-xs font-semibold">{toastMessage.text}</span>
          </div>
        )}

        {/* Top Navbar Header */}
        <header className="border-b border-[#1ABE56]/20 bg-black/80 backdrop-blur-md sticky top-0 z-30 px-6 py-4 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold font-mono tracking-wide text-white flex items-center gap-2">
              <Briefcase className="w-6 h-6 text-[#1ABE56]" />
              Manage <span className="text-[#1ABE56]">Job Openings & Hiring</span>
            </h1>
            <p className="text-xs text-neutral-400">
              Create openings, update salary ranges, and toggle active hiring status for Careers portal
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={fetchJobs}
              className="px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-[#1ABE56]/40 text-neutral-300 hover:text-white text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-[#1ABE56]' : ''}`} />
              Refresh
            </button>

            <button
              onClick={handleOpenCreateModal}
              className="glow-btn px-4 py-2.5 rounded-xl text-xs font-semibold text-white flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create Job Opening</span>
            </button>
          </div>
        </header>

        {/* Dashboard Main View */}
        <main className="p-6 sm:p-8 space-y-8 flex-1">
          {/* Key Metric Overview Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="glass-card p-5 rounded-2xl border border-[#1ABE56]/30 bg-black/80 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-[#1ABE56]/20 flex items-center justify-center shrink-0">
                <Briefcase className="w-6 h-6 text-[#1ABE56]" />
              </div>
              <div>
                <p className="text-xs font-mono uppercase text-neutral-400">Total Openings</p>
                <h3 className="text-2xl font-bold text-white">{totalCount}</h3>
              </div>
            </div>

            <div className="glass-card p-5 rounded-2xl border border-emerald-500/30 bg-black/80 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center shrink-0">
                <Sparkles className="w-6 h-6 text-emerald-400" />
              </div>
              <div>
                <p className="text-xs font-mono uppercase text-neutral-400">Active Hiring</p>
                <h3 className="text-2xl font-bold text-white">{activeCount}</h3>
              </div>
            </div>

            <div className="glass-card p-5 rounded-2xl border border-neutral-700 bg-black/80 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-neutral-800 flex items-center justify-center shrink-0">
                <Clock className="w-6 h-6 text-neutral-400" />
              </div>
              <div>
                <p className="text-xs font-mono uppercase text-neutral-400">Closed Postings</p>
                <h3 className="text-2xl font-bold text-white">{closedCount}</h3>
              </div>
            </div>

            <div className="glass-card p-5 rounded-2xl border border-purple-500/30 bg-black/80 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center shrink-0">
                <Layers className="w-6 h-6 text-purple-400" />
              </div>
              <div>
                <p className="text-xs font-mono uppercase text-neutral-400">Departments</p>
                <h3 className="text-2xl font-bold text-white">{deptCount}</h3>
              </div>
            </div>
          </div>

          {/* Search & Filter Pills */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
              <div className="relative w-full sm:w-80">
                <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  placeholder="Search job title, department, or location..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-500 focus:outline-none focus:border-[#1ABE56] text-xs transition-colors"
                />
              </div>

              {/* Status filter buttons */}
              <div className="flex items-center p-1 rounded-xl bg-neutral-900 border border-neutral-800 text-xs">
                {(['ALL', 'ACTIVE', 'CLOSED'] as const).map((st) => (
                  <button
                    key={st}
                    onClick={() => setStatusFilter(st)}
                    className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                      statusFilter === st
                        ? 'bg-[#1ABE56]/20 text-[#1ABE56] font-semibold border border-[#1ABE56]/40'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    {st} ({st === 'ALL' ? totalCount : st === 'ACTIVE' ? activeCount : closedCount})
                  </button>
                ))}
              </div>
            </div>

            <div className="text-xs text-neutral-400 font-mono">
              Showing {filteredJobs.length} of {jobs.length} Job Openings
            </div>
          </div>

          {/* Job Postings Grid */}
          {filteredJobs.length === 0 ? (
            <div className="glass-card p-12 text-center rounded-2xl border border-neutral-800 bg-black/80 space-y-3">
              <Briefcase className="w-12 h-12 text-neutral-600 mx-auto" />
              <h3 className="text-base font-semibold text-neutral-300">No Job Openings Found</h3>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                No matching job openings found for &quot;{searchTerm}&quot;. Create a new opening to start accepting applications.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredJobs.map((job) => {
                const isActive = job.status === 'ACTIVE';
                return (
                  <div
                    key={job.id}
                    className={`glass-card p-6 rounded-2xl border transition-all duration-300 bg-black/90 flex flex-col justify-between space-y-5 hover:shadow-xl ${
                      isActive
                        ? 'border-[#1ABE56]/30 hover:border-[#1ABE56]/60 hover:shadow-[#1ABE56]/10'
                        : 'border-neutral-800 opacity-75 hover:opacity-100'
                    }`}
                  >
                    <div className="space-y-4">
                      {/* Top Badges & Actions */}
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <div className="flex flex-wrap items-center gap-2 mb-2">
                            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-[#1ABE56]/20 text-[#1ABE56] border border-[#1ABE56]/30 uppercase">
                              {job.badge || job.department}
                            </span>
                            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-semibold bg-neutral-900 text-neutral-400 border border-neutral-800 uppercase">
                              {job.department}
                            </span>
                          </div>
                          <h3 className="text-lg font-bold text-white font-mono tracking-wide">
                            {job.title}
                          </h3>
                        </div>

                        {/* Action buttons */}
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            onClick={() => handleOpenEditModal(job)}
                            className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white transition-colors cursor-pointer"
                            title="Edit Job Posting & Salary"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setDeletingJob(job)}
                            className="p-2 rounded-xl bg-neutral-900 hover:bg-red-950/60 border border-neutral-800 hover:border-red-500/40 text-neutral-400 hover:text-red-400 transition-colors cursor-pointer"
                            title="Delete Job Opening"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Description */}
                      <p className="text-xs text-neutral-400 line-clamp-2 leading-relaxed font-mono">
                        {job.description || 'No detailed description provided.'}
                      </p>

                      {/* Meta Info: Salary, Location, Type */}
                      <div className="grid grid-cols-2 gap-2 py-3 border-y border-neutral-900 text-xs font-mono">
                        <div className="flex items-center gap-1.5 text-neutral-300">
                          <MapPin className="w-3.5 h-3.5 text-[#1ABE56]" />
                          <span>{job.location}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-neutral-400">
                          <Clock className="w-3.5 h-3.5 text-neutral-500" />
                          <span>{job.type}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-[#1ABE56] font-bold col-span-2">
                          <DollarSign className="w-4 h-4" />
                          <span>{job.salary}</span>
                        </div>
                      </div>
                    </div>

                    {/* Hiring Status Toggle Switcher */}
                    <div className="flex items-center justify-between pt-2">
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-mono text-neutral-400 uppercase">Hiring Status:</span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                            isActive
                              ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                              : 'bg-neutral-800 text-neutral-400 border-neutral-700'
                          }`}
                        >
                          {isActive ? 'ACTIVE HIRING' : 'CLOSED'}
                        </span>
                      </div>

                      {/* Instant Status Switcher Toggle Button */}
                      <button
                        onClick={() => handleToggleStatus(job)}
                        disabled={togglingId === job.id}
                        className={`px-3 py-1.5 rounded-xl border text-xs font-mono font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                          isActive
                            ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300 hover:bg-emerald-900/60'
                            : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
                        }`}
                      >
                        {togglingId === job.id ? (
                          <RefreshCw className="w-4 h-4 animate-spin text-[#1ABE56]" />
                        ) : isActive ? (
                          <ToggleRight className="w-5 h-5 text-emerald-400" />
                        ) : (
                          <ToggleLeft className="w-5 h-5 text-neutral-500" />
                        )}
                        <span>{isActive ? 'Close Role' : 'Activate Role'}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </main>
      </div>

      {/* CREATE / EDIT JOB MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="bg-neutral-950 border border-[#1ABE56]/40 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl space-y-0">
            {/* Header */}
            <div className="p-6 border-b border-neutral-900 flex items-center justify-between bg-black/40">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#1ABE56]/20 border border-[#1ABE56]/40 flex items-center justify-center">
                  <Briefcase className="w-5 h-5 text-[#1ABE56]" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white font-mono">
                    {editingJob ? `Edit Job Opening: ${editingJob.title}` : 'Create New Job Opening'}
                  </h3>
                  <p className="text-xs text-neutral-400">
                    Define position details, salary range, badge, requirements, and hiring status
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-2 rounded-xl text-neutral-400 hover:text-white bg-neutral-900 border border-neutral-800 hover:border-neutral-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSaveJob} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
              {formError && (
                <div className="p-4 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 text-xs flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 shrink-0 text-red-400" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Title & Department */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-mono text-neutral-300 uppercase font-semibold">
                    Job Title <span className="text-[#1ABE56]">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Senior DevOps Architect"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-500 focus:outline-none focus:border-[#1ABE56] text-xs font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono text-neutral-300 uppercase font-semibold">
                    Department <span className="text-[#1ABE56]">*</span>
                  </label>
                  <select
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white focus:outline-none focus:border-[#1ABE56] text-xs font-mono cursor-pointer"
                  >
                    <option value="engineering">Engineering</option>
                    <option value="design">Design & UI/UX</option>
                    <option value="product">Product & ERP</option>
                    <option value="internship">Internships</option>
                  </select>
                </div>
              </div>

              {/* Location & Job Type */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-mono text-neutral-300 uppercase font-semibold">
                    Location <span className="text-[#1ABE56]">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Remote / Colombo"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:outline-none focus:border-[#1ABE56]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono text-neutral-300 uppercase font-semibold">
                    Job Type
                  </label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white focus:outline-none focus:border-[#1ABE56] text-xs font-mono cursor-pointer"
                  >
                    <option value="Full-Time">Full-Time</option>
                    <option value="Part-Time">Part-Time</option>
                    <option value="Contract">Contract</option>
                    <option value="Internship (6 Months)">Internship (6 Months)</option>
                  </select>
                </div>
              </div>

              {/* Salary Range & Badge */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-mono text-neutral-300 uppercase font-semibold">
                    Salary Range <span className="text-[#1ABE56]">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. LKR 250,000 - 400,000 / mo"
                    value={salary}
                    onChange={(e) => setSalary(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:outline-none focus:border-[#1ABE56]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono text-neutral-300 uppercase font-semibold">
                    Badge Tag
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Urgent Hiring, Featured, Core Team"
                    value={badge}
                    onChange={(e) => setBadge(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:outline-none focus:border-[#1ABE56]"
                  />
                </div>
              </div>

              {/* Description */}
              <div className="space-y-1">
                <label className="text-xs font-mono text-neutral-300 uppercase font-semibold">
                  Job Description Overview
                </label>
                <textarea
                  rows={3}
                  placeholder="Provide a summary of the role, team environment, and mission..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:outline-none focus:border-[#1ABE56]"
                />
              </div>

              {/* Requirements & Responsibilities */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-mono text-neutral-300 uppercase font-semibold">
                    Key Requirements (One per line)
                  </label>
                  <textarea
                    rows={4}
                    placeholder="3+ years Next.js & React&#10;Experience with MySQL & Prisma ORM&#10;Strong REST API background"
                    value={requirementsText}
                    onChange={(e) => setRequirementsText(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:outline-none focus:border-[#1ABE56]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono text-neutral-300 uppercase font-semibold">
                    Responsibilities (One per line)
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Architect enterprise SaaS solutions&#10;Collaborate with UI designers&#10;Maintain 99.9% uptime"
                    value={responsibilitiesText}
                    onChange={(e) => setResponsibilitiesText(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:outline-none focus:border-[#1ABE56]"
                  />
                </div>
              </div>

              {/* Hiring Status Radio Selection */}
              <div className="space-y-2 pt-2 border-t border-neutral-900">
                <label className="text-xs font-mono text-neutral-300 uppercase font-semibold">
                  Initial Hiring Status
                </label>
                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-mono text-white">
                    <input
                      type="radio"
                      name="status"
                      value="ACTIVE"
                      checked={jobStatus === 'ACTIVE'}
                      onChange={() => setJobStatus('ACTIVE')}
                      className="accent-[#1ABE56]"
                    />
                    <span className="text-emerald-400 font-bold">ACTIVE (Publish to Careers Page)</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-xs font-mono text-white">
                    <input
                      type="radio"
                      name="status"
                      value="CLOSED"
                      checked={jobStatus === 'CLOSED'}
                      onChange={() => setJobStatus('CLOSED')}
                      className="accent-neutral-500"
                    />
                    <span className="text-neutral-400">CLOSED (Hidden from Public)</span>
                  </label>
                </div>
              </div>

              {/* Footer */}
              <div className="pt-4 border-t border-neutral-900 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-neutral-300 text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="glow-btn px-6 py-2.5 rounded-xl text-xs font-semibold text-white flex items-center gap-2 cursor-pointer disabled:opacity-60"
                >
                  {submitting && <RefreshCw className="w-4 h-4 animate-spin" />}
                  <span>{editingJob ? 'Save Changes' : 'Create Job Opening'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {deletingJob && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="bg-neutral-950 border border-red-500/40 rounded-2xl w-full max-w-md p-6 space-y-6 shadow-2xl">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-red-950/80 border border-red-500/40 flex items-center justify-center shrink-0">
                <AlertCircle className="w-6 h-6 text-red-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-mono">
                  Delete &quot;{deletingJob.title}&quot;?
                </h3>
                <p className="text-xs text-neutral-400 mt-1">
                  This action is permanent and will remove the job opening from the database.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setDeletingJob(null)}
                className="px-4 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteJob}
                disabled={submitting}
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-semibold flex items-center gap-2 cursor-pointer disabled:opacity-60"
              >
                {submitting && <RefreshCw className="w-4 h-4 animate-spin" />}
                <span>Confirm Delete</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
