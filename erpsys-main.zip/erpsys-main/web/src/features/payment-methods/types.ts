export interface BranchPaymentMethodMapping {
  branchId: string;
  paymentMethodId: string;
  isActive: boolean;
  branch: {
    id: string;
    name: string;
  };
}

export interface PaymentMethodItem {
  id: string;
  businessId: string;
  code: string;
  name: string;
  description?: string;
  isSystem: boolean;
  isActive: boolean;
  sortOrder: number;
  branches: BranchPaymentMethodMapping[];
  createdAt: string;
  updatedAt: string;
}
