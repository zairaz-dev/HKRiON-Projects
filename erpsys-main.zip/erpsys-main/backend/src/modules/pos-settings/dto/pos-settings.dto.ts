export class UpdatePosSettingsDto {
  businessId?: string;
  branchId?: string | null;
  defaultCustomerId?: string | null;
  defaultPaymentMethodId?: string | null;
  enableExpressCheckout?: boolean;
  autoPrintInvoice?: boolean;
  showProductSuggestions?: boolean;
  allowOverSelling?: boolean;
  enableDiscount?: boolean;
  enableHoldOrders?: boolean;
  enableSoundEffects?: boolean;

  // Shortcuts
  searchShortcut?: string;
  checkoutShortcut?: string;
  cashShortcut?: string;
  cardShortcut?: string;
  holdShortcut?: string;
  cancelShortcut?: string;
}
