# POS Module

This module handles transactional processing for retail checkouts:
- Invoice creation and receipt generation
- Cash, Card, UPI payment validation
- Real-time stock decrement hooks (emitted when invoice is paid)
- Sales reports data aggregation

## Files to create
- `pos.controller.ts`: Handles invoice checkouts and sales API endpoints.
- `pos.service.ts`: Handles business logic for transactions.
- `pos.module.ts`: NestJS module declaration.
- `dto/create-invoice.dto.ts`: Input validation for invoices.
