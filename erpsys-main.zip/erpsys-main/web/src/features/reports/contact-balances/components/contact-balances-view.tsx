import React, { useState } from "react";
import {
  Users,
  Printer,
  Search,
  DollarSign,
  UserCheck,
  Building2,
  Phone,
  ArrowUpRight,
  ArrowDownLeft
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useContactBalancesQuery } from "../hooks/use-contact-balances";
import { useCurrency } from "@/hooks/use-currency";

interface ContactBalancesViewProps {
  businessId: string;
  searchQuery?: string;
  onSearchChange?: (val: string) => void;
}

export function ContactBalancesView({
  businessId,
  searchQuery = "",
  onSearchChange,
}: ContactBalancesViewProps) {
  const [activeTab, setActiveTab] = useState<"CUSTOMERS" | "SUPPLIERS">("CUSTOMERS");
  const { symbol } = useCurrency(businessId);

  const { data, isLoading } = useContactBalancesQuery(businessId, {
    search: searchQuery,
  });

  const handlePrint = () => {
    window.print();
  };

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="text-center space-y-2">
          <div className="w-8 h-8 border-4 border-zinc-700 border-t-emerald-500 rounded-full animate-spin mx-auto" />
          <span className="text-sm text-muted-foreground block">Computing Contact Balance Ledgers...</span>
        </div>
      </div>
    );
  }

  const {
    totalCustomerReceivables = 0,
    totalSupplierPayables = 0,
    customerLedger = [],
    supplierLedger = [],
  } = data || {};

  const currentLedger = activeTab === "CUSTOMERS" ? customerLedger : supplierLedger;

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Action Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold tracking-tight flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" /> Contact Balances Ledger (Receivables & Payables)
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Outstanding customer invoice dues (Receivables) and supplier purchase dues (Payables).
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onSearchChange && (
            <div className="relative w-48 sm:w-60">
              <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search contact name or phone..."
                className="pl-8 h-8 text-xs"
              />
            </div>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={handlePrint}
            className="gap-1.5 text-xs h-8 shrink-0"
          >
            <Printer className="h-3.5 w-3.5" /> Print Balances
          </Button>
        </div>
      </div>

      {/* High-level KPI Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-card border border-border/60 rounded-sm p-5 space-y-2 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1.5">
              <ArrowDownLeft className="h-4 w-4 text-emerald-500" /> Customer Receivables (To Receive)
            </span>
            <span className="text-xs font-mono font-bold text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-sm">
              Asset
            </span>
          </div>
          <p className="text-3xl font-black text-emerald-500 font-mono">
            {symbol}{totalCustomerReceivables.toFixed(2)}
          </p>
        </div>

        <div className="bg-card border border-border/60 rounded-sm p-5 space-y-2 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1.5">
              <ArrowUpRight className="h-4 w-4 text-rose-500" /> Supplier Payables (To Pay)
            </span>
            <span className="text-xs font-mono font-bold text-rose-500 bg-rose-500/10 px-2 py-0.5 rounded-sm">
              Liability
            </span>
          </div>
          <p className="text-3xl font-black text-rose-500 font-mono">
            {symbol}{totalSupplierPayables.toFixed(2)}
          </p>
        </div>
      </div>

      {/* Tabs & Table Section */}
      <div className="space-y-3">
        <div className="flex items-center gap-2 border-b border-border pb-2">
          <button
            onClick={() => setActiveTab("CUSTOMERS")}
            className={`px-3 py-1.5 rounded-sm text-xs font-bold transition-all ${activeTab === "CUSTOMERS" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:bg-muted/50"}`}
          >
            Customer Receivables ({customerLedger.length})
          </button>
          <button
            onClick={() => setActiveTab("SUPPLIERS")}
            className={`px-3 py-1.5 rounded-sm text-xs font-bold transition-all ${activeTab === "SUPPLIERS" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:bg-muted/50"}`}
          >
            Supplier Payables ({supplierLedger.length})
          </button>
        </div>

        <div className="border border-border/60 rounded-sm overflow-hidden shadow-sm">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-muted/40 border-b border-border/60">
                <th className="p-3 font-semibold text-muted-foreground">Contact Name</th>
                <th className="p-3 font-semibold text-muted-foreground">Phone</th>
                <th className="p-3 font-semibold text-muted-foreground text-right">Invoice Due ({symbol})</th>
                <th className="p-3 font-semibold text-muted-foreground text-right">Advance Balance ({symbol})</th>
                <th className="p-3 font-semibold text-muted-foreground text-right pr-4">Net Balance ({symbol})</th>
              </tr>
            </thead>
            <tbody>
              {currentLedger.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-muted-foreground">
                    No active balances found for {activeTab.toLowerCase()}.
                  </td>
                </tr>
              ) : (
                currentLedger.map((c: any) => (
                  <tr key={c.id} className="border-b border-border/40 hover:bg-muted/15 transition-colors">
                    <td className="p-3 font-bold text-foreground">
                      {c.name}
                    </td>
                    <td className="p-3 font-mono text-muted-foreground">
                      {c.phone || c.mobile || "N/A"}
                    </td>
                    <td className="p-3 text-right font-mono font-semibold text-rose-500">
                      {symbol}{c.totalDue.toFixed(2)}
                    </td>
                    <td className="p-3 text-right font-mono font-semibold text-emerald-500">
                      {symbol}{c.totalAdvance.toFixed(2)}
                    </td>
                    <td className="p-3 text-right font-mono font-bold text-foreground text-sm pr-4">
                      {symbol}{c.netBalance.toFixed(2)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
