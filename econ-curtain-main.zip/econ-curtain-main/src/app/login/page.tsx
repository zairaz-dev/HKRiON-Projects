"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Logo from "@/components/ui/Logo";
import { Mail, Lock, Eye, EyeOff, LogIn, AlertCircle, CheckCircle2, ShieldCheck, ArrowLeft } from "lucide-react";
import Link from "next/link";

function LoginForm() {
  const searchParams = useSearchParams();
  const callbackUrl = searchParams.get("callbackUrl") || "/admin";
  const urlError = searchParams.get("error");
  const urlSuccess = searchParams.get("success");

  const [showPassword, setShowPassword] = useState(false);

  return (
    <div className="min-h-screen w-full bg-slate-950 flex flex-col justify-center items-center px-4 py-12 relative overflow-hidden selection:bg-amber-500 selection:text-slate-950">
      {/* Background Ambience Spotlight */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-150 h-87.5 bg-amber-500/10 blur-3xl pointer-events-none rounded-full" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-yellow-500/5 blur-3xl pointer-events-none rounded-full" />

      {/* Back to Home Button */}
      <div className="absolute top-6 left-6 z-20">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-slate-400 hover:text-amber-400 text-xs sm:text-sm font-semibold transition-colors px-4 py-2 rounded-full bg-slate-900/80 border border-slate-800"
        >
          <ArrowLeft size={16} />
          <span>Back to Website</span>
        </Link>
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Glassmorphic Login Form Card - Pure Native Form for 100% LAN & Mobile Reliability */}
        <div className="bg-slate-900/90 backdrop-blur-2xl border border-slate-800/90 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/80">
          {/* Card Header with Logo */}
          <div className="text-center mb-8">
            <Link href="/" className="inline-flex justify-center mb-4">
              <Logo className="h-12 w-auto" />
            </Link>
            <div className="flex justify-center">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-400 text-xs font-bold uppercase tracking-widest mb-3">
                <ShieldCheck size={14} /> Admin Portal
              </div>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white">Sign In to Dashboard</h1>
            <p className="text-slate-400 text-xs sm:text-sm mt-1.5 font-light">
              Manage your products, inquiries, and shade systems.
            </p>
          </div>

          {urlSuccess && (
            <div className="mb-6 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs sm:text-sm flex items-center gap-3">
              <CheckCircle2 size={18} className="shrink-0 text-emerald-400" />
              <span>{urlSuccess}</span>
            </div>
          )}

          {urlError && (
            <div className="mb-6 p-4 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs sm:text-sm flex items-center gap-3">
              <AlertCircle size={18} className="shrink-0 text-red-400" />
              <span>{urlError}</span>
            </div>
          )}

          <form method="POST" action="/api/auth/login" className="space-y-5" autoComplete="off">
            <input type="hidden" name="callbackUrl" value={callbackUrl} />

            {/* Email Field - Clean without prefilled default values */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                Email Address
              </label>
              <div className="relative">
                <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
                <input
                  id="email-input"
                  name="email"
                  type="email"
                  required
                  autoComplete="off"
                  placeholder="Enter your email"
                  className="w-full bg-slate-950/80 border border-slate-800 focus:border-amber-400 rounded-2xl py-3.5 pl-11 pr-4 text-white text-sm placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-amber-400 transition-all"
                />
              </div>
            </div>

            {/* Password Field - Clean without prefilled default values */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                  Password
                </label>
                <Link
                  href="/forgot-password"
                  className="text-xs text-amber-400 hover:text-amber-300 font-bold transition-colors"
                >
                  Forgot Password?
                </Link>
              </div>
              <div className="relative">
                <Lock size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
                <input
                  id="password-input"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  required
                  autoComplete="new-password"
                  placeholder="Enter your password"
                  className="w-full bg-slate-950/80 border border-slate-800 focus:border-amber-400 rounded-2xl py-3.5 pl-11 pr-12 text-white text-sm placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-amber-400 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors p-1 cursor-pointer"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-4 bg-linear-to-r from-primary via-amber-500 to-yellow-500 text-slate-950 font-bold rounded-2xl text-base hover:brightness-110 transition-all shadow-xl shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer active:scale-95"
            >
              <LogIn size={18} />
              <span>Sign In</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">Loading Login...</div>}>
      <LoginForm />
    </Suspense>
  );
}
