import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { ProductType, ImeiStatus } from '@prisma/client';

interface GroupPriceInput {
  sellingPriceGroupId: string;
  price: number;
}

interface VariantInput {
  id?: string;
  name: string;
  sku?: string;
  purchasePrice: number;
  sellingPrice: number;
  valueIds?: string[]; // for variable products
  groupPrices?: GroupPriceInput[];
  openingStock?: number;
  openingStockBranchId?: string;
}

@Injectable()
export class ProductsService {
  constructor(private readonly prisma: PrismaService) {}

  async createProduct(data: {
    name: string;
    description?: string;
    imageUrl?: string;
    type: ProductType;
    isActive?: boolean;
    enableStock?: boolean;
    enableImei?: boolean;
    isImei?: boolean;
    alertQuantity?: number;
    notForSelling?: boolean;
    weight?: number;
    businessId: string;
    categoryId?: string;
    brandId?: string;
    unitId?: string;
    warrantyId?: string;
    branchIds?: string[];
    // For SINGLE type
    sku?: string;
    purchasePrice?: number;
    sellingPrice?: number;
    groupPrices?: GroupPriceInput[];
    openingStock?: number;
    openingStockBranchId?: string;
    // For VARIABLE type
    variants?: VariantInput[];
    createdById?: string;
  }) {
    const {
      name,
      description,
      imageUrl,
      type,
      isActive,
      enableStock,
      enableImei,
      isImei,
      alertQuantity,
      notForSelling,
      weight,
      businessId,
      categoryId,
      brandId,
      unitId,
      warrantyId,
      branchIds,
      sku,
      purchasePrice,
      sellingPrice,
      groupPrices,
      openingStock,
      openingStockBranchId,
      variants,
      createdById,
    } = data;

    // 1. Validations
    if (!name || name.trim().length < 2) {
      throw new BadRequestException('Product name must be at least 2 characters');
    }

    // Check duplicate product name in business
    const existingProduct = await this.prisma.product.findFirst({
      where: { name: { equals: name.trim(), mode: 'insensitive' }, businessId },
    });
    if (existingProduct) {
      throw new BadRequestException(`A product named "${name.trim()}" already exists in your catalog`);
    }

    if (type === ProductType.SINGLE) {
      if (purchasePrice === undefined || purchasePrice < 0) {
        throw new BadRequestException('Purchase price is required and must be 0 or greater');
      }
      if (sellingPrice === undefined || sellingPrice < 0) {
        throw new BadRequestException('Selling price is required and must be 0 or greater');
      }
    } else if (type === ProductType.VARIABLE) {
      if (!variants || variants.length === 0) {
        throw new BadRequestException('At least one variant must be defined for variable products');
      }
      const seenSkus = new Set<string>();
      for (const v of variants) {
        if (!v.name || v.name.trim() === '') {
          throw new BadRequestException('Each variant must have a valid name');
        }
        if (v.purchasePrice === undefined || v.purchasePrice < 0) {
          throw new BadRequestException(`Variant "${v.name}" purchase price must be 0 or greater`);
        }
        if (v.sellingPrice === undefined || v.sellingPrice < 0) {
          throw new BadRequestException(`Variant "${v.name}" selling price must be 0 or greater`);
        }
        if (v.sku && v.sku.trim()) {
          const normSku = v.sku.trim().toUpperCase();
          if (seenSkus.has(normSku)) {
            throw new BadRequestException(`Duplicate SKU "${normSku}" found among the variants in this product`);
          }
          seenSkus.add(normSku);
        }
      }
    }

    // Cross-tenant verification
    if (categoryId) {
      const cat = await this.prisma.category.findFirst({ where: { id: categoryId, businessId } });
      if (!cat) throw new BadRequestException('Selected category does not exist in this business');
    }
    if (brandId) {
      const br = await this.prisma.brand.findFirst({ where: { id: brandId, businessId } });
      if (!br) throw new BadRequestException('Selected brand does not exist in this business');
    }
    if (unitId) {
      const un = await this.prisma.unit.findFirst({ where: { id: unitId, businessId } });
      if (!un) throw new BadRequestException('Selected unit does not exist in this business');
    }
    if (warrantyId) {
      const wr = await this.prisma.warranty.findFirst({ where: { id: warrantyId, businessId } });
      if (!wr) throw new BadRequestException('Selected warranty does not exist in this business');
    }

    // Resolve missing SKUs
    let resolvedSku = sku && sku.trim() ? sku.trim().toUpperCase() : null;
    if (type === ProductType.SINGLE && (!resolvedSku || resolvedSku === '')) {
      resolvedSku = await this.generateUniqueSku(name, businessId);
    }

    const resolvedVariants = [];
    if (type === ProductType.VARIABLE && variants) {
      for (const v of variants) {
        let vSku = v.sku && v.sku.trim() ? v.sku.trim().toUpperCase() : null;
        if (!vSku || vSku === '') {
          vSku = await this.generateUniqueSku(v.name || `${name} Variant`, businessId);
        }
        resolvedVariants.push({
          ...v,
          sku: vSku,
        });
      }
    }

    // Check duplicate SKU in the business
    const skuList: string[] = [];
    if (type === ProductType.SINGLE) {
      if (resolvedSku) skuList.push(resolvedSku);
    } else {
      resolvedVariants.forEach((v) => {
        if (v.sku) skuList.push(v.sku);
      });
    }

    if (skuList.length > 0) {
      const existingSku = await this.prisma.productVariant.findFirst({
        where: {
          sku: { in: skuList },
          product: { businessId },
        },
      });
      if (existingSku) {
        throw new BadRequestException(`SKU "${existingSku.sku}" is already in use`);
      }
    }

    // Verify branches belong to the business
    if (branchIds && branchIds.length > 0) {
      const validBranches = await this.prisma.branch.findMany({
        where: { id: { in: branchIds }, businessId },
      });
      if (validBranches.length !== branchIds.length) {
        throw new BadRequestException('One or more selected branches are invalid');
      }
    }

    // 2. Transactional Create
    return this.prisma.$transaction(async (tx) => {
      // Create Product
      const product = await tx.product.create({
        data: {
          name: name.trim(),
          description: description || null,
          imageUrl: imageUrl || null,
          type,
          isActive: isActive !== undefined ? isActive : true,
          enableStock: enableStock !== undefined ? enableStock : true,
          enableImei: isImei !== undefined ? isImei : (enableImei !== undefined ? enableImei : false),
          isImei: isImei !== undefined ? isImei : (enableImei !== undefined ? enableImei : false),
          alertQuantity: alertQuantity || 0,
          notForSelling: notForSelling !== undefined ? notForSelling : false,
          weight: weight !== undefined ? weight : null,
          businessId,
          categoryId: categoryId || null,
          brandId: brandId || null,
          unitId: unitId || null,
          warrantyId: warrantyId || null,
          createdById: createdById || null,
          branches: branchIds && branchIds.length > 0
            ? {
                create: branchIds.map((branchId) => ({
                  branchId,
                })),
              }
            : undefined,
        } as any,
      });

      // Create Variants
      if (type === ProductType.SINGLE) {
        const variant = await tx.productVariant.create({
          data: {
            name: name.trim(),
            sku: resolvedSku,
            barcode: null,
            purchasePrice,
            sellingPrice,
            productId: product.id,
            groupPrices: groupPrices && groupPrices.length > 0
              ? {
                  create: groupPrices.map((gp) => ({
                    sellingPriceGroupId: gp.sellingPriceGroupId,
                    price: gp.price,
                  })),
                }
              : undefined,
          },
        });

        // Seed opening stock if enabled and set
        if (enableStock !== false && openingStock !== undefined && openingStock > 0) {
          const targetBranchId = (openingStockBranchId && openingStockBranchId !== 'none')
            ? openingStockBranchId
            : (branchIds && branchIds.length > 0 ? branchIds[0] : null);

          if (targetBranchId) {
            await tx.purchaseLine.create({
              data: {
                variantId: variant.id,
                branchId: targetBranchId,
                businessId,
                quantityPurchased: parseFloat(String(openingStock)),
                quantityRemaining: parseFloat(String(openingStock)),
                purchasePrice: purchasePrice || 0,
                sellingPrice: sellingPrice || 0,
                batchNumber: 'OPENING-STOCK',
              },
            });
          }
        }
      } else {
        for (const vInput of resolvedVariants) {
          const variant = await tx.productVariant.create({
            data: {
              name: vInput.name.trim(),
              sku: vInput.sku,
              barcode: null,
              purchasePrice: vInput.purchasePrice,
              sellingPrice: vInput.sellingPrice,
              productId: product.id,
              valueMaps: vInput.valueIds && vInput.valueIds.length > 0
                ? {
                    create: vInput.valueIds.map((valueId) => ({
                      valueId,
                    })),
                  }
                : undefined,
              groupPrices: vInput.groupPrices && vInput.groupPrices.length > 0
                ? {
                    create: vInput.groupPrices.map((gp) => ({
                      sellingPriceGroupId: gp.sellingPriceGroupId,
                      price: gp.price,
                    })),
                  }
                : undefined,
            },
          });

          // Seed opening stock if enabled and set for this variant
          if (enableStock !== false && vInput.openingStock !== undefined && vInput.openingStock > 0) {
            const targetBranchId = (vInput.openingStockBranchId && vInput.openingStockBranchId !== 'none')
              ? vInput.openingStockBranchId
              : (branchIds && branchIds.length > 0 ? branchIds[0] : null);

            if (targetBranchId) {
              await tx.purchaseLine.create({
                data: {
                  variantId: variant.id,
                  branchId: targetBranchId,
                  businessId,
                  quantityPurchased: parseFloat(String(vInput.openingStock)),
                  quantityRemaining: parseFloat(String(vInput.openingStock)),
                  purchasePrice: vInput.purchasePrice || 0,
                  sellingPrice: vInput.sellingPrice || 0,
                  batchNumber: 'OPENING-STOCK',
                },
              });
            }
          }
        }
      }

      return tx.product.findUnique({
        where: { id: product.id },
        include: {
          variants: {
            include: {
              valueMaps: {
                include: {
                  value: true,
                },
              },
              groupPrices: {
                include: {
                  sellingPriceGroup: true,
                },
              },
            },
          },
          branches: {
            include: {
              branch: true,
            },
          },
        },
      });
    });
  }

  async getProducts(
    businessId: string,
    options: {
      branchId?: string;
      categoryId?: string;
      brandId?: string;
      search?: string;
      page?: number;
      limit?: number;
      all?: boolean;
      isActive?: boolean;
      notForSelling?: boolean;
    } = {},
  ) {
    const whereClause: any = {
      businessId,
    };

    if (options.isActive !== undefined) {
      whereClause.isActive = options.isActive;
    }

    if (options.notForSelling !== undefined) {
      whereClause.notForSelling = options.notForSelling;
    }

    if (options.branchId === 'global') {
      whereClause.branches = { none: {} };
    } else if (options.branchId && options.branchId !== 'all') {
      whereClause.OR = [
        { branches: { none: {} } },
        { branches: { some: { branchId: options.branchId } } },
      ];
    }

    if (options.categoryId && options.categoryId !== 'all') {
      whereClause.categoryId = options.categoryId;
    }

    if (options.brandId && options.brandId !== 'all') {
      whereClause.brandId = options.brandId;
    }

    if (options.search && options.search.trim()) {
      const q = options.search.trim();
      whereClause.AND = [
        {
          OR: [
            { name: { contains: q, mode: 'insensitive' } },
            { description: { contains: q, mode: 'insensitive' } },
            { variants: { some: { sku: { contains: q, mode: 'insensitive' } } } },
            { variants: { some: { barcode: { contains: q, mode: 'insensitive' } } } },
          ],
        },
      ];
    }

    const includeClause = {
      category: true,
      brand: true,
      unit: true,
      warranty: true,
      variants: {
        include: {
          valueMaps: {
            include: {
              value: {
                include: {
                  variation: true,
                },
              },
            },
          },
          groupPrices: {
            include: {
              sellingPriceGroup: true,
            },
          },
          purchaseLines: {
            select: {
              quantityRemaining: true,
              branchId: true,
            },
          },
        },
      },
      branches: {
        include: {
          branch: {
            select: {
              id: true,
              name: true,
            },
          },
        },
      },
    };

    if (options.all) {
      const data = await this.prisma.product.findMany({
        where: whereClause,
        include: includeClause,
        orderBy: {
          createdAt: 'desc',
        },
      });
      return {
        data,
        meta: {
          totalItems: data.length,
          totalPages: 1,
          currentPage: 1,
          limit: data.length,
        },
      };
    }

    const page = Math.max(1, options.page || 1);
    const limit = Math.max(1, Math.min(100, options.limit || 10));
    const skip = (page - 1) * limit;

    const [totalItems, data] = await Promise.all([
      this.prisma.product.count({ where: whereClause }),
      this.prisma.product.findMany({
        where: whereClause,
        include: includeClause,
        orderBy: {
          createdAt: 'desc',
        },
        skip,
        take: limit,
      }),
    ]);

    return {
      data,
      meta: {
        totalItems,
        totalPages: Math.ceil(totalItems / limit) || 1,
        currentPage: page,
        limit,
      },
    };
  }

  async getProductById(id: string, businessId: string) {
    const product = await this.prisma.product.findFirst({
      where: { id, businessId },
      include: {
        category: true,
        brand: true,
        unit: true,
        warranty: true,
        createdBy: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        updatedBy: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        productImeis: {
          include: {
            branch: {
              select: {
                id: true,
                name: true,
              },
            },
          },
          orderBy: {
            createdAt: 'desc',
          },
        },
        variants: {
          include: {
            valueMaps: {
              include: {
                value: {
                  include: {
                    variation: true,
                  },
                },
              },
            },
            groupPrices: {
              include: {
                sellingPriceGroup: true,
              },
            },
            purchaseLines: {
              include: {
                branch: {
                  select: {
                    id: true,
                    name: true,
                  },
                },
                purchase: {
                  select: {
                    id: true,
                    purchaseNumber: true,
                    purchaseDate: true,
                    supplier: {
                      select: {
                        id: true,
                        name: true,
                      },
                    },
                    branch: {
                      select: {
                        id: true,
                        name: true,
                      },
                    },
                  },
                },
              },
              orderBy: {
                createdAt: 'desc',
              },
            },
            saleLines: {
              take: 50,
              include: {
                branch: {
                  select: {
                    id: true,
                    name: true,
                  },
                },
                sale: {
                  select: {
                    id: true,
                    invoiceNumber: true,
                    saleDate: true,
                    customer: {
                      select: {
                        id: true,
                        name: true,
                      },
                    },
                    branch: {
                      select: {
                        id: true,
                        name: true,
                      },
                    },
                  },
                },
              },
              orderBy: {
                createdAt: 'desc',
              },
            },
            stockAdjustmentLines: {
              take: 50,
              include: {
                branch: {
                  select: {
                    id: true,
                    name: true,
                  },
                },
                stockAdjustment: {
                  select: {
                    id: true,
                    adjustmentNumber: true,
                    adjustmentDate: true,
                    type: true,
                    reason: true,
                    branch: {
                      select: {
                        id: true,
                        name: true,
                      },
                    },
                  },
                },
              },
              orderBy: {
                createdAt: 'desc',
              },
            },
            stockTransferLines: {
              take: 50,
              include: {
                stockTransfer: {
                  select: {
                    id: true,
                    transferNumber: true,
                    transferDate: true,
                    status: true,
                    fromBranch: {
                      select: {
                        id: true,
                        name: true,
                      },
                    },
                    toBranch: {
                      select: {
                        id: true,
                        name: true,
                      },
                    },
                  },
                },
              },
              orderBy: {
                createdAt: 'desc',
              },
            },
          },
        },
        branches: {
          include: {
            branch: true,
          },
        },
      },
    });

    if (!product) {
      throw new BadRequestException('Product not found');
    }

    return product;
  }

  async updateProduct(
    id: string,
    businessId: string,
    data: {
      name?: string;
      description?: string;
      imageUrl?: string;
      isActive?: boolean;
      enableStock?: boolean;
      enableImei?: boolean;
      isImei?: boolean;
      alertQuantity?: number;
      notForSelling?: boolean;
      weight?: number;
      categoryId?: string | null;
      brandId?: string | null;
      unitId?: string | null;
      warrantyId?: string | null;
      branchIds?: string[];
      // For SINGLE type
      sku?: string;
      purchasePrice?: number;
      sellingPrice?: number;
      groupPrices?: GroupPriceInput[];
      // For VARIABLE type
      variants?: VariantInput[];
      updatedById?: string;
    },
  ) {
    const product = await this.getProductById(id, businessId);
    const {
      name,
      description,
      imageUrl,
      isActive,
      enableStock,
      enableImei,
      isImei,
      alertQuantity,
      notForSelling,
      weight,
      categoryId,
      brandId,
      unitId,
      warrantyId,
      branchIds,
      sku,
      purchasePrice,
      sellingPrice,
      groupPrices,
      variants,
      updatedById,
    } = data;

    // 1. Validations
    if (name !== undefined) {
      if (name.trim().length < 2) {
        throw new BadRequestException('Product name must be at least 2 characters');
      }
      if (name.trim().toLowerCase() !== product.name.toLowerCase()) {
        const existingProduct = await this.prisma.product.findFirst({
          where: { name: { equals: name.trim(), mode: 'insensitive' }, businessId, id: { not: id } },
        });
        if (existingProduct) {
          throw new BadRequestException(`A product named "${name.trim()}" already exists in your catalog`);
        }
      }
    }

    if (purchasePrice !== undefined && purchasePrice < 0) {
      throw new BadRequestException('Purchase price must be 0 or greater');
    }
    if (sellingPrice !== undefined && sellingPrice < 0) {
      throw new BadRequestException('Selling price must be 0 or greater');
    }

    if (product.type === ProductType.VARIABLE && variants !== undefined) {
      if (variants.length === 0) {
        throw new BadRequestException('At least one variant must be defined for variable products');
      }
      const seenSkus = new Set<string>();
      for (const v of variants) {
        if (!v.name || v.name.trim() === '') {
          throw new BadRequestException('Each variant must have a valid name');
        }
        if (v.purchasePrice !== undefined && v.purchasePrice < 0) {
          throw new BadRequestException(`Variant "${v.name}" purchase price must be 0 or greater`);
        }
        if (v.sellingPrice !== undefined && v.sellingPrice < 0) {
          throw new BadRequestException(`Variant "${v.name}" selling price must be 0 or greater`);
        }
        if (v.sku && v.sku.trim()) {
          const normSku = v.sku.trim().toUpperCase();
          if (seenSkus.has(normSku)) {
            throw new BadRequestException(`Duplicate SKU "${normSku}" found among the variants in this product`);
          }
          seenSkus.add(normSku);
        }
      }
    }

    // Cross-tenant verification
    if (categoryId) {
      const cat = await this.prisma.category.findFirst({ where: { id: categoryId, businessId } });
      if (!cat) throw new BadRequestException('Selected category does not exist in this business');
    }
    if (brandId) {
      const br = await this.prisma.brand.findFirst({ where: { id: brandId, businessId } });
      if (!br) throw new BadRequestException('Selected brand does not exist in this business');
    }
    if (unitId) {
      const un = await this.prisma.unit.findFirst({ where: { id: unitId, businessId } });
      if (!un) throw new BadRequestException('Selected unit does not exist in this business');
    }
    if (warrantyId) {
      const wr = await this.prisma.warranty.findFirst({ where: { id: warrantyId, businessId } });
      if (!wr) throw new BadRequestException('Selected warranty does not exist in this business');
    }

    // Resolve missing/empty SKUs during update
    let resolvedSku = sku !== undefined ? (sku.trim() !== '' ? sku.trim().toUpperCase() : null) : undefined;
    if (product.type === ProductType.SINGLE && resolvedSku === null) {
      resolvedSku = await this.generateUniqueSku(name || product.name, businessId);
    }

    const resolvedVariants = [];
    if (product.type === ProductType.VARIABLE && variants) {
      for (const v of variants) {
        let vSku = v.sku && v.sku.trim() ? v.sku.trim().toUpperCase() : null;
        if (!vSku || vSku === '') {
          vSku = await this.generateUniqueSku(v.name || `${name || product.name} Variant`, businessId);
        }
        resolvedVariants.push({
          ...v,
          sku: vSku,
        });
      }
    }

    // Check duplicate SKUs excluding the current product's variants
    const skuList: string[] = [];
    if (product.type === ProductType.SINGLE && resolvedSku) {
      skuList.push(resolvedSku);
    } else if (product.type === ProductType.VARIABLE && variants) {
      resolvedVariants.forEach((v) => {
        if (v.sku) skuList.push(v.sku);
      });
    }

    if (skuList.length > 0) {
      const existingSku = await this.prisma.productVariant.findFirst({
        where: {
          sku: { in: skuList },
          product: { businessId },
          productId: { not: id },
        },
      });
      if (existingSku) {
        throw new BadRequestException(`SKU "${existingSku.sku}" is already in use`);
      }
    }

    // Verify branches
    if (branchIds && branchIds.length > 0) {
      const validBranches = await this.prisma.branch.findMany({
        where: { id: { in: branchIds }, businessId },
      });
      if (validBranches.length !== branchIds.length) {
        throw new BadRequestException('One or more selected branches are invalid');
      }
    }

    // 2. Transactional Update
    return this.prisma.$transaction(async (tx) => {
      // Update branches
      if (branchIds !== undefined) {
        await tx.productBranch.deleteMany({ where: { productId: id } });
        if (branchIds.length > 0) {
          await tx.productBranch.createMany({
            data: branchIds.map((branchId) => ({
              productId: id,
              branchId,
            })),
          });
        }
      }

      // Update Product fields
      const updateData: any = {};
      if (name !== undefined) updateData.name = name.trim();
      if (description !== undefined) updateData.description = description || null;
      if (imageUrl !== undefined) updateData.imageUrl = imageUrl || null;
      if (isActive !== undefined) updateData.isActive = isActive;
      if (enableStock !== undefined) updateData.enableStock = enableStock;
      if (isImei !== undefined) {
        updateData.isImei = isImei;
        updateData.enableImei = isImei;
      } else if (enableImei !== undefined) {
        updateData.isImei = enableImei;
        updateData.enableImei = enableImei;
      }
      if (alertQuantity !== undefined) updateData.alertQuantity = alertQuantity;
      if (notForSelling !== undefined) updateData.notForSelling = notForSelling;
      if (weight !== undefined) updateData.weight = weight || null;
      if (categoryId !== undefined) updateData.categoryId = categoryId || null;
      if (brandId !== undefined) updateData.brandId = brandId || null;
      if (unitId !== undefined) updateData.unitId = unitId || null;
      if (warrantyId !== undefined) updateData.warrantyId = warrantyId || null;
      if (updatedById !== undefined) updateData.updatedById = updatedById;

      await tx.product.update({
        where: { id },
        data: updateData,
      });

      // Update Variants
      if (product.type === ProductType.SINGLE) {
        const singleVariant = product.variants[0];
        const vUpdateData: any = {};
        if (name !== undefined) vUpdateData.name = name.trim();
        if (resolvedSku !== undefined) vUpdateData.sku = resolvedSku;
        if (purchasePrice !== undefined) vUpdateData.purchasePrice = purchasePrice;
        if (sellingPrice !== undefined) vUpdateData.sellingPrice = sellingPrice;

        await tx.productVariant.update({
          where: { id: singleVariant.id },
          data: vUpdateData,
        });

        // Update Group Prices
        if (groupPrices !== undefined) {
          await tx.variantGroupPrice.deleteMany({ where: { variantId: singleVariant.id } });
          if (groupPrices.length > 0) {
            await tx.variantGroupPrice.createMany({
              data: groupPrices.map((gp) => ({
                variantId: singleVariant.id,
                sellingPriceGroupId: gp.sellingPriceGroupId,
                price: gp.price,
              })),
            });
          }
        }
      } else if (variants !== undefined) {
        // For VARIABLE: Synchronize variants
        const inputVariantIds = variants.map((v) => v.id).filter(Boolean);

        // 1. Delete variants that are no longer in the input
        await tx.productVariant.deleteMany({
          where: {
            productId: id,
            id: { notIn: inputVariantIds },
          },
        });

        // 2. Add or Update variants
        for (const vInput of resolvedVariants) {
          if (vInput.id) {
            // Update existing variant
            await tx.productVariant.update({
              where: { id: vInput.id },
              data: {
                name: vInput.name.trim(),
                sku: vInput.sku,
                barcode: null,
                purchasePrice: vInput.purchasePrice,
                sellingPrice: vInput.sellingPrice,
              },
            });

            // Sync Group Prices for this variant
            if (vInput.groupPrices !== undefined) {
              await tx.variantGroupPrice.deleteMany({ where: { variantId: vInput.id } });
              if (vInput.groupPrices.length > 0) {
                await tx.variantGroupPrice.createMany({
                  data: vInput.groupPrices.map((gp) => ({
                    variantId: vInput.id,
                    sellingPriceGroupId: gp.sellingPriceGroupId,
                    price: gp.price,
                  })),
                });
              }
            }
          } else {
            // Create new variant
            await tx.productVariant.create({
              data: {
                name: vInput.name.trim(),
                sku: vInput.sku,
                barcode: null,
                purchasePrice: vInput.purchasePrice,
                sellingPrice: vInput.sellingPrice,
                productId: id,
                valueMaps: vInput.valueIds && vInput.valueIds.length > 0
                  ? {
                      create: vInput.valueIds.map((valueId) => ({
                        valueId,
                      })),
                    }
                  : undefined,
                groupPrices: vInput.groupPrices && vInput.groupPrices.length > 0
                  ? {
                      create: vInput.groupPrices.map((gp) => ({
                        sellingPriceGroupId: gp.sellingPriceGroupId,
                        price: gp.price,
                      })),
                    }
                  : undefined,
              },
            });
          }
        }
      }

      return tx.product.findUnique({
        where: { id },
        include: {
          variants: {
            include: {
              valueMaps: {
                include: {
                  value: true,
                },
              },
              groupPrices: {
                include: {
                  sellingPriceGroup: true,
                },
              },
            },
          },
          branches: {
            include: {
              branch: true,
            },
          },
        },
      });
    });
  }

  private async generateUniqueSku(productName: string, businessId: string): Promise<string> {
    try {
      // Find the highest purely numeric SKU in the business
      const result = await this.prisma.$queryRaw<Array<{ sku: string }>>`
        SELECT pv.sku 
        FROM "ProductVariant" pv
        JOIN "Product" p ON p.id = pv."productId"
        WHERE p."businessId" = ${businessId}
          AND pv.sku ~ '^[0-9]+$'
        ORDER BY pv.sku DESC
        LIMIT 1
      `;

      let nextNum = 1;
      if (result && result.length > 0) {
        const lastSku = result[0].sku;
        const parsed = parseInt(lastSku, 10);
        if (!isNaN(parsed)) {
          nextNum = parsed + 1;
        }
      }

      // Pad with 5 zeros (e.g. 00001)
      let uniqueSku = String(nextNum).padStart(5, '0');
      
      // Double check if there's any clash
      let isUnique = false;
      let attempts = 0;
      while (!isUnique && attempts < 5) {
        const existing = await this.prisma.productVariant.findFirst({
          where: {
            sku: uniqueSku,
            product: { businessId }
          }
        });
        if (!existing) {
          isUnique = true;
        } else {
          nextNum++;
          uniqueSku = String(nextNum).padStart(5, '0');
        }
        attempts++;
      }

      return uniqueSku;
    } catch (err) {
      // Fallback generator in case of database error or raw query issue
      const suffix = Math.floor(1000 + Math.random() * 9000);
      return `PROD-${suffix}`;
    }
  }

  async deleteProduct(id: string, businessId: string) {
    const product = await this.getProductById(id, businessId);

    const variants = await this.prisma.productVariant.findMany({
      where: { productId: id },
      select: { id: true },
    });
    const variantIds = variants.map((v) => v.id);

    if (variantIds.length > 0) {
      const [
        salesCount,
        salesReturnCount,
        purchaseCount,
        purchaseReturnCount,
        transferCount,
        adjustmentCount,
        soldImeiCount,
      ] = await Promise.all([
        this.prisma.saleLine.count({ where: { variantId: { in: variantIds } } }),
        this.prisma.salesReturnLine.count({ where: { variantId: { in: variantIds } } }),
        this.prisma.purchaseLine.count({ where: { variantId: { in: variantIds }, purchaseId: { not: null } } }),
        this.prisma.purchaseReturnLine.count({ where: { variantId: { in: variantIds } } }),
        this.prisma.stockTransferLine.count({ where: { variantId: { in: variantIds } } }),
        this.prisma.stockAdjustmentLine.count({ where: { variantId: { in: variantIds } } }),
        this.prisma.productImei.count({ where: { productId: id, status: { not: ImeiStatus.IN_STOCK } } }),
      ]);

      const reasons: string[] = [];

      if (salesCount > 0) reasons.push(`${salesCount} sales transaction(s)`);
      if (salesReturnCount > 0) reasons.push(`${salesReturnCount} sales return record(s)`);
      if (purchaseCount > 0) reasons.push(`${purchaseCount} supplier purchase bill(s)`);
      if (purchaseReturnCount > 0) reasons.push(`${purchaseReturnCount} purchase return record(s)`);
      if (transferCount > 0) reasons.push(`${transferCount} branch transfer record(s)`);
      if (adjustmentCount > 0) reasons.push(`${adjustmentCount} stock adjustment record(s)`);
      if (soldImeiCount > 0) reasons.push(`${soldImeiCount} sold/transferred IMEI unit(s)`);

      if (reasons.length > 0) {
        throw new BadRequestException(
          `Cannot delete "${product.name}" because it has existing transaction records: ${reasons.join(', ')}. To preserve inventory and audit history, please deactivate this product instead.`
        );
      }
    }

    await this.prisma.product.delete({ where: { id } });
    return { success: true };
  }
}
