import { Controller, Get, Body, Post, Put, Delete, Param, Query, UseGuards, Req } from '@nestjs/common';
import { ExpenseCategoriesService } from './expense-categories.service';
import { CreateExpenseCategoryDto } from './dto/create-expense-category.dto';
import { UpdateExpenseCategoryDto } from './dto/update-expense-category.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('expense-categories')
export class ExpenseCategoriesController {
  constructor(private readonly expenseCategoriesService: ExpenseCategoriesService) {}

  @Permissions(Permission.PURCHASE_CREATE)
  @Post()
  create(@Req() req: any, @Body() createDto: CreateExpenseCategoryDto) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      createDto.businessId = user.businessId;
    }
    if (!createDto.createdById) {
      createDto.createdById = user.id;
    }
    return this.expenseCategoriesService.create(createDto);
  }

  @Permissions(Permission.PURCHASE_VIEW)
  @Get()
  findAll(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.expenseCategoriesService.findAll(bId, branchId);
  }

  @Permissions(Permission.PURCHASE_VIEW)
  @Get(':id')
  findOne(@Req() req: any, @Param('id') id: string, @Query('businessId') businessId?: string) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.expenseCategoriesService.findOne(id, bId);
  }

  @Permissions(Permission.PURCHASE_CREATE)
  @Put(':id')
  update(@Req() req: any, @Param('id') id: string, @Body() updateDto: UpdateExpenseCategoryDto) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      updateDto.businessId = user.businessId;
    }
    if (!updateDto.updatedById) {
      updateDto.updatedById = user.id;
    }
    return this.expenseCategoriesService.update(id, updateDto);
  }

  @Permissions(Permission.PURCHASE_CREATE)
  @Delete(':id')
  remove(@Req() req: any, @Param('id') id: string, @Query('businessId') businessId?: string) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.expenseCategoriesService.remove(id, bId);
  }
}

