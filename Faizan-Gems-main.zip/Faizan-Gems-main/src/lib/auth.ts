import crypto from "crypto";
import bcrypt from "bcryptjs";

function getAuthSecret(): string {
  const secret = process.env.AUTH_SECRET;
  if (!secret) {
    return "faizan_gems_default_auth_secret_key_production_fallback_2026";
  }
  return secret;
}

export const SESSION_COOKIE_NAME = "faizan_admin_session";
export const OAUTH_NONCE_COOKIE = "fg_oauth_nonce";

export interface AdminSessionUser {
  jti?: string;
  email: string;
  name: string;
  role: "ADMIN";
  issuedAt: number;
  expiresAt: number;
}

/**
 * Constant-time comparison between two strings to prevent timing attacks
 */
export function timingSafeCompare(a: string, b: string): boolean {
  try {
    const bufA = Buffer.from(a, "utf-8");
    const bufB = Buffer.from(b, "utf-8");

    if (bufA.length !== bufB.length) {
      // Dummy comparison with bufA to equalize execution time
      crypto.timingSafeEqual(bufA, bufA);
      return false;
    }

    return crypto.timingSafeEqual(bufA, bufB);
  } catch {
    return false;
  }
}

/**
 * Hash a password using bcrypt (cost factor 12)
 */
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

/**
 * Verify a plain-text password against a bcrypt hash
 */
export async function verifyPassword(plainText: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plainText, hash);
}

/**
 * Create a cryptographically signed session token with random jti nonce
 */
export function createSessionToken(user: { email: string; name: string }): string {
  const now = Date.now();
  const expiresAt = now + 7 * 24 * 60 * 60 * 1000; // 7 days

  const payload: AdminSessionUser = {
    jti: crypto.randomUUID(),
    email: user.email,
    name: user.name,
    role: "ADMIN",
    issuedAt: now,
    expiresAt,
  };

  const payloadBase64 = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const signature = crypto
    .createHmac("sha256", getAuthSecret())
    .update(payloadBase64)
    .digest("base64url");

  return `${payloadBase64}.${signature}`;
}

/**
 * Verify a signed session token in Node.js environment using crypto.timingSafeEqual
 */
export function verifySessionToken(token: string): AdminSessionUser | null {
  try {
    const [payloadBase64, signature] = token.split(".");
    if (!payloadBase64 || !signature) return null;

    const expectedSignature = crypto
      .createHmac("sha256", getAuthSecret())
      .update(payloadBase64)
      .digest("base64url");

    if (
      !crypto.timingSafeEqual(
        Buffer.from(signature),
        Buffer.from(expectedSignature)
      )
    ) {
      return null;
    }

    const payload: AdminSessionUser = JSON.parse(
      Buffer.from(payloadBase64, "base64url").toString("utf-8")
    );

    // Enforce role and expiration
    if (payload.role !== "ADMIN" || Date.now() > payload.expiresAt) {
      return null;
    }

    return payload;
  } catch {
    return null;
  }
}

/**
 * Verify a signed session token in Edge/Next Middleware environments using Web Crypto API
 */
export async function verifySessionTokenEdge(
  token: string,
  secretOverride?: string
): Promise<AdminSessionUser | null> {
  try {
    const [payloadBase64, signatureBase64] = token.split(".");
    if (!payloadBase64 || !signatureBase64) return null;

    const secret = secretOverride || getAuthSecret();
    const enc = new TextEncoder();
    const key = await globalThis.crypto.subtle.importKey(
      "raw",
      enc.encode(secret),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["verify"]
    );

    // Convert base64url to Uint8Array
    const base64 = signatureBase64.replace(/-/g, "+").replace(/_/g, "/");
    const pad = base64.length % 4;
    const padded = pad ? base64 + "=".repeat(4 - pad) : base64;
    const binary = atob(padded);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }

    const isValid = await globalThis.crypto.subtle.verify(
      "HMAC",
      key,
      bytes,
      enc.encode(payloadBase64)
    );

    if (!isValid) return null;

    const json = atob(payloadBase64.replace(/-/g, "+").replace(/_/g, "/"));
    const payload: AdminSessionUser = JSON.parse(json);

    if (payload.role !== "ADMIN" || Date.now() > payload.expiresAt) {
      return null;
    }

    return payload;
  } catch {
    return null;
  }
}

export const CUSTOMER_SESSION_COOKIE_NAME = "faizan_customer_session";

export interface CustomerSessionUser {
  id: string;
  email: string;
  name: string;
  phone?: string;
  role: "CUSTOMER";
  issuedAt: number;
  expiresAt: number;
}

/**
 * Create a cryptographically signed session token for customers
 */
export function createCustomerSessionToken(user: {
  id: string;
  email: string;
  name: string;
  phone?: string;
}): string {
  const now = Date.now();
  const expiresAt = now + 14 * 24 * 60 * 60 * 1000; // 14 days for customer session

  const payload: CustomerSessionUser = {
    id: user.id,
    email: user.email,
    name: user.name,
    phone: user.phone || "",
    role: "CUSTOMER",
    issuedAt: now,
    expiresAt,
  };

  const payloadBase64 = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const signature = crypto
    .createHmac("sha256", getAuthSecret())
    .update(payloadBase64)
    .digest("base64url");

  return `${payloadBase64}.${signature}`;
}

/**
 * Verify a customer session token using crypto.timingSafeEqual
 */
export function verifyCustomerSessionToken(token: string): CustomerSessionUser | null {
  try {
    const [payloadBase64, signature] = token.split(".");
    if (!payloadBase64 || !signature) return null;

    const expectedSignature = crypto
      .createHmac("sha256", getAuthSecret())
      .update(payloadBase64)
      .digest("base64url");

    if (
      !crypto.timingSafeEqual(
        Buffer.from(signature),
        Buffer.from(expectedSignature)
      )
    ) {
      return null;
    }

    const payload: CustomerSessionUser = JSON.parse(
      Buffer.from(payloadBase64, "base64url").toString("utf-8")
    );

    if (payload.role !== "CUSTOMER" || Date.now() > payload.expiresAt) {
      return null;
    }

    return payload;
  } catch {
    return null;
  }
}

/**
 * Create a cryptographically signed HMAC token for guest order verification
 */
export function createOrderAccessToken(orderNumberOrId: string): string {
  const normalized = (orderNumberOrId || "").trim();
  return crypto
    .createHmac("sha256", getAuthSecret())
    .update(`order_access:${normalized}`)
    .digest("base64url");
}

/**
 * Verify a guest order access token using timing-safe comparison
 */
export function verifyOrderAccessToken(orderNumberOrId: string, token?: string | null): boolean {
  try {
    if (!orderNumberOrId || !token) return false;
    const expected = createOrderAccessToken(orderNumberOrId);
    return timingSafeCompare(token.trim(), expected);
  } catch {
    return false;
  }
}

/**
 * Create a cryptographically signed HMAC token for payment slip access
 */
export function createSlipAccessToken(filename: string): string {
  const normalized = (filename || "").trim();
  return crypto
    .createHmac("sha256", getAuthSecret())
    .update(`slip_access:${normalized}`)
    .digest("base64url");
}

/**
 * Verify a slip access token using timing-safe comparison
 */
export function verifySlipAccessToken(filename: string, token?: string | null): boolean {
  try {
    if (!filename || !token) return false;
    const expected = createSlipAccessToken(filename);
    return timingSafeCompare(token.trim(), expected);
  } catch {
    return false;
  }
}
