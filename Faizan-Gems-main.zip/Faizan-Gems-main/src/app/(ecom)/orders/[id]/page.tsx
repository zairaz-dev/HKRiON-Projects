"use client";

import React, { use, useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import {
  CheckIcon,
  SecurityLockIcon,
} from "@/components/ui/LuxuryIcons";
import { LuxuryPrice } from "@/components/ui/LuxuryPrice";
import { useCurrency } from "@/features/currency/context/CurrencyContext";
import { getCountryFlag } from "@/lib/data/countries";
import { SITE_CONFIG } from "@/lib/constants/site";

interface OrderDetail {
  id: string;
  orderNumber: string;
  date: string;
  client: {
    fullName: string;
    email: string;
    phone: string;
  };
  shippingAddress: {
    address: string;
    city: string;
    state?: string;
    postalCode?: string;
    country: string;
  };
  courier: string;
  status: "pending_verification" | "pending_inspection" | "accepted" | "vault_packed" | "in_transit" | "delivered" | "rejected";
  subtotal?: number;
  total: number;
  paymentMethod?: string;
  bankReference?: string | null;
  items: Array<{
    gemstone?: {
      id?: string;
      name?: string;
      carat?: number;
      price?: number;
      origin?: string;
      cut?: string;
    };
    setting?: {
      name?: string;
    } | string;
    selectedWeight?: number;
    selectedPrice?: number;
    quantity?: number;
  }>;
}

export default function OrderDetailsPage({ params }: { params: Promise<{ id: string }> }) {
  const resolvedParams = use(params);
  const orderId = resolvedParams.id;
  const { formatPrice } = useCurrency();

  const [order, setOrder] = useState<OrderDetail | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const search = typeof window !== "undefined" ? window.location.search : "";
    fetch(`/api/orders/${orderId}${search}`)
      .then((res) => {
        if (res.ok) return res.json();
        return null;
      })
      .then((data) => {
        if (data?.order) {
          setOrder(data.order);
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [orderId]);

  const currentStatus = order?.status || "pending_verification";

  const rawPaymentMethod = order?.paymentMethod || "Bank Transfer";
  const bankRef =
    order?.bankReference ||
    rawPaymentMethod.match(/\(Ref:\s*([^)]+)\)/i)?.[1]?.trim() ||
    null;

  const displayPaymentMethod = (() => {
    if (!rawPaymentMethod) return "Bank Transfer";
    if (rawPaymentMethod.toLowerCase().includes("wire") || rawPaymentMethod.toLowerCase().includes("bank")) {
      return "Bank Transfer";
    }
    if (rawPaymentMethod.toLowerCase().includes("card")) {
      return "Credit / Debit Card";
    }
    return rawPaymentMethod.replace(/\s*\(Ref:[^)]+\)/i, "").trim();
  })();

  const isCard =
    rawPaymentMethod.toLowerCase().includes("card") ||
    rawPaymentMethod.toLowerCase().includes("credit") ||
    rawPaymentMethod.toLowerCase().includes("debit");

  const getStepStatus = (stepIndex: number): "completed" | "current" | "upcoming" => {
    switch (currentStatus) {
      case "pending_verification":
      case "pending_inspection":
        if (stepIndex === 0) return "completed";
        if (stepIndex === 1) return "current";
        return "upcoming";
      case "accepted":
        if (stepIndex <= 1) return "completed";
        if (stepIndex === 2) return "current";
        return "upcoming";
      case "vault_packed":
        if (stepIndex <= 2) return "completed";
        if (stepIndex === 3) return "current";
        return "upcoming";
      case "in_transit":
        if (stepIndex <= 3) return "completed";
        if (stepIndex === 4) return "current";
        return "upcoming";
      case "delivered":
        return "completed";
      case "rejected":
        if (stepIndex === 0) return "completed";
        return "upcoming";
      default:
        return stepIndex === 0 ? "completed" : "upcoming";
    }
  };

  const trackingSteps = [
    {
      title: "Order Placed",
      time: order?.date || "Placed",
      status: getStepStatus(0),
      desc: "Your order has been received and registered.",
    },
    {
      title: "Payment Verification",
      time: currentStatus === "rejected"
        ? "Declined ✕"
        : currentStatus === "pending_verification" || currentStatus === "pending_inspection"
        ? "In Review"
        : "Verified ✓",
      status: getStepStatus(1),
      desc: currentStatus === "rejected"
        ? "Payment was declined or could not be verified."
        : isCard
        ? "Your card payment was authorized and is being processed for packaging."
        : "We are checking your bank transfer details and payment slip.",
    },
    {
      title: "Order Confirmed",
      time: currentStatus === "accepted" ? "Confirmed ✓" : (["vault_packed", "in_transit", "delivered"].includes(currentStatus) ? "Completed" : "Pending"),
      status: getStepStatus(2),
      desc: "Payment is verified and your gemstone is prepared for packing.",
    },
    {
      title: "Packed & Ready",
      time: ["vault_packed", "in_transit", "delivered"].includes(currentStatus) ? "Packed & Inspected" : "Waiting for Packing",
      status: getStepStatus(3),
      desc: "Your gemstone is carefully inspected and placed in its presentation box.",
    },
    {
      title: "Delivery",
      time: currentStatus === "delivered" ? "Delivered ✓" : (currentStatus === "in_transit" ? "On the Way" : "Est. 2-3 business days"),
      status: getStepStatus(4),
      desc: "Secure insured delivery with signature required upon delivery.",
    },
  ];

  const handlePrint = () => {
    const originalTitle = document.title;
    document.title = "";
    window.print();
    setTimeout(() => {
      document.title = originalTitle;
    }, 1500);
  };

  return (
    <>
      {/* ========================================================================= */}
      {/* 1. PRINT-ONLY CLEAN OFFICIAL RECEIPT (Appears ONLY when printing)        */}
      {/* ========================================================================= */}
      {order && (
        <div className="print-only hidden print:block text-black bg-white font-sans max-w-2xl mx-auto p-4 leading-normal">
          {/* Official Letterhead & Logo */}
          <div className="border-b-2 border-black pb-4 flex items-start justify-between">
            <div className="space-y-1">
              <div className="relative w-44 h-12 mb-2">
                <Image
                  src="/faizan-gems-logo.png"
                  alt="Faizan Gems"
                  width={176}
                  height={48}
                  className="object-contain"
                  priority
                />
              </div>
              <h1 className="font-serif text-lg font-bold uppercase tracking-wider text-black">
                {SITE_CONFIG.legalName}
              </h1>
              <p className="text-[11px] text-stone-600">
                Natural Certified Gemstones &bull; High Jewellery
              </p>
              <p className="text-[11px] text-stone-600">
                {SITE_CONFIG.showroom.fullAddress}
              </p>
              <p className="text-[11px] text-stone-600">
                Tel: {SITE_CONFIG.contact.phone} / {SITE_CONFIG.contact.secondaryPhone} &bull; {SITE_CONFIG.contact.email}
              </p>
            </div>

            <div className="text-right space-y-1">
              <span className="text-[10px] uppercase font-bold tracking-widest text-stone-500 block">
                Official Order Receipt
              </span>
              <span className="text-base font-mono font-bold block text-black">
                {order.id}
              </span>
              <p className="text-xs text-stone-700">Date: {order.date}</p>
              <div className="mt-2 inline-block px-2.5 py-1 border border-black text-[10px] uppercase font-bold tracking-wider">
                {currentStatus === "accepted"
                  ? "✓ Payment Verified"
                  : currentStatus === "rejected"
                  ? "✕ Payment Declined"
                  : "Payment Under Review"}
              </div>
            </div>
          </div>

          {/* Customer & Shipping Details */}
          <div className="grid grid-cols-2 gap-6 my-6 text-xs">
            <div className="space-y-1">
              <span className="font-bold uppercase tracking-wider text-stone-500 block text-[10px]">
                Customer Details:
              </span>
              <p className="font-bold text-sm text-black">{order.client.fullName}</p>
              {order.client.email && <p className="text-stone-700">{order.client.email}</p>}
              {order.client.phone && <p className="text-stone-700">{order.client.phone}</p>}
            </div>

            <div className="space-y-1 text-right">
              <span className="font-bold uppercase tracking-wider text-stone-500 block text-[10px]">
                Delivery Address:
              </span>
              {order.shippingAddress.address && <p className="text-black">{order.shippingAddress.address}</p>}
              <p className="text-black">
                {[
                  order.shippingAddress.city,
                  order.shippingAddress.state,
                  order.shippingAddress.postalCode,
                  order.shippingAddress.country,
                ]
                  .filter(Boolean)
                  .join(", ")}
              </p>
              <p className="text-stone-700 pt-1">
                Payment Method: <strong>{displayPaymentMethod}</strong>
              </p>
              {bankRef && (
                <p className="text-stone-700">
                  Reference: <strong>{bankRef}</strong>
                </p>
              )}
            </div>
          </div>

          {/* Itemized Order Items Table */}
          <div className="my-6">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b-2 border-black">
                  <th className="py-2.5 font-bold uppercase tracking-wider text-[10px]">Description</th>
                  <th className="py-2.5 text-center font-bold uppercase tracking-wider text-[10px]">Weight</th>
                  <th className="py-2.5 text-center font-bold uppercase tracking-wider text-[10px]">Qty</th>
                  <th className="py-2.5 text-right font-bold uppercase tracking-wider text-[10px]">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-300">
                {order.items && order.items.length > 0 ? (
                  order.items.map((item, idx) => {
                    const name = item.gemstone?.name || "Natural Gemstone";
                    const carat = item.selectedWeight || item.gemstone?.carat;
                    const price = item.selectedPrice || item.gemstone?.price || order.total;
                    const qty = item.quantity || 1;
                    const setting =
                      typeof item.setting === "string"
                        ? item.setting !== "loose" ? item.setting : null
                        : item.setting?.name;

                    return (
                      <tr key={idx}>
                        <td className="py-3 pr-4">
                          <div className="font-bold text-black">{name}</div>
                          {setting && (
                            <div className="text-[11px] text-stone-600">Setting: {setting}</div>
                          )}
                          {item.gemstone?.origin && (
                            <div className="text-[11px] text-stone-600">Origin: {item.gemstone.origin}</div>
                          )}
                        </td>
                        <td className="py-3 text-center text-stone-800 font-mono">
                          {carat ? `${Number(carat).toFixed(2)} ct` : "—"}
                        </td>
                        <td className="py-3 text-center text-stone-800 font-mono">
                          {qty}
                        </td>
                        <td className="py-3 text-right font-bold text-black font-mono">
                          {formatPrice(price * qty)}
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td className="py-3 font-bold text-black">Natural Certified Gemstone</td>
                    <td className="py-3 text-center">—</td>
                    <td className="py-3 text-center">1</td>
                    <td className="py-3 text-right font-bold text-black font-mono">
                      {formatPrice(order.total)}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Totals Section */}
          <div className="border-t-2 border-black pt-4 ml-auto w-64 space-y-1.5 text-xs">
            <div className="flex justify-between text-stone-700">
              <span>Subtotal:</span>
              <span className="font-mono">{formatPrice(order.subtotal || order.total)}</span>
            </div>
            <div className="flex justify-between text-stone-700">
              <span>Insured Delivery:</span>
              <span className="text-emerald-700 font-semibold">FREE</span>
            </div>
            <div className="border-t border-black pt-2 flex justify-between font-bold text-sm text-black">
              <span>Grand Total:</span>
              <span className="font-mono text-base">{formatPrice(order.total)}</span>
            </div>
          </div>

          {/* Receipt Footer & Authenticity Notice */}
          <div className="border-t border-stone-300 mt-10 pt-4 text-center text-[10px] text-stone-600 space-y-1">
            <p className="font-bold uppercase tracking-wider text-black">
              100% Certified Natural &bull; Conflict-Free
            </p>
            <p>
              Original gemological laboratory dossier is enclosed with delivery.
            </p>
            <p>
              For inquiries, contact client support at {SITE_CONFIG.contact.email} or {SITE_CONFIG.contact.phone} / {SITE_CONFIG.contact.secondaryPhone}.
            </p>
            <p className="pt-2 font-mono uppercase tracking-widest text-stone-500">
              *** THANK YOU FOR CHOOSING FAIZAN GEMS ***
            </p>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. REGULAR WEB UI (Hidden during print via .no-print)                     */}
      {/* ========================================================================= */}
      <div className="no-print bg-[#FAF8F5] min-h-screen py-12 lg:py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">

          {/* Success / Status Header */}
          <div className={`bg-white p-8 sm:p-12 text-center shadow-xl mb-10 ${currentStatus === "rejected" ? "border border-red-300" : "border border-[#C5A880]"}`}>
            <div className={`w-14 h-14 rounded-full mx-auto flex items-center justify-center mb-4 ${currentStatus === "rejected" ? "bg-red-50 text-red-600 border border-red-200" : "bg-[#18181D] text-[#C5A880]"}`}>
              {currentStatus === "rejected" ? (
                <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              ) : (
                <CheckIcon className="w-7 h-7" />
              )}
            </div>

            <span className="text-[11px] font-sans tracking-wide uppercase text-[#9A7B4F] block">
              {currentStatus === "rejected" ? "Order Status Update" : "Order Confirmation"}
            </span>
            <h1 className="font-serif text-3xl sm:text-4xl text-[#18181D] mt-1">
              {currentStatus === "accepted"
                ? "Order Confirmed & Payment Verified"
                : currentStatus === "delivered"
                ? "Order Delivered"
                : currentStatus === "rejected"
                ? "Payment Declined"
                : "Order Received"}
            </h1>
            <p className="text-xs sm:text-sm font-mono text-[#8C867D] mt-2">
              Order Reference: <strong className="text-[#18181D]">{orderId}</strong>
            </p>

            {/* Payment Status Reassurance Banner */}
            {currentStatus === "accepted" ? (
              <div className="mt-4 p-3.5 bg-emerald-50 border border-emerald-300 max-w-md mx-auto text-xs font-sans text-emerald-900 rounded-sm flex items-center justify-center gap-2">
                <CheckIcon className="w-4 h-4 text-emerald-700 shrink-0" />
                <span><strong>Payment Verified:</strong> Your payment has been confirmed and your order is being prepared.</span>
              </div>
            ) : currentStatus === "rejected" ? (
              <div className="mt-4 p-3.5 bg-red-50 border border-red-300 max-w-md mx-auto text-xs font-sans text-red-900 rounded-sm flex items-center justify-center gap-2">
                <span className="w-2 h-2 rounded-full bg-red-600 shrink-0" />
                <span><strong>Payment Rejected:</strong> The payment verification was declined. Please contact support or try a different payment method.</span>
              </div>
            ) : (currentStatus === "pending_verification" || currentStatus === "pending_inspection") ? (
              <div className={`mt-4 p-3.5 ${isCard ? "bg-emerald-50 border-emerald-300 text-emerald-900" : "bg-amber-50 border-amber-300 text-amber-900"} border max-w-md mx-auto text-xs font-sans rounded-sm flex items-center justify-center gap-2`}>
                <span className={`w-2 h-2 rounded-full ${isCard ? "bg-emerald-600" : "bg-amber-600"} shrink-0`} />
                <span>
                  {isCard ? (
                    <><strong>Card Payment Authorized:</strong> Your order has been placed and is being prepared for packaging.</>
                  ) : (
                    <><strong>Payment Under Review:</strong> We are checking your bank transfer details and payment slip.</>
                  )}
                </span>
              </div>
            ) : null}

            {order && (
              <div className="mt-4 p-3 bg-[#FAF8F5] border border-[#E8E4DC] max-w-md mx-auto text-xs font-sans text-[#554F47]">
                <span>Customer: <strong className="text-[#18181D]">{order.client.fullName}</strong></span>
                {order.shippingAddress.city && (
                  <span className="ml-3">
                    Delivery to: <strong className="text-[#18181D]">{getCountryFlag(order.shippingAddress.country)} {[order.shippingAddress.city, order.shippingAddress.country].filter(Boolean).join(", ")}</strong>
                  </span>
                )}
              </div>
            )}

            <p className="text-xs sm:text-sm text-[#554F47] font-sans max-w-lg mx-auto mt-4 leading-relaxed">
              {currentStatus === "rejected"
                ? "Because the payment could not be validated, this order will not be processed or delivered. If you need assistance, please contact our support team."
                : "Thank you for your order. We have received your order details. Once payment is confirmed, your certified gemstone will be safely packed and shipped to your address."}
            </p>

            <div className="mt-6 flex flex-wrap items-center justify-center gap-4">
              {currentStatus !== "rejected" && (
                <button
                  onClick={handlePrint}
                  className="px-6 py-2.5 bg-[#18181D] hover:bg-[#2A2A32] text-white text-xs uppercase tracking-wider font-sans transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
                  </svg>
                  Print Receipt
                </button>
              )}
              <Link
                href="/account"
                className="px-6 py-2.5 border border-[#C5A880] text-[#9A7B4F] text-xs uppercase tracking-wider font-sans hover:bg-[#FAF8F5] transition-colors"
              >
                View in My Account &rarr;
              </Link>
            </div>
          </div>

          {/* Clean Ordered Items Card (Screen UI) */}
          {order && (
            <div className="bg-white border border-[#E8E4DC] p-6 sm:p-8 shadow-sm mb-10 space-y-4">
              <div className="flex items-center justify-between border-b border-[#F2EFE9] pb-3">
                <span className="text-[10px] uppercase tracking-wider text-[#8C867D] font-sans font-medium">
                  Ordered Gemstone Details
                </span>
                {bankRef && (
                  <span className="text-xs font-mono text-[#8C867D]">
                    Reference: <strong className="text-[#18181D]">{bankRef}</strong>
                  </span>
                )}
              </div>

              <div className="divide-y divide-[#F2EFE9] text-xs font-sans">
                {order.items && order.items.length > 0 ? (
                  order.items.map((item, idx) => {
                    const name = item.gemstone?.name || "Natural Gemstone";
                    const carat = item.selectedWeight || item.gemstone?.carat;
                    const price = item.selectedPrice || item.gemstone?.price || order.total;
                    const qty = item.quantity || 1;
                    const setting =
                      typeof item.setting === "string"
                        ? item.setting !== "loose" ? item.setting : null
                        : item.setting?.name;

                    return (
                      <div key={idx} className="py-3 flex items-start justify-between gap-4">
                        <div className="space-y-0.5">
                          <h4 className="font-serif text-base text-[#18181D] font-medium">{name}</h4>
                          <div className="text-[11px] text-[#8C867D] flex flex-wrap gap-x-3">
                            {carat ? <span>Weight: <strong>{Number(carat).toFixed(2)} ct</strong></span> : null}
                            {item.gemstone?.cut ? <span>Cut: <strong>{item.gemstone.cut}</strong></span> : null}
                            {setting ? <span>Setting: <strong>{setting}</strong></span> : null}
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <span className="text-[10px] text-[#8C867D] block">Qty: {qty}</span>
                          <LuxuryPrice amount={price * qty} size="sm" />
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="py-3 flex justify-between items-center">
                    <span className="font-serif text-base text-[#18181D]">Natural Certified Gemstone</span>
                    <LuxuryPrice amount={order.total} size="sm" />
                  </div>
                )}
              </div>

              <div className="border-t border-[#F2EFE9] pt-3 flex justify-between items-center">
                <span className="text-xs uppercase text-[#8C867D] font-sans">
                  {currentStatus === "rejected" ? "Total Amount" : "Order Total"}
                </span>
                <LuxuryPrice amount={order.total} size="lg" />
              </div>
            </div>
          )}

          {/* Real-time Tracking Timeline — Hidden when payment is rejected */}
          {currentStatus !== "rejected" ? (
            <div className="bg-white border border-[#E8E4DC] p-6 sm:p-10 shadow-sm mb-10 space-y-8">
              <div className="border-b border-[#F2EFE9] pb-4">
                <span className="text-[10px] uppercase tracking-wider text-[#8C867D] font-sans">
                  Real-Time Order Tracking
                </span>
                <h2 className="font-serif text-xl text-[#18181D]">
                  Delivery Timeline
                </h2>
              </div>

              {/* Timeline steps */}
              <div className="relative pl-6 sm:pl-8 space-y-8 before:absolute before:left-[11px] sm:before:left-[15px] before:top-2 before:bottom-2 before:w-[1.5px] before:bg-[#E8E4DC]">
                {trackingSteps.map((stepItem, idx) => (
                  <div key={idx} className="relative">
                    {/* Dot */}
                    <div
                      className={`absolute -left-[24px] sm:-left-[32px] top-0.5 w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
                        stepItem.status === "completed"
                          ? "bg-[#18181D] text-[#C5A880]"
                          : stepItem.status === "current"
                          ? "bg-[#C5A880] text-[#0D0D11] ring-4 ring-[#C5A880]/20"
                          : "bg-[#F2EFE9] text-[#8C867D] border border-[#E8E4DC]"
                      }`}
                    >
                      {stepItem.status === "completed" ? "✓" : idx + 1}
                    </div>

                    <div>
                      <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
                        <h3 className="font-serif text-base text-[#18181D] font-medium">
                          {stepItem.title}
                        </h3>
                        <span className="text-[11px] font-mono text-[#8C867D]">
                          {stepItem.time}
                        </span>
                      </div>
                      <p className="text-xs text-[#6B655C] font-sans mt-1">{stepItem.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="bg-white border border-red-200 p-6 sm:p-10 shadow-sm mb-10 space-y-4 text-center">
              <div className="w-12 h-12 rounded-full bg-red-50 text-red-600 mx-auto flex items-center justify-center">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <circle cx="12" cy="12" r="10" />
                  <line x1="12" y1="8" x2="12" y2="12" />
                  <line x1="12" y1="16" x2="12.01" y2="16" />
                </svg>
              </div>
              <h2 className="font-serif text-xl text-[#18181D]">
                Order Processing Stopped
              </h2>
              <p className="text-xs sm:text-sm text-[#6B655C] max-w-md mx-auto">
                This order has been declined due to payment verification issues and will not be delivered. If you have questions or wish to complete this purchase with another payment method, please reach out to us.
              </p>
              <div className="pt-3 flex flex-wrap items-center justify-center gap-3">
                <Link
                  href="/contact"
                  className="px-5 py-2.5 bg-[#18181D] hover:bg-[#2A2A32] text-white text-xs uppercase tracking-wider font-sans transition-colors"
                >
                  Contact Support
                </Link>
                <Link
                  href="/shop"
                  className="px-5 py-2.5 border border-[#C5A880] text-[#9A7B4F] text-xs uppercase tracking-wider font-sans hover:bg-[#FAF8F5] transition-colors"
                >
                  Browse Gemstones
                </Link>
              </div>
            </div>
          )}

          {/* 30-Day Money Back Guarantee */}
          <div className="bg-[#18181D] text-white border border-[#2A2A32] p-8 shadow-md flex flex-col sm:flex-row items-center gap-6">
            <div className="w-12 h-12 rounded-full bg-white/5 border border-[#C5A880] text-[#C5A880] flex items-center justify-center flex-shrink-0">
              <SecurityLockIcon className="w-6 h-6" />
            </div>
            <div className="text-xs font-sans text-center sm:text-left space-y-1">
              <h4 className="font-serif text-lg text-white font-normal">
                30-Day Money-Back Guarantee
              </h4>
              <p className="text-[#D3CBBF] leading-relaxed">
                Take your time to inspect your gemstone. If you are not completely satisfied, you can return it within 30 days for a full refund.
              </p>
            </div>
            <Link
              href="/contact"
              className="whitespace-nowrap px-5 py-2.5 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-xs uppercase tracking-wider font-sans font-medium transition-colors"
            >
              Contact Support
            </Link>
          </div>

          <div className="mt-8 text-center">
            <Link
              href="/shop"
              className="text-xs uppercase tracking-luxury text-[#8C867D] hover:text-[#18181D] font-sans"
            >
              &larr; Return to Shop
            </Link>
          </div>
        </div>
      </div>
    </>
  );
}
