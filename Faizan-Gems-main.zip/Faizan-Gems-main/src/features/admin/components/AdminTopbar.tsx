"use client";

import React, { useState, useRef, useEffect, useMemo } from "react";
import Image from "next/image";
import Link from "next/link";
import { useCMS } from "@/features/cms/useCMS";
import { AdminTab, AdminUser, AdminOrder } from "../types";
import { AdminProfileModal } from "./AdminProfileModal";
import { LuxuryPrice } from "@/components/ui/LuxuryPrice";
import { SITE_CONFIG } from "@/lib/constants/site";

interface AdminTopbarProps {
  activeTab: AdminTab;
  setActiveTab?: (tab: AdminTab) => void;
  setIsMobileSidebarOpen: (open: boolean) => void;
  onOpenAddModal?: () => void;
  adminUser?: AdminUser | null;
  handleLogout?: () => void;
  onUpdateAdminUser?: (user: AdminUser) => void;
  ordersList?: AdminOrder[];
}

const TAB_LABELS: Record<AdminTab, string> = {
  overview: "Dashboard",
  inventory: "Inventory",
  orders: "Orders",
  clients: "Customers",
  inquiries: "Messages & Inquiries",
  cms: "Settings",
  vault_security: "Security & Database",
};

function formatRelativeTime(dateStr?: string | null): string {
  if (!dateStr) return "Recently";
  const date = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  if (isNaN(diffMs) || diffMs < 0) return "Just now";

  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHour = Math.floor(diffMin / 60);
  const diffDays = Math.floor(diffHour / 24);

  if (diffSec < 45) return "Just now";
  if (diffMin < 60) return `${diffMin}m ago`;
  if (diffHour < 24) return `${diffHour}h ago`;
  if (diffDays === 1) return "Yesterday";
  if (diffDays < 7) return `${diffDays}d ago`;
  return date.toLocaleDateString("en-GB", { day: "2-digit", month: "short" });
}

function getOrderBadgeClass(status?: string | null) {
  switch (status) {
    case "pending_verification":
    case "pending_inspection":
      return "bg-amber-950/70 text-amber-300 border-amber-800/60";
    case "accepted":
      return "bg-emerald-950/70 text-emerald-300 border-emerald-700/80";
    case "vault_packed":
      return "bg-purple-950/70 text-purple-300 border-purple-800/60";
    case "in_transit":
      return "bg-blue-950/70 text-blue-300 border-blue-800/60";
    case "delivered":
      return "bg-emerald-950/60 text-emerald-300 border-emerald-800/60";
    case "rejected":
      return "bg-red-950/70 text-red-300 border-red-700/80";
    default:
      return "bg-gray-800 text-gray-300 border-gray-700";
  }
}

function getOrderBadgeLabel(status?: string | null) {
  switch (status) {
    case "pending_verification":
    case "pending_inspection":
      return "Pending Verification";
    case "accepted":
      return "Payment Confirmed";
    case "vault_packed":
      return "Packed & Ready";
    case "in_transit":
      return "In Transit";
    case "delivered":
      return "Delivered";
    case "rejected":
      return "Declined";
    default:
      return status || "Pending";
  }
}

export function AdminTopbar({
  activeTab,
  setActiveTab,
  setIsMobileSidebarOpen,
  adminUser,
  handleLogout,
  onUpdateAdminUser,
  ordersList = [],
}: AdminTopbarProps) {
  const { getBlock } = useCMS();
  const topbarLogo = getBlock("branding.footer_logo", getBlock("branding.header_logo", "/faizan-gems-logo.png"));

  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);

  // Notifications State
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [viewedOrderIds, setViewedOrderIds] = useState<Set<string>>(new Set());
  const [mounted, setMounted] = useState(false);
  const notificationsRef = useRef<HTMLDivElement>(null);

  // Initialize viewedOrderIds from localStorage on mount
  useEffect(() => {
    setMounted(true);
    try {
      const stored = localStorage.getItem("fg_admin_viewed_order_ids");
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          setViewedOrderIds(new Set(parsed));
        }
      }
    } catch {
      // ignore
    }
  }, []);

  // Filter orders that have not yet been viewed by the admin
  const unviewedOrders = useMemo(() => {
    if (!mounted || !ordersList || ordersList.length === 0) return [];
    return ordersList.filter(
      (o) => !viewedOrderIds.has(o.id) && !viewedOrderIds.has(o.orderNumber || o.id)
    );
  }, [mounted, ordersList, viewedOrderIds]);

  const hasUnviewedOrders = unviewedOrders.length > 0;
  const unviewedCount = unviewedOrders.length;

  // Mark current orders as viewed
  const markOrdersAsViewed = () => {
    if (!ordersList || ordersList.length === 0) return;
    const updated = new Set(viewedOrderIds);
    ordersList.forEach((o) => {
      updated.add(o.id);
      if (o.orderNumber) updated.add(o.orderNumber);
    });
    setViewedOrderIds(updated);
    try {
      localStorage.setItem("fg_admin_viewed_order_ids", JSON.stringify(Array.from(updated)));
    } catch {
      // ignore
    }
  };

  const handleToggleNotifications = () => {
    const willOpen = !isNotificationsOpen;
    setIsNotificationsOpen(willOpen);
    if (willOpen) {
      setIsProfileOpen(false);
      markOrdersAsViewed();
    }
  };

  const handleMarkAllRead = (e: React.MouseEvent) => {
    e.stopPropagation();
    markOrdersAsViewed();
  };

  const handleSelectOrderNotification = () => {
    setIsNotificationsOpen(false);
    setActiveTab?.("orders");
  };

  // Close notifications dropdown on outside click or Escape
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (notificationsRef.current && !notificationsRef.current.contains(e.target as Node)) {
        setIsNotificationsOpen(false);
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") setIsNotificationsOpen(false);
    };

    if (isNotificationsOpen) {
      document.addEventListener("mousedown", handleClickOutside);
      document.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [isNotificationsOpen]);

  // Close profile dropdown on outside click or Escape
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setIsProfileOpen(false);
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") setIsProfileOpen(false);
    };

    if (isProfileOpen) {
      document.addEventListener("mousedown", handleClickOutside);
      document.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [isProfileOpen]);

  const initials = adminUser?.name
    ? adminUser.name
        .split(" ")
        .map((p) => p[0])
        .join("")
        .toUpperCase()
        .slice(0, 2)
    : "FG";

  return (
    <header className="fixed top-0 right-0 left-0 md:left-64 lg:left-72 h-16 bg-[#141419]/95 backdrop-blur-md border-b border-[#24242C] px-4 sm:px-6 lg:px-8 flex items-center justify-between z-30">
      <div className="flex items-center gap-3">
        {/* Mobile Hamburger Toggle */}
        <button
          onClick={() => setIsMobileSidebarOpen(true)}
          aria-label="Toggle Navigation Drawer"
          className="md:hidden p-2 text-[#8C867D] hover:text-white rounded transition-colors"
        >
          <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="3" y1="12" x2="21" y2="12" />
            <line x1="3" y1="6" x2="21" y2="6" />
            <line x1="3" y1="18" x2="21" y2="18" />
          </svg>
        </button>

        {/* Mobile Brand Logo */}
        <div className="md:hidden flex items-center">
          <Image
            src={topbarLogo}
            alt="Faizan Gems"
            width={120}
            height={28}
            className="h-6 w-auto object-contain"
            unoptimized
          />
        </div>

        {/* Breadcrumb Navigation */}
        <div className="hidden sm:flex items-center gap-2 text-xs font-sans text-[#8C867D]">
          <span>Admin</span>
          <span className="text-[#44382B]">/</span>
          <span className="text-white font-medium capitalize">
            {TAB_LABELS[activeTab] || "Dashboard"}
          </span>
        </div>
      </div>

      {/* Right: Order Notifications & Authenticated Admin Profile */}
      <div className="flex items-center gap-3">
        {/* Customer Order Notifications */}
        <div className="relative" ref={notificationsRef}>
          <button
            type="button"
            onClick={handleToggleNotifications}
            aria-label="Customer Order Notifications"
            aria-expanded={isNotificationsOpen}
            title={hasUnviewedOrders ? `${unviewedCount} new customer order(s)` : "Order Notifications"}
            className={`relative p-2 rounded-sm border transition-all ${
              isNotificationsOpen
                ? "bg-[#1E1E28] border-[#C5A880] text-[#C5A880] shadow-lg shadow-[#C5A880]/10"
                : hasUnviewedOrders
                ? "bg-[#1A1A22] border-[#C5A880]/60 text-white hover:border-[#C5A880]"
                : "bg-[#16161D] hover:bg-[#1C1C24] border-[#2A2A36] hover:border-[#C5A880]/60 text-[#8C867D] hover:text-white"
            }`}
          >
            {/* Bell Icon */}
            <svg
              className="w-4 h-4"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.75"
            >
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
              <path d="M13.73 21a2 2 0 0 1-3.46 0" />
            </svg>

            {/* Glowing Notification Dot & Counter Badge (immediately hidden once viewed) */}
            {hasUnviewedOrders && (
              <span className="absolute -top-1 -right-1 flex h-4 min-w-4 px-1 items-center justify-center pointer-events-none">
                <span className="relative inline-flex items-center justify-center rounded-full h-4 min-w-4 px-1 bg-gradient-to-r from-[#C5A880] to-[#E0CFA9] text-[#0D0D11] text-[9px] font-mono font-bold shadow-sm">
                  {unviewedCount > 9 ? "9+" : unviewedCount}
                </span>
              </span>
            )}
          </button>

          {/* Notifications Dropdown Panel */}
          {isNotificationsOpen && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 max-w-[calc(100vw-2rem)] bg-[#16161D] border border-[#2E2E3C] shadow-2xl rounded-sm z-50 animate-luxury-popover overflow-hidden">
              {/* Header */}
              <div className="px-4 py-3 border-b border-[#24242C] bg-[#141419] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <svg className="w-3.5 h-3.5 text-[#C5A880]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                  </svg>
                  <span className="font-sans font-semibold text-sm text-white tracking-tight">Order Notifications</span>
                </div>
                {ordersList && ordersList.length > 0 && (
                  <button
                    type="button"
                    onClick={handleMarkAllRead}
                    className="text-[10px] font-mono uppercase tracking-wider text-[#8C867D] hover:text-[#C5A880] transition-colors"
                  >
                    Mark read
                  </button>
                )}
              </div>

              {/* Orders List */}
              {ordersList && ordersList.length > 0 ? (
                <div className="max-h-[360px] overflow-y-auto admin-scroll divide-y divide-[#202028]">
                  {ordersList.slice(0, 8).map((order) => {
                    const isNew = !viewedOrderIds.has(order.id) && !viewedOrderIds.has(order.orderNumber || order.id);
                    return (
                      <div
                        key={order.id}
                        onClick={handleSelectOrderNotification}
                        className={`p-3 sm:p-3.5 hover:bg-[#1C1C26] cursor-pointer transition-colors flex items-start justify-between gap-3 ${
                          isNew ? "bg-[#1C1A16]/50" : ""
                        }`}
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-white text-xs font-sans font-medium truncate">
                              {order.clientName || "Valued Client"}
                            </span>
                            <span className="text-[10px] font-mono text-[#8C867D] truncate">
                              #{order.orderNumber || order.id}
                            </span>
                          </div>

                          <p className="text-[11px] text-[#A69E92] truncate mb-1.5 font-sans">
                            {order.gemstoneName}
                            {order.carat ? ` (${order.carat.toFixed(2)}ct)` : ""}
                          </p>

                          <div className="flex items-center gap-2">
                            <span
                              className={`text-[9px] font-mono px-1.5 py-0.5 rounded border uppercase tracking-wider ${getOrderBadgeClass(
                                order.status
                              )}`}
                            >
                              {getOrderBadgeLabel(order.status)}
                            </span>
                            <span className="text-[10px] font-mono text-[#6E6B65]">
                              {formatRelativeTime(order.createdAt || order.date)}
                            </span>
                          </div>
                        </div>

                        <div className="text-right shrink-0 pt-0.5">
                          <LuxuryPrice amount={order.total} size="xs" color="gold" weight="semibold" />
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="py-10 px-4 text-center">
                  <div className="w-10 h-10 mx-auto mb-3 rounded-full bg-[#1C1C24] border border-[#2A2A36] flex items-center justify-center text-[#8C867D]">
                    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                      <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                      <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                    </svg>
                  </div>
                  <p className="font-sans font-medium text-sm text-white mb-1">No Orders Yet</p>
                  <p className="text-[11px] text-[#8C867D] font-sans max-w-[220px] mx-auto">
                    When customers place orders, live notifications will appear here.
                  </p>
                </div>
              )}

              {/* Footer */}
              <div className="p-2.5 bg-[#141419] border-t border-[#24242C] text-center">
                <button
                  type="button"
                  onClick={handleSelectOrderNotification}
                  className="w-full py-1.5 text-xs font-mono uppercase tracking-wider text-[#C5A880] hover:text-white transition-colors flex items-center justify-center gap-1.5"
                >
                  <span>View All Orders</span>
                  {ordersList && ordersList.length > 0 && (
                    <span className="text-[10px] text-[#8C867D]">({ordersList.length})</span>
                  )}
                  <span>→</span>
                </button>
              </div>
            </div>
          )}
        </div>

        <div className="relative" ref={profileRef}>
          <button
            onClick={() => setIsProfileOpen((prev) => !prev)}
            aria-expanded={isProfileOpen}
            aria-label="Admin Profile Menu"
            className={`flex items-center gap-2.5 p-1 sm:pl-1 sm:pr-3 sm:py-1 rounded-full sm:rounded-sm border transition-all ${
              isProfileOpen
                ? "bg-[#1E1E28] border-[#C5A880] text-white shadow-lg shadow-[#C5A880]/10"
                : "bg-[#16161D] hover:bg-[#1C1C24] border-[#2A2A36] hover:border-[#C5A880]/60 text-[#E7E2D7]"
            }`}
          >
            {/* Avatar with Status Pulse */}
            <div className="relative shrink-0">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#242430] to-[#16161D] border border-[#C5A880]/70 flex items-center justify-center text-[#C5A880] text-xs font-sans font-bold shadow-inner">
                {initials}
              </div>
              <span
                className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-[#141419]"
                title="Active Session Encrypted"
              />
            </div>

            {/* Admin Name & Role (Hidden on mobile) */}
            <div className="hidden sm:flex flex-col text-left">
              <span className="text-xs font-sans font-medium text-white max-w-[120px] truncate leading-tight">
                {adminUser?.name || "Admin"}
              </span>
              <span className="text-[9px] font-mono text-[#C5A880] uppercase tracking-wider leading-tight">
                Admin
              </span>
            </div>

            {/* Dropdown Chevron */}
            <svg
              className={`w-3.5 h-3.5 text-[#8C867D] transition-transform duration-200 ml-0.5 ${
                isProfileOpen ? "rotate-180 text-[#C5A880]" : ""
              }`}
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <polyline points="6 9 12 15 18 9" />
            </svg>
          </button>

          {/* Luxury Profile Popover Menu */}
          {isProfileOpen && (
            <div className="absolute right-0 mt-2 w-72 max-w-[calc(100vw-2rem)] bg-[#16161D] border border-[#2A2A38] shadow-2xl rounded-sm p-4 z-50 animate-luxury-popover">
              {/* Profile Card Header */}
              <div
                onClick={() => {
                  setIsProfileOpen(false);
                  setIsProfileModalOpen(true);
                }}
                className="flex items-center gap-3 pb-3 border-b border-[#24242C] cursor-pointer group hover:bg-[#1C1C24] p-1.5 -mx-1.5 rounded-sm transition-colors"
                title="Click to view & edit admin profile"
              >
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#242430] to-[#181822] border border-[#C5A880] flex items-center justify-center text-[#C5A880] text-sm font-sans font-bold shrink-0">
                  {initials}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-1">
                    <p className="text-xs font-sans font-semibold text-white truncate">
                      {adminUser?.name || "Admin"}
                    </p>
                    <span className="text-[9px] text-[#C5A880] font-mono group-hover:underline">
                      Edit
                    </span>
                  </div>
                  <p className="text-[10px] font-mono text-[#8C867D] truncate mt-0.5">
                    {adminUser?.email || SITE_CONFIG.contact.adminEmail}
                  </p>
                  <div className="mt-1 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" />
                    <span className="text-[9px] font-mono uppercase tracking-widest text-[#C5A880]">
                      Admin
                    </span>
                  </div>
                </div>
              </div>

              {/* Quick Navigation Links */}
              <div className="py-2.5 space-y-1">
                {/* Admin Profile & Settings Option */}
                <button
                  type="button"
                  onClick={() => {
                    setIsProfileOpen(false);
                    setIsProfileModalOpen(true);
                  }}
                  className="w-full flex items-center justify-between px-2.5 py-2 text-xs font-sans text-[#E7E2D7] hover:text-white hover:bg-[#20202A] rounded-sm transition-colors group"
                >
                  <span className="flex items-center gap-2.5">
                    <div className="w-5 h-5 rounded bg-[#C5A880]/15 flex items-center justify-center text-[#C5A880]">
                      <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                        <circle cx="12" cy="7" r="4" />
                      </svg>
                    </div>
                    <span className="font-medium text-white group-hover:text-[#C5A880] transition-colors">
                      Admin Profile & Credentials
                    </span>
                  </span>
                  <span className="text-[10px] text-[#64615B] group-hover:text-white">&rarr;</span>
                </button>

                <Link
                  href="/shop"
                  target="_blank"
                  className="flex items-center justify-between px-2.5 py-2 text-xs font-sans text-[#A29F96] hover:text-white hover:bg-[#20202A] rounded-sm transition-colors group"
                >
                  <span className="flex items-center gap-2">
                    <span className="text-[#C5A880]">✦</span>
                    <span>View Online Store</span>
                  </span>
                  <span className="text-[10px] text-[#64615B] group-hover:text-white">&rarr;</span>
                </Link>

                <Link
                  href="/account"
                  className="flex items-center justify-between px-2.5 py-2 text-xs font-sans text-[#A29F96] hover:text-white hover:bg-[#20202A] rounded-sm transition-colors group"
                >
                  <span className="flex items-center gap-2">
                    <span className="text-[#C5A880]">🏛</span>
                    <span>Customer Account View</span>
                  </span>
                  <span className="text-[10px] text-[#64615B] group-hover:text-white">&rarr;</span>
                </Link>
              </div>

              {/* Secure Logout Action */}
              <div className="pt-2.5 border-t border-[#24242C]">
                <button
                  onClick={() => {
                    setIsProfileOpen(false);
                    if (handleLogout) handleLogout();
                  }}
                  className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-red-950/20 hover:bg-red-950/40 border border-red-900/40 hover:border-red-700/60 text-red-300 text-xs font-sans uppercase tracking-wider rounded-sm transition-all"
                >
                  <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                    <polyline points="16 17 21 12 16 7" />
                    <line x1="21" y1="12" x2="9" y2="12" />
                  </svg>
                  <span>Sign Out</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Admin Profile Modal */}
      <AdminProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        adminUser={adminUser || null}
        onUpdateAdminUser={(updated) => {
          if (onUpdateAdminUser) {
            onUpdateAdminUser(updated);
          }
        }}
      />
    </header>
  );
}
