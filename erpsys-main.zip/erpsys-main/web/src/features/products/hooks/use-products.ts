import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { productService } from "@/services/product-service";
import { categoryService } from "@/services/category-service";
import { brandService } from "@/services/brand-service";
import { unitService } from "@/services/unit-service";
import { warrantyService } from "@/services/warranty-service";
import { variationService } from "@/services/variation-service";
import { sellingPriceGroupService } from "@/services/selling-price-group-service";
import { branchService } from "@/services/branch-service";
import { queryKeys } from "@/lib/query-keys";
import { ProductItem } from "../types";

export type ProductQueryOptions = {
  branchId?: string;
  categoryId?: string;
  brandId?: string;
  page?: number;
  limit?: number;
  search?: string;
  all?: boolean;
  isActive?: boolean;
  notForSelling?: boolean;
};

export function useProductsQuery(businessId: string, branchId?: string) {
  return useQuery<ProductItem[]>({
    queryKey: queryKeys.products.list(businessId, { branchId, all: true }),
    queryFn: () => productService.getAllProducts(businessId, branchId),
    enabled: !!businessId,
  });
}

export function useProductsPaginatedQuery(
  businessId: string,
  options: ProductQueryOptions = {}
) {
  return useQuery<{
    data: ProductItem[];
    meta: { totalItems: number; totalPages: number; currentPage: number; limit: number };
  }>({
    queryKey: queryKeys.products.list(businessId, options),
    queryFn: () => productService.getProducts(businessId, options),
    enabled: !!businessId,
  });
}

export function useCategoriesQuery(businessId: string) {
  return useQuery({
    queryKey: ["categories", businessId, { limit: 1000 }],
    queryFn: () => categoryService.getCategories(businessId, { limit: 1000 }).then(res => res.data),
    enabled: !!businessId,
  });
}

export function useBrandsQuery(businessId: string) {
  return useQuery({
    queryKey: queryKeys.brands.list(businessId, undefined, undefined, 1000),
    queryFn: () => brandService.getBrands(businessId, { limit: 1000 }),
    enabled: !!businessId,
  });
}

export function useUnitsQuery(businessId: string) {
  return useQuery({
    queryKey: ["units", businessId],
    queryFn: () => unitService.getUnits(businessId),
    enabled: !!businessId,
  });
}

export function useWarrantiesQuery(businessId: string) {
  return useQuery({
    queryKey: queryKeys.warranties.list(businessId),
    queryFn: () => warrantyService.getWarranties(businessId),
    enabled: !!businessId,
  });
}

export function useVariationsQuery(businessId: string) {
  return useQuery({
    queryKey: queryKeys.variations.list(businessId),
    queryFn: () => variationService.getVariations(businessId),
    enabled: !!businessId,
  });
}

export function useSpgQuery(businessId: string) {
  return useQuery({
    queryKey: ["sellingPriceGroups", businessId],
    queryFn: () => sellingPriceGroupService.getSellingPriceGroups(businessId),
    enabled: !!businessId,
  });
}

export function useBranchesQuery(businessId: string, userId?: string) {
  return useQuery({
    queryKey: queryKeys.branches.list(businessId, userId),
    queryFn: () => branchService.getBranches(businessId, userId),
    enabled: !!businessId,
  });
}

export function useCreateProductMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (productData: Parameters<typeof productService.createProduct>[0]) =>
      productService.createProduct(productData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
    },
  });
}

export function useUpdateProductMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, productData }: { id: string; productData: Parameters<typeof productService.updateProduct>[1] }) =>
      productService.updateProduct(id, productData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
    },
  });
}

export function useDeleteProductMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, businessId }: { id: string; businessId: string }) =>
      productService.deleteProduct(id, businessId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
    },
  });
}

export function useProductByIdQuery(id: string, businessId: string) {
  return useQuery<ProductItem>({
    queryKey: [...queryKeys.products.all, "detail", id, businessId],
    queryFn: () => productService.getProductById(id, businessId),
    enabled: !!id && !!businessId,
  });
}
