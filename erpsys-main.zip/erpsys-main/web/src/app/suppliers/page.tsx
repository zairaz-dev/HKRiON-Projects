"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import {
  Users,
  Plus,
  Edit2,
  Trash2,
  Loader2,
  CheckCircle,
  AlertCircle,
  Building2,
  Globe,
  Coins,
  History,
  Eye
} from "lucide-react";
import { SupplierPaymentDialog, SupplierPaymentsListDialog } from "@/features/supplier-payments";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { DataTable, ColumnDef, ActionsDropdown } from "@/components/ui/table";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";

import { Select } from "@/components/ui/select";
import { useCurrency } from "@/hooks/use-currency";
import { getFullAssetUrl } from "@/lib/utils";

import {
  SupplierItem,
  SupplierDialog,
  SupplierDeleteDialog,
  useSuppliersQuery,
  useBranchesQuery
} from "@/features/suppliers";

function SuppliersPageContent() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Notifications
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Dialog States
  const [isDialogOpen, setIsDialogOpen] = useState<boolean>(false);
  const [editingSupplier, setEditingSupplier] = useState<SupplierItem | null>(null);
  const [supplierToDelete, setSupplierToDelete] = useState<SupplierItem | null>(null);
  const [selectedSupplierForPayment, setSelectedSupplierForPayment] = useState<SupplierItem | null>(null);
  const [selectedSupplierForHistory, setSelectedSupplierForHistory] = useState<SupplierItem | null>(null);

  // URL-driven Branch Filter
  const selectedBranchFilter = searchParams.get("branchId") || "all";

  const setSelectedBranchFilter = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value === "all") {
      params.delete("branchId");
    } else {
      params.set("branchId", value);
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  // Authenticate
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  // Fetch Data via React Query
  const businessId = currentUser?.businessId || "";
  const { format } = useCurrency(businessId);
  const { data: suppliers = [], isLoading: suppliersLoading, error: suppliersError } = useSuppliersQuery(businessId);
  const { data: branchesList = [], isLoading: branchesLoading } = useBranchesQuery(businessId, currentUser?.id);

  // Handle Query Errors
  useEffect(() => {
    if (suppliersError) {
      setError(suppliersError.message || "Failed to load suppliers.");
    }
  }, [suppliersError]);

  // Auto-dismiss notifications
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  const handleOpenCreateModal = () => {
    setEditingSupplier(null);
    setIsDialogOpen(true);
  };

  const handleOpenEditModal = (supplier: SupplierItem) => {
    setEditingSupplier(supplier);
    setIsDialogOpen(true);
  };

  // Filter Logic
  const getFilteredSuppliers = () => {
    let list = suppliers;

    if (selectedBranchFilter !== "all") {
      if (selectedBranchFilter === "global") {
        list = list.filter((s) => !s.branches || s.branches.length === 0);
      } else {
        list = list.filter((s) =>
          s.branches?.some((sb) => sb.branch.id === selectedBranchFilter)
        );
      }
    }

    return list;
  };

  const filteredList = getFilteredSuppliers();

  // Columns Definition
  const columns: ColumnDef<SupplierItem>[] = [
    {
      header: "Supplier Name",
      searchable: true,
      render: (supplier) => (
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full border border-border/80 bg-secondary/40 overflow-hidden flex items-center justify-center shrink-0 shadow-sm">
            {supplier.image ? (
              <img
                src={getFullAssetUrl(supplier.image) || supplier.image}
                alt={supplier.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="text-xs font-bold font-mono text-primary uppercase">
                {supplier.name.substring(0, 2)}
              </div>
            )}
          </div>
          <div className="flex flex-col">
            <span className="font-semibold text-foreground leading-tight">{supplier.name}</span>
            {supplier.email && (
              <span className="text-[11px] text-muted-foreground font-mono">{supplier.email}</span>
            )}
          </div>
        </div>
      ),
    },
    {
      header: "Business Name",
      render: (supplier) => (
        <span className="text-xs font-medium text-foreground/80">
          {supplier.businessName || <span className="text-muted-foreground italic">None</span>}
        </span>
      ),
    },
    {
      header: "Phone Number",
      render: (supplier) => (
        <span className="text-xs font-mono">
          {supplier.phone || <span className="text-muted-foreground italic">None</span>}
        </span>
      ),
    },
    {
      header: "Tax Number",
      render: (supplier) => (
        <span className="text-xs font-mono">
          {supplier.taxNumber || <span className="text-muted-foreground italic">None</span>}
        </span>
      ),
    },
    {
      header: "Branch Scope",
      render: (supplier) => {
        if (!supplier.branches || supplier.branches.length === 0) {
          return (
            <span className="inline-flex items-center gap-1 text-xs text-muted-foreground font-medium">
              <Globe className="h-3.5 w-3.5 text-muted-foreground/60" />
              Global
            </span>
          );
        }
        if (supplier.branches.length === 1) {
          return (
            <span className="inline-flex items-center gap-1 text-xs text-foreground/80 font-medium">
              <Building2 className="h-3.5 w-3.5 text-muted-foreground/60" />
              {supplier.branches[0].branch.name}
            </span>
          );
        }
        return (
          <span className="inline-flex items-center gap-1 text-xs text-primary font-medium">
            <Building2 className="h-3.5 w-3.5 text-primary/60" />
            {supplier.branches.length} Branches
          </span>
        );
      },
    },
    {
      header: "Outstanding Due",
      render: (supplier) => {
        const due = supplier.outstandingDue || 0;
        return (
          <span className={`font-mono text-xs font-bold ${due > 0.01 ? "text-rose-500 font-extrabold" : "text-muted-foreground"}`}>
            {format(due)}
          </span>
        );
      },
    },
    {
      header: "Status",
      render: (supplier) => (
        <span
          className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${
            supplier.isActive
              ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
              : "bg-destructive/10 text-destructive border-destructive/20"
          }`}
        >
          {supplier.isActive ? "Active" : "Inactive"}
        </span>
      ),
    },
    {
      header: "Actions",
      render: (supplier) => (
        <ActionsDropdown
          actions={[
            {
              label: "View Ledger",
              onClick: () => router.push(`/suppliers/view?id=${supplier.id}`),
              icon: <Eye className="h-3.5 w-3.5" />,
            },
            {
              label: "Edit",
              onClick: () => handleOpenEditModal(supplier),
              icon: <Edit2 className="h-3.5 w-3.5" />,
            },
            {
              label: "Pay Supplier",
              onClick: () => setSelectedSupplierForPayment(supplier),
              icon: <Coins className="h-3.5 w-3.5" />,
            },
            {
              label: "Payment History",
              onClick: () => setSelectedSupplierForHistory(supplier),
              icon: <History className="h-3.5 w-3.5" />,
            },
            {
              label: "Delete",
              onClick: () => setSupplierToDelete(supplier),
              icon: <Trash2 className="h-3.5 w-3.5" />,
              variant: "destructive",
            },
          ]}
        />
      ),
    },
  ];

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3 p-6 max-w-sm border border-border/40 rounded-xl bg-card/60 backdrop-blur-sm">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <h2 className="text-lg font-bold">Unauthorized Access</h2>
          <p className="text-sm text-muted-foreground">
            You need to be logged in to view this page. Redirecting to login...
          </p>
          <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
        </div>
      </div>
    );
  }

  const isLoading = suppliersLoading || branchesLoading;

  const customFilters = (
    <div className="space-y-1.5 min-w-[200px]">
      <label className="text-[10px] font-bold text-muted-foreground uppercase">
        Branch Filter
      </label>
      <Select
        value={selectedBranchFilter}
        onValueChange={setSelectedBranchFilter}
        className="h-9 text-xs"
      >
        <option value="all">All Branches</option>
        <option value="global">Global (No Branch)</option>
        {branchesList.map((b) => (
          <option key={b.id} value={b.id}>
            {b.name}
          </option>
        ))}
      </Select>
    </div>
  );

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/suppliers" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Suppliers" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <Users className="h-7 w-7 text-primary" /> Suppliers
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Manage your supplier database, billing details, tax numbers, and branch mappings.
              </p>
            </div>
          </div>

          {/* Banner Notifications */}
          {successMessage && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 animate-in fade-in slide-in-from-top-4 duration-300">
              <CheckCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive animate-in fade-in slide-in-from-top-4 duration-300">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          {/* Main Table Card */}
          {isLoading ? (
            <div className="flex h-64 items-center justify-center">
              <div className="text-center space-y-2">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
                <span className="text-sm text-muted-foreground block">Loading suppliers...</span>
              </div>
            </div>
          ) : (
            <DataTable
              data={filteredList}
              columns={columns}
              searchKeys={["name", "businessName"]}
              actionButton={{
                label: "Add Supplier",
                onClick: handleOpenCreateModal,
                icon: <Plus className="h-4 w-4" />
              }}
              customFilters={customFilters}
              reportTitle="Suppliers Report"
            />
          )}
        </main>
      </div>

      {/* Create / Edit Modal Dialog */}
      {currentUser && (
        <SupplierDialog
          isOpen={isDialogOpen}
          onClose={() => {
            setIsDialogOpen(false);
            setEditingSupplier(null);
          }}
          supplier={editingSupplier}
          branches={branchesList}
          currentUser={currentUser}
          onSuccess={setSuccessMessage}
          onError={setError}
        />
      )}

      {/* Delete Confirmation Dialog */}
      {currentUser && supplierToDelete && (
        <SupplierDeleteDialog
          isOpen={!!supplierToDelete}
          onClose={() => setSupplierToDelete(null)}
          supplier={supplierToDelete}
          currentUser={currentUser}
          onSuccess={setSuccessMessage}
          onError={setError}
        />
      )}

      {/* Direct Payment Dialog */}
      {currentUser && (
        <SupplierPaymentDialog
          isOpen={!!selectedSupplierForPayment}
          onClose={() => setSelectedSupplierForPayment(null)}
          purchase={null}
          supplier={selectedSupplierForPayment}
          currentUser={currentUser}
          onSuccess={setSuccessMessage}
          onError={setError}
        />
      )}

      {/* Direct Payments List Dialog */}
      {currentUser && (
        <SupplierPaymentsListDialog
          isOpen={!!selectedSupplierForHistory}
          onClose={() => setSelectedSupplierForHistory(null)}
          purchase={null}
          supplier={selectedSupplierForHistory}
          currentUser={currentUser}
          onSuccess={setSuccessMessage}
          onError={setError}
        />
      )}
    </div>
  );
}

export default function SuppliersPage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen w-screen items-center justify-center bg-[#121216]">
        <div className="flex flex-col items-center gap-2">
          <div className="w-8 h-8 border-4 border-zinc-700 border-t-emerald-500 rounded-full animate-spin" />
          <p className="text-sm text-zinc-400">Loading...</p>
        </div>
      </div>
    }>
      <SuppliersPageContent />
    </Suspense>
  );
}
