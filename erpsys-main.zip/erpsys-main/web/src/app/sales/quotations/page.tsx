"use client";

import React, { useEffect, useState, useMemo, Suspense } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import Link from "next/link";
import {
  FileText,
  Loader2,
  AlertCircle,
  Building2,
  Calendar,
  User as UserIcon,
  Plus,
  Printer,
  ShoppingCart,
  Trash2,
  Edit,
  Eye,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Ban,
  Filter,
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { DataTable, ColumnDef } from "@/components/ui/table";
import { ActionsDropdown } from "@/components/ui/actions-dropdown";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";
import {
  QuotationItem,
  useQuotationsQuery,
  useDeleteQuotationMutation,
  useConvertToSaleMutation,
  QuotationPreviewDialog,
} from "@/features/quotations";
import { useCustomersQuery, useBranchesQuery } from "@/features/customers/hooks/use-customers";
import { useCurrency } from "@/hooks/use-currency";
import { usePermissions } from "@/hooks/use-permissions";

function QuotationsPageContent() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const { hasPermission } = usePermissions();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  // Preview Dialog State
  const [previewQuotation, setPreviewQuotation] = useState<QuotationItem | null>(null);

  // URL Search Params for Filters
  const selectedBranchFilter = searchParams.get("branchId") || "all";
  const selectedCustomerFilter = searchParams.get("customerId") || "all";
  const selectedStatusFilter = searchParams.get("status") || "all";
  const currentPage = Number(searchParams.get("page")) || 1;
  const searchQuery = searchParams.get("search") || "";
  const limit = Number(searchParams.get("limit")) || 10;

  const updateFilters = (key: string, value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1");
    if (value === "all" || !value) {
      params.delete(key);
    } else {
      params.set(key, value);
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  useEffect(() => {
    async function checkAuth() {
      try {
        const user = await authService.getCurrentUser();
        if (user) {
          setCurrentUser(user);
          setIsAuthenticated(true);
        } else {
          setIsAuthenticated(false);
          router.push("/auth/login");
        }
      } catch {
        setIsAuthenticated(false);
        router.push("/auth/login");
      }
    }
    checkAuth();
  }, [router]);

  const businessId = currentUser?.businessId || "";
  const { symbol, format } = useCurrency(businessId);

  const { data: branches = [] } = useBranchesQuery(businessId, currentUser?.id);
  const { data: customers = [] } = useCustomersQuery(businessId);

  const isSuperOrAdmin = currentUser?.role === "admin" || currentUser?.role === "super-admin";
  const effectiveBranchFilter = useMemo(() => {
    if (selectedBranchFilter && selectedBranchFilter !== "all") {
      return selectedBranchFilter;
    }
    if (!isSuperOrAdmin && branches.length > 0) {
      return branches[0].id;
    }
    return selectedBranchFilter;
  }, [selectedBranchFilter, isSuperOrAdmin, branches]);

  // Queries
  const { data: quotationsData, isLoading: isLoadingQuotations } = useQuotationsQuery({
    branchId: effectiveBranchFilter !== "all" ? effectiveBranchFilter : undefined,
    customerId: selectedCustomerFilter,
    status: selectedStatusFilter,
    search: searchQuery,
    page: currentPage,
    limit,
  });

  // Mutations
  const deleteMutation = useDeleteQuotationMutation();
  const convertMutation = useConvertToSaleMutation();

  const handleDelete = async (id: string, quotationNumber: string) => {
    if (confirm(`Are you sure you want to delete quotation ${quotationNumber}?`)) {
      try {
        await deleteMutation.mutateAsync(id);
        setSuccessMsg(`Quotation ${quotationNumber} deleted successfully.`);
        setTimeout(() => setSuccessMsg(""), 4000);
      } catch (err: any) {
        setErrorMsg(err.message || "Failed to delete quotation.");
        setTimeout(() => setErrorMsg(""), 4000);
      }
    }
  };

  const handleConvertToSale = async (quotation: QuotationItem) => {
    if (confirm(`Convert quotation ${quotation.quotationNumber} directly into a Final Sale Invoice?`)) {
      try {
        const result = await convertMutation.mutateAsync({ id: quotation.id });
        setSuccessMsg(result.message);
        setPreviewQuotation(null);
        setTimeout(() => setSuccessMsg(""), 5000);
      } catch (err: any) {
        setErrorMsg(err.message || "Failed to convert quotation to sale.");
        setTimeout(() => setErrorMsg(""), 5000);
      }
    }
  };

  const handleLoadInPos = (quotationId: string) => {
    router.push(`/pos?quotationId=${quotationId}`);
  };

  const setSelectedBranchFilter = (value: string) => {
    updateFilters("branchId", value);
  };

  const setSelectedCustomerFilter = (value: string) => {
    updateFilters("customerId", value);
  };

  const setSelectedStatusFilter = (value: string) => {
    updateFilters("status", value);
  };

  const handlePageChange = (newPage: number) => {
    updateFilters("page", String(newPage));
  };

  const handleSearchChange = (newSearch: string) => {
    updateFilters("search", newSearch);
  };

  const handleLimitChange = (newLimit: number) => {
    updateFilters("limit", String(newLimit));
  };

  const columns: ColumnDef<QuotationItem>[] = [
    {
      header: "Quotation No",
      searchable: true,
      render: (q) => (
        <button
          type="button"
          onClick={() => setPreviewQuotation(q)}
          className="font-mono font-bold text-foreground hover:text-primary hover:underline text-xs text-left"
        >
          {q.quotationNumber}
        </button>
      ),
    },
    {
      header: "Date",
      render: (q) => {
        const dateObj = new Date(q.date);
        return (
          <div className="flex flex-col gap-0.5 text-xs font-medium text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <Calendar className="h-3.5 w-3.5" />
              {dateObj.toLocaleDateString()}
            </span>
            {q.expiryDate ? (
              <span className="text-[10px] text-amber-500/90 pl-5 font-mono">
                Valid till: {new Date(q.expiryDate).toLocaleDateString()}
              </span>
            ) : (
              <span className="text-[10px] text-muted-foreground/75 pl-5">
                No expiry
              </span>
            )}
          </div>
        );
      },
    },
    {
      header: "Customer",
      render: (q) => (
        <span className="text-xs font-semibold text-foreground">
          {q.customer?.name || "Walk-in Customer"}
        </span>
      ),
    },
    {
      header: "Branch",
      render: (q) => (
        <div className="flex flex-col gap-0.5">
          <span className="text-xs font-semibold text-foreground flex items-center gap-1.5">
            <Building2 className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
            {q.branch?.name || "N/A"}
          </span>
          {q.createdBy?.name && (
            <span className="text-[10px] text-muted-foreground flex items-center gap-1 pl-5">
              <span className="text-muted-foreground/70 font-medium">By:</span>
              <span className="font-semibold text-foreground/90">{q.createdBy.name}</span>
            </span>
          )}
        </div>
      ),
    },
    {
      header: "Total Items",
      render: (q) => (
        <span className="text-xs font-semibold text-muted-foreground">
          {q.quotationLines?.reduce((sum: number, l: any) => sum + l.quantity, 0) || 0} items
        </span>
      ),
    },
    {
      header: "Grand Total",
      render: (q) => (
        <span className="font-extrabold text-foreground text-xs">
          {format(q.grandTotal)}
        </span>
      ),
    },
    {
      header: "Status",
      render: (q) => {
        const status = q.status || "PENDING";
        let badgeClass = "bg-amber-500/10 border-amber-500/25 text-amber-600 dark:text-amber-400";
        if (status === "CONVERTED") {
          badgeClass = "bg-emerald-500/10 border-emerald-500/25 text-emerald-600 dark:text-emerald-400";
        } else if (status === "EXPIRED" || status === "CANCELLED") {
          badgeClass = "bg-rose-500/10 border-rose-500/25 text-rose-600 dark:text-rose-400";
        }
        return (
          <span className={`inline-flex items-center px-2 py-0.5 rounded border text-[10px] font-extrabold tracking-wide uppercase ${badgeClass}`}>
            {status}
          </span>
        );
      },
    },
    {
      header: "Actions",
      render: (q) => {
        const isPending = q.status === "PENDING";
        const actionItems: any[] = [
          {
            label: "View & Print",
            onClick: () => setPreviewQuotation(q),
            icon: <Printer className="h-3.5 w-3.5" />,
          },
        ];

        if (isPending && hasPermission("pos:create_transaction")) {
          actionItems.push({
            label: "Resume in POS",
            onClick: () => handleLoadInPos(q.id),
            icon: <ShoppingCart className="h-3.5 w-3.5 text-primary" />,
          });
        }

        if (hasPermission("quotations:delete")) {
          actionItems.push({
            label: "Delete",
            onClick: () => handleDelete(q.id, q.quotationNumber),
            icon: <Trash2 className="h-3.5 w-3.5 text-rose-500" />,
          });
        }

        return <ActionsDropdown actions={actionItems} />;
      },
    },
  ];

  // Custom filters popover content
  const customFilters = (
    <div className="space-y-3.5 min-w-[220px]">
      {/* Branch Filter */}
      <div className="space-y-1.5">
        <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
          <Building2 className="h-3 w-3" /> Branch Filter
        </label>
        <Select
          value={effectiveBranchFilter}
          onValueChange={setSelectedBranchFilter}
          className="h-9 text-xs"
        >
          {isSuperOrAdmin && <option value="all">All Branches</option>}
          {branches.map((b: any) => (
            <option key={b.id} value={b.id}>{b.name}</option>
          ))}
        </Select>
      </div>

      {/* Customer Filter */}
      <div className="space-y-1.5">
        <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
          <UserIcon className="h-3 w-3" /> Customer Filter
        </label>
        <Select
          value={selectedCustomerFilter}
          onValueChange={setSelectedCustomerFilter}
          className="h-9 text-xs"
        >
          <option value="all">All Customers</option>
          {customers.map((c: any) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </Select>
      </div>

      {/* Status Filter */}
      <div className="space-y-1.5">
        <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
          <Clock className="h-3 w-3" /> Status Filter
        </label>
        <Select
          value={selectedStatusFilter}
          onValueChange={setSelectedStatusFilter}
          className="h-9 text-xs"
        >
          <option value="all">All Statuses</option>
          <option value="PENDING">Pending</option>
          <option value="CONVERTED">Converted</option>
          <option value="EXPIRED">Expired</option>
          <option value="CANCELLED">Cancelled</option>
        </Select>
      </div>
    </div>
  );

  if (isAuthenticated === null) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/sales/quotations" />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Navbar title="Quotations" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <FileText className="h-7 w-7 text-primary" /> Quotations
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Manage, send, and track official customer price quotations without affecting inventory.
              </p>
            </div>
          </div>

          {/* Feedback Alerts */}
          {successMsg && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 animate-in fade-in slide-in-from-top-4 duration-300">
              <CheckCircle2 className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMsg}</span>
            </div>
          )}
          {errorMsg && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive animate-in fade-in slide-in-from-top-4 duration-300">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{errorMsg}</span>
            </div>
          )}

          {/* Main Table Card */}
          {isLoadingQuotations ? (
            <div className="flex h-64 items-center justify-center">
              <div className="text-center space-y-2">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
                <span className="text-sm text-muted-foreground block">Loading quotations...</span>
              </div>
            </div>
          ) : (
            <DataTable
              data={quotationsData?.data || []}
              columns={columns}
              searchPlaceholder="Search Quotation No..."
              serverSide={true}
              totalItems={quotationsData?.meta?.total || 0}
              totalPages={quotationsData?.meta?.totalPages || 1}
              currentPage={currentPage}
              onPageChange={handlePageChange}
              searchQuery={searchQuery}
              onSearchQueryChange={handleSearchChange}
              onPageSizeChange={handleLimitChange}
              actionButton={{
                label: "Create in POS",
                onClick: () => router.push("/pos"),
                icon: <Plus className="h-4 w-4" />,
              }}
              customFilters={customFilters}
              reportTitle="Quotations Report"
            />
          )}

          {/* Quotation Preview Modal */}
          <QuotationPreviewDialog
            isOpen={!!previewQuotation}
            onClose={() => setPreviewQuotation(null)}
            quotation={previewQuotation}
            onConvert={handleConvertToSale}
            canConvert={hasPermission("pos:create_transaction")}
          />
        </main>
      </div>
    </div>
  );
}

export default function QuotationsPage() {
  return (
    <Suspense
      fallback={
        <div className="flex h-screen items-center justify-center bg-background">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      }
    >
      <QuotationsPageContent />
    </Suspense>
  );
}
