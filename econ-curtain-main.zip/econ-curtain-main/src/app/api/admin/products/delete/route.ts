import { NextResponse } from "next/server";
import { ProductService } from "@/services/product.service";
import { SessionManager } from "@/core/auth/session";
import { revalidatePath } from "next/cache";

export async function DELETE(request: Request) {
  try {
    const session = await SessionManager.getCurrentSession();
    if (!session) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ success: false, error: "Missing product ID" }, { status: 400 });
    }

    await ProductService.delete(id);

    // Revalidate paths
    revalidatePath("/products");
    revalidatePath("/admin");
    revalidatePath("/admin/products");
    revalidatePath("/");

    return NextResponse.json({ success: true, message: "Product deleted successfully" });
  } catch (error) {
    console.error("Failed to delete product:", error);
    return NextResponse.json({ success: false, error: "Failed to delete product" }, { status: 500 });
  }
}
