/**
 * Utility functions for generating rich WhatsApp product inquiry links
 */

export interface ProductInquiryData {
  name: string;
  category: string;
  description?: string;
  imageUrl?: string;
  features?: string[];
}

export function generateProductWhatsAppLink(product: ProductInquiryData, whatsappNumber: string): string {
  // Clean phone number (remove +, spaces, etc)
  const cleanNumber = whatsappNumber.replace(/[^0-9]/g, '');
  // Use environment variable for the base URL, falling back to the production domain.
  // This avoids Next.js hydration mismatches while allowing different domains per environment.
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://shadeitblinds.com';

  const lines: string[] = [
    `✨ *SHADEIT BLINDS — Product Inquiry* ✨`,
    ``,
    `🏷️ *Product:* ${product.name}`,
    `📂 *Category:* ${product.category}`,
  ];

  if (product.description) {
    lines.push(`📝 *Details:* ${product.description}`);
  }

  if (product.features && product.features.length > 0) {
    lines.push(``);
    lines.push(`🌟 *Key Features:*`);
    product.features.forEach((feat) => {
      lines.push(`• ${feat}`);
    });
  }

  if (product.imageUrl) {
    const fullImgUrl = product.imageUrl.startsWith("http")
      ? product.imageUrl
      : `${baseUrl}${product.imageUrl}`;
    lines.push(``);
    lines.push(`🖼️ *Image Preview:* ${fullImgUrl}`);
  }

  const catalogUrl = `${baseUrl}/products?cat=${encodeURIComponent(product.category)}`;
  lines.push(`🔗 *Website Link:* ${catalogUrl}`);
  lines.push(``);
  lines.push(`💬 *Customer Message:* Hello SHADEIT BLINDS, I would like to get a quote and check availability/custom measurements for this product.`);

  const text = lines.join("\n");
  return `https://wa.me/${cleanNumber}?text=${encodeURIComponent(text)}`;
}
