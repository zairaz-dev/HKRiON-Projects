import { NextResponse } from "next/server";
import { SessionManager } from "@/core/auth/session";
import { UploadService } from "@/services/upload.service";

export async function POST(request: Request) {
  try {
    const session = await SessionManager.getCurrentSession();
    if (!session) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const data = await request.formData();
    const files = data.getAll("files");

    if (!files || files.length === 0) {
      return NextResponse.json({ success: false, error: "No files provided" }, { status: 400 });
    }

    const uploadedUrls: string[] = [];

    for (const file of files) {
      if (file instanceof File) {
        const url = await UploadService.processAndSave(file);
        uploadedUrls.push(url);
      }
    }

    return NextResponse.json({ success: true, urls: uploadedUrls });
  } catch (error: unknown) {
    console.error("Upload error:", error);
    const message = error instanceof Error ? error.message : "Upload failed";
    return NextResponse.json(
      { success: false, error: message },
      { status: 400 }
    );
  }
}
