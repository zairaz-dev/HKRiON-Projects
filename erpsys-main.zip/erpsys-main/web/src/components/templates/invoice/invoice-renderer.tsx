import React from "react";
import { InvoiceTemplateProps } from "./types";
import { Thermal80mmTemplate, generateThermal80mmHtml } from "./thermal-80mm-template";
import { Thermal58mmTemplate, generateThermal58mmHtml } from "./thermal-58mm-template";
import { A4StandardTemplate, generateA4StandardHtml } from "./a4-standard-template";
import { A5CompactTemplate, generateA5CompactHtml } from "./a5-compact-template";

export function getInvoiceTemplateHtml(props: InvoiceTemplateProps): string {
  const paperSize = props.layout?.paperSize || "THERMAL_80MM";

  switch (paperSize) {
    case "A4":
      return generateA4StandardHtml(props);
    case "A5":
      return generateA5CompactHtml(props);
    case "THERMAL_58MM":
      return generateThermal58mmHtml(props);
    case "THERMAL_80MM":
    default:
      return generateThermal80mmHtml(props);
  }
}

export function printInvoice(props: InvoiceTemplateProps) {
  const html = getInvoiceTemplateHtml(props);
  const printWindow = window.open("", "_blank");
  if (!printWindow) return;
  printWindow.document.write(html);
  printWindow.document.close();
}

export function InvoiceRenderer(props: InvoiceTemplateProps) {
  const paperSize = props.layout?.paperSize || "THERMAL_80MM";

  switch (paperSize) {
    case "A4":
      return <A4StandardTemplate {...props} />;
    case "A5":
      return <A5CompactTemplate {...props} />;
    case "THERMAL_58MM":
      return <Thermal58mmTemplate {...props} />;
    case "THERMAL_80MM":
    default:
      return <Thermal80mmTemplate {...props} />;
  }
}
