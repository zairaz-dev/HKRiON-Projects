import { Controller, Get, Put, Post, Body, Query, UseGuards, Req } from '@nestjs/common';
import { SmsSettingsService } from './sms-settings.service';
import { UpdateSmsSettingsDto, TestSmsDto } from './dto/sms-settings.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('sms-settings')
export class SmsSettingsController {
  constructor(private readonly smsSettingsService: SmsSettingsService) {}

  @Permissions(Permission.SETTINGS_VIEW)
  @Get()
  async getSettings(@Req() req: any, @Query('businessId') queryBusinessId?: string) {
    const user = req.user;
    const bId = user.role === 'super-admin' && queryBusinessId ? queryBusinessId : user.businessId;
    return this.smsSettingsService.getSettings(bId);
  }

  @Permissions(Permission.SETTINGS_EDIT)
  @Put()
  async updateSettings(@Req() req: any, @Body() dto: UpdateSmsSettingsDto) {
    const user = req.user;
    const bId = user.role === 'super-admin' && dto.businessId ? dto.businessId : user.businessId;
    return this.smsSettingsService.updateSettings(bId, dto);
  }

  @Permissions(Permission.SETTINGS_EDIT)
  @Post('test')
  async sendTestSms(@Req() req: any, @Body() dto: TestSmsDto) {
    const user = req.user;
    const bId = user.role === 'super-admin' && dto.businessId ? dto.businessId : user.businessId;
    return this.smsSettingsService.sendTestSms(bId, dto);
  }
}
