import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { getOrderById } from "@/lib/data/gemstones-db";
import {
  verifyCustomerSessionToken,
  verifySessionToken,
  verifyOrderAccessToken,
  CUSTOMER_SESSION_COOKIE_NAME,
  SESSION_COOKIE_NAME,
} from "@/lib/auth";

export async function GET(
  request: Request,
  props: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await props.params;
    const order = await getOrderById(id);

    if (!order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    // Security Authorization: IDOR & Customer PII Protection
    const cookieStore = await cookies();
    const adminToken = cookieStore.get(SESSION_COOKIE_NAME)?.value;
    const customerToken = cookieStore.get(CUSTOMER_SESSION_COOKIE_NAME)?.value;

    const isAdmin = adminToken ? Boolean(verifySessionToken(adminToken)) : false;
    const customerSession = customerToken ? verifyCustomerSessionToken(customerToken) : null;

    const url = new URL(request.url);
    const queryOrderToken = url.searchParams.get("token") || request.headers.get("x-order-token");
    const orderRef = order.order_number || order.id;
    const cookieOrderToken =
      cookieStore.get(`fg_order_${orderRef}`)?.value ||
      cookieStore.get(`fg_order_${order.id}`)?.value ||
      cookieStore.get(`fg_order_${id}`)?.value;
    const candidateOrderToken = queryOrderToken || cookieOrderToken;

    const isAuthorizedGuest =
      verifyOrderAccessToken(orderRef, candidateOrderToken) ||
      verifyOrderAccessToken(order.id, candidateOrderToken) ||
      verifyOrderAccessToken(id, candidateOrderToken);

    const isOrderOwner = Boolean(
      customerSession &&
        ((order.client_id && order.client_id === customerSession.id) ||
          (order.client_email &&
            order.client_email.toLowerCase() === customerSession.email.toLowerCase()))
    );

    if (!isAdmin && !isOrderOwner && !isAuthorizedGuest) {
      return NextResponse.json(
        { error: "Access denied. Order details are restricted to authorized clients." },
        { status: 403 }
      );
    }

    let items = [];
    try {
      items = typeof order.items === "string" ? JSON.parse(order.items) : (order.items || []);
    } catch {
      items = [];
    }

    const formattedOrder = {
      id: order.order_number || order.id,
      dbId: order.id,
      orderNumber: order.order_number,
      createdAt: order.created_at,
      date: order.created_at
        ? new Date(order.created_at).toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "short",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit",
          })
        : "Recently",
      client: {
        fullName: order.client_name || "Private Patron",
        email: order.client_email || "",
        phone: order.client_phone || "",
        clientId: order.client_id || undefined,
      },
      shippingAddress: {
        address: order.shipping_address || "",
        city: order.city || "",
        state: order.state || "",
        postalCode: order.postal_code || "",
        country: order.country || "",
      },
      courier: order.courier || "Armored Air Courier",
      items,
      subtotal: Number(order.subtotal || 0),
      total: Number(order.total || 0),
      currency: order.currency || "USD",
      paymentMethod: order.payment_method || "wire",
      bankReference: (items[0] as any)?.bankReference || order.bank_reference || null,
      paymentSlipUrl: (items[0] as any)?.paymentSlipUrl || order.payment_slip || null,
      status: order.status || "pending_verification",
      trackingNumber: order.tracking_number || null,
      destination: [order.city, order.country].filter(Boolean).join(", ") || "Vault Custody",
    };

    return NextResponse.json({ order: formattedOrder });
  } catch (error) {
    console.error("Error fetching order by ID:", error);
    return NextResponse.json({ error: "Failed to fetch order" }, { status: 500 });
  }
}
