import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import pool from "@/lib/db";
import { RowDataPacket } from "mysql2";
import crypto from "crypto";
import {
  createSessionToken,
  SESSION_COOKIE_NAME,
  createCustomerSessionToken,
  CUSTOMER_SESSION_COOKIE_NAME,
  hashPassword,
  timingSafeCompare,
  OAUTH_NONCE_COOKIE,
} from "@/lib/auth";

function getSafeRedirectDest(fromParam: string | null, fallback: string): string {
  if (!fromParam) return fallback;
  if (
    fromParam.startsWith("/") &&
    !fromParam.startsWith("//") &&
    !fromParam.startsWith("/\\") &&
    !fromParam.toLowerCase().includes("javascript:")
  ) {
    return fromParam;
  }
  return fallback;
}

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const state = searchParams.get("state");
  const error = searchParams.get("error");

  const cookieStore = await cookies();
  const expectedNonce = cookieStore.get(OAUTH_NONCE_COOKIE)?.value;

  // Clear the single-use OAuth nonce cookie immediately
  cookieStore.delete(OAUTH_NONCE_COOKIE);

  let from = "";
  let stateNonce = "";
  if (state) {
    try {
      const parsed = JSON.parse(Buffer.from(state, "base64url").toString("utf-8"));
      from = parsed.from || "";
      stateNonce = parsed.nonce || "";
    } catch {}
  }

  const safeFrom = getSafeRedirectDest(from, "");
  const loginUrl = new URL("/login", request.url);
  if (safeFrom) loginUrl.searchParams.set("from", safeFrom);

  if (error || !code) {
    loginUrl.searchParams.set("error", "Google authentication was cancelled or failed");
    return NextResponse.redirect(loginUrl.toString());
  }

  // Validate state nonce against HttpOnly cookie to defeat Login CSRF attacks
  if (!expectedNonce || !stateNonce || !timingSafeCompare(stateNonce, expectedNonce)) {
    loginUrl.searchParams.set("error", "Invalid or expired authentication session. Please try again.");
    return NextResponse.redirect(loginUrl.toString());
  }

  try {
    const clientId = process.env.GOOGLE_CLIENT_ID;
    const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
    const baseUrl = process.env.NEXTAUTH_URL || origin || "http://127.0.0.1:3000";
    const redirectUri = `${baseUrl}/api/auth/google/callback`;

    // 1. Exchange authorization code for tokens
    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id: clientId || "",
        client_secret: clientSecret || "",
        redirect_uri: redirectUri,
        grant_type: "authorization_code",
      }),
    });

    const tokenData = await tokenRes.json();
    if (!tokenRes.ok || !tokenData.access_token) {
      console.error("Google token exchange failed:", tokenData);
      loginUrl.searchParams.set("error", "Failed to exchange authorization token with Google");
      return NextResponse.redirect(loginUrl.toString());
    }

    // 2. Fetch Google profile info
    const profileRes = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });
    const profile = await profileRes.json();

    if (!profile || !profile.email) {
      loginUrl.searchParams.set("error", "Unable to retrieve profile from Google");
      return NextResponse.redirect(loginUrl.toString());
    }

    // Ensure Google has verified ownership of this email address to prevent account hijacking
    if (!profile.email_verified) {
      loginUrl.searchParams.set(
        "error",
        "Your Google account email address is not verified. Please verify your email with Google."
      );
      return NextResponse.redirect(loginUrl.toString());
    }

    const email = profile.email.trim().toLowerCase();
    const name = profile.name || email.split("@")[0];

    const cookieStore = await cookies();

    // 3. Check existing user
    const [rows] = await pool.query<RowDataPacket[]>(
      "SELECT id, name, email, phone, role FROM users WHERE email = ? LIMIT 1",
      [email]
    );

    let destination = getSafeRedirectDest(from, "/account");

    if (rows && rows.length > 0) {
      const user = rows[0];
      if (user.role === "ADMIN") {
        const adminToken = createSessionToken({ email, name: user.name || name });
        cookieStore.set(SESSION_COOKIE_NAME, adminToken, {
          httpOnly: true,
          secure: process.env.NODE_ENV === "production",
          sameSite: "lax",
          path: "/",
          maxAge: 7 * 24 * 60 * 60,
        });

        const custToken = createCustomerSessionToken({
          id: user.id,
          email,
          name: user.name || name,
        });
        cookieStore.set(CUSTOMER_SESSION_COOKIE_NAME, custToken, {
          httpOnly: true,
          secure: process.env.NODE_ENV === "production",
          sameSite: "lax",
          path: "/",
          maxAge: 7 * 24 * 60 * 60,
        });

        destination = getSafeRedirectDest(from, "/admindashboard");
        return NextResponse.redirect(new URL(destination, request.url));
      }

      // Customer
      const custToken = createCustomerSessionToken({
        id: user.id,
        email,
        name: user.name || name,
      });
      cookieStore.set(CUSTOMER_SESSION_COOKIE_NAME, custToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        path: "/",
        maxAge: 14 * 24 * 60 * 60,
      });

      return NextResponse.redirect(new URL(destination, request.url));
    }

    // New Google Patron
    const newUserId = crypto.randomUUID();
    const secureRandomSecret = crypto.randomBytes(32).toString("hex");
    const passwordHash = await hashPassword(`google-auth-${secureRandomSecret}`);

    await pool.query(
      `INSERT INTO users (id, name, email, password_hash, phone, role, created_at)
       VALUES (?, ?, ?, ?, '', 'CUSTOMER', NOW())`,
      [newUserId, name, email, passwordHash]
    );

    const clientIdCRM = `client-google-${Date.now()}`;
    try {
      await pool.query(
        `INSERT INTO clients (id, name, email, phone, total_spent, acquisitions, tier, location, created_at)
         VALUES (?, ?, ?, '', 0, 0, 'Regular Customer', 'Sri Lanka', NOW())
         ON DUPLICATE KEY UPDATE name = VALUES(name)`,
        [clientIdCRM, name, email]
      );
    } catch {}

    const token = createCustomerSessionToken({
      id: newUserId,
      email,
      name,
    });
    cookieStore.set(CUSTOMER_SESSION_COOKIE_NAME, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 14 * 24 * 60 * 60,
    });

    return NextResponse.redirect(new URL(destination, request.url));
  } catch (err) {
    console.error("Google OAuth callback error:", err);
    loginUrl.searchParams.set("error", "Google authentication failed unexpectedly");
    return NextResponse.redirect(loginUrl.toString());
  }
}
