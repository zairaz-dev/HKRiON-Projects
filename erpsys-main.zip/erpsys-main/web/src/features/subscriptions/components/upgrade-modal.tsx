"use strict";
"use client";

import React, { useState, useEffect, useRef } from 'react';
import { Plan, BillingInterval, SaasBankSetting } from '../types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  X,
  CheckCircle,
  ShieldCheck,
  Loader2,
  Landmark,
  Sparkles,
  Receipt,
  CreditCard,
  Smartphone,
  UploadCloud,
  FileImage,
  Trash2,
} from 'lucide-react';
import { subscriptionService } from '@/services/subscription-service';

declare global {
  interface Window {
    payhere?: any;
  }
}

interface UpgradeModalProps {
  plan: Plan;
  initialInterval?: BillingInterval;
  currency?: 'LKR' | 'USD';
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export function UpgradeModal({
  plan,
  initialInterval = 'MONTHLY',
  currency = 'LKR',
  isOpen,
  onClose,
  onSuccess,
}: UpgradeModalProps) {
  const [interval, setInterval] = useState<BillingInterval>(initialInterval);
  const [paymentMode, setPaymentMode] = useState<'payhere' | 'bank_transfer'>('payhere');
  const [transactionRef, setTransactionRef] = useState<string>('');
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [proofPreviewUrl, setProofPreviewUrl] = useState<string>('');
  const [uploadingProof, setUploadingProof] = useState<boolean>(false);
  const [loadingPayHere, setLoadingPayHere] = useState<boolean>(false);
  const [submittingBank, setSubmittingBank] = useState<boolean>(false);
  const [bankConfig, setBankConfig] = useState<SaasBankSetting | null>(null);
  const [error, setError] = useState<string>('');
  const [successMessage, setSuccessMessage] = useState<string>('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      subscriptionService.getSaasBankConfig().then((cfg) => {
        if (cfg) setBankConfig(cfg);
      });
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const currencySymbol = currency === 'USD' ? '$' : 'Rs.';
  const monthlyPrice = currency === 'USD' ? (plan.priceMonthlyUsd || 0) : plan.priceMonthly;
  const yearlyPrice = currency === 'USD' ? (plan.priceYearlyUsd || (plan.priceMonthlyUsd || 0) * 10) : plan.priceYearly;
  const basePrice = interval === 'YEARLY' ? yearlyPrice : monthlyPrice;
  const taxRate = 0.18;
  const taxAmount = Math.round(basePrice * taxRate * 100) / 100;
  const totalAmount = Math.round((basePrice + taxAmount) * 100) / 100;

  const monthlyAnnualized = monthlyPrice * 12;
  const savingsPercent = monthlyAnnualized > 0 && yearlyPrice < monthlyAnnualized
    ? Math.round(((monthlyAnnualized - yearlyPrice) / monthlyAnnualized) * 100)
    : 20;

  const isFreeOrZero = totalAmount <= 0;

  // Handle Slip File Selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setProofFile(file);
      setProofPreviewUrl(URL.createObjectURL(file));
    }
  };

  // 1. Direct Bank Transfer Handler with Slip Upload
  const handleBankTransferUpgrade = async () => {
    setError('');
    if (!transactionRef.trim()) {
      setError('Please enter your Bank Deposit Reference / UTR Number.');
      return;
    }

    setSubmittingBank(true);
    try {
      let uploadedUrl = '';
      if (proofFile) {
        setUploadingProof(true);
        const uploadRes = await subscriptionService.uploadProofFile(proofFile);
        uploadedUrl = uploadRes.url;
        setUploadingProof(false);
      }

      await subscriptionService.submitBankTransfer({
        planId: plan.id,
        billingInterval: interval,
        transactionId: transactionRef.trim(),
        proofUrl: uploadedUrl || undefined,
        notes: `Subscription Upgrade to ${plan.name} (${interval}) via Bank Transfer`,
      });

      setSuccessMessage('Bank Transfer request submitted! Super Admin will verify the deposit and activate your plan shortly.');
      if (onSuccess) onSuccess();
      setTimeout(() => {
        onClose();
      }, 2000);
    } catch (err: any) {
      setError(err.message || 'Failed to process bank transfer request. Please try again.');
    } finally {
      setSubmittingBank(false);
      setUploadingProof(false);
    }
  };

  // 2. PayHere.lk Online Checkout Handler
  const handlePayHereCheckout = async () => {
    setError('');
    setLoadingPayHere(true);
    try {
      const paymentParams = await subscriptionService.getPayHereParams(plan.id, interval, currency);

      if (typeof window !== 'undefined' && window.payhere) {
        window.payhere.onCompleted = async function onCompleted(orderId: string) {
          console.log('PayHere payment completed. OrderID:', orderId);
          try {
            await subscriptionService.completePayHereOrder(orderId);
            setSuccessMessage(`Payment successful! Order ID: ${orderId}. Your subscription is now active.`);
            if (onSuccess) onSuccess();
            setTimeout(() => {
              onClose();
            }, 1200);
          } catch (e: any) {
            console.error('Error confirming order:', e);
            setSuccessMessage(`Payment received! Refreshing subscription...`);
            if (onSuccess) onSuccess();
            setTimeout(() => {
              onClose();
            }, 1200);
          }
        };

        window.payhere.onDismissed = function onDismissed() {
          console.log('PayHere popup closed by user');
        };

        window.payhere.onError = function onError(errorMsg: any) {
          console.error('PayHere error occurred:', errorMsg);
          setError(typeof errorMsg === 'string' ? errorMsg : 'Payment could not be completed. Please try again.');
        };

        window.payhere.startPayment(paymentParams);
      } else {
        // Fallback if payhere.js is still loading dynamically
        const script = document.createElement('script');
        script.src = 'https://www.payhere.lk/lib/payhere.js';
        script.async = true;
        script.onload = () => {
          if (window.payhere) {
            window.payhere.onCompleted = async function onCompleted(orderId: string) {
              try {
                await subscriptionService.completePayHereOrder(orderId);
              } catch (e) {}
              if (onSuccess) onSuccess();
              onClose();
            };
            window.payhere.startPayment(paymentParams);
          }
        };
        document.body.appendChild(script);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to initiate PayHere payment.');
    } finally {
      setLoadingPayHere(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-lg bg-card border border-border rounded-xl overflow-hidden shadow-2xl relative max-h-[95vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border bg-background/50">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            <h3 className="text-sm font-bold text-foreground tracking-wider uppercase font-mono">
              Upgrade to {plan.name}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-5 overflow-y-auto flex-1">
          {successMessage && (
            <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 p-3.5 rounded-lg text-xs flex items-center gap-2">
              <CheckCircle className="w-4 h-4 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 p-3 rounded-lg text-xs">
              {error}
            </div>
          )}

          {/* Billing Interval Toggle */}
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">
              Billing Cycle
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setInterval('MONTHLY')}
                className={`p-3 rounded-lg border text-left transition-all ${
                  interval === 'MONTHLY'
                    ? 'border-primary bg-primary/10 text-foreground'
                    : 'border-border bg-background/40 text-muted-foreground hover:border-border/80'
                }`}
              >
                <div className="text-xs font-bold">Monthly Billing</div>
                <div className="text-sm font-extrabold text-foreground mt-0.5">
                  {currencySymbol} {monthlyPrice.toLocaleString()} <span className="text-[10px] font-normal text-muted-foreground">/mo</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setInterval('YEARLY')}
                className={`p-3 rounded-lg border text-left transition-all relative overflow-hidden ${
                  interval === 'YEARLY'
                    ? 'border-primary bg-primary/10 text-foreground'
                    : 'border-border bg-background/40 text-muted-foreground hover:border-border/80'
                }`}
              >
                <span className="absolute top-1.5 right-2 bg-emerald-500/20 text-emerald-400 text-[9px] font-bold px-1.5 py-0.5 rounded">
                  Save ~{savingsPercent}%
                </span>
                <div className="text-xs font-bold">Yearly Billing</div>
                <div className="text-sm font-extrabold text-foreground mt-0.5">
                  {currencySymbol} {yearlyPrice.toLocaleString()} <span className="text-[10px] font-normal text-muted-foreground">/yr</span>
                </div>
              </button>
            </div>
          </div>

          {/* Payment Method Selection */}
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">
              Choose Payment Method
            </label>

            <div className="grid grid-cols-2 gap-3">
              {/* Option 1: PayHere.lk */}
              <button
                type="button"
                onClick={() => setPaymentMode('payhere')}
                className={`p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between space-y-2 ${
                  paymentMode === 'payhere'
                    ? 'border-primary bg-primary/10 ring-1 ring-primary/30'
                    : 'border-border bg-background/40 hover:border-border/80'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <CreditCard className="w-4 h-4 text-primary" />
                    <span className="text-xs font-bold text-foreground">PayHere.lk</span>
                  </div>
                  <span className="text-[9px] font-bold bg-primary/20 text-primary px-1.5 py-0.5 rounded font-mono">
                    🇱🇰 SRI LANKA
                  </span>
                </div>
                <p className="text-[10px] text-muted-foreground leading-tight">
                  Cards (Visa/Master), FriMi, Genie, eZ Cash, mCash & Internet Banking.
                </p>
              </button>

              {/* Option 2: Direct Bank Transfer */}
              <button
                type="button"
                onClick={() => setPaymentMode('bank_transfer')}
                className={`p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between space-y-2 ${
                  paymentMode === 'bank_transfer'
                    ? 'border-primary bg-primary/10 ring-1 ring-primary/30'
                    : 'border-border bg-background/40 hover:border-border/80'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Landmark className="w-4 h-4 text-primary" />
                    <span className="text-xs font-bold text-foreground">Bank Transfer</span>
                  </div>
                  <span className="text-[9px] font-bold bg-amber-500/20 text-amber-400 px-1.5 py-0.5 rounded font-mono">
                    VERIFICATION
                  </span>
                </div>
                <p className="text-[10px] text-muted-foreground leading-tight">
                  Direct bank deposit with Slip upload & Super Admin approval.
                </p>
              </button>
            </div>
          </div>

          {/* Conditional Details based on Payment Mode */}
          {paymentMode === 'payhere' ? (
            <div className="bg-primary/5 border border-primary/20 rounded-xl p-3.5 space-y-2 text-xs">
              <div className="flex items-center justify-between font-semibold text-foreground">
                <span className="flex items-center gap-1.5 text-primary">
                  <Smartphone className="w-4 h-4" /> Instant Online Checkout
                </span>
                <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded">
                  {currency || 'LKR'} Currency
                </span>
              </div>
              <p className="text-[11px] text-muted-foreground">
                Clicking the button below will open the official secure <strong>PayHere.lk</strong> payment window. Your plan will activate automatically immediately after payment completion.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {/* Dynamic Bank Account Box */}
              <div className="bg-background/60 border border-border/80 rounded-xl p-3.5 space-y-1.5 text-xs">
                <div className="flex items-center justify-between text-muted-foreground">
                  <span>Account Name:</span>
                  <span className="font-semibold text-foreground font-mono">
                    {bankConfig?.accountName || 'HKRION SYSTEMS PVT LTD'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-muted-foreground">
                  <span>Bank & Branch:</span>
                  <span className="font-semibold text-foreground font-mono">
                    {bankConfig?.bankName || 'Commercial Bank of Ceylon'}, {bankConfig?.branchName || 'Colombo'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-muted-foreground">
                  <span>Account Number:</span>
                  <span className="font-semibold text-foreground font-mono">
                    {bankConfig?.accountNumber || '800234567890'}
                  </span>
                </div>
                {bankConfig?.swiftCode && (
                  <div className="flex items-center justify-between text-muted-foreground">
                    <span>SWIFT / IFSC:</span>
                    <span className="font-semibold text-foreground font-mono">{bankConfig.swiftCode}</span>
                  </div>
                )}
                {bankConfig?.instructions && (
                  <div className="border-t border-border/60 pt-1.5 text-[10px] text-muted-foreground italic">
                    ℹ {bankConfig.instructions}
                  </div>
                )}
              </div>

              {/* Reference & Slip Upload Inputs */}
              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">
                    Transaction Reference / UTR Number *
                  </label>
                  <Input
                    placeholder="Enter NEFT/IMPS UTR or Bank Ref #"
                    value={transactionRef}
                    onChange={(e) => setTransactionRef(e.target.value)}
                    className="h-9 text-xs font-mono"
                    required
                  />
                </div>

                {/* Bank Slip Upload Area */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">
                    Upload Bank Deposit Slip / Screenshot
                  </label>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept="image/*,.pdf"
                    className="hidden"
                  />

                  {proofFile ? (
                    <div className="flex items-center justify-between p-2.5 rounded-lg border border-primary/40 bg-primary/5 text-xs">
                      <div className="flex items-center gap-2 truncate">
                        <FileImage className="w-4 h-4 text-primary shrink-0" />
                        <span className="truncate text-foreground font-mono text-[11px]">{proofFile.name}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setProofFile(null);
                          setProofPreviewUrl('');
                          if (fileInputRef.current) fileInputRef.current.value = '';
                        }}
                        className="text-muted-foreground hover:text-rose-400 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full border border-dashed border-border hover:border-primary/60 rounded-lg p-3 text-center transition-all bg-background/30 hover:bg-background/50 flex flex-col items-center justify-center gap-1 cursor-pointer"
                    >
                      <UploadCloud className="w-4 h-4 text-muted-foreground" />
                      <span className="text-xs text-foreground font-medium">Click to upload deposit receipt</span>
                      <span className="text-[10px] text-muted-foreground">PNG, JPG, or PDF up to 5MB</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Order Summary Breakdown */}
          <div className="bg-secondary/40 border border-border/70 rounded-xl p-4 space-y-2">
            <div className="text-xs font-bold text-foreground mb-2 flex items-center justify-between">
              <span>Order Summary</span>
              <span className="text-[10px] font-mono text-muted-foreground uppercase">
                {interval} PLAN
              </span>
            </div>
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Base Price</span>
              <span className="font-mono text-foreground">{currencySymbol} {basePrice.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>GST / Taxes (18%)</span>
              <span className="font-mono text-foreground">{currencySymbol} {taxAmount.toLocaleString()}</span>
            </div>
            <div className="border-t border-border pt-2 flex justify-between text-sm font-bold text-foreground">
              <span>Total Payable</span>
              <span className="font-mono text-primary text-base">{currencySymbol} {totalAmount.toLocaleString()}</span>
            </div>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
            <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>256-Bit Encrypted & PCI-DSS Compliant Payment Processing.</span>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-border bg-background/50 flex items-center justify-end gap-3 shrink-0">
          <Button type="button" variant="outline" onClick={onClose} className="text-xs h-9">
            Cancel
          </Button>

          {paymentMode === 'payhere' ? (
            <Button
              type="button"
              onClick={handlePayHereCheckout}
              disabled={loadingPayHere || isFreeOrZero}
              className="text-xs h-9 px-5 shadow-lg shadow-primary/20 flex items-center gap-1.5 font-bold"
            >
              {loadingPayHere ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" /> Initializing PayHere...
                </>
              ) : isFreeOrZero ? (
                <>Free Plan / Non-Billable</>
              ) : (
                <>
                  <CreditCard className="w-3.5 h-3.5" /> Pay with PayHere.lk {currencySymbol} {totalAmount.toLocaleString()}
                </>
              )}
            </Button>
          ) : (
            <Button
              type="button"
              onClick={handleBankTransferUpgrade}
              disabled={submittingBank || uploadingProof || isFreeOrZero}
              className="text-xs h-9 px-5 shadow-lg shadow-primary/20 flex items-center gap-1.5 font-bold"
            >
              {submittingBank || uploadingProof ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" /> Submitting Slip...
                </>
              ) : isFreeOrZero ? (
                <>Free Plan / Non-Billable</>
              ) : (
                <>
                  <Receipt className="w-3.5 h-3.5" /> Submit Bank Transfer {currencySymbol} {totalAmount.toLocaleString()}
                </>
              )}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
