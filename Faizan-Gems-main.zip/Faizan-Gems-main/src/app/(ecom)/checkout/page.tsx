"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCart } from "@/features/cart/context/CartContext";
import { useCurrency } from "@/features/currency/context/CurrencyContext";
import { useAuth } from "@/features/auth/context/AuthContext";
import { useCMS } from "@/features/cms/useCMS";
import {
  CertificateShieldIcon,
  ArmoredTruckIcon,
  SecurityLockIcon,
  CheckIcon,
  CloseIcon,
  ChevronRightIcon,
  CopyIcon
} from "@/components/ui/LuxuryIcons";
import { LuxuryPrice } from "@/components/ui/LuxuryPrice";
import { LuxurySelect } from "@/components/ui/LuxurySelect";
import { COUNTRY_OPTIONS, getCountryFlag, isSriLanka } from "@/lib/data/countries";
import { SRI_LANKA_DISTRICTS } from "@/lib/data/districts";
import { SITE_CONFIG } from "@/lib/constants/site";
import {
  getAddressFormat,
  requiresPostalCode,
  formatFullStreetAddress,
} from "@/lib/data/address-formats";

interface SavedAddress {
  id: string;
  fullName: string;
  phone: string;
  address: string;
  city: string;
  district: string;
  postalCode: string;
  country: string;
  isDefault?: boolean;
}

export default function CheckoutPage() {
  const router = useRouter();
  const { items, subtotal, clearCart } = useCart();
  const { formatPrice } = useCurrency();
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { getBlock } = useCMS();
  const headerLogo = getBlock("branding.header_logo", SITE_CONFIG.branding.headerLogo);

  // Dynamic CMS Banking Details
  const bankName = getBlock("banking.bank_name", SITE_CONFIG.banking.bankName);
  const bankShortName = getBlock("banking.bank_short_name", SITE_CONFIG.banking.bankShortName);
  const branchName = getBlock("banking.branch_name", SITE_CONFIG.banking.branchName);
  const accountName = getBlock("banking.account_name", SITE_CONFIG.banking.accountName);
  const accountNumber = getBlock("banking.account_number", SITE_CONFIG.banking.accountNumber);
  const bankLogo = getBlock("banking.bank_logo", SITE_CONFIG.banking.bankLogo);

  const rawAccountNumber = accountNumber ? accountNumber.replace(/\s+/g, "") : SITE_CONFIG.banking.accountNumber;
  const formattedAccountNumber = rawAccountNumber.length >= 8
    ? rawAccountNumber.replace(/(\d{4})(?=\d)/g, "$1 ")
    : (accountNumber || SITE_CONFIG.banking.formattedAccountNumber);

  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Saved Addresses State
  const [savedAddresses, setSavedAddresses] = useState<SavedAddress[]>([]);
  const [selectedAddressId, setSelectedAddressId] = useState<string>("");
  const [isAddingNewAddress, setIsAddingNewAddress] = useState(false);
  const [isLoadingAddresses, setIsLoadingAddresses] = useState(false);

  // Form State
  const [formData, setFormData] = useState({
    email: user?.email || "",
    fullName: user?.name || "",
    phone: user?.phone || "",
    clientId: user?.id || "",
    address: "",
    addressLine2: "",
    city: "",
    state: "",
    postalCode: "",
    country: "United States",
    courier: "Armored Air Courier",
    paymentMethod: "wire",
    bankReference: "",
    paymentSlipUrl: "",
    paymentSlipName: "",
    specialInstructions: "",
  });

  // Fetch saved delivery addresses from database
  const loadAddresses = React.useCallback(async (targetEmail?: string) => {
    const email = targetEmail || user?.email || formData.email;
    if (!email) return;
    setIsLoadingAddresses(true);
    try {
      const res = await fetch(`/api/account/addresses?email=${encodeURIComponent(email)}`);
      if (res.ok) {
        const data = await res.json();
        const list: SavedAddress[] = data.addresses || [];
        setSavedAddresses(list);
        if (list.length > 0) {
          // Automatically select default or most recent address
          const defaultAddr = list.find((a) => a.isDefault) || list[0];
          setSelectedAddressId(defaultAddr.id);
          setIsAddingNewAddress(false);
          setFormData((prev) => ({
            ...prev,
            fullName: defaultAddr.fullName || prev.fullName,
            phone: defaultAddr.phone || prev.phone,
            address: defaultAddr.address,
            addressLine2: "",
            city: defaultAddr.city,
            state: defaultAddr.district,
            postalCode: defaultAddr.postalCode,
            country: defaultAddr.country || "United States",
          }));
        } else {
          setIsAddingNewAddress(true);
        }
      }
    } catch (err) {
      console.error("Failed to load saved addresses:", err);
    } finally {
      setIsLoadingAddresses(false);
    }
  }, [user?.email, formData.email]);

  React.useEffect(() => {
    if (user?.email) {
      loadAddresses(user.email);
    }
  }, [user?.email, loadAddresses]);

  // Sync with authenticated customer profile
  React.useEffect(() => {
    if (user) {
      setFormData((prev) => ({
        ...prev,
        fullName: user.name || prev.fullName,
        email: user.email || prev.email,
        phone: user.phone || prev.phone,
        clientId: user.id || prev.clientId,
      }));
    }
  }, [user]);

  const handleSelectAddress = (addr: SavedAddress) => {
    setSelectedAddressId(addr.id);
    setIsAddingNewAddress(false);
    setFormData((prev) => ({
      ...prev,
      fullName: addr.fullName || prev.fullName,
      phone: addr.phone || prev.phone,
      address: addr.address,
      addressLine2: "",
      city: addr.city,
      state: addr.district,
      postalCode: addr.postalCode,
      country: addr.country || "United States",
    }));
  };

  const handleAddNewAddressClick = () => {
    setIsAddingNewAddress(true);
    setSelectedAddressId("new");
    setFormData((prev) => ({
      ...prev,
      address: "",
      addressLine2: "",
      city: "",
      state: "",
      postalCode: "",
      country: prev.country || "United States",
    }));
  };

  const handleCancelNewAddress = () => {
    if (savedAddresses.length > 0) {
      const target = savedAddresses.find((a) => a.id === selectedAddressId && a.id !== "new") || savedAddresses[0];
      handleSelectAddress(target);
    }
  };

  // Redirect unauthenticated clients to login with return path to checkout
  React.useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      router.replace("/login?from=/checkout");
    }
  }, [authLoading, isAuthenticated, router]);

  const [isProcessing, setIsProcessing] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [isUploadingSlip, setIsUploadingSlip] = useState(false);
  const [slipUploadError, setSlipUploadError] = useState<string | null>(null);
  const [stepErrors, setStepErrors] = useState<Record<string, string>>({});
  const [orderError, setOrderError] = useState<string | null>(null);
  const slipFileInputRef = React.useRef<HTMLInputElement | null>(null);

  const grandTotal = subtotal;

  const [liveUnavailableKeys, setLiveUnavailableKeys] = useState<Set<string>>(new Set());
  const [isLiveChecked, setIsLiveChecked] = useState(false);

  // Real-time stock verification against live database when entering checkout
  useEffect(() => {
    if (items.length === 0) return;
    let isMounted = true;
    fetch("/api/gemstones")
      .then((res) => (res.ok ? res.json() : []))
      .then((gems: any[]) => {
        if (!isMounted || !Array.isArray(gems)) return;
        const gemMap = new Map(gems.map((g) => [g.id, g]));
        const unavail = new Set<string>();

        for (const item of items) {
          const live = gemMap.get(item.gemstone.id);
          const itemKey = `${item.gemstone.id}-${item.selectedVariant?.id || "default"}`;
          if (!live || !live.inStock) {
            unavail.add(itemKey);
            continue;
          }
          if (item.selectedVariant && live.variants && live.variants.length > 0) {
            const liveVar = live.variants.find((v: any) => v.id === item.selectedVariant?.id);
            if (!liveVar || (liveVar.stock ?? 0) < (item.quantity ?? 1)) {
              unavail.add(itemKey);
            }
          }
        }
        setLiveUnavailableKeys(unavail);
        setIsLiveChecked(true);
      })
      .catch(() => {});

    return () => {
      isMounted = false;
    };
  }, [items]);

  const outOfStockItems = items.filter((item) => {
    const itemKey = `${item.gemstone.id}-${item.selectedVariant?.id || "default"}`;
    if (isLiveChecked) {
      return liveUnavailableKeys.has(itemKey);
    }
    if (item.gemstone.inStock === false) return true;
    if (item.selectedVariant && (item.selectedVariant.stock ?? 0) <= 0) return true;
    return false;
  });
  const hasOutOfStock = outOfStockItems.length > 0;

  const handleCopyText = (text: string, key: string) => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 2000);
    }
  };

  const handleCopyAllBankDetails = () => {
    const details = [
      "FAIZAN GEMS (PVT) LTD - OFFICIAL BENEFICIARY DETAILS",
      `Bank Name: ${bankName}`,
      `Branch: ${branchName}`,
      `Account Name: ${accountName}`,
      `Account Number: ${rawAccountNumber}`,
    ].join("\n");
    handleCopyText(details, "all");
  };

  const handleSlipUpload = async (file: File) => {
    setIsUploadingSlip(true);
    setSlipUploadError(null);
    setStepErrors((prev) => {
      const next = { ...prev };
      delete next.paymentSlip;
      return next;
    });

    try {
      if (file.size > 25 * 1024 * 1024) {
        throw new Error("File exceeds maximum 25MB limit.");
      }

      const uploadData = new FormData();
      uploadData.append("file", file);
      uploadData.append("category", "slips");

      const res = await fetch("/api/upload/slip", {
        method: "POST",
        body: uploadData,
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to upload slip");
      }

      setFormData((prev) => ({
        ...prev,
        paymentSlipUrl: data.url,
        paymentSlipName: file.name,
      }));
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Failed to upload slip";
      setSlipUploadError(msg);
    } finally {
      setIsUploadingSlip(false);
    }
  };

  const validateStep1 = () => {
    const errors: Record<string, string> = {};
    const name = formData.fullName.trim();
    if (!name || name.length < 2) {
      errors.fullName = "Please enter your full name (minimum 2 characters).";
    }
    const email = formData.email.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || !emailRegex.test(email)) {
      errors.email = "Please enter a valid email address (e.g. name@domain.com).";
    }
    const phoneDigits = formData.phone.replace(/\D/g, "");
    if (!formData.phone.trim() || phoneDigits.length < 9) {
      errors.phone = "Please enter a valid phone number (minimum 9 digits).";
    }
    return errors;
  };

  const validateStep2 = () => {
    const errors: Record<string, string> = {};
    if (!isAddingNewAddress && savedAddresses.length > 0) {
      if (!formData.address || !selectedAddressId) {
        errors.address = "Please select a delivery address to proceed.";
      }
    } else {
      const format = getAddressFormat(formData.country);

      if (!formData.country || formData.country.trim() === "") {
        errors.country = "Please select your destination country.";
      }

      const addr = formData.address.trim();
      if (!addr || addr.length < 3) {
        errors.address = `Please enter your ${format.fields.addressLine1.label.toLowerCase()} (minimum 3 characters).`;
      }

      const city = formData.city.trim();
      if (!city || city.length < 2) {
        errors.city = `Please enter your ${format.fields.city.label.toLowerCase()}.`;
      }

      if (format.fields.state.required && (!formData.state || formData.state.trim() === "")) {
        errors.state = format.fields.state.type === "select"
          ? `Please select your ${format.fields.state.label.toLowerCase()}.`
          : `Please enter your ${format.fields.state.label.toLowerCase()}.`;
      }

      if (format.hasPostalCode && format.fields.postalCode?.required) {
        const postal = formData.postalCode.trim();
        if (!postal || postal.length < 2) {
          errors.postalCode = `Please enter a valid ${format.fields.postalCode.label.toLowerCase()}.`;
        }
      }
    }
    return errors;
  };

  const validateStep3 = () => {
    const errors: Record<string, string> = {};
    const ref = formData.bankReference.trim();
    if (!ref || ref.length < 3) {
      errors.bankReference = "Please enter your transaction reference number from your bank or mobile receipt.";
    }
    if (!formData.paymentSlipUrl) {
      errors.paymentSlip = "Please upload a photo or PDF of your bank transfer / deposit slip.";
    }
    return errors;
  };

  const handleNextStep = async (e: React.FormEvent) => {
    e.preventDefault();
    setOrderError(null);

    if (step === 1) {
      const errors = validateStep1();
      if (Object.keys(errors).length > 0) {
        setStepErrors(errors);
        return;
      }
      setStepErrors({});

      // If moving from Step 1 to Step 2, ensure addresses are loaded for this user
      if (savedAddresses.length === 0) {
        const emailToUse = formData.email || user?.email;
        if (emailToUse) {
          await loadAddresses(emailToUse);
        }
      }
    } else if (step === 2) {
      const errors = validateStep2();
      if (Object.keys(errors).length > 0) {
        setStepErrors(errors);
        return;
      }
      setStepErrors({});

      // If user entered a new address, automatically save it to database
      if (isAddingNewAddress && formData.address) {
        const emailToUse = user?.email || formData.email;
        if (emailToUse) {
          try {
            const combinedAddress = formatFullStreetAddress(formData.address, formData.addressLine2);
            const res = await fetch("/api/account/addresses", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                email: emailToUse,
                fullName: formData.fullName,
                phone: formData.phone,
                address: combinedAddress,
                city: formData.city,
                district: formData.state,
                postalCode: requiresPostalCode(formData.country) ? formData.postalCode : "",
                country: formData.country || "United States",
              }),
            });

            if (res.ok) {
              const data = await res.json();
              if (data.address) {
                setSavedAddresses((prev) => {
                  const filtered = prev.filter((a) => a.id !== data.address.id && a.address !== data.address.address);
                  return [data.address, ...filtered];
                });
                setSelectedAddressId(data.address.id);
                setIsAddingNewAddress(false);
              }
            }
          } catch (err) {
            console.error("Non-fatal: auto-saving address failed:", err);
          }
        }
      }
    } else if (step === 3) {
      const errors = validateStep3();
      if (Object.keys(errors).length > 0) {
        setStepErrors(errors);
        return;
      }
      setStepErrors({});
    }

    if (step < 4) {
      setStep((prev) => (prev + 1) as 1 | 2 | 3 | 4);
    }
  };

  const handlePlaceOrder = async () => {
    if (hasOutOfStock) {
      setOrderError(`"${outOfStockItems[0].gemstone.name}" is out of stock. Please remove it from your shopping bag.`);
      return;
    }

    setIsProcessing(true);
    setOrderError(null);
    const randomOrderNum = "ORD-MA-" + Math.floor(100000 + Math.random() * 900000);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          orderNumber: randomOrderNum,
          client: {
            fullName: formData.fullName,
            email: formData.email,
            phone: formData.phone,
            clientId: formData.clientId,
          },
          shippingAddress: {
            address: formatFullStreetAddress(formData.address, formData.addressLine2),
            city: formData.city,
            state: formData.state,
            postalCode: requiresPostalCode(formData.country) ? formData.postalCode : "",
            country: formData.country,
          },
          courier: formData.courier,
          items: items.map((it) => ({
            ...it,
            paymentSlipUrl: formData.paymentSlipUrl || undefined,
            bankReference: formData.bankReference.trim() || undefined,
          })),
          subtotal,
          total: grandTotal,
          paymentMethod: formData.bankReference.trim()
            ? `Bank Transfer (Ref: ${formData.bankReference.trim()})`
            : "Bank Transfer",
          bankReference: formData.bankReference.trim() || undefined,
          paymentSlip: formData.paymentSlipUrl || undefined,
          status: "pending_verification",
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to place order. Please review your details and try again.");
      }

      clearCart();
      const tokenParam = data?.orderToken ? `&token=${encodeURIComponent(data.orderToken)}` : "";
      router.push(`/orders/${data?.orderNumber || randomOrderNum}?success=true${tokenParam}`);
    } catch (err: any) {
      setOrderError(err.message || "Failed to process order.");
      setIsProcessing(false);
    }
  };

  // 1. Auth Loading State
  if (authLoading) {
    return (
      <div className="bg-[#FAF8F5] min-h-screen py-24 flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 border-2 border-[#C5A880] border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="font-serif text-lg text-[#18181D]">Loading checkout...</p>
        </div>
      </div>
    );
  }

  // 2. Unauthenticated State: Redirecting to Login
  if (!isAuthenticated) {
    return (
      <div className="bg-[#FAF8F5] min-h-screen py-16 px-4 flex flex-col justify-between items-center selection:bg-[#C5A880] selection:text-[#0D0D11]">
        <div className="my-auto text-center space-y-4 max-w-sm w-full">
          <div className="mb-6">
            <Link href="/" className="inline-block transition-opacity hover:opacity-85">
              <Image
                src={headerLogo}
                alt="Faizan Gems"
                width={180}
                height={45}
                className="h-9 w-auto object-contain mx-auto"
                priority
                unoptimized
              />
            </Link>
          </div>
          <div className="bg-white border border-[#E8E4DC] p-8 shadow-sm space-y-4">
            <div className="w-8 h-8 border-2 border-[#C5A880] border-t-transparent rounded-full animate-spin mx-auto" />
            <h2 className="font-serif text-xl text-[#18181D]">Please Sign In to Continue</h2>
            <p className="text-xs text-[#8C867D] font-sans leading-relaxed">
              Please sign in to complete your purchase. Redirecting to login page...
            </p>
            <Link
              href="/login?from=/checkout"
              className="inline-block mt-2 text-xs uppercase tracking-widest text-[#9A7B4F] hover:text-[#7A5B2F] underline font-sans"
            >
              Click here if not redirected automatically
            </Link>
          </div>
        </div>
        <p className="text-[10px] text-[#8C867D] font-mono pt-6">
          © {new Date().getFullYear()} Faizan Gems (Pvt) Ltd. All rights reserved.
        </p>
      </div>
    );
  }

  if (items.length === 0 && step < 4) {
    return (
      <div className="bg-[#FAF8F5] min-h-screen py-16 px-4 flex flex-col justify-between items-center">
        <div className="my-auto text-center max-w-md w-full">
          <div className="mb-6">
            <Link href="/" className="inline-block transition-opacity hover:opacity-85">
              <Image
                src={headerLogo}
                alt="Faizan Gems"
                width={180}
                height={45}
                className="h-9 w-auto object-contain mx-auto"
                priority
                unoptimized
              />
            </Link>
          </div>
          <div className="bg-white border border-[#E8E4DC] p-10 shadow-sm space-y-4">
            <h2 className="font-serif text-2xl text-[#18181D]">Your Shopping Bag is Empty</h2>
            <p className="text-xs text-[#8C867D] font-sans leading-relaxed">
              Please select a rare natural gemstone from our collection before proceeding to checkout.
            </p>
            <Link
              href="/shop"
              className="inline-block mt-4 px-8 py-3 bg-[#18181D] hover:bg-[#2A2A32] text-white text-xs uppercase tracking-luxury font-sans font-medium transition-colors shadow-sm"
            >
              Explore Collection
            </Link>
          </div>
        </div>
        <p className="text-[10px] text-[#8C867D] font-mono pt-6">
          © {new Date().getFullYear()} Faizan Gems (Pvt) Ltd. All rights reserved.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-[#FAF8F5] min-h-screen py-8 sm:py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Distraction-Free Luxury Checkout Header */}
        <div className="flex items-center justify-between border-b border-[#E8E4DC] pb-6 mb-8 sm:mb-10 gap-4">
          <Link
            href="/cart"
            className="inline-flex items-center gap-1.5 text-xs font-sans uppercase tracking-wider text-[#554F47] hover:text-[#18181D] transition-colors group"
          >
            <span className="text-sm transition-transform group-hover:-translate-x-1">&larr;</span>
            <span className="hidden sm:inline">Return to </span>
            <span>Bag</span>
          </Link>

          <Link href="/" className="inline-block transition-opacity hover:opacity-85 text-center">
            <Image
              src={headerLogo}
              alt="Faizan Gems"
              width={180}
              height={45}
              className="h-8 sm:h-9 w-auto object-contain mx-auto"
              priority
              unoptimized
            />
            <span className="text-[9px] font-sans tracking-wide-luxury uppercase text-[#C5A880] block mt-1">
              Secure Checkout
            </span>
          </Link>
        </div>

        {/* 4-Step Progress Indicator */}
        <div className="max-w-2xl mx-auto mb-10 sm:mb-12">
          <div className="flex items-center justify-between text-xs font-sans">
            <button
              onClick={() => step > 1 && setStep(1)}
              className={`flex items-center gap-1.5 uppercase tracking-wider ${
                step >= 1 ? "text-[#18181D] font-medium" : "text-[#8C867D]"
              }`}
            >
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                step >= 1 ? "bg-[#18181D] text-white" : "bg-[#E8E4DC] text-[#8C867D]"
              }`}>1</span>
              <span>Contact</span>
            </button>
            <span className="h-[1px] w-12 bg-[#E8E4DC]" />

            <button
              onClick={() => step > 2 && setStep(2)}
              className={`flex items-center gap-1.5 uppercase tracking-wider ${
                step >= 2 ? "text-[#18181D] font-medium" : "text-[#8C867D]"
              }`}
            >
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                step >= 2 ? "bg-[#18181D] text-white" : "bg-[#E8E4DC] text-[#8C867D]"
              }`}>2</span>
              <span>Delivery</span>
            </button>
            <span className="h-[1px] w-12 bg-[#E8E4DC]" />

            <button
              onClick={() => step > 3 && setStep(3)}
              className={`flex items-center gap-1.5 uppercase tracking-wider ${
                step >= 3 ? "text-[#18181D] font-medium" : "text-[#8C867D]"
              }`}
            >
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                step >= 3 ? "bg-[#18181D] text-white" : "bg-[#E8E4DC] text-[#8C867D]"
              }`}>3</span>
              <span>Payment</span>
            </button>
            <span className="h-[1px] w-12 bg-[#E8E4DC]" />

            <div className={`flex items-center gap-1.5 uppercase tracking-wider ${
              step === 4 ? "text-[#18181D] font-medium" : "text-[#8C867D]"
            }`}>
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                step === 4 ? "bg-[#18181D] text-white" : "bg-[#E8E4DC] text-[#8C867D]"
              }`}>4</span>
              <span>Review</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Main Form Column (7 Cols) */}
          <div className="lg:col-span-7 bg-white border border-[#E8E4DC] p-6 sm:p-10 shadow-sm">
            {/* STEP 1: Contact Info */}
            {step === 1 && (
              <form onSubmit={handleNextStep} className="space-y-6">
                <div>
                  <h2 className="font-serif text-2xl text-[#18181D]">1. Contact Details</h2>
                  <p className="text-xs text-[#8C867D] font-sans mt-1">
                    We will use these details to update you about your order and delivery.
                  </p>
                </div>

                <div className="space-y-4 text-xs font-sans">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                        Full Name *
                      </label>
                      {stepErrors.fullName && (
                        <span className="text-[11px] text-red-600 font-sans">{stepErrors.fullName}</span>
                      )}
                    </div>
                    <input
                      type="text"
                      value={formData.fullName}
                      onChange={(e) => {
                        setFormData({ ...formData, fullName: e.target.value });
                        if (stepErrors.fullName) setStepErrors((prev) => ({ ...prev, fullName: "" }));
                      }}
                      placeholder="Your full name"
                      className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none transition-colors ${
                        stepErrors.fullName ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                      }`}
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                          Email Address *
                        </label>
                      </div>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => {
                          setFormData({ ...formData, email: e.target.value });
                          if (stepErrors.email) setStepErrors((prev) => ({ ...prev, email: "" }));
                        }}
                        placeholder="name@domain.com"
                        className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none transition-colors ${
                          stepErrors.email ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                        }`}
                      />
                      {stepErrors.email && (
                        <span className="text-[11px] text-red-600 font-sans block mt-1">{stepErrors.email}</span>
                      )}
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                          Phone Number *
                        </label>
                      </div>
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => {
                          setFormData({ ...formData, phone: e.target.value });
                          if (stepErrors.phone) setStepErrors((prev) => ({ ...prev, phone: "" }));
                        }}
                        placeholder="+94 (75) 000 0000"
                        className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none transition-colors ${
                          stepErrors.phone ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                        }`}
                      />
                      {stepErrors.phone && (
                        <span className="text-[11px] text-red-600 font-sans block mt-1">{stepErrors.phone}</span>
                      )}
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-4 bg-[#18181D] hover:bg-[#2A2A32] text-white text-xs uppercase tracking-luxury font-sans font-medium transition-colors shadow-md"
                >
                  Continue to Delivery &rarr;
                </button>
              </form>
            )}

            {/* STEP 2: Shipping & Delivery */}
            {step === 2 && (
              <form onSubmit={handleNextStep} className="space-y-6">
                <div>
                  <h2 className="font-serif text-2xl text-[#18181D]">2. Delivery Address</h2>
                  <p className="text-xs text-[#8C867D] font-sans mt-1">
                    Every order is 100% insured and delivered safely to your address.
                  </p>
                </div>

                <div className="space-y-4 text-xs font-sans">
                  {/* Saved Address Cards Mode */}
                  {!isAddingNewAddress && savedAddresses.length > 0 ? (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-[#554F47] uppercase tracking-wider text-[10px] font-medium">
                          Your Saved Address ({savedAddresses.length})
                        </label>
                        <span className="text-[10px] text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 uppercase tracking-wider font-mono">
                          Saved in Account
                        </span>
                      </div>

                      <div className="grid grid-cols-1 gap-3">
                        {savedAddresses.map((addr) => {
                          const isSelected = selectedAddressId === addr.id;
                          return (
                            <div
                              key={addr.id}
                              onClick={() => handleSelectAddress(addr)}
                              className={`p-4 sm:p-5 border cursor-pointer transition-all relative ${
                                isSelected
                                  ? "border-[#C5A880] bg-[#FAF8F5] shadow-sm ring-1 ring-[#C5A880]"
                                  : "border-[#E8E4DC] bg-white hover:border-[#C5A880]/60 hover:bg-[#FAF8F5]/40"
                              }`}
                            >
                              <div className="flex items-start justify-between gap-3">
                                <div className="flex items-start gap-3.5">
                                  <div className="mt-0.5">
                                    <input
                                      type="radio"
                                      name="selectedAddress"
                                      checked={isSelected}
                                      onChange={() => handleSelectAddress(addr)}
                                      className="accent-[#C5A880] w-4 h-4 cursor-pointer"
                                    />
                                  </div>
                                  <div className="space-y-1 text-xs">
                                    <div className="flex items-center gap-2 flex-wrap">
                                      <span className="font-semibold text-sm text-[#18181D]">
                                        {addr.fullName || formData.fullName || "Your Address"}
                                      </span>
                                      {addr.isDefault && (
                                        <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 bg-[#18181D] text-white">
                                          Default
                                        </span>
                                      )}
                                    </div>
                                    <p className="text-[#2A2723] font-medium text-sm leading-relaxed">{addr.address}</p>
                                    <p className="text-[#554F47]">
                                      {addr.city}, {addr.district} {addr.postalCode && `• ${addr.postalCode}`}
                                    </p>
                                    <div className="flex items-center gap-2 pt-1 text-[11px] text-[#7D776E]">
                                      <span>{getCountryFlag(addr.country)} {addr.country || "Sri Lanka"}</span>
                                      {addr.phone && <span>• Phone: {addr.phone}</span>}
                                    </div>
                                  </div>
                                </div>

                                {isSelected && (
                                  <span className="text-[10px] font-medium text-[#9A7B4F] uppercase tracking-wider flex items-center gap-1 shrink-0 bg-amber-50 border border-[#C5A880]/40 px-2 py-0.5">
                                    <span className="w-1.5 h-1.5 rounded-full bg-[#9A7B4F]" />
                                    Deliver Here
                                  </span>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {/* Add New Address Button */}
                      <button
                        type="button"
                        onClick={handleAddNewAddressClick}
                        className="w-full py-3.5 border-2 border-dashed border-[#E8E4DC] hover:border-[#C5A880] bg-white hover:bg-[#FAF8F5] text-xs font-medium uppercase tracking-wider text-[#18181D] transition-colors flex items-center justify-center gap-2 cursor-pointer mt-2"
                      >
                        <span className="text-base leading-none text-[#C5A880] font-bold">+</span>
                        <span>Add New Address</span>
                      </button>
                    </div>
                  ) : (
                    /* Manual Address Form */
                    <div className="space-y-4">
                      {savedAddresses.length > 0 && (
                        <div className="flex items-center justify-between pb-2 border-b border-[#E8E4DC]">
                          <span className="text-xs font-medium text-[#18181D]">Enter New Delivery Address</span>
                          <button
                            type="button"
                            onClick={handleCancelNewAddress}
                            className="text-[11px] text-[#9A7B4F] hover:text-[#7A5B2F] underline uppercase tracking-wider cursor-pointer"
                          >
                            &larr; Use saved address instead
                          </button>
                        </div>
                      )}

                      {/* 1. Destination Country - Prominent Primary Selector */}
                      <div className="p-4 bg-[#FAF8F5] border border-[#C5A880]/40 space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <label className="block text-[#18181D] font-serif tracking-wider text-xs font-semibold uppercase">
                              Destination Country *
                            </label>
                          </div>
                        </div>
                        <p className="text-[11px] text-[#8C867D] font-sans">
                          Select your destination country to automatically adapt regional address formatting and postal requirements.
                        </p>
                        {stepErrors.country && (
                          <span className="text-[11px] text-red-600 font-sans block">{stepErrors.country}</span>
                        )}
                        <LuxurySelect
                          value={formData.country}
                          onChange={(val) => {
                            const newFmt = getAddressFormat(val);
                            setFormData((prev) => ({
                              ...prev,
                              country: val,
                              state: newFmt.fields.state.options ? "" : prev.state,
                              postalCode: newFmt.hasPostalCode ? prev.postalCode : "",
                            }));
                            setStepErrors((prev) => ({
                              ...prev,
                              country: "",
                              address: "",
                              city: "",
                              state: "",
                              postalCode: "",
                            }));
                          }}
                          options={COUNTRY_OPTIONS}
                          placeholder="Select Destination Country"
                          searchable={true}
                          searchPlaceholder="Search destination country or code..."
                          variant="light"
                          triggerClassName={`!p-3 text-xs bg-white ${stepErrors.country ? "!border-red-500" : ""}`}
                        />
                      </div>

                      {/* 2. Dynamic Country-Specific Address Fields */}
                      {(() => {
                        const addressFormat = getAddressFormat(formData.country);
                        const code = addressFormat.countryCode;

                        // Case A: Japan (JP) -> Prefecture, Postal Code, City/Ward, Block/Building
                        if (code === "JP") {
                          return (
                            <div className="space-y-3">
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                <div>
                                  <div className="flex items-center justify-between mb-1">
                                    <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                                      {addressFormat.fields.state.label} *
                                    </label>
                                    {stepErrors.state && (
                                      <span className="text-[10px] text-red-600 font-sans">{stepErrors.state}</span>
                                    )}
                                  </div>
                                  <LuxurySelect
                                    value={formData.state}
                                    onChange={(val) => {
                                      setFormData({ ...formData, state: val });
                                      if (stepErrors.state) setStepErrors((prev) => ({ ...prev, state: "" }));
                                    }}
                                    options={addressFormat.fields.state.options || []}
                                    placeholder={addressFormat.fields.state.placeholder}
                                    searchable={true}
                                    searchPlaceholder="Search prefecture..."
                                    variant="light"
                                    triggerClassName={`!p-3 text-xs ${stepErrors.state ? "!border-red-500" : ""}`}
                                  />
                                </div>

                                <div>
                                  <div className="flex items-center justify-between mb-1">
                                    <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                                      {addressFormat.fields.postalCode?.label || "Postal Code"} *
                                    </label>
                                    {stepErrors.postalCode && (
                                      <span className="text-[10px] text-red-600 font-sans">{stepErrors.postalCode}</span>
                                    )}
                                  </div>
                                  <input
                                    type="text"
                                    value={formData.postalCode}
                                    onChange={(e) => {
                                      setFormData({ ...formData, postalCode: e.target.value });
                                      if (stepErrors.postalCode) setStepErrors((prev) => ({ ...prev, postalCode: "" }));
                                    }}
                                    placeholder={addressFormat.fields.postalCode?.placeholder || "e.g. 100-0001"}
                                    className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none font-mono transition-colors ${
                                      stepErrors.postalCode ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                                    }`}
                                  />
                                </div>
                              </div>

                              <div>
                                <div className="flex items-center justify-between mb-1">
                                  <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                                    {addressFormat.fields.city.label} *
                                  </label>
                                  {stepErrors.city && (
                                    <span className="text-[10px] text-red-600 font-sans">{stepErrors.city}</span>
                                  )}
                                </div>
                                <input
                                  type="text"
                                  value={formData.city}
                                  onChange={(e) => {
                                    setFormData({ ...formData, city: e.target.value });
                                    if (stepErrors.city) setStepErrors((prev) => ({ ...prev, city: "" }));
                                  }}
                                  placeholder={addressFormat.fields.city.placeholder}
                                  className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none transition-colors ${
                                    stepErrors.city ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                                  }`}
                                />
                              </div>

                              <div>
                                <div className="flex items-center justify-between mb-1">
                                  <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                                    {addressFormat.fields.addressLine1.label} *
                                  </label>
                                  {stepErrors.address && (
                                    <span className="text-[11px] text-red-600 font-sans">{stepErrors.address}</span>
                                  )}
                                </div>
                                <input
                                  type="text"
                                  value={formData.address}
                                  onChange={(e) => {
                                    setFormData({ ...formData, address: e.target.value });
                                    if (stepErrors.address) setStepErrors((prev) => ({ ...prev, address: "" }));
                                  }}
                                  placeholder={addressFormat.fields.addressLine1.placeholder}
                                  className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none transition-colors ${
                                    stepErrors.address ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                                  }`}
                                />
                              </div>
                            </div>
                          );
                        }

                        // Case B: United Arab Emirates (UAE / AE) -> Villa/Building, City, Emirate, Landmark (NO postal code!)
                        if (code === "AE") {
                          return (
                            <div className="space-y-3">
                              <div>
                                <div className="flex items-center justify-between mb-1">
                                  <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                                    {addressFormat.fields.addressLine1.label} *
                                  </label>
                                  {stepErrors.address && (
                                    <span className="text-[11px] text-red-600 font-sans">{stepErrors.address}</span>
                                  )}
                                </div>
                                <input
                                  type="text"
                                  value={formData.address}
                                  onChange={(e) => {
                                    setFormData({ ...formData, address: e.target.value });
                                    if (stepErrors.address) setStepErrors((prev) => ({ ...prev, address: "" }));
                                  }}
                                  placeholder={addressFormat.fields.addressLine1.placeholder}
                                  className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none transition-colors ${
                                    stepErrors.address ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                                  }`}
                                />
                              </div>

                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                <div>
                                  <div className="flex items-center justify-between mb-1">
                                    <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                                      {addressFormat.fields.city.label} *
                                    </label>
                                    {stepErrors.city && (
                                      <span className="text-[10px] text-red-600 font-sans">{stepErrors.city}</span>
                                    )}
                                  </div>
                                  <input
                                    type="text"
                                    value={formData.city}
                                    onChange={(e) => {
                                      setFormData({ ...formData, city: e.target.value });
                                      if (stepErrors.city) setStepErrors((prev) => ({ ...prev, city: "" }));
                                    }}
                                    placeholder={addressFormat.fields.city.placeholder}
                                    className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none transition-colors ${
                                      stepErrors.city ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                                    }`}
                                  />
                                </div>

                                <div>
                                  <div className="flex items-center justify-between mb-1">
                                    <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                                      {addressFormat.fields.state.label} *
                                    </label>
                                    {stepErrors.state && (
                                      <span className="text-[10px] text-red-600 font-sans">{stepErrors.state}</span>
                                    )}
                                  </div>
                                  <LuxurySelect
                                    value={formData.state}
                                    onChange={(val) => {
                                      setFormData({ ...formData, state: val });
                                      if (stepErrors.state) setStepErrors((prev) => ({ ...prev, state: "" }));
                                    }}
                                    options={addressFormat.fields.state.options || []}
                                    placeholder={addressFormat.fields.state.placeholder}
                                    variant="light"
                                    triggerClassName={`!p-3 text-xs ${stepErrors.state ? "!border-red-500" : ""}`}
                                  />
                                </div>
                              </div>

                              <div>
                                <label className="block text-[#554F47] uppercase tracking-wider text-[10px] mb-1">
                                  {addressFormat.fields.addressLine2?.label || "Landmark (Optional)"}
                                </label>
                                <input
                                  type="text"
                                  value={formData.addressLine2}
                                  onChange={(e) => setFormData({ ...formData, addressLine2: e.target.value })}
                                  placeholder={addressFormat.fields.addressLine2?.placeholder || "e.g. Near Mall of the Emirates, Behind Spinneys"}
                                  className="w-full p-3 bg-[#FAF8F5] border border-[#E8E4DC] focus:border-[#C5A880] focus:outline-none transition-colors"
                                />
                              </div>
                            </div>
                          );
                        }

                        // Case C: United States (US) -> Address Line 1, Address Line 2, City, State, ZIP Code
                        if (code === "US") {
                          return (
                            <div className="space-y-3">
                              <div>
                                <div className="flex items-center justify-between mb-1">
                                  <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                                    {addressFormat.fields.addressLine1.label} *
                                  </label>
                                  {stepErrors.address && (
                                    <span className="text-[11px] text-red-600 font-sans">{stepErrors.address}</span>
                                  )}
                                </div>
                                <input
                                  type="text"
                                  value={formData.address}
                                  onChange={(e) => {
                                    setFormData({ ...formData, address: e.target.value });
                                    if (stepErrors.address) setStepErrors((prev) => ({ ...prev, address: "" }));
                                  }}
                                  placeholder={addressFormat.fields.addressLine1.placeholder}
                                  className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none transition-colors ${
                                    stepErrors.address ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                                  }`}
                                />
                              </div>

                              <div>
                                <label className="block text-[#554F47] uppercase tracking-wider text-[10px] mb-1">
                                  {addressFormat.fields.addressLine2?.label || "Address Line 2 (Optional)"}
                                </label>
                                <input
                                  type="text"
                                  value={formData.addressLine2}
                                  onChange={(e) => setFormData({ ...formData, addressLine2: e.target.value })}
                                  placeholder={addressFormat.fields.addressLine2?.placeholder || "Apartment, suite, unit, building, floor, etc."}
                                  className="w-full p-3 bg-[#FAF8F5] border border-[#E8E4DC] focus:border-[#C5A880] focus:outline-none transition-colors"
                                />
                              </div>

                              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                <div>
                                  <div className="flex items-center justify-between mb-1">
                                    <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                                      {addressFormat.fields.city.label} *
                                    </label>
                                    {stepErrors.city && (
                                      <span className="text-[10px] text-red-600 font-sans">{stepErrors.city}</span>
                                    )}
                                  </div>
                                  <input
                                    type="text"
                                    value={formData.city}
                                    onChange={(e) => {
                                      setFormData({ ...formData, city: e.target.value });
                                      if (stepErrors.city) setStepErrors((prev) => ({ ...prev, city: "" }));
                                    }}
                                    placeholder={addressFormat.fields.city.placeholder}
                                    className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none transition-colors ${
                                      stepErrors.city ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                                    }`}
                                  />
                                </div>

                                <div>
                                  <div className="flex items-center justify-between mb-1">
                                    <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                                      {addressFormat.fields.state.label} *
                                    </label>
                                    {stepErrors.state && (
                                      <span className="text-[10px] text-red-600 font-sans">{stepErrors.state}</span>
                                    )}
                                  </div>
                                  <LuxurySelect
                                    value={formData.state}
                                    onChange={(val) => {
                                      setFormData({ ...formData, state: val });
                                      if (stepErrors.state) setStepErrors((prev) => ({ ...prev, state: "" }));
                                    }}
                                    options={addressFormat.fields.state.options || []}
                                    placeholder={addressFormat.fields.state.placeholder}
                                    searchable={true}
                                    searchPlaceholder="Search state..."
                                    variant="light"
                                    triggerClassName={`!p-3 text-xs ${stepErrors.state ? "!border-red-500" : ""}`}
                                  />
                                </div>

                                <div>
                                  <div className="flex items-center justify-between mb-1">
                                    <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                                      {addressFormat.fields.postalCode?.label || "ZIP Code"} *
                                    </label>
                                    {stepErrors.postalCode && (
                                      <span className="text-[10px] text-red-600 font-sans">{stepErrors.postalCode}</span>
                                    )}
                                  </div>
                                  <input
                                    type="text"
                                    value={formData.postalCode}
                                    onChange={(e) => {
                                      setFormData({ ...formData, postalCode: e.target.value });
                                      if (stepErrors.postalCode) setStepErrors((prev) => ({ ...prev, postalCode: "" }));
                                    }}
                                    placeholder={addressFormat.fields.postalCode?.placeholder || "e.g. 10001"}
                                    className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none font-mono transition-colors ${
                                      stepErrors.postalCode ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                                    }`}
                                  />
                                </div>
                              </div>
                            </div>
                          );
                        }

                        // Case D: United Kingdom (GB) -> Address Line 1, Address Line 2, Town/City, County, Postcode
                        if (code === "GB") {
                          return (
                            <div className="space-y-3">
                              <div>
                                <div className="flex items-center justify-between mb-1">
                                  <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                                    {addressFormat.fields.addressLine1.label} *
                                  </label>
                                  {stepErrors.address && (
                                    <span className="text-[11px] text-red-600 font-sans">{stepErrors.address}</span>
                                  )}
                                </div>
                                <input
                                  type="text"
                                  value={formData.address}
                                  onChange={(e) => {
                                    setFormData({ ...formData, address: e.target.value });
                                    if (stepErrors.address) setStepErrors((prev) => ({ ...prev, address: "" }));
                                  }}
                                  placeholder={addressFormat.fields.addressLine1.placeholder}
                                  className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none transition-colors ${
                                    stepErrors.address ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                                  }`}
                                />
                              </div>

                              <div>
                                <label className="block text-[#554F47] uppercase tracking-wider text-[10px] mb-1">
                                  {addressFormat.fields.addressLine2?.label || "Address Line 2 (Optional)"}
                                </label>
                                <input
                                  type="text"
                                  value={formData.addressLine2}
                                  onChange={(e) => setFormData({ ...formData, addressLine2: e.target.value })}
                                  placeholder={addressFormat.fields.addressLine2?.placeholder || "Flat, suite, unit, etc."}
                                  className="w-full p-3 bg-[#FAF8F5] border border-[#E8E4DC] focus:border-[#C5A880] focus:outline-none transition-colors"
                                />
                              </div>

                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                <div>
                                  <div className="flex items-center justify-between mb-1">
                                    <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                                      {addressFormat.fields.city.label} *
                                    </label>
                                    {stepErrors.city && (
                                      <span className="text-[10px] text-red-600 font-sans">{stepErrors.city}</span>
                                    )}
                                  </div>
                                  <input
                                    type="text"
                                    value={formData.city}
                                    onChange={(e) => {
                                      setFormData({ ...formData, city: e.target.value });
                                      if (stepErrors.city) setStepErrors((prev) => ({ ...prev, city: "" }));
                                    }}
                                    placeholder={addressFormat.fields.city.placeholder}
                                    className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none transition-colors ${
                                      stepErrors.city ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                                    }`}
                                  />
                                </div>

                                <div>
                                  <label className="block text-[#554F47] uppercase tracking-wider text-[10px] mb-1">
                                    {addressFormat.fields.state.label}
                                  </label>
                                  <input
                                    type="text"
                                    value={formData.state}
                                    onChange={(e) => {
                                      setFormData({ ...formData, state: e.target.value });
                                      if (stepErrors.state) setStepErrors((prev) => ({ ...prev, state: "" }));
                                    }}
                                    placeholder={addressFormat.fields.state.placeholder}
                                    className="w-full p-3 bg-[#FAF8F5] border border-[#E8E4DC] focus:border-[#C5A880] focus:outline-none transition-colors"
                                  />
                                </div>
                              </div>

                              <div>
                                <div className="flex items-center justify-between mb-1">
                                  <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                                    {addressFormat.fields.postalCode?.label || "Postcode"} *
                                  </label>
                                  {stepErrors.postalCode && (
                                    <span className="text-[10px] text-red-600 font-sans">{stepErrors.postalCode}</span>
                                  )}
                                </div>
                                <input
                                  type="text"
                                  value={formData.postalCode}
                                  onChange={(e) => {
                                    setFormData({ ...formData, postalCode: e.target.value });
                                    if (stepErrors.postalCode) setStepErrors((prev) => ({ ...prev, postalCode: "" }));
                                  }}
                                  placeholder={addressFormat.fields.postalCode?.placeholder || "e.g. SW1A 1AA"}
                                  className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none font-mono transition-colors ${
                                    stepErrors.postalCode ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                                  }`}
                                />
                              </div>
                            </div>
                          );
                        }

                        // Case E: Worldwide / Canada / Australia / Sri Lanka / Rest of World
                        return (
                          <div className="space-y-3">
                            <div>
                              <div className="flex items-center justify-between mb-1">
                                <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                                  {addressFormat.fields.addressLine1.label} *
                                </label>
                                {stepErrors.address && (
                                  <span className="text-[11px] text-red-600 font-sans">{stepErrors.address}</span>
                                )}
                              </div>
                              <input
                                type="text"
                                value={formData.address}
                                onChange={(e) => {
                                  setFormData({ ...formData, address: e.target.value });
                                  if (stepErrors.address) setStepErrors((prev) => ({ ...prev, address: "" }));
                                }}
                                placeholder={addressFormat.fields.addressLine1.placeholder}
                                className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none transition-colors ${
                                  stepErrors.address ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                                }`}
                              />
                            </div>

                            <div>
                              <label className="block text-[#554F47] uppercase tracking-wider text-[10px] mb-1">
                                {addressFormat.fields.addressLine2?.label || "Address Line 2 (Optional)"}
                              </label>
                              <input
                                type="text"
                                value={formData.addressLine2}
                                onChange={(e) => setFormData({ ...formData, addressLine2: e.target.value })}
                                placeholder={addressFormat.fields.addressLine2?.placeholder || "Apartment, suite, unit, floor (optional)"}
                                className="w-full p-3 bg-[#FAF8F5] border border-[#E8E4DC] focus:border-[#C5A880] focus:outline-none transition-colors"
                              />
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                              <div>
                                <div className="flex items-center justify-between mb-1">
                                  <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                                    {addressFormat.fields.city.label} *
                                  </label>
                                  {stepErrors.city && (
                                    <span className="text-[10px] text-red-600 font-sans">{stepErrors.city}</span>
                                  )}
                                </div>
                                <input
                                  type="text"
                                  value={formData.city}
                                  onChange={(e) => {
                                    setFormData({ ...formData, city: e.target.value });
                                    if (stepErrors.city) setStepErrors((prev) => ({ ...prev, city: "" }));
                                  }}
                                  placeholder={addressFormat.fields.city.placeholder}
                                  className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none transition-colors ${
                                    stepErrors.city ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                                  }`}
                                />
                              </div>

                              <div>
                                <div className="flex items-center justify-between mb-1">
                                  <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                                    {addressFormat.fields.state.label} {addressFormat.fields.state.required ? "*" : ""}
                                  </label>
                                  {stepErrors.state && (
                                    <span className="text-[10px] text-red-600 font-sans block">{stepErrors.state}</span>
                                  )}
                                </div>
                                {addressFormat.fields.state.options ? (
                                  <LuxurySelect
                                    value={formData.state}
                                    onChange={(val) => {
                                      setFormData({ ...formData, state: val });
                                      if (stepErrors.state) setStepErrors((prev) => ({ ...prev, state: "" }));
                                    }}
                                    options={addressFormat.fields.state.options}
                                    placeholder={addressFormat.fields.state.placeholder}
                                    searchable={true}
                                    searchPlaceholder="Search state / province..."
                                    variant="light"
                                    triggerClassName={`!p-3 text-xs ${stepErrors.state ? "!border-red-500" : ""}`}
                                  />
                                ) : (
                                  <input
                                    type="text"
                                    value={formData.state}
                                    onChange={(e) => {
                                      setFormData({ ...formData, state: e.target.value });
                                      if (stepErrors.state) setStepErrors((prev) => ({ ...prev, state: "" }));
                                    }}
                                    placeholder={addressFormat.fields.state.placeholder}
                                    className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none transition-colors ${
                                      stepErrors.state ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                                    }`}
                                  />
                                )}
                              </div>
                            </div>

                            {addressFormat.hasPostalCode && addressFormat.fields.postalCode && (
                              <div>
                                <div className="flex items-center justify-between mb-1">
                                  <label className="block text-[#554F47] uppercase tracking-wider text-[10px]">
                                    {addressFormat.fields.postalCode.label} *
                                  </label>
                                  {stepErrors.postalCode && (
                                    <span className="text-[10px] text-red-600 font-sans block">{stepErrors.postalCode}</span>
                                  )}
                                </div>
                                <input
                                  type="text"
                                  value={formData.postalCode}
                                  onChange={(e) => {
                                    setFormData({ ...formData, postalCode: e.target.value });
                                    if (stepErrors.postalCode) setStepErrors((prev) => ({ ...prev, postalCode: "" }));
                                  }}
                                  placeholder={addressFormat.fields.postalCode.placeholder}
                                  className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none font-mono transition-colors ${
                                    stepErrors.postalCode ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                                  }`}
                                />
                              </div>
                            )}
                          </div>
                        );
                      })()}
                    </div>
                  )}

                </div>

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="px-6 py-4 border border-[#E8E4DC] text-xs uppercase font-sans hover:bg-[#FAF8F5]"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-4 bg-[#18181D] hover:bg-[#2A2A32] text-white text-xs uppercase tracking-luxury font-sans font-medium transition-colors"
                  >
                    Continue to Payment &rarr;
                  </button>
                </div>
              </form>
            )}

            {/* STEP 3: Payment Method */}
            {step === 3 && (
              <form onSubmit={handleNextStep} className="space-y-6">
                <div>
                  <h2 className="font-serif text-2xl text-[#18181D]">3. Payment Method</h2>
                  <p className="text-xs text-[#8C867D] font-sans mt-1">
                    All payments are safe and encrypted.
                  </p>
                </div>

                <div className="space-y-4 text-xs font-sans">
                  {/* Official Payment Method Banner */}
                  <div className="p-4 border border-[#C5A880] bg-[#FAF8F5] rounded-sm shadow-xs select-none">
                    <div className="flex items-start gap-3">
                      {/* Precision Indicator */}
                      <div className="pt-0.5 shrink-0">
                        <div className="w-4 h-4 rounded-full border border-[#C5A880] bg-[#C5A880] flex items-center justify-center">
                          <div className="w-1.5 h-1.5 rounded-full bg-white" />
                        </div>
                      </div>

                      {/* Text & Badge Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center justify-between gap-1.5">
                          <span className="font-serif text-sm font-semibold text-[#18181D]">
                            Direct Bank Transfer / Wire Deposit
                          </span>
                          <span className="text-[10px] font-mono uppercase tracking-wider text-[#9A7B4F] bg-white px-2 py-0.5 border border-[#E3DEC3] rounded-xs shrink-0 font-medium shadow-2xs">
                            {bankShortName}
                          </span>
                        </div>
                        <p className="text-[#787167] text-[11px] leading-relaxed mt-1.5">
                          Direct wire transfer to our verified treasury bank account. Bank account coordinates and transfer slip upload are provided below.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Bank Transfer Account Details & Reference Number */}
                  <div className="p-4 sm:p-6 bg-white border border-[#C5A880]/50 shadow-sm space-y-6 animate-in fade-in duration-200">
                        {/* Step 1 Clarity Notice Banner */}
                        <div className="p-3.5 bg-[#FAF8F5] border-l-4 border-[#C5A880] border border-[#E8E4DC] rounded-sm text-xs text-[#554F47] space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="w-5 h-5 rounded-full bg-[#C5A880] text-[#18181D] font-mono text-[10px] font-bold flex items-center justify-center shrink-0">
                              1
                            </span>
                            <span className="font-semibold text-[#18181D] text-xs uppercase tracking-wider">
                              Step 1: Transfer Payment to Our Official Account
                            </span>
                          </div>
                          <p className="text-[11px] text-[#6E685F] pl-7 leading-relaxed">
                            These are <strong>Faizan Gems&apos; receiving bank details</strong>. You do <strong>not</strong> need to type your personal bank details here. Simply transfer your order total using your mobile banking app or bank counter, then enter your proof in Step 2.
                          </p>
                        </div>

                        {/* Official Beneficiary Bank Pass Card (Distinct Luxury Obsidian Card - Impossible to mistake for form inputs) */}
                        <div className="bg-gradient-to-br from-[#18181D] via-[#201F26] to-[#16161B] text-white rounded-lg p-4 sm:p-5 border border-[#C5A880]/40 shadow-lg relative overflow-hidden space-y-4">
                          {/* Ambient Gold Glow */}
                          <div className="absolute top-0 right-0 w-64 h-64 bg-[#C5A880]/10 rounded-full blur-3xl pointer-events-none -mr-16 -mt-16" />

                          {/* Card Header */}
                          <div className="flex flex-wrap items-center justify-between border-b border-white/10 pb-3 gap-3 relative z-10">
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[9px] font-mono uppercase tracking-widest bg-[#C5A880]/20 text-[#DFC9A9] border border-[#C5A880]/30 font-semibold">
                                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                                  Official Beneficiary Account
                                </span>
                                <span className="text-[10px] text-white/50 font-mono">
                                  (Pay To This Account)
                                </span>
                              </div>
                              <h4 className="font-serif text-sm sm:text-base font-medium text-white">
                                Faizan Gems Bank Transfer Details
                              </h4>
                            </div>

                            {/* Bank Badge */}
                            <div className="flex items-center gap-2 bg-white px-2.5 py-1 rounded shadow-sm shrink-0">
                              {bankLogo && (
                                <div className="relative h-5 w-10 flex-shrink-0">
                                  <Image
                                    src={bankLogo}
                                    alt={bankName}
                                    fill
                                    className="object-contain"
                                    unoptimized
                                  />
                                </div>
                              )}
                              <span className="text-[10px] uppercase tracking-wider font-mono text-[#18181D] font-bold border-l border-gray-200 pl-2">
                                {bankShortName}
                              </span>
                            </div>
                          </div>

                          {/* Copy Helper & Quick Copy All */}
                          <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-[#A69E92] relative z-10">
                            <span>Use the details below to complete your transfer:</span>
                            <button
                              type="button"
                              onClick={handleCopyAllBankDetails}
                              className="text-[10px] font-mono uppercase tracking-wider px-2.5 py-1 bg-white/10 hover:bg-white/20 text-[#DFC9A9] hover:text-white rounded border border-white/15 transition-all flex items-center gap-1.5 active:scale-95 cursor-pointer"
                            >
                              {copiedKey === "all" ? (
                                <>
                                  <CheckIcon className="w-3.5 h-3.5 text-emerald-400" />
                                  <span className="text-emerald-300 font-bold">All Details Copied!</span>
                                </>
                              ) : (
                                <>
                                  <CopyIcon className="w-3.5 h-3.5 text-[#C5A880]" />
                                  <span>Copy All Details</span>
                                </>
                              )}
                            </button>
                          </div>

                          {/* Detail Rows in Specified Order: Bank Name, Branch, Account name, Account number */}
                          <div className="space-y-2 relative z-10">
                            {/* Bank Name */}
                            <div className="p-3 bg-white/[0.04] hover:bg-white/[0.07] border border-white/10 rounded flex items-center justify-between gap-3 transition-colors">
                              <div className="min-w-0">
                                <span className="text-[9px] uppercase font-mono tracking-widest text-[#A69E92] block">
                                  Bank Name
                                </span>
                                <span className="text-xs sm:text-sm font-medium text-white block select-all truncate">
                                  {bankName}
                                </span>
                              </div>
                              <button
                                type="button"
                                onClick={() => handleCopyText(bankName, "bankName")}
                                className="px-2.5 py-1 text-[10px] font-mono rounded bg-white/10 hover:bg-white/20 text-[#DFC9A9] hover:text-white flex items-center gap-1 shrink-0 transition-all active:scale-95 cursor-pointer"
                                title="Copy Bank Name"
                              >
                                {copiedKey === "bankName" ? (
                                  <>
                                    <CheckIcon className="w-3 h-3 text-emerald-400" />
                                    <span className="text-emerald-300">Copied</span>
                                  </>
                                ) : (
                                  <>
                                    <CopyIcon className="w-3 h-3 text-[#C5A880]" />
                                    <span>Copy</span>
                                  </>
                                )}
                              </button>
                            </div>

                            {/* Branch */}
                            <div className="p-3 bg-white/[0.04] hover:bg-white/[0.07] border border-white/10 rounded flex items-center justify-between gap-3 transition-colors">
                              <div className="min-w-0">
                                <span className="text-[9px] uppercase font-mono tracking-widest text-[#A69E92] block">
                                  Branch
                                </span>
                                <span className="text-xs sm:text-sm font-medium text-white block select-all truncate">
                                  {branchName}
                                </span>
                              </div>
                              <button
                                type="button"
                                onClick={() => handleCopyText(branchName, "branch")}
                                className="px-2.5 py-1 text-[10px] font-mono rounded bg-white/10 hover:bg-white/20 text-[#DFC9A9] hover:text-white flex items-center gap-1 shrink-0 transition-all active:scale-95 cursor-pointer"
                                title="Copy Branch"
                              >
                                {copiedKey === "branch" ? (
                                  <>
                                    <CheckIcon className="w-3 h-3 text-emerald-400" />
                                    <span className="text-emerald-300">Copied</span>
                                  </>
                                ) : (
                                  <>
                                    <CopyIcon className="w-3 h-3 text-[#C5A880]" />
                                    <span>Copy</span>
                                  </>
                                )}
                              </button>
                            </div>

                            {/* Account Name */}
                            <div className="p-3 bg-white/[0.04] hover:bg-white/[0.07] border border-white/10 rounded flex items-center justify-between gap-3 transition-colors">
                              <div className="min-w-0">
                                <span className="text-[9px] uppercase font-mono tracking-widest text-[#A69E92] block">
                                  Account Name
                                </span>
                                <span className="text-xs sm:text-sm font-medium text-white block select-all truncate">
                                  {accountName}
                                </span>
                              </div>
                              <button
                                type="button"
                                onClick={() => handleCopyText(accountName, "accountName")}
                                className="px-2.5 py-1 text-[10px] font-mono rounded bg-white/10 hover:bg-white/20 text-[#DFC9A9] hover:text-white flex items-center gap-1 shrink-0 transition-all active:scale-95 cursor-pointer"
                                title="Copy Account Name"
                              >
                                {copiedKey === "accountName" ? (
                                  <>
                                    <CheckIcon className="w-3 h-3 text-emerald-400" />
                                    <span className="text-emerald-300">Copied</span>
                                  </>
                                ) : (
                                  <>
                                    <CopyIcon className="w-3 h-3 text-[#C5A880]" />
                                    <span>Copy</span>
                                  </>
                                )}
                              </button>
                            </div>

                            {/* Account Number with Prominent High-Contrast Copy Box */}
                            <div className="p-3.5 bg-gradient-to-r from-[#C5A880]/20 via-[#C5A880]/10 to-transparent border border-[#C5A880]/40 rounded flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                              <div>
                                <span className="text-[9px] uppercase font-mono tracking-widest text-[#DFC9A9] block font-semibold">
                                  Account Number
                                </span>
                                <span className="font-mono text-base sm:text-lg font-bold text-white tracking-widest select-all">
                                  {formattedAccountNumber}
                                </span>
                              </div>

                              <button
                                type="button"
                                onClick={() => handleCopyText(rawAccountNumber, "accountNumber")}
                                className="px-4 py-2 bg-[#C5A880] hover:bg-[#B3956D] text-[#18181D] font-medium text-xs font-sans rounded flex items-center justify-center gap-2 transition-all active:scale-95 shrink-0 shadow-sm cursor-pointer"
                              >
                                {copiedKey === "accountNumber" ? (
                                  <>
                                    <CheckIcon className="w-4 h-4 text-[#18181D]" />
                                    <span className="font-bold">Copied!</span>
                                  </>
                                ) : (
                                  <>
                                    <CopyIcon className="w-4 h-4 text-[#18181D]" />
                                    <span className="font-semibold">Copy Account Number</span>
                                  </>
                                )}
                              </button>
                            </div>
                          </div>
                        </div>

                        {/* Step 2 Divider & Header */}
                        <div className="pt-3 border-t border-[#F2EFE9] space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="w-5 h-5 rounded-full bg-[#18181D] text-white font-mono text-[10px] font-bold flex items-center justify-center shrink-0">
                              2
                            </span>
                            <span className="font-semibold text-[#18181D] text-xs uppercase tracking-wider">
                              Step 2: Enter Your Payment Proof
                            </span>
                          </div>
                          <p className="text-[11px] text-[#8C867D] pl-7">
                            After transferring to the account above, enter your transaction reference number and attach your bank slip below.
                          </p>
                        </div>

                        {/* Reference Number Field */}
                        <div className="pt-2 border-t border-[#F2EFE9] space-y-1.5">
                          <div className="flex items-center justify-between">
                            <label className="block text-[#554F47] uppercase tracking-wider text-[10px] font-medium">
                              Reference Number *
                            </label>
                            {stepErrors.bankReference && (
                              <span className="text-[11px] text-red-600 font-sans">{stepErrors.bankReference}</span>
                            )}
                          </div>
                          <input
                            type="text"
                            value={formData.bankReference}
                            onChange={(e) => {
                              setFormData({ ...formData, bankReference: e.target.value });
                              if (stepErrors.bankReference) setStepErrors((prev) => ({ ...prev, bankReference: "" }));
                            }}
                            placeholder="Enter bank transfer reference / slip number"
                            className={`w-full p-3 bg-[#FAF8F5] border focus:outline-none font-mono text-xs placeholder:text-[#AAA49A] transition-colors ${
                              stepErrors.bankReference ? "border-red-500 focus:border-red-600" : "border-[#E8E4DC] focus:border-[#C5A880]"
                            }`}
                          />
                          <p className="text-[11px] text-[#8C867D] leading-relaxed">
                            Please provide the transaction reference number from your bank or mobile transfer receipt for swift audit and vault dispatch.
                          </p>
                        </div>

                        {/* Upload Transfer Slip */}
                        <div className="pt-2 border-t border-[#F2EFE9] space-y-2">
                          <div className="flex items-center justify-between">
                            <label className="block text-[#554F47] uppercase tracking-wider text-[10px] font-medium">
                              Upload Transfer Slip *
                            </label>
                            {formData.paymentSlipUrl && (
                              <span className="text-[10px] font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded flex items-center gap-1">
                                <CheckIcon className="w-3 h-3 text-emerald-600" />
                                Slip Attached
                              </span>
                            )}
                          </div>

                          <input
                            ref={slipFileInputRef}
                            type="file"
                            accept="image/jpeg,image/png,image/webp,image/avif,application/pdf"
                            className="hidden"
                            onChange={(e) => {
                              if (e.target.files && e.target.files.length > 0) {
                                handleSlipUpload(e.target.files[0]);
                                e.target.value = "";
                              }
                            }}
                          />

                          {!formData.paymentSlipUrl ? (
                            <div
                              onClick={() => slipFileInputRef.current?.click()}
                              onDragOver={(e) => e.preventDefault()}
                              onDrop={(e) => {
                                e.preventDefault();
                                if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                                  handleSlipUpload(e.dataTransfer.files[0]);
                                }
                              }}
                              className={`border-2 border-dashed rounded-sm p-4 text-center cursor-pointer transition-all group ${
                                stepErrors.paymentSlip
                                  ? "border-red-400 bg-red-50/40 hover:bg-red-50/60"
                                  : "border-[#E8E4DC] hover:border-[#C5A880] bg-[#FAF8F5]/80 hover:bg-[#FAF8F5]"
                              }`}
                            >
                              {isUploadingSlip ? (
                                <div className="space-y-1.5 py-2">
                                  <div className="w-5 h-5 border-2 border-[#C5A880] border-t-transparent rounded-full animate-spin mx-auto" />
                                  <p className="text-xs text-[#9A7B4F] font-mono">Uploading payment slip...</p>
                                </div>
                              ) : (
                                <div className="space-y-1.5 py-1">
                                  <div className="w-9 h-9 rounded-full bg-white border border-[#E8E4DC] flex items-center justify-center mx-auto text-[#9A7B4F] group-hover:scale-105 group-hover:border-[#C5A880] transition-all">
                                    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round">
                                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                                      <polyline points="17 8 12 3 7 8" />
                                      <line x1="12" y1="3" x2="12" y2="15" />
                                    </svg>
                                  </div>
                                  <div>
                                    <span className="text-xs font-medium text-[#18181D] group-hover:text-[#9A7B4F] transition-colors block">
                                      Click or drag transfer slip to upload
                                    </span>
                                    <span className="text-[10px] text-[#8C867D] font-mono block mt-0.5">
                                      JPG, PNG, WEBP or PDF (Up to 25MB)
                                    </span>
                                  </div>
                                </div>
                              )}
                            </div>
                          ) : (
                            <div className="p-3 bg-[#FAF8F5] border border-[#C5A880]/50 rounded-sm flex items-center justify-between gap-3">
                              <div className="flex items-center gap-3 min-w-0">
                                <div className="w-10 h-10 rounded bg-white border border-[#E8E4DC] flex items-center justify-center text-[#9A7B4F] shrink-0 overflow-hidden">
                                  {formData.paymentSlipUrl.endsWith(".pdf") ? (
                                    <span className="font-mono text-[10px] font-bold text-red-700 uppercase">PDF</span>
                                  ) : (
                                    <div className="relative w-full h-full">
                                      <Image
                                        src={formData.paymentSlipUrl}
                                        alt="Transfer Slip"
                                        fill
                                        unoptimized
                                        className="object-cover"
                                      />
                                    </div>
                                  )}
                                </div>
                                <div className="min-w-0">
                                  <span className="font-medium text-[#18181D] text-xs block truncate">
                                    {formData.paymentSlipName || "Bank-Transfer-Slip"}
                                  </span>
                                  <span className="text-[10px] text-emerald-700 font-mono block">
                                    ✓ Slip Attached
                                  </span>
                                </div>
                              </div>

                              <div className="flex items-center gap-2 shrink-0">
                                <a
                                  href={formData.paymentSlipUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="px-2.5 py-1 text-[11px] font-medium text-[#9A7B4F] hover:text-[#18181D] bg-white border border-[#E8E4DC] hover:border-[#C5A880] transition-colors"
                                >
                                  View
                                </a>
                                <button
                                  type="button"
                                  onClick={() => slipFileInputRef.current?.click()}
                                  className="px-2.5 py-1 text-[11px] font-medium text-[#554F47] hover:text-[#18181D] bg-white border border-[#E8E4DC] transition-colors"
                                >
                                  Replace
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setFormData({ ...formData, paymentSlipUrl: "", paymentSlipName: "" })}
                                  className="p-1 text-[#8C867D] hover:text-red-600 transition-colors"
                                  title="Remove slip"
                                >
                                  <CloseIcon className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                          )}
                          {stepErrors.paymentSlip && (
                            <p className="text-[11px] text-red-600 font-sans mt-1">{stepErrors.paymentSlip}</p>
                          )}
                          {slipUploadError && (
                            <p className="text-[11px] text-red-600 font-sans">{slipUploadError}</p>
                          )}
                        </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="px-6 py-4 border border-[#E8E4DC] text-xs uppercase font-sans hover:bg-[#FAF8F5]"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-4 bg-[#18181D] hover:bg-[#2A2A32] text-white text-xs uppercase tracking-luxury font-sans font-medium transition-colors"
                  >
                    Review Your Order &rarr;
                  </button>
                </div>
              </form>
            )}

            {/* STEP 4: Review & Final Confirmation */}
            {step === 4 && (
              <div className="space-y-6">
                <div>
                  <h2 className="font-serif text-2xl text-[#18181D]">4. Review Your Order</h2>
                  <p className="text-xs text-[#8C867D] font-sans mt-1">
                    Please confirm your delivery address and payment method before placing your order.
                  </p>
                </div>

                {orderError && (
                  <div className="p-4 bg-red-50 border-l-4 border-red-500 border border-red-200 text-red-800 text-xs rounded-xs space-y-1 animate-in fade-in">
                    <div className="font-semibold flex items-center gap-2">
                      <span className="w-4 h-4 rounded-full bg-red-200 text-red-800 flex items-center justify-center font-bold text-[11px]">!</span>
                      <span>Order Placement Notice</span>
                    </div>
                    <p className="text-[11px] leading-relaxed pl-6">{orderError}</p>
                  </div>
                )}

                {hasOutOfStock && (
                  <div className="p-4 bg-amber-50 border-l-4 border-amber-500 border border-amber-200 text-amber-900 text-xs rounded-xs space-y-1 animate-in fade-in">
                    <div className="font-semibold flex items-center gap-2">
                      <span className="w-4 h-4 rounded-full bg-amber-200 text-amber-800 flex items-center justify-center font-bold text-[11px]">!</span>
                      <span>Vault Stock Depleted</span>
                    </div>
                    <p className="text-[11px] leading-relaxed pl-6">
                      One or more items in your order ({outOfStockItems.map((i) => `"${i.gemstone.name}"`).join(", ")}) are out of stock or have insufficient vault reserves. Please return to your shopping bag to update your selection.
                    </p>
                  </div>
                )}

                <div className="space-y-4 text-xs font-sans">
                  <div className="p-4 bg-[#FAF8F5] border border-[#E8E4DC] space-y-2">
                    <span className="text-[#8C867D] uppercase tracking-wider text-[10px] block font-medium">
                      Delivery Address:
                    </span>
                    <p className="font-medium text-[#18181D]">{formData.fullName}</p>
                    <p className="text-[#554F47]">
                      {[
                        formatFullStreetAddress(formData.address, formData.addressLine2),
                        formData.city,
                        formData.state,
                        requiresPostalCode(formData.country) ? formData.postalCode : null,
                        formData.country,
                      ]
                        .filter(Boolean)
                        .join(", ")}
                    </p>
                    <p className="text-[#8C867D]">Phone: {formData.phone} • Email: {formData.email}</p>
                  </div>

                  <div className="p-4 bg-[#FAF8F5] border border-[#E8E4DC] space-y-1">
                    <span className="text-[#8C867D] uppercase tracking-wider text-[10px] block font-medium">
                      Shipping:
                    </span>
                    <p className="font-medium text-[#18181D]">Delivery (Free)</p>
                  </div>

                  <div className="p-4 bg-[#FAF8F5] border border-[#E8E4DC] space-y-1">
                    <span className="text-[#8C867D] uppercase tracking-wider text-[10px] block font-medium">
                      Payment Method:
                    </span>
                    <p className="font-medium text-[#18181D]">
                      Bank Transfer
                    </p>
                    {formData.bankReference && (
                      <p className="text-xs text-[#8C867D] font-mono mt-1">
                        Reference Number: <span className="text-[#18181D] font-semibold">{formData.bankReference}</span>
                      </p>
                    )}
                    {formData.paymentSlipUrl && (
                      <p className="text-xs text-emerald-700 font-mono mt-1 flex items-center gap-1.5">
                        <CheckIcon className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Transfer Slip Attached</span>
                        <a
                          href={formData.paymentSlipUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[#9A7B4F] underline ml-1 text-[11px]"
                        >
                          (View Slip)
                        </a>
                      </p>
                    )}
                  </div>
                </div>

                <div className="pt-2 flex gap-3">
                  <button
                    type="button"
                    onClick={() => setStep(3)}
                    className="px-6 py-4 border border-[#E8E4DC] text-xs uppercase font-sans hover:bg-[#FAF8F5]"
                  >
                    Back
                  </button>
                  <button
                    onClick={handlePlaceOrder}
                    disabled={isProcessing || hasOutOfStock}
                    className={`flex-1 py-4 text-xs uppercase tracking-luxury font-sans font-medium transition-all shadow-xl active:scale-[0.99] ${
                      hasOutOfStock
                        ? "bg-stone-300 text-stone-500 cursor-not-allowed opacity-80"
                        : isProcessing
                        ? "bg-[#C5A880]/70 text-[#0D0D11] cursor-wait"
                        : "bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11]"
                    }`}
                  >
                    {isProcessing
                      ? "Placing Order..."
                      : hasOutOfStock
                      ? "Item Out of Stock"
                      : `Place Order (${formatPrice(grandTotal)})`}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Order Summary Sidebar (5 Cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white border border-[#E8E4DC] p-6 shadow-sm space-y-5">
              <h3 className="font-serif text-lg text-[#18181D] border-b border-[#F2EFE9] pb-3">
                Your Order ({items.length} {items.length === 1 ? "Item" : "Items"})
              </h3>

              <div className="space-y-4 max-h-72 overflow-y-auto no-scrollbar pr-1">
                {items.map((item) => {
                  const itemKey = `${item.gemstone.id}-${item.selectedVariant?.id || "default"}`;
                  const itemWeight = item.selectedWeight ?? item.gemstone.carat;
                  const itemPrice = item.selectedPrice ?? item.gemstone.price;
                  const quantity = item.quantity ?? 1;
                  const isItemOutOfStock = outOfStockItems.some(
                    (oos) =>
                      oos.gemstone.id === item.gemstone.id &&
                      (oos.selectedVariant?.id || "default") === (item.selectedVariant?.id || "default")
                  );
                  return (
                    <div key={itemKey} className="flex items-center gap-3 text-xs font-sans">
                      <div className="relative w-14 h-14 bg-[#F7F5F1] border border-[#E8E4DC] flex-shrink-0 overflow-hidden">
                        <Image
                          src={item.gemstone.images?.[0] || (item.gemstone as any).imageUrl || "/uploads/gemstones/gem-1789652077476-hwzsqu.webp"}
                          alt={item.gemstone.name}
                          fill
                          unoptimized={Boolean((item.gemstone.images?.[0] || (item.gemstone as any).imageUrl)?.startsWith("/uploads"))}
                          className="object-cover"
                        />
                        {isItemOutOfStock && (
                          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                            <span className="text-[8px] font-mono text-white uppercase font-bold tracking-widest">
                              Sold Out
                            </span>
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-1">
                          <span className="font-serif text-sm text-[#18181D] block truncate">{item.gemstone.name}</span>
                          {isItemOutOfStock && (
                            <span className="shrink-0 text-[9px] font-mono uppercase tracking-wider text-red-700 bg-red-50 border border-red-200 px-1.5 py-0.5 rounded-xs font-semibold">
                              Sold Out
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] text-[#8C867D] block">
                          {itemWeight.toFixed(2)} ct • {item.gemstone.cut} {item.selectedSize ? `• ${item.selectedSize}` : ""}
                        </span>
                        <div className="flex items-center justify-between mt-0.5">
                          <LuxuryPrice amount={itemPrice * quantity} size="sm" />
                          {quantity > 1 && (
                            <span className="text-[10px] text-[#8C867D] font-mono">Qty: {quantity}</span>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="pt-4 border-t border-[#F2EFE9] space-y-2 text-xs font-sans">
                <div className="flex items-center justify-between text-[#554F47]">
                  <span>Subtotal</span>
                  <LuxuryPrice amount={subtotal} size="sm" weight="medium" />
                </div>

                <div className="flex items-center justify-between text-[#554F47]">
                  <span>Insured Delivery</span>
                  <span className="text-emerald-800 uppercase text-[10px] font-medium">Free</span>
                </div>


                <div className="pt-3 border-t border-[#E8E4DC] flex items-baseline justify-between">
                  <span className="font-serif text-base text-[#18181D]">Total</span>
                  <LuxuryPrice amount={grandTotal} size="xl" weight="bold" />
                </div>
              </div>
            </div>

            {/* Guarantee badge */}
            <div className="p-4 bg-[#FAF8F5] border border-[#E8E4DC] text-xs font-sans text-[#554F47] space-y-2">
              <div className="flex items-center gap-2 text-[#9A7B4F] font-medium">
                <SecurityLockIcon className="w-4 h-4" />
                <span className="uppercase tracking-wider text-[11px]">30-Day Money-Back Guarantee</span>
              </div>
              <p className="text-[11px] text-[#8C867D] leading-relaxed">
                If you are not completely satisfied with your gemstone, you can return it within 30 days for a 100% full refund.
              </p>
            </div>
          </div>
        </div>

        {/* Minimal Distraction-Free Checkout Footer */}
        <footer className="mt-14 pt-8 border-t border-[#E8E4DC] text-center text-xs text-[#8C867D] space-y-3 font-sans">
          <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[11px]">
            <Link href="/shipping-returns" target="_blank" className="hover:text-[#18181D] transition-colors">
              Delivery & Returns Policy
            </Link>
            <span className="text-[#D3CECE]">•</span>
            <Link href="/faq" target="_blank" className="hover:text-[#18181D] transition-colors">
              Client FAQ
            </Link>
            <span className="text-[#D3CECE]">•</span>
            <Link href="/contact" target="_blank" className="hover:text-[#18181D] transition-colors">
              Concierge Contact
            </Link>
          </div>
          <p className="text-[10px] text-[#8C867D] font-mono">
            © {new Date().getFullYear()} Faizan Gems (Pvt) Ltd. All rights reserved. • Trincomalee Showroom
          </p>
        </footer>
      </div>
    </div>
  );
}

