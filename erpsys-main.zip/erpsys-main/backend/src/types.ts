export interface Country {
  id: string;
  code: string;
  name: string;
  isActive: boolean;
  createdAt: string;
}

export interface Currency {
  id: string;
  code: string;
  symbol: string;
  name: string;
  isActive: boolean;
  createdAt: string;
}

export interface PhoneCode {
  id: string;
  code: string;
  name: string;
  isActive: boolean;
  createdAt: string;
}

export interface Business {
  id: string;
  name: string;
  industry: string;
  phone: string;
  phoneCodeId: string;
  phoneCode?: PhoneCode;
  countryId: string;
  country?: Country;
  currencyId: string;
  currency?: Currency;
  createdAt: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'manager' | 'cashier' | 'employee' | 'super-admin';
  businessId?: string;
  business?: Business;
  branches?: any[];
  branchIds?: string[];
  phone?: string;
  isActive?: boolean;
  avatar?: string;
  address?: string;
  lastLoginAt?: string;
  lastLoginIp?: string;
  createdAt: string;
  permissions?: string[];
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  price: number;
  stock: number;
  category: string;
  updatedAt: string;
}

export interface InvoiceItem {
  productId: string;
  productName: string;
  sku: string;
  quantity: number;
  price: number;
  total: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  customerName?: string;
  customerPhone?: string;
  items: InvoiceItem[];
  subTotal: number;
  tax: number;
  total: number;
  paymentMethod: 'cash' | 'card' | 'upi' | 'credit';
  status: 'paid' | 'pending' | 'cancelled';
  cashierId: string;
  createdAt: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
}
