Act as a Senior NestJS Architect.

Implement DTOs and Validation for the current module without changing any business logic.

Requirements:

1. Create a dto/ folder inside the current module.

2. Create the following DTOs:
   - create-<module>.dto.ts
   - update-<module>.dto.ts

3. Use class-validator and class-transformer.

4. Add appropriate validators such as:
   - @IsString()
   - @IsNotEmpty()
   - @IsOptional()
   - @IsNumber()
   - @IsBoolean()
   - @IsUUID()
   - @IsEnum()
   - @IsArray()
   - @ValidateNested()
   - @IsDateString()
   - @Min()
   - @Max()
   - @Length()

5. Replace every @Body() body:any or inline object with the corresponding DTO.

Example:

Before:

@Post()
create(@Body() body:any)

After:

@Post()
create(@Body() dto: CreateModuleDto)

6. Do NOT modify the service business logic.

7. Preserve all existing API responses.

8. Keep backward compatibility.

9. Generate proper imports.

10. Follow NestJS best practices.

11. If Update DTO is required, use PartialType(CreateModuleDto).

12. Return all generated DTO files and show every modified controller.
