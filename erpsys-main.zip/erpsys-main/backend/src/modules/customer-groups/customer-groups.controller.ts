import { Controller, Get, Post, Body, Put, Param, Delete, Query, UseGuards, Req } from '@nestjs/common';
import { CustomerGroupsService } from './customer-groups.service';
import { CreateCustomerGroupDto } from './dto/create-customer-group.dto';
import { UpdateCustomerGroupDto } from './dto/update-customer-group.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('customer-groups')
export class CustomerGroupsController {
  constructor(private readonly customerGroupsService: CustomerGroupsService) {}

  @Permissions(Permission.CUSTOMER_CREATE)
  @Post()
  create(@Req() req: any, @Body() createDto: CreateCustomerGroupDto) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      createDto.businessId = user.businessId;
    }
    if (!createDto.createdById) {
      createDto.createdById = user.id;
    }
    return this.customerGroupsService.create(createDto);
  }

  @Permissions(Permission.CUSTOMER_VIEW)
  @Get()
  findAll(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.customerGroupsService.findAll(bId, branchId);
  }

  @Permissions(Permission.CUSTOMER_VIEW)
  @Get(':id')
  findOne(@Req() req: any, @Param('id') id: string, @Query('businessId') businessId?: string) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.customerGroupsService.findOne(id, bId);
  }

  @Permissions(Permission.USER_MANAGE)
  @Put(':id')
  update(@Req() req: any, @Param('id') id: string, @Body() updateDto: UpdateCustomerGroupDto) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      updateDto.businessId = user.businessId;
    }
    if (!updateDto.updatedById) {
      updateDto.updatedById = user.id;
    }
    return this.customerGroupsService.update(id, updateDto);
  }

  @Permissions(Permission.USER_MANAGE)
  @Delete(':id')
  remove(@Req() req: any, @Param('id') id: string, @Query('businessId') businessId?: string) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.customerGroupsService.remove(id, bId);
  }
}

