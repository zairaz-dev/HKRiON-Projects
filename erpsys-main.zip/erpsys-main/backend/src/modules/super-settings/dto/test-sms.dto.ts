import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class TestSmsDto {
  @IsNotEmpty()
  @IsString()
  phoneNumber: string;

  @IsOptional()
  @IsString()
  message?: string;
}
