import * as React from "react"
import { cn } from "@/lib/utils"

/**
 * ==========================================================================
 * RadioGroupProps Interface
 * ==========================================================================
 * 
 * Defines properties for the RadioGroup wrapper.
 */
export interface RadioGroupProps extends React.HTMLAttributes<HTMLDivElement> {
  /**
   * The currently selected value of the radio group.
   */
  value?: string;
  /**
   * Callback triggered when a new radio item is selected.
   */
  onValueChange?: (value: string) => void;
  /**
   * The name attribute for the native radio inputs (for grouping).
   */
  name?: string;
}

/**
 * RadioGroup Context to share state between RadioGroup and RadioGroupItems
 */
const RadioGroupContext = React.createContext<{
  value?: string;
  onValueChange?: (value: string) => void;
  name?: string;
}>({});

/**
 * ==========================================================================
 * Reusable RadioGroup Component
 * ==========================================================================
 * 
 * Container component that coordinates selection states among multiple 
 * RadioGroupItem children using React Context.
 */
const RadioGroup = React.forwardRef<HTMLDivElement, RadioGroupProps>(
  ({ className, value, onValueChange, name, children, ...props }, ref) => {
    const [localValue, setLocalValue] = React.useState(value);

    // Sync external value changes to local state
    React.useEffect(() => {
      setLocalValue(value);
    }, [value]);

    const handleValueChange = (newValue: string) => {
      setLocalValue(newValue);
      if (onValueChange) {
        onValueChange(newValue);
      }
    };

    return (
      <RadioGroupContext.Provider value={{ value: localValue, onValueChange: handleValueChange, name }}>
        <div ref={ref} className={cn("grid gap-2", className)} {...props}>
          {children}
        </div>
      </RadioGroupContext.Provider>
    )
  }
)
RadioGroup.displayName = "RadioGroup"

/**
 * ==========================================================================
 * RadioGroupItemProps Interface
 * ==========================================================================
 */
export interface RadioGroupItemProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type'> {
  /**
   * Unique value for this radio item.
   */
  value: string;
}

/**
 * ==========================================================================
 * Reusable RadioGroupItem Component
 * ==========================================================================
 * 
 * Individual radio button component styled with custom outer ring, inner circle, 
 * and violet glow transitions. Includes a hidden native radio input for accessibility.
 */
const RadioGroupItem = React.forwardRef<HTMLInputElement, RadioGroupItemProps>(
  ({ className, value, children, ...props }, ref) => {
    const context = React.useContext(RadioGroupContext);
    const isChecked = context.value === value;

    const handleChange = () => {
      if (context.onValueChange) {
        context.onValueChange(value);
      }
    };

    return (
      <label className="flex items-center gap-2.5 cursor-pointer select-none text-sm text-slate-300">
        <div className="relative">
          {/* Native Hidden Radio input for keyboard and screen reader accessibility */}
          <input
            type="radio"
            name={context.name}
            checked={isChecked}
            onChange={handleChange}
            className="sr-only"
            ref={ref}
            value={value}
            {...props}
          />
          {/* Custom Styled Radio UI */}
          <div
            className={cn(
              "w-4 h-4 rounded-full border border-slate-700 bg-slate-950/40 flex items-center justify-center transition-all",
              isChecked ? "border-violet-500 shadow-lg shadow-violet-500/15" : "hover:border-slate-500",
              className
            )}
          >
            {/* Center dot shown when checked */}
            {isChecked && (
              <div className="w-2.5 h-2.5 rounded-full bg-violet-600 animate-in fade-in zoom-in-50 duration-150" />
            )}
          </div>
        </div>
        {/* Label text */}
        {children && <span className="text-xs font-medium text-slate-300">{children}</span>}
      </label>
    )
  }
)
RadioGroupItem.displayName = "RadioGroupItem"

export { RadioGroup, RadioGroupItem }
