import AdminDashboard from "@/features/admin/AdminDashboard";

export default function InquiriesPage() {
  return <AdminDashboard initialTab="inquiries" />;
}
