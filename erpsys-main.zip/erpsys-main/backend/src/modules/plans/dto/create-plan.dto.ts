import { IsBoolean, IsInt, IsNotEmpty, IsNumber, IsOptional, IsString, Min } from 'class-validator';

export class CreatePlanDto {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsString()
  @IsNotEmpty()
  slug: string;

  @IsString()
  @IsOptional()
  description?: string;

  @IsNumber()
  @Min(0)
  priceMonthly: number;

  @IsNumber()
  @Min(0)
  priceYearly: number;

  @IsNumber()
  @Min(0)
  @IsOptional()
  priceMonthlyUsd?: number;

  @IsNumber()
  @Min(0)
  @IsOptional()
  priceYearlyUsd?: number;

  @IsString()
  @IsOptional()
  currency?: string;

  @IsInt()
  @Min(0)
  @IsOptional()
  trialDays?: number;

  @IsInt()
  @IsOptional()
  maxBranches?: number;

  @IsInt()
  @IsOptional()
  maxUsers?: number;

  @IsInt()
  @IsOptional()
  maxProducts?: number;

  @IsInt()
  @IsOptional()
  maxInvoicesMonthly?: number;

  @IsBoolean()
  @IsOptional()
  enablePos?: boolean;

  @IsBoolean()
  @IsOptional()
  enableImei?: boolean;

  @IsBoolean()
  @IsOptional()
  enableAccounting?: boolean;

  @IsBoolean()
  @IsOptional()
  enableSms?: boolean;

  @IsBoolean()
  @IsOptional()
  enableApiAccess?: boolean;

  @IsBoolean()
  @IsOptional()
  isActive?: boolean;

  @IsBoolean()
  @IsOptional()
  isPopular?: boolean;

  @IsBoolean()
  @IsOptional()
  isCustom?: boolean;

  @IsString()
  @IsOptional()
  businessId?: string;

  @IsInt()
  @IsOptional()
  sortOrder?: number;
}
