"use client";

import React, { useRef } from "react";
import { Dialog } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { usePurchaseDetailQuery } from "../hooks/use-purchases";
import {
  Printer,
  Loader2,
  Phone,
  RotateCcw,
} from "lucide-react";
import { useCurrency } from "@/hooks/use-currency";

interface PurchaseDetailDialogProps {
  isOpen: boolean;
  onClose: () => void;
  purchaseId: string;
  businessId: string;
  businessName?: string;
  onReturnClick?: (purchase: any) => void;
}

export function PurchaseDetailDialog({
  isOpen,
  onClose,
  purchaseId,
  businessId,
  businessName = "HKRION ERP",
  onReturnClick,
}: PurchaseDetailDialogProps) {
  const { data: purchase, isLoading } = usePurchaseDetailQuery(purchaseId, businessId);
  const { symbol, format } = useCurrency(businessId);
  const printContentRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    if (!printContentRef.current) return;
    const printContents = printContentRef.current.innerHTML;
    const printWindow = window.open("", "_blank", "width=850,height=900");
    if (!printWindow) {
      window.print();
      return;
    }

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Purchase Invoice - ${purchase?.purchaseNumber || "Bill"}</title>
          <style>
            @page {
              size: A4;
              margin: 15mm;
            }
            body {
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
              color: #1a1a1a;
              margin: 0;
              padding: 10px;
              font-size: 12px;
              line-height: 1.4;
            }
            .header-table {
              width: 100%;
              margin-bottom: 20px;
              border-bottom: 2px solid #333;
              padding-bottom: 12px;
            }
            .company-title {
              font-size: 22px;
              font-weight: 800;
              text-transform: uppercase;
              letter-spacing: 0.5px;
            }
            .voucher-title {
              font-size: 18px;
              font-weight: 700;
              text-align: right;
              color: #2563eb;
              text-transform: uppercase;
            }
            .meta-grid {
              display: flex;
              justify-content: space-between;
              margin-bottom: 20px;
              gap: 20px;
            }
            .meta-box {
              flex: 1;
              border: 1px solid #ddd;
              padding: 10px 14px;
              border-radius: 6px;
              background-color: #fafafa;
            }
            .meta-box h4 {
              margin: 0 0 6px 0;
              font-size: 11px;
              text-transform: uppercase;
              color: #666;
            }
            .meta-box p {
              margin: 2px 0;
            }
            table.items-table {
              width: 100%;
              border-collapse: collapse;
              margin-bottom: 20px;
            }
            table.items-table th {
              background-color: #f1f5f9;
              border: 1px solid #cbd5e1;
              padding: 8px 10px;
              text-align: left;
              font-size: 11px;
              text-transform: uppercase;
            }
            table.items-table td {
              border: 1px solid #e2e8f0;
              padding: 8px 10px;
              font-size: 11px;
            }
            .text-right { text-align: right; }
            .text-center { text-align: center; }
            .font-bold { font-weight: bold; }
            .summary-table {
              width: 320px;
              margin-left: auto;
              border-collapse: collapse;
              margin-bottom: 30px;
            }
            .summary-table td {
              padding: 5px 8px;
              font-size: 12px;
            }
            .grand-total-row {
              font-weight: 800;
              font-size: 14px;
              border-top: 2px solid #333;
              border-bottom: 2px solid #333;
            }
            .signature-section {
              margin-top: 60px;
              display: flex;
              justify-content: space-between;
              padding: 0 30px;
            }
            .signature-box {
              text-align: center;
              width: 180px;
              border-top: 1px dashed #666;
              padding-top: 6px;
              font-size: 11px;
              font-weight: 600;
            }
            @media print {
              body { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
            }
          </style>
        </head>
        <body>
          ${printContents}
        </body>
      </html>
    `);

    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 400);
  };

  if (!isOpen) return null;

  // Calculate Subtotal before discount & shipping
  const itemsSubtotal = (purchase?.purchaseLines || []).reduce(
    (sum: number, line: any) => sum + (line.quantityPurchased * line.purchasePrice),
    0
  );

  const discountAmount = purchase?.discountAmount || 0;
  const shippingAmount = purchase?.shippingAmount || 0;
  const taxAmount = purchase?.taxAmount || 0;
  const remainingDue = Math.max(0, (purchase?.grandTotal || 0) - (purchase?.amountPaid || 0));

  return (
    <Dialog isOpen={isOpen} onClose={onClose} title="Purchase Invoice Details" size="3xl">
      {isLoading ? (
        <div className="py-16 flex flex-col items-center justify-center gap-3">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-xs text-muted-foreground">Loading purchase bill details...</p>
        </div>
      ) : !purchase ? (
        <div className="py-12 text-center text-sm text-destructive">
          Failed to load purchase details. Record may have been removed.
        </div>
      ) : (
        <div className="space-y-6 py-2">
          {/* Top Actions Bar inside Dialog */}
          <div className="flex items-center justify-between pb-3 border-b border-border/60">
            <div className="flex items-center gap-2">
              <span className="font-mono text-sm font-bold text-foreground">
                Bill #{purchase.purchaseNumber}
              </span>
              {/* Payment Status Badge */}
              <span
                className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded border ${
                  purchase.paymentStatus === "PAID"
                    ? "bg-emerald-500/10 text-emerald-600 border-emerald-500/30"
                    : purchase.paymentStatus === "PARTIAL"
                    ? "bg-amber-500/10 text-amber-600 border-amber-500/30"
                    : "bg-rose-500/10 text-rose-600 border-rose-500/30"
                }`}
              >
                {purchase.paymentStatus}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                className="h-8 gap-1.5 text-xs font-semibold"
                onClick={handlePrint}
              >
                <Printer className="h-3.5 w-3.5 text-primary" /> Print Bill / A4
              </Button>
            </div>
          </div>

          {/* Printable Container */}
          <div ref={printContentRef} className="space-y-6 p-2">
            {/* Header Table */}
            <div className="header-table flex items-center justify-between border-b pb-4">
              <div>
                <h1 className="company-title text-xl font-black text-foreground uppercase tracking-tight">
                  {purchase.branch?.name || businessName}
                </h1>
                <p className="text-xs text-muted-foreground">
                  Branch: {purchase.branch?.name}
                </p>
              </div>
              <div className="text-right">
                <h2 className="voucher-title text-base font-extrabold text-primary uppercase">
                  Purchase Voucher
                </h2>
                <p className="text-xs font-mono font-bold text-foreground">
                  Invoice #: {purchase.purchaseNumber}
                </p>
                <p className="text-xs text-muted-foreground">
                  Date: {new Date(purchase.purchaseDate).toLocaleDateString("en-IN", {
                    day: "2-digit",
                    month: "short",
                    year: "numeric",
                  })}
                </p>
              </div>
            </div>

            {/* Supplier and Purchase Info Cards */}
            <div className="meta-grid grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="meta-box p-3.5 rounded-lg border border-border/60 bg-card/50 space-y-1">
                <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider block">
                  Supplier Details
                </span>
                <p className="font-bold text-foreground text-sm">
                  {purchase.supplier?.name}
                </p>
                {purchase.supplier?.businessName && (
                  <p className="text-muted-foreground font-medium">
                    {purchase.supplier.businessName}
                  </p>
                )}
                {purchase.supplier?.phone && (
                  <p className="text-muted-foreground flex items-center gap-1">
                    <Phone className="h-3 w-3 inline" /> {purchase.supplier.phone}
                  </p>
                )}
                {purchase.supplier?.taxNumber && (
                  <p className="text-muted-foreground">
                    Tax / GST: {purchase.supplier.taxNumber}
                  </p>
                )}
              </div>

              <div className="meta-box p-3.5 rounded-lg border border-border/60 bg-card/50 space-y-1">
                <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider block">
                  Order & Payment Summary
                </span>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Payment Status:</span>
                  <span className="font-bold uppercase">{purchase.paymentStatus}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Grand Total:</span>
                  <span className="font-bold text-foreground">{format(purchase.grandTotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Paid So Far:</span>
                  <span className="font-bold text-emerald-600">{format(purchase.amountPaid || 0)}</span>
                </div>
                <div className="flex justify-between border-t border-border/40 pt-1">
                  <span className="text-muted-foreground font-semibold">Remaining Due:</span>
                  <span className={`font-black ${remainingDue > 0 ? "text-rose-600" : "text-muted-foreground"}`}>
                    {format(remainingDue)}
                  </span>
                </div>
              </div>
            </div>

            {/* Purchase Line Items Table */}
            <div className="border border-border/80 rounded-lg overflow-hidden">
              <table className="items-table w-full text-xs text-left">
                <thead className="bg-muted/50 border-b border-border text-muted-foreground">
                  <tr>
                    <th className="p-2.5 text-center w-10">#</th>
                    <th className="p-2.5">Product & Variant</th>
                    <th className="p-2.5">Batch & Expiry</th>
                    <th className="p-2.5 text-center">Qty</th>
                    <th className="p-2.5 text-right">Unit Cost</th>
                    <th className="p-2.5 text-right">Selling Price</th>
                    <th className="p-2.5 text-right">Line Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40 text-foreground">
                  {purchase.purchaseLines?.map((line: any, idx: number) => {
                    const lineTotal = line.quantityPurchased * line.purchasePrice;
                    const prodName = line.variant?.product?.name || "Product";
                    const varName = line.variant?.name;
                    const displayName = varName && varName !== "Standard" ? `${prodName} - ${varName}` : prodName;

                    return (
                      <tr key={line.id || idx} className="hover:bg-muted/20">
                        <td className="p-2.5 text-center font-mono text-muted-foreground">
                          {idx + 1}
                        </td>
                        <td className="p-2.5 font-semibold">
                          <span>{displayName}</span>
                          {line.variant?.sku && (
                            <span className="text-[10px] text-muted-foreground block font-mono">
                              SKU: {line.variant.sku}
                            </span>
                          )}
                        </td>
                        <td className="p-2.5 text-muted-foreground text-[11px]">
                          {line.batchNumber ? (
                            <span className="font-mono font-medium block">
                              B: {line.batchNumber}
                            </span>
                          ) : (
                            <span>-</span>
                          )}
                          {line.expiryDate && (
                            <span className="text-[10px] block">
                              Exp: {new Date(line.expiryDate).toLocaleDateString("en-IN", { month: "short", year: "numeric" })}
                            </span>
                          )}
                        </td>
                        <td className="p-2.5 text-center font-bold">
                          {line.quantityPurchased}
                        </td>
                        <td className="p-2.5 text-right font-medium">
                          {format(line.purchasePrice)}
                        </td>
                        <td className="p-2.5 text-right text-muted-foreground">
                          {format(line.sellingPrice)}
                        </td>
                        <td className="p-2.5 text-right font-bold text-foreground">
                          {format(lineTotal)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Financial Summary Breakdown */}
            <div className="flex flex-col sm:flex-row justify-between gap-6 pt-2">
              {/* Payment Records Section */}
              <div className="flex-1 space-y-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground block">
                  Payment Transactions
                </span>
                {(!purchase.payments || purchase.payments.length === 0) ? (
                  <p className="text-xs text-muted-foreground italic bg-secondary/30 p-3 rounded-lg border border-border/40">
                    No payment transactions recorded for this invoice yet.
                  </p>
                ) : (
                  <div className="space-y-1.5">
                    {purchase.payments.map((p: any) => (
                      <div
                        key={p.id}
                        className="p-2.5 border border-border/50 rounded-lg bg-card/40 flex items-center justify-between text-xs"
                      >
                        <div>
                          <span className="font-bold text-foreground block">
                            {p.paymentMethod?.name || "Direct Payment"}
                          </span>
                          <span className="text-[10px] text-muted-foreground font-mono">
                            {p.paymentNumber} • {new Date(p.paymentDate).toLocaleDateString("en-IN")}
                          </span>
                        </div>
                        <span className="font-black text-emerald-600">
                          {format(p.amount)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                {purchase.notes && (
                  <div className="pt-2">
                    <span className="text-[10px] font-bold uppercase text-muted-foreground block">
                      Notes / Remarks:
                    </span>
                    <p className="text-xs text-muted-foreground bg-muted/20 p-2.5 rounded border border-border/40">
                      {purchase.notes}
                    </p>
                  </div>
                )}
              </div>

              {/* Total Calculation Table */}
              <div className="w-full sm:w-72">
                <table className="summary-table w-full text-xs text-left">
                  <tbody>
                    <tr>
                      <td className="text-muted-foreground py-1">Items Subtotal:</td>
                      <td className="text-right font-semibold py-1">{format(itemsSubtotal)}</td>
                    </tr>
                    {discountAmount > 0 && (
                      <tr>
                        <td className="text-rose-600 font-medium py-1">Discount:</td>
                        <td className="text-right font-bold text-rose-600 py-1">
                          -{format(discountAmount)}
                        </td>
                      </tr>
                    )}
                    {shippingAmount > 0 && (
                      <tr>
                        <td className="text-muted-foreground py-1">Shipping / Freight:</td>
                        <td className="text-right font-semibold py-1">+{format(shippingAmount)}</td>
                      </tr>
                    )}
                    {taxAmount > 0 && (
                      <tr>
                        <td className="text-muted-foreground py-1">Tax:</td>
                        <td className="text-right font-semibold py-1">+{format(taxAmount)}</td>
                      </tr>
                    )}
                    <tr className="grand-total-row border-t-2 border-b-2 border-foreground/30 font-black">
                      <td className="py-2 text-sm text-foreground">Grand Total:</td>
                      <td className="py-2 text-right text-sm text-primary font-extrabold">
                        {format(purchase.grandTotal)}
                      </td>
                    </tr>
                    <tr>
                      <td className="text-muted-foreground py-1">Total Paid:</td>
                      <td className="text-right font-bold text-emerald-600 py-1">
                        {format(purchase.amountPaid || 0)}
                      </td>
                    </tr>
                    {remainingDue > 0 ? (
                      <tr className="font-bold">
                        <td className="text-rose-600 py-1">Balance Due:</td>
                        <td className="text-right text-rose-600 py-1">{format(remainingDue)}</td>
                      </tr>
                    ) : (
                      <tr>
                        <td className="text-emerald-600 font-semibold py-1">Status:</td>
                        <td className="text-right text-emerald-600 font-bold py-1">Fully Settled</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Signature Area (Visible during printing) */}
            <div className="signature-section mt-12 pt-8 flex justify-between">
              <div className="signature-box text-center border-t border-dashed border-muted-foreground/60 pt-2 w-44">
                <span className="text-xs font-semibold text-muted-foreground block">
                  Received / Checked By
                </span>
              </div>
              <div className="signature-box text-center border-t border-dashed border-muted-foreground/60 pt-2 w-44">
                <span className="text-xs font-semibold text-muted-foreground block">
                  Authorized Signatory
                </span>
              </div>
            </div>
          </div>

          {/* Dialog Footer */}
          <div className="flex justify-between items-center gap-3 pt-4 border-t border-border">
            <div>
              {onReturnClick && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    onClose();
                    onReturnClick(purchase);
                  }}
                  className="h-9 gap-1.5 border-amber-500/30 text-amber-600 dark:text-amber-400 hover:bg-amber-500/10 font-semibold"
                >
                  <RotateCcw className="h-4 w-4" /> Return Items
                </Button>
              )}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={onClose} className="h-9">
                Close
              </Button>
              <Button
                size="sm"
                onClick={handlePrint}
                className="h-9 gap-1.5 bg-primary text-black font-bold hover:bg-primary/90"
              >
                <Printer className="h-4 w-4" /> Print Invoice
              </Button>
            </div>
          </div>
        </div>
      )}
    </Dialog>
  );
}
