import {
  Injectable,
  BadRequestException,
  ForbiddenException,
  InternalServerErrorException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AiToolsService } from './ai-tools.service';
import { ChatPromptDto } from './dto/chat-prompt.dto';

@Injectable()
export class AiService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly toolsService: AiToolsService,
  ) {}

  private async getAiSettings() {
    const settings = await this.prisma.superPlatformSetting.findFirst();
    const isEnabled = settings?.enableAiAssistant ?? false;
    const apiKey = (settings?.openRouterApiKey || process.env.OPENROUTER_API_KEY || '').trim();
    const model = (settings?.openRouterModel || 'google/gemini-2.0-flash-exp:free').trim();
    const maxTokens = settings?.aiMaxTokens ? Math.min(settings.aiMaxTokens, 800) : 500;
    const temperature = settings?.aiTemperature || 0.7;
    const baseSystemPrompt =
      settings?.aiSystemPrompt ||
      'You are HKRION ERP AI Copilot, an expert AI business assistant for enterprise ERP management. You provide concise, polite, data-driven, and actionable business insights in English by default.';
    const allowedRoles = settings?.aiAllowedRoles || ['SUPER_ADMIN', 'ADMIN', 'MANAGER', 'CASHIER'];

    return {
      isEnabled,
      apiKey,
      model,
      maxTokens,
      temperature,
      baseSystemPrompt,
      allowedRoles,
    };
  }

  /**
   * Main conversational chat endpoint with OpenRouter and Live ERP Context
   */
  async chat(dto: ChatPromptDto, user: { id: string; role: string; businessId?: string }) {
    const aiConfig = await this.getAiSettings();

    // 1. Verify global enablement
    if (!aiConfig.isEnabled) {
      return {
        reply:
          'AI Copilot is currently disabled by the Super Administrator. Please contact support or enable it in Super Admin Platform Settings.',
        disabled: true,
      };
    }

    // 2. Verify API key
    if (!aiConfig.apiKey) {
      throw new BadRequestException(
        'OpenRouter API Key is not configured. Please configure it in Super Admin Settings > AI tab.',
      );
    }

    // 3. Verify user role permission with case & hyphen normalization
    const normalizeRole = (r: string) => (r || '').toUpperCase().replace(/[-\s]/g, '_');
    const userRoleNormalized = normalizeRole(user.role || '');

    const isSuperAdmin =
      userRoleNormalized === 'SUPER_ADMIN' ||
      user.role === 'super-admin' ||
      userRoleNormalized.includes('SUPER');

    const normalizedAllowedRoles = (aiConfig.allowedRoles || []).map((r) => normalizeRole(r));

    if (!isSuperAdmin && !normalizedAllowedRoles.includes(userRoleNormalized)) {
      throw new ForbiddenException(
        `Your current role (${user.role}) does not have access to HKRION AI Copilot. Please ask a Super Administrator to grant permission in Super Admin Settings.`,
      );
    }

    // 4. Ensure business context exists (Super Admin may not have a businessId)
    const businessId = user.businessId || '';
    const lastUserMessage = dto.messages[dto.messages.length - 1]?.content || '';

    let liveContext: any = {};
    if (businessId) {
      liveContext = await this.toolsService.buildAiContext(
        businessId,
        lastUserMessage,
        dto.branchId,
        user.role,
      );
    } else {
      // Platform-wide overview for Super Admin
      const [tenantsCount, usersCount, totalSalesAgg, totalProductsCount] = await Promise.all([
        this.prisma.business.count(),
        this.prisma.user.count(),
        this.prisma.sale.aggregate({ _sum: { grandTotal: true, amountPaid: true }, _count: { _all: true } }),
        this.prisma.product.count(),
      ]);

      liveContext = {
        platformView: 'Super Administrator Global View',
        totalRegisteredTenants: tenantsCount,
        totalUsers: usersCount,
        totalProductsInSystem: totalProductsCount,
        totalPlatformSales: Number(totalSalesAgg._sum.grandTotal || 0),
        totalPlatformReceived: Number(totalSalesAgg._sum.amountPaid || 0),
        totalInvoicesCreated: totalSalesAgg._count._all || 0,
      };
    }

    // 5. Build rich system prompt with live ERP context and strict language rules
    const systemPrompt = `
${aiConfig.baseSystemPrompt}

=== CURRENT USER & SESSION INFO ===
User ID: ${user.id}
User Role: ${user.role || 'Super Admin'}
Business ID: ${businessId || 'N/A (Super Admin View)'}
Timestamp: ${new Date().toLocaleString('en-US', { timeZone: 'Asia/Colombo' })}

=== LIVE ERP REAL-TIME DATABASE SNAPSHOT ===
${JSON.stringify(liveContext, null, 2)}

=== LANGUAGE & BEHAVIOR RULES (CHATGPT / CLAUDE STYLE) ===
1. DEFAULT LANGUAGE IS ENGLISH: By default, always reply in professional, fluent, concise English (just like ChatGPT or Claude).
2. CONDITIONAL TAMIL ONLY: Only if the user explicitly writes or asks in Tamil (தமிழ்) or Tanglish, reply in clear, natural Tamil. In all other cases (English queries, general requests, or commands), strictly reply in English.
3. Use clean Markdown formatting (bullet points, bold highlights, small tables) for readability.
4. When quoting monetary values, mention the business currency (e.g. Rs., LKR, or USD).
5. If the user asks for ERP actions (like creating invoice or transferring stock), give exact step-by-step navigation in HKRION ERP.
6. Strictly answer based on the real-time snapshot above. Do not fabricate financial or inventory figures.
7. Be concise, punchy, and direct to the point without verbose filler phrases to save tokens.
`.trim();

    // 6. Format messages for OpenRouter with Sliding Window (last 6 messages max to save 70% tokens)
    const MAX_SLIDING_WINDOW = 6;
    const recentMessages = (dto.messages || []).slice(-MAX_SLIDING_WINDOW);
    const apiMessages = [
      { role: 'system', content: systemPrompt },
      ...recentMessages.map((m) => ({
        role: m.role,
        content: m.content,
      })),
    ];

    const startTime = Date.now();

    try {
      const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${aiConfig.apiKey}`,
          'HTTP-Referer': 'https://ihmtech.com',
          'X-Title': 'HKRION ERP Copilot',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: aiConfig.model,
          messages: apiMessages,
          max_tokens: aiConfig.maxTokens,
          temperature: aiConfig.temperature,
        }),
        signal: AbortSignal.timeout(35000),
      });

      const latencyMs = Date.now() - startTime;
      const data = await response.json();

      if (!response.ok) {
        const errorMsg = data?.error?.message || response.statusText || 'OpenRouter API request failed';
        throw new BadRequestException(`OpenRouter API Error: ${errorMsg}`);
      }

      const choice = data?.choices?.[0];
      let reply = choice?.message?.content?.trim() || '';

      // Fallback for reasoning models that output thoughts or hit token limits
      if (!reply && choice?.message?.reasoning) {
        reply = choice.message.reasoning.trim();
      }

      if (!reply) {
        if (choice?.finish_reason === 'length') {
          reply =
            '⚠️ **Token Limit Reached:** The model exhausted its Max Token limit while generating the answer. Please increase **Max Output Tokens** to 800+ in Super Admin Settings or switch to a faster Flash model like `google/gemini-2.0-flash-exp:free`.';
        } else {
          reply =
            'I received an empty response from the AI provider. Please try again or switch to a faster model like `google/gemini-2.0-flash-exp:free`.';
        }
      }

      return {
        reply,
        model: aiConfig.model,
        latencyMs,
        contextSnapshot: {
          hasSalesData: !!liveContext.sales,
          hasStockData: !!liveContext.lowStockProducts,
          hasCustomerData: !!liveContext.topCustomers,
          hasExpenseData: !!liveContext.expenses,
        },
      };
    } catch (error: any) {
      if (error instanceof BadRequestException || error instanceof ForbiddenException) {
        throw error;
      }
      throw new InternalServerErrorException(`AI Copilot encountered an error: ${error.message}`);
    }
  }

  /**
   * Get public status of AI (whether enabled) for the web client
   */
  async getPublicAiStatus() {
    const settings = await this.prisma.superPlatformSetting.findFirst();
    return {
      isEnabled: settings?.enableAiAssistant ?? false,
      model: settings?.openRouterModel || 'google/gemini-2.0-flash-exp:free',
    };
  }
}
