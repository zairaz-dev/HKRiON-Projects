import {
  Controller,
  Post,
  Body,
  Get,
  Put,
  Delete,
  Param,
  Query,
  UseInterceptors,
  UploadedFile,
  BadRequestException,
} from '@nestjs/common';
import { ProductsService } from './products.service';
import { ProductType } from '@prisma/client';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';
import { FileInterceptor } from '@nestjs/platform-express';
import {
  ApiTags,
  ApiOperation,
  ApiBody,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiQuery,
  ApiConsumes,
} from '@nestjs/swagger';
import {
  CreateProductBodySchema,
  UpdateProductBodySchema,
  ProductResponseSchema,
} from '../../docs/products.docs';
import { getImageUploadOptions } from '../../common/utils/upload.util';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';

@ApiTags('Products')
@ApiBearerAuth()
@Controller('products')
export class ProductsController {
  constructor(private readonly productsService: ProductsService) {}

  @Permissions(Permission.PRODUCT_CREATE)
  @Post('upload-image')
  @UseInterceptors(FileInterceptor('image', getImageUploadOptions('products')))
  @ApiConsumes('multipart/form-data')
  @ApiOperation({ summary: 'Upload a product image' })
  @ApiResponse({
    status: 201,
    description: 'Image uploaded successfully',
    schema: {
      type: 'object',
      properties: {
        imageUrl: { type: 'string', example: '/uploads/products/1723829000-12345.png' },
      },
    },
  })
  async uploadImage(@UploadedFile() file: any) {
    if (!file) {
      throw new BadRequestException('No image file provided');
    }
    return {
      imageUrl: `/uploads/products/${file.filename}`,
    };
  }

  @Permissions(Permission.PRODUCT_CREATE)
  @Post()
  @ApiOperation({ summary: 'Create a single or variable product' })
  @ApiBody({ schema: CreateProductBodySchema })
  @ApiResponse({
    status: 201,
    description: 'Product created successfully',
    schema: ProductResponseSchema,
  })
  async createProduct(@Body() body: CreateProductDto) {
    return this.productsService.createProduct(body);
  }

  @Permissions(Permission.PRODUCT_VIEW)
  @Get()
  @ApiOperation({ summary: 'Get list of products for a business with pagination and filters' })
  @ApiQuery({ name: 'businessId', required: true, type: String })
  @ApiQuery({ name: 'branchId', required: false, type: String })
  @ApiQuery({ name: 'categoryId', required: false, type: String })
  @ApiQuery({ name: 'brandId', required: false, type: String })
  @ApiQuery({ name: 'search', required: false, type: String })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'all', required: false, type: Boolean })
  @ApiQuery({ name: 'isActive', required: false, type: Boolean })
  @ApiQuery({ name: 'notForSelling', required: false, type: Boolean })
  @ApiResponse({
    status: 200,
    description: 'Products retrieved successfully',
  })
  async getProducts(
    @Query('businessId') businessId: string,
    @Query('branchId') branchId?: string,
    @Query('categoryId') categoryId?: string,
    @Query('brandId') brandId?: string,
    @Query('search') search?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('all') all?: string,
    @Query('isActive') isActive?: string,
    @Query('notForSelling') notForSelling?: string,
  ) {
    return this.productsService.getProducts(businessId, {
      branchId,
      categoryId,
      brandId,
      search,
      page: page ? parseInt(page, 10) : undefined,
      limit: limit ? parseInt(limit, 10) : undefined,
      all: all === 'true',
      isActive: isActive !== undefined ? isActive === 'true' : undefined,
      notForSelling: notForSelling !== undefined ? notForSelling === 'true' : undefined,
    });
  }

  @Permissions(Permission.PRODUCT_VIEW)
  @Get(':id')
  @ApiOperation({ summary: 'Get product details by ID' })
  @ApiParam({ name: 'id', description: 'Product UUID' })
  @ApiQuery({ name: 'businessId', required: true, type: String })
  @ApiResponse({
    status: 200,
    description: 'Product retrieved successfully',
    schema: ProductResponseSchema,
  })
  async getProductById(
    @Param('id') id: string,
    @Query('businessId') businessId: string,
  ) {
    return this.productsService.getProductById(id, businessId);
  }

  @Permissions(Permission.PRODUCT_UPDATE)
  @Put(':id')
  @ApiOperation({ summary: 'Update product details, prices, or variants' })
  @ApiParam({ name: 'id', description: 'Product UUID' })
  @ApiBody({ schema: UpdateProductBodySchema })
  @ApiResponse({
    status: 200,
    description: 'Product updated successfully',
    schema: ProductResponseSchema,
  })
  async updateProduct(
    @Param('id') id: string,
    @Body() body: UpdateProductDto,
  ) {
    const { businessId, ...data } = body;
    return this.productsService.updateProduct(id, businessId, data);
  }

  @Permissions(Permission.PRODUCT_DELETE)
  @Delete(':id')
  @ApiOperation({ summary: 'Delete product' })
  @ApiParam({ name: 'id', description: 'Product UUID' })
  @ApiQuery({ name: 'businessId', required: true, type: String })
  @ApiResponse({
    status: 200,
    description: 'Product deleted successfully',
  })
  async deleteProduct(
    @Param('id') id: string,
    @Query('businessId') businessId: string,
  ) {
    return this.productsService.deleteProduct(id, businessId);
  }
}
