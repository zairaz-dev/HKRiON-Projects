"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import {
  User as UserIcon,
  Phone,
  Mail,
  Building2,
  Calendar,
  AlertCircle,
  CheckCircle,
  Loader2,
  ArrowLeft,
  Shield,
  MapPin,
  Clock,
  Globe,
  Edit2,
  Power,
  Key,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Briefcase,
  Layers,
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { authService } from "@/services/auth-service";
import { getFullAssetUrl } from "@/lib/utils";
import { User } from "@hkr/types";
import {
  useUserByIdQuery,
  useRolesQuery,
  useBranchesQuery,
  useToggleUserStatusMutation,
  UserDialog,
} from "@/features/users";

function UserViewPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const userId = searchParams.get("id") || "";

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState<boolean>(false);
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [errorMessage, setErrorMessage] = useState<string>("");

  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (errorMessage) {
      const timer = setTimeout(() => setErrorMessage(""), 5000);
      return () => clearTimeout(timer);
    }
  }, [errorMessage]);

  // Authenticate
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 1500);
    }
  }, []);

  const businessId = currentUser?.businessId || "";

  // Queries
  const { data: user, isLoading, isError, refetch } = useUserByIdQuery(userId);
  const { data: rolesList = [] } = useRolesQuery(businessId);
  const { data: branchesList = [] } = useBranchesQuery(businessId);
  const toggleStatusMutation = useToggleUserStatusMutation();

  if (isAuthenticated === null || isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
          <p className="text-xs font-mono text-muted-foreground">Loading user profile...</p>
        </div>
      </div>
    );
  }

  if (isError || !user) {
    return (
      <div className="flex h-screen bg-background text-foreground font-sans">
        <Sidebar activePath="/users" />
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <Navbar />
          <main className="flex-1 p-6 flex flex-col items-center justify-center">
            <div className="text-center space-y-4 max-w-md">
              <div className="w-16 h-16 rounded-full bg-rose-500/10 text-rose-500 flex items-center justify-center mx-auto border border-rose-500/20">
                <AlertCircle className="w-8 h-8" />
              </div>
              <h2 className="text-xl font-bold font-mono uppercase tracking-wider">User Not Found</h2>
              <p className="text-xs text-muted-foreground">
                The requested user could not be found or you do not have permission to view their profile.
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => router.push("/users")}
                className="gap-2 text-xs rounded-sm uppercase tracking-wider font-mono font-bold"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Back to Users
              </Button>
            </div>
          </main>
        </div>
      </div>
    );
  }

  const handleToggleStatus = async () => {
    try {
      const newStatus = !user.isActive;
      await toggleStatusMutation.mutateAsync({
        id: user.id,
        isActive: newStatus,
        updatedById: currentUser?.id,
      });
      setSuccessMessage(`User "${user.name}" has been ${newStatus ? "activated" : "deactivated"}.`);
      refetch();
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to update user status.");
    }
  };

  const getRoleBadgeStyle = (role: string) => {
    switch (role?.toLowerCase()) {
      case "super-admin":
        return "bg-purple-500/10 text-purple-400 border-purple-500/30";
      case "admin":
        return "bg-primary/10 text-primary border-primary/30";
      case "manager":
        return "bg-amber-500/10 text-amber-400 border-amber-500/30";
      case "cashier":
        return "bg-emerald-500/10 text-emerald-400 border-emerald-500/30";
      default:
        return "bg-secondary text-muted-foreground border-border";
    }
  };

  const permissions: string[] = (user as any)?.permissions || [];

  return (
    <div className="flex h-screen bg-background text-foreground font-sans">
      <Sidebar activePath="/users" />

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Navbar />

        <main className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Notifications */}
          {successMessage && (
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 rounded-sm text-xs flex items-center gap-2 animate-in fade-in-50">
              <CheckCircle className="w-4 h-4 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}
          {errorMessage && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 text-rose-500 rounded-sm text-xs flex items-center gap-2 animate-in fade-in-50">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Navigation / Header Actions */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border pb-4">
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => router.push("/users")}
                className="h-8 px-2.5 rounded-sm border-border hover:bg-secondary/40 text-xs font-mono"
              >
                <ArrowLeft className="w-3.5 h-3.5 mr-1" /> Back
              </Button>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-base sm:text-lg font-bold uppercase tracking-wider font-mono text-foreground">
                    User Profile
                  </h1>
                  <span className="text-[10px] text-muted-foreground font-mono">#{user.id.substring(0, 8)}</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  View staff credentials, branch permissions, contact data, and security activity.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleToggleStatus}
                disabled={toggleStatusMutation.isPending}
                className={`h-8 px-3 rounded-sm text-xs font-mono font-bold uppercase tracking-wider gap-1.5 ${
                  user.isActive
                    ? "border-rose-500/30 text-rose-400 hover:bg-rose-500/10"
                    : "border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10"
                }`}
              >
                <Power className="w-3.5 h-3.5" />
                {user.isActive ? "Deactivate" : "Activate"}
              </Button>

              <Button
                size="sm"
                onClick={() => setIsEditDialogOpen(true)}
                className="h-8 px-3 rounded-sm bg-primary text-primary-foreground hover:bg-primary/90 text-xs font-mono font-bold uppercase tracking-wider gap-1.5 shadow-sm"
              >
                <Edit2 className="w-3.5 h-3.5" /> Edit Profile
              </Button>
            </div>
          </div>

          {/* Main Profile Hero Banner */}
          <Card className="border border-border/70 bg-gradient-to-r from-card to-background/50 overflow-hidden shadow-sm">
            <CardContent className="p-5 sm:p-6">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                <div className="flex items-center gap-4 sm:gap-5">
                  <div className="relative shrink-0">
                    <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full border-2 border-primary/30 bg-secondary/40 overflow-hidden flex items-center justify-center shadow-md">
                      {user.avatar ? (
                        <img
                          src={getFullAssetUrl(user.avatar) || user.avatar}
                          alt={user.name}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.currentTarget as HTMLElement).style.display = "none";
                          }}
                        />
                      ) : (
                        <div className="text-2xl sm:text-3xl font-black text-primary uppercase font-mono">
                          {user.name.substring(0, 2)}
                        </div>
                      )}
                    </div>
                    <span
                      className={`absolute bottom-0.5 right-0.5 w-4 h-4 rounded-full border-2 border-card ${
                        user.isActive ? "bg-emerald-500 ring-2 ring-emerald-500/20" : "bg-rose-500"
                      }`}
                      title={user.isActive ? "Active Account" : "Deactivated Account"}
                    />
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="text-lg sm:text-xl font-bold text-foreground font-mono">{user.name}</h2>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-sm border uppercase font-mono tracking-wider ${getRoleBadgeStyle(
                          user.role
                        )}`}
                      >
                        {user.role}
                      </span>
                      <span
                        className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-sm border uppercase font-mono tracking-wider ${
                          user.isActive
                            ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                            : "bg-rose-500/10 text-rose-400 border-rose-500/30"
                        }`}
                      >
                        {user.isActive ? (
                          <>
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Active
                          </>
                        ) : (
                          <>
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-400" /> Deactivated
                          </>
                        )}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-y-1 gap-x-4 text-xs text-muted-foreground font-mono">
                      <div className="flex items-center gap-1.5">
                        <Mail className="w-3.5 h-3.5 text-primary/70" />
                        <a href={`mailto:${user.email}`} className="hover:underline hover:text-foreground">
                          {user.email}
                        </a>
                      </div>
                      {user.phone && (
                        <div className="flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-primary/70" />
                          <a href={`tel:${user.phone}`} className="hover:underline hover:text-foreground">
                            {user.phone}
                          </a>
                        </div>
                      )}
                      {(user as any).business && (
                        <div className="flex items-center gap-1.5">
                          <Briefcase className="w-3.5 h-3.5 text-primary/70" />
                          <span>{(user as any).business.name}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex md:flex-col items-end gap-1.5 text-right w-full md:w-auto pt-3 md:pt-0 border-t md:border-t-0 border-border">
                  <span className="text-[10px] text-muted-foreground font-mono uppercase tracking-wider">
                    Member Since
                  </span>
                  <span className="text-xs font-mono font-semibold text-foreground">
                    {new Date(user.createdAt).toLocaleDateString(undefined, {
                      year: "numeric",
                      month: "short",
                      day: "numeric",
                    })}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 4 Detail Grid Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Card 1: Contact Information */}
            <Card className="border border-border bg-card/60">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-2 text-primary">
                  <Phone className="w-4 h-4" />
                  <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-foreground">
                    Contact Details
                  </h3>
                </div>
                <div className="space-y-2 text-xs">
                  <div>
                    <span className="text-[10px] text-muted-foreground font-mono uppercase block">Email</span>
                    <span className="font-mono text-foreground break-all">{user.email}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-muted-foreground font-mono uppercase block">Phone Number</span>
                    <span className="font-mono text-foreground">{user.phone || "Not specified"}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-muted-foreground font-mono uppercase block">Address</span>
                    <span className="text-foreground">{user.address || "No address provided"}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Card 2: Security & Login Activity */}
            <Card className="border border-border bg-card/60">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-2 text-primary">
                  <ShieldCheck className="w-4 h-4" />
                  <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-foreground">
                    Security & Session
                  </h3>
                </div>
                <div className="space-y-2 text-xs">
                  <div>
                    <span className="text-[10px] text-muted-foreground font-mono uppercase block">Last Login Time</span>
                    <span className="font-mono text-foreground">
                      {user.lastLoginAt
                        ? new Date(user.lastLoginAt).toLocaleString(undefined, {
                            month: "short",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })
                        : "Never logged in"}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-muted-foreground font-mono uppercase block">Last Known IP</span>
                    <span className="font-mono text-foreground">{user.lastLoginIp || "Not recorded"}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-muted-foreground font-mono uppercase block">Auth Method</span>
                    <span className="font-mono text-foreground">
                      {(user as any).provider ? (user as any).provider.toUpperCase() : "Standard Password"}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Card 3: Branch Access */}
            <Card className="border border-border bg-card/60">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-2 text-primary">
                  <Building2 className="w-4 h-4" />
                  <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-foreground">
                    Branch Assignment
                  </h3>
                </div>
                <div className="space-y-2 text-xs">
                  {user.role === "admin" || user.role === "super-admin" ? (
                    <div className="p-2.5 rounded-sm bg-primary/10 border border-primary/20 text-primary text-[11px] font-mono">
                      ⭐ Global Access (All Branches Permitted)
                    </div>
                  ) : user.branches && user.branches.length > 0 ? (
                    <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                      {user.branches.map((branch: any) => (
                        <span
                          key={branch.id}
                          className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-sm bg-secondary border border-border text-foreground font-mono"
                        >
                          <Building2 className="w-3 h-3 text-muted-foreground" />
                          {branch.name}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-muted-foreground font-mono">No branch assigned</p>
                  )}
                  <div className="pt-1">
                    <span className="text-[10px] text-muted-foreground font-mono uppercase block">Total Branches</span>
                    <span className="font-mono font-bold text-foreground">
                      {user.role === "admin" || user.role === "super-admin"
                        ? "Unlimited"
                        : `${user.branches?.length || 0} Branch(es)`}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Card 4: Business Organization */}
            <Card className="border border-border bg-card/60">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-2 text-primary">
                  <Briefcase className="w-4 h-4" />
                  <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-foreground">
                    Organization
                  </h3>
                </div>
                <div className="space-y-2 text-xs">
                  <div>
                    <span className="text-[10px] text-muted-foreground font-mono uppercase block">Business Name</span>
                    <span className="font-mono font-semibold text-foreground">
                      {(user as any).business?.name || "Global / Root System"}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-muted-foreground font-mono uppercase block">Industry Type</span>
                    <span className="font-mono text-foreground">
                      {(user as any).business?.industry || "Enterprise"}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-muted-foreground font-mono uppercase block">Assigned Role</span>
                    <span className="font-mono text-primary font-bold">{user.role}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Role Permissions Section */}
          <Card className="border border-border bg-card">
            <CardContent className="p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-border pb-3">
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-primary" />
                  <h3 className="text-sm font-bold uppercase tracking-wider font-mono text-foreground">
                    Role Permissions & Capabilities
                  </h3>
                </div>
                <span className="text-xs font-mono text-muted-foreground">
                  Role: <strong className="text-foreground">{user.role}</strong> ({permissions.length} Permissions)
                </span>
              </div>

              {permissions.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2.5">
                  {permissions.map((perm: string) => (
                    <div
                      key={perm}
                      className="p-2 rounded-sm border border-border/80 bg-background/50 flex items-center gap-2 text-[11px] font-mono text-foreground"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span className="truncate" title={perm}>
                        {perm}
                      </span>
                    </div>
                  ))}
                </div>
              ) : user.role === "admin" || user.role === "super-admin" ? (
                <div className="p-4 rounded-sm bg-primary/5 border border-primary/20 text-xs font-mono text-primary flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 shrink-0" />
                  <span>
                    Full Administrative Access. All system permissions and operational capabilities are granted by
                    default for this account.
                  </span>
                </div>
              ) : (
                <p className="text-xs text-muted-foreground font-mono">No specific permissions assigned to this role.</p>
              )}
            </CardContent>
          </Card>
        </main>
      </div>

      {/* Edit User Modal Dialog */}
      <UserDialog
        isOpen={isEditDialogOpen}
        onClose={() => setIsEditDialogOpen(false)}
        user={user}
        rolesList={rolesList}
        branchesList={branchesList}
        currentUser={currentUser}
        onSuccess={(msg) => {
          setSuccessMessage(msg);
          refetch();
        }}
        onError={(err) => setErrorMessage(err)}
      />
    </div>
  );
}

export default function UserViewPage() {
  return (
    <Suspense
      fallback={
        <div className="flex h-screen w-full items-center justify-center bg-background">
          <div className="flex flex-col items-center gap-3">
            <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
            <p className="text-xs font-mono text-muted-foreground">Loading user profile...</p>
          </div>
        </div>
      }
    >
      <UserViewPageContent />
    </Suspense>
  );
}
