import React, { useState, useEffect } from "react";
import {
  X,
  Loader2,
  Undo2,
  Calendar,
  User as UserIcon,
  CreditCard,
  Building2,
  FileText,
  DollarSign
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { useCreateSalesReturnMutation } from "../hooks/use-sales-returns";
import { useCurrency } from "@/hooks/use-currency";

interface CreateSalesReturnDialogProps {
  isOpen: boolean;
  onClose: () => void;
  sale: any;
  businessId: string;
  userId: string;
  onSuccess: (msg: string) => void;
  onError: (msg: string) => void;
}

interface ReturnLineItem {
  saleLineId: string;
  variantId: string;
  productName: string;
  sku: string;
  soldQuantity: number;
  maxReturnable: number;
  quantityReturned: number;
  unitPrice: number;
  taxAmount: number;
  subtotal: number;
}

export function CreateSalesReturnDialog({
  isOpen,
  onClose,
  sale,
  businessId,
  userId,
  onSuccess,
  onError,
}: CreateSalesReturnDialogProps) {
  const { symbol } = useCurrency(businessId);
  const createMutation = useCreateSalesReturnMutation();

  const [returnDate, setReturnDate] = useState("");
  const [refundType, setRefundType] = useState<"CREDIT_NOTE" | "CASH_REFUND">("CREDIT_NOTE");
  const [reason, setReason] = useState("");
  const [notes, setNotes] = useState("");
  const [returnLines, setReturnLines] = useState<ReturnLineItem[]>([]);

  useEffect(() => {
    if (isOpen && sale) {
      setReturnDate(new Date().toISOString().split("T")[0]);
      setRefundType("CREDIT_NOTE");
      setReason("Defective / Damaged Item");
      setNotes("");

      if (sale.saleLines && sale.saleLines.length > 0) {
        const lines: ReturnLineItem[] = sale.saleLines.map((sl: any) => {
          let alreadyReturned = 0;
          if (sale.salesReturns) {
            sale.salesReturns.forEach((sr: any) => {
              sr.returnLines?.forEach((rl: any) => {
                if (rl.variantId === sl.variantId) {
                  alreadyReturned += rl.quantityReturned;
                }
              });
            });
          }

          const maxQty = Math.max(0, sl.quantity - alreadyReturned);

          return {
            saleLineId: sl.id,
            variantId: sl.variantId,
            productName: sl.variant?.product?.name || sl.variant?.name || "Item",
            sku: sl.variant?.sku || "N/A",
            soldQuantity: sl.quantity,
            maxReturnable: maxQty,
            quantityReturned: 0,
            unitPrice: sl.unitPrice,
            taxAmount: 0,
            subtotal: 0,
          };
        });

        setReturnLines(lines);
      } else {
        setReturnLines([]);
      }
    }
  }, [isOpen, sale]);

  if (!isOpen || !sale) return null;

  const handleQuantityChange = (index: number, val: string) => {
    const qty = parseInt(val) || 0;
    setReturnLines((prev) =>
      prev.map((line, i) => {
        if (i === index) {
          const validQty = Math.min(line.maxReturnable, Math.max(0, qty));
          return {
            ...line,
            quantityReturned: validQty,
            subtotal: validQty * line.unitPrice,
          };
        }
        return line;
      })
    );
  };

  const handleUnitPriceChange = (index: number, val: string) => {
    const price = parseFloat(val) || 0;
    setReturnLines((prev) =>
      prev.map((line, i) => {
        if (i === index) {
          return {
            ...line,
            unitPrice: price,
            subtotal: line.quantityReturned * price,
          };
        }
        return line;
      })
    );
  };

  const totalReturnAmount = returnLines.reduce((sum, l) => sum + l.subtotal, 0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const activeLines = returnLines.filter((l) => l.quantityReturned > 0);
    if (activeLines.length === 0) {
      onError("Please select at least one product quantity to return.");
      return;
    }

    const payload = {
      saleId: sale.id,
      businessId,
      branchId: sale.branchId,
      customerId: sale.customerId || undefined,
      createdById: userId,
      returnDate: new Date(returnDate).toISOString(),
      refundType,
      reason,
      notes: notes || undefined,
      returnLines: activeLines.map((l) => ({
        variantId: l.variantId,
        quantityReturned: l.quantityReturned,
        unitPrice: l.unitPrice,
        taxAmount: l.taxAmount,
      })),
    };

    try {
      const res = await createMutation.mutateAsync(payload);
      onSuccess(`Sales Return ${res.returnNumber || ""} created successfully!`);
      onClose();
    } catch (err: any) {
      onError(err.message || "Failed to process sales return.");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
      <div className="w-full max-w-3xl rounded-xl border border-border bg-card p-6 shadow-2xl animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh] overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border pb-3 mb-4 shrink-0">
          <div className="flex items-center gap-2">
            <Undo2 className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-bold">
              New Sales Return — Invoice #{sale.invoiceNumber}
            </h3>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="h-8 w-8 rounded-full"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto space-y-4 pr-1 pb-4">
            
            {/* Invoice Info Summary */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-muted/30 p-3.5 rounded-lg border border-border/40 text-xs">
              <div className="space-y-1">
                <span className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                  <UserIcon className="h-3 w-3 text-primary" /> Customer
                </span>
                <p className="font-bold text-foreground text-sm">
                  {sale.customer?.name || "Walk-in Customer"}
                </p>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                  <Building2 className="h-3 w-3 text-primary" /> Branch
                </span>
                <p className="font-bold text-foreground text-sm">
                  {sale.branch?.name || "N/A"}
                </p>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                  <DollarSign className="h-3 w-3 text-primary" /> Sale Invoice Grand Total
                </span>
                <p className="font-mono font-extrabold text-foreground text-sm">
                  {symbol}{sale.grandTotal?.toFixed(2)}
                </p>
              </div>
            </div>

            {/* Form Fields */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                  <Calendar className="h-3 w-3 text-primary" /> Return Date
                </label>
                <Input
                  type="date"
                  value={returnDate}
                  onChange={(e) => setReturnDate(e.target.value)}
                  className="h-9 text-xs"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                  <CreditCard className="h-3 w-3 text-primary" /> Refund Option
                </label>
                <Select
                  value={refundType}
                  onValueChange={(val: any) => setRefundType(val)}
                  className="h-9 text-xs"
                >
                  <option value="CREDIT_NOTE">Customer Credit Note (Advance)</option>
                  <option value="CASH_REFUND">Cash Refund</option>
                </Select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-muted-foreground uppercase">
                  Return Reason
                </label>
                <Select
                  value={reason}
                  onValueChange={setReason}
                  className="h-9 text-xs"
                >
                  <option value="Defective / Damaged Item">Defective / Damaged Item</option>
                  <option value="Incorrect Size / Variant">Incorrect Size / Variant</option>
                  <option value="Customer Change of Mind">Customer Change of Mind</option>
                  <option value="Expired Item">Expired Item</option>
                </Select>
              </div>
            </div>

            {/* Table of Sale Lines */}
            <div className="space-y-2">
              <span className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider block">
                Select Quantities to Return
              </span>
              <div className="border border-border/60 rounded-lg overflow-hidden">
                <table className="w-full text-xs text-left border-collapse">
                  <thead>
                    <tr className="bg-muted/40 border-b border-border/60">
                      <th className="p-3 font-semibold text-muted-foreground">Product</th>
                      <th className="p-3 font-semibold text-muted-foreground text-center">Sold Qty</th>
                      <th className="p-3 font-semibold text-muted-foreground text-center">Max Returnable</th>
                      <th className="p-3 font-semibold text-muted-foreground text-center w-28">Return Qty</th>
                      <th className="p-3 font-semibold text-muted-foreground text-right w-28">Unit Price ({symbol})</th>
                      <th className="p-3 font-semibold text-muted-foreground text-right pr-4 w-28">Subtotal ({symbol})</th>
                    </tr>
                  </thead>
                  <tbody>
                    {returnLines.map((line, idx) => (
                      <tr key={line.saleLineId || idx} className="border-b border-border/40">
                        <td className="p-3">
                          <span className="font-semibold text-foreground block">{line.productName}</span>
                          <span className="text-[10px] font-mono text-muted-foreground">SKU: {line.sku}</span>
                        </td>
                        <td className="p-3 text-center font-mono">
                          {line.soldQuantity}
                        </td>
                        <td className="p-3 text-center font-bold text-emerald-600 dark:text-emerald-400 font-mono">
                          {line.maxReturnable}
                        </td>
                        <td className="p-3 text-center">
                          <Input
                            type="number"
                            min="0"
                            max={line.maxReturnable}
                            value={line.quantityReturned}
                            onChange={(e) => handleQuantityChange(idx, e.target.value)}
                            disabled={line.maxReturnable <= 0}
                            className="h-8 text-center text-xs font-bold"
                          />
                        </td>
                        <td className="p-3 text-right">
                          <Input
                            type="number"
                            min="0"
                            step="any"
                            value={line.unitPrice}
                            onChange={(e) => handleUnitPriceChange(idx, e.target.value)}
                            className="h-8 text-right text-xs font-mono"
                          />
                        </td>
                        <td className="p-3 text-right font-mono font-bold pr-4">
                          {symbol}{line.subtotal.toFixed(2)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Notes */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-muted-foreground uppercase">
                Remarks / Audit Notes
              </label>
              <Input
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Remarks about customer return..."
                className="h-9 text-xs"
              />
            </div>
          </div>

          {/* Footer controls */}
          <div className="border-t border-border pt-4 shrink-0 flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-muted-foreground uppercase">Total Refund / Return Value</span>
              <span className="text-xl font-extrabold text-primary font-mono">
                {symbol}{totalReturnAmount.toFixed(2)}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="h-9 text-xs"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createMutation.isPending || totalReturnAmount <= 0}
                className="h-9 text-xs gap-1.5 shadow-md shadow-primary/10"
              >
                {createMutation.isPending && <Loader2 className="h-3 w-3 animate-spin" />}
                Confirm Sales Return
              </Button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
