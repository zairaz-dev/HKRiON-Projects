"use strict";
"use client";

import React, { useState } from "react";
import {
  Layers,
  ArrowLeft,
  Settings,
  Info,
  Check,
  Search,
  Mail,
  Lock,
  Eye,
  EyeOff,
  Sliders,
  Play
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { PageContainer } from "@/components/ui/page-container";
import Link from "next/link";

/**
 * ==========================================================================
 * Components Preview Page
 * ==========================================================================
 * 
 * This page serves as a live catalog and testing ground for the custom 
 * UI design system components. It showcases their styling, responsive 
 * layouts, states (default, hover, active, disabled), and animations.
 * 
 * All components are styled in accordance with the premium dark-theme 
 * glassmorphism aesthetic of the ERP application.
 */
export default function PreviewPage() {
  // ------------------------------------------------------------------------
  // State Management for Interactive Components
  // ------------------------------------------------------------------------

  // Input: Password visibility toggle
  const [showPassword, setShowPassword] = useState(false);

  // Checkbox: Agreement & newsletter subscription states
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [newsletter, setNewsletter] = useState(true);

  // Radio Group: Payment method selection
  const [paymentMethod, setPaymentMethod] = useState("upi");

  // Select: User role dropdown selection
  const [selectedRole, setSelectedRole] = useState("admin");

  return (
    <PageContainer size="lg" className="space-y-8">

      {/* ====================================================================
          1. HEADER SECTION
          ==================================================================== */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-900 pb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-violet-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-violet-500/25">
            <Sliders className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-black text-white tracking-tight">Design System</h1>
            <p className="text-xs text-slate-455 font-medium mt-0.5">Live catalog of custom premium UI components</p>
          </div>
        </div>
        <Link href="/dashboard">
          <Button variant="outline" size="sm" className="gap-2 border-slate-800 text-slate-300 hover:text-white rounded-sm h-9">
            <ArrowLeft className="w-3.5 h-3.5" /> Back to Dashboard
          </Button>
        </Link>
      </div>

      {/* ====================================================================
          2. COMPONENTS DISPLAY GRID
          ==================================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">

        {/* 2.1 BUTTON COMPONENT SECTION */}
        <Card className="glass border-slate-800/80">
          <CardHeader>
            <CardTitle className="text-sm font-semibold text-white tracking-tight uppercase font-mono text-violet-400">
              1. Button Component
            </CardTitle>
            <CardDescription className="text-xs text-slate-500">
              Standard trigger buttons with various stylistic variants and states.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">

            {/* Button Variants */}
            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-455">Variants</label>
              <div className="flex flex-wrap gap-3">
                <Button className="bg-violet-600 hover:bg-violet-500 text-white shadow-lg shadow-violet-500/10">Default</Button>
                <Button variant="secondary">Secondary</Button>
                <Button variant="outline" className="border-slate-800 text-slate-300 hover:text-white">Outline</Button>
                <Button variant="destructive">Destructive</Button>
                <Button variant="ghost">Ghost</Button>
                <Button variant="link">Link</Button>
              </div>
            </div>

            {/* Button Sizes */}
            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-455">Sizes</label>
              <div className="flex flex-wrap items-center gap-3">
                <Button size="sm" className="bg-violet-600 hover:bg-violet-500 text-white">Small</Button>
                <Button className="bg-violet-600 hover:bg-violet-500 text-white">Default</Button>
                <Button size="lg" className="bg-violet-600 hover:bg-violet-500 text-white">Large</Button>
                <Button size="icon" className="bg-violet-600 hover:bg-violet-500 text-white">
                  <Settings className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Button States */}
            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-455">States</label>
              <div className="flex flex-wrap gap-3">
                <Button disabled className="bg-violet-600 hover:bg-violet-500 text-white">Disabled</Button>
                <Button variant="outline" disabled className="border-slate-900 text-slate-600">Disabled Outline</Button>
              </div>
            </div>

          </CardContent>
        </Card>

        {/* 2.2 TEXT INPUT COMPONENT SECTION */}
        <Card className="glass border-slate-800/80">
          <CardHeader>
            <CardTitle className="text-sm font-semibold text-white tracking-tight uppercase font-mono text-violet-400">
              2. Text Input Component
            </CardTitle>
            <CardDescription className="text-xs text-slate-500">
              Custom text input fields with icon support and focus glow.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">

            {/* Standard Text Input */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-455">Standard Input</label>
              <Input type="text" placeholder="Enter username..." />
            </div>

            {/* Input with Icon (e.g. Email) */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-455">Input with Icon</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <Input type="email" placeholder="email@example.com" className="pl-10" />
              </div>
            </div>

            {/* Password Input with Visibility Toggle */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-455">Password Input (Interactive)</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <Input
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter password..."
                  className="pl-10 pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition"
                >
                </button>
              </div>
            </div>

            {/* Disabled Input */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-455">Disabled State</label>
              <Input type="text" placeholder="Locked field" disabled />
            </div>

          </CardContent>
        </Card>

        {/* 2.3 DROPDOWN (SELECT) COMPONENT SECTION */}
        <Card className="glass border-slate-800/80 relative z-10">
          <CardHeader>
            <CardTitle className="text-sm font-semibold text-white tracking-tight uppercase font-mono text-violet-400">
              3. Dropdown (Select) Component
            </CardTitle>
            <CardDescription className="text-xs text-slate-500">
              Custom dropdown selection menus styled to match the dark glass theme.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">

            {/* Standard Select */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-455">Standard Select (User Role)</label>
              <Select
                value={selectedRole}
                onChange={(e) => setSelectedRole(e.target.value)}
              >
                <option value="admin">Administrator</option>
                <option value="manager">POS Manager</option>
                <option value="cashier">Cashier</option>
                <option value="finance">Accountant</option>
              </Select>
              <p className="text-[10px] text-slate-500 font-mono">Selected: <span className="text-violet-450">{selectedRole}</span></p>
            </div>

            {/* Select with Sticky Search Bar */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-455">Select with Search Bar (showSearch={"{true}"})</label>
              <Select showSearch={true}>
                <option value="prod1">Apple iPhone 15 Pro</option>
                <option value="prod2">Samsung Galaxy S24 Ultra</option>
                <option value="prod3">Sony WH-1000XM5 Headphones</option>
                <option value="prod4">Apple MacBook Pro M3</option>
                <option value="prod5">Dell XPS 15 Laptop</option>
                <option value="prod6">Nintendo Switch OLED</option>
                <option value="prod7">Sony PlayStation 5</option>
              </Select>
              <p className="text-[10px] text-slate-500 font-mono">Useful for long lists (e.g. Products, Customers).</p>
            </div>

            {/* Disabled Select */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-455">Disabled Select</label>
              <Select disabled>
                <option>Feature locked</option>
              </Select>
            </div>

          </CardContent>
        </Card>

        {/* 2.4 CHECKBOX & RADIO COMPONENT SECTION */}
        <Card className="glass border-slate-800/80">
          <CardHeader>
            <CardTitle className="text-sm font-semibold text-white tracking-tight uppercase font-mono text-violet-400">
              4. Checkboxes & Radio Groups
            </CardTitle>
            <CardDescription className="text-xs text-slate-500">
              Premium selection states with glowing active indicator rings.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">

            {/* Checkbox States */}
            <div className="space-y-3">
              <label className="text-xs font-medium text-slate-455">Checkboxes</label>

              {/* Interactive Checkbox 1 */}
              <div className="flex items-center space-x-2.5">
                <Checkbox
                  id="preview-terms"
                  checked={agreeTerms}
                  onCheckedChange={(checked) => setAgreeTerms(checked)}
                />
                <label
                  htmlFor="preview-terms"
                  className="text-xs text-slate-350 cursor-pointer select-none font-medium"
                >
                  I accept the terms and conditions (Interactive)
                </label>
              </div>

              {/* Interactive Checkbox 2 */}
              <div className="flex items-center space-x-2.5">
                <Checkbox
                  id="preview-news"
                  checked={newsletter}
                  onCheckedChange={(checked) => setNewsletter(checked)}
                />
                <label
                  htmlFor="preview-news"
                  className="text-xs text-slate-350 cursor-pointer select-none font-medium"
                >
                  Subscribe to weekly newsletter (Default Checked)
                </label>
              </div>

              {/* Disabled Checkbox */}
              <div className="flex items-center space-x-2.5">
                <Checkbox id="preview-disabled" disabled />
                <label
                  htmlFor="preview-disabled"
                  className="text-xs text-slate-500 cursor-not-allowed select-none opacity-60 font-medium"
                >
                  Disabled Checkbox state
                </label>
              </div>
            </div>

            {/* Radio Group States */}
            <div className="space-y-3">
              <label className="text-xs font-medium text-slate-455">Radio Group (Payment Method)</label>
              <RadioGroup value={paymentMethod} onValueChange={(val) => setPaymentMethod(val)} name="preview-payment">
                <RadioGroupItem value="upi">UPI (GPAY, PhonePe)</RadioGroupItem>
                <RadioGroupItem value="card">Credit / Debit Card</RadioGroupItem>
                <RadioGroupItem value="cash">Cash on Register</RadioGroupItem>
                <RadioGroupItem value="netbanking" disabled>Net Banking (Disabled)</RadioGroupItem>
              </RadioGroup>
              <p className="text-[10px] text-slate-500 font-mono">Selected Method: <span className="text-violet-450 uppercase">{paymentMethod}</span></p>
            </div>

          </CardContent>
        </Card>

      </div>

      {/* ====================================================================
          3. FULL CARD COMPONENT IN ACTION
          ==================================================================== */}
      <Card className="glass border-slate-800/80">
        <CardHeader>
          <CardTitle className="text-sm font-semibold text-white tracking-tight uppercase font-mono text-violet-400 flex items-center gap-2">
            <Info className="w-4 h-4 text-violet-400" /> 5. Card Component in Action
          </CardTitle>
          <CardDescription className="text-xs text-slate-500">
            The parent container showing layout options with header, description, content, and footer.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="p-4 rounded-sm border border-slate-850 bg-slate-950/20 text-xs text-slate-350 leading-relaxed">
            This card is styled with the <code className="text-violet-400 bg-violet-950/20 px-1.5 py-0.5 rounded-sm font-mono">.glass</code> class in <code className="text-slate-400 bg-slate-900 px-1.5 py-0.5 rounded-sm font-mono">globals.css</code>. It features a semi-transparent dark background, backdrop blur, and a subtle border that glows when hovered when configured with <code className="text-violet-400 bg-violet-950/20 px-1.5 py-0.5 rounded-sm font-mono">.glass-hover</code>.
          </div>
        </CardContent>
        <CardFooter className="border-t border-slate-900/60 pt-4 flex justify-between items-center">
          <span className="text-[10px] font-mono text-slate-500">RADIUS BINDING: 12PX (--RADIUS)</span>
          <div className="flex gap-2">
            <Button size="sm" variant="ghost">Cancel</Button>
            <Button size="sm" className="bg-violet-600 hover:bg-violet-500 text-white shadow-lg shadow-violet-500/10">Confirm</Button>
          </div>
        </CardFooter>
      </Card>

    </PageContainer>
  );
}
