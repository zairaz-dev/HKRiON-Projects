import React from "react";
import { Loader2, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { User } from "@hkr/types";
import { BrandItem } from "../types";
import { useDeleteBrandMutation } from "../hooks/use-brands";

interface BrandDeleteDialogProps {
  isOpen: boolean;
  onClose: () => void;
  brand: BrandItem | null;
  currentUser: User;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

export function BrandDeleteDialog({
  isOpen,
  onClose,
  brand,
  currentUser,
  onSuccess,
  onError,
}: BrandDeleteDialogProps) {
  const deleteMutation = useDeleteBrandMutation();
  const [errorMessage, setErrorMessage] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (isOpen) {
      setErrorMessage(null);
    }
  }, [isOpen]);

  const handleDelete = async () => {
    if (!brand || !currentUser.businessId) return;
    setErrorMessage(null);

    try {
      await deleteMutation.mutateAsync({
        id: brand.id,
        businessId: currentUser.businessId,
      });
      onSuccess("Brand deleted successfully!");
      onClose();
    } catch (err: any) {
      const msg = err.message || "Failed to delete brand.";
      setErrorMessage(msg);
      onError(msg);
    }
  };

  const isLoading = deleteMutation.isPending;

  if (!isOpen || !brand) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="w-full max-w-sm bg-card border border-border rounded-sm shadow-2xl p-6 space-y-4 animate-in zoom-in-95 duration-200">
        <div className="text-center space-y-2">
          <div className="h-12 w-12 rounded-full bg-rose-500/10 border border-rose-500/25 flex items-center justify-center text-rose-550 mx-auto">
            <Trash2 className="h-5 w-5 text-rose-500" />
          </div>
          <h3 className="text-sm font-bold text-foreground tracking-wider uppercase font-mono">Delete Product Brand?</h3>
          {errorMessage && (
            <div className="p-2.5 rounded-sm bg-rose-500/15 border border-rose-500/30 text-rose-450 text-xs text-left animate-in fade-in duration-200">
              {errorMessage}
            </div>
          )}
          <p className="text-xs text-muted-foreground leading-relaxed">
            Are you sure you want to delete the brand <strong className="text-foreground">"{brand.name}"</strong>?
            This action cannot be undone and will remove it from all associated branches.
          </p>
        </div>
        <div className="flex gap-3 border-t border-border pt-4 bg-background/25">
          <Button
            variant="outline"
            onClick={onClose}
            className="w-full text-xs h-9 rounded-sm"
          >
            Cancel
          </Button>
          <Button
            onClick={handleDelete}
            disabled={isLoading}
            variant="destructive"
            className="w-full text-xs h-9 rounded-sm flex items-center justify-center gap-1.5"
          >
            {isLoading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            Delete Brand
          </Button>
        </div>
      </div>
    </div>
  );
}
