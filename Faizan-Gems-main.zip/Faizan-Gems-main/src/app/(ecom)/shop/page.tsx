"use client";

import React, { useState, useEffect, useMemo, Suspense } from "react";
import Image from "next/image";
import { useSearchParams } from "next/navigation";
import { Gemstone, extractCountryFromOrigin } from "@/types/gemstone";
import { GemstoneCard } from "@/features/gemstones/components/GemstoneCard";
import { GemstoneCardSkeleton } from "@/features/gemstones/components/GemstoneCardSkeleton";
import { useCurrency } from "@/features/currency/context/CurrencyContext";
import { useCMS } from "@/features/cms/useCMS";
import {
  SlidersIcon,
  CloseIcon,
  CertificateShieldIcon,
  ChevronDownIcon,
  CheckIcon,
  SearchIcon
} from "@/components/ui/LuxuryIcons";
import { LuxurySelect } from "@/components/ui/LuxurySelect";
import {
  useGemstoneAttributes,
  DEFAULT_GEMSTONE_TYPES,
} from "@/features/admin/hooks/useGemstoneAttributes";

function ShopPageContent() {
  const searchParams = useSearchParams();
  const initialType = searchParams.get("type") || "All";
  const { formatPrice } = useCurrency();
  const { getBlock } = useCMS();

  // CMS Content Blocks for Shop
  const shopEyebrow = getBlock("shop", "eyebrow", "Faizan Gems Vault Catalog");
  const shopHeadline = getBlock("shop", "headline", "Certified Natural Gemstones");
  const shopSubheadline = getBlock(
    "shop",
    "subheadline",
    "Each specimen is individually authenticated and certified by world-leading independent laboratories. Never heated or chemically diffused unless explicitly specified."
  );
  const shopBannerImage = getBlock("shop", "banner_image", "");
  const shopNoticeBadge = getBlock(
    "shop",
    "notice_badge",
    ""
  );
  const shopNoticeActive = getBlock("shop", "notice_active", "false") === "true";

  // Dynamic Gemstones Catalog
  const [gemstonesList, setGemstonesList] = useState<Gemstone[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    let isMounted = true;
    fetch("/api/gemstones")
      .then((res) => {
        if (!res.ok) throw new Error("Failed to fetch gemstones catalog");
        return res.json();
      })
      .then((data) => {
        if (isMounted && Array.isArray(data)) {
          setGemstonesList(data);
        }
      })
      .catch((err) => {
        console.warn("Failed to fetch gemstones catalog:", err);
      })
      .finally(() => {
        if (isMounted) {
          setIsLoading(false);
        }
      });
    return () => {
      isMounted = false;
    };
  }, []);

  // Filter States
  const [selectedType, setSelectedType] = useState<string>(initialType);
  const [selectedOrigin, setSelectedOrigin] = useState<string>("All");
  const [selectedCaratRange, setSelectedCaratRange] = useState<string>("All");
  const [userMaxPrice, setUserMaxPrice] = useState<number | null>(null);
  const [sortBy, setSortBy] = useState<string>("rarity");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);
  const [viewColumns, setViewColumns] = useState<2 | 3>(3);

  // Sync type filter if URL query param changes
  useEffect(() => {
    const typeParam = searchParams.get("type");
    if (typeParam) {
      setSelectedType(typeParam);
    }
  }, [searchParams]);

  // Prevent background scrolling when mobile filter drawer is open
  useEffect(() => {
    if (mobileFilterOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileFilterOpen]);

  // Escape key to close mobile filters
  useEffect(() => {
    if (!mobileFilterOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMobileFilterOpen(false);
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [mobileFilterOpen]);

  // Dynamic maximum catalog price for the slider
  const maxCatalogPrice = useMemo(() => {
    if (gemstonesList.length === 0) return 1000000;
    const max = Math.max(...gemstonesList.map((g) => Number(g.price) || 0));
    if (max <= 100000) return 100000;
    if (max <= 500000) return Math.ceil(max / 50000) * 50000;
    return Math.ceil(max / 100000) * 100000;
  }, [gemstonesList]);

  const effectiveSliderPrice = userMaxPrice !== null ? userMaxPrice : maxCatalogPrice;

  const [isHydrated, setIsHydrated] = useState(false);
  useEffect(() => {
    setIsHydrated(true);
  }, []);

  // Dynamic Gemstone Attributes (defaults, localStorage, CMS & catalog)
  const { types: customGemstoneTypes } = useGemstoneAttributes(gemstonesList);

  // Filter Lists
  const cmsCustomTypesRaw = getBlock("inventory", "custom_types", "");
  const cmsCustomTypes = useMemo(() => {
    if (!cmsCustomTypesRaw) return [];
    try {
      const parsed = JSON.parse(cmsCustomTypesRaw);
      return Array.isArray(parsed) ? (parsed as string[]) : [];
    } catch {
      return [];
    }
  }, [cmsCustomTypesRaw]);

  const gemstoneTypes = useMemo(() => {
    const set = new Set<string>(["All"]);
    if (isHydrated && Array.isArray(customGemstoneTypes) && customGemstoneTypes.length > 0) {
      customGemstoneTypes.forEach((t) => {
        if (t && typeof t === "string" && t.trim()) set.add(t.trim());
      });
    } else {
      DEFAULT_GEMSTONE_TYPES.forEach((t) => set.add(t));
    }
    gemstonesList.forEach((g) => {
      if (g.type && typeof g.type === "string" && g.type.trim()) {
        set.add(g.type.trim());
      }
    });
    return Array.from(set);
  }, [isHydrated, customGemstoneTypes, gemstonesList]);
  const origins = useMemo(() => {
    const defaultOrigins = ["All", "Sri Lanka", "Burma", "Colombia", "Mozambique", "Brazil", "Tanzania"];
    const set = new Set(defaultOrigins);
    gemstonesList.forEach((g) => {
      const country = g.originCountry || extractCountryFromOrigin(g.origin);
      if (country && country.trim()) set.add(country.trim());
    });
    return Array.from(set);
  }, [gemstonesList]);
  const caratRanges = [
    { label: "All Carats", value: "All" },
    { label: "Under 2.00 ct", value: "under-2" },
    { label: "2.00 – 3.99 ct", value: "2-4" },
    { label: "4.00 – 5.99 ct", value: "4-6" },
    { label: "6.00+ ct", value: "6-plus" },
  ];

  // Filtered & Sorted Gemstones
  const filteredGemstones = useMemo(() => {
    return gemstonesList.filter((gem) => {
      // Type
      if (selectedType !== "All" && gem.type !== selectedType) return false;

      // Origin
      if (selectedOrigin !== "All") {
        const country = gem.originCountry || extractCountryFromOrigin(gem.origin);
        if (country !== selectedOrigin) return false;
      }

      // Carat
      if (selectedCaratRange === "under-2" && gem.carat >= 2) return false;
      if (selectedCaratRange === "2-4" && (gem.carat < 2 || gem.carat >= 4)) return false;
      if (selectedCaratRange === "4-6" && (gem.carat < 4 || gem.carat >= 6)) return false;
      if (selectedCaratRange === "6-plus" && gem.carat < 6) return false;

      // Price
      if (userMaxPrice !== null && gem.price > userMaxPrice) return false;

      // Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = gem.name.toLowerCase().includes(q);
        const matchesOrigin = gem.origin.toLowerCase().includes(q);
        const matchesColor = gem.color.toLowerCase().includes(q);
        const matchesSku = gem.sku.toLowerCase().includes(q);
        if (!matchesName && !matchesOrigin && !matchesColor && !matchesSku) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === "price-asc") return a.price - b.price;
      if (sortBy === "price-desc") return b.price - a.price;
      if (sortBy === "carat-desc") return b.carat - a.carat;
      if (sortBy === "rarity") return b.rarityScore - a.rarityScore;
      return 0; // Default
    });
  }, [gemstonesList, selectedType, selectedOrigin, selectedCaratRange, userMaxPrice, sortBy, searchQuery]);

  const activeFilterCount =
    (selectedType !== "All" ? 1 : 0) +
    (selectedOrigin !== "All" ? 1 : 0) +
    (selectedCaratRange !== "All" ? 1 : 0) +
    (userMaxPrice !== null && userMaxPrice < maxCatalogPrice ? 1 : 0) +
    (searchQuery ? 1 : 0);

  const resetFilters = () => {
    setSelectedType("All");
    setSelectedOrigin("All");
    setSelectedCaratRange("All");
    setUserMaxPrice(null);
    setSearchQuery("");
  };

  return (
    <div className="bg-[#FAF8F5] min-h-screen py-8 lg:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Page Header & CMS Editorial Banner */}
        {shopBannerImage ? (
          <div className="relative w-full h-48 sm:h-64 lg:h-72 overflow-hidden mb-8 border border-[#E8E4DC] group">
            <Image
              src={shopBannerImage}
              alt={shopHeadline}
              fill
              priority
              sizes="(max-width: 1280px) 100vw, 1200px"
              className="object-cover object-center group-hover:scale-105 transition-transform duration-700"
              unoptimized={shopBannerImage.startsWith("/uploads")}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#18181D]/90 via-[#18181D]/45 to-black/20 flex flex-col justify-end p-6 sm:p-10">
              {shopNoticeActive && shopNoticeBadge && (
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 backdrop-blur-md border border-white/20 text-[#E5C396] text-[10px] uppercase font-sans tracking-wider w-fit mb-3">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#E5C396]" />
                  <span>{shopNoticeBadge}</span>
                </div>
              )}
              <span className="text-[11px] font-sans tracking-wide-luxury uppercase text-[#E5C396] block mb-1.5">
                {shopEyebrow}
              </span>
              <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-white font-normal">
                {shopHeadline}
              </h1>
              <p className="mt-2 text-xs sm:text-sm text-[#E0DDD8] font-sans max-w-2xl line-clamp-2">
                {shopSubheadline}
              </p>
            </div>
          </div>
        ) : (
          <div className="mb-8 border-b border-[#E8E4DC] pb-6">
            {shopNoticeActive && shopNoticeBadge && (
              <div className="mb-3 inline-flex items-center gap-2 px-3 py-1 bg-[#F5EFE6] border border-[#C5A880]/40 text-[#6D5228] text-[11px] font-sans tracking-wide">
                <span className="w-1.5 h-1.5 rounded-full bg-[#C5A880]" />
                <span>{shopNoticeBadge}</span>
              </div>
            )}
            <span className="text-[11px] font-sans tracking-wide-luxury uppercase text-[#9A7B4F] block mb-1">
              {shopEyebrow}
            </span>
            <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-[#18181D] font-normal">
              {shopHeadline}
            </h1>
            <p className="mt-2 text-xs sm:text-sm text-[#6B655C] font-sans max-w-2xl">
              {shopSubheadline}
            </p>
          </div>
        )}

        {/* Toolbar Bar: Count, Sort, View toggles & Mobile filter trigger */}
        <div className="bg-white border border-[#E8E4DC] p-4 mb-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center justify-between w-full md:w-auto gap-4">
            <span className="text-xs font-sans text-[#554F47]">
              {isLoading ? (
                <span className="inline-block w-36 h-3.5 bg-[#E8E4DC] rounded-xs animate-pulse align-middle" />
              ) : (
                <>
                  Showing <strong className="text-[#18181D]">{filteredGemstones.length}</strong> of {gemstonesList.length} specimens
                </>
              )}
            </span>

            {/* Mobile Filter Button */}
            <button
              onClick={() => setMobileFilterOpen(true)}
              className="md:hidden px-3 py-1.5 bg-[#FAF8F5] border border-[#E8E4DC] text-xs font-sans uppercase tracking-wider flex items-center gap-1.5 text-[#18181D]"
            >
              <SlidersIcon className="w-3.5 h-3.5 text-[#C5A880]" />
              <span>Filters {activeFilterCount > 0 && `(${activeFilterCount})`}</span>
            </button>
          </div>

          {/* Search within catalog */}
          <div className="relative w-full md:w-72">
            <SearchIcon className="w-4 h-4 text-[#8C867D] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by variety or origin..."
              className="w-full text-xs font-sans pl-9 pr-3 py-2 bg-[#FAF8F5] border border-[#E8E4DC] focus:border-[#C5A880] focus:outline-none"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] uppercase font-mono text-[#8C867D]"
              >
                ✕
              </button>
            )}
          </div>

          {/* Sort & Grid Toggles */}
          <div className="flex items-center gap-4 w-full md:w-auto justify-end">
            <div className="flex items-center gap-2 text-xs font-sans text-[#554F47]">
              <span className="text-[#8C867D] uppercase tracking-wider text-[10px] shrink-0">Sort By:</span>
              <div className="w-52">
                <LuxurySelect
                  value={sortBy}
                  onChange={setSortBy}
                  variant="light"
                  size="sm"
                  options={[
                    { value: "rarity", label: "Investment Grade / Rarity" },
                    { value: "price-desc", label: "Price: High to Low" },
                    { value: "price-asc", label: "Price: Low to High" },
                    { value: "carat-desc", label: "Carat: High to Low" },
                  ]}
                />
              </div>
            </div>

            {/* Desktop Grid Switcher */}
            <div className="hidden lg:flex items-center border border-[#E8E4DC]">
              <button
                onClick={() => setViewColumns(2)}
                title="2-Column Editorial View"
                className={`px-2.5 py-1 text-xs font-mono transition-colors ${
                  viewColumns === 2 ? "bg-[#18181D] text-white" : "text-[#8C867D] hover:bg-[#FAF8F5]"
                }`}
              >
                2 Col
              </button>
              <button
                onClick={() => setViewColumns(3)}
                title="3-Column Standard View"
                className={`px-2.5 py-1 text-xs font-mono transition-colors ${
                  viewColumns === 3 ? "bg-[#18181D] text-white" : "text-[#8C867D] hover:bg-[#FAF8F5]"
                }`}
              >
                3 Col
              </button>
            </div>
          </div>
        </div>

        {/* Active Filter Chips */}
        {activeFilterCount > 0 && (
          <div className="flex flex-wrap items-center gap-2 mb-6 text-xs font-sans">
            <span className="text-[10px] uppercase tracking-wider text-[#8C867D]">Active Filters:</span>
            {selectedType !== "All" && (
              <span className="px-2.5 py-1 bg-white border border-[#C5A880] text-[#9A7B4F] flex items-center gap-1.5">
                Type: {selectedType}
                <button onClick={() => setSelectedType("All")} className="hover:text-black">✕</button>
              </span>
            )}
            {selectedOrigin !== "All" && (
              <span className="px-2.5 py-1 bg-white border border-[#C5A880] text-[#9A7B4F] flex items-center gap-1.5">
                Origin: {selectedOrigin}
                <button onClick={() => setSelectedOrigin("All")} className="hover:text-black">✕</button>
              </span>
            )}

            {selectedCaratRange !== "All" && (
              <span className="px-2.5 py-1 bg-white border border-[#C5A880] text-[#9A7B4F] flex items-center gap-1.5">
                Carat: {caratRanges.find(c => c.value === selectedCaratRange)?.label}
                <button onClick={() => setSelectedCaratRange("All")} className="hover:text-black">✕</button>
              </span>
            )}
            {userMaxPrice !== null && userMaxPrice < maxCatalogPrice && (
              <span className="px-2.5 py-1 bg-white border border-[#C5A880] text-[#9A7B4F] flex items-center gap-1.5">
                Max Price: <span className="font-price font-semibold text-[#18181D]">{formatPrice(userMaxPrice)}</span>
                <button onClick={() => setUserMaxPrice(null)} className="hover:text-black">✕</button>
              </span>
            )}
            <button
              onClick={resetFilters}
              className="text-[#8C867D] hover:text-[#18181D] underline ml-2 text-[11px]"
            >
              Reset All
            </button>
          </div>
        )}

        {/* Main Grid & Desktop Sidebar */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Desktop Filter Sidebar */}
          <aside className="hidden md:block md:col-span-1 space-y-6">
            <div className="bg-white border border-[#E8E4DC] p-5 space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-[#F2EFE9]">
                <h3 className="font-serif text-base uppercase tracking-wider text-[#18181D]">
                  Filters
                </h3>
                {activeFilterCount > 0 && (
                  <button
                    onClick={resetFilters}
                    className="text-[11px] text-[#9A7B4F] hover:underline uppercase"
                  >
                    Reset
                  </button>
                )}
              </div>

              {/* Gemstone Type */}
              <div>
                <span className="text-[11px] font-sans uppercase tracking-wider text-[#8C867D] block mb-2 font-medium">
                  Gemstone Variety
                </span>
                <div className="space-y-1.5 text-xs font-sans">
                  {gemstoneTypes.map((type) => (
                    <button
                      key={type}
                      onClick={() => setSelectedType(type)}
                      className={`w-full text-left py-1 px-2 transition-colors flex items-center justify-between ${
                        selectedType === type
                          ? "bg-[#FAF8F5] text-[#18181D] font-medium border-l-2 border-[#C5A880]"
                          : "text-[#554F47] hover:text-[#18181D]"
                      }`}
                    >
                      <span>{type}</span>
                      {selectedType === type && <CheckIcon className="w-3.5 h-3.5 text-[#C5A880]" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Carat Range */}
              <div className="pt-4 border-t border-[#F2EFE9]">
                <span className="text-[11px] font-sans uppercase tracking-wider text-[#8C867D] block mb-2 font-medium">
                  Carat Weight
                </span>
                <div className="space-y-1.5 text-xs font-sans">
                  {caratRanges.map((range) => (
                    <button
                      key={range.value}
                      onClick={() => setSelectedCaratRange(range.value)}
                      className={`w-full text-left py-1 px-2 transition-colors flex items-center justify-between ${
                        selectedCaratRange === range.value
                          ? "bg-[#FAF8F5] text-[#18181D] font-medium border-l-2 border-[#C5A880]"
                          : "text-[#554F47] hover:text-[#18181D]"
                      }`}
                    >
                      <span>{range.label}</span>
                      {selectedCaratRange === range.value && <CheckIcon className="w-3.5 h-3.5 text-[#C5A880]" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Origin Country */}
              <div className="pt-4 border-t border-[#F2EFE9]">
                <span className="text-[11px] font-sans uppercase tracking-wider text-[#8C867D] block mb-2 font-medium">
                  Geographic Origin
                </span>
                <div className="space-y-1.5 text-xs font-sans">
                  {origins.map((origin) => (
                    <button
                      key={origin}
                      onClick={() => setSelectedOrigin(origin)}
                      className={`w-full text-left py-1 px-2 transition-colors flex items-center justify-between ${
                        selectedOrigin === origin
                          ? "bg-[#FAF8F5] text-[#18181D] font-medium border-l-2 border-[#C5A880]"
                          : "text-[#554F47] hover:text-[#18181D]"
                      }`}
                    >
                      <span>{origin}</span>
                      {selectedOrigin === origin && <CheckIcon className="w-3.5 h-3.5 text-[#C5A880]" />}
                    </button>
                  ))}
                </div>
              </div>



              {/* Price Range */}
              <div className="pt-4 border-t border-[#F2EFE9]">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-sans uppercase tracking-wider text-[#8C867D] font-medium">
                    Max Price
                  </span>
                  <span className="font-price text-xs font-semibold text-[#18181D]">
                    {formatPrice(effectiveSliderPrice)}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max={maxCatalogPrice}
                  step={maxCatalogPrice > 500000 ? 25000 : 5000}
                  value={effectiveSliderPrice}
                  onChange={(e) => setUserMaxPrice(parseInt(e.target.value, 10))}
                  className="w-full accent-[#C5A880] h-1.5 bg-[#E8E4DC] rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-[#8C867D] mt-1 font-mono">
                  <span>{formatPrice(0)}</span>
                  <span>{formatPrice(maxCatalogPrice)}</span>
                </div>
              </div>
            </div>
          </aside>

          {/* Product Grid Area */}
          <main className="col-span-1 md:col-span-3">
            {isLoading ? (
              <div
                className={`grid gap-3 sm:gap-6 ${
                  viewColumns === 2
                    ? "grid-cols-2"
                    : "grid-cols-2 lg:grid-cols-3"
                }`}
              >
                {[...Array(6)].map((_, idx) => (
                  <GemstoneCardSkeleton key={idx} />
                ))}
              </div>
            ) : filteredGemstones.length === 0 ? (
              <div className="bg-white border border-[#E8E4DC] p-12 text-center">
                <CertificateShieldIcon className="w-10 h-10 text-[#8C867D] mx-auto mb-3" />
                <h3 className="font-serif text-2xl text-[#18181D]">No Matching Specimens</h3>
                <p className="mt-2 text-xs text-[#6B655C] font-sans max-w-md mx-auto leading-relaxed">
                  No gemstones match your specific criteria. Please adjust your carat weight, origin, or gemstone type filters, or request a private acquisition from our gemological vault.
                </p>
                <button
                  onClick={resetFilters}
                  className="mt-6 px-6 py-2.5 bg-[#18181D] text-white text-xs uppercase tracking-widest font-sans hover:bg-[#2A2A32] transition-colors"
                >
                  Clear All Filters
                </button>
              </div>
            ) : (
              <div
                className={`grid gap-3 sm:gap-6 ${
                  viewColumns === 2
                    ? "grid-cols-2"
                    : "grid-cols-2 lg:grid-cols-3"
                }`}
              >
                {filteredGemstones.map((gem, idx) => (
                  <GemstoneCard key={gem.id} gemstone={gem} priority={idx < 6} />
                ))}
              </div>
            )}
          </main>
        </div>
      </div>

      {/* Mobile Filter Drawer */}
      {mobileFilterOpen && (
        <div
          className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm md:hidden animate-luxury-backdrop"
          onClick={() => setMobileFilterOpen(false)}
        >
          <div
            className="w-4/5 max-w-sm bg-white h-full shadow-2xl p-6 flex flex-col justify-between overflow-y-auto animate-luxury-drawer-right"
            onClick={(e) => e.stopPropagation()}
          >
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-[#E8E4DC]">
                <h3 className="font-serif text-lg text-[#18181D]">Filter Gemstones</h3>
                <button onClick={() => setMobileFilterOpen(false)} aria-label="Close filters">
                  <CloseIcon className="w-5 h-5 text-[#8C867D]" />
                </button>
              </div>

              {/* Mobile filter controls */}
              <div className="py-4 space-y-5 text-xs font-sans">
                {/* Gemstone Type */}
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-[#8C867D] block mb-2 font-medium">
                    Variety
                  </span>
                  <div className="grid grid-cols-2 gap-1.5">
                    {gemstoneTypes.map((type) => (
                      <button
                        key={type}
                        onClick={() => setSelectedType(type)}
                        className={`p-2 border text-left truncate ${
                          selectedType === type
                            ? "bg-[#18181D] text-white border-[#18181D]"
                            : "bg-[#FAF8F5] text-[#554F47] border-[#E8E4DC]"
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Origin */}
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-[#8C867D] block mb-2 font-medium">
                    Origin
                  </span>
                  <div className="grid grid-cols-2 gap-1.5">
                    {origins.map((origin) => (
                      <button
                        key={origin}
                        onClick={() => setSelectedOrigin(origin)}
                        className={`p-2 border text-left truncate ${
                          selectedOrigin === origin
                            ? "bg-[#18181D] text-white border-[#18181D]"
                            : "bg-[#FAF8F5] text-[#554F47] border-[#E8E4DC]"
                        }`}
                      >
                        {origin}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Mobile Price Range */}
                <div className="pt-4 border-t border-[#E8E4DC]">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] uppercase tracking-wider text-[#8C867D] block font-medium">
                      Max Price
                    </span>
                    <span className="font-price text-xs font-semibold text-[#18181D]">
                      {formatPrice(effectiveSliderPrice)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max={maxCatalogPrice}
                    step={maxCatalogPrice > 500000 ? 25000 : 5000}
                    value={effectiveSliderPrice}
                    onChange={(e) => setUserMaxPrice(parseInt(e.target.value, 10))}
                    className="w-full accent-[#C5A880] h-1.5 bg-[#E8E4DC] rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-[#8C867D] mt-1 font-mono">
                    <span>{formatPrice(0)}</span>
                    <span>{formatPrice(maxCatalogPrice)}</span>
                  </div>
                </div>

              </div>
            </div>

            <div className="pt-4 border-t border-[#E8E4DC] space-y-2">
              <button
                onClick={() => setMobileFilterOpen(false)}
                className="w-full py-3 bg-[#18181D] text-white text-xs uppercase tracking-widest font-sans"
              >
                Apply Filters ({filteredGemstones.length} Results)
              </button>
              <button
                onClick={resetFilters}
                className="w-full py-2 text-center text-xs text-[#8C867D] hover:underline uppercase"
              >
                Reset All Filters
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function ShopPage() {
  return (
    <Suspense fallback={
      <div className="bg-[#FAF8F5] min-h-screen py-20 text-center font-serif text-xl text-[#18181D]">
        Opening Faizan Gems Vault...
      </div>
    }>
      <ShopPageContent />
    </Suspense>
  );
}
