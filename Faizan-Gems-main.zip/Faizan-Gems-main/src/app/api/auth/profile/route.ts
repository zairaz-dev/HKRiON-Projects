import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import pool from "@/lib/db";
import {
  verifyCustomerSessionToken,
  CUSTOMER_SESSION_COOKIE_NAME,
} from "@/lib/auth";

export async function PATCH(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get(CUSTOMER_SESSION_COOKIE_NAME)?.value;

    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const session = verifyCustomerSessionToken(token);
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { name, phone, location, salon } = body;
    const targetLoc = location || salon;

    // Update users table
    if (name || phone !== undefined) {
      await pool.query(
        "UPDATE users SET name = COALESCE(?, name), phone = COALESCE(?, phone) WHERE email = ?",
        [name ? name.trim() : null, phone ? phone.trim() : null, session.email]
      );
    }

    // Update clients table
    if (name || phone !== undefined || targetLoc) {
      await pool.query(
        `UPDATE clients
         SET name = COALESCE(?, name), phone = COALESCE(?, phone), location = COALESCE(?, location)
         WHERE email = ?`,
        [name ? name.trim() : null, phone ? phone.trim() : null, targetLoc ? targetLoc.trim() : null, session.email]
      );
    }

    return NextResponse.json({
      success: true,
      user: {
        ...session,
        name: name || session.name,
        phone: phone !== undefined ? phone : session.phone,
        location: targetLoc || (session as any).location || "Sri Lanka",
        salon: targetLoc || (session as any).location || "Sri Lanka",
      },
    });
  } catch (error) {
    console.error("Profile update error:", error);
    return NextResponse.json({ error: "Failed to update profile" }, { status: 500 });
  }
}
