# HKRION ERP Standalone Frontend (Next.js)

This is a standalone Next.js frontend application, separated from the monorepo for easier deployment on VPS, Vercel, or similar hosting platforms.

## Local Run Instructions

1. **Install Dependencies**:

   ```bash
   pnpm install
   # or
   npm install
   ```

2. **Run in Development Mode**:

   ```bash
   pnpm dev
   # or
   npm run dev
   ```

3. **Build and Run in Production Mode**:
   ```bash
   pnpm build
   pnpm start
   # or
   npm run build
   npm run start
   ```

---

## Deployment Instructions

### 1. Vercel / Netlify (Recommended - Free & Easy)

Hosting the Next.js frontend on Vercel is straightforward:

1. Push the frontend directory to a new GitHub repository.
2. Log into Vercel, import the GitHub repository, and click **Deploy**.
3. In Environment Variables, set `NEXT_PUBLIC_API_URL` to your production API URL (e.g., `https://api.yourdomain.com`).

---

### 2. VPS Deployment (Running with PM2)

1. **File Upload**:
   Upload the frontend folder to your VPS (exclude `node_modules` and `.next` folders).

2. **Production Environment Variables (`.env.local`)**:
   Create a `.env.local` file on your VPS and configure your API URL:

   ```env
   NEXT_PUBLIC_API_URL="https://api.yourdomain.com"
   ```

3. **VPS Commands**:
   In your VPS terminal, run:

   ```bash
   # 1. Install dependencies
   pnpm install

   # 2. Build the project
   pnpm build

   # 3. Run Next.js on port 3000 in the background using PM2
   pm2 start npm --name "hkr-erp-web" -- run start
   ```

## ###### Windows App

# - Development Mode (Hot Reload):

npm run electron:dev

## - Build for Windows:

npm run electron:build
