import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class StockValuationService {
  constructor(private readonly prisma: PrismaService) {}

  async getStockValuation(
    businessId: string,
    filters: {
      branchId?: string;
      search?: string;
    },
  ) {
    const { branchId, search } = filters;

    const whereClause: any = {
      businessId,
      quantityRemaining: { gt: 0 },
    };

    if (branchId && branchId !== 'all') {
      whereClause.branchId = branchId;
    }

    if (search) {
      whereClause.variant = {
        OR: [
          { name: { contains: search, mode: 'insensitive' } },
          { sku: { contains: search, mode: 'insensitive' } },
          { product: { name: { contains: search, mode: 'insensitive' } } },
        ],
      };
    }

    const batches = await this.prisma.purchaseLine.findMany({
      where: whereClause,
      include: {
        branch: {
          select: { id: true, name: true },
        },
        variant: {
          include: {
            product: {
              select: { id: true, name: true, categoryId: true },
            },
          },
        },
      },
    });

    let totalStockUnits = 0;
    let totalCostValue = 0;
    let totalSellingValue = 0;

    const variantSummaryMap = new Map<string, {
      variantId: string;
      productName: string;
      sku: string;
      branchName: string;
      stockQty: number;
      costPrice: number;
      sellingPrice: number;
      totalCost: number;
      totalSelling: number;
    }>();

    for (const batch of batches) {
      const qty = batch.quantityRemaining;
      const cost = batch.purchasePrice || batch.variant.purchasePrice || 0;
      const sell = batch.sellingPrice || batch.variant.sellingPrice || 0;

      totalStockUnits += qty;
      totalCostValue += qty * cost;
      totalSellingValue += qty * sell;

      const key = `${batch.variantId}-${batch.branchId}`;
      const existing = variantSummaryMap.get(key);

      if (existing) {
        existing.stockQty += qty;
        existing.totalCost += qty * cost;
        existing.totalSelling += qty * sell;
      } else {
        variantSummaryMap.set(key, {
          variantId: batch.variantId,
          productName: batch.variant.product?.name || batch.variant.name,
          sku: batch.variant.sku,
          branchName: batch.branch?.name || 'N/A',
          stockQty: qty,
          costPrice: cost,
          sellingPrice: sell,
          totalCost: qty * cost,
          totalSelling: qty * sell,
        });
      }
    }

    const items = Array.from(variantSummaryMap.values());
    const lowStockItems = items.filter((item) => item.stockQty <= 5);

    return {
      totalStockUnits,
      totalCostValue,
      totalSellingValue,
      potentialProfitMargin: totalSellingValue - totalCostValue,
      itemsCount: items.length,
      items,
      lowStockItems,
    };
  }
}
