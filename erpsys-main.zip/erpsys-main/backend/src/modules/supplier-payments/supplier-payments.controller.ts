import { Controller, Post, Body, Get, Delete, Param, Query, UseGuards, Req } from '@nestjs/common';
import { SupplierPaymentsService } from './supplier-payments.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('supplier-payments')
export class SupplierPaymentsController {
  constructor(private readonly supplierPaymentsService: SupplierPaymentsService) {}

  @Permissions(Permission.PURCHASE_CREATE)
  @Post()
  async createPayment(@Req() req: any, @Body() body: any) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }

    const {
      amount,
      paymentDate,
      purchaseId,
      supplierId,
      paymentMethodId,
      branchId,
      businessId,
      transactionNo,
      notes,
      createdById,
    } = body;

    return this.supplierPaymentsService.createPayment({
      amount: Number(amount),
      paymentDate: paymentDate ? new Date(paymentDate) : undefined,
      purchaseId,
      supplierId,
      paymentMethodId,
      branchId,
      businessId,
      transactionNo,
      notes,
      createdById: createdById || user.id,
    });
  }

  @Permissions(Permission.PURCHASE_VIEW)
  @Get()
  async getPayments(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
    @Query('supplierId') supplierId?: string,
    @Query('purchaseId') purchaseId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.supplierPaymentsService.getPayments(bId, {
      branchId,
      supplierId,
      purchaseId,
    });
  }

  @Permissions(Permission.PURCHASE_CREATE)
  @Delete(':id')
  async deletePayment(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.supplierPaymentsService.deletePayment(id, bId);
  }
}

