'use client';
import { useState, useEffect } from 'react';
import { 
  MapPin, 
  Search, 
  Send, 
  Download, 
  Trash2, 
  CheckCircle2, 
  AlertCircle, 
  Loader2, 
  Phone, 
  Star, 
  Store, 
  Sparkles, 
  Layers, 
  Clock, 
  ShieldCheck, 
  Filter, 
  CheckSquare, 
  Square,
  ExternalLink,
  MessageSquare,
  RefreshCw,
  Zap,
  Tag
} from 'lucide-react';

const PRESET_LOCATIONS = [
  'Trincomalee, Sri Lanka',
  'Colombo, Sri Lanka',
  'Jaffna, Sri Lanka',
  'Batticaloa, Sri Lanka',
  'Kandy, Sri Lanka',
  'Kinniya, Trincomalee',
];

const PRESET_CATEGORIES = [
  { id: 'Restaurants', name: 'Restaurants & Dining 🍽️' },
  { id: 'Cafes', name: 'Cafes & Bakeries ☕' },
  { id: 'Supermarkets', name: 'Supermarkets & Groceries 🛒' },
  { id: 'Mobile Phone Shops', name: 'Mobile Phone & Electronics 📱' },
  { id: 'Pharmacies', name: 'Pharmacies & Medical 💊' },
  { id: 'Hardware Shops', name: 'Hardware & Construction 🔨' },
  { id: 'Hotels', name: 'Hotels & Resorts 🏨' },
];

const PROPOSAL_TEMPLATES = [
  {
    id: 'restaurant_tamil',
    name: '🍽️ Restaurant POS & QR Menu Proposal (Tamil)',
    content: `வணக்கம் {business_name} மேலாளர் அவர்களுக்கு! 🙏

{location}-ல் உள்ள உங்கள் உணவகத்திற்கு HKRiON வழங்கும் நவீன POS & Business Management மென்பொருள் மூலம்:

✅ Quick Touch Billing & KOT
✅ QR Menu (வாடிக்கையாளர்கள் போனில் Menu பார்க்கலாம்)
✅ Stock & Daily Sales Reports
✅ Multi-user & Table Management

உங்கள் உணவகத்திற்கு ஒருமுறை *இலவச Demo* பார்க்க விரும்புகிறீர்களா? 

HKRiON Pvt Ltd — Trincomalee
📞 0775014217 | https://hkrion.com`,
  },
  {
    id: 'retail_tamil',
    name: '🛒 Supermarket & Retail POS Proposal (Tamil)',
    content: `வணக்கம் {business_name} நிர்வாகத்தினருக்கு! 🙏

{location}-ல் இயங்கும் உங்கள் வணிகத்திற்கு *HKRiON Retail POS System*:

📊 Barcode Billing & Inventory Tracking
📦 Stock Alerts & Expiry Management
👥 Supplier & Customer Credit Management
📱 Mobile-ல் இருந்து Daily Profit & Sales பார்க்கலாம்

இலவச டெமோ அல்லது Quotation பெற இந்த மெசேஜுக்கு பதிலளிக்கவும். 

HKRiON Pvt Ltd 🚀`,
  },
  {
    id: 'english_general',
    name: '🌐 English Modern Business POS Pitch',
    content: `Hello Team {business_name}! 👋

Digitize and grow your business in {location} with HKRiON's Modern Cloud POS Solution.

✨ Super-fast Billing & Receipts
✨ Real-time Stock & Inventory Control
✨ Multi-branch & User Permissions
✨ WhatsApp Invoices & Reports

Would you like a FREE 15-minute online/direct demo for {business_name}?

Best regards,
HKRiON Pvt Ltd (IHM TECH)
🌐 https://hkrion.com | 📞 0775014217`,
  },
];

export default function LeadExtractor({ onNavigateToChat }) {
  // Search parameters
  const [location, setLocation] = useState('Trincomalee, Sri Lanka');
  const [category, setCategory] = useState('Restaurants');
  const [limit, setLimit] = useState(20);
  const [scraping, setScraping] = useState(false);

  // Leads state
  const [leads, setLeads] = useState([]);
  const [selectedLeadIds, setSelectedLeadIds] = useState(new Set());
  const [filterMobileOnly, setFilterMobileOnly] = useState(true);
  const [searchFilter, setSearchFilter] = useState('');

  // Campaign State
  const [showCampaignModal, setShowCampaignModal] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState(PROPOSAL_TEMPLATES[0].id);
  const [customMessage, setCustomMessage] = useState(PROPOSAL_TEMPLATES[0].content);
  const [delaySeconds, setDelaySeconds] = useState(10);
  const [campaignRunning, setCampaignRunning] = useState(false);
  const [campaignProgress, setCampaignProgress] = useState({ current: 0, total: 0, sent: 0, failed: 0 });
  const [campaignLogs, setCampaignLogs] = useState([]);

  // Toast / Alert
  const [toast, setToast] = useState(null);

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 4000);
  };

  // Load existing leads from server
  const fetchSavedLeads = async () => {
    try {
      const res = await fetch('/api/leads');
      if (res.ok) {
        const data = await res.json();
        if (data.leads) {
          setLeads(data.leads);
        }
      }
    } catch (e) {
      console.warn('Failed to load saved leads:', e);
    }
  };

  useEffect(() => {
    fetchSavedLeads();
  }, []);

  // Handle Scraping
  const handleScrape = async (e) => {
    e.preventDefault();
    if (!location.trim()) {
      showToast('Please enter a location', 'error');
      return;
    }

    setScraping(true);
    showToast(`Google Maps-ல் ${category} in ${location} தேடப்படுகிறது...`, 'info');

    try {
      const res = await fetch('/api/maps/scrape', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          category,
          location: location.trim(),
          limit: parseInt(limit, 10),
          autoSave: true,
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to extract Google Maps leads');
      }

      if (data.leads && data.leads.length > 0) {
        showToast(`வெற்றிகரமாக ${data.leads.length} நிறுவனங்களின் தகவல்கள் பெறப்பட்டன! 🎉`);
        // Refresh full lead list
        await fetchSavedLeads();
      } else {
        showToast('முடிவுகள் எதுவும் கிடைக்கவில்லை. வேறு இடத்தைப் பயன்படுத்திப் பார்க்கவும்.', 'error');
      }
    } catch (err) {
      showToast(err.message || 'Scraping failed', 'error');
    } finally {
      setScraping(false);
    }
  };

  // Select all / Toggle
  const displayedLeads = leads
    .filter((l) => (filterMobileOnly ? l.isMobile || l.phoneNumber : true))
    .filter((l) => 
      l.name.toLowerCase().includes(searchFilter.toLowerCase()) || 
      (l.address && l.address.toLowerCase().includes(searchFilter.toLowerCase())) ||
      (l.formattedPhone && l.formattedPhone.includes(searchFilter))
    );

  const toggleSelectAll = () => {
    if (selectedLeadIds.size === displayedLeads.length) {
      setSelectedLeadIds(new Set());
    } else {
      setSelectedLeadIds(new Set(displayedLeads.map((l) => l.id)));
    }
  };

  const toggleSelectLead = (id) => {
    const next = new Set(selectedLeadIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSelectedLeadIds(next);
  };

  // Delete lead
  const handleDeleteLead = async (id) => {
    try {
      await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', leadId: id }),
      });
      setLeads((prev) => prev.filter((l) => l.id !== id));
      const nextSel = new Set(selectedLeadIds);
      nextSel.delete(id);
      setSelectedLeadIds(nextSel);
      showToast('Lead deleted');
    } catch (e) {
      showToast('Failed to delete lead', 'error');
    }
  };

  // Export to CSV
  const handleExportCSV = () => {
    const target = leads.filter((l) => selectedLeadIds.size === 0 || selectedLeadIds.has(l.id));
    if (target.length === 0) {
      showToast('No leads to export', 'error');
      return;
    }

    const headers = ['Name', 'Phone Number', 'Is WhatsApp Mobile', 'Category', 'Location', 'Rating', 'Reviews', 'Status', 'Address'];
    const rows = target.map((l) => [
      `"${(l.name || '').replace(/"/g, '""')}"`,
      `"${l.phoneNumber || l.formattedPhone || ''}"`,
      l.isMobile ? 'Yes' : 'No',
      `"${l.category || ''}"`,
      `"${l.location || ''}"`,
      l.rating || '',
      l.reviews || 0,
      l.status || 'New',
      `"${(l.address || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `google_maps_leads_${Date.now()}.csv`;
    a.click();
    showToast(`${target.length} Leads Exported to CSV! 📥`);
  };

  // Handle Campaign Dispatch
  const handleStartCampaign = async () => {
    const targetLeads = displayedLeads.filter((l) => selectedLeadIds.has(l.id));
    if (targetLeads.length === 0) {
      showToast('Please select at least one lead for the campaign', 'error');
      return;
    }

    setCampaignRunning(true);
    setCampaignProgress({ current: 0, total: targetLeads.length, sent: 0, failed: 0 });
    setCampaignLogs([]);

    try {
      const res = await fetch('/api/campaign/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          instanceName: 'saas_instance',
          leads: targetLeads,
          messageTemplate: customMessage,
          delaySeconds: parseInt(delaySeconds, 10),
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Campaign dispatch failed');
      }

      setCampaignLogs(data.results || []);
      setCampaignProgress({
        current: targetLeads.length,
        total: targetLeads.length,
        sent: data.sentCount,
        failed: data.failedCount,
      });

      showToast(`Campaign Complete! ${data.sentCount} Messages Sent Successfully 🚀`);
      await fetchSavedLeads();
    } catch (err) {
      showToast(err.message || 'Campaign error', 'error');
    } finally {
      setCampaignRunning(false);
    }
  };

  const selectTemplateHandler = (tplId) => {
    setSelectedTemplate(tplId);
    const tpl = PROPOSAL_TEMPLATES.find((t) => t.id === tplId);
    if (tpl) {
      setCustomMessage(tpl.content);
    }
  };

  const mobileCount = leads.filter((l) => l.isMobile).length;

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Toast */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 px-4 py-3 rounded-2xl text-xs font-semibold shadow-2xl flex items-center gap-2.5 animate-fadeIn border ${
          toast.type === 'error' 
            ? 'bg-rose-950/90 border-rose-800 text-rose-200 shadow-rose-950/50' 
            : toast.type === 'info'
            ? 'bg-cyan-950/90 border-cyan-800 text-cyan-200 shadow-cyan-950/50'
            : 'bg-emerald-950/90 border-emerald-800 text-emerald-200 shadow-emerald-950/50'
        }`}>
          {toast.type === 'error' ? <AlertCircle className="w-4 h-4 text-rose-400" /> : <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
          {toast.msg}
        </div>
      )}

      {/* Header Banner */}
      <div className="glass-card rounded-3xl p-6 border border-emerald-500/30 bg-gradient-to-r from-emerald-950/40 via-slate-900 to-cyan-950/40 relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-cyan-400 text-slate-950 flex items-center justify-center font-bold shadow-lg shadow-emerald-500/20 shrink-0">
              <MapPin className="w-7 h-7" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-950 border border-emerald-800 text-emerald-400 text-xs font-mono mb-1">
                <Sparkles className="w-3.5 h-3.5" /> B2B Lead Extractor & Campaign
              </div>
              <h2 className="text-2xl font-heading font-extrabold text-white">
                Google Maps Lead Extractor & POS Campaign Engine
              </h2>
              <p className="text-xs text-slate-300 mt-0.5">
                Extract restaurants & businesses from Google Maps by location and dispatch personalized WhatsApp POS proposals
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowCampaignModal(true)}
              disabled={selectedLeadIds.size === 0}
              className="emerald-glow-btn text-slate-950 font-bold text-xs px-5 py-2.5 rounded-xl flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-4 h-4 fill-slate-950" /> Send POS Proposal ({selectedLeadIds.size})
            </button>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-5 border-t border-slate-800/80 text-xs">
          <div className="bg-slate-950/50 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Total Extracted</span>
            <strong className="text-lg text-white font-mono">{leads.length} Leads</strong>
          </div>
          <div className="bg-slate-950/50 p-3 rounded-2xl border border-slate-800">
            <span className="text-emerald-400 block mb-0.5">WhatsApp Ready</span>
            <strong className="text-lg text-emerald-300 font-mono">{mobileCount} Numbers</strong>
          </div>
          <div className="bg-slate-950/50 p-3 rounded-2xl border border-slate-800">
            <span className="text-cyan-400 block mb-0.5">Selected</span>
            <strong className="text-lg text-cyan-300 font-mono">{selectedLeadIds.size} Selected</strong>
          </div>
          <div className="bg-slate-950/50 p-3 rounded-2xl border border-slate-800">
            <span className="text-amber-400 block mb-0.5">Cost</span>
            <strong className="text-lg text-amber-300 font-mono">100% Free ($0)</strong>
          </div>
        </div>
      </div>

      {/* Search & Extraction Bar */}
      <div className="glass-card rounded-3xl p-6 border border-slate-800 space-y-4">
        <div className="flex items-center gap-2 text-white font-bold text-sm">
          <Search className="w-4 h-4 text-emerald-400" /> Search Google Maps for Business Leads
        </div>

        <form onSubmit={handleScrape} className="grid grid-cols-1 md:grid-cols-12 gap-4">
          <div className="md:col-span-4">
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-rose-400" /> Location (ஊர் / இடம்)
            </label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g. Trincomalee, Sri Lanka"
              className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 outline-none transition-colors"
            />
          </div>

          <div className="md:col-span-4">
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
              <Store className="w-3.5 h-3.5 text-cyan-400" /> Business Category (வகை)
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 outline-none transition-colors"
            >
              {PRESET_CATEGORIES.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Limit (எண்ணிக்கை)
            </label>
            <select
              value={limit}
              onChange={(e) => setLimit(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 outline-none transition-colors"
            >
              <option value="10">10 Leads</option>
              <option value="20">20 Leads</option>
              <option value="30">30 Leads</option>
              <option value="50">50 Leads</option>
            </select>
          </div>

          <div className="md:col-span-2 flex items-end">
            <button
              type="submit"
              disabled={scraping}
              className="w-full bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-bold text-xs py-2.5 rounded-xl flex items-center justify-center gap-2 transition-all shadow-md shadow-emerald-950 disabled:opacity-50"
            >
              {scraping ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              {scraping ? 'Extracting...' : 'Extract Leads'}
            </button>
          </div>
        </form>

        {/* Quick Locations pills */}
        <div className="flex flex-wrap items-center gap-2 pt-2 text-xs">
          <span className="text-slate-400 text-[11px]">Quick Locations:</span>
          {PRESET_LOCATIONS.map((loc) => (
            <button
              key={loc}
              type="button"
              onClick={() => setLocation(loc)}
              className={`px-2.5 py-1 rounded-lg border text-[11px] transition-all ${
                location === loc
                  ? 'bg-emerald-950 border-emerald-700 text-emerald-300'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {loc}
            </button>
          ))}
        </div>
      </div>

      {/* Leads Table Card */}
      <div className="glass-card rounded-3xl border border-slate-800 overflow-hidden">
        {/* Table Toolbar */}
        <div className="p-5 border-b border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={toggleSelectAll}
              className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 hover:text-white flex items-center gap-1.5"
            >
              {selectedLeadIds.size === displayedLeads.length && displayedLeads.length > 0 ? (
                <CheckSquare className="w-4 h-4 text-emerald-400" />
              ) : (
                <Square className="w-4 h-4 text-slate-500" />
              )}
              Select All ({displayedLeads.length})
            </button>

            <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
              <input
                type="checkbox"
                checked={filterMobileOnly}
                onChange={(e) => setFilterMobileOnly(e.target.checked)}
                className="rounded border-slate-700 text-emerald-500 focus:ring-0"
              />
              <span>Mobile / WhatsApp Only</span>
            </label>
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto">
            <div className="relative flex-1 md:w-64">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder="Filter by name / phone..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-slate-700 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 outline-none"
              />
            </div>

            <button
              onClick={handleExportCSV}
              className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs text-cyan-300 font-semibold flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" /> Export CSV
            </button>
          </div>
        </div>

        {/* Table Content */}
        <div className="overflow-x-auto">
          {displayedLeads.length === 0 ? (
            <div className="p-12 text-center text-slate-500 text-xs space-y-2">
              <Store className="w-8 h-8 text-slate-600 mx-auto stroke-1" />
              <p>No leads found. Enter a location above and click &quot;Extract Leads&quot;.</p>
            </div>
          ) : (
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-950/60 border-b border-slate-800 text-slate-400 font-semibold">
                  <th className="p-3.5 w-10 text-center">#</th>
                  <th className="p-3.5">Business Name</th>
                  <th className="p-3.5">Phone Number</th>
                  <th className="p-3.5">Category</th>
                  <th className="p-3.5">Location & Address</th>
                  <th className="p-3.5">Rating</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {displayedLeads.map((lead, idx) => {
                  const isSelected = selectedLeadIds.has(lead.id);
                  return (
                    <tr
                      key={lead.id}
                      className={`hover:bg-slate-900/40 transition-colors ${
                        isSelected ? 'bg-emerald-950/20' : ''
                      }`}
                    >
                      <td className="p-3.5 text-center">
                        <button
                          type="button"
                          onClick={() => toggleSelectLead(lead.id)}
                          className="text-slate-400 hover:text-white"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-emerald-400" />
                          ) : (
                            <Square className="w-4 h-4 text-slate-600" />
                          )}
                        </button>
                      </td>
                      <td className="p-3.5 font-semibold text-white">
                        <div className="flex items-center gap-2">
                          <span>{lead.name}</span>
                          {lead.mapsUrl && (
                            <a
                              href={lead.mapsUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-slate-500 hover:text-cyan-400"
                              title="Open in Google Maps"
                            >
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          )}
                        </div>
                      </td>
                      <td className="p-3.5 font-mono">
                        {lead.phoneNumber ? (
                          <div className="flex items-center gap-1.5">
                            <span className="text-slate-200">+{lead.phoneNumber}</span>
                            {lead.isMobile ? (
                              <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] font-sans">
                                WhatsApp
                              </span>
                            ) : (
                              <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 text-[10px] font-sans">
                                Landline
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="text-slate-500 italic">Not Listed</span>
                        )}
                      </td>
                      <td className="p-3.5 text-slate-300">
                        <span className="px-2 py-0.5 rounded-full bg-slate-950 border border-slate-800 text-[11px]">
                          {lead.category || 'Business'}
                        </span>
                      </td>
                      <td className="p-3.5 text-slate-400 max-w-xs truncate" title={lead.address}>
                        {lead.address || lead.location || '-'}
                      </td>
                      <td className="p-3.5">
                        {lead.rating ? (
                          <div className="flex items-center gap-1 text-amber-400 font-mono">
                            <Star className="w-3.5 h-3.5 fill-amber-400" />
                            <span>{lead.rating}</span>
                            <span className="text-slate-500 text-[10px]">({lead.reviews})</span>
                          </div>
                        ) : (
                          <span className="text-slate-500">-</span>
                        )}
                      </td>
                      <td className="p-3.5">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium ${
                            lead.status === 'Contacted'
                              ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                              : lead.status === 'Demo Booked'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : 'bg-slate-950 text-slate-400 border border-slate-800'
                          }`}
                        >
                          {lead.status || 'New'}
                        </span>
                      </td>
                      <td className="p-3.5 text-right space-x-2">
                        <button
                          type="button"
                          onClick={() => handleDeleteLead(lead.id)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-950/40"
                          title="Delete Lead"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* WhatsApp Campaign Modal / Drawer */}
      {showCampaignModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="glass-card bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 space-y-5 shadow-2xl animate-scaleUp max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-white font-bold text-base">
                <Send className="w-5 h-5 text-emerald-400" /> WhatsApp POS Campaign Dispatcher
              </div>
              <button
                type="button"
                onClick={() => !campaignRunning && setShowCampaignModal(false)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1 bg-slate-950 rounded-lg border border-slate-800"
              >
                Close
              </button>
            </div>

            {/* Campaign Config */}
            <div className="space-y-4 text-xs">
              <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950 border border-slate-800">
                <span className="text-slate-300 font-semibold">
                  Selected Recipients: <strong className="text-emerald-400">{selectedLeadIds.size} Leads</strong>
                </span>
                <span className="text-slate-400">Instance: <strong className="text-white font-mono">saas_instance</strong></span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Select Proposal Template (விளம்பர மாதிரி)
                </label>
                <select
                  value={selectedTemplate}
                  onChange={(e) => selectTemplateHandler(e.target.value)}
                  disabled={campaignRunning}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 outline-none"
                >
                  {PROPOSAL_TEMPLATES.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-slate-300">
                    Message Content (with dynamic tags)
                  </label>
                  <span className="text-[11px] text-slate-500">
                    Tags: <code className="text-emerald-400">{'{business_name}'}</code>, <code className="text-cyan-400">{'{location}'}</code>
                  </span>
                </div>
                <textarea
                  value={customMessage}
                  onChange={(e) => setCustomMessage(e.target.value)}
                  disabled={campaignRunning}
                  rows={6}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl p-3 text-xs text-slate-200 font-sans outline-none leading-relaxed"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Safe Anti-Ban Delay
                  </label>
                  <select
                    value={delaySeconds}
                    onChange={(e) => setDelaySeconds(e.target.value)}
                    disabled={campaignRunning}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs text-slate-200 outline-none"
                  >
                    <option value="8">8 Seconds (Fast)</option>
                    <option value="12">12 Seconds (Recommended Safe)</option>
                    <option value="15">15 Seconds (Extra Safe)</option>
                    <option value="20">20 Seconds (High Protection)</option>
                  </select>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 flex items-center gap-2 text-[11px] text-slate-400">
                  <Clock className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>
                    Estimated Time: ~{Math.ceil((selectedLeadIds.size * delaySeconds) / 60)} mins for {selectedLeadIds.size} messages.
                  </span>
                </div>
              </div>

              {/* Progress & Logs */}
              {campaignRunning && (
                <div className="p-4 rounded-2xl bg-slate-950 border border-emerald-500/40 space-y-2 animate-fadeIn">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-emerald-400 flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin" /> Dispatching Campaign...
                    </span>
                    <span className="font-mono text-slate-300">
                      {campaignProgress.current} / {campaignProgress.total}
                    </span>
                  </div>
                  <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-emerald-500 h-2 transition-all duration-300"
                      style={{
                        width: `${
                          campaignProgress.total > 0
                            ? (campaignProgress.current / campaignProgress.total) * 100
                            : 0
                        }%`,
                      }}
                    />
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                    <span>Sent: {campaignProgress.sent}</span>
                    <span>Failed: {campaignProgress.failed}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowCampaignModal(false)}
                disabled={campaignRunning}
                className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white bg-slate-950 border border-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleStartCampaign}
                disabled={campaignRunning || selectedLeadIds.size === 0}
                className="emerald-glow-btn text-slate-950 font-bold text-xs px-6 py-2.5 rounded-xl flex items-center gap-2 disabled:opacity-50"
              >
                {campaignRunning ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4 fill-slate-950" />
                )}
                {campaignRunning ? 'Dispatching...' : `Start Campaign (${selectedLeadIds.size})`}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
