import {
  IsString,
  IsOptional,
  Length,
  IsEnum,
  IsInt,
  Min,
  Max,
} from 'class-validator';
import { DurationType } from '@prisma/client';

export class UpdateWarrantyDto {
  @IsOptional()
  @IsString()
  @Length(2, 100, { message: 'Warranty name must be between 2 and 100 characters' })
  name?: string;

  @IsOptional()
  @IsString()
  @Length(0, 500, { message: 'Description cannot exceed 500 characters' })
  description?: string;

  @IsOptional()
  @IsInt({ message: 'Duration must be an integer' })
  @Min(1, { message: 'Duration must be at least 1' })
  @Max(1000, { message: 'Duration cannot exceed 1000' })
  duration?: number;

  @IsOptional()
  @IsEnum(DurationType, { message: 'Duration type must be DAYS, MONTHS, or YEARS' })
  durationType?: DurationType;

  @IsOptional()
  isActive?: boolean | string;

  @IsOptional()
  @IsString()
  businessId?: string;

  @IsOptional()
  branchIds?: string[] | string;

  @IsOptional()
  @IsString()
  updatedById?: string;
}
