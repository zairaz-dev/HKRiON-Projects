# 🪟 SHADEIT BLINDS — Premium Window & Architectural Shade Solutions

A modern, high-performance web platform and Content Management System (CMS) built for **SHADEIT BLINDS**, specializing in custom indoor blinds, motorized drapery, architectural outdoor awnings, pergolas, and heavy-duty weather protection screens.

---

## 🚀 Tech Stack

- **Framework**: [Next.js 16 (App Router)](https://nextjs.org/) & [React 19](https://react.dev/)
- **Language**: TypeScript 5
- **Styling**: [Tailwind CSS v4](https://tailwindcss.com/) & Vanilla CSS Tokens
- **Animations**: [Framer Motion](https://www.framer.com/motion/)
- **Icons**: [Lucide React](https://lucide.dev/)
- **Database & ORM**: [Prisma ORM](https://www.prisma.io/) with SQLite
- **Security & Auth**: JWT (`jose`), Password Hashing (`bcryptjs`), and Dual-Layer Cookie Persistence
- **Deployment & Server**: Universal Host Binding (`-H 0.0.0.0 -p 3001`) for Seamless LAN & Multi-Device Testing

---

## ✨ Key Features

### 🌐 Public Client Experience
- **13 Core Product Catalog**: Complete showcase with high-resolution imagery, feature highlights, and direct WhatsApp inquiry CTAs.
- **Fast Search & Filter Navigation**: URL query parameter-based filtering (`<Link href="/products?cat=..." scroll={false}>`) for instant hydration-safe navigation.
- **Interactive CMS-Driven Pages**: Dynamic Home, About Us, Projects, Services, and Contact pages with zero client hydration delay.
- **Direct Lead & Quote Inquiries**: Instant quote submission forms with phone/WhatsApp integrations.
- **Mobile-First & Ultra Responsive**: Verified across all viewports (320px mobile to ultra-wide desktop) with zero horizontal overflow (`overflow-x-hidden`).

### 🛡️ Admin & CMS Dashboard (`/admin`)
- **Authentication System**: Secure JWT cookie-based SSR authentication with fail-safe middleware.
- **Product & Category Management**: Create, update, toggle active states, and organize product catalogs.
- **Inquiry Management System**: Real-time customer quote requests, lead status tracking (`PENDING`, `CONTACTED`, `COMPLETED`).
- **Live Visual CMS**:
  - **Homepage CMS Editor**: Customize Hero titles, subtitles, editorial philosophy, stats, and CTAs.
  - **About Page CMS Editor**: Modify story, brand statements, mission, vision, and experience metrics.
  - **Contact Page CMS Editor**: Update business addresses, phone numbers, WhatsApp, and operating hours dynamically.
- **User & Access Management**: Manage administrative accounts and roles.

---

## 🪟 13 Core Product Catalog Coverage

1. **Monsoon Blinds** — Heavy-duty weather and wind protection blinds
2. **Zebra Blinds** — Dual-layer sheer and privacy light control
3. **Roller Blinds** — Sleek blackout and sun-filtering motorized roller shades
4. **Roman Blinds** — Elegant soft fabric folded drapery shades
5. **Curtains** — Acoustic, sheer, and luxury blackout curtain drapery
6. **Vertical Blinds** — Versatile vertical slat blinds for wide windows & offices
7. **Timber Venetian Blinds** — Premium natural wooden slat blinds
8. **Awning** — Retractable and fixed architectural outdoor patio awnings
9. **Canopy** — Weatherproof entrance and balcony canopy coverings
10. **Pergola** — Louvered and motorized architectural outdoor pergolas
11. **Outdoor Teak Sunbed** — Weatherproof teak luxury outdoor furniture
12. **Outdoor Fabric** — Marine-grade, UV-treated, mold-resistant outdoor textiles
13. **Outdoor UV Clear PVC** — Crystal clear waterproof rain and wind barrier curtains

---

## 📁 Project Structure

```text
shadeitBlinds/
├── prisma/
│   ├── dev.db               # SQLite database file
│   └── schema.prisma        # Prisma data models & migrations
├── public/                  # Static assets & product imagery
├── src/
│   ├── app/
│   │   ├── (public)/        # Public routes: /, /about, /contact, /products, /projects, /services
│   │   ├── admin/           # Admin Dashboard & CMS Management routes
│   │   ├── api/             # API routes (Auth, CMS, Inquiries, Products, Categories)
│   │   ├── login/           # Secure Admin Login Page
│   │   ├── globals.css      # Design system tokens and global CSS
│   │   └── layout.tsx       # Root layout with navigation and footer
│   ├── components/          # Reusable UI & Client/Server components
│   ├── core/                # Core architecture & shared business logic
│   ├── data/                # Static fallbacks and catalog constants
│   ├── lib/                 # Prisma client instance, Auth helpers, and utilities
│   ├── middleware.ts        # Route protection & cookie parser
│   └── services/            # Database query services & CMS data handlers
├── package.json
└── tsconfig.json
```

---

## 🛠️ Getting Started

### 1. Prerequisites
- **Node.js**: v18.17 or later (Node.js 20+ recommended)
- **npm**, **pnpm**, or **yarn**

### 2. Installation

Clone the repository and install dependencies:

```bash
git clone <repository-url>
cd shadeitBlinds
npm install
```

### 3. Database Initialization

Generate Prisma client and initialize SQLite database:

```bash
npx prisma generate
npx prisma db push
```

*(Optional: If you have seed scripts)*
```bash
npx prisma db seed
```

### 4. Run Development Server

Start the server on `0.0.0.0:3001` (accessible via localhost and local network LAN IP):

```bash
npm run dev
```

Visit the application at:
- **Local**: [http://localhost:3001](http://localhost:3001)
- **LAN IP**: `http://<your-local-ip>:3001` (e.g. `http://192.168.1.x:3001`)

---

## 📜 Available Scripts

| Command | Description |
| :--- | :--- |
| `npm run dev` | Starts Next.js development server on `0.0.0.0:3001` |
| `npm run build` | Builds the production bundle |
| `npm run start` | Runs the production build on `0.0.0.0:3001` |
| `npm run lint` | Runs ESLint check |
| `npx prisma studio` | Opens interactive visual database browser |

---

## 🏛️ Architectural Standards & Core Rules

- **Hydration-Safe Form Submissions**: Authentication and mission-critical actions use native HTML forms with HTTP 303 Redirects to guarantee instant response regardless of client hydration status.
- **Universal Host & LAN Binding**: Dev and production servers explicitly bind to `-H 0.0.0.0 -p 3001` to enable multi-device and mobile testing over Wi-Fi without CORS/HMR blocks.
- **Dual-Layer Cookie Persistence**: Cookies are managed seamlessly across server route handlers and client-side helpers with lax SameSite settings for reliable LAN authentication.
- **Zero Horizontal Scroll**: Strict mobile viewport enforcement with `overflow-x-hidden` containers and responsive CSS grid collapsing.

---

## 📄 License

Private & Proprietary — **SHADEIT BLINDS**. All rights reserved.
