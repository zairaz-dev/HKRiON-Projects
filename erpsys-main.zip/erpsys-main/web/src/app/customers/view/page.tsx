"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import {
  User as UserIcon,
  Phone,
  Mail,
  Building2,
  Calendar,
  AlertCircle,
  CheckCircle,
  Loader2,
  ArrowLeft,
  DollarSign,
  TrendingUp,
  CreditCard,
  History,
  Coins,
  Printer,
  Eye,
  Upload,
  FileText,
  RotateCcw,
  Filter,
  X,
  Trash2,
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { DataTable, ColumnDef } from "@/components/ui/table";
import { authService } from "@/services/auth-service";
import { customerService } from "@/services/customer-service";
import { getFullAssetUrl } from "@/lib/utils";
import { User } from "@hkr/types";

import { useCustomerByIdQuery, useBranchesQuery } from "@/features/customers/hooks/use-customers";
import { usePaymentMethodsQuery } from "@/features/payment-methods/hooks/use-payment-methods";
import {
  useSalesQuery,
  useCustomerAdvancesQuery,
  SaleItem,
  CustomerAdvanceItem,
  SaleDetailDialog,
  ReceiptPreview,
  SalePaymentDialog,
} from "@/features/pos";
import {
  CustomerPaymentDialog,
  CustomerPaymentsListDialog,
  useCustomerPaymentsQuery,
  useRefundCustomerAdvanceMutation,
  useDeleteCustomerPaymentMutation,
} from "@/features/customer-payments";
import { useCurrency } from "@/hooks/use-currency";

function CustomerViewPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const customerId = searchParams.get("id") || "";

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    if (typeof window !== "undefined") {
      return authService.getCurrentUser();
    }
    return null;
  });
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(() => {
    if (typeof window !== "undefined") {
      return authService.isAuthenticated();
    }
    return null;
  });
  const [activeTab, setActiveTab] = useState<"invoices" | "payments" | "advances" | "statement">("invoices");
  const [statementFilter, setStatementFilter] = useState<"all" | "month" | "30days" | "year">("all");

  // Photo upload state
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState<boolean>(false);

  // Modal states for POS receipts
  const [selectedSaleIdForDetail, setSelectedSaleIdForDetail] = useState<string | null>(null);
  const [selectedSaleForReceipt, setSelectedSaleForReceipt] = useState<any | null>(null);
  const [selectedSaleForPayment, setSelectedSaleForPayment] = useState<any | null>(null);
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);

  // Main Advance refund state
  const [isRefundOpen, setIsRefundOpen] = useState<boolean>(false);
  const [refundAmount, setRefundAmount] = useState<number>(0);
  const [refundNotes, setRefundNotes] = useState<string>("");
  const [selectedBranchId, setSelectedBranchId] = useState<string>("");
  const [selectedPaymentMethodId, setSelectedPaymentMethodId] = useState<string>("");
  const refundMutation = useRefundCustomerAdvanceMutation();
  const deletePaymentMutation = useDeleteCustomerPaymentMutation();

  // Notification banners
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (errorMessage) {
      const timer = setTimeout(() => setErrorMessage(""), 5000);
      return () => clearTimeout(timer);
    }
  }, [errorMessage]);

  // URL-driven pagination/search for transactions table
  const currentPage = Number(searchParams.get("page")) || 1;
  const searchQuery = searchParams.get("search") || "";
  const limit = Number(searchParams.get("limit")) || 10;

  // Authenticate
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  const businessId = currentUser?.businessId || "";
  const { symbol, format } = useCurrency(businessId);

  const { data: branches = [] } = useBranchesQuery(businessId);
  const { data: paymentMethods = [] } = usePaymentMethodsQuery(businessId, selectedBranchId || undefined, true);

  useEffect(() => {
    if (branches.length > 0 && !selectedBranchId) {
      setSelectedBranchId(branches[0].id);
    }
  }, [branches, selectedBranchId]);

  useEffect(() => {
    if (paymentMethods.length > 0 && !selectedPaymentMethodId) {
      setSelectedPaymentMethodId(paymentMethods[0].id);
    }
  }, [paymentMethods, selectedPaymentMethodId]);

  // Queries
  const { data: customer, isLoading: customerLoading, error: customerError, refetch: refetchCustomer } = useCustomerByIdQuery(customerId, businessId);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !customerId) return;

    if (file.size > 5 * 1024 * 1024) {
      setErrorMessage("Image file size must be under 5MB.");
      return;
    }

    try {
      setIsUploadingPhoto(true);
      await customerService.uploadImage(file, customerId);
      setSuccessMessage("Customer profile photo updated successfully!");
      refetchCustomer();
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to upload photo.");
    } finally {
      setIsUploadingPhoto(false);
    }
  };

  const handleRefundSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!customerId || refundAmount <= 0) return;
    if (refundAmount > remainingAdvance) {
      setErrorMessage(`Refund amount cannot exceed available advance balance of ${format(remainingAdvance)}.`);
      return;
    }
    try {
      await refundMutation.mutateAsync({
        customerId,
        amount: refundAmount,
        paymentMethodId: selectedPaymentMethodId || paymentMethods[0]?.id || "",
        branchId: selectedBranchId || branches[0]?.id || "",
        businessId,
        notes: refundNotes,
      });
      setSuccessMessage(`Successfully refunded ${format(refundAmount)} to ${customer?.name || "Customer"}!`);
      setIsRefundOpen(false);
      setRefundAmount(0);
      setRefundNotes("");
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to process advance refund.");
    }
  };

  const isWalkIn = Boolean(
    customer &&
      (customer.isDefault ||
        customer.name?.toLowerCase() === "walk-in customer" ||
        customer.allowCredit === false)
  );

  const handleDeletePayment = async (paymentId: string) => {
    if (!window.confirm("Are you sure you want to delete this payment record? This will restore the customer due or opening balance.")) {
      return;
    }
    try {
      await deletePaymentMutation.mutateAsync({ id: paymentId, businessId });
      setSuccessMessage("Payment record deleted successfully!");
      refetchCustomer();
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to delete payment record.");
    }
  };

  // Fetch sales for this customer
  const { data: salesResponse, isLoading: salesLoading } = useSalesQuery(
    businessId,
    {
      customerId,
      status: "FINAL",
      page: currentPage,
      limit,
      search: searchQuery || undefined,
    }
  );

  // Fetch customer advances
  const { data: advances = [], isLoading: advancesLoading } = useCustomerAdvancesQuery(customerId, businessId);

  const sales = salesResponse?.data || [];
  const meta = salesResponse?.meta || { total: 0, totalPages: 1 };

  // Calculate totals
  // Query Customer Payments
  const { data: customerPayments = [], isLoading: paymentsLoading } = useCustomerPaymentsQuery(
    businessId,
    { customerId }
  );

  const allCustomerSales = customer?.sales || [];

  const totalSalesSpent = React.useMemo(() => {
    if (!allCustomerSales || !Array.isArray(allCustomerSales)) return 0;
    return allCustomerSales.reduce((sum: number, sale: any) => sum + sale.grandTotal, 0);
  }, [allCustomerSales]);

  const totalAmountPaid = React.useMemo(() => {
    if (!allCustomerSales || !Array.isArray(allCustomerSales)) return 0;
    return allCustomerSales.reduce((sum: number, sale: any) => sum + (sale.amountPaid || 0), 0);
  }, [allCustomerSales]);

  const totalOutstanding = Math.max(
    0,
    totalSalesSpent + (customer?.openingBalance || 0) - totalAmountPaid
  );

  const remainingAdvance = React.useMemo(() => {
    if (!advances || !Array.isArray(advances)) return 0;
    return advances.reduce((sum: number, adv: any) => sum + adv.amountRemaining, 0);
  }, [advances]);

  // Invoices columns definition
  const invoiceColumns: ColumnDef<SaleItem>[] = [
    {
      header: "Invoice No",
      render: (s) => (
        <span className="font-mono font-bold text-foreground text-xs">
          {s.invoiceNumber}
        </span>
      ),
    },
    {
      header: "Date",
      render: (s) => (
        <span className="text-xs text-muted-foreground flex items-center gap-1.5 font-medium">
          <Calendar className="h-3.5 w-3.5" />
          {new Date(s.saleDate).toLocaleDateString()}
        </span>
      ),
    },
    {
      header: "Branch",
      render: (s) => (
        <span className="text-xs font-semibold text-foreground">
          {s.branch?.name || "N/A"}
        </span>
      ),
    },
    {
      header: "Grand Total",
      align: "right",
      render: (s) => (
        <span className="font-extrabold text-foreground text-xs inline-block w-full text-right font-mono">
          {format(s.grandTotal)}
        </span>
      ),
    },
    {
      header: "Paid Amount",
      align: "right",
      render: (s) => (
        <span className="font-semibold text-emerald-500 text-xs inline-block w-full text-right font-mono">
          {format(s.amountPaid || 0)}
        </span>
      ),
    },
    {
      header: "Outstanding Due",
      align: "right",
      render: (s) => {
        const remaining = Math.max(0, s.grandTotal - (s.amountPaid || 0));
        return (
          <span className={`font-bold text-xs inline-block w-full text-right font-mono ${remaining > 0 ? "text-rose-500" : "text-muted-foreground"}`}>
            {format(remaining)}
          </span>
        );
      },
    },
    {
      header: "Payment Status",
      render: (s) => {
        const status = s.paymentStatus || "DUE";
        let badgeClass = "bg-rose-500/10 border-rose-500/25 text-rose-600 dark:text-rose-400";
        if (status === "PAID") {
          badgeClass = "bg-emerald-500/10 border-emerald-500/25 text-emerald-600 dark:text-emerald-400";
        } else if (status === "PARTIAL") {
          badgeClass = "bg-amber-500/10 border-amber-500/25 text-amber-600 dark:text-amber-400";
        }
        return (
          <span className={`inline-flex items-center px-2 py-0.5 rounded border text-[10px] font-extrabold tracking-wide uppercase ${badgeClass}`}>
            {status}
          </span>
        );
      },
    },
    {
      header: "Action",
      render: (s) => (
        <div className="flex items-center gap-1.5">
          <Button
            size="sm"
            variant="outline"
            className="h-7 w-7 p-0"
            onClick={() => setSelectedSaleIdForDetail(s.id)}
            title="View Invoice"
          >
            <Eye className="h-3.5 w-3.5" />
          </Button>
          <Button
            variant="secondary"
            className="h-7 px-2.5 text-[10px] font-bold flex items-center gap-1 text-muted-foreground hover:text-foreground border border-border/40"
            onClick={() => setSelectedSaleForReceipt(s)}
            title="Print Receipt"
          >
            <Printer className="h-3 w-3" /> Print
          </Button>
        </div>
      ),
    },
  ];

  // Payments columns definition
  const paymentColumns: ColumnDef<any>[] = [
    {
      header: "Payment No",
      render: (p) => (
        <span className="font-mono font-bold text-foreground text-xs">
          {p.paymentNumber}
        </span>
      ),
    },
    {
      header: "Date",
      render: (p) => (
        <span className="text-xs text-muted-foreground flex items-center gap-1.5 font-medium whitespace-nowrap">
          <Calendar className="h-3.5 w-3.5" />
          {new Date(p.paymentDate).toLocaleDateString("en-IN", {
            day: "2-digit",
            month: "short",
            year: "numeric",
          })}
        </span>
      ),
    },
    {
      header: "Payment Method",
      render: (p) => (
        <span className="text-xs font-semibold text-foreground">
          {p.paymentMethod?.name || "Direct"}
        </span>
      ),
    },
    {
      header: "Amount Paid",
      align: "right",
      render: (p) => (
        <span className="font-extrabold text-emerald-600 dark:text-emerald-400 text-xs font-mono inline-block w-full text-right">
          {format(p.amount)}
        </span>
      ),
    },
    {
      header: "Notes / Allocation",
      render: (p) => (
        <span className="text-xs text-foreground/80 max-w-[280px] truncate block" title={p.notes || ""}>
          {p.notes || "-"}
        </span>
      ),
    },
    {
      header: "Actions",
      render: (p) => (
        <div className="flex items-center gap-2">
          {!isWalkIn && (
            <Button
              size="sm"
              variant="outline"
              className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive hover:border-destructive/40"
              onClick={() => handleDeletePayment(p.id)}
              disabled={deletePaymentMutation.isPending}
              title="Delete Payment"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          )}
        </div>
      ),
    },
  ];

  // Advances columns definition
  const advanceColumns: ColumnDef<CustomerAdvanceItem>[] = [
    {
      header: "Receipt No",
      render: (a) => (
        <span className="font-mono font-bold text-foreground text-xs">
          {a.advanceNumber}
        </span>
      ),
    },
    {
      header: "Date",
      render: (a) => (
        <span className="text-xs text-muted-foreground flex items-center gap-1.5 font-medium">
          <Calendar className="h-3.5 w-3.5" />
          {new Date(a.advanceDate).toLocaleDateString()}
        </span>
      ),
    },
    {
      header: "Payment Method",
      render: (a) => (
        <span className="text-xs font-semibold text-foreground">
          {a.paymentMethod?.name}
        </span>
      ),
    },
    {
      header: "Total Advance",
      align: "right",
      render: (a) => (
        <span className="font-extrabold text-foreground text-xs inline-block w-full text-right font-mono">
          {format(a.amount)}
        </span>
      ),
    },
    {
      header: "Remaining Credit",
      align: "right",
      render: (a) => (
        <span className={`font-bold text-xs inline-block w-full text-right font-mono ${a.amountRemaining > 0 ? "text-emerald-500 font-extrabold" : "text-muted-foreground"}`}>
          {format(a.amountRemaining)}
        </span>
      ),
    },
    {
      header: "Status",
      render: (a) => (
        <span
          className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold border uppercase tracking-wider ${
            a.amountRemaining > 0
              ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
              : "bg-muted text-muted-foreground border-border"
          }`}
        >
          {a.amountRemaining > 0 ? "Available" : "Consumed"}
        </span>
      ),
    },
  ];

  const handlePageChange = (newPage: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", String(newPage));
    router.push(`?id=${customerId}&${params.toString()}`);
  };

  const handleSearchChange = (newSearch: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1");
    if (newSearch) {
      params.set("search", newSearch);
    } else {
      params.delete("search");
    }
    router.push(`?id=${customerId}&${params.toString()}`);
  };

  const handleLimitChange = (newLimit: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("limit", String(newLimit));
    params.set("page", "1");
    router.push(`?id=${customerId}&${params.toString()}`);
  };

  // Calculate Ledger Entries for Account Statement
  const ledgerEntries = React.useMemo(() => {
    if (!customer) return [];

    interface RawEvent {
      date: string;
      type: "OPENING_BALANCE" | "INVOICE" | "PAYMENT" | "ADVANCE";
      ref: string;
      description: string;
      debit: number;
      credit: number;
    }

    const events: RawEvent[] = [];

    // 1. Opening Balance (Initial Opening Due before any settlements)
    const openingPaymentsTotal = (customerPayments || [])
      .filter((p: any) => p.notes?.includes("Opening Balance"))
      .reduce((sum: number, p: any) => sum + p.amount, 0);
    const initialOpeningBalance = (customer.openingBalance || 0) + openingPaymentsTotal;

    if (initialOpeningBalance > 0) {
      events.push({
        date: customer.createdAt || new Date().toISOString(),
        type: "OPENING_BALANCE",
        ref: "OPENING",
        description: "Initial Balance (Pre-existing Due)",
        debit: initialOpeningBalance,
        credit: 0,
      });
    }

    // 2. Sales Invoices (Full lifetime sales)
    (customer?.sales || salesResponse?.data || []).forEach((s: any) => {
      events.push({
        date: s.saleDate,
        type: "INVOICE",
        ref: s.invoiceNumber,
        description: `Sales Invoice #${s.invoiceNumber}`,
        debit: s.grandTotal,
        credit: 0,
      });
    });

    // 3. Payments Received
    (customerPayments || []).forEach((p: any) => {
      events.push({
        date: p.paymentDate,
        type: "PAYMENT",
        ref: p.paymentNumber,
        description: `Payment Received (${p.paymentMethod?.name || "Direct"})${p.notes ? ` - ${p.notes}` : ""}`,
        debit: 0,
        credit: p.amount,
      });
    });

    // Sort chronologically ascending
    events.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    // Filter by statementFilter
    const now = new Date();
    const filteredEvents = events.filter((ev) => {
      if (statementFilter === "all") return true;
      const evDate = new Date(ev.date);
      if (statementFilter === "month") {
        return evDate.getMonth() === now.getMonth() && evDate.getFullYear() === now.getFullYear();
      }
      if (statementFilter === "30days") {
        const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        return evDate >= thirtyDaysAgo;
      }
      if (statementFilter === "year") {
        return evDate.getFullYear() === now.getFullYear();
      }
      return true;
    });

    // Compute running balance
    let currentBalance = 0;
    return filteredEvents.map((ev, idx) => {
      currentBalance += ev.debit - ev.credit;
      return {
        id: `${ev.type}-${ev.ref}-${idx}`,
        ...ev,
        balance: currentBalance,
      };
    });
  }, [customer, salesResponse, customerPayments, statementFilter]);

  const ledgerColumns: ColumnDef<any>[] = [
    {
      header: "Date",
      render: (item) => (
        <span className="text-xs text-muted-foreground flex items-center gap-1.5 font-medium whitespace-nowrap">
          <Calendar className="h-3.5 w-3.5" />
          {new Date(item.date).toLocaleDateString("en-IN", {
            day: "2-digit",
            month: "short",
            year: "numeric",
          })}
        </span>
      ),
    },
    {
      header: "Type",
      render: (item) => {
        let badgeClass = "bg-primary/10 text-primary border-primary/20";
        if (item.type === "INVOICE") badgeClass = "bg-rose-500/10 text-rose-500 border-rose-500/20";
        if (item.type === "PAYMENT") badgeClass = "bg-emerald-500/10 text-emerald-500 border-emerald-500/20";
        if (item.type === "OPENING_BALANCE") badgeClass = "bg-amber-500/10 text-amber-500 border-amber-500/20";
        return (
          <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold border uppercase tracking-wider ${badgeClass}`}>
            {item.type.replace("_", " ")}
          </span>
        );
      },
    },
    {
      header: "Ref / Voucher",
      render: (item) => (
        <span className="font-mono text-xs font-bold text-foreground">
          {item.ref}
        </span>
      ),
    },
    {
      header: "Description",
      render: (item) => (
        <span className="text-xs text-foreground/90 max-w-[260px] truncate block" title={item.description}>
          {item.description}
        </span>
      ),
    },
    {
      header: "Credit (Paid -)",
      align: "right",
      render: (item) => (
        <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 font-mono inline-block w-full text-right">
          {item.credit > 0 ? format(item.credit) : "-"}
        </span>
      ),
    },
    {
      header: "Debit (Due +)",
      align: "right",
      render: (item) => (
        <span className="text-xs font-bold text-rose-600 dark:text-rose-400 font-mono inline-block w-full text-right">
          {item.debit > 0 ? format(item.debit) : "-"}
        </span>
      ),
    },
    {
      header: "Running Balance",
      align: "right",
      render: (item) => (
        <span className={`font-mono text-xs font-extrabold inline-block w-full text-right ${item.balance > 0 ? "text-rose-600 dark:text-rose-400" : "text-emerald-600 dark:text-emerald-400"}`}>
          {format(Math.abs(item.balance))}
        </span>
      ),
    },
  ];

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3 p-6 max-w-sm border border-border/40 rounded-xl bg-card/60 backdrop-blur-sm">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <h2 className="text-lg font-bold">Unauthorized Access</h2>
          <p className="text-sm text-muted-foreground">
            You need to be logged in to view this page. Redirecting to login...
          </p>
          <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
        </div>
      </div>
    );
  }

  if (customerLoading || (!customer && !customerError)) {
    return (
      <div className="flex h-screen bg-background text-foreground overflow-hidden">
        <Sidebar activePath="/customers" />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Navbar title="Loading Customer Details" />
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center space-y-2">
              <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
              <span className="text-sm text-muted-foreground block">Loading profile...</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (customerError || !customer) {
    return (
      <div className="flex h-screen bg-background text-foreground overflow-hidden">
        <Sidebar activePath="/customers" />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Navbar title="Customer Profile" />
          <div className="flex-1 p-6 flex flex-col items-center justify-center gap-4 text-center">
            <AlertCircle className="h-12 w-12 text-rose-500" />
            <h2 className="text-xl font-bold">Customer Not Found</h2>
            <p className="text-sm text-muted-foreground">{(customerError as any)?.message || "The requested customer could not be found or you do not have permission."}</p>
            <Button variant="secondary" onClick={() => router.push("/customers")}>
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Customers
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/customers" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title={`Customer: ${customer.name}`} />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          {/* Back button */}
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-4">
              <Button variant="secondary" size="sm" className="h-9 gap-1.5" onClick={() => router.push("/customers")}>
                <ArrowLeft className="h-4 w-4" /> Back
              </Button>
              <h1 className="text-2xl font-extrabold tracking-tight">Customer Profile</h1>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                className="h-9 border-primary/40 hover:border-primary text-primary hover:bg-primary/5 font-semibold gap-1.5"
                onClick={() => setIsPaymentOpen(true)}
              >
                <Coins className="h-4 w-4" /> Record Payment
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="h-9 border-border/60 text-muted-foreground hover:text-foreground hover:bg-accent font-semibold gap-1.5"
                onClick={() => setActiveTab("payments")}
              >
                <History className="h-4 w-4" /> Payments History
              </Button>
              {remainingAdvance > 0 && (
                <Button
                  size="sm"
                  className="h-9 bg-amber-600 hover:bg-amber-700 text-white font-bold gap-1.5 shadow-sm"
                  onClick={() => {
                    setRefundAmount(remainingAdvance);
                    setRefundNotes("");
                    setIsRefundOpen(true);
                  }}
                >
                  <RotateCcw className="h-4 w-4" /> Refund Advance
                </Button>
              )}
            </div>
          </div>

          {/* Banner Notifications */}
          {successMessage && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 animate-in fade-in slide-in-from-top-4 duration-300">
              <CheckCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}
          {errorMessage && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive animate-in fade-in slide-in-from-top-4 duration-300">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{errorMessage}</span>
            </div>
          )}

          {/* Profile Overview Card */}
          <Card className="border border-border/60 bg-card/40 backdrop-blur-md">
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                <div className="flex items-center gap-4">
                  {/* Circular Avatar */}
                  <div className="relative shrink-0">
                    <div className="h-16 w-16 sm:h-20 sm:w-20 rounded-full border-2 border-primary/30 bg-secondary/40 overflow-hidden flex items-center justify-center shadow-md">
                      {customer.image ? (
                        <img
                          src={getFullAssetUrl(customer.image) || customer.image}
                          alt={customer.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="text-xl sm:text-2xl font-black text-primary uppercase font-mono">
                          {customer.name.substring(0, 2)}
                        </div>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isUploadingPhoto}
                      className="absolute bottom-0 right-0 p-1.5 rounded-full bg-primary text-primary-foreground hover:bg-primary/90 shadow-md cursor-pointer transition-transform hover:scale-105"
                      title="Upload Customer Photo"
                    >
                      {isUploadingPhoto ? <Loader2 className="w-3 h-3 animate-spin" /> : <Upload className="w-3 h-3" />}
                    </button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/png, image/jpeg, image/webp"
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h2 className="text-xl font-bold text-foreground">{customer.name}</h2>
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold border uppercase ${
                        customer.isActive ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20" : "bg-destructive/10 text-destructive border-destructive/20"
                      }`}>
                        {customer.isActive ? "Active" : "Inactive"}
                      </span>
                    </div>
                    {customer.businessName && (
                      <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                        <Building2 className="h-3.5 w-3.5" /> {customer.businessName}
                      </p>
                    )}
                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground pt-1">
                      {customer.phone && (
                        <span className="flex items-center gap-1">
                          <Phone className="h-3.5 w-3.5" /> {customer.phone}
                        </span>
                      )}
                      {customer.email && (
                        <span className="flex items-center gap-1">
                          <Mail className="h-3.5 w-3.5" /> {customer.email}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 border-t lg:border-t-0 lg:border-l border-border/60 pt-4 lg:pt-0 lg:pl-6">
                  <div>
                    <span className="text-[10px] font-bold text-muted-foreground uppercase block">Group</span>
                    <span className="text-sm font-bold text-foreground">
                      {customer.customerGroup?.name || "None"}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-muted-foreground uppercase block">Credit Limit</span>
                    <span className="text-sm font-bold text-foreground">
                      {customer.creditLimit !== null ? format(customer.creditLimit) : "Unlimited"}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-muted-foreground uppercase block">Opening Balance</span>
                    <span className="text-sm font-bold text-foreground">
                      {format(customer.openingBalance || 0)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-muted-foreground uppercase block">Status</span>
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border mt-1 ${
                      customer.isActive
                        ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
                        : "bg-destructive/10 text-destructive border-destructive/20"
                    }`}>
                      {customer.isActive ? "Active" : "Inactive"}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Metric Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="border border-border/40 bg-background/50">
              <CardContent className="p-4 flex items-center gap-4">
                <div className="h-10 w-10 rounded-lg bg-blue-500/10 flex items-center justify-center shrink-0">
                  <TrendingUp className="h-5 w-5 text-blue-500" />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-muted-foreground uppercase block">Total Spent</span>
                  <span className="text-lg font-black text-foreground">{format(totalSalesSpent)}</span>
                </div>
              </CardContent>
            </Card>

            <Card className="border border-border/40 bg-background/50">
              <CardContent className="p-4 flex items-center gap-4">
                <div className="h-10 w-10 rounded-lg bg-emerald-500/10 flex items-center justify-center shrink-0">
                  <DollarSign className="h-5 w-5 text-emerald-500" />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-muted-foreground uppercase block">Total Paid</span>
                  <span className="text-lg font-black text-foreground">{format(totalAmountPaid)}</span>
                </div>
              </CardContent>
            </Card>

            <Card className="border border-border/40 bg-background/50">
              <CardContent className="p-4 flex items-center gap-4">
                <div className="h-10 w-10 rounded-lg bg-rose-500/10 flex items-center justify-center shrink-0">
                  <CreditCard className="h-5 w-5 text-rose-500" />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-muted-foreground uppercase block">Balance Due</span>
                  <span className="text-lg font-black text-foreground">{format(totalOutstanding)}</span>
                </div>
              </CardContent>
            </Card>

            <Card className="border border-border/40 bg-background/50">
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="h-10 w-10 rounded-lg bg-yellow-500/10 flex items-center justify-center shrink-0">
                    <Coins className="h-5 w-5 text-yellow-500" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-muted-foreground uppercase block">Advance Credits</span>
                    <span className="text-lg font-black text-foreground">{format(remainingAdvance)}</span>
                  </div>
                </div>
                {remainingAdvance > 0 && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-8 px-2.5 text-xs font-bold text-amber-600 dark:text-amber-400 border-amber-500/30 hover:bg-amber-500/10"
                    onClick={() => {
                      setRefundAmount(remainingAdvance);
                      setRefundNotes("");
                      setIsRefundOpen(true);
                    }}
                  >
                    <RotateCcw className="h-3 w-3 mr-1" /> Refund
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Ledger tabs container */}
          <div className="space-y-4">
            <div className="flex border-b border-border/60">
              <button
                className={`py-2.5 px-4 font-bold text-xs uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 ${
                  activeTab === "invoices"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
                onClick={() => setActiveTab("invoices")}
              >
                <History className="h-4 w-4" /> Invoices History
              </button>
              <button
                className={`py-2.5 px-4 font-bold text-xs uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 ${
                  activeTab === "payments"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
                onClick={() => setActiveTab("payments")}
              >
                <CreditCard className="h-4 w-4" /> Payments History
              </button>
              <button
                className={`py-2.5 px-4 font-bold text-xs uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 ${
                  activeTab === "advances"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
                onClick={() => setActiveTab("advances")}
              >
                <Coins className="h-4 w-4" /> Advances History
              </button>
              <button
                className={`py-2.5 px-4 font-bold text-xs uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 ${
                  activeTab === "statement"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
                onClick={() => setActiveTab("statement")}
              >
                <FileText className="h-4 w-4" /> Ledger Statement
              </button>
            </div>

            {/* List Table wrapper */}
            {activeTab === "invoices" ? (
              salesLoading ? (
                <div className="py-12 flex justify-center">
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                </div>
              ) : (
                <DataTable
                  data={sales}
                  columns={invoiceColumns}
                  searchPlaceholder="Search Invoices..."
                  serverSide={true}
                  totalItems={meta.total}
                  totalPages={meta.totalPages}
                  currentPage={currentPage}
                  onPageChange={handlePageChange}
                  searchQuery={searchQuery}
                  onSearchQueryChange={handleSearchChange}
                  onPageSizeChange={handleLimitChange}
                  reportTitle={`${customer.name} - Invoices Ledger`}
                />
              )
            ) : activeTab === "payments" ? (
              paymentsLoading ? (
                <div className="py-12 flex justify-center">
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                </div>
              ) : (
                <DataTable
                  data={customerPayments}
                  columns={paymentColumns}
                  searchPlaceholder="Search Payments..."
                  searchKeys={["paymentNumber", "notes"]}
                  serverSide={false}
                  reportTitle={`${customer.name} - Payments History`}
                />
              )
            ) : activeTab === "advances" ? (
              advancesLoading ? (
                <div className="py-12 flex justify-center">
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                </div>
              ) : (
                <DataTable
                  data={advances}
                  columns={advanceColumns}
                  searchPlaceholder="Search Advances..."
                  searchKeys={["advanceNumber"]}
                  serverSide={false}
                  reportTitle={`${customer.name} - Advances Ledger`}
                />
              )
            ) : (
              <div className="space-y-4">
                {/* Ledger Data Table with integrated Period Filter & Search in top bar */}
                <DataTable
                  data={ledgerEntries}
                  columns={ledgerColumns}
                  searchPlaceholder="Search Statement..."
                  searchKeys={["ref", "description", "type"]}
                  extraFilters={
                    <div className="w-52 shrink-0">
                      <Select
                        value={statementFilter}
                        onValueChange={(val) => setStatementFilter(val as any)}
                        icon={<Filter className="h-3.5 w-3.5 text-muted-foreground" />}
                        className="h-9 text-xs w-full bg-background/50"
                      >
                        <option value="all">All Time Transactions</option>
                        <option value="month">This Month</option>
                        <option value="30days">Last 30 Days</option>
                        <option value="year">This Year</option>
                      </Select>
                    </div>
                  }
                  serverSide={false}
                  reportTitle={`${customer.name} - Account Ledger Statement`}
                />

                {/* Statement Summary Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                  <div className="p-4 rounded-sm bg-card border border-border/50">
                    <span className="text-[10px] font-bold text-muted-foreground uppercase block">Total Credits (Payments / Advances)</span>
                    <span className="text-lg font-black text-emerald-600 dark:text-emerald-400">
                      {format(ledgerEntries.reduce((sum: number, item: any) => sum + (item.credit || 0), 0))}
                    </span>
                  </div>
                  <div className="p-4 rounded-sm bg-card border border-border/50">
                    <span className="text-[10px] font-bold text-muted-foreground uppercase block">Total Debits (Invoiced / Due)</span>
                    <span className="text-lg font-black text-rose-600 dark:text-rose-400">
                      {format(ledgerEntries.reduce((sum: number, item: any) => sum + (item.debit || 0), 0))}
                    </span>
                  </div>
                  <div className="p-4 rounded-sm bg-card border border-border/50">
                    <span className="text-[10px] font-bold text-muted-foreground uppercase block">Closing Outstanding Balance</span>
                    <span className={`text-lg font-black ${
                      (ledgerEntries[ledgerEntries.length - 1]?.balance || 0) > 0
                        ? "text-rose-600 dark:text-rose-400"
                        : "text-emerald-600 dark:text-emerald-400"
                    }`}>
                      {format(Math.abs(ledgerEntries[ledgerEntries.length - 1]?.balance || 0))} {(ledgerEntries[ledgerEntries.length - 1]?.balance || 0) > 0 ? "Due" : "Credit"}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Sale detail & Receipt modals */}
      {selectedSaleIdForDetail && (
        <SaleDetailDialog
          isOpen={!!selectedSaleIdForDetail}
          onClose={() => setSelectedSaleIdForDetail(null)}
          saleId={selectedSaleIdForDetail}
          businessId={businessId}
        />
      )}

      {selectedSaleForReceipt && (
        <ReceiptPreview
          isOpen={!!selectedSaleForReceipt}
          onClose={() => setSelectedSaleForReceipt(null)}
          sale={selectedSaleForReceipt}
          businessName={currentUser?.business?.name || "HKR ERP Store"}
        />
      )}

      {selectedSaleForPayment && (
        <SalePaymentDialog
          isOpen={!!selectedSaleForPayment}
          onClose={() => setSelectedSaleForPayment(null)}
          sale={selectedSaleForPayment}
          businessId={businessId}
          createdById={currentUser?.id}
          onSuccess={setSuccessMessage}
          onError={setErrorMessage}
        />
      )}

      {/* Customer Record Payment Dialog */}
      {currentUser && isPaymentOpen && (
        <CustomerPaymentDialog
          isOpen={isPaymentOpen}
          onClose={() => setIsPaymentOpen(false)}
          sale={null}
          customer={customer}
          currentUser={currentUser}
          onSuccess={setSuccessMessage}
          onError={setErrorMessage}
        />
      )}

      {/* Customer Payments List Dialog */}
      {currentUser && isHistoryOpen && (
        <CustomerPaymentsListDialog
          isOpen={isHistoryOpen}
          onClose={() => setIsHistoryOpen(false)}
          sale={null}
          customer={customer}
          currentUser={currentUser}
          onSuccess={setSuccessMessage}
          onError={setErrorMessage}
        />
      )}

      {/* Main Advance Cash Refund Dialog */}
      {isRefundOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-card border border-border rounded-lg shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-border p-5 bg-background/40">
              <h3 className="text-base font-bold text-foreground flex items-center gap-2">
                <RotateCcw className="h-4.5 w-4.5 text-amber-500" /> Refund Customer Advance
              </h3>
              <button
                onClick={() => setIsRefundOpen(false)}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="h-4.5 w-4.5" />
              </button>
            </div>

            <form onSubmit={handleRefundSubmit}>
              <div className="p-5 space-y-4">
                {/* Available Balance Header */}
                <div className="p-3.5 bg-secondary/40 rounded border border-border/50 text-xs space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Customer:</span>
                    <span className="font-bold text-foreground">{customer?.name}</span>
                  </div>
                  <div className="flex justify-between border-t border-border/30 pt-1.5">
                    <span className="text-muted-foreground">Total Available Advance:</span>
                    <span className="font-black text-sm text-emerald-500">{format(remainingAdvance)}</span>
                  </div>
                </div>

                {/* Branch Selection (if multiple) */}
                {branches.length > 1 && (
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-muted-foreground">Branch *</label>
                    <select
                      value={selectedBranchId}
                      onChange={(e) => setSelectedBranchId(e.target.value)}
                      className="w-full h-10 px-3 py-2 bg-background border border-input text-foreground rounded text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                    >
                      {branches.map((b: any) => (
                        <option key={b.id} value={b.id}>
                          {b.name}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {/* Payment Method (Cash / Bank) */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground">Refund Method *</label>
                  <select
                    value={selectedPaymentMethodId}
                    onChange={(e) => setSelectedPaymentMethodId(e.target.value)}
                    className="w-full h-10 px-3 py-2 bg-background border border-input text-foreground rounded text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                  >
                    {paymentMethods.map((pm: any) => (
                      <option key={pm.id} value={pm.id}>
                        {pm.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Refund Amount */}
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-semibold text-muted-foreground">Refund Amount ({symbol}) *</label>
                    <button
                      type="button"
                      onClick={() => setRefundAmount(remainingAdvance)}
                      className="text-[11px] font-bold text-primary hover:underline"
                    >
                      Refund Full ({format(remainingAdvance)})
                    </button>
                  </div>
                  <Input
                    type="number"
                    step="any"
                    max={remainingAdvance}
                    min={1}
                    value={refundAmount || ""}
                    onChange={(e) => setRefundAmount(Number(e.target.value))}
                    placeholder="0.00"
                    required
                  />
                  {refundAmount > remainingAdvance && (
                    <span className="text-xs text-rose-500 font-semibold">
                      Refund amount cannot exceed available balance of {format(remainingAdvance)}.
                    </span>
                  )}
                </div>

                {/* Refund Reason / Notes */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground">Refund Notes (Optional)</label>
                  <Input
                    type="text"
                    value={refundNotes}
                    onChange={(e) => setRefundNotes(e.target.value)}
                    placeholder="e.g. Returned advance on customer request"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2.5 p-4 border-t border-border bg-background/20">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsRefundOpen(false)}
                  disabled={refundMutation.isPending}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  size="sm"
                  className="bg-amber-600 hover:bg-amber-700 text-white font-bold"
                  disabled={
                    refundMutation.isPending ||
                    refundAmount <= 0 ||
                    refundAmount > remainingAdvance
                  }
                >
                  {refundMutation.isPending ? (
                    <>
                      <Loader2 className="h-3.5 w-3.5 animate-spin mr-1.5" /> Processing...
                    </>
                  ) : (
                    `Confirm Refund ${refundAmount > 0 ? format(refundAmount) : ""}`
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default function CustomerViewPage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen w-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
          <p className="text-sm text-muted-foreground">Loading Profile...</p>
        </div>
      </div>
    }>
      <CustomerViewPageContent />
    </Suspense>
  );
}
