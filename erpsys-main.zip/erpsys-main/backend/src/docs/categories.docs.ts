export const CreateCategoryBodySchema = {
  type: 'object',
  properties: {
    name: { type: 'string', minLength: 2, maxLength: 100, example: 'Electronics' },
    description: { type: 'string', maxLength: 500, example: 'Electronic gadgets and items' },
    color: { type: 'string', pattern: '^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$', example: '#3B82F6' },
    businessId: { type: 'string', example: 'business-uuid-123' },
    parentId: { type: 'string', example: 'null', nullable: true },
    branchIds: { type: 'array', items: { type: 'string' }, example: ['branch-uuid-1'] },
    isActive: { type: 'boolean', example: true },
    imageUrl: { type: 'string', example: '/uploads/categories/electronics.png' },
    createdById: { type: 'string', example: 'user-uuid-123' }
  },
  required: ['name', 'businessId']
};

export const UpdateCategoryBodySchema = {
  type: 'object',
  properties: {
    name: { type: 'string', minLength: 2, maxLength: 100, example: 'Smartphones' },
    description: { type: 'string', maxLength: 500, example: 'Mobile smart devices' },
    color: { type: 'string', pattern: '^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$', example: '#3B82F6' },
    businessId: { type: 'string', example: 'business-uuid-123' },
    parentId: { type: 'string', example: 'category-uuid-electronics', nullable: true },
    branchIds: { type: 'array', items: { type: 'string' }, example: ['branch-uuid-1'] },
    isActive: { type: 'boolean', example: true },
    imageUrl: { type: 'string', example: '/uploads/categories/smartphones.png' },
    updatedById: { type: 'string', example: 'user-uuid-123' }
  },
  required: ['businessId']
};

export const CategoryResponseSchema = {
  type: 'object',
  properties: {
    id: { type: 'string', example: 'category-uuid-123' },
    name: { type: 'string', example: 'Electronics' },
    description: { type: 'string', example: 'Electronic gadgets and items' },
    imageUrl: { type: 'string', example: '/uploads/categories/electronics.png' },
    parentId: { type: 'string', example: null, nullable: true },
    isActive: { type: 'boolean', example: true },
    businessId: { type: 'string', example: 'business-uuid-123' }
  }
};
