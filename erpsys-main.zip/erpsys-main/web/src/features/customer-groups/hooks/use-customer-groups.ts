import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { customerGroupService } from "@/services/customer-group-service";
import { branchService } from "@/services/branch-service";
import { sellingPriceGroupService } from "@/services/selling-price-group-service";
import { queryKeys } from "@/lib/query-keys";
import { CustomerGroupItem } from "../types";

export function useCustomerGroupsQuery(businessId: string, branchId?: string) {
  return useQuery<CustomerGroupItem[]>({
    queryKey: queryKeys.customerGroups.list(businessId, branchId),
    queryFn: () => customerGroupService.getCustomerGroups(businessId, branchId),
    enabled: !!businessId,
  });
}

export function useBranchesQuery(businessId: string, userId?: string) {
  return useQuery({
    queryKey: queryKeys.branches.list(businessId, userId),
    queryFn: () => branchService.getBranches(businessId, userId),
    enabled: !!businessId,
  });
}

export function useSellingPriceGroupsQuery(businessId: string) {
  return useQuery({
    queryKey: ["sellingPriceGroups", businessId],
    queryFn: () => sellingPriceGroupService.getSellingPriceGroups(businessId),
    enabled: !!businessId,
  });
}

export function useCreateCustomerGroupMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: Parameters<typeof customerGroupService.createCustomerGroup>[0]) =>
      customerGroupService.createCustomerGroup(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.customerGroups.all });
    },
  });
}

export function useUpdateCustomerGroupMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Parameters<typeof customerGroupService.updateCustomerGroup>[1] }) =>
      customerGroupService.updateCustomerGroup(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.customerGroups.all });
    },
  });
}

export function useDeleteCustomerGroupMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, businessId }: { id: string; businessId: string }) =>
      customerGroupService.deleteCustomerGroup(id, businessId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.customerGroups.all });
    },
  });
}
