import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { X, Loader2, Coins } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { User } from "@hkr/types";
import { PurchaseItem } from "@/features/purchases/types";
import { SupplierItem } from "@/features/suppliers/types";
import { supplierPaymentFormSchema, SupplierPaymentFormSchema } from "../schema";
import { useCreateSupplierPaymentMutation } from "../hooks/use-supplier-payments";
import { usePaymentMethodsQuery } from "@/features/payment-methods/hooks/use-payment-methods";
import { usePurchasesQuery } from "@/features/purchases";
import { useBranchesQuery } from "@/features/suppliers/hooks/use-suppliers";
import { useCurrency } from "@/hooks/use-currency";

interface SupplierPaymentDialogProps {
  isOpen: boolean;
  onClose: () => void;
  purchase: PurchaseItem | null;
  supplier?: SupplierItem | null;
  currentUser: User;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

export function SupplierPaymentDialog({
  isOpen,
  onClose,
  purchase,
  supplier,
  currentUser,
  onSuccess,
  onError,
}: SupplierPaymentDialogProps) {
  const { symbol } = useCurrency(currentUser.businessId);
  const createMutation = useCreateSupplierPaymentMutation();

  const [selectedPurchaseId, setSelectedPurchaseId] = useState<string>("direct");
  const [selectedBranchId, setSelectedBranchId] = useState<string>("");

  // Determine branchId to query payment methods
  const queryBranchId = purchase
    ? purchase.branchId
    : (selectedBranchId || undefined);

  // Query payment methods for this branch
  const { data: paymentMethods = [], isLoading: methodsLoading } = usePaymentMethodsQuery(
    currentUser?.businessId || "",
    queryBranchId,
    true // only active
  );

  // Query supplier's purchases to allocate payment if supplier prop is provided
  const { data: purchasesResponse, isLoading: purchasesLoading } = usePurchasesQuery(
    currentUser?.businessId || "",
    { supplierId: supplier?.id || "", limit: 100 }
  );

  // Filter for unpaid or partially paid purchases
  const unpaidPurchases = React.useMemo(() => {
    const list = purchasesResponse?.data || [];
    return list.filter((p: any) => p.paymentStatus !== "PAID");
  }, [purchasesResponse]);

  // Query branches
  const { data: branches = [], isLoading: branchesLoading } = useBranchesQuery(
    currentUser?.businessId || "",
    currentUser?.id
  );

  // Prefill default branch
  useEffect(() => {
    if (branches.length > 0 && !selectedBranchId) {
      setSelectedBranchId(branches[0].id);
    }
  }, [branches, selectedBranchId]);

  // Calculate remaining due
  const remainingDue = React.useMemo(() => {
    if (purchase) {
      return Math.max(0, purchase.grandTotal - purchase.amountPaid);
    }
    if (supplier) {
      if (selectedPurchaseId === "direct") {
        return Math.max(0, supplier.outstandingDue || 0);
      }
      const matched = unpaidPurchases.find((p: any) => p.id === selectedPurchaseId);
      return matched ? Math.max(0, matched.grandTotal - matched.amountPaid) : 0;
    }
    return 0;
  }, [purchase, supplier, selectedPurchaseId, unpaidPurchases]);

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { errors },
  } = useForm<SupplierPaymentFormSchema>({
    resolver: zodResolver(supplierPaymentFormSchema),
    defaultValues: {
      amount: 0,
      paymentDate: new Date().toISOString().split("T")[0],
      paymentMethodId: "",
      transactionNo: "",
      notes: "",
    },
  });

  // Set default values
  useEffect(() => {
    if (isOpen) {
      reset({
        amount: Number(remainingDue.toFixed(2)),
        paymentDate: new Date().toISOString().split("T")[0],
        paymentMethodId: paymentMethods[0]?.id || "",
        transactionNo: "",
        notes: "",
      });
      if (supplier) {
        setSelectedPurchaseId("direct");
      }
    }
  }, [purchase, supplier, isOpen, reset, paymentMethods, remainingDue]);

  // Update paymentMethodId once payment methods load
  useEffect(() => {
    if (paymentMethods.length > 0) {
      setValue("paymentMethodId", paymentMethods[0].id);
    }
  }, [paymentMethods, setValue]);

  if (!isOpen || (!purchase && !supplier)) return null;

  const onSubmit = async (data: SupplierPaymentFormSchema) => {
    if (!currentUser.businessId) return;

    const actualSupplierId = purchase ? purchase.supplierId : supplier!.id;
    const actualBranchId = purchase ? purchase.branchId : selectedBranchId;
    const actualPurchaseId = purchase ? purchase.id : (selectedPurchaseId === "direct" ? undefined : selectedPurchaseId);

    if (!actualBranchId) {
      onError("Please select a branch.");
      return;
    }

    const payload = {
      amount: data.amount,
      paymentDate: new Date(data.paymentDate).toISOString(),
      purchaseId: actualPurchaseId,
      supplierId: actualSupplierId,
      paymentMethodId: data.paymentMethodId,
      branchId: actualBranchId,
      businessId: currentUser.businessId,
      transactionNo: data.transactionNo?.trim() || undefined,
      notes: data.notes?.trim() || undefined,
      createdById: currentUser.id,
    };

    try {
      await createMutation.mutateAsync(payload);
      onSuccess("Payment recorded successfully!");
      onClose();
    } catch (err: any) {
      onError(err.message || "Failed to record payment.");
    }
  };

  const isLoading = createMutation.isPending;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-card border border-border rounded-sm shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between border-b border-border p-5 bg-background/40">
          <h2 className="text-lg font-bold text-foreground flex items-center gap-2">
            <Coins className="h-5 w-5 text-primary" /> Record Supplier Payment
          </h2>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-5 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Purchase Details Summary */}
          {purchase ? (
            <div className="p-3 bg-secondary/50 rounded-sm border border-border/40 text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Invoice / Bill:</span>
                <span className="font-mono font-bold">{purchase.purchaseNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Supplier:</span>
                <span className="font-semibold">{purchase.supplier?.name}</span>
              </div>
              <div className="flex justify-between border-t border-border/30 pt-1.5 mt-1.5">
                <span className="text-muted-foreground">Grand Total:</span>
                <span className="font-bold">{symbol}{purchase.grandTotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Amount Paid:</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">{symbol}{purchase.amountPaid.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Remaining Due:</span>
                <span className="font-extrabold text-rose-600 dark:text-rose-400">{symbol}{remainingDue.toFixed(2)}</span>
              </div>
            </div>
          ) : (
            <div className="p-3 bg-secondary/50 rounded-sm border border-border/40 text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Supplier:</span>
                <span className="font-semibold">{supplier?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Business Name:</span>
                <span className="font-semibold">{supplier?.businessName || "N/A"}</span>
              </div>
              <div className="flex justify-between border-t border-border/30 pt-1.5 mt-1.5">
                <span className="text-muted-foreground">Total Outstanding Due:</span>
                <span className="font-bold text-rose-600 dark:text-rose-400">{symbol}{(supplier?.outstandingDue || 0).toFixed(2)}</span>
              </div>
            </div>
          )}

          {/* Allocation Selector for Direct Supplier Payment */}
          {supplier && (
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">Allocation / Destination Invoice</label>
              {purchasesLoading ? (
                <div className="h-10 flex items-center justify-center border border-input rounded-sm text-xs text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin mr-2" /> Loading supplier invoices...
                </div>
              ) : (
                <select
                  value={selectedPurchaseId}
                  onChange={(e) => setSelectedPurchaseId(e.target.value)}
                  className="w-full h-10 px-3 py-2 bg-background border border-input text-foreground rounded-sm text-sm focus:outline-none focus:border-primary placeholder:text-muted-foreground/60 transition-all focus:ring-1 focus:ring-primary"
                >
                  <option value="direct">Direct Payment (On-Account / Advance)</option>
                  {unpaidPurchases.map((p: any) => {
                    const due = Math.max(0, p.grandTotal - p.amountPaid);
                    return (
                      <option key={p.id} value={p.id}>
                        {p.purchaseNumber} (Due: {symbol}{due.toFixed(2)})
                      </option>
                    );
                  })}
                </select>
              )}
            </div>
          )}

          {/* Branch Selector for Direct Payment */}
          {supplier && selectedPurchaseId === "direct" && (
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">Branch *</label>
              {branchesLoading ? (
                <div className="h-10 flex items-center justify-center border border-input rounded-sm text-xs text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin mr-2" /> Loading branches...
                </div>
              ) : (
                <select
                  value={selectedBranchId}
                  onChange={(e) => setSelectedBranchId(e.target.value)}
                  className="w-full h-10 px-3 py-2 bg-background border border-input text-foreground rounded-sm text-sm focus:outline-none focus:border-primary placeholder:text-muted-foreground/60 transition-all focus:ring-1 focus:ring-primary"
                >
                  {branches.map((b: any) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </select>
              )}
            </div>
          )}

          {/* Amount field */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">Payment Amount ({symbol}) *</label>
            <Input
              type="number"
              step="any"
              placeholder="0.00"
              {...register("amount", { valueAsNumber: true })}
            />
            {errors.amount && (
              <span className="text-xs text-rose-500">{errors.amount.message}</span>
            )}
          </div>

          {/* Payment Date */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">Payment Date *</label>
            <Input
              type="date"
              {...register("paymentDate")}
            />
            {errors.paymentDate && (
              <span className="text-xs text-rose-500">{errors.paymentDate.message}</span>
            )}
          </div>

          {/* Payment Method */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">Payment Method *</label>
            {methodsLoading ? (
              <div className="flex items-center gap-2 text-xs text-muted-foreground h-10 px-3 border border-input rounded-sm">
                <Loader2 className="h-4 w-4 animate-spin" /> Loading payment methods...
              </div>
            ) : (
              <select
                {...register("paymentMethodId")}
                className="w-full h-10 px-3 py-2 bg-background border border-input text-foreground rounded-sm text-sm focus:outline-none focus:border-primary placeholder:text-muted-foreground/60 transition-all focus:ring-1 focus:ring-primary"
              >
                {paymentMethods.map((pm) => (
                  <option key={pm.id} value={pm.id}>
                    {pm.name}
                  </option>
                ))}
              </select>
            )}
            {errors.paymentMethodId && (
              <span className="text-xs text-rose-500">{errors.paymentMethodId.message}</span>
            )}
          </div>

          {/* Transaction No */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">Transaction / Reference No</label>
            <Input
              placeholder="e.g. Cheque No, Bank Txn Ref"
              {...register("transactionNo")}
            />
          </div>

          {/* Notes */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">Notes</label>
            <textarea
              placeholder="Optional payment notes..."
              {...register("notes")}
              className="w-full h-16 px-3 py-2 bg-background border border-input text-foreground rounded-sm text-sm focus:outline-none focus:border-primary placeholder:text-muted-foreground/60 transition-all focus:ring-1 focus:ring-primary"
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 border-t border-border pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Recording...
                </>
              ) : (
                "Record Payment"
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
