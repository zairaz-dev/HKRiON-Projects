import { z } from "zod";

export const productFormSchema = z
  .object({
    name: z
      .string()
      .trim()
      .min(2, "Product name must be at least 2 characters")
      .max(150, "Product name cannot exceed 150 characters"),
    description: z.string().max(1000, "Description cannot exceed 1000 characters").optional().or(z.literal("")),
    imageUrl: z.string().optional().or(z.literal("")),
    type: z.enum(["SINGLE", "VARIABLE"]),
    isActive: z.boolean(),
    enableStock: z.boolean(),
    enableImei: z.boolean().optional(),
    isImei: z.boolean().optional(),
    alertQuantity: z.number().min(0, "Alert quantity cannot be negative"),
    notForSelling: z.boolean().optional(),
    weight: z.number().min(0, "Weight cannot be negative").optional().nullable(),
    categoryId: z.string().optional().or(z.literal("none")),
    brandId: z.string().optional().or(z.literal("none")),
    unitId: z.string().optional().or(z.literal("none")),
    warrantyId: z.string().optional().or(z.literal("none")),
    branchIds: z.array(z.string()),

    // Single Product fields
    sku: z.string().max(50, "SKU cannot exceed 50 characters").optional().or(z.literal("")),
    purchasePrice: z.number().min(0, "Purchase price must be 0 or greater").optional(),
    sellingPrice: z.number().min(0, "Selling price must be 0 or greater").optional(),
    openingStock: z.number().min(0, "Opening stock cannot be negative").optional(),
    openingStockBranchId: z.string().optional().or(z.literal("none")),
  })
  .superRefine((val, ctx) => {
    if (val.type === "SINGLE") {
      if (val.purchasePrice === undefined || isNaN(val.purchasePrice)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Purchase price is required for single products",
          path: ["purchasePrice"],
        });
      }
      if (val.sellingPrice === undefined || isNaN(val.sellingPrice)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Selling price is required for single products",
          path: ["sellingPrice"],
        });
      }
      if (
        val.openingStock &&
        val.openingStock > 0 &&
        (!val.openingStockBranchId || val.openingStockBranchId === "none")
      ) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Please select a branch to allocate initial opening stock",
          path: ["openingStockBranchId"],
        });
      }
    }
  });

export type ProductFormValues = z.infer<typeof productFormSchema>;

