"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import {
  FileText,
  Plus,
  Loader2,
  CheckCircle,
  AlertCircle,
  Coins,
  Building2,
  Trash2,
  Calendar,
  Layers,
  Search,
  User as UserIcon,
  Users,
  Link2,
  History,
  DollarSign,
  Pencil,
  RotateCcw,
  Printer,
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { DataTable, ColumnDef, ActionsDropdown } from "@/components/ui/table";
import { ActionItem } from "@/components/ui/actions-dropdown";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";

import {
  PurchaseItem,
  usePurchasesQuery,
  CreatePurchaseReturnDialog,
  PurchaseDetailDialog
} from "@/features/purchases";
import { useSuppliersQuery, useBranchesQuery } from "@/features/suppliers/hooks/use-suppliers";
import { SupplierPaymentDialog, SupplierPaymentsListDialog } from "@/features/supplier-payments";
import { SupplierAdvanceAllocationDialog } from "@/features/supplier-advances";
import { useCurrency } from "@/hooks/use-currency";

function PurchasesPageContent() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    if (typeof window !== "undefined") return authService.getCurrentUser();
    return null;
  });
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(() => {
    if (typeof window !== "undefined") return authService.isAuthenticated();
    return null;
  });

  // Success / Error notifications
  const [successMessage, setSuccessMessage] = useState<string>("none");
  const [error, setError] = useState<string>("");

  // Dialog states
  const [selectedPurchaseForPayment, setSelectedPurchaseForPayment] = useState<PurchaseItem | null>(null);
  const [selectedPurchaseForHistory, setSelectedPurchaseForHistory] = useState<PurchaseItem | null>(null);
  const [selectedPurchaseForAdvance, setSelectedPurchaseForAdvance] = useState<PurchaseItem | null>(null);
  const [selectedPurchaseForReturn, setSelectedPurchaseForReturn] = useState<PurchaseItem | null>(null);
  const [selectedPurchaseForDetail, setSelectedPurchaseForDetail] = useState<PurchaseItem | null>(null);


  // URL Search Params for Filters (Rule #3: Store table filters in URL Search Params)
  const selectedBranchFilter = searchParams.get("branchId") || "all";
  const selectedSupplierFilter = searchParams.get("supplierId") || "all";
  const currentPage = Number(searchParams.get("page")) || 1;
  const searchQuery = searchParams.get("search") || "";
  const limit = Number(searchParams.get("limit")) || 10;

  const setSelectedBranchFilter = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1");
    if (value === "all") {
      params.delete("branchId");
    } else {
      params.set("branchId", value);
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  const setSelectedSupplierFilter = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1");
    if (value === "all") {
      params.delete("supplierId");
    } else {
      params.set("supplierId", value);
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  const handlePageChange = (newPage: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", String(newPage));
    router.push(`${pathname}?${params.toString()}`);
  };

  const handleSearchChange = (newSearch: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1");
    if (newSearch) {
      params.set("search", newSearch);
    } else {
      params.delete("search");
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  const handleLimitChange = (newLimit: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("limit", String(newLimit));
    params.set("page", "1");
    router.push(`${pathname}?${params.toString()}`);
  };

  // Auth check
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  // Notifications timeouts
  useEffect(() => {
    if (successMessage && successMessage !== "none") {
      const timer = setTimeout(() => setSuccessMessage("none"), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  const businessId = currentUser?.businessId || "";
  const { symbol, format } = useCurrency(businessId);

  // Queries
  const { data: purchasesResponse, isLoading: purchasesLoading } = usePurchasesQuery(
    businessId,
    {
      branchId: selectedBranchFilter !== "all" ? selectedBranchFilter : undefined,
      supplierId: selectedSupplierFilter !== "all" ? selectedSupplierFilter : undefined,
      page: currentPage,
      limit,
      search: searchQuery || undefined
    }
  );
  
  const purchasesList = purchasesResponse?.data || [];
  const meta = purchasesResponse?.meta || { total: 0, totalPages: 1 };

  const { data: suppliersList = [] } = useSuppliersQuery(businessId);
  const { data: branchesList = [] } = useBranchesQuery(businessId, currentUser?.id);

  // Columns definition
  const columns: ColumnDef<PurchaseItem>[] = [
    {
      header: "Invoice / Bill #",
      render: (p) => (
        <button
          onClick={() => setSelectedPurchaseForDetail(p)}
          className="font-mono font-bold text-primary hover:underline text-left block"
          title="Click to view & print invoice"
        >
          {p.purchaseNumber}
        </button>
      ),
    },
    {
      header: "Purchase Date",
      render: (p) => (
        <span className="text-xs text-muted-foreground block">
          {new Date(p.purchaseDate).toLocaleDateString("en-IN", {
            day: "2-digit",
            month: "short",
            year: "numeric",
          })}
        </span>
      ),
    },
    {
      header: "Supplier",
      render: (p) => (
        <div className="flex flex-col gap-0.5">
          <span className="font-semibold text-foreground text-xs">{p.supplier?.name}</span>
          {p.supplier?.businessName && (
            <span className="text-[10px] text-muted-foreground uppercase font-medium">
              {p.supplier.businessName}
            </span>
          )}
        </div>
      ),
    },
    {
      header: "Branch",
      render: (p) => (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-secondary text-secondary-foreground border border-border text-[10px] font-bold">
          <Building2 className="h-3 w-3" /> {p.branch?.name}
        </span>
      ),
    },
    {
      header: "Total Items",
      render: (p) => (
        <span className="text-xs font-semibold">
          {p.purchaseLines?.length || 0} unique items
        </span>
      ),
    },
    {
      header: "Grand Total",
      render: (p) => (
        <span className="font-extrabold text-foreground text-xs">
          {format(p.grandTotal)}
        </span>
      ),
    },
    {
      header: "Paid Amount",
      render: (p) => (
        <span className="font-semibold text-emerald-600 dark:text-emerald-400 text-xs">
          {format(p.amountPaid || 0)}
        </span>
      ),
    },
    {
      header: "Remaining Due",
      render: (p) => {
        const remaining = Math.max(0, p.grandTotal - (p.amountPaid || 0));
        return (
          <span className={`font-bold text-xs ${remaining > 0 ? "text-rose-600 dark:text-rose-400" : "text-muted-foreground"}`}>
            {format(remaining)}
          </span>
        );
      },
    },
    {
      header: "Payment Status",
      render: (p) => {
        const status = p.paymentStatus || "DUE";
        let badgeClass = "bg-rose-500/10 border-rose-500/25 text-rose-600 dark:text-rose-400";
        if (status === "PAID") {
          badgeClass = "bg-emerald-500/10 border-emerald-500/25 text-emerald-600 dark:text-emerald-400";
        } else if (status === "PARTIAL") {
          badgeClass = "bg-amber-500/10 border-amber-500/25 text-amber-600 dark:text-amber-400";
        }
        return (
          <span className={`inline-flex items-center px-2 py-0.5 rounded border text-[10px] font-extrabold tracking-wide uppercase ${badgeClass}`}>
            {status}
          </span>
        );
      },
    },
    {
      header: "Actions",
      render: (p) => {
        const remaining = Math.max(0, p.grandTotal - (p.amountPaid || 0));
        const actions: ActionItem[] = [
          {
            label: "View / Print Invoice",
            onClick: () => setSelectedPurchaseForDetail(p),
            icon: <Printer className="h-3.5 w-3.5 text-primary" />,
          },
        ];

        if (remaining > 0) {
          actions.push({
            label: "Pay Due",
            onClick: () => setSelectedPurchaseForPayment(p),
            icon: <DollarSign className="h-3.5 w-3.5" />,
          });
          actions.push({
            label: "Apply Advance",
            onClick: () => setSelectedPurchaseForAdvance(p),
            icon: <Link2 className="h-3.5 w-3.5" />,
          });
        }

        actions.push({
          label: "Return Items",
          onClick: () => setSelectedPurchaseForReturn(p),
          icon: <RotateCcw className="h-3.5 w-3.5" />,
        });

        actions.push({
          label: "Edit",
          onClick: () => router.push(`/purchases/edit?id=${p.id}`),
          icon: <Pencil className="h-3.5 w-3.5" />,
        });

        actions.push({
          label: "Payment History",
          onClick: () => setSelectedPurchaseForHistory(p),
          icon: <History className="h-3.5 w-3.5" />,
        });

        return <ActionsDropdown actions={actions} />;
      },
    },
  ];

  // Custom filters popover content
  const customFilters = (
    <div className="space-y-3.5 min-w-[220px]">
      {/* Branch Filter */}
      <div className="space-y-1.5">
        <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
          <Building2 className="h-3 w-3" /> Branch Filter
        </label>
        <Select
          value={selectedBranchFilter}
          onValueChange={setSelectedBranchFilter}
          className="h-9 text-xs"
        >
          <option value="all">All Branches</option>
          {branchesList.map((b: any) => (
            <option key={b.id} value={b.id}>{b.name}</option>
          ))}
        </Select>
      </div>

      {/* Supplier Filter */}
      <div className="space-y-1.5">
        <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
          <UserIcon className="h-3 w-3" /> Supplier Filter
        </label>
        <Select
          value={selectedSupplierFilter}
          onValueChange={setSelectedSupplierFilter}
          className="h-9 text-xs"
        >
          <option value="all">All Suppliers</option>
          {suppliersList.map((s: any) => (
            <option key={s.id} value={s.id}>{s.name}</option>
          ))}
        </Select>
      </div>
    </div>
  );

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3 p-6 max-w-sm border border-border/40 rounded-xl bg-card/60 backdrop-blur-sm">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <h2 className="text-lg font-bold">Unauthorized Access</h2>
          <p className="text-sm text-muted-foreground">
            You need to be logged in to view this page. Redirecting to login...
          </p>
          <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/purchases" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Purchases & Stock Ledger" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <FileText className="h-7 w-7 text-primary" /> Purchases & Stock
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Record new stock purchases, trace suppliers, manage lot costs and track batch-wise inventory.
              </p>
            </div>
            <div>
              <Button 
                variant="outline" 
                onClick={() => router.push("/purchases/returns")}
                className="text-xs gap-1.5 h-9"
              >
                <RotateCcw className="h-4 w-4" /> View Purchase Returns
              </Button>
            </div>
          </div>

          {/* Banner Notifications */}
          {successMessage && successMessage !== "none" && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 animate-in fade-in slide-in-from-top-4 duration-300">
              <CheckCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive animate-in fade-in slide-in-from-top-4 duration-300">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          {/* Main Table Card */}
          {purchasesLoading ? (
            <div className="flex h-64 items-center justify-center">
              <div className="text-center space-y-2">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
                <span className="text-sm text-muted-foreground block">Loading purchases...</span>
              </div>
            </div>
          ) : (
            <DataTable
              data={purchasesList}
              columns={columns}
              searchPlaceholder="Search Invoice..."
              serverSide={true}
              totalItems={meta.total}
              totalPages={meta.totalPages}
              currentPage={currentPage}
              onPageChange={handlePageChange}
              searchQuery={searchQuery}
              onSearchQueryChange={handleSearchChange}
              onPageSizeChange={handleLimitChange}
              actionButton={{
                label: "Add Purchase",
                onClick: () => router.push("/purchases/create"),
                icon: <Plus className="h-4 w-4" />
              }}
              customFilters={customFilters}
              reportTitle="Purchases Ledger Report"
            />
          )}
        </main>
      </div>

      {currentUser && (
        <>
          <SupplierPaymentDialog
            isOpen={!!selectedPurchaseForPayment}
            onClose={() => setSelectedPurchaseForPayment(null)}
            purchase={selectedPurchaseForPayment}
            currentUser={currentUser}
            onSuccess={(msg: string) => setSuccessMessage(msg)}
            onError={(msg: string) => setError(msg)}
          />
          <SupplierPaymentsListDialog
            isOpen={!!selectedPurchaseForHistory}
            onClose={() => setSelectedPurchaseForHistory(null)}
            purchase={selectedPurchaseForHistory}
            currentUser={currentUser}
            onSuccess={(msg: string) => setSuccessMessage(msg)}
            onError={(msg: string) => setError(msg)}
          />
          {selectedPurchaseForAdvance && (
            <SupplierAdvanceAllocationDialog
              isOpen={!!selectedPurchaseForAdvance}
              onClose={() => setSelectedPurchaseForAdvance(null)}
              purchase={selectedPurchaseForAdvance}
              currentUser={currentUser}
              onSuccess={(msg: string) => setSuccessMessage(msg)}
              onError={(msg: string) => setError(msg)}
            />
          )}
          {selectedPurchaseForReturn && (
            <CreatePurchaseReturnDialog
              isOpen={!!selectedPurchaseForReturn}
              onClose={() => setSelectedPurchaseForReturn(null)}
              purchase={selectedPurchaseForReturn}
              businessId={businessId}
              userId={currentUser?.id || ""}
              onSuccess={(msg: string) => setSuccessMessage(msg)}
              onError={(msg: string) => setError(msg)}
            />
          )}
          {selectedPurchaseForDetail && (
            <PurchaseDetailDialog
              isOpen={!!selectedPurchaseForDetail}
              onClose={() => setSelectedPurchaseForDetail(null)}
              purchaseId={selectedPurchaseForDetail.id}
              businessId={businessId}
              onReturnClick={(p) => setSelectedPurchaseForReturn(p)}
            />
          )}
        </>
      )}
    </div>
  );
}

export default function PurchasesPage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen w-screen items-center justify-center bg-[#121216]">
        <div className="flex flex-col items-center gap-2">
          <div className="w-8 h-8 border-4 border-zinc-700 border-t-emerald-500 rounded-full animate-spin" />
          <p className="text-sm text-zinc-400">Loading...</p>
        </div>
      </div>
    }>
      <PurchasesPageContent />
    </Suspense>
  );
}
