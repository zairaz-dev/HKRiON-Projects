'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import DashboardSidebar from '@/components/DashboardSidebar';
import { UserCheck, CheckCircle2, Clock, Plus, RefreshCw } from 'lucide-react';

interface Inquiry {
  id: string;
  name: string;
  email: string;
  service: string;
  message: string;
  status: string;
  createdAt: string;
}

export default function CustomerDashboard() {
  const router = useRouter();
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchInquiries = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/customer/inquiries');
      if (res.status === 401 || res.status === 403) {
        router.push('/login');
        return;
      }
      const data = await res.json();
      if (data.inquiries) {
        setInquiries(data.inquiries);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    fetchInquiries();
  }, [fetchInquiries]);

  return (
    <div className="min-h-screen bg-black text-white radial-bg flex">
      {/* Left Sidebar */}
      <DashboardSidebar
        userRole="CUSTOMER"
        userName="John Doe (Client)"
        userEmail="customer@hkrion.com"
        activeTab="inquiries"
      />

      {/* Main Content Area */}
      <div className="flex-1 lg:ml-64 flex flex-col min-w-0 min-h-screen">
        
        {/* Top Header */}
        <header className="border-b border-purple-500/20 bg-black/80 backdrop-blur-md sticky top-0 z-30 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center">
              <UserCheck className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h1 className="text-lg font-bold font-mono tracking-wide text-white">
                HKRION <span className="text-purple-400">Client Portal</span>
              </h1>
              <p className="text-xs text-neutral-400">Your Project Inquiries & Status Tracker</p>
            </div>
          </div>

          <button
            onClick={fetchInquiries}
            className="px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-purple-500/40 text-neutral-300 hover:text-white text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-purple-400' : ''}`} />
            Refresh Portal
          </button>
        </header>

        {/* Content */}
        <main className="p-6 sm:p-8 space-y-6 flex-1">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-white">My Submitted Requests</h2>
              <p className="text-xs text-neutral-400 mt-1">
                Track the real-time review and progress of your software & ERP project requests.
              </p>
            </div>
            <Link
              href="/#contact"
              className="glow-btn px-4 py-2.5 rounded-xl text-xs font-semibold text-white flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Submit New Request
            </Link>
          </div>

          <div className="space-y-4">
            {inquiries.length === 0 ? (
              <div className="glass-card p-12 text-center text-neutral-500 rounded-2xl border border-neutral-800">
                You haven&apos;t submitted any inquiries yet. Submit one from our contact page!
              </div>
            ) : (
              inquiries.map((inquiry) => (
                <div
                  key={inquiry.id}
                  className="glass-card p-6 rounded-2xl border border-purple-500/30 bg-black/90 space-y-4"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <span className="px-2.5 py-1 rounded-lg bg-purple-500/10 text-purple-300 font-medium text-xs border border-purple-500/30">
                        {inquiry.service}
                      </span>
                      <h3 className="text-base font-semibold text-white mt-2">{inquiry.message}</h3>
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-mono font-semibold border flex items-center gap-1.5 ${
                          inquiry.status === 'RESOLVED'
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                            : inquiry.status === 'IN_PROGRESS' || inquiry.status === 'CONTACTED'
                            ? 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                            : 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30'
                        }`}
                      >
                        {inquiry.status === 'RESOLVED' ? (
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        ) : (
                          <Clock className="w-3.5 h-3.5" />
                        )}
                        Status: {inquiry.status}
                      </span>
                    </div>
                  </div>

                  <div className="text-[10px] font-mono text-neutral-500 border-t border-neutral-800/80 pt-3 flex justify-between">
                    <span>Submitted on: {new Date(inquiry.createdAt).toLocaleDateString()}</span>
                    <span>Assigned Team: HKRION Enterprise Team</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
