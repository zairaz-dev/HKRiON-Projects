import { NextResponse } from "next/server";
import { UserService } from "@/services/user.service";
import { SessionManager } from "@/core/auth/session";
import { SafeHttp } from "@/core/http/redirect";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  try {
    const session = await SessionManager.getCurrentSession();
    if (!session) {
      return SafeHttp.redirect("/login", request, 303);
    }

    const contentType = request.headers.get("content-type") || "";
    const isJson = contentType.includes("application/json");

    let id = "";
    if (isJson) {
      const body = await request.json();
      id = body.id || "";
    } else {
      const formData = await request.formData();
      id = (formData.get("id") as string) || "";
    }

    if (!id) {
      if (isJson) {
        return NextResponse.json({ success: false, error: "User ID is required" }, { status: 400 });
      }
      return SafeHttp.redirect("/admin/users?error=User+ID+is+required", request, 303);
    }

    // Prevent deleting oneself
    if (id === session.userId) {
      if (isJson) {
        return NextResponse.json({ success: false, error: "You cannot delete your own active session account." }, { status: 400 });
      }
      return SafeHttp.redirect("/admin/users?error=You+cannot+delete+your+own+account", request, 303);
    }

    // Check user exists
    const targetUser = await UserService.getById(id);
    if (!targetUser) {
      if (isJson) {
        return NextResponse.json({ success: false, error: "User not found." }, { status: 404 });
      }
      return SafeHttp.redirect("/admin/users?error=User+not+found", request, 303);
    }

    // If target user is ADMIN, check if they are the last remaining admin
    if (targetUser.role === "ADMIN") {
      const adminCount = await UserService.countAdmins();
      if (adminCount <= 1) {
        if (isJson) {
          return NextResponse.json({ success: false, error: "Cannot delete the only remaining administrator." }, { status: 400 });
        }
        return SafeHttp.redirect("/admin/users?error=Cannot+delete+the+last+remaining+admin", request, 303);
      }
    }

    await UserService.delete(id);

    revalidatePath("/admin/users");
    revalidatePath("/admin");

    if (isJson) {
      return NextResponse.json({ success: true, message: "User deleted successfully" });
    }

    return SafeHttp.redirect(`/admin/users?success=User+deleted+successfully`, request, 303);
  } catch (error: any) {
    console.error("Error deleting user:", error);
    const contentType = request.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      return NextResponse.json({ success: false, error: error.message || "Failed to delete user" }, { status: 500 });
    }
    return SafeHttp.redirect(`/admin/users?error=${encodeURIComponent(error.message || "Failed to delete user")}`, request, 303);
  }
}
