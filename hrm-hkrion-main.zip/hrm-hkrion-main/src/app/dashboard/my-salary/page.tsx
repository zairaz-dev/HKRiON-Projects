import { redirect } from "next/navigation";
import { getSession } from "@/lib/session";
import { prisma } from "@/lib/db";
import MySalaryClient from "./my-salary-client";

import { PageContainer } from "@/components/layout/page-container";

export const metadata = {
  title: "My Salary | HKRiON HRM",
};

export default async function MySalaryPage() {
  const session = await getSession();

  if (!session) {
    redirect("/login");
  }

  // Fetch user's compensation and payslips
  const userData = await prisma.user.findUnique({
    where: { id: session.userId },
    include: {
      compensations: {
        where: { isActive: true },
        take: 1,
      },
      payslips: {
        orderBy: [{ year: "desc" }, { month: "desc" }],
      },
    },
  });

  if (!userData) {
    return <div className="p-6 text-error">Failed to load salary data.</div>;
  }

  return (
    <PageContainer className="!space-y-0">
      <MySalaryClient 
        compensation={userData.compensations[0] ? { ...userData.compensations[0], baseSalary: Number(userData.compensations[0].baseSalary) } : null} 
        payslips={userData.payslips.map(p => ({ 
          ...p, 
          basicPay: Number(p.basicPay),
          allowances: Number(p.allowances),
          deductions: Number(p.deductions),
          netPay: Number(p.netPay) 
        }))} 
      />
    </PageContainer>
  );
}
