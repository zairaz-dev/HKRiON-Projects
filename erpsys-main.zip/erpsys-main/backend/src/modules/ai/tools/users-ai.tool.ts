import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class UsersAiTool {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Get staff directory and roles overview with strict PII & password protection
   */
  async getUsersContext(businessId: string, userRole = 'CASHIER') {
    const normalizedRole = userRole.toUpperCase().replace(/[-\s]/g, '_');
    const isAuthorized =
      normalizedRole === 'ADMIN' ||
      normalizedRole === 'SUPER_ADMIN' ||
      normalizedRole.includes('SUPER') ||
      normalizedRole.includes('OWNER');

    if (!isAuthorized) {
      return {
        accessRestricted: true,
        message: 'Staff directory and internal user details are strictly restricted to Administrators.',
      };
    }

    const [totalUsers, users] = await Promise.all([
      this.prisma.user.count({ where: { businessId } }),
      this.prisma.user.findMany({
        where: { businessId },
        select: {
          id: true,
          name: true,
          email: true,
          phone: true,
          isActive: true,
          role: {
            select: { name: true, role: true },
          },
          branches: {
            select: {
              branch: { select: { name: true } },
            },
          },
        },
        take: 10,
      }),
    ]);

    return {
      totalStaffCount: totalUsers,
      staffSummary: users.map((u) => ({
        name: u.name,
        email: u.email,
        phone: u.phone || 'N/A',
        role: u.role?.name || 'Staff',
        status: u.isActive ? 'Active' : 'Inactive',
        assignedBranches: u.branches.map((b) => b.branch?.name).filter(Boolean),
      })),
    };
  }
}
