export const CreatePurchaseBodySchema = {
  type: 'object',
  properties: {
    purchaseNumber: { type: 'string', example: 'PUR-2026-0001' },
    purchaseDate: { type: 'string', example: '2026-07-09T00:00:00.000Z' },
    supplierId: { type: 'string', example: 'supplier-uuid-123' },
    branchId: { type: 'string', example: 'branch-uuid-123' },
    businessId: { type: 'string', example: 'business-uuid-123' },
    grandTotal: { type: 'number', example: 1200.00 },
    notes: { type: 'string', example: 'Bulk purchase of wireless mice' },
    createdById: { type: 'string', example: 'user-uuid-123' },
    purchaseLines: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          variantId: { type: 'string', example: 'variant-uuid-123' },
          quantity: { type: 'number', example: 100 },
          purchasePrice: { type: 'number', example: 10.00 },
          sellingPrice: { type: 'number', example: 25.00 }
        },
        required: ['variantId', 'quantity', 'purchasePrice']
      }
    }
  },
  required: ['supplierId', 'branchId', 'businessId', 'purchaseLines', 'grandTotal']
};

export const UpdatePurchaseBodySchema = {
  type: 'object',
  properties: {
    purchaseNumber: { type: 'string', example: 'PUR-2026-0001-REV' },
    purchaseDate: { type: 'string', example: '2026-07-09T00:00:00.000Z' },
    supplierId: { type: 'string', example: 'supplier-uuid-123' },
    branchId: { type: 'string', example: 'branch-uuid-123' },
    businessId: { type: 'string', example: 'business-uuid-123' },
    notes: { type: 'string', example: 'Revised bulk purchase details' },
    purchaseLines: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          variantId: { type: 'string', example: 'variant-uuid-123' },
          quantity: { type: 'number', example: 110 },
          purchasePrice: { type: 'number', example: 10.00 },
          sellingPrice: { type: 'number', example: 25.00 }
        },
        required: ['variantId', 'quantity', 'purchasePrice']
      }
    }
  },
  required: ['businessId']
};

export const PurchaseResponseSchema = {
  type: 'object',
  properties: {
    id: { type: 'string', example: 'purchase-uuid-123' },
    purchaseNumber: { type: 'string', example: 'PUR-2026-0001' },
    purchaseDate: { type: 'string', example: '2026-07-09T00:00:00.000Z' },
    supplierId: { type: 'string', example: 'supplier-uuid-123' },
    branchId: { type: 'string', example: 'branch-uuid-123' },
    grandTotal: { type: 'number', example: 1200.00 },
    status: { type: 'string', example: 'RECEIVED' },
    businessId: { type: 'string', example: 'business-uuid-123' }
  }
};
