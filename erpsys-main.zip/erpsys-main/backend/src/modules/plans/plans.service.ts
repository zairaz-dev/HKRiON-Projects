import { Injectable, BadRequestException, NotFoundException, OnModuleInit } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreatePlanDto } from './dto/create-plan.dto';
import { UpdatePlanDto } from './dto/update-plan.dto';

@Injectable()
export class PlansService implements OnModuleInit {
  constructor(private readonly prisma: PrismaService) {}

  async onModuleInit() {
    await this.seedDefaultPlans();
    await this.syncExistingPlansCurrency();
  }

  async syncExistingPlansCurrency() {
    try {
      await this.prisma.plan.updateMany({
        where: { currency: 'INR' },
        data: { currency: 'LKR' },
      });
    } catch (err) {
      console.error('Failed to sync plans currency:', err);
    }
  }

  async seedDefaultPlans() {
    try {
      const count = await this.prisma.plan.count();
      if (count === 0) {
        const defaultPlans = [
          {
            name: 'Free Trial',
            slug: 'trial',
            description: '14-day free access to test all basic ERP capabilities',
            priceMonthly: 0,
            priceYearly: 0,
            priceMonthlyUsd: 0,
            priceYearlyUsd: 0,
            currency: 'LKR',
            trialDays: 14,
            maxBranches: 1,
            maxUsers: 2,
            maxProducts: 100,
            maxInvoicesMonthly: 50,
            enablePos: true,
            enableImei: false,
            enableAccounting: false,
            enableSms: false,
            enableApiAccess: false,
            isActive: true,
            isPopular: false,
            sortOrder: 1,
          },
          {
            name: 'Starter Plan',
            slug: 'starter',
            description: 'Ideal for small retail shops and single-location businesses',
            priceMonthly: 499,
            priceYearly: 4999,
            priceMonthlyUsd: 2,
            priceYearlyUsd: 20,
            currency: 'LKR',
            trialDays: 0,
            maxBranches: 1,
            maxUsers: 3,
            maxProducts: 1000,
            maxInvoicesMonthly: 500,
            enablePos: true,
            enableImei: false,
            enableAccounting: false,
            enableSms: false,
            enableApiAccess: false,
            isActive: true,
            isPopular: false,
            sortOrder: 2,
          },
          {
            name: 'Professional Plan',
            slug: 'pro',
            description: 'Powerful multi-branch system with IMEI tracking and accounting',
            priceMonthly: 1499,
            priceYearly: 14999,
            priceMonthlyUsd: 5,
            priceYearlyUsd: 50,
            currency: 'LKR',
            trialDays: 0,
            maxBranches: 5,
            maxUsers: 10,
            maxProducts: 10000,
            maxInvoicesMonthly: 5000,
            enablePos: true,
            enableImei: true,
            enableAccounting: true,
            enableSms: true,
            enableApiAccess: false,
            isActive: true,
            isPopular: true,
            sortOrder: 3,
          },
          {
            name: 'Enterprise Plan',
            slug: 'enterprise',
            description: 'Unlimited branches, users, and transactions with dedicated support',
            priceMonthly: 0,
            priceYearly: 0,
            priceMonthlyUsd: 0,
            priceYearlyUsd: 0,
            currency: 'LKR',
            trialDays: 0,
            maxBranches: -1, // Unlimited
            maxUsers: -1,    // Unlimited
            maxProducts: -1, // Unlimited
            maxInvoicesMonthly: -1, // Unlimited
            enablePos: true,
            enableImei: true,
            enableAccounting: true,
            enableSms: true,
            enableApiAccess: true,
            isActive: true,
            isPopular: false,
            sortOrder: 4,
          },
        ];

        for (const plan of defaultPlans) {
          await this.prisma.plan.create({ data: plan });
        }
        console.log('Default SaaS plans seeded successfully');
      }
    } catch (error) {
      console.error('Error seeding default SaaS plans:', error);
    }
  }

  async getAllPlans(includeInactive = false, businessId?: string) {
    if (includeInactive) {
      // Super Admin view: get all plans and include associated business info & subscriptions to track payment
      return this.prisma.plan.findMany({
        include: {
          business: {
            select: { id: true, name: true, email: true, phone: true },
          },
          subscriptions: {
            select: { id: true, status: true, businessId: true },
          },
        },
        orderBy: [{ isCustom: 'asc' }, { sortOrder: 'asc' }, { createdAt: 'desc' }],
      });
    }

    if (businessId) {
      // Tenant view (settings/subscription): return public active plans + this tenant's dedicated custom plans
      const tenantPlans = await this.prisma.plan.findMany({
        where: {
          isActive: true,
          OR: [
            { isCustom: false },
            { isCustom: true, businessId: businessId },
          ],
        },
        include: {
          business: {
            select: { id: true, name: true },
          },
        },
        orderBy: { sortOrder: 'asc' },
      });

      // If this business has a dedicated custom enterprise plan, exclude the generic public 'enterprise' plan
      const hasCustom = tenantPlans.some((p) => p.isCustom && p.businessId === businessId);
      const activeCustomSub = await this.prisma.subscription.findFirst({
        where: { businessId, status: { in: ['ACTIVE', 'TRIAL'] } },
        include: { plan: true },
      });
      const isCustomSubscribed = !!activeCustomSub?.plan?.isCustom;

      if (hasCustom || isCustomSubscribed) {
        return tenantPlans.filter(
          (p) => p.slug !== 'enterprise' && !(p.name?.toLowerCase().includes('enterprise') && !p.isCustom)
        );
      }

      return tenantPlans;
    }

    // Public catalog view (/pricing, /): return public non-custom active plans only
    return this.prisma.plan.findMany({
      where: {
        isActive: true,
        isCustom: false,
      },
      orderBy: { sortOrder: 'asc' },
    });
  }

  async getPlanById(id: string) {
    const plan = await this.prisma.plan.findUnique({
      where: { id },
      include: {
        business: {
          select: { id: true, name: true, email: true, phone: true },
        },
      },
    });
    if (!plan) {
      throw new NotFoundException(`Plan with ID ${id} not found`);
    }
    return plan;
  }

  async getPlanBySlug(slug: string) {
    return this.prisma.plan.findUnique({
      where: { slug },
      include: {
        business: {
          select: { id: true, name: true, email: true, phone: true },
        },
      },
    });
  }

  async createPlan(dto: CreatePlanDto) {
    const existing = await this.prisma.plan.findUnique({ where: { slug: dto.slug } });
    if (existing) {
      throw new BadRequestException(`Plan with slug '${dto.slug}' already exists`);
    }

    if (dto.isCustom) {
      if (!dto.businessId) {
        throw new BadRequestException('Client Business is required for custom dedicated enterprise plans.');
      }
      const business = await this.prisma.business.findUnique({ where: { id: dto.businessId } });
      if (!business) {
        throw new BadRequestException('Selected client business does not exist.');
      }
    }

    return this.prisma.plan.create({
      data: dto,
      include: {
        business: {
          select: { id: true, name: true, email: true, phone: true },
        },
      },
    });
  }

  async updatePlan(id: string, dto: UpdatePlanDto) {
    const current = await this.getPlanById(id);
    if (dto.slug) {
      const existing = await this.prisma.plan.findUnique({ where: { slug: dto.slug } });
      if (existing && existing.id !== id) {
        throw new BadRequestException(`Plan with slug '${dto.slug}' already exists`);
      }
    }

    const willBeCustom = dto.isCustom !== undefined ? dto.isCustom : current.isCustom;
    if (willBeCustom) {
      const targetBusinessId = dto.businessId !== undefined ? dto.businessId : current.businessId;
      if (!targetBusinessId) {
        throw new BadRequestException('Client Business is required for custom dedicated enterprise plans.');
      }
      const business = await this.prisma.business.findUnique({ where: { id: targetBusinessId } });
      if (!business) {
        throw new BadRequestException('Selected client business does not exist.');
      }
    }

    return this.prisma.plan.update({
      where: { id },
      data: dto,
      include: {
        business: {
          select: { id: true, name: true, email: true, phone: true },
        },
      },
    });
  }

  async deletePlan(id: string) {
    const plan = await this.getPlanById(id);
    const SYSTEM_DEFAULT_SLUGS = ['trial', 'starter', 'pro', 'business', 'enterprise'];
    if (SYSTEM_DEFAULT_SLUGS.includes(plan.slug)) {
      throw new BadRequestException('This is a core system default plan and cannot be deleted. You can deactivate it if needed.');
    }

    // Check if subscriptions are using this plan
    const subCount = await this.prisma.subscription.count({ where: { planId: id } });
    if (subCount > 0) {
      throw new BadRequestException('Cannot delete plan because active subscriptions are attached to it. Deactivate it instead.');
    }
    return this.prisma.plan.delete({ where: { id } });
  }
}
