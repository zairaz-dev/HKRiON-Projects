import React, { useState, useMemo, useEffect } from "react";
import { createPortal } from "react-dom";
import Link from "next/link";
import { AdminOrder, AdminOrderStatus } from "../types";
import { SearchIcon, CloseIcon } from "@/components/ui/LuxuryIcons";
import { LuxurySelect } from "@/components/ui/LuxurySelect";
import { LuxuryPrice } from "@/components/ui/LuxuryPrice";
import { COUNTRY_OPTIONS, getCountryFlag } from "@/lib/data/countries";

interface OrdersTabProps {
  ordersList: AdminOrder[];
  formatPrice: (price: number) => string;
  onUpdateOrderStatus: (orderId: string, newStatus: AdminOrderStatus) => void;
  onRefreshOrders?: () => void;
  isLoadingOrders?: boolean;
}

export function OrdersTab({
  ordersList,
  formatPrice,
  onUpdateOrderStatus,
  onRefreshOrders,
  isLoadingOrders = false,
}: OrdersTabProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>("all");
  const [selectedOrderForInspection, setSelectedOrderForInspection] = useState<AdminOrder | null>(null);
  const [mounted, setMounted] = useState(false);
  const [copiedRef, setCopiedRef] = useState(false);

  // Address edit state for inspection modal
  const [isEditingAddress, setIsEditingAddress] = useState(false);
  const [addressFormData, setAddressFormData] = useState({
    shippingAddress: "",
    city: "",
    state: "",
    postalCode: "",
    country: "Sri Lanka",
  });
  const [isSavingAddress, setIsSavingAddress] = useState(false);
  const [addressSaveError, setAddressSaveError] = useState<string | null>(null);
  const [addressSaveSuccess, setAddressSaveSuccess] = useState(false);

  // Payment helpers
  const isCardPaymentMethod = (pm?: string) => {
    if (!pm) return false;
    const lower = pm.toLowerCase();
    return (
      lower.includes("card") ||
      lower.includes("credit") ||
      lower.includes("debit") ||
      lower.includes("stripe")
    );
  };

  const getPaymentDisplayName = (pm?: string) => {
    if (!pm) return "Bank Wire Transfer";
    if (isCardPaymentMethod(pm)) return "Credit / Debit Card";
    if (pm.toLowerCase().includes("wire") || pm.toLowerCase().includes("bank")) return "Bank Wire Transfer";
    return pm.replace(/\s*\(Ref:[^)]+\)/i, "").trim();
  };

  const getOrderBankRef = (order: AdminOrder) => {
    return (
      order.bankReference ||
      (order.items?.[0] as any)?.bankReference ||
      order.paymentMethod?.match(/\(Ref:\s*([^)]+)\)/i)?.[1]?.trim() ||
      null
    );
  };

  const getOrderSlipUrl = (order: AdminOrder) => {
    return (
      order.paymentSlipUrl ||
      (order.items?.[0] as any)?.paymentSlipUrl ||
      null
    );
  };

  const startEditingAddress = (order: AdminOrder) => {
    setAddressFormData({
      shippingAddress: order.shippingAddress || "",
      city: order.city || "",
      state: order.state || "",
      postalCode: order.postalCode || "",
      country: order.country || "Sri Lanka",
    });
    setAddressSaveError(null);
    setAddressSaveSuccess(false);
    setIsEditingAddress(true);
  };

  const handleSaveAddress = async () => {
    if (!selectedOrderForInspection) return;
    setIsSavingAddress(true);
    setAddressSaveError(null);
    setAddressSaveSuccess(false);

    try {
      const res = await fetch("/api/orders", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: selectedOrderForInspection.id,
          shippingAddress: addressFormData.shippingAddress.trim(),
          city: addressFormData.city.trim(),
          state: addressFormData.state.trim(),
          postalCode: addressFormData.postalCode.trim(),
          country: addressFormData.country.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        setAddressSaveError(data.error || "Failed to update address.");
        return;
      }

      // Update current inspection order state
      setSelectedOrderForInspection((prev) =>
        prev
          ? {
              ...prev,
              shippingAddress: addressFormData.shippingAddress.trim(),
              city: addressFormData.city.trim(),
              state: addressFormData.state.trim(),
              postalCode: addressFormData.postalCode.trim(),
              country: addressFormData.country.trim(),
              destination: [addressFormData.city.trim(), addressFormData.country.trim()]
                .filter(Boolean)
                .join(", "),
            }
          : null
      );

      setAddressSaveSuccess(true);
      setIsEditingAddress(false);
      onRefreshOrders?.();
    } catch {
      setAddressSaveError("Network error while updating address.");
    } finally {
      setIsSavingAddress(false);
    }
  };

  useEffect(() => {
    setMounted(true);
  }, []);

  // Automatically refresh orders whenever this page/tab is opened
  useEffect(() => {
    onRefreshOrders?.();
  }, [onRefreshOrders]);

  // Filtered Orders
  const filteredOrders = useMemo(() => {
    return ordersList.filter((order) => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        q === "" ||
        order.id.toLowerCase().includes(q) ||
        order.clientName.toLowerCase().includes(q) ||
        order.email.toLowerCase().includes(q) ||
        order.gemstoneName.toLowerCase().includes(q) ||
        order.destination.toLowerCase().includes(q) ||
        (order.paymentMethod && order.paymentMethod.toLowerCase().includes(q)) ||
        (order.bankReference && order.bankReference.toLowerCase().includes(q));

      const matchesStatus =
        selectedStatusFilter === "all" ||
        order.status === selectedStatusFilter ||
        (selectedStatusFilter === "pending_verification" &&
          (order.status === "pending_verification" || order.status === "pending_inspection"));

      return matchesSearch && matchesStatus;
    });
  }, [ordersList, searchQuery, selectedStatusFilter]);

  const getStatusBadge = (status: AdminOrderStatus, isCard = false) => {
    switch (status) {
      case "pending_verification":
      case "pending_inspection":
        return isCard
          ? {
              label: "Card Authorized",
              classes: "bg-emerald-950/60 text-emerald-300 border-emerald-700/60 font-medium",
            }
          : {
              label: "Pending Payment",
              classes: "bg-amber-950/60 text-amber-300 border-amber-800/60 font-medium",
            };
      case "accepted":
        return {
          label: isCard ? "Order Confirmed" : "Payment Confirmed",
          classes: "bg-emerald-950/70 text-emerald-300 border-emerald-700/80 font-semibold",
        };
      case "vault_packed":
        return {
          label: "Packed & Ready",
          classes: "bg-purple-950/60 text-purple-300 border-purple-800/60",
        };
      case "in_transit":
        return {
          label: "In Transit",
          classes: "bg-blue-950/60 text-blue-300 border-blue-800/60",
        };
      case "delivered":
        return {
          label: "Delivered",
          classes: "bg-emerald-950/60 text-emerald-300 border-emerald-800/60",
        };
      case "rejected":
        return {
          label: isCard ? "Order Declined" : "Payment Rejected",
          classes: "bg-red-950/70 text-red-300 border-red-700/80 font-medium",
        };
      default:
        return {
          label: status,
          classes: "bg-gray-800 text-gray-300 border-gray-700",
        };
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Metric Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#24242C] pb-6">
        <div>
          <h1 className="font-sans text-xl sm:text-2xl text-white font-semibold tracking-tight">
            Customer Orders
          </h1>
          <p className="text-xs text-[#A1A1AA] font-sans mt-1">
            View customer orders, delivery status, payment slips, and shipping details.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {isLoadingOrders && (
            <span className="text-xs text-[#C5A880] font-sans flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C5A880]" />
              Syncing...
            </span>
          )}

          <span className="text-xs font-mono font-medium tabular-nums text-[#C5A880] bg-[#C5A880]/10 border border-[#C5A880]/30 px-3 py-1.5 rounded-sm">
            {ordersList.length} Total Orders
          </span>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4 bg-[#141419] p-4 border border-[#24242C] rounded-sm">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8C867D]" />
          <input
            type="text"
            placeholder="Search by Order ID, Client Name, Gemstone, Destination..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-[#1B1B24] border border-[#2A2A36] text-white text-xs font-sans placeholder-[#6E6B65] focus:outline-none focus:border-[#C5A880]"
          />
        </div>

        {/* Status Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0">
          {[
            { id: "all", label: "All" },
            { id: "pending_verification", label: "Pending Payment" },
            { id: "accepted", label: "Payment Confirmed" },
            { id: "vault_packed", label: "Packed & Ready" },
            { id: "in_transit", label: "In Transit" },
            { id: "delivered", label: "Delivered" },
            { id: "rejected", label: "Rejected" },
          ].map((tab) => {
            const isActive = selectedStatusFilter === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setSelectedStatusFilter(tab.id)}
                className={`px-3 py-1.5 text-xs font-sans rounded-sm whitespace-nowrap transition-colors ${
                  isActive
                    ? "bg-[#C5A880] text-[#0D0D11] font-semibold"
                    : "bg-[#1B1B24] text-[#8C867D] hover:text-white border border-[#2A2A36]"
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Orders List Stream */}
      {filteredOrders.length === 0 ? (
        <div className="bg-[#141419] border border-[#24242C] p-12 text-center text-[#8C867D] font-sans rounded-sm space-y-2">
          <div className="w-12 h-12 mx-auto rounded-full bg-[#1B1B24] border border-[#2A2A36] flex items-center justify-center text-[#C5A880] mb-3 shadow-inner">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
            </svg>
          </div>
          <p className="text-white font-sans font-medium text-base">No Orders in Vault Stream</p>
          <p className="text-xs text-[#8C867D] max-w-sm mx-auto">
            {searchQuery || selectedStatusFilter !== "all"
              ? "No orders match your filter criteria."
              : "Acquisitions and client orders will appear here automatically upon checkout."}
          </p>
          {(searchQuery || selectedStatusFilter !== "all") && (
            <button
              onClick={() => {
                setSearchQuery("");
                setSelectedStatusFilter("all");
              }}
              className="mt-3 inline-block text-xs text-[#C5A880] underline hover:text-[#E0CFA9] transition-colors"
            >
              Clear filters
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredOrders.map((order) => {
            const isCard = isCardPaymentMethod(order.paymentMethod);
            const badge = getStatusBadge(order.status, isCard);
            const bankRef = getOrderBankRef(order);
            const slipUrl = getOrderSlipUrl(order);

            const statusOptions = isCard
              ? [
                  { value: "pending_verification", label: "Card Authorized" },
                  { value: "accepted", label: "Order Confirmed" },
                  { value: "vault_packed", label: "Packed & Ready" },
                  { value: "in_transit", label: "In Transit" },
                  { value: "delivered", label: "Delivered" },
                  { value: "rejected", label: "Order Declined" },
                ]
              : [
                  { value: "pending_verification", label: "Pending Payment" },
                  { value: "accepted", label: "Payment Confirmed" },
                  { value: "vault_packed", label: "Packed & Ready" },
                  { value: "in_transit", label: "In Transit" },
                  { value: "delivered", label: "Delivered" },
                  { value: "rejected", label: "Payment Rejected" },
                ];

            return (
              <div
                key={order.id}
                className="bg-[#141419] border border-[#24242C] p-5 sm:p-6 rounded-sm space-y-3.5 text-xs font-sans hover:border-[#C5A880]/40 transition-colors"
              >
                {/* Header Row: ID, Status, Date on Left — Actions on Right */}
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-b border-[#24242C] pb-3.5">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <span className="font-mono font-semibold text-sm sm:text-base text-[#C5A880] tracking-wide tabular-nums">
                      {order.id}
                    </span>
                    <span
                      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[11px] font-mono whitespace-nowrap border font-medium ${badge.classes}`}
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-current shrink-0" />
                      <span>{badge.label}</span>
                    </span>
                    <span className="text-xs text-[#8C867D] font-mono tabular-nums">
                      • {order.date}
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    {/* Quick Payment Verification / Rejection Buttons */}
                    {(order.status === "pending_verification" || order.status === "pending_inspection") ? (
                      <>
                        <button
                          onClick={() => onUpdateOrderStatus(order.id, "accepted")}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs rounded-sm transition-all flex items-center gap-1.5 shadow-sm active:scale-95 whitespace-nowrap"
                          title={isCard ? "Approve card order and proceed to packing" : "Confirm wire payment and accept order"}
                        >
                          <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
                            <polyline points="20 6 9 17 4 12" />
                          </svg>
                          <span>{isCard ? "Approve Order" : "Confirm Payment"}</span>
                        </button>
                        <button
                          onClick={() => onUpdateOrderStatus(order.id, "rejected")}
                          className="px-3 py-1.5 bg-red-950/80 hover:bg-red-900/90 text-red-300 hover:text-red-200 border border-red-800/80 font-medium text-xs rounded-sm transition-all flex items-center gap-1.5 shadow-sm active:scale-95 whitespace-nowrap"
                          title={isCard ? "Decline / cancel card order" : "Reject payment and decline order"}
                        >
                          <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
                            <line x1="18" y1="6" x2="6" y2="18" />
                            <line x1="6" y1="6" x2="18" y2="18" />
                          </svg>
                          <span>{isCard ? "Decline Order" : "Reject Payment"}</span>
                        </button>
                      </>
                    ) : order.status === "accepted" ? (
                      <span className="px-2.5 py-1 bg-emerald-950/80 text-emerald-300 border border-emerald-700/80 rounded text-[11px] font-mono font-medium flex items-center gap-1.5 whitespace-nowrap">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                        <span>{isCard ? "Card Order Confirmed" : "Payment Confirmed"}</span>
                      </span>
                    ) : order.status === "rejected" ? (
                      <span className="px-2.5 py-1 bg-red-950/80 text-red-300 border border-red-700/80 rounded text-[11px] font-mono font-medium flex items-center gap-1.5 whitespace-nowrap">
                        <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                        <span>{isCard ? "Order Declined" : "Payment Rejected"}</span>
                      </span>
                    ) : null}

                    <button
                      onClick={() => setSelectedOrderForInspection(order)}
                      className="px-3 py-1.5 border border-[#2A2A36] hover:border-[#C5A880] text-white hover:text-[#C5A880] font-sans text-xs transition-colors rounded-sm whitespace-nowrap"
                    >
                      View Order Details
                    </button>

                    <div className="w-40 shrink-0">
                      <LuxurySelect
                        variant="dark"
                        size="sm"
                        value={order.status}
                        onChange={(val) =>
                          onUpdateOrderStatus(order.id, val as AdminOrderStatus)
                        }
                        options={statusOptions}
                        triggerClassName="!py-1.5 !text-xs"
                      />
                    </div>
                  </div>
                </div>

                {/* Payment & Slip Details Strip on Card */}
                <div className="bg-[#181822] px-4 py-2.5 border border-[#262632] rounded-sm flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <span className="text-[#8C867D] uppercase tracking-wider text-[10px] font-mono">Payment:</span>
                    {isCard ? (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-[#20202C] border border-[#2E2E3E] rounded text-white font-medium text-xs">
                        <svg className="w-3.5 h-3.5 text-[#C5A880]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <rect x="2" y="5" width="20" height="14" rx="2" strokeWidth={1.8} />
                          <line x1="2" y1="10" x2="22" y2="10" strokeWidth={1.8} />
                        </svg>
                        <span>Credit / Debit Card</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-[#20202C] border border-[#2E2E3E] rounded text-white font-medium text-xs">
                        <svg className="w-3.5 h-3.5 text-[#C5A880]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                        </svg>
                        <span>{getPaymentDisplayName(order.paymentMethod)}</span>
                      </span>
                    )}

                    {!isCard && bankRef && (
                      <span className="text-[#C5A880] font-mono text-[11px] bg-[#22222E] px-2 py-0.5 rounded border border-[#C5A880]/30">
                        Ref: {bankRef}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    {isCard ? (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-mono rounded-sm bg-emerald-950/60 text-emerald-300 border border-emerald-800/60">
                        <svg className="w-3.5 h-3.5 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        <span>Card Settled • No Slip Required</span>
                      </span>
                    ) : slipUrl ? (
                      <a
                        href={slipUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-2.5 py-1 text-[11px] font-mono text-[#C5A880] hover:text-white bg-[#22222E] hover:bg-[#2A2A38] border border-[#C5A880]/40 rounded-sm flex items-center gap-1 transition-colors"
                      >
                        <span>View Bank Slip ↗</span>
                      </a>
                    ) : (
                      <span className="text-[#8C867D] text-[10px] font-mono italic">Awaiting Wire Slip</span>
                    )}
                  </div>
                </div>

                {/* 3-Column Structured Information Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-[#A29F96]">
                  <div className="bg-[#181822]/70 p-3.5 border border-[#242432] rounded-sm space-y-1">
                    <span className="text-[#8C867D] block uppercase tracking-wider text-[10px] font-mono font-medium">
                      Customer
                    </span>
                    <span className="text-white font-medium text-sm block truncate">
                      {order.clientName}
                    </span>
                    <p className="text-[11px] font-mono text-[#8C867D] truncate">{order.email || "—"}</p>
                    <p className="text-[11px] font-mono text-[#8C867D]">{order.phone || "—"}</p>
                  </div>

                  <div className="bg-[#181822]/70 p-3.5 border border-[#242432] rounded-sm space-y-1">
                    <span className="text-[#8C867D] block uppercase tracking-wider text-[10px] font-mono font-medium">
                      Ordered Gemstone
                    </span>
                    <span className="text-white font-sans text-sm font-medium block truncate">
                      {order.gemstoneName}
                    </span>
                    <div className="text-[11px] text-[#C5A880] pt-0.5 flex items-center justify-between">
                      <span className="font-mono tabular-nums">{order.carat.toFixed(2)} Carats</span>
                      <div className="flex items-center gap-1">
                        <span className="text-[#8C867D] text-[10px] uppercase font-mono">Total:</span>
                        <LuxuryPrice amount={order.total} size="xs" color="gold" weight="semibold" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-[#181822]/70 p-3.5 border border-[#242432] rounded-sm space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[#8C867D] uppercase tracking-wider text-[10px] font-mono font-medium">
                        Shipping &amp; Destination
                      </span>
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-blue-950/60 text-blue-300 border border-blue-800/60">
                        Insured
                      </span>
                    </div>
                    <span className="text-white font-medium text-sm block truncate">
                      {order.courier}
                    </span>
                    <p className="text-[11px] text-[#8C867D] truncate" title={order.destination}>
                      {order.destination}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Order Dossier Inspection Modal */}
      {selectedOrderForInspection && mounted && createPortal(
        <div
          className="fixed inset-0 z-[99999] flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-sm animate-luxury-backdrop"
        >
          <div
            className="bg-[#141419] border border-[#2A2A36] max-w-2xl w-full max-h-[90vh] overflow-y-auto rounded-sm p-6 sm:p-8 space-y-6 animate-luxury-modal my-auto"
          >
            <div className="flex items-center justify-between border-b border-[#2A2A36] pb-4">
              <div>
                <span className="text-[10px] uppercase font-mono text-[#C5A880] tracking-wider">
                  Order Details
                </span>
                <h3 className="font-sans text-xl sm:text-2xl font-semibold tracking-tight text-white mt-0.5">
                  Order <span className="font-mono text-[#C5A880] tabular-nums">#{selectedOrderForInspection.id}</span>
                </h3>
              </div>
              <button
                onClick={() => setSelectedOrderForInspection(null)}
                className="text-[#8C867D] hover:text-white p-1"
              >
                <CloseIcon className="w-5 h-5" />
              </button>
            </div>

            {/* Status Banner */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-[#1B1B24] p-4 border border-[#2A2A36]">
              <div>
                <span className="text-[10px] uppercase text-[#8C867D] block">Current Status</span>
                <span className="font-mono text-sm text-[#C5A880] font-semibold">
                  {getStatusBadge(
                    selectedOrderForInspection.status,
                    isCardPaymentMethod(selectedOrderForInspection.paymentMethod)
                  ).label}
                </span>
              </div>
              <div className="text-right">
                <span className="text-[10px] uppercase text-[#8C867D] block">Total Amount</span>
                <div className="mt-0.5">
                  <LuxuryPrice amount={selectedOrderForInspection.total} size="lg" color="white" weight="bold" />
                </div>
              </div>
            </div>

            {/* Client and Transit Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-sans">
              <div className="bg-[#1A1A22] p-4 border border-[#2A2A36]/60 rounded-sm">
                <h4 className="text-[#C5A880] uppercase text-[10px] tracking-wider mb-2 font-mono">
                  Customer Details
                </h4>
                <p className="text-white font-medium">{selectedOrderForInspection.clientName}</p>
                <p className="text-[#8C867D] font-mono mt-1">{selectedOrderForInspection.email}</p>
                <p className="text-[#8C867D] font-mono">{selectedOrderForInspection.phone}</p>
              </div>

              <div className="bg-[#1A1A22] p-4 border border-[#2A2A36]/60 rounded-sm">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-[#C5A880] uppercase text-[10px] tracking-wider font-mono">
                    Delivery Details
                  </h4>
                  {!isEditingAddress ? (
                    <button
                      type="button"
                      onClick={() => startEditingAddress(selectedOrderForInspection)}
                      className="text-[10px] text-[#C5A880] hover:text-white uppercase tracking-wider font-mono px-2 py-0.5 border border-[#C5A880]/40 hover:border-[#C5A880] transition-colors"
                    >
                      Edit Address
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setIsEditingAddress(false)}
                      className="text-[10px] text-[#8C867D] hover:text-white uppercase tracking-wider font-mono"
                    >
                      Cancel
                    </button>
                  )}
                </div>

                {addressSaveSuccess && (
                  <div className="mb-2 p-1.5 bg-emerald-950/40 border border-emerald-800/60 text-emerald-400 text-[10px] font-mono">
                    Address updated successfully.
                  </div>
                )}

                {addressSaveError && (
                  <div className="mb-2 p-1.5 bg-red-950/40 border border-red-800/60 text-red-400 text-[10px] font-mono">
                    {addressSaveError}
                  </div>
                )}

                {!isEditingAddress ? (
                  <>
                    <p className="text-white font-medium">{selectedOrderForInspection.courier}</p>
                    <p className="text-[#8C867D] mt-1 flex items-center gap-1">
                      <span>{getCountryFlag(selectedOrderForInspection.country)}</span>
                      <span>
                        Destination: {[selectedOrderForInspection.city, selectedOrderForInspection.country].filter(Boolean).join(", ") || selectedOrderForInspection.destination}
                      </span>
                    </p>
                    {selectedOrderForInspection.shippingAddress && (
                      <div className="mt-1 pt-1 border-t border-[#2A2A36]/60 text-[11px] text-[#A29C91] space-y-0.5 font-sans">
                        <p className="text-white">{selectedOrderForInspection.shippingAddress}</p>
                        <p>
                          {[
                            selectedOrderForInspection.city,
                            selectedOrderForInspection.state,
                            selectedOrderForInspection.postalCode,
                            selectedOrderForInspection.country,
                          ]
                            .filter(Boolean)
                            .join(", ")}
                        </p>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="space-y-2.5 mt-2">
                    <div>
                      <label className="block text-[9px] uppercase tracking-wider text-[#8C867D] mb-1 font-mono">
                        Street Address *
                      </label>
                      <input
                        type="text"
                        value={addressFormData.shippingAddress}
                        onChange={(e) =>
                          setAddressFormData({ ...addressFormData, shippingAddress: e.target.value })
                        }
                        className="w-full p-2 bg-[#121217] border border-[#2A2A36] text-white text-xs focus:border-[#C5A880] focus:outline-none"
                        placeholder="Street address or P.O. Box"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[9px] uppercase tracking-wider text-[#8C867D] mb-1 font-mono">
                          City / Town *
                        </label>
                        <input
                          type="text"
                          value={addressFormData.city}
                          onChange={(e) =>
                            setAddressFormData({ ...addressFormData, city: e.target.value })
                          }
                          className="w-full p-2 bg-[#121217] border border-[#2A2A36] text-white text-xs focus:border-[#C5A880] focus:outline-none"
                          placeholder="City / Town"
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] uppercase tracking-wider text-[#8C867D] mb-1 font-mono">
                          State / Province / District *
                        </label>
                        <input
                          type="text"
                          value={addressFormData.state}
                          onChange={(e) =>
                            setAddressFormData({ ...addressFormData, state: e.target.value })
                          }
                          className="w-full p-2 bg-[#121217] border border-[#2A2A36] text-white text-xs focus:border-[#C5A880] focus:outline-none"
                          placeholder="State / District"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[9px] uppercase tracking-wider text-[#8C867D] mb-1 font-mono">
                          Postal / ZIP Code *
                        </label>
                        <input
                          type="text"
                          value={addressFormData.postalCode}
                          onChange={(e) =>
                            setAddressFormData({ ...addressFormData, postalCode: e.target.value })
                          }
                          className="w-full p-2 bg-[#121217] border border-[#2A2A36] text-white text-xs font-mono focus:border-[#C5A880] focus:outline-none"
                          placeholder="Postal Code"
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] uppercase tracking-wider text-[#8C867D] mb-1 font-mono">
                          Country *
                        </label>
                        <LuxurySelect
                          variant="dark"
                          value={addressFormData.country}
                          onChange={(val) =>
                            setAddressFormData({ ...addressFormData, country: val })
                          }
                          options={COUNTRY_OPTIONS}
                          placeholder="Select Country"
                          searchable={true}
                          searchPlaceholder="Search country or code..."
                          triggerClassName="!p-2 text-xs"
                        />
                      </div>
                    </div>

                    <div className="flex gap-2 pt-1">
                      <button
                        type="button"
                        onClick={handleSaveAddress}
                        disabled={isSavingAddress}
                        className="flex-1 py-1.5 bg-[#C5A880] hover:bg-[#D4B992] text-black text-[10px] font-mono uppercase tracking-wider font-semibold transition-colors disabled:opacity-50"
                      >
                        {isSavingAddress ? "Saving..." : "Save Address"}
                      </button>
                      <button
                        type="button"
                        onClick={() => setIsEditingAddress(false)}
                        disabled={isSavingAddress}
                        className="px-3 py-1.5 border border-[#2A2A36] hover:bg-[#2A2A36] text-[#8C867D] hover:text-white text-[10px] font-mono uppercase tracking-wider transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Items Details */}
            <div>
              <h4 className="text-[#C5A880] uppercase text-[10px] tracking-wider mb-2 font-mono">
                Ordered Items
              </h4>
              <div className="bg-[#1A1A22] border border-[#2A2A36]/60 rounded-sm p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-[#2A2A36] pb-2">
                  <div>
                    <span className="font-sans text-white text-sm font-semibold">
                      {selectedOrderForInspection.gemstoneName}
                    </span>
                    <span className="text-[#8C867D] text-xs font-mono block">
                      {selectedOrderForInspection.carat.toFixed(2)} Carats
                    </span>
                  </div>
                  <LuxuryPrice amount={selectedOrderForInspection.total} size="sm" color="gold" weight="semibold" />
                </div>

                {selectedOrderForInspection.items &&
                  selectedOrderForInspection.items.length > 0 &&
                  selectedOrderForInspection.items.map((item, idx) => (
                    <div
                      key={idx}
                      className="text-[11px] text-[#8C867D] flex items-center justify-between pt-1"
                    >
                      <span>
                        {item.setting?.name && !item.setting.name.toLowerCase().includes("loose")
                          ? `Setting: ${item.setting.name}${item.ringSize ? ` (Ring Size: ${item.ringSize})` : ""}`
                          : "Gemstone in Presentation Box"}
                      </span>
                      <span>{item.giftBox ? "Gift Box Included" : ""}</span>
                    </div>
                  ))}

              </div>
            </div>

            {/* Dedicated Payment Verification Panel */}
            {(() => {
              const isCardSelected = isCardPaymentMethod(selectedOrderForInspection.paymentMethod);
              const selectedBankRef = getOrderBankRef(selectedOrderForInspection);
              const selectedSlipUrl = getOrderSlipUrl(selectedOrderForInspection);
              const inspectBadge = getStatusBadge(selectedOrderForInspection.status, isCardSelected);

              return (
                <div className="bg-[#1A1A22] border border-[#2A2A36]/70 rounded-sm p-4 sm:p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-[#2A2A36] pb-3">
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${isCardSelected ? "bg-emerald-400" : "bg-[#C5A880]"}`} />
                      <h4 className="text-[#C5A880] uppercase text-[11px] tracking-wider font-mono font-medium">
                        Payment &amp; Settlement Details
                      </h4>
                    </div>
                    <span className={`px-2.5 py-0.5 rounded text-[10px] font-mono border ${inspectBadge.classes}`}>
                      {inspectBadge.label}
                    </span>
                  </div>

                  {isCardSelected ? (
                    /* High-End Luxury Card Settlement Panel */
                    <div className="bg-[#14141A] border border-emerald-500/25 rounded-sm p-4 sm:p-5 space-y-4 relative overflow-hidden">
                      {/* Ambient emerald backlight glow */}
                      <div className="absolute top-0 right-0 w-80 h-32 bg-emerald-500/5 blur-2xl pointer-events-none -mr-20 -mt-10" />

                      {/* Header Row */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3.5 border-b border-[#242430]">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-sm bg-[#1E1E2A] border border-[#323246] flex items-center justify-center text-[#C5A880] shrink-0 shadow-sm">
                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <rect x="2" y="5" width="20" height="14" rx="2" strokeWidth={1.75} />
                              <line x1="2" y1="10" x2="22" y2="10" strokeWidth={1.75} />
                              <circle cx="6.5" cy="14.5" r="1" fill="currentColor" />
                              <circle cx="10" cy="14.5" r="1" fill="currentColor" />
                            </svg>
                          </div>
                          <div>
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="text-white font-sans text-sm font-semibold tracking-tight">
                                Credit / Debit Card Transaction
                              </span>
                              <span className="px-2 py-0.5 rounded-full bg-emerald-950/70 border border-emerald-600/50 text-emerald-300 font-mono text-[10px] font-semibold uppercase tracking-wider whitespace-nowrap">
                                Online Settled
                              </span>
                            </div>
                            <p className="text-[#8C867D] text-xs font-sans mt-0.5">
                              Direct electronic authorization • Gateway Verified
                            </p>
                          </div>
                        </div>

                        <div className="text-left sm:text-right shrink-0">
                          <span className="text-[10px] uppercase font-mono text-[#8C867D] block">
                            Settled Total
                          </span>
                          <LuxuryPrice
                            amount={selectedOrderForInspection.total}
                            size="md"
                            color="gold"
                            weight="bold"
                          />
                        </div>
                      </div>

                      {/* Key 3 Metrics */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-sans">
                        <div className="bg-[#0F0F14] p-3 border border-[#262634] rounded-sm space-y-1">
                          <span className="text-[10px] uppercase text-[#8C867D] font-mono block">
                            Channel
                          </span>
                          <p className="text-white font-medium text-xs flex items-center gap-1.5 whitespace-nowrap">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0 animate-pulse" />
                            <span>Online Gateway</span>
                          </p>
                          <span className="text-[10px] text-[#8C867D] block truncate">
                            Instant capture
                          </span>
                        </div>

                        <div className="bg-[#0F0F14] p-3 border border-[#262634] rounded-sm space-y-1">
                          <span className="text-[10px] uppercase text-[#8C867D] font-mono block">
                            Verification
                          </span>
                          <p className="text-emerald-400 font-medium text-xs flex items-center gap-1.5 whitespace-nowrap">
                            <svg className="w-3.5 h-3.5 text-emerald-400 shrink-0" viewBox="0 0 20 20" fill="currentColor">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                            <span>Auto-Authorized</span>
                          </p>
                          <span className="text-[10px] text-[#8C867D] block truncate">
                            No slip or code needed
                          </span>
                        </div>

                        <div className="bg-[#0F0F14] p-3 border border-[#262634] rounded-sm space-y-1">
                          <span className="text-[10px] uppercase text-[#8C867D] font-mono block">
                            Dispatch Status
                          </span>
                          <p className="text-[#C5A880] font-medium text-xs flex items-center gap-1.5 whitespace-nowrap">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#C5A880] shrink-0" />
                            <span>
                              {selectedOrderForInspection.status === "rejected"
                                ? "Declined / Cancelled"
                                : selectedOrderForInspection.status === "accepted" ||
                                  selectedOrderForInspection.status === "vault_packed" ||
                                  selectedOrderForInspection.status === "in_transit" ||
                                  selectedOrderForInspection.status === "delivered"
                                ? "In Fulfillment"
                                : "Ready for Packing"}
                            </span>
                          </p>
                          <span className="text-[10px] text-[#8C867D] block font-mono truncate">
                            Ref #{selectedOrderForInspection.id}
                          </span>
                        </div>
                      </div>

                      {/* Clean reassurance note */}
                      <div className="p-3 bg-[#111118] border-l-2 border-l-emerald-500 border-y border-r border-[#262634] rounded-sm flex items-start gap-2.5 text-[11px] text-[#A29F96] leading-relaxed">
                        <svg className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                        </svg>
                        <span>
                          Customer settled this acquisition electronically via credit/debit card. The payment was verified automatically by the gateway — no bank deposit slip or manual wire reference is needed. You may approve the order directly to begin vault packaging.
                        </span>
                      </div>
                    </div>
                  ) : (
                    /* Bank Wire Transfer Panel */
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-sans">
                      <div className="bg-[#141419] p-3.5 border border-[#262632] space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] uppercase text-[#8C867D] block font-mono">Payment Method</span>
                          <span className="text-[10px] font-mono text-[#C5A880] uppercase">Wire Transfer</span>
                        </div>
                        <p className="text-white font-medium text-sm">
                          {getPaymentDisplayName(selectedOrderForInspection.paymentMethod)}
                        </p>
                        {selectedBankRef ? (
                          <div className="mt-2 pt-2 border-t border-[#262632]">
                            <span className="text-[10px] uppercase text-[#8C867D] block font-mono mb-1">
                              Wire Reference:
                            </span>
                            <div className="flex items-center justify-between bg-[#0F0F14] px-2.5 py-1.5 border border-[#252533] rounded-sm">
                              <span className="font-mono text-xs text-[#C5A880] font-semibold select-all">
                                {selectedBankRef}
                              </span>
                              <button
                                type="button"
                                onClick={() => {
                                  if (navigator?.clipboard && selectedBankRef) {
                                    navigator.clipboard.writeText(selectedBankRef);
                                    setCopiedRef(true);
                                    setTimeout(() => setCopiedRef(false), 2000);
                                  }
                                }}
                                className="text-[10px] font-mono text-[#8C867D] hover:text-white transition-colors"
                              >
                                {copiedRef ? "✓ Copied" : "Copy"}
                              </button>
                            </div>
                          </div>
                        ) : (
                          <p className="text-[#8C867D] text-[11px] italic mt-1 pt-1 border-t border-[#262632]">
                            No wire reference code entered by patron
                          </p>
                        )}
                      </div>

                      <div className="bg-[#141419] p-3.5 border border-[#262632] space-y-2 flex flex-col justify-between">
                        <div>
                          <span className="text-[10px] uppercase text-[#8C867D] block font-mono">Bank Deposit Slip</span>
                          {selectedSlipUrl ? (
                            <span className="text-emerald-400 font-mono text-xs block mt-1 flex items-center gap-1.5">
                              <svg className="w-3.5 h-3.5 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                              </svg>
                              <span>Digital Slip Uploaded</span>
                            </span>
                          ) : (
                            <span className="text-[#8C867D] font-mono text-xs block mt-1 italic">
                              Awaiting patron deposit slip
                            </span>
                          )}
                        </div>
                        {selectedSlipUrl && (
                          <a
                            href={selectedSlipUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="mt-2 inline-flex items-center justify-center gap-1.5 px-3 py-2 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-[11px] font-sans font-semibold uppercase tracking-wider rounded-sm transition-colors shadow-sm"
                          >
                            <span>View Payment Slip ↗</span>
                          </a>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Action: Verify Payment & Accept Order or Reject */}
                  {(selectedOrderForInspection.status === "pending_verification" || selectedOrderForInspection.status === "pending_inspection") ? (
                    <div className="pt-2 border-t border-[#2A2A36] space-y-2">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <button
                          onClick={() => {
                            onUpdateOrderStatus(selectedOrderForInspection.id, "accepted");
                            setSelectedOrderForInspection({
                              ...selectedOrderForInspection,
                              status: "accepted",
                            });
                          }}
                          className="py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs uppercase tracking-wider rounded-sm transition-all flex items-center justify-center gap-2 shadow-lg active:scale-[0.99] whitespace-nowrap"
                        >
                          <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
                            <polyline points="20 6 9 17 4 12" />
                          </svg>
                          <span>
                            {isCardSelected
                              ? "Approve Card Order"
                              : "Confirm Payment & Accept"}
                          </span>
                        </button>
                        <button
                          onClick={() => {
                            onUpdateOrderStatus(selectedOrderForInspection.id, "rejected");
                            setSelectedOrderForInspection({
                              ...selectedOrderForInspection,
                              status: "rejected",
                            });
                          }}
                          className="py-3 bg-red-950/80 hover:bg-red-900/90 text-red-300 hover:text-red-200 border border-red-800/80 font-medium text-xs uppercase tracking-wider rounded-sm transition-all flex items-center justify-center gap-2 shadow-lg active:scale-[0.99] whitespace-nowrap"
                        >
                          <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
                            <line x1="18" y1="6" x2="6" y2="18" />
                            <line x1="6" y1="6" x2="18" y2="18" />
                          </svg>
                          <span>{isCardSelected ? "Decline / Void Order" : "Reject Payment"}</span>
                        </button>
                      </div>
                      <p className="text-[11px] text-[#8C867D] text-center font-sans">
                        {isCardSelected
                          ? "Approving confirms order fulfillment, commits inventory, and prepares gemstone for packing. Declining cancels the order and releases reserved stock."
                          : "Confirming adds order to Total Sales & deducts stock. Rejecting marks order as rejected and leaves stock untouched."}
                      </p>
                    </div>
                  ) : selectedOrderForInspection.status === "rejected" ? (
                    <div className="p-3 bg-red-950/50 border border-red-800/80 rounded-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-red-400" />
                        <span className="text-red-300 font-medium">
                          {isCardSelected ? "✕ Card Order Declined / Cancelled" : "✕ Payment Rejected (Order Declined)"}
                        </span>
                      </div>
                      <button
                        onClick={() => {
                          onUpdateOrderStatus(selectedOrderForInspection.id, "pending_verification");
                          setSelectedOrderForInspection({
                            ...selectedOrderForInspection,
                            status: "pending_verification",
                          });
                        }}
                        className="px-3 py-1 bg-[#1B1B24] hover:bg-[#252532] text-amber-300 border border-amber-800/60 text-[11px] font-sans rounded-sm transition-colors"
                      >
                        Re-open Verification
                      </button>
                    </div>
                  ) : selectedOrderForInspection.status === "accepted" ? (
                    <div className="p-3 bg-emerald-950/50 border border-emerald-800/80 rounded-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-emerald-400" />
                        <span className="text-emerald-300 font-medium">
                          {isCardSelected ? "✓ Card Payment Confirmed & Validated" : "✓ Payment Confirmed"}
                        </span>
                      </div>
                      <button
                        onClick={() => {
                          onUpdateOrderStatus(selectedOrderForInspection.id, "vault_packed");
                          setSelectedOrderForInspection({
                            ...selectedOrderForInspection,
                            status: "vault_packed",
                          });
                        }}
                        className="px-3 py-1.5 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-[11px] font-sans uppercase tracking-wider font-semibold rounded-sm transition-colors"
                      >
                        Mark as Packed &amp; Ready &rarr;
                      </button>
                    </div>
                  ) : null}
                </div>
              );
            })()}

            {/* Delivery Note */}
            <div className="p-3 bg-[#181822] border border-[#262634] rounded-sm text-[11px] text-[#A29F96] leading-relaxed font-sans flex items-center gap-2.5">
              <svg className="w-4 h-4 text-[#C5A880] shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
              </svg>
              <span>
                <strong className="text-white font-medium">Delivery Protocol:</strong> Orders are securely packed and dispatched in tamper-sealed presentation cases with signature required upon handover.
              </span>
            </div>

            {/* Actions */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <Link
                href={`/orders/${selectedOrderForInspection.id}`}
                target="_blank"
                className="px-4 py-2.5 bg-[#1B1B24] hover:bg-[#252532] text-xs text-[#C5A880] hover:text-[#E0CFA9] border border-[#C5A880]/30 hover:border-[#C5A880]/60 rounded-sm font-mono flex items-center gap-1.5 transition-colors"
              >
                <span>View Customer Order Page</span>
                <span className="text-[11px]">&rarr;</span>
              </Link>

              <button
                onClick={() => setSelectedOrderForInspection(null)}
                className="px-7 py-2.5 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-xs uppercase font-sans font-semibold tracking-wider rounded-sm transition-colors shadow-sm"
              >
                Close
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}
