import { pool } from "@/lib/db";
import { VIPClient } from "@/features/admin/types";
import { DEFAULT_LKR_RATE, SITE_CONFIG } from "@/lib/constants/site";

export async function getClients(): Promise<VIPClient[]> {
  try {
    // 1. Query order statistics aggregated by customer email
    const [orderStats]: any = await pool.query(`
      SELECT 
        LOWER(TRIM(client_email)) AS email,
        MAX(client_name) AS latest_name,
        MAX(client_phone) AS latest_phone,
        MAX(city) AS latest_city,
        MAX(country) AS latest_country,
        COUNT(id) AS acquisitions,
        SUM(CASE 
          WHEN currency = 'LKR' THEN CAST(total AS DECIMAL(15,2)) / ${DEFAULT_LKR_RATE} 
          ELSE CAST(total AS DECIMAL(15,2)) 
        END) AS total_spent
      FROM orders
      WHERE client_email IS NOT NULL AND TRIM(client_email) != ''
      GROUP BY LOWER(TRIM(client_email))
    `);

    const orderMap = new Map<string, any>();
    for (const stat of (orderStats || [])) {
      if (stat.email) {
        orderMap.set(stat.email, stat);
      }
    }

    // 2. Query registered users (customers only)
    const [users]: any = await pool.query(`
      SELECT id, name, LOWER(TRIM(email)) AS email, phone, role, created_at 
      FROM users 
      WHERE role IS NULL OR role != 'ADMIN'
    `);

    // 3. Query records from clients table
    const [clients]: any = await pool.query(`
      SELECT id, name, LOWER(TRIM(email)) AS email, phone, total_spent, acquisitions, tier, location, created_at
      FROM clients
    `);

    // Aggregation Map keyed by normalized email
    const customersMap = new Map<
      string,
      {
        name: string;
        email: string;
        phone: string;
        totalSpent: number;
        acquisitions: number;
        tier: string;
        location: string;
      }
    >();

    // A. Seed with registered users
    for (const u of (users || [])) {
      if (!u.email) continue;
      const email = u.email.toLowerCase().trim();
      customersMap.set(email, {
        name: u.name?.trim() || "Registered Customer",
        email,
        phone: u.phone?.trim() || "",
        totalSpent: 0,
        acquisitions: 0,
        tier: "Regular Customer",
        location: "Sri Lanka",
      });
    }

    // B. Merge with clients table
    for (const c of (clients || [])) {
      if (!c.email) continue;
      const email = c.email.toLowerCase().trim();
      const existing = customersMap.get(email) || {
        name: c.name?.trim() || "Customer",
        email,
        phone: c.phone?.trim() || "",
        totalSpent: 0,
        acquisitions: 0,
        tier: "Regular Customer",
        location: c.location?.trim() || "Sri Lanka",
      };

      if (c.name && (!existing.name || existing.name === "Registered Customer" || existing.name === "Customer")) {
        existing.name = c.name.trim();
      }
      if (c.phone && !existing.phone) {
        existing.phone = c.phone.trim();
      }
      if (c.location) {
        existing.location = c.location.trim();
      }
      if (c.tier && c.tier.toLowerCase().includes("vip")) {
        existing.tier = "VIP Customer";
      }

      customersMap.set(email, existing);
    }

    // C. Merge with orders stats (accurate spend and order counts)
    for (const [email, stat] of orderMap.entries()) {
      const existing = customersMap.get(email) || {
        name: stat.latest_name?.trim() || "Customer",
        email,
        phone: stat.latest_phone?.trim() || "",
        totalSpent: 0,
        acquisitions: 0,
        tier: "Regular Customer",
        location: stat.latest_city?.trim() || stat.latest_country?.trim() || "Sri Lanka",
      };

      if (stat.latest_name && (!existing.name || existing.name === "Customer" || existing.name === "Registered Customer")) {
        existing.name = stat.latest_name.trim();
      }
      if (stat.latest_phone && !existing.phone) {
        existing.phone = stat.latest_phone.trim();
      }
      if (stat.latest_city) {
        existing.location = stat.latest_city.trim();
      }

      existing.totalSpent = Number(stat.total_spent) || 0;
      existing.acquisitions = Number(stat.acquisitions) || 0;

      customersMap.set(email, existing);
    }

    // D. Filter out admins and test accounts
    const filteredClients: VIPClient[] = [];

    for (const c of customersMap.values()) {
      const lowerEmail = c.email.toLowerCase();
      const lowerName = c.name.toLowerCase();

      // Exclude admin staff
      const adminEmail = (process.env.ADMIN_EMAIL || SITE_CONFIG.contact.adminEmail).toLowerCase();
      if (lowerEmail === adminEmail || lowerName.includes("vault registrar") || lowerName.includes("administrator")) {
        continue;
      }

      // Exclude automated test accounts
      if (lowerEmail.startsWith("autotest.") || lowerEmail.startsWith("test.google.patron.")) {
        continue;
      }

      // Tier calculation
      const isVip =
        c.tier === "VIP Customer" ||
        c.totalSpent >= 25000 ||
        c.acquisitions >= 2;

      filteredClients.push({
        name: c.name,
        email: c.email,
        phone: c.phone || "—",
        totalSpent: c.totalSpent,
        acquisitions: c.acquisitions,
        tier: isVip ? "VIP Customer" : "Regular Customer",
        location: c.location || "Sri Lanka",
        salon: c.location || "Sri Lanka",
      });
    }

    // Sort by order count (desc), total spend (desc), name (asc)
    filteredClients.sort((a, b) => {
      if (b.acquisitions !== a.acquisitions) {
        return b.acquisitions - a.acquisitions;
      }
      if (b.totalSpent !== a.totalSpent) {
        return b.totalSpent - a.totalSpent;
      }
      return a.name.localeCompare(b.name);
    });

    return filteredClients;
  } catch (error) {
    console.error("Failed to query clients from database:", error);
    return [];
  }
}
