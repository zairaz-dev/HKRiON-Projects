import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
  Req,
} from '@nestjs/common';
import { QuotationsService } from './quotations.service';
import { CreateQuotationDto } from './dto/create-quotation.dto';
import { UpdateQuotationDto } from './dto/update-quotation.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('quotations')
export class QuotationsController {
  constructor(private readonly quotationsService: QuotationsService) {}

  @Permissions(Permission.QUOTATION_CREATE)
  @Post()
  async create(@Req() req: any, @Body() dto: CreateQuotationDto) {
    const user = req.user;
    return this.quotationsService.create(user.businessId, user.id, dto);
  }

  @Permissions(Permission.QUOTATION_VIEW)
  @Get()
  async findAll(
    @Req() req: any,
    @Query('branchId') branchId?: string,
    @Query('customerId') customerId?: string,
    @Query('status') status?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
    @Query('search') search?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    const user = req.user;
    return this.quotationsService.findAll(user.businessId, {
      branchId,
      customerId,
      status,
      startDate,
      endDate,
      search,
      page: page ? parseInt(page, 10) : 1,
      limit: limit ? parseInt(limit, 10) : 20,
      userId: user.id,
      userRole: user.role,
    });
  }

  @Permissions(Permission.QUOTATION_VIEW)
  @Get(':id')
  async findOne(@Req() req: any, @Param('id') id: string) {
    const user = req.user;
    return this.quotationsService.findOne(user.businessId, id);
  }

  @Permissions(Permission.QUOTATION_EDIT)
  @Put(':id')
  async update(
    @Req() req: any,
    @Param('id') id: string,
    @Body() dto: UpdateQuotationDto,
  ) {
    const user = req.user;
    return this.quotationsService.update(user.businessId, id, dto);
  }

  @Permissions(Permission.QUOTATION_DELETE)
  @Delete(':id')
  async delete(@Req() req: any, @Param('id') id: string) {
    const user = req.user;
    return this.quotationsService.delete(user.businessId, id);
  }

  @Permissions(Permission.SALE_CREATE)
  @Post(':id/convert-to-sale')
  async convertToSale(
    @Req() req: any,
    @Param('id') id: string,
    @Body() body?: { payments?: any[]; useAdvance?: boolean },
  ) {
    const user = req.user;
    return this.quotationsService.convertToSale(user.businessId, user.id, id, body);
  }
}
