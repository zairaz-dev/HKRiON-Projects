"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Package,
  ChevronLeft,
  Loader2,
  CheckCircle,
  Save,
  Info,
  Percent,
  Barcode,
  Calendar,
  Layers,
  ShieldCheck,
  RotateCcw,
  Sparkles,
  Tag,
  Hash,
  Scale,
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { authService } from "@/services/auth-service";
import { unitService } from "@/services/unit-service";
import { taxService } from "@/services/tax-service";
import {
  productSettingsService,
  ProductSettingsData,
} from "@/services/product-settings-service";

export default function ProductSettingsPage() {
  const router = useRouter();

  const [currentUser, setCurrentUser] = useState<any>(null);
  const [businessId, setBusinessId] = useState<string>("");

  const [units, setUnits] = useState<any[]>([]);
  const [taxRates, setTaxRates] = useState<any[]>([]);

  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);

  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  const defaultFormState: ProductSettingsData = {
    defaultProfitMargin: 20.0,
    enableAutoSku: true,
    skuPrefix: "SKU-",
    defaultBarcodeType: "CODE128",
    enableProductExpiry: true,
    expiryAlertDays: 30,
    onProductExpiry: "ALERT_ONLY",
    stopSellingBeforeExpiryDays: 0,
    enableBrands: true,
    enableCategories: true,
    enableSubCategories: true,
    enablePriceTax: true,
    enableWarranty: true,
    defaultUnitId: "",
    defaultTaxId: "",
  };

  const [productForm, setProductForm] =
    useState<ProductSettingsData>(defaultFormState);

  useEffect(() => {
    const user = authService.getCurrentUser();
    if (!user || !user.businessId) {
      router.push("/login");
      return;
    }
    setCurrentUser(user);
    setBusinessId(user.businessId);

    loadInitialData(user.businessId);
  }, []);

  const loadInitialData = async (bId: string) => {
    setLoading(true);
    setError("");
    try {
      const [unitRes, taxRes, settingsRes] = await Promise.all([
        unitService.getUnits(bId).catch(() => []),
        taxService.getTaxRates(bId).catch(() => []),
        productSettingsService.getSettings(bId),
      ]);

      setUnits(unitRes || []);
      setTaxRates(taxRes || []);
      setProductForm({
        ...defaultFormState,
        ...settingsRes,
        defaultUnitId: settingsRes.defaultUnitId || "",
        defaultTaxId: settingsRes.defaultTaxId || "",
      });
    } catch (err: any) {
      setError(err.message || "Failed to load product settings.");
    } finally {
      setLoading(false);
    }
  };

  const showSuccess = (msg: string) => {
    setSuccessMessage(msg);
    setTimeout(() => setSuccessMessage(""), 4000);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      await productSettingsService.updateSettings({
        ...productForm,
        businessId,
        defaultProfitMargin: Number(productForm.defaultProfitMargin) || 0,
        expiryAlertDays: Number(productForm.expiryAlertDays) || 0,
        stopSellingBeforeExpiryDays:
          Number(productForm.stopSellingBeforeExpiryDays) || 0,
        defaultUnitId: productForm.defaultUnitId || null,
        defaultTaxId: productForm.defaultTaxId || null,
      });
      showSuccess("Product settings saved successfully!");
    } catch (err: any) {
      setError(err.message || "Failed to save product settings.");
    } finally {
      setSaving(false);
    }
  };

  const handleResetDefaults = () => {
    setProductForm(defaultFormState);
    showSuccess("Reset to system recommended settings.");
  };

  // Sample calculated selling price based on cost 100
  const sampleCost = 100;
  const sampleSelling =
    sampleCost * (1 + (Number(productForm.defaultProfitMargin) || 0) / 100);

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/settings" />
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Glowing Ambient Orbs */}
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-primary/5 blur-[120px] pointer-events-none z-0" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[550px] h-[550px] rounded-full bg-primary/5 blur-[130px] pointer-events-none z-0" />

        <Navbar title="Product Settings" className="relative z-10" />

        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 relative z-10">
          <div className="max-w-4xl mx-auto space-y-6">

            {/* Header */}
            <div>
              <button
                onClick={() => router.push("/settings")}
                className="inline-flex items-center text-xs font-semibold text-muted-foreground hover:text-primary mb-2 transition-colors"
              >
                <ChevronLeft className="w-4 h-4 mr-1" /> Back to Settings
              </button>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <Package className="h-7 w-7 text-primary" /> Product Settings
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Configure default profit margins, auto-generated SKU rules, expiry alerts, and field toggles.
              </p>
            </div>

            {/* Notifications */}
            {successMessage && (
              <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 p-3 rounded-lg text-sm flex items-center gap-2 animate-in fade-in">
                <CheckCircle className="w-4 h-4 shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}

            {error && (
              <div className="bg-destructive/10 border border-destructive/30 text-destructive p-3 rounded-lg text-sm flex items-center gap-2 animate-in fade-in">
                <Info className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {loading ? (
              <div className="flex items-center justify-center py-16 text-muted-foreground">
                <Loader2 className="w-6 h-6 animate-spin mr-2 text-primary" /> Loading product configurations...
              </div>
            ) : (
              <form onSubmit={handleSave} className="space-y-6 pb-16">

                {/* Section 1: Pricing & Profit Margin Defaults */}
                <Card className="border border-border/50 bg-card/30 backdrop-blur-md">
                  <CardContent className="p-5 space-y-4">
                    <div className="flex items-center gap-2 border-b border-border/40 pb-3">
                      <div className="p-1.5 rounded-lg bg-primary/10 text-primary">
                        <Percent className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-sm font-bold text-foreground">Pricing & Profit Rules</h2>
                        <p className="text-xs text-muted-foreground">
                          Default profit markup and tax associations when creating new items.
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
                      {/* Default Profit Margin */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <Percent className="w-3.5 h-3.5 text-primary" /> Default Profit Margin (%)
                        </label>
                        <Input
                          type="number"
                          step="0.01"
                          min="0"
                          value={productForm.defaultProfitMargin}
                          onChange={(e) =>
                            setProductForm({
                              ...productForm,
                              defaultProfitMargin: parseFloat(e.target.value) || 0,
                            })
                          }
                          className="font-mono text-sm h-10"
                          placeholder="20"
                        />
                        <div className="bg-background/80 px-2.5 py-1.5 rounded border border-border/40 text-[11px] flex items-center justify-between">
                          <span className="text-muted-foreground">Cost 100 → Sell:</span>
                          <span className="font-mono font-bold text-primary">
                            {sampleSelling.toFixed(2)}
                          </span>
                        </div>
                      </div>

                      {/* Default Unit */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <Scale className="w-3.5 h-3.5 text-primary" /> Default Measurement Unit
                        </label>
                        <select
                          value={productForm.defaultUnitId || ""}
                          onChange={(e) =>
                            setProductForm({
                              ...productForm,
                              defaultUnitId: e.target.value,
                            })
                          }
                          className="w-full h-10 px-3 rounded-md bg-background/80 border border-border/60 text-xs focus:ring-1 focus:ring-primary focus:outline-none"
                        >
                          <option value="">-- None (Select Manually) --</option>
                          {units.map((u) => (
                            <option key={u.id} value={u.id}>
                              {u.name} ({u.code})
                            </option>
                          ))}
                        </select>
                        <p className="text-[10px] text-muted-foreground">
                          Pre-selected unit on Add Product screen.
                        </p>
                      </div>

                      {/* Default Tax Rate */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <Tag className="w-3.5 h-3.5 text-primary" /> Default Tax Rate
                        </label>
                        <select
                          value={productForm.defaultTaxId || ""}
                          onChange={(e) =>
                            setProductForm({
                              ...productForm,
                              defaultTaxId: e.target.value,
                            })
                          }
                          className="w-full h-10 px-3 rounded-md bg-background/80 border border-border/60 text-xs focus:ring-1 focus:ring-primary focus:outline-none"
                        >
                          <option value="">-- No Default Tax --</option>
                          {taxRates.map((t) => (
                            <option key={t.id} value={t.id}>
                              {t.name} ({t.rate}%)
                            </option>
                          ))}
                        </select>
                        <p className="text-[10px] text-muted-foreground">
                          Default applied sales tax on products.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Section 2: SKU & Barcode Automation */}
                <Card className="border border-border/50 bg-card/30 backdrop-blur-md">
                  <CardContent className="p-5 space-y-4">
                    <div className="flex items-center gap-2 border-b border-border/40 pb-3">
                      <div className="p-1.5 rounded-lg bg-primary/10 text-primary">
                        <Barcode className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-sm font-bold text-foreground">SKU & Barcode Automation</h2>
                        <p className="text-xs text-muted-foreground">
                          Automatic SKU generation prefixes and barcode formats.
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
                      {/* Auto SKU Toggle */}
                      <div className="p-3 rounded-lg border border-border/40 bg-background/50 flex flex-col justify-between space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold">Auto-Generate SKU</span>
                          <input
                            type="checkbox"
                            checked={productForm.enableAutoSku}
                            onChange={(e) =>
                              setProductForm({
                                ...productForm,
                                enableAutoSku: e.target.checked,
                              })
                            }
                            className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                          />
                        </div>
                        <p className="text-[10px] text-muted-foreground">
                          Generate SKU automatically if left empty by user.
                        </p>
                      </div>

                      {/* SKU Prefix */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <Hash className="w-3.5 h-3.5 text-primary" /> SKU Number Prefix
                        </label>
                        <Input
                          type="text"
                          value={productForm.skuPrefix}
                          onChange={(e) =>
                            setProductForm({
                              ...productForm,
                              skuPrefix: e.target.value,
                            })
                          }
                          className="font-mono text-xs h-10"
                          placeholder="SKU-"
                        />
                        <p className="text-[10px] text-muted-foreground">
                          Sample: <span className="font-mono font-bold text-primary">{productForm.skuPrefix}0001</span>
                        </p>
                      </div>

                      {/* Default Barcode Type */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <Barcode className="w-3.5 h-3.5 text-primary" /> Barcode Symbology
                        </label>
                        <select
                          value={productForm.defaultBarcodeType}
                          onChange={(e) =>
                            setProductForm({
                              ...productForm,
                              defaultBarcodeType: e.target.value,
                            })
                          }
                          className="w-full h-10 px-3 rounded-md bg-background/80 border border-border/60 text-xs focus:ring-1 focus:ring-primary focus:outline-none"
                        >
                          <option value="CODE128">Code 128 (Standard)</option>
                          <option value="CODE39">Code 39</option>
                          <option value="EAN13">EAN-13 (Retail)</option>
                          <option value="EAN8">EAN-8</option>
                          <option value="UPCA">UPC-A</option>
                          <option value="QR">QR Code</option>
                        </select>
                        <p className="text-[10px] text-muted-foreground">
                          Default barcode format for label printing.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Section 3: Product Expiry & Shelf Life */}
                <Card className="border border-border/50 bg-card/30 backdrop-blur-md">
                  <CardContent className="p-5 space-y-4">
                    <div className="flex items-center gap-2 border-b border-border/40 pb-3">
                      <div className="p-1.5 rounded-lg bg-primary/10 text-primary">
                        <Calendar className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-sm font-bold text-foreground">Expiry & Shelf-Life Management</h2>
                        <p className="text-xs text-muted-foreground">
                          Track product expiration dates and configure automatic sales warnings.
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
                      {/* Enable Product Expiry */}
                      <div className="p-3 rounded-lg border border-border/40 bg-background/50 flex flex-col justify-between space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold">Track Expiry Dates</span>
                          <input
                            type="checkbox"
                            checked={productForm.enableProductExpiry}
                            onChange={(e) =>
                              setProductForm({
                                ...productForm,
                                enableProductExpiry: e.target.checked,
                              })
                            }
                            className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                          />
                        </div>
                        <p className="text-[10px] text-muted-foreground">
                          Allow recording expiration dates on purchase & batches.
                        </p>
                      </div>

                      {/* Expiry Alert Days */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5 text-primary" /> Expiry Alert (Days Before)
                        </label>
                        <Input
                          type="number"
                          min="1"
                          value={productForm.expiryAlertDays}
                          onChange={(e) =>
                            setProductForm({
                              ...productForm,
                              expiryAlertDays: parseInt(e.target.value) || 0,
                            })
                          }
                          className="font-mono text-xs h-10"
                          placeholder="30"
                        />
                        <p className="text-[10px] text-muted-foreground">
                          Alert on dashboard X days prior to expiration.
                        </p>
                      </div>

                      {/* On Expiry Action */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <ShieldCheck className="w-3.5 h-3.5 text-primary" /> Action on Expired Items
                        </label>
                        <select
                          value={productForm.onProductExpiry}
                          onChange={(e) =>
                            setProductForm({
                              ...productForm,
                              onProductExpiry: e.target.value,
                            })
                          }
                          className="w-full h-10 px-3 rounded-md bg-background/80 border border-border/60 text-xs focus:ring-1 focus:ring-primary focus:outline-none"
                        >
                          <option value="ALERT_ONLY">⚠️ Show Alert & Keep Selling</option>
                          <option value="STOP_SELLING">🛑 Block & Stop Selling</option>
                        </select>
                        <p className="text-[10px] text-muted-foreground">
                          Behavior on POS when product has expired.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Section 4: Module Field Visibility Toggles */}
                <Card className="border border-border/50 bg-card/30 backdrop-blur-md">
                  <CardContent className="p-5 space-y-4">
                    <div className="flex items-center gap-2 border-b border-border/40 pb-3">
                      <div className="p-1.5 rounded-lg bg-primary/10 text-primary">
                        <Layers className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-sm font-bold text-foreground">Form Field Visibility</h2>
                        <p className="text-xs text-muted-foreground">
                          Show or hide optional fields across product creation forms.
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 pt-1">
                      {/* Brands */}
                      <div className="p-3 rounded-lg border border-border/40 bg-background/50 flex flex-col justify-between space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold">Brands</span>
                          <input
                            type="checkbox"
                            checked={productForm.enableBrands}
                            onChange={(e) =>
                              setProductForm({
                                ...productForm,
                                enableBrands: e.target.checked,
                              })
                            }
                            className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                          />
                        </div>
                        <p className="text-[10px] text-muted-foreground">Enable Brands field</p>
                      </div>

                      {/* Categories */}
                      <div className="p-3 rounded-lg border border-border/40 bg-background/50 flex flex-col justify-between space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold">Categories</span>
                          <input
                            type="checkbox"
                            checked={productForm.enableCategories}
                            onChange={(e) =>
                              setProductForm({
                                ...productForm,
                                enableCategories: e.target.checked,
                              })
                            }
                            className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                          />
                        </div>
                        <p className="text-[10px] text-muted-foreground">Enable Category field</p>
                      </div>

                      {/* Sub-categories */}
                      <div className="p-3 rounded-lg border border-border/40 bg-background/50 flex flex-col justify-between space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold">Sub-Categories</span>
                          <input
                            type="checkbox"
                            checked={productForm.enableSubCategories}
                            onChange={(e) =>
                              setProductForm({
                                ...productForm,
                                enableSubCategories: e.target.checked,
                              })
                            }
                            className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                          />
                        </div>
                        <p className="text-[10px] text-muted-foreground">Sub-category selector</p>
                      </div>

                      {/* Price Tax */}
                      <div className="p-3 rounded-lg border border-border/40 bg-background/50 flex flex-col justify-between space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold">Tax Selection</span>
                          <input
                            type="checkbox"
                            checked={productForm.enablePriceTax}
                            onChange={(e) =>
                              setProductForm({
                                ...productForm,
                                enablePriceTax: e.target.checked,
                              })
                            }
                            className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                          />
                        </div>
                        <p className="text-[10px] text-muted-foreground">Show Tax selector</p>
                      </div>

                      {/* Warranty */}
                      <div className="p-3 rounded-lg border border-border/40 bg-background/50 flex flex-col justify-between space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold">Warranty</span>
                          <input
                            type="checkbox"
                            checked={productForm.enableWarranty}
                            onChange={(e) =>
                              setProductForm({
                                ...productForm,
                                enableWarranty: e.target.checked,
                              })
                            }
                            className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                          />
                        </div>
                        <p className="text-[10px] text-muted-foreground">Warranty period field</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Actions */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-border/60">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleResetDefaults}
                    className="text-xs text-muted-foreground hover:text-foreground gap-1.5"
                  >
                    <RotateCcw className="w-3.5 h-3.5" /> Reset Defaults
                  </Button>

                  <Button
                    type="submit"
                    disabled={saving}
                    className="gap-2 min-w-[170px] shadow-md shadow-primary/10"
                  >
                    {saving ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Save className="w-4 h-4" />
                    )}
                    Save Product Settings
                  </Button>
                </div>

              </form>
            )}

          </div>
        </main>
      </div>
    </div>
  );
}
