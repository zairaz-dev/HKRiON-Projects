import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supplierPaymentService } from "@/services/supplier-payment-service";
import { queryKeys } from "@/lib/query-keys";

export function useSupplierPaymentsQuery(
  businessId: string,
  filters: {
    branchId?: string;
    supplierId?: string;
    purchaseId?: string;
  },
) {
  return useQuery({
    queryKey: queryKeys.supplierPayments.list(
      businessId,
      filters.branchId,
      filters.supplierId,
      filters.purchaseId,
    ),
    queryFn: () => supplierPaymentService.getPayments(businessId, filters),
    enabled: !!businessId,
  });
}

export function useCreateSupplierPaymentMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: Parameters<typeof supplierPaymentService.createPayment>[0]) =>
      supplierPaymentService.createPayment(data),
    onSuccess: () => {
      // Invalidate query caches for payments and purchases!
      queryClient.invalidateQueries({ queryKey: queryKeys.supplierPayments.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.purchases.all });
    },
  });
}

export function useDeleteSupplierPaymentMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, businessId }: { id: string; businessId: string }) =>
      supplierPaymentService.deletePayment(id, businessId),
    onSuccess: () => {
      // Invalidate query caches for payments and purchases!
      queryClient.invalidateQueries({ queryKey: queryKeys.supplierPayments.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.purchases.all });
    },
  });
}
