"use server";

import { prisma } from "@/lib/db";
import { getSession } from "@/lib/session";
import { Role } from "@prisma/client";
import bcrypt from "bcryptjs";
import { revalidatePath } from "next/cache";

export async function getEmployees() {
  try {
    const session = await getSession();
    if (!session || session.role === Role.EMPLOYEE) {
      return { error: "Unauthorized access" };
    }

    const employees = await prisma.user.findMany({
      where: {
        role: {
          not: Role.SUPER_ADMIN,
        }
      },
      include: {
        position: true,
        manager: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            profileImage: true,
          },
        },
      },
      orderBy: {
        createdAt: "desc",
      },
    });
    return { data: employees };
  } catch (error) {
    console.error("Failed to fetch employees:", error);
    return { error: "Failed to fetch employees." };
  }
}

export async function getEmployeeById(id: number) {
  try {
    const session = await getSession();
    if (!session || session.role === Role.EMPLOYEE) {
      return { error: "Unauthorized access" };
    }

    const employee = await prisma.user.findUnique({
      where: { id },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        email: true,
        phone: true,
        role: true,
        positionId: true,
        managerId: true,
        profileImage: true,
        position: {
          select: {
            id: true,
            title: true,
          },
        },
        manager: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            profileImage: true,
          },
        },
      },
    });

    if (!employee) {
      return { error: "Employee not found." };
    }

    return { data: employee };
  } catch (error) {
    console.error("Failed to fetch employee details:", error);
    return { error: "Failed to fetch employee details." };
  }
}

export async function getPotentialManagers() {
  try {
    const session = await getSession();
    if (!session || session.role === Role.EMPLOYEE) {
      return { error: "Unauthorized access" };
    }

    // Return users with SUPER_ADMIN or MANAGER role as potential managers
    const managers = await prisma.user.findMany({
      where: {
        role: { in: [Role.SUPER_ADMIN, Role.MANAGER] },
      },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        role: true,
      },
      orderBy: {
        firstName: "asc",
      },
    });
    return { data: managers };
  } catch (error) {
    console.error("Failed to fetch managers:", error);
    return { error: "Failed to fetch managers." };
  }
}

import { CreateEmployeeSchema, UpdateEmployeeSchema } from "@/lib/schemas";
import { logAudit } from "@/lib/audit";
import { uploadProfilePicture } from "@/lib/upload";

export async function createEmployee(formData: FormData) {
  try {
    const session = await getSession();
    if (!session || session.role === Role.EMPLOYEE) {
      return { error: "Unauthorized access" };
    }

    const parsed = CreateEmployeeSchema.safeParse(Object.fromEntries(formData));
    if (!parsed.success) {
      return { error: parsed.error.issues[0].message };
    }
    const data = parsed.data;

    // RBAC: Only Super Admins can create Super Admin accounts
    if (session.role !== Role.SUPER_ADMIN && data.role === Role.SUPER_ADMIN) {
      return { error: "Only Super Admins can create Super Admin accounts." };
    }

    // Check if email exists
    const existingUser = await prisma.user.findUnique({
      where: { email: data.email },
    });

    if (existingUser) {
      return { error: "Email is already in use." };
    }

    // Handle Profile Picture Upload
    let profileImageUrl: string | undefined;
    const file = formData.get("profileImage") as File | null;
    if (file && file.size > 0 && file.name) {
      profileImageUrl = await uploadProfilePicture(file, session.userId);
    }

    const passwordHash = await bcrypt.hash(data.password, 10);

    // Using transaction to ensure creation and audit log both succeed or fail together
    await prisma.$transaction(async (tx) => {
      await tx.user.create({
        data: {
          firstName: data.firstName,
          lastName: data.lastName,
          email: data.email,
          phone: data.phone || null,
          passwordHash,
          role: data.role,
          positionId: data.positionId,
          managerId: data.managerId,
          profileImage: profileImageUrl,
        },
      });

      await tx.auditLog.create({
        data: {
          userId: session.userId,
          action: "CREATE_EMPLOYEE",
          details: `Created employee ${data.email} with role ${data.role}`,
        }
      });
    });

    revalidatePath("/dashboard/employees");
    return { success: true };
  } catch (error) {
    console.error("Failed to create employee:", error);
    return { error: "Failed to create employee." };
  }
}

export async function updateEmployee(id: number, formData: FormData) {
  try {
    const session = await getSession();
    if (!session || session.role === Role.EMPLOYEE) {
      return { error: "Unauthorized access" };
    }

    const parsed = UpdateEmployeeSchema.safeParse(Object.fromEntries(formData));
    if (!parsed.success) {
      return { error: parsed.error.issues[0].message };
    }
    const data = parsed.data;

    // Target user check
    const targetUser = await prisma.user.findUnique({
      where: { id },
    });

    if (!targetUser) {
      return { error: "Employee not found." };
    }

    // RBAC: Only Super Admins can modify another Super Admin
    if (targetUser.role === Role.SUPER_ADMIN && session.role !== Role.SUPER_ADMIN) {
      return { error: "Only Super Admins can modify a Super Admin account." };
    }

    // RBAC: Only Super Admins can promote users to Super Admin
    if (session.role !== Role.SUPER_ADMIN && data.role === Role.SUPER_ADMIN) {
      return { error: "Only Super Admins can assign the Super Admin role." };
    }

    // Prevent user from locking themselves out by demoting their own account
    if (id === session.userId && data.role !== session.role) {
      return { error: "You cannot change your own role." };
    }

    // Prevent circular manager self-assignment
    if (data.managerId === id) {
      return { error: "An employee cannot be assigned as their own manager." };
    }

    // Check if another user has this email
    const existingUser = await prisma.user.findUnique({
      where: { email: data.email },
    });

    if (existingUser && existingUser.id !== id) {
      return { error: "Email is already in use by another employee." };
    }

    // Handle Profile Picture Upload
    let profileImageUrl: string | undefined;
    const file = formData.get("profileImage") as File | null;
    if (file && file.size > 0 && file.name) {
      profileImageUrl = await uploadProfilePicture(file, session.userId);
    }

    const dataToUpdate: any = {
      firstName: data.firstName,
      lastName: data.lastName,
      email: data.email,
      phone: data.phone || null,
      role: data.role,
      positionId: data.positionId,
      managerId: data.managerId,
    };

    if (profileImageUrl) {
      dataToUpdate.profileImage = profileImageUrl;
    }

    if (data.password && data.password.trim().length > 0) {
      dataToUpdate.passwordHash = await bcrypt.hash(data.password, 10);
    }

    await prisma.$transaction(async (tx) => {
      await tx.user.update({
        where: { id },
        data: dataToUpdate,
      });

      await tx.auditLog.create({
        data: {
          userId: session.userId,
          action: "UPDATE_EMPLOYEE",
          details: `Updated employee ${data.email} (ID: ${id})`,
        }
      });
    });

    revalidatePath("/dashboard/employees");
    return { success: true };
  } catch (error) {
    console.error("Failed to update employee:", error);
    return { error: "Failed to update employee." };
  }
}

export async function deleteEmployee(id: number) {
  try {
    const session = await getSession();
    if (!session || session.role === Role.EMPLOYEE) {
      return { error: "Unauthorized access" };
    }

    // Self-deletion safeguard
    if (id === session.userId) {
      return { error: "You cannot delete your own account." };
    }

    const targetUser = await prisma.user.findUnique({
      where: { id },
    });

    if (!targetUser) {
      return { error: "Employee not found." };
    }

    // RBAC: Only Super Admins can delete a Super Admin
    if (targetUser.role === Role.SUPER_ADMIN && session.role !== Role.SUPER_ADMIN) {
      return { error: "Only Super Admins can delete a Super Admin account." };
    }

    await prisma.$transaction(async (tx) => {
      await tx.user.delete({
        where: { id },
      });

      await tx.auditLog.create({
        data: {
          userId: session.userId,
          action: "DELETE_EMPLOYEE",
          details: `Deleted employee ${targetUser.email} (ID: ${id})`,
        }
      });
    });

    revalidatePath("/dashboard/employees");
    return { success: true };
  } catch (error) {
    console.error("Failed to delete employee:", error);
    return { error: "Failed to delete employee." };
  }
}
