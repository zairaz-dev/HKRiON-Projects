# 💎 Faizan Gems

A luxury colored gemstone e-commerce storefront and admin catalog management system built with **Next.js 16 (App Router)**, **React 19**, **Prisma**, and **MySQL**.

---

## 🚀 How to Run the Project (Step-by-Step)

### 1. Prerequisites
Ensure you have the following installed on your machine:
- **Node.js**: v20.x, v22.x, or later
- **Package Manager**: **pnpm** (v9.x or later) or **npm** (v10.x or later)
- **MySQL Server**: v8.0 or later (running locally on port `3306`)
- **Git**

---

### 2. Clone the Repository
Open your terminal and clone the repository:
```bash
git clone https://github.com/HKRiON-Pvt-Ltd/Faizan-Gems.git
cd Faizan-Gems
```

---

### 3. Install Dependencies
Install all required project dependencies using either **pnpm** (recommended) or **npm**:

#### Using pnpm:
```bash
pnpm install
```

#### Using npm:
```bash
npm install
```

---

### 4. Configure Environment Variables
Copy the example environment file:
```bash
cp .env.example .env
```

Open `.env` and verify your MySQL database credentials and secrets:
```env
# MySQL Database Connection URL
DATABASE_URL="mysql://root:@localhost:3306/gem_ecommerce"

# Secret key for session encryption & HMAC signatures
AUTH_SECRET="faizan_gems_secret_key_2026_change_in_production"

# Default admin account for initial seeding
ADMIN_EMAIL="admin@faizangems.com"
ADMIN_PASSWORD="FaizanGems@2026!"
ADMIN_NAME="Faizan Gems Admin"
ADMIN_PHONE="+94768671219"

# Optional: Custom directory for uploaded payment slips
# SLIP_STORAGE_DIR="/mnt/data/slips"
```
> *Adjust the username (`root`) or password in `DATABASE_URL` to match your local MySQL configuration if needed.*

---

### 5. Create the MySQL Database
Ensure your MySQL server is running, then create the database:

```bash
# If your MySQL root account requires a password:
mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS gem_ecommerce CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# If your MySQL root account does NOT have a password:
mysql -u root -e "CREATE DATABASE IF NOT EXISTS gem_ecommerce CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
```

---

### 6. Generate Prisma Client
Generate the type-safe Prisma client code from `prisma/schema.prisma`:

#### Using pnpm:
```bash
pnpm prisma generate
# or:
pnpm run db:generate
```

#### Using npm:
```bash
npx prisma generate
# or:
npm run db:generate
```

---

### 7. Push Schema to Database
Push the Prisma schema to synchronize all tables and relations in your MySQL database:

#### Using pnpm:
```bash
pnpm run db:push
# or:
pnpm prisma db push
```

#### Using npm:
```bash
npm run db:push
# or:
npx prisma db push
```

---

### 8. Seed Initial Data
Seed the default administrator account, initial gemstone catalog, and CMS content:

#### Using pnpm:
```bash
pnpm run db:seed
```

#### Using npm:
```bash
npm run db:seed
```

---

### 9. Start Development Server
Start the local Next.js development server:

#### Using pnpm:
```bash
pnpm dev
```

#### Using npm:
```bash
npm run dev
```

The application will be running at **[http://localhost:3000](http://localhost:3000)**.

---

### 10. Database Backups (Optional)
To create a timestamped SQL dump of the database into the `backups/` directory:

#### Using pnpm:
```bash
pnpm run db:backup
```

#### Using npm:
```bash
npm run db:backup
```

---

## 🌐 Application URLs

| Page | URL | Description |
| :--- | :--- | :--- |
| **Storefront** | [http://localhost:3000](http://localhost:3000) | Main customer-facing website & showcase |
| **Catalog / Shop** | [http://localhost:3000/shop](http://localhost:3000/shop) | Gemstone inventory with dynamic filters |
| **Admin Login** | [http://localhost:3000/login](http://localhost:3000/login) | Administrator authentication portal |
| **Admin Dashboard** | [http://localhost:3000/admin](http://localhost:3000/admin) | Inventory management, orders, CMS editor |

---

## 🔑 Default Admin Credentials

- **Email:** `admin@faizangems.com`
- **Password:** `FaizanGems@2026!`

---

## 📜 Available Scripts Comparison (npm vs pnpm)

| Task | pnpm Command | npm Command | Description |
| :--- | :--- | :--- | :--- |
| **Install packages** | `pnpm install` | `npm install` | Installs all project dependencies |
| **Development server** | `pnpm dev` | `npm run dev` | Starts dev server on [http://localhost:3000](http://localhost:3000) |
| **Prisma Generate** | `pnpm prisma generate`<br>`pnpm run db:generate` | `npx prisma generate`<br>`npm run db:generate` | Generates typed Prisma Client |
| **Push DB Schema** | `pnpm run db:push`<br>`pnpm prisma db push` | `npm run db:push`<br>`npx prisma db push` | Syncs schema changes directly to MySQL |
| **Seed Database** | `pnpm run db:seed` | `npm run db:seed` | Seeds admin and initial catalog records |
| **Database Backup** | `pnpm run db:backup` | `npm run db:backup` | Creates timestamped SQL dump in `backups/` |
| **Prisma Studio** | `pnpm run db:studio` | `npm run db:studio` | GUI browser for inspecting database data |
| **Production Build** | `pnpm build` | `npm run build` | Compiles optimized Next.js production build |
| **Start Production** | `pnpm start` | `npm run start` | Runs the compiled production server |
| **Linting** | `pnpm lint` | `npm run lint` | Runs ESLint checks |

---

## 🏛️ Credits & Engineering

Design & Technology by **[HKRiON](https://hkrion.com)** — Bespoke luxury e-commerce and enterprise digital platforms.
