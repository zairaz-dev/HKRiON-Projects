'use client';

import React, { useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { GoogleOAuthProvider } from '@react-oauth/google';
import { AiCopilotWidget } from '@/components/ai/ai-copilot-widget';

export default function Providers({ children }: { children: React.ReactNode }) {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 5 * 60 * 1000, // 5 minutes
            refetchOnWindowFocus: false, // Prevent refetching on window focus
          },
        },
      })
  );

  const isGoogleEnabled = process.env.NEXT_PUBLIC_ENABLE_GOOGLE_LOGIN !== 'false';
  const googleClientId = isGoogleEnabled ? (process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID || '') : '';

  if (isGoogleEnabled && googleClientId) {
    return (
      <GoogleOAuthProvider clientId={googleClientId}>
        <QueryClientProvider client={queryClient}>
          {children}
          <AiCopilotWidget />
        </QueryClientProvider>
      </GoogleOAuthProvider>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      {children}
      <AiCopilotWidget />
    </QueryClientProvider>
  );
}
