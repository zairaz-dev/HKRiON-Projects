"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Logo from "@/components/ui/Logo";
import { Mail, Lock, Eye, EyeOff, KeyRound, AlertCircle, ArrowLeft, Send } from "lucide-react";
import Link from "next/link";
import { ContactService } from "@/services/contact.service";

function ForgotPasswordForm({ whatsappNumber }: { whatsappNumber: string }) {
  const searchParams = useSearchParams();
  const urlError = searchParams.get("error");

  const [showPassword, setShowPassword] = useState(false);

  return (
    <div className="min-h-screen w-full bg-slate-950 flex flex-col justify-center items-center px-4 py-12 relative overflow-hidden selection:bg-amber-500 selection:text-slate-950">
      {/* Background Ambience Spotlight */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-150 h-87.5 bg-amber-500/10 blur-3xl pointer-events-none rounded-full" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-yellow-500/5 blur-3xl pointer-events-none rounded-full" />

      {/* Back to Login Button */}
      <div className="absolute top-6 left-6 z-20">
        <Link
          href="/login"
          className="inline-flex items-center gap-2 text-slate-400 hover:text-amber-400 text-xs sm:text-sm font-semibold transition-colors px-4 py-2 rounded-full bg-slate-900/80 border border-slate-800"
        >
          <ArrowLeft size={16} />
          <span>Back to Sign In</span>
        </Link>
      </div>

      <div className="w-full max-w-md relative z-10">
        <div className="bg-slate-900/90 backdrop-blur-2xl border border-slate-800/90 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/80">
          {/* Card Header with Logo */}
          <div className="text-center mb-8">
            <Link href="/" className="inline-flex justify-center mb-4">
              <Logo className="h-12 w-auto" />
            </Link>
            <div className="flex justify-center">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-400 text-xs font-bold uppercase tracking-widest mb-3">
                <KeyRound size={14} /> Password Recovery
              </div>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white">Reset Admin Password</h1>
            <p className="text-slate-400 text-xs sm:text-sm mt-1.5 font-light">
              Enter your registered administrator email to set a new password.
            </p>
          </div>

          {urlError && (
            <div className="mb-6 p-4 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs sm:text-sm flex items-center gap-3">
              <AlertCircle size={18} className="shrink-0 text-red-400" />
              <span>{urlError}</span>
            </div>
          )}

          <form method="POST" action="/api/auth/forgot-password" className="space-y-5">
            {/* Email Field */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                Registered Admin Email
              </label>
              <div className="relative">
                <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
                <input
                  name="email"
                  type="email"
                  required
                  placeholder="Enter your registered email"
                  className="w-full bg-slate-950/80 border border-slate-800 focus:border-amber-400 rounded-2xl py-3.5 pl-11 pr-4 text-white text-sm placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-amber-400 transition-all"
                />
              </div>
            </div>

            {/* New Password Field */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                New Password
              </label>
              <div className="relative">
                <Lock size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
                <input
                  name="newPassword"
                  type={showPassword ? "text" : "password"}
                  required
                  minLength={6}
                  placeholder="Minimum 6 characters"
                  className="w-full bg-slate-950/80 border border-slate-800 focus:border-amber-400 rounded-2xl py-3.5 pl-11 pr-12 text-white text-sm placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-amber-400 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors p-1"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {/* Confirm New Password Field */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                Confirm New Password
              </label>
              <div className="relative">
                <Lock size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
                <input
                  name="confirmPassword"
                  type={showPassword ? "text" : "password"}
                  required
                  minLength={6}
                  placeholder="Re-enter new password"
                  className="w-full bg-slate-950/80 border border-slate-800 focus:border-amber-400 rounded-2xl py-3.5 pl-11 pr-4 text-white text-sm placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-amber-400 transition-all"
                />
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-4 bg-linear-to-r from-primary via-amber-500 to-yellow-500 text-slate-950 font-bold rounded-2xl text-base hover:brightness-110 transition-all shadow-xl shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer active:scale-95"
            >
              <KeyRound size={18} />
              <span>Reset & Update Password</span>
            </button>
          </form>

          {/* Quick WhatsApp Support Option */}
          <div className="mt-6 pt-6 border-t border-slate-800/80 text-center">
            <p className="text-xs text-slate-400 mb-2">Need direct assistance with your account?</p>
            <a
              href={`https://wa.me/${whatsappNumber}?text=Hello%20SHADEIT%20Support,%20I%20need%20help%20recovering%20my%20admin%20account%20password.`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-xs text-emerald-400 hover:text-emerald-300 font-bold"
            >
              <Send size={12} />
              <span>Contact System Admin on WhatsApp</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default async function ForgotPasswordPage() {
  const contact = await ContactService.getContent();
  const cleanNumber = contact.whatsapp.replace(/[^0-9]/g, '');

  return (
    <Suspense fallback={<div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">Loading...</div>}>
      <ForgotPasswordForm whatsappNumber={cleanNumber} />
    </Suspense>
  );
}
