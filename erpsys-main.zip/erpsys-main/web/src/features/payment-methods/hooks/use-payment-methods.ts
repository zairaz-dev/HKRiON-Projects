import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { paymentMethodService } from "@/services/payment-method-service";
import { queryKeys } from "@/lib/query-keys";
import { PaymentMethodItem } from "../types";

export function usePaymentMethodsQuery(businessId: string, branchId?: string, onlyActive?: boolean) {
  return useQuery<PaymentMethodItem[]>({
    queryKey: queryKeys.paymentMethods.list(businessId, branchId),
    queryFn: () => paymentMethodService.getPaymentMethods(businessId, branchId, onlyActive),
    enabled: !!businessId,
  });
}

export function useCreatePaymentMethodMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: Parameters<typeof paymentMethodService.createPaymentMethod>[0]) =>
      paymentMethodService.createPaymentMethod(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.paymentMethods.all });
    },
  });
}

export function useUpdatePaymentMethodMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Parameters<typeof paymentMethodService.updatePaymentMethod>[1] }) =>
      paymentMethodService.updatePaymentMethod(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.paymentMethods.all });
    },
  });
}

export function useDeletePaymentMethodMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, businessId }: { id: string; businessId: string }) =>
      paymentMethodService.deletePaymentMethod(id, businessId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.paymentMethods.all });
    },
  });
}

export function useUpdateBranchStatusMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({
      paymentMethodId,
      branchId,
      data,
    }: {
      paymentMethodId: string;
      branchId: string;
      data: Parameters<typeof paymentMethodService.updateBranchStatus>[2];
    }) => paymentMethodService.updateBranchStatus(paymentMethodId, branchId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.paymentMethods.all });
    },
  });
}
