import { NextResponse } from "next/server";
import { getGemstoneById, deleteGemstone, updateGemstone } from "@/lib/data/gemstones-db";
import { requireAdmin } from "@/lib/require-admin";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function GET(
  _request: Request,
  props: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await props.params;
    const gemstone = await getGemstoneById(id);
    if (!gemstone) {
      return NextResponse.json({ error: "Gemstone not found" }, { status: 404 });
    }
    return NextResponse.json(gemstone);
  } catch {
    return NextResponse.json({ error: "Failed to fetch gemstone" }, { status: 500 });
  }
}

export async function PUT(
  request: Request,
  props: { params: Promise<{ id: string }> }
) {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const { id } = await props.params;
    const body = await request.json();
    const success = await updateGemstone(id, body);
    if (!success) {
      return NextResponse.json({ error: "Failed to update gemstone or specimen not found" }, { status: 404 });
    }
    const updated = await getGemstoneById(id);
    return NextResponse.json({ success: true, gemstone: updated });
  } catch {
    return NextResponse.json({ error: "Invalid gemstone update payload" }, { status: 400 });
  }
}

export async function PATCH(
  request: Request,
  props: { params: Promise<{ id: string }> }
) {
  return PUT(request, props);
}

export async function DELETE(
  _request: Request,
  props: { params: Promise<{ id: string }> }
) {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const { id } = await props.params;
    const success = await deleteGemstone(id);
    return NextResponse.json({ success });
  } catch {
    return NextResponse.json({ error: "Failed to delete gemstone" }, { status: 500 });
  }
}
