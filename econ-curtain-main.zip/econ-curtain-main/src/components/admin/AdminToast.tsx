"use client";

import { useEffect, useState, useTransition, useCallback } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import { CheckCircle2, AlertCircle, X } from "lucide-react";

export default function AdminToast() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();
  const [, startTransition] = useTransition();

  const successParam = searchParams.get("success");
  const errorParam = searchParams.get("error");

  const [dismissedParam, setDismissedParam] = useState<string | null>(null);

  const activeMessage = successParam || errorParam;
  const isVisible = Boolean(activeMessage && activeMessage !== dismissedParam);
  const isSuccess = Boolean(successParam);

  const handleDismiss = useCallback(() => {
    if (activeMessage) {
      setDismissedParam(activeMessage);
    }
    startTransition(() => {
      const params = new URLSearchParams(searchParams.toString());
      params.delete("success");
      params.delete("error");
      const newQuery = params.toString() ? `?${params.toString()}` : "";
      router.replace(`${pathname}${newQuery}`, { scroll: false });
    });
  }, [activeMessage, searchParams, pathname, router]);

  // Auto-dismiss toast after 4.5 seconds
  useEffect(() => {
    if (!isVisible) return;

    const timer = setTimeout(() => {
      handleDismiss();
    }, 4500);

    return () => clearTimeout(timer);
  }, [isVisible, handleDismiss]);

  if (!isVisible || !activeMessage) return null;

  return (
    <div
      role="alert"
      aria-live="polite"
      className="fixed top-6 right-6 z-[100] max-w-sm sm:max-w-md w-[calc(100vw-3rem)] animate-in slide-in-from-top-3 fade-in duration-300 pointer-events-auto"
    >
      <div
        className={`p-4 rounded-none backdrop-blur-2xl border shadow-2xl flex items-center justify-between gap-3.5 transition-all ${
          isSuccess
            ? "bg-white/95 dark:bg-black/95 border-emerald-500/50 text-emerald-800 dark:text-emerald-300 shadow-emerald-500/10"
            : "bg-white/95 dark:bg-black/95 border-red-500/50 text-red-800 dark:text-red-300 shadow-red-500/10"
        }`}
      >
        <div className="flex items-center gap-3 min-w-0">
          <div
            className={`w-9 h-9 rounded-none flex items-center justify-center shrink-0 border ${
              isSuccess
                ? "bg-emerald-50 dark:bg-emerald-500/15 border-emerald-200 dark:border-emerald-500/30 text-emerald-600 dark:text-emerald-400"
                : "bg-red-50 dark:bg-red-500/15 border-red-200 dark:border-red-500/30 text-red-600 dark:text-red-400"
            }`}
          >
            {isSuccess ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
          </div>
          <div className="min-w-0">
            <p className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 dark:text-neutral-500 mb-0.5">
              {isSuccess ? "System Notification" : "Action Error"}
            </p>
            <p className="text-xs sm:text-sm font-bold text-neutral-900 dark:text-white truncate">
              {activeMessage}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleDismiss}
          className="p-1.5 rounded-none text-neutral-400 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors shrink-0 cursor-pointer"
          aria-label="Dismiss notification"
        >
          <X size={16} />
        </button>
      </div>
    </div>
  );
}
