"use client";

import { useState } from "react";
import { createPosition, updatePosition, deletePosition } from "@/actions/positions";
import { Plus, Edit2, Trash2, AlertTriangle, Briefcase, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Modal } from "@/components/ui/modal";
import { PageHeader } from "@/components/ui/page-header";
import { Select } from "@/components/ui/select";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { toast } from "sonner";

type Position = {
  id: number;
  title: string;
  _count?: {
    users: number;
  };
};

type PositionClientProps = {
  positions: Position[];
  isAdmin?: boolean;
};

export default function PositionClient({ positions, isAdmin = false }: PositionClientProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [editingPosition, setEditingPosition] = useState<Position | null>(null);
  const [deletingPositionId, setDeletingPositionId] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("title-asc");

  const filteredPositions = positions
    .filter((pos) => pos.title.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => {
      if (sortBy === "title-asc") return a.title.localeCompare(b.title);
      if (sortBy === "title-desc") return b.title.localeCompare(a.title);
      if (sortBy === "emp-desc") return (b._count?.users || 0) - (a._count?.users || 0);
      if (sortBy === "emp-asc") return (a._count?.users || 0) - (b._count?.users || 0);
      return 0;
    });

  const handleOpenModal = (position?: Position) => {
    setError(null);
    if (position) {
      setEditingPosition(position);
    } else {
      setEditingPosition(null);
    }
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingPosition(null);
    setError(null);
  };

  const confirmDelete = (id: number) => {
    setDeletingPositionId(id);
    setIsDeleteModalOpen(true);
  };

  const handleDelete = async () => {
    if (!deletingPositionId) return;
    setIsLoading(true);
    const res = await deletePosition(deletingPositionId);
    if (res.error) {
      setError(res.error);
      toast.error(res.error);
    } else {
      setIsDeleteModalOpen(false);
      setDeletingPositionId(null);
      toast.success("Position deleted successfully!");
    }
    setIsLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    const formData = new FormData(e.currentTarget);
    let res;

    if (editingPosition) {
      res = await updatePosition(editingPosition.id, formData);
    } else {
      res = await createPosition(formData);
    }

    if (res.error) {
      setError(res.error);
      toast.error(res.error);
    } else {
      handleCloseModal();
      toast.success(editingPosition ? "Position updated!" : "Position created!");
    }
    setIsLoading(false);
  };

  return (
    <div className="space-y-6">
      <PageHeader 
        title="Positions"
        description="Define and manage job titles across your organization."
        actions={
          isAdmin ? (
            <Button onClick={() => handleOpenModal()}>
              <Plus className="mr-2 h-4 w-4" />
              Add Position
            </Button>
          ) : null
        }
      />

      <div className="flex flex-col sm:flex-row gap-4 mb-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-text-secondary" />
          <Input
            type="text"
            placeholder="Search positions..."
            className="pl-9 bg-surface"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2">
          <div className="w-56">
            <Select
              size="sm"
              value={sortBy}
              onValueChange={setSortBy}
              options={[
                { value: "title-asc", label: "Sort: Title (A-Z)" },
                { value: "title-desc", label: "Sort: Title (Z-A)" },
                { value: "emp-desc", label: "Sort: Employees (High to Low)" },
                { value: "emp-asc", label: "Sort: Employees (Low to High)" },
              ]}
            />
          </div>
        </div>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Title</TableHead>
            <TableHead>Employees</TableHead>
            {isAdmin && <TableHead className="text-right">Actions</TableHead>}
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredPositions.length === 0 ? (
            <TableRow>
              <TableCell colSpan={3} className="h-32 text-center">
                <div className="flex flex-col items-center justify-center text-text-secondary">
                  <Briefcase className="h-10 w-10 mb-3 text-border" />
                  <p className="font-medium text-text-primary">No positions found</p>
                  <p className="text-sm mt-1">Try adjusting your search query.</p>
                </div>
              </TableCell>
            </TableRow>
          ) : (
            filteredPositions.map((position) => (
              <TableRow key={position.id}>
                <TableCell>
                  <div className="font-medium text-text-primary">{position.title}</div>
                </TableCell>
                <TableCell>
                  <Badge variant="secondary">
                    {position._count?.users || 0}
                  </Badge>
                </TableCell>
                {isAdmin && (
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon" onClick={() => handleOpenModal(position)} title="Edit">
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => confirmDelete(position.id)} title="Delete" className="hover:text-error hover:bg-error-bg">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                )}
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>

      <Modal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        title={editingPosition ? "Edit Position" : "Add New Position"}
      >
        {error && (
          <div className="mb-5 p-3 rounded-md bg-error-bg border border-error-border text-error text-sm flex items-start gap-2">
            <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-text-primary">Position Title <span className="text-error">*</span></label>
            <Input
              type="text"
              name="title"
              required
              defaultValue={editingPosition?.title}
              placeholder="e.g. Software Engineer"
            />
          </div>

          <div className="pt-6 flex gap-3 justify-end border-t border-border mt-6">
            <Button type="button" variant="outline" onClick={handleCloseModal} disabled={isLoading}>
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading} className="min-w-[80px]">
              {isLoading ? "Saving..." : "Save"}
            </Button>
          </div>
        </form>
      </Modal>

      <Modal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
      >
        <div className="text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-error-bg mb-4">
            <AlertTriangle className="h-6 w-6 text-error" />
          </div>
          <h3 className="text-lg font-semibold text-text-primary mb-2">Delete Position?</h3>
          <p className="text-sm text-text-secondary mb-6">
            Are you sure you want to delete this position? Any employees assigned to this position will have it removed.
          </p>
          <div className="flex gap-3 justify-center">
            <Button variant="outline" onClick={() => setIsDeleteModalOpen(false)} disabled={isLoading}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete} disabled={isLoading} className="min-w-[80px]">
              {isLoading ? "Deleting..." : "Delete"}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
