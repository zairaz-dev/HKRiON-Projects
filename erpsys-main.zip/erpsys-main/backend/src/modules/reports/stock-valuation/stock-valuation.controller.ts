import { Controller, Get, Query, UseGuards, Req } from '@nestjs/common';
import { StockValuationService } from './stock-valuation.service';
import { JwtAuthGuard } from '../../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { PermissionsGuard } from '../../../common/guards/permissions.guard';
import { Permissions } from '../../../common/decorators/permissions.decorator';
import { Permission } from '../../../common/enums/permission.enum';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('reports/stock-valuation')
export class StockValuationController {
  constructor(private readonly stockValuationService: StockValuationService) {}

  @Permissions(Permission.REPORT_VIEW)
  @Get()
  async getStockValuation(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
    @Query('search') search?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.stockValuationService.getStockValuation(bId, {
      branchId,
      search,
    });
  }
}

