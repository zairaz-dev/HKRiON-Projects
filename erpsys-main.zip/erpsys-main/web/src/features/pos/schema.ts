import * as z from 'zod';

export const checkoutSchema = z.object({
  customerId: z.string().min(1, 'Customer is required'),
  discountType: z.enum(['FIXED', 'PERCENTAGE']).optional(),
  discountAmount: z.number().min(0).default(0),
  taxAmount: z.number().min(0).default(0),
  notes: z.string().optional(),
  useAdvance: z.boolean().default(false),
  payments: z.array(
    z.object({
      amount: z.number().min(0),
      paymentMethodId: z.string().min(1, 'Payment method is required'),
      transactionNo: z.string().optional(),
      notes: z.string().optional(),
    })
  ),
});

export const customerAdvanceSchema = z.object({
  customerId: z.string().min(1, 'Customer is required'),
  amount: z.number().min(1, 'Amount must be greater than 0'),
  paymentMethodId: z.string().min(1, 'Payment method is required'),
  transactionNo: z.string().optional(),
  notes: z.string().optional(),
});
