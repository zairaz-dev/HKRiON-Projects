'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { 
  Menu, 
  X, 
  ArrowUpRight,
  ChevronRight,
  Home,
  Layers,
  Box,
  Briefcase,
  BookOpen,
  Users,
  PhoneCall
} from 'lucide-react';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Prevent background scroll when mobile drawer is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [mobileMenuOpen]);

  const navLinks = [
    { name: 'Home', href: '/', icon: Home },
    { name: 'Services', href: '/services', icon: Layers },
    { name: 'Products', href: '/products', icon: Box },
    { name: 'Careers', href: '/careers', icon: Briefcase, badge: 'Hiring' },
    { name: 'Blog', href: '/blog', icon: BookOpen },
    { name: 'About Us', href: '/about', icon: Users },
    { name: 'Contact', href: '/contact', icon: PhoneCall },
  ];

  return (
    <>
      <header className={`fixed top-0 left-0 right-0 z-40 border-b transition-all duration-300 ${scrolled ? 'glass-nav py-3.5 shadow-2xl shadow-black border-[#1ABE56]/30' : 'bg-transparent py-5 border-[#1ABE56]/0'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          
          {/* Brand Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="relative h-10 w-auto flex items-center justify-center">
              <Image 
                src="/assets/logos/logo.png" 
                alt="HKRION (Pvt) Ltd Logo" 
                width={40} 
                height={40} 
                className="h-full w-auto object-contain group-hover:scale-105 transition-transform"
                priority
              />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold tracking-tight text-white flex items-center gap-1 font-outfit">
                HKRION
              </span>
            </div>
          </Link>

          {/* Desktop Nav Links */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                className="text-sm font-medium text-neutral-300 hover:text-[#1ABE56] transition-colors flex items-center gap-1.5"
              >
                <span>{link.name}</span>
                {link.badge && (
                  <span className="text-[10px] font-mono font-bold bg-[#1ABE56]/20 text-[#1ABE56] px-1.5 py-0.5 rounded border border-[#1ABE56]/40">
                    {link.badge}
                  </span>
                )}
              </Link>
            ))}
          </nav>

          {/* Desktop Action Button */}
          <div className="hidden md:flex items-center gap-4">
            <Link
              href="/login"
              className="px-4 py-2 rounded-xl text-sm font-medium text-neutral-300 hover:text-white border border-neutral-800 hover:border-[#1ABE56]/40 transition-colors"
            >
              Login
            </Link>
            <Link
              href="/contact"
              className="glow-btn px-5 py-2.5 rounded-xl text-sm font-semibold text-white flex items-center gap-2"
            >
              <span>Start a Project</span>
              <ArrowUpRight className="w-4 h-4" />
            </Link>
          </div>

          {/* Mobile Menu Hamburger Button */}
          <button
            onClick={() => setMobileMenuOpen(true)}
            className="md:hidden p-2.5 rounded-xl text-neutral-200 hover:text-white bg-neutral-900/80 border border-[#1ABE56]/30 active:scale-95 transition-all"
            aria-label="Open Mobile Drawer Menu"
          >
            <Menu className="w-6 h-6 text-[#1ABE56]" />
          </button>
        </div>
      </header>

      {/* Mobile Navigation Drawer Backdrop Overlay */}
      {mobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 md:hidden animate-fade-in"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Mobile Slide-in Side Drawer */}
      <aside
        className={`fixed top-0 right-0 bottom-0 w-[85%] max-w-sm h-full bg-black/98 border-l border-[#1ABE56]/30 shadow-2xl z-50 md:hidden flex flex-col justify-between transform transition-transform duration-300 ease-in-out ${
          mobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Drawer Header */}
        <div className="p-5 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="relative h-8 w-auto flex items-center justify-center">
              <Image 
                src="/assets/logos/logo.png" 
                alt="HKRION (Pvt) Ltd Logo" 
                width={32} 
                height={32} 
                className="h-full w-auto object-contain"
              />
            </div>
            <span className="text-lg font-bold text-white tracking-wide font-outfit">HKRION</span>
          </div>
          <button
            onClick={() => setMobileMenuOpen(false)}
            className="p-2 rounded-xl text-neutral-400 hover:text-white bg-neutral-900 border border-neutral-800 active:scale-95 transition-all"
            aria-label="Close Drawer"
          >
            <X className="w-5 h-5 text-neutral-300" />
          </button>
        </div>

        {/* Drawer Scrollable Navigation Links */}
        <div className="p-5 overflow-y-auto space-y-1.5 flex-1">
          {navLinks.map((link) => {
            const IconComponent = link.icon;
            return (
              <Link
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center justify-between p-3 rounded-xl text-neutral-200 hover:text-white hover:bg-neutral-900/90 border border-transparent hover:border-[#1ABE56]/30 transition-all group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-neutral-900 border border-neutral-800 flex items-center justify-center group-hover:border-[#1ABE56]/50 transition-colors">
                    <IconComponent className="w-4 h-4 text-[#1ABE56]" />
                  </div>
                  <span className="text-base font-medium">{link.name}</span>
                </div>

                <div className="flex items-center gap-2">
                  {link.badge && (
                    <span className="text-[10px] font-mono font-bold bg-[#1ABE56]/20 text-[#1ABE56] px-2 py-0.5 rounded border border-[#1ABE56]/40">
                      {link.badge}
                    </span>
                  )}
                  <ChevronRight className="w-4 h-4 text-neutral-600 group-hover:text-[#1ABE56] group-hover:translate-x-0.5 transition-all" />
                </div>
              </Link>
            );
          })}
        </div>

        {/* Drawer Footer CTA */}
        <div className="p-5 border-t border-neutral-800 bg-neutral-950/60 space-y-3">
          <Link
            href="/contact"
            onClick={() => setMobileMenuOpen(false)}
            className="glow-btn block text-center w-full py-3.5 rounded-xl text-sm font-semibold text-white shadow-lg shadow-[#1ABE56]/20 active:scale-98 transition-all"
          >
            Start a Project
          </Link>
          <p className="text-center text-xs font-mono text-neutral-400 pt-1">
            Enterprise ERP, IoT & Software Solutions
          </p>
        </div>
      </aside>
    </>
  );
}
