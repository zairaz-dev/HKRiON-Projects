/**
 * Centralized LocalStorage and Cache Keys.
 * Includes legacy keys for backward-compatible data migration.
 */

export const STORAGE_KEYS = {
  cart: "fg_vault_cart_v1",
  legacyCart: "maison_cart",

  wishlist: "fg_vault_wishlist_v1",
  legacyWishlist: "maison_vault_wishlist",

  currency: "fg_vault_currency_v1",
  legacyCurrency: "maison_currency",

  cmsCache: "fg_cms_blocks_cache_v1",
  pwaDismissed: "faizan_pwa_dismissed",
  adminViewedOrderIds: "fg_admin_viewed_order_ids",
  gemstoneAttributes: "faizan_gemstone_attributes_v2",
} as const;
