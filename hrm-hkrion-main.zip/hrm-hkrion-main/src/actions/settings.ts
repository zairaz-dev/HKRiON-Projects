"use server";

import { prisma } from "@/lib/db";
import { getSession } from "@/lib/session";
import bcrypt from "bcryptjs";
import { revalidatePath } from "next/cache";
import { uploadProfilePicture } from "@/lib/upload";

import { UpdateProfileSchema, UpdatePasswordSchema } from "@/lib/schemas";

export async function updateProfile(formData: FormData) {
  try {
    const session = await getSession();
    if (!session) {
      return { error: "Unauthorized" };
    }

    const parsed = UpdateProfileSchema.safeParse(Object.fromEntries(formData));
    if (!parsed.success) {
      return { error: parsed.error.issues[0].message };
    }
    const data = parsed.data;

    // Check if email is already taken by another user
    const existingEmail = await prisma.user.findUnique({
      where: { email: data.email }
    });

    if (existingEmail && existingEmail.id !== session.userId) {
      return { error: "Email is already in use by another account." };
    }

    // Handle Profile Picture Upload
    let profileImageUrl: string | undefined;
    const file = formData.get("profileImage") as File | null;
    if (file && file.size > 0 && file.name) {
      profileImageUrl = await uploadProfilePicture(file, session.userId);
    }

    await prisma.$transaction(async (tx) => {
      const updateData: any = {
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        phone: data.phone || null,
      };

      if (profileImageUrl) {
        updateData.profileImage = profileImageUrl;
      }

      await tx.user.update({
        where: { id: session.userId },
        data: updateData
      });

      await tx.auditLog.create({
        data: {
          userId: session.userId,
          action: "UPDATE_PROFILE",
          details: `Updated personal profile details`,
        }
      });
    });

    revalidatePath("/dashboard/settings");
    revalidatePath("/dashboard"); // To update the topbar/sidebar if needed
    return { success: true };
  } catch (error) {
    console.error("Failed to update profile:", error);
    return { error: "Failed to update profile." };
  }
}

export async function updatePassword(formData: FormData) {
  try {
    const session = await getSession();
    if (!session) {
      return { error: "Unauthorized" };
    }

    const parsed = UpdatePasswordSchema.safeParse(Object.fromEntries(formData));
    if (!parsed.success) {
      return { error: parsed.error.issues[0].message };
    }
    const data = parsed.data;

    const user = await prisma.user.findUnique({
      where: { id: session.userId }
    });

    if (!user) {
      return { error: "User not found." };
    }

    const isMatch = await bcrypt.compare(data.currentPassword, user.passwordHash);
    if (!isMatch) {
      return { error: "Current password is incorrect." };
    }

    const isSame = await bcrypt.compare(data.newPassword, user.passwordHash);
    if (isSame) {
      return { error: "New password cannot be the same as your current password." };
    }

    const newPasswordHash = await bcrypt.hash(data.newPassword, 12);

    await prisma.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: session.userId },
        data: {
          passwordHash: newPasswordHash
        }
      });

      await tx.auditLog.create({
        data: {
          userId: session.userId,
          action: "UPDATE_PASSWORD",
          details: `Changed personal account password`,
        }
      });

      await tx.notification.create({
        data: {
          userId: session.userId,
          title: "Password Updated",
          message: "Your account password was successfully changed.",
          link: "/dashboard/settings?tab=security",
        },
      });
    });

    revalidatePath("/dashboard/settings");
    return { success: true };
  } catch (error) {
    console.error("Failed to update password:", error);
    return { error: "Failed to update password." };
  }
}
