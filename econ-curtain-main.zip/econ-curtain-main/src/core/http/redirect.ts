import { NextResponse } from "next/server";

export class SafeHttp {
  /**
   * Resolves the true routeable origin of the request, eliminating 0.0.0.0 bind address errors.
   */
  static getOrigin(request: Request): string {
    const referer = request.headers.get("referer");
    if (referer) {
      try {
        const refUrl = new URL(referer);
        if (!refUrl.hostname.includes("0.0.0.0")) {
          return refUrl.origin;
        }
      } catch {}
    }

    const host =
      request.headers.get("x-forwarded-host") ||
      request.headers.get("host") ||
      "localhost:3001";
    const proto = request.headers.get("x-forwarded-proto") || "http";

    const cleanHost = host.includes("0.0.0.0") ? "localhost:3001" : host;
    return `${proto}://${cleanHost}`;
  }

  /**
   * Generates a safe URL instance bound to the real user host
   */
  static getUrl(path: string, request: Request): URL {
    const origin = this.getOrigin(request);
    const cleanPath = path.startsWith("/") ? path : `/${path}`;
    return new URL(cleanPath, origin);
  }

  /**
   * Performs an error-free 303 Redirect to the target path
   */
  static redirect(path: string, request: Request, status = 303): NextResponse {
    const safeUrl = this.getUrl(path, request);
    return NextResponse.redirect(safeUrl, status);
  }
}
