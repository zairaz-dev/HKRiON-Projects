'use client';

import { Mail, ShieldCheck, Code, Sparkles, UserCheck } from 'lucide-react';

const leadership = [
  {
    name: 'Mohamed Ilham',
    role: 'CEO (Founder & Chief Executive Officer)',
    badge: 'Executive Leadership',
    tag: 'CEO',
    bio: 'Visionary tech entrepreneur leading HKRION (Pvt) Ltd. Oversees strategic direction, enterprise partnerships, and product innovation.',
    image: '/images/people/mohamed_ilham.png',
    linkedin: 'https://www.linkedin.com/in/ilhamhkr',
    github: '#',
    email: 'ceo@hkrion.com'
  },
  {
    name: 'Fathima Zahra',
    role: 'Chief Technology Officer (CTO)',
    badge: 'Technical Lead',
    tag: 'CTO',
    bio: 'Architect of HKRION core cloud infrastructure, Next-Gen ERP engines, database scalability, and system security standards.',
    image: '/images/people/fathimazahra.png',
    linkedin: 'https://www.linkedin.com/in/fathima-zahra-446385229/',
    github: '#',
    email: 'cto@hkrion.com'
  }
];

const teamMembers = [
  {
    name: 'Jawed Karim',
    role: 'Head of Product & UI/UX',
    specialty: 'Figma & Design Systems',
    image: 'https://kristalle.com/wp-content/uploads/2020/07/dummy-profile-pic-1.jpg',
    icon: Sparkles
  },
  {
    name: 'Mustafa Suleyman',
    role: 'Lead Full-Stack Engineer',
    specialty: 'Next.js, Node.js & MySQL',
    image: 'https://kristalle.com/wp-content/uploads/2020/07/dummy-profile-pic-1.jpg',
    icon: Code
  },
  {
    name: 'Adnan Khurram',
    role: 'Mobile & IoT Solutions Lead',
    specialty: 'Flutter, Android & Telemetry',
    image: 'https://kristalle.com/wp-content/uploads/2020/07/dummy-profile-pic-1.jpg',
    icon: UserCheck
  },
  {
    name: 'Ivan Holovatyi',
    role: 'DevOps & Cloud Architect',
    specialty: 'AWS Cloud, Docker & Security',
    image: 'https://kristalle.com/wp-content/uploads/2020/07/dummy-profile-pic-1.jpg',
    icon: ShieldCheck
  }
];

export default function Team() {
  return (
    <section id="team" className="py-24 bg-black relative overflow-hidden border-t border-white/10">
      
      {/* Background ambient light */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-125 h-125 bg-[#1ABE56]/15 blur-[160px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <span className="text-xs font-mono font-bold uppercase tracking-widest text-[#1ABE56] bg-[#1ABE56]/10 px-4 py-1.5 rounded-full border border-[#1ABE56]/30 inline-block animate-pulse">
            MEET OUR LEADERSHIP & TEAM
          </span>
          <h2 className="text-3xl sm:text-5xl font-semibold text-white tracking-tight">
            The Minds Behind <span className="gradient-text">HKRION (Pvt) Ltd</span>
          </h2>
          <p className="text-neutral-400 text-base sm:text-lg leading-relaxed">
            Our multi-disciplinary team of engineers, system architects, and designers are dedicated to building world-class enterprise software.
          </p>
        </div>

        {/* Executive Leadership Grid (CEO & CTO) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {leadership.map((exec, idx) => (
            <div
              key={idx}
              className="glass-card p-6 sm:p-8 rounded-3xl border border-[#1ABE56]/40 bg-neutral-950/90 hover:border-[#1ABE56] transition-all duration-300 group flex flex-col sm:flex-row gap-6 items-center sm:items-start relative overflow-hidden shadow-xl hover:shadow-[#1ABE56]/20"
            >
              {/* Top-Right Modern Tag */}
              <div className="absolute top-4 right-4 sm:top-5 sm:right-5 px-3 py-1 rounded-full bg-[#1ABE56]/15 text-[#1ABE56] border border-[#1ABE56]/40 font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 backdrop-blur-md shadow-md z-10">
                <span className="w-1.5 h-1.5 rounded-full bg-[#1ABE56] animate-pulse" />
                {exec.tag}
              </div>
              {/* Profile Image */}
              <div className="relative w-32 h-32 sm:w-36 sm:h-36 rounded-full overflow-hidden border-2 border-[#1ABE56]/50 shrink-0 group-hover:border-[#1ABE56] transition-colors shadow-lg">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={exec.image}
                  alt={exec.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>

              {/* Info Details */}
              <div className="space-y-3 flex-1 text-center sm:text-left">
                <span className="text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-md bg-[#1ABE56]/20 text-[#1ABE56] border border-[#1ABE56]/40 inline-block">
                  {exec.badge}
                </span>

                <div>
                  <h3 className="text-2xl font-bold text-white group-hover:text-[#1ABE56] transition-colors">
                    {exec.name}
                  </h3>
                  <p className="text-xs font-mono text-[#1ABE56] font-semibold">{exec.role}</p>
                </div>

                <p className="text-neutral-300 text-xs sm:text-sm leading-relaxed">
                  {exec.bio}
                </p>

                {/* Contact & Social Links */}
                <div className="pt-2 flex items-center justify-center sm:justify-start gap-3">
                  <a
                    href={exec.email ? `mailto:${exec.email}` : '#'}
                    className="p-2 rounded-lg bg-neutral-900 text-neutral-300 border border-white/10 hover:border-[#1ABE56] hover:text-[#1ABE56] transition-colors"
                    title="Send Email"
                  >
                    <Mail className="w-4 h-4" />
                  </a>
                  <a
                    href={exec.linkedin}
                    target={exec.linkedin !== '#' ? "_blank" : undefined}
                    rel={exec.linkedin !== '#' ? "noopener noreferrer" : undefined}
                    className="p-2 rounded-lg bg-neutral-900 text-neutral-300 border border-white/10 hover:border-[#1ABE56] hover:text-[#1ABE56] transition-colors"
                    title="LinkedIn"
                  >
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                      <path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.28 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.75M6.46 10.9v8.37H9.25V10.9H6.46M7.86 6.78a1.63 1.63 0 1 0 0 3.26 1.63 1.63 0 0 0 0-3.26z" />
                    </svg>
                  </a>
                  <a
                    href={exec.github}
                    className="p-2 rounded-lg bg-neutral-900 text-neutral-300 border border-white/10 hover:border-[#1ABE56] hover:text-[#1ABE56] transition-colors"
                    title="GitHub"
                  >
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                      <path d="M12 2A10 10 0 0 0 2 12c0 4.42 2.87 8.17 6.84 9.5.5.08.66-.23.66-.5v-1.69c-2.77.6-3.36-1.34-3.36-1.34-.46-1.16-1.11-1.47-1.11-1.47-.91-.62.07-.6.07-.6 1 .07 1.53 1.03 1.53 1.03.87 1.52 2.34 1.07 2.91.83.1-.65.35-1.09.63-1.34-2.22-.25-4.55-1.11-4.55-4.92 0-1.11.38-2 1.03-2.71-.1-.25-.45-1.29.1-2.64 0 0 .84-.27 2.75 1.02.79-.22 1.65-.33 2.5-.33.85 0 1.71.11 2.5.33 1.91-1.29 2.75-1.02 2.75-1.02.55 1.35.2 2.39.1 2.64.65.71 1.03 1.6 1.03 2.71 0 3.82-2.34 4.66-4.57 4.91.36.31.69.92.69 1.85V21c0 .27.16.59.67.5C19.14 20.16 22 16.42 22 12A10 10 0 0 0 12 2z" />
                    </svg>
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Team Members Grid */}
        <div className="space-y-6">
          <div className="text-center sm:text-left">
            <h3 className="text-xl font-bold text-white tracking-tight flex items-center justify-center sm:justify-start gap-2">
              <span className="w-2 h-2 rounded-full bg-[#1ABE56] animate-ping" />
              Core Engineering Team
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {teamMembers.map((member, idx) => {
              const Icon = member.icon;
              return (
                <div
                  key={idx}
                  className="glass-card p-5 rounded-2xl border border-white/10 bg-neutral-950/80 hover:border-[#1ABE56]/60 transition-all duration-300 group flex items-center gap-4 hover:-translate-y-1"
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-14 h-14 rounded-full object-cover border border-[#1ABE56]/40 shrink-0 group-hover:border-[#1ABE56] transition-colors"
                  />
                  <div className="overflow-hidden">
                    <h4 className="text-sm font-bold text-white group-hover:text-[#1ABE56] transition-colors truncate">
                      {member.name}
                    </h4>
                    <p className="text-xs font-mono text-[#1ABE56] truncate">{member.role}</p>
                    <div className="flex items-center gap-1 mt-1 text-[11px] font-mono text-neutral-400">
                      <Icon className="w-3 h-3 text-[#1ABE56] shrink-0" />
                      <span className="truncate">{member.specialty}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
}
