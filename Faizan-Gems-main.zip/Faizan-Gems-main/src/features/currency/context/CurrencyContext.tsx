"use client";

import React, { createContext, useContext, useState, useEffect } from "react";
import { STORAGE_KEYS } from "@/lib/constants/storage";

export type CurrencyCode = "USD";

interface CurrencyConfig {
  symbol: string;
  rate: number;
  label: string;
  flag: string;
}

export const CURRENCY_MAP: Record<CurrencyCode, CurrencyConfig> = {
  USD: { symbol: "$", rate: 1, label: "USD ($)", flag: "US" },
};

interface CurrencyContextType {
  currency: CurrencyCode;
  setCurrency: (code: CurrencyCode) => void;
  formatPrice: (amount: number) => string;
  convertPrice: (amount: number) => number;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export function CurrencyProvider({ children }: { children: React.ReactNode }) {
  const [currency] = useState<CurrencyCode>("USD");

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.currency, "USD");
    } catch {
      // ignore
    }
  }, []);

  const setCurrency = () => {
    // Platform currency is locked strictly to USD
  };

  const convertPrice = (amount: number): number => {
    const config = CURRENCY_MAP.USD;
    return Math.round(amount * config.rate);
  };

  const formatPrice = (amount: number): string => {
    const config = CURRENCY_MAP.USD;
    const converted = Math.round(amount * config.rate);
    return `${config.symbol}${converted.toLocaleString("en-US")}`;
  };

  return (
    <CurrencyContext.Provider value={{ currency, setCurrency, formatPrice, convertPrice }}>
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const context = useContext(CurrencyContext);
  if (!context) {
    throw new Error("useCurrency must be used within a CurrencyProvider");
  }
  return context;
}
