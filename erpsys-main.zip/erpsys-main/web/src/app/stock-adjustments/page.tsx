"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import {
  SlidersHorizontal,
  Loader2,
  CheckCircle,
  AlertCircle,
  Building2,
  Calendar,
  Search,
  User as UserIcon,
  FileText,
  Plus,
  Tag
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { DataTable, ColumnDef } from "@/components/ui/table";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";
import {
  useStockAdjustmentsQuery,
  CreateAdjustmentDialog,
  AdjustmentDetailDialog
} from "@/features/stock-adjustments";
import { useBranchesQuery } from "@/features/suppliers/hooks/use-suppliers";
import { useCurrency } from "@/hooks/use-currency";

function StockAdjustmentsPageContent() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Success / Error notifications
  const [successMessage, setSuccessMessage] = useState("none");
  const [error, setError] = useState("");

  // Dialog States
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedAdjustment, setSelectedAdjustment] = useState<any | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  // URL Search Params for Filters
  const selectedBranchFilter = searchParams.get("branchId") || "all";
  const selectedTypeFilter = (searchParams.get("type") as "ADDITION" | "SUBTRACTION" | "all") || "all";
  const currentPage = Number(searchParams.get("page")) || 1;
  const searchQuery = searchParams.get("search") || "";
  const limit = Number(searchParams.get("limit")) || 10;

  const setSelectedBranchFilter = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1");
    if (value === "all") {
      params.delete("branchId");
    } else {
      params.set("branchId", value);
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  const setSelectedTypeFilter = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1");
    if (value === "all") {
      params.delete("type");
    } else {
      params.set("type", value);
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  const handlePageChange = (newPage: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", String(newPage));
    router.push(`${pathname}?${params.toString()}`);
  };

  const handleSearchChange = (newSearch: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1");
    if (newSearch) {
      params.set("search", newSearch);
    } else {
      params.delete("search");
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  const handleLimitChange = (newLimit: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("limit", String(newLimit));
    params.set("page", "1");
    router.push(`${pathname}?${params.toString()}`);
  };

  // Auth check
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  const businessId = currentUser?.businessId || "";
  const { symbol, format } = useCurrency(businessId);

  // Queries
  const { data: adjustmentsResponse, isLoading: adjustmentsLoading } = useStockAdjustmentsQuery(
    businessId,
    {
      branchId: selectedBranchFilter !== "all" ? selectedBranchFilter : undefined,
      type: selectedTypeFilter !== "all" ? selectedTypeFilter : undefined,
      page: currentPage,
      limit,
      search: searchQuery || undefined,
    }
  );

  const adjustmentsList = adjustmentsResponse?.data || [];
  const meta = adjustmentsResponse?.meta || { total: 0, totalPages: 1 };

  const { data: branchesList = [] } = useBranchesQuery(businessId, currentUser?.id);

  // Columns definition
  const columns: ColumnDef<any>[] = [
    {
      header: "Adjustment Ref #",
      render: (r) => (
        <span className="font-mono font-bold text-foreground block">
          {r.adjustmentNumber}
        </span>
      ),
    },
    {
      header: "Date",
      render: (r) => (
        <span className="text-xs text-muted-foreground block">
          {new Date(r.adjustmentDate).toLocaleDateString("en-IN", {
            day: "2-digit",
            month: "short",
            year: "numeric",
          })}
        </span>
      ),
    },
    {
      header: "Type",
      render: (r) => (
        <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold ${r.type === "SUBTRACTION" ? "bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20" : "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20"}`}>
          {r.type === "SUBTRACTION" ? "(-) Reduction" : "(+) Addition"}
        </span>
      ),
    },
    {
      header: "Reason",
      render: (r) => (
        <span className="font-semibold text-foreground text-xs">
          {r.reason}
        </span>
      ),
    },
    {
      header: "Branch",
      render: (r) => (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-secondary text-secondary-foreground border border-border text-[10px] font-bold">
          <Building2 className="h-3 w-3" /> {r.branch?.name}
        </span>
      ),
    },
    {
      header: "Items Adjusted",
      render: (r) => (
        <span className="text-xs">
          {r.adjustmentLines?.length || 0} items
        </span>
      ),
    },
    {
      header: "Total Value",
      render: (r) => (
        <span className="font-extrabold text-foreground text-xs font-mono">
          {format(r.totalAmount)}
        </span>
      ),
    },
    {
      header: "Created By",
      render: (r) => (
        <span className="text-xs text-muted-foreground">
          {r.createdBy?.name || "System"}
        </span>
      ),
    },
    {
      header: "Actions",
      render: (r) => (
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            setSelectedAdjustment(r);
            setIsDetailOpen(true);
          }}
          className="h-7 text-[11px] gap-1 px-2 border-primary/30 hover:border-primary text-primary"
        >
          <FileText className="h-3 w-3" />
          View Slip
        </Button>
      ),
    },
  ];

  // Custom filters popover content
  const customFilters = (
    <div className="space-y-3.5 min-w-[220px]">
      {/* Branch Filter */}
      <div className="space-y-1.5">
        <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
          <Building2 className="h-3 w-3" /> Branch Filter
        </label>
        <Select
          value={selectedBranchFilter}
          onValueChange={setSelectedBranchFilter}
          className="h-9 text-xs"
        >
          <option value="all">All Branches</option>
          {branchesList.map((b: any) => (
            <option key={b.id} value={b.id}>{b.name}</option>
          ))}
        </Select>
      </div>

      {/* Type Filter */}
      <div className="space-y-1.5">
        <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
          <Tag className="h-3 w-3" /> Adjustment Type
        </label>
        <Select
          value={selectedTypeFilter}
          onValueChange={setSelectedTypeFilter}
          className="h-9 text-xs"
        >
          <option value="all">All Types</option>
          <option value="SUBTRACTION">(-) Stock Reduction</option>
          <option value="ADDITION">(+) Stock Addition</option>
        </Select>
      </div>
    </div>
  );

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3 p-6 max-w-sm border border-border/40 rounded-xl bg-card/60 backdrop-blur-sm">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <h2 className="text-lg font-bold">Unauthorized Access</h2>
          <p className="text-sm text-muted-foreground">
            You need to be logged in to view this page. Redirecting to login...
          </p>
          <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/stock-adjustments" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Stock Adjustments Ledger" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <SlidersHorizontal className="h-7 w-7 text-primary" /> Stock Adjustments
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Record damaged stock, expired goods, inventory audit corrections, and track manual stock adjustments.
              </p>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <Button
                onClick={() => setIsCreateOpen(true)}
                className="gap-2 shadow-lg shadow-primary/20"
              >
                <Plus className="h-4 w-4" />
                Add Stock Adjustment
              </Button>
            </div>
          </div>

          {/* Banner Notifications */}
          {successMessage && successMessage !== "none" && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 animate-in fade-in slide-in-from-top-4 duration-300">
              <CheckCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive animate-in fade-in slide-in-from-top-4 duration-300">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          {/* Main Table Card */}
          {adjustmentsLoading ? (
            <div className="flex h-64 items-center justify-center">
              <div className="text-center space-y-2">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
                <span className="text-sm text-muted-foreground block">Loading stock adjustments...</span>
              </div>
            </div>
          ) : (
            <DataTable
              data={adjustmentsList}
              columns={columns}
              searchPlaceholder="Search Ref # or Reason..."
              serverSide={true}
              totalItems={meta.total}
              totalPages={meta.totalPages}
              currentPage={currentPage}
              onPageChange={handlePageChange}
              searchQuery={searchQuery}
              onSearchQueryChange={handleSearchChange}
              onPageSizeChange={handleLimitChange}
              customFilters={customFilters}
              reportTitle="Stock Adjustments Ledger Report"
            />
          )}

          {/* Create Stock Adjustment Modal */}
          <CreateAdjustmentDialog
            isOpen={isCreateOpen}
            onClose={() => setIsCreateOpen(false)}
            businessId={businessId}
            userId={currentUser?.id || ""}
            onSuccess={(msg) => {
              setSuccessMessage(msg);
              setTimeout(() => setSuccessMessage("none"), 5000);
            }}
            onError={(msg) => {
              setError(msg);
              setTimeout(() => setError(""), 5000);
            }}
          />

          {/* Adjustment Detail Modal */}
          <AdjustmentDetailDialog
            isOpen={isDetailOpen}
            onClose={() => {
              setIsDetailOpen(false);
              setSelectedAdjustment(null);
            }}
            adjustment={selectedAdjustment}
          />
        </main>
      </div>
    </div>
  );
}

export default function StockAdjustmentsPage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen w-screen items-center justify-center bg-[#121216]">
        <div className="flex flex-col items-center gap-2">
          <div className="w-8 h-8 border-4 border-zinc-700 border-t-emerald-500 rounded-full animate-spin" />
          <p className="text-sm text-zinc-400">Loading...</p>
        </div>
      </div>
    }>
      <StockAdjustmentsPageContent />
    </Suspense>
  );
}
