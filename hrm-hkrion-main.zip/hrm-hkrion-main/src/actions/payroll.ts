"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import { PayslipStatus } from "@prisma/client";

// Fetch all employees and their active salaries
export async function getPayrollOverview() {
  try {
    const users = await prisma.user.findMany({
      where: {
        role: {
          not: "SUPER_ADMIN",
        }
      },
      include: {
        position: true,
        compensations: {
          where: { isActive: true },
          take: 1,
        },
      },
      orderBy: { firstName: "asc" },
    });

    const serializedUsers = users.map(u => ({
      ...u,
      compensations: u.compensations.map(c => ({
        ...c,
        baseSalary: Number(c.baseSalary)
      }))
    }));

    return { users: serializedUsers };
  } catch (error) {
    console.error("Error fetching payroll overview:", error);
    return { error: "Failed to fetch payroll overview." };
  }
}

// Update (or add) a user's base salary
export async function updateBaseSalary(userId: number, baseSalary: number, currency: string = "LKR", effectiveDate: Date) {
  try {
    // 1. Deactivate current active compensation (if any)
    await prisma.compensation.updateMany({
      where: { userId, isActive: true },
      data: { isActive: false },
    });

    // 2. Create new compensation record
    await prisma.compensation.create({
      data: {
        userId,
        baseSalary,
        currency,
        effectiveDate,
        isActive: true,
      },
    });

    revalidatePath("/dashboard/payroll");
    return { success: true };
  } catch (error) {
    console.error("Error updating base salary:", error);
    return { error: "Failed to update base salary." };
  }
}

// Stub for generating payslips
export async function generatePayslipsForMonth(month: number, year: number) {
  try {
    // 1. Fetch all users with active compensation
    const activeComps = await prisma.compensation.findMany({
      where: { isActive: true },
    });

    let count = 0;

    // 2. Create payslips
    for (const comp of activeComps) {
      // Check if payslip already exists
      const existing = await prisma.payslip.findFirst({
        where: { userId: comp.userId, month, year },
      });

      if (!existing) {
        await prisma.payslip.create({
          data: {
            userId: comp.userId,
            month,
            year,
            basicPay: comp.baseSalary,
            allowances: 0,
            deductions: 0,
            netPay: comp.baseSalary, // Basic logic for now
            status: PayslipStatus.DRAFT,
          },
        });
        count++;
      }
    }

    revalidatePath("/dashboard/payroll");
    return { success: true, generatedCount: count };
  } catch (error) {
    console.error("Error generating payslips:", error);
    return { error: "Failed to generate payslips." };
  }
}
