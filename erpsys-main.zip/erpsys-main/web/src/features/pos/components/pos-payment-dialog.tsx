"use client";

import React, { useState, useEffect, useMemo } from "react";
import {
  Coins,
  CreditCard,
  Banknote,
  Landmark,
  QrCode,
  Wallet,
  AlertCircle,
  CheckCircle2,
  Loader2,
  Plus,
  Trash2,
  ArrowLeft,
  Check,
  User,
  Sparkles,
  Info,
} from "lucide-react";
import { Dialog } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { usePaymentMethodsQuery } from "@/features/payment-methods/hooks/use-payment-methods";
import { useCurrency } from "@/hooks/use-currency";
import { usePermissions } from "@/hooks/use-permissions";
import { cn } from "@/lib/utils";

interface POSPaymentDialogProps {
  isOpen: boolean;
  onClose: () => void;
  grandTotal: number;
  businessId: string;
  branchId: string;
  customerAdvanceBalance: number;
  useAdvance: boolean;
  onUseAdvanceChange: (val: boolean) => void;
  onCheckout: (payments: any[]) => void;
  isPending: boolean;
  allowCredit?: boolean;
  customerName?: string;
  creditLimit?: number | null;
  currentOutstandingDue?: number;
  defaultPaymentMethodId?: string | null;
  initialPaymentMethodId?: string | null;
}

interface PaymentRow {
  paymentMethodId: string;
  amount: number;
  transactionNo: string;
  notes: string;
}

export function POSPaymentDialog({
  isOpen,
  onClose,
  grandTotal,
  businessId,
  branchId,
  customerAdvanceBalance,
  useAdvance,
  onUseAdvanceChange,
  onCheckout,
  isPending,
  allowCredit = true,
  customerName,
  creditLimit,
  currentOutstandingDue = 0,
  defaultPaymentMethodId,
  initialPaymentMethodId,
}: POSPaymentDialogProps) {
  const { hasPermission } = usePermissions();
  const canCreditSale = hasPermission("pos:credit_sale");
  const { symbol, format } = useCurrency(businessId);
  const { data: paymentMethods = [] } = usePaymentMethodsQuery(businessId, branchId, true);

  // Local payment rows state
  const [payments, setPayments] = useState<PaymentRow[]>([]);
  const [showNotes, setShowNotes] = useState(false);

  // Calculate remaining total to pay
  const advanceDeduction = useAdvance ? Math.min(customerAdvanceBalance, grandTotal) : 0;
  const netRemainingToPay = Math.max(0, grandTotal - advanceDeduction);

  // Initialize with a single payment row when dialog opens
  useEffect(() => {
    if (isOpen) {
      if (paymentMethods.length > 0) {
        const targetMethodId = initialPaymentMethodId || defaultPaymentMethodId;
        const matched = targetMethodId
          ? paymentMethods.find((pm) => pm.id === targetMethodId)
          : null;
        const selectedMethodId = matched ? matched.id : paymentMethods[0].id;

        setPayments([
          {
            paymentMethodId: selectedMethodId,
            amount: netRemainingToPay,
            transactionNo: "",
            notes: "",
          },
        ]);
      }
    } else {
      setPayments([]);
      setShowNotes(false);
    }
  }, [isOpen, paymentMethods, initialPaymentMethodId, defaultPaymentMethodId]);

  // Adjust single payment amount if netRemainingToPay changes (e.g. advance toggled)
  useEffect(() => {
    if (isOpen && payments.length === 1) {
      setPayments((prev) => [
        {
          ...prev[0],
          amount: netRemainingToPay,
        },
      ]);
    }
  }, [netRemainingToPay, isOpen]);

  const addPaymentRow = () => {
    if (paymentMethods.length === 0) return;
    const currentTotal = payments.reduce((sum, p) => sum + p.amount, 0);
    const remaining = Math.max(0, netRemainingToPay - currentTotal);
    setPayments([
      ...payments,
      {
        paymentMethodId: paymentMethods[0].id,
        amount: remaining,
        transactionNo: "",
        notes: "",
      },
    ]);
  };

  const removePaymentRow = (index: number) => {
    setPayments(payments.filter((_, i) => i !== index));
  };

  const updatePaymentRow = (index: number, fields: Partial<PaymentRow>) => {
    setPayments(payments.map((p, i) => (i === index ? { ...p, ...fields } : p)));
  };

  const totalPaid = payments.reduce((sum, p) => sum + p.amount, 0);
  const changeReturn = totalPaid > netRemainingToPay ? totalPaid - netRemainingToPay : 0;
  const newDue = Math.max(0, netRemainingToPay - totalPaid);
  const projectedDue = currentOutstandingDue + newDue;

  const availableCredit =
    creditLimit !== null && creditLimit !== undefined
      ? Math.max(0, creditLimit - currentOutstandingDue)
      : null;

  const minRequiredPayment =
    creditLimit !== null && creditLimit !== undefined && projectedDue > creditLimit
      ? Number((projectedDue - creditLimit).toFixed(2))
      : 0;

  const isCreditLimitExceeded = Boolean(
    creditLimit !== null &&
      creditLimit !== undefined &&
      newDue > 0 &&
      projectedDue > creditLimit
  );

  // Helper to find icon for payment method
  const getMethodIcon = (name: string) => {
    const lower = name.toLowerCase();
    if (lower.includes("cash")) return <Banknote className="h-4 w-4" />;
    if (lower.includes("card") || lower.includes("credit") || lower.includes("debit") || lower.includes("pos"))
      return <CreditCard className="h-4 w-4" />;
    if (lower.includes("bank") || lower.includes("transfer"))
      return <Landmark className="h-4 w-4" />;
    if (lower.includes("qr") || lower.includes("upi") || lower.includes("online"))
      return <QrCode className="h-4 w-4" />;
    return <Wallet className="h-4 w-4" />;
  };

  // Quick smart cash denominations
  const smartDenominations = useMemo(() => {
    if (netRemainingToPay <= 0) return [];
    const base = netRemainingToPay;
    const suggestions = new Set<number>();

    // Exact
    suggestions.add(base);

    // Common roundups
    const roundTo10 = Math.ceil(base / 10) * 10;
    if (roundTo10 > base) suggestions.add(roundTo10);

    const roundTo50 = Math.ceil(base / 50) * 50;
    if (roundTo50 > base) suggestions.add(roundTo50);

    const roundTo100 = Math.ceil(base / 100) * 100;
    if (roundTo100 > base) suggestions.add(roundTo100);

    const roundTo500 = Math.ceil(base / 500) * 500;
    if (roundTo500 > base) suggestions.add(roundTo500);

    const roundTo1000 = Math.ceil(base / 1000) * 1000;
    if (roundTo1000 > base) suggestions.add(roundTo1000);

    return Array.from(suggestions)
      .sort((a, b) => a - b)
      .slice(0, 5);
  }, [netRemainingToPay]);

  // Set quick cash denomination
  const handleQuickAmount = (amount: number) => {
    if (payments.length === 0 && paymentMethods.length > 0) {
      setPayments([
        {
          paymentMethodId: paymentMethods[0].id,
          amount,
          transactionNo: "",
          notes: "",
        },
      ]);
    } else {
      updatePaymentRow(0, { amount });
    }
  };

  // Add increment
  const handleAddIncrement = (inc: number) => {
    const current = payments[0]?.amount || 0;
    updatePaymentRow(0, { amount: current + inc });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (netRemainingToPay > 0 && totalPaid <= 0 && !allowCredit) {
      alert("This customer does not have credit permission. Please enter a payment amount.");
      return;
    }

    if (newDue > 0 && !canCreditSale) {
      alert(
        "You do not have permission to complete sales with an unpaid / due balance (pos:credit_sale). Full payment is required."
      );
      return;
    }

    // Deduct change return from payments for backend recording
    let remainingChangeToDeduct = changeReturn;
    const paymentsPayload = payments
      .filter((p) => p.amount > 0 && p.paymentMethodId)
      .map((p) => ({ ...p }))
      .reverse();

    for (let i = 0; i < paymentsPayload.length; i++) {
      if (remainingChangeToDeduct <= 0) break;
      const deduct = Math.min(paymentsPayload[i].amount, remainingChangeToDeduct);
      paymentsPayload[i].amount -= deduct;
      remainingChangeToDeduct -= deduct;
    }

    const finalPayments = paymentsPayload
      .reverse()
      .filter((p) => p.amount > 0)
      .map((p) => ({
        amount: Number(p.amount.toFixed(2)),
        paymentMethodId: p.paymentMethodId,
        transactionNo: p.transactionNo.trim() || undefined,
        notes: p.notes.trim() || undefined,
      }));

    onCheckout(finalPayments);
  };

  return (
    <Dialog isOpen={isOpen} onClose={onClose} title="Complete POS Payment" size="lg">
      <form onSubmit={handleSubmit} className="space-y-4 py-1">
        {/* Hero Banner: Net Payable & Customer Info */}
        <div className="relative overflow-hidden rounded-sm border border-primary/25 bg-gradient-to-br from-primary/10 via-background to-secondary/30 p-4 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            {/* Customer Details */}
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground">
                <User className="h-3.5 w-3.5 text-primary" />
                <span className="font-semibold text-foreground">{customerName || "Walk-in Customer"}</span>
                {customerAdvanceBalance > 0 && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded-sm bg-emerald-500/15 text-emerald-400 font-bold font-mono">
                    Advance: {format(customerAdvanceBalance)}
                  </span>
                )}
                {creditLimit !== null && creditLimit !== undefined && allowCredit && (
                  <span
                    className={cn(
                      "text-[10px] px-1.5 py-0.5 rounded-sm font-bold font-mono",
                      availableCredit && availableCredit > 0
                        ? "bg-blue-500/15 text-blue-400 border border-blue-500/30"
                        : "bg-rose-500/15 text-rose-400 border border-rose-500/30"
                    )}
                  >
                    Credit Left: {format(availableCredit || 0)} / {format(creditLimit)}
                  </span>
                )}
                {currentOutstandingDue > 0 && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded-sm bg-amber-500/15 text-amber-400 font-bold font-mono border border-amber-500/30">
                    Old Due: {format(currentOutstandingDue)}
                  </span>
                )}
              </div>
              <div className="text-[11px] text-muted-foreground flex items-center gap-2">
                <span>Invoice Total: <strong className="text-foreground">{format(grandTotal)}</strong></span>
                {useAdvance && advanceDeduction > 0 && (
                  <span className="text-emerald-400 font-semibold">
                    (Advance: -{format(advanceDeduction)})
                  </span>
                )}
              </div>
            </div>

            {/* Net Payable Highlight */}
            <div className="text-left sm:text-right">
              <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground block font-mono">
                Total Net Payable
              </span>
              <span className="text-2xl sm:text-3xl font-black text-primary font-mono tracking-tight drop-shadow-sm">
                {format(netRemainingToPay)}
              </span>
            </div>
          </div>

          {/* Customer Advance Toggle */}
          {customerAdvanceBalance > 0 && (
            <div className="mt-3 pt-3 border-t border-border/60 flex items-center justify-between bg-background/40 -mx-4 -mb-4 px-4 py-2.5">
              <label className="flex items-center gap-2.5 cursor-pointer text-xs font-semibold text-foreground select-none">
                <Checkbox
                  id="use-advance-checkbox"
                  checked={useAdvance}
                  onCheckedChange={(val) => onUseAdvanceChange(!!val)}
                  className="h-4 w-4 rounded-sm border-input"
                />
                <span>Apply Available Advance Balance</span>
              </label>
              <span className="text-xs font-bold text-emerald-400">
                {useAdvance ? `Deducted: ${format(advanceDeduction)}` : `Available: ${format(customerAdvanceBalance)}`}
              </span>
            </div>
          )}
        </div>

        {/* Quick Payment Method Selector (Tabs) */}
        {paymentMethods.length > 0 && (
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground flex items-center justify-between font-mono">
              <span>Primary Payment Method</span>
              {payments.length > 1 && (
                <span className="text-primary text-[10px] font-semibold lowercase">
                  ({payments.length} split methods active)
                </span>
              )}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {paymentMethods.slice(0, 4).map((pm) => {
                const isSelected = payments[0]?.paymentMethodId === pm.id;
                return (
                  <button
                    key={pm.id}
                    type="button"
                    onClick={() => {
                      if (payments.length === 0) {
                        setPayments([
                          {
                            paymentMethodId: pm.id,
                            amount: netRemainingToPay,
                            transactionNo: "",
                            notes: "",
                          },
                        ]);
                      } else {
                        updatePaymentRow(0, { paymentMethodId: pm.id });
                      }
                    }}
                    className={cn(
                      "flex items-center justify-center gap-2 p-2.5 rounded-sm border text-xs font-bold transition-all",
                      isSelected
                        ? "bg-primary text-black border-primary shadow-sm"
                        : "bg-background/40 hover:bg-secondary/40 text-foreground border-border hover:border-primary/40"
                    )}
                  >
                    {getMethodIcon(pm.name)}
                    <span className="truncate">{pm.name}</span>
                    {isSelected && <Check className="h-3.5 w-3.5 ml-auto stroke-[3]" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Quick Cash Chips (Fast One-Click Billing) */}
        {netRemainingToPay > 0 && (
          <div className="space-y-1.5 bg-secondary/15 border border-border/60 rounded-sm p-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5 font-mono">
                <Sparkles className="h-3 w-3 text-amber-400" />
                Quick Cash Tender
              </span>
              <span className="text-[10px] text-muted-foreground">Click chip to set tender</span>
            </div>

            <div className="flex flex-wrap gap-2 pt-0.5">
              {/* Exact Chip */}
              <button
                type="button"
                onClick={() => handleQuickAmount(netRemainingToPay)}
                className={cn(
                  "px-3 py-1.5 rounded-sm border text-xs font-bold transition-all flex items-center gap-1",
                  payments[0]?.amount === netRemainingToPay
                    ? "bg-emerald-600 text-white border-emerald-500 shadow-sm"
                    : "bg-background/60 hover:bg-background border-border text-foreground hover:border-emerald-500/50"
                )}
              >
                <span>Exact ({format(netRemainingToPay)})</span>
              </button>

              {/* Smart Round Chips */}
              {smartDenominations
                .filter((d) => d > netRemainingToPay)
                .map((amount) => {
                  const isCurrent = payments[0]?.amount === amount;
                  return (
                    <button
                      key={amount}
                      type="button"
                      onClick={() => handleQuickAmount(amount)}
                      className={cn(
                        "px-3 py-1.5 rounded-sm border text-xs font-bold font-mono transition-all",
                        isCurrent
                          ? "bg-emerald-600 text-white border-emerald-500 shadow-sm"
                          : "bg-background/60 hover:bg-background border-border text-foreground hover:border-primary/50"
                      )}
                    >
                      {format(amount)}
                    </button>
                  );
                })}

              {/* Increment buttons */}
              <div className="flex items-center gap-1 ml-auto">
                {[10, 50, 100].map((inc) => (
                  <button
                    key={inc}
                    type="button"
                    onClick={() => handleAddIncrement(inc)}
                    className="px-2 py-1 rounded-sm bg-secondary/50 hover:bg-secondary border border-border/70 text-[10px] font-bold text-muted-foreground hover:text-foreground transition-all font-mono"
                  >
                    +{inc}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Payment Rows / Splits Container */}
        <div className="space-y-3">
          <div className="flex items-center justify-between border-b border-border/60 pb-1.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground font-mono">
              Payment Breakdown
            </span>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={addPaymentRow}
              className="h-7 px-2.5 text-[11px] flex items-center gap-1 border-border/70 hover:border-primary/60 hover:text-primary rounded-sm"
            >
              <Plus className="h-3 w-3" />
              Split / Add Method
            </Button>
          </div>

          <div className="space-y-2.5 max-h-[220px] overflow-y-auto pr-1">
            {payments.map((payment, index) => (
              <div
                key={index}
                className="p-3 border border-border/70 rounded-sm bg-background/30 hover:border-border transition-all space-y-2.5 shadow-sm"
              >
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-end">
                  {/* Payment Method Selector */}
                  <div className="sm:col-span-4 space-y-1">
                    <label className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground font-mono">
                      Method
                    </label>
                    <select
                      value={payment.paymentMethodId}
                      onChange={(e) => updatePaymentRow(index, { paymentMethodId: e.target.value })}
                      className="w-full h-9 text-xs font-semibold text-foreground bg-background border border-input rounded-sm px-2.5 focus:outline-none focus:ring-1 focus:ring-primary"
                    >
                      {paymentMethods.map((pm) => (
                        <option key={pm.id} value={pm.id}>
                          {pm.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Amount Paid Input */}
                  <div className="sm:col-span-4 space-y-1">
                    <label className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground flex justify-between font-mono">
                      <span>Tender Amount</span>
                      <span className="font-mono text-primary font-bold">{symbol}</span>
                    </label>
                    <Input
                      type="number"
                      min={0}
                      step="0.01"
                      placeholder="0.00"
                      value={payment.amount === undefined ? "" : payment.amount}
                      onChange={(e) => {
                        const val = e.target.value === "" ? 0 : parseFloat(e.target.value);
                        updatePaymentRow(index, { amount: isNaN(val) ? 0 : val });
                      }}
                      className="h-9 font-mono font-bold text-sm bg-background border border-input rounded-sm"
                    />
                  </div>

                  {/* Ref / Trans No */}
                  <div className={cn("space-y-1", payments.length > 1 ? "sm:col-span-3" : "sm:col-span-4")}>
                    <label className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground font-mono">
                      Ref / Card No
                    </label>
                    <Input
                      type="text"
                      placeholder="e.g. Card 1234 / UPI"
                      value={payment.transactionNo}
                      onChange={(e) => updatePaymentRow(index, { transactionNo: e.target.value })}
                      className="h-9 text-xs bg-background border border-input rounded-sm"
                    />
                  </div>

                  {/* Delete row button (if multiple rows) */}
                  {payments.length > 1 && (
                    <div className="sm:col-span-1 flex justify-end">
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removePaymentRow(index)}
                        className="h-9 w-9 p-0 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-sm"
                        title="Remove this payment method"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </div>

                {/* Optional Note field toggle */}
                {showNotes && (
                  <div className="pt-1.5 border-t border-border/40">
                    <Input
                      type="text"
                      placeholder="Add memo or transaction note..."
                      value={payment.notes}
                      onChange={(e) => updatePaymentRow(index, { notes: e.target.value })}
                      className="h-8 text-[11px] bg-background/50 border border-input rounded-sm"
                    />
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Toggle note link */}
          <button
            type="button"
            onClick={() => setShowNotes(!showNotes)}
            className="text-[11px] text-muted-foreground hover:text-primary transition-colors flex items-center gap-1 font-semibold"
          >
            <Info className="h-3 w-3" />
            {showNotes ? "Hide payment notes" : "+ Add payment memo / notes"}
          </button>
        </div>

        {/* Change Return Banner */}
        {changeReturn > 0 && (
          <div className="p-3.5 bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 rounded-sm flex items-center justify-between animate-in fade-in zoom-in-95 duration-150 shadow-sm">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-emerald-500/20 rounded-sm">
                <Coins className="h-5 w-5 text-emerald-400 animate-bounce" />
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-wider font-extrabold text-emerald-300/90 block font-mono">
                  Change to Return to Customer
                </span>
                <span className="text-xl sm:text-2xl font-black font-mono tracking-tight text-white drop-shadow">
                  {format(changeReturn)}
                </span>
              </div>
            </div>
            <span className="text-xs px-2.5 py-1 rounded-sm bg-emerald-500/20 border border-emerald-500/30 font-bold text-emerald-300">
              Cash Return
            </span>
          </div>
        )}

        {/* Full payment matching indicator */}
        {totalPaid === netRemainingToPay && netRemainingToPay > 0 && (
          <div className="p-2.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-sm flex items-center justify-between text-xs font-semibold">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
              <span>Exact Payment Allocated ({format(totalPaid)})</span>
            </div>
            <span className="text-[11px] text-emerald-300 font-mono">Zero Due</span>
          </div>
        )}

        {/* Credit / Balance Due Alerts */}
        {totalPaid < netRemainingToPay && (
          allowCredit === false ? (
            <div className="p-3 bg-destructive/15 text-destructive border border-destructive/30 rounded-sm flex gap-2.5 items-start animate-in fade-in duration-150">
              <AlertCircle className="h-5 w-5 shrink-0 mt-0.5 text-destructive" />
              <div className="text-xs leading-relaxed">
                <strong className="block font-bold font-mono">Credit Sale Blocked</strong>
                Credit sales are disabled for <strong>{customerName || "this customer"}</strong>. Full payment of{" "}
                <strong>{format(netRemainingToPay)}</strong> is required. Remaining balance of{" "}
                <strong>{format(netRemainingToPay - totalPaid)}</strong> is unpaid.
              </div>
            </div>
          ) : isCreditLimitExceeded ? (
            <div className="p-3 bg-destructive/15 text-destructive border border-destructive/30 rounded-sm flex flex-col gap-2.5 animate-in fade-in duration-150">
              <div className="flex gap-2.5 items-start">
                <AlertCircle className="h-5 w-5 shrink-0 mt-0.5 text-destructive" />
                <div className="text-xs leading-relaxed flex-1">
                  <strong className="block font-bold font-mono text-destructive">Credit Limit Exceeded!</strong>
                  Credit Limit: <strong>{format(creditLimit!)}</strong> | Old Due: <strong>{format(currentOutstandingDue)}</strong> | Available Credit: <strong>{format(availableCredit || 0)}</strong>.
                  <br />
                  New bill due of <strong>{format(newDue)}</strong> exceeds limit by <strong>{format(minRequiredPayment)}</strong>.
                </div>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-destructive/25">
                <span className="text-[11px] font-semibold text-foreground">
                  Minimum payment required: <strong className="text-rose-400 font-mono">{format(minRequiredPayment)}</strong>
                </span>
                <Button
                  type="button"
                  size="sm"
                  onClick={() => handleQuickAmount(minRequiredPayment)}
                  className="h-7 px-3 text-[11px] font-bold bg-destructive text-white hover:bg-destructive/90 rounded-sm cursor-pointer shadow-sm"
                >
                  Pay Min ({format(minRequiredPayment)})
                </Button>
              </div>
            </div>
          ) : !canCreditSale ? (
            <div className="p-3 bg-destructive/15 text-destructive border border-destructive/30 rounded-sm flex gap-2.5 items-start">
              <AlertCircle className="h-5 w-5 shrink-0 mt-0.5 text-destructive" />
              <div className="text-xs leading-relaxed">
                <strong className="block font-bold font-mono">Credit Sale Permission Required</strong>
                You do not have permission to leave unpaid / credit balance (<code>pos:credit_sale</code>). Full payment of{" "}
                <strong>{format(netRemainingToPay)}</strong> is required.
              </div>
            </div>
          ) : (
            <div className="p-3 bg-amber-500/10 text-amber-400 border border-amber-500/25 rounded-sm flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <AlertCircle className="h-5 w-5 shrink-0 text-amber-400" />
                <div>
                  <span className="text-xs font-bold block">Remaining Due on Account</span>
                  <span className="text-[11px] text-muted-foreground">Will be billed as customer credit</span>
                </div>
              </div>
              <span className="text-base font-bold font-mono text-amber-300">
                {format(netRemainingToPay - totalPaid)}
              </span>
            </div>
          )
        )}

        {/* Bottom Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-border/60">
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
            className="h-10 px-4 text-xs font-semibold flex items-center gap-1.5 border-border hover:bg-secondary rounded-sm"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Go Back
          </Button>

          <Button
            type="submit"
            disabled={
              isPending ||
              (allowCredit === false && totalPaid < netRemainingToPay) ||
              (newDue > 0 && !canCreditSale) ||
              isCreditLimitExceeded
            }
            className="h-10 px-6 text-sm font-black bg-emerald-500 hover:bg-emerald-400 text-black shadow-lg shadow-emerald-500/20 flex items-center gap-2 rounded-sm transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isPending ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin text-black" />
                Processing Sale...
              </>
            ) : (
              <>
                <Check className="h-4 w-4 stroke-[3]" />
                Complete Checkout
              </>
            )}
          </Button>
        </div>
      </form>
    </Dialog>
  );
}
