import React from "react";
import { InvoiceTemplateProps } from "./types";

export function generateThermal80mmHtml(props: InvoiceTemplateProps): string {
  const { sale, layout, businessName, currencySymbol = "₹" } = props;
  const cur = currencySymbol;

  const headerText = layout?.headerText || "TAX INVOICE";
  const subHeading = layout?.subHeading || "";
  const showCustomerDetails = layout?.showCustomerDetails ?? true;
  const showSku = layout?.showSku ?? true;
  const showDiscount = layout?.showDiscount ?? true;
  const showTax = layout?.showTax ?? true;
  const footerText = layout?.footerText || "Thank you for shopping with us!";
  const termsConditions = layout?.termsConditions || "";
  const bankDetails = layout?.bankDetails || "";

  return `
    <!DOCTYPE html>
    <html>
      <head>
        <title>${headerText} - ${sale.invoiceNumber}</title>
        <style>
          @page {
            margin: 0;
            size: 80mm auto;
          }
          body {
            margin: 0;
            padding: 4mm;
            font-family: 'Courier New', Courier, monospace;
            font-size: 11px;
            color: #000;
            width: 72mm;
          }
          .text-center { text-align: center; }
          .text-right { text-align: right; }
          .font-bold { font-weight: bold; }
          .mb-3 { margin-bottom: 12px; }
          .mb-1 { margin-bottom: 4px; }
          .pb-2 { padding-bottom: 8px; }
          .border-b { border-bottom: 1px dashed #000; }
          .border-t { border-top: 1px dashed #000; }
          table { width: 100%; border-collapse: collapse; margin-top: 8px; }
          th, td { padding: 4px 0; vertical-align: top; }
          hr { border: none; border-top: 1px dashed #000; margin: 8px 0; }
          .total-section { text-align: right; margin-top: 8px; line-height: 1.5; }
          .box-section { border: 1px dashed #000; padding: 6px; margin-top: 8px; font-size: 9px; white-space: pre-line; }
        </style>
      </head>
      <body onload="window.print(); window.close();">
        <div class="text-center mb-3">
          <h2 style="margin: 0 0 2px 0; font-size: 14px; text-transform: uppercase;">${businessName}</h2>
          ${subHeading ? `<div style="font-size: 10px; font-weight: bold;">${subHeading}</div>` : ""}
          <div style="font-size: 11px; font-weight: bold; margin: 2px 0;">${headerText}</div>
          <div>${sale.branch?.name || ""}</div>
          ${sale.branch?.address ? `<div>${sale.branch.address}</div>` : ""}
          ${sale.branch?.phone ? `<div>Tel: ${sale.branch.phone}</div>` : ""}
        </div>
        
        <div class="border-b pb-2 mb-1" style="font-size: 10px;">
          <div><b>Invoice:</b> ${sale.invoiceNumber}</div>
          <div><b>Date:</b> ${new Date(sale.saleDate).toLocaleString()}</div>
          ${showCustomerDetails && sale.customer ? `<div><b>Customer:</b> ${sale.customer.name || "Walk-in"}</div>` : ""}
        </div>

        <table>
          <thead>
            <tr class="border-b">
              <th align="left">Item</th>
              ${showSku ? `<th align="left">SKU</th>` : ""}
              <th align="right">Qty</th>
              <th align="right">Total</th>
            </tr>
          </thead>
          <tbody>
            ${sale.saleLines?.map((line: any) => {
              const imeiText = line.productImeis && line.productImeis.length > 0
                ? line.productImeis.map((i: any) => i.imeiNumber).join(", ")
                : (line.imeiNumber || "");
              return `
              <tr>
                <td>
                  <div>${line.variant?.product?.name || line.variant?.name}</div>
                  ${imeiText ? `<div style="font-size: 8px; color: #666; font-family: monospace;">SN/IMEI: ${imeiText}</div>` : ""}
                </td>
                ${showSku ? `<td>${line.variant?.sku || "-"}</td>` : ""}
                <td align="right">${line.quantity}</td>
                <td align="right">${cur}${line.subtotal.toFixed(2)}</td>
              </tr>
            `;}).join("")}
          </tbody>
        </table>

        <hr/>

        <div class="total-section">
          ${showDiscount && sale.discountAmount > 0 ? `<div>Discount: -${cur}${sale.discountAmount.toFixed(2)}</div>` : ""}
          ${showTax && sale.taxAmount > 0 ? `<div>Tax: +${cur}${sale.taxAmount.toFixed(2)}</div>` : ""}
          <div class="font-bold">Total Payable: ${cur}${sale.grandTotal.toFixed(2)}</div>
          <div style="color: green;">Amount Paid: ${cur}${sale.amountPaid.toFixed(2)}</div>
          ${sale.grandTotal - sale.amountPaid > 0 ? `<div style="color: red; font-weight: bold;">Due: ${cur}${(sale.grandTotal - sale.amountPaid).toFixed(2)}</div>` : ""}
        </div>

        ${bankDetails ? `
          <div class="box-section">
            <b>Bank Account Details:</b>\n${bankDetails}
          </div>
        ` : ""}

        ${termsConditions ? `
          <div class="box-section">
            <b>Terms & Conditions:</b>\n${termsConditions}
          </div>
        ` : ""}

        <div class="text-center" style="margin-top: 16px; font-size: 9px; color: #555;">
          <div>${footerText}</div>
          <div>Powered by HKR ERP</div>
        </div>
      </body>
    </html>
  `;
}

export function Thermal80mmTemplate(props: InvoiceTemplateProps) {
  const { sale, layout, businessName, currencySymbol = "₹" } = props;
  const cur = currencySymbol;

  const headerText = layout?.headerText || "TAX INVOICE";
  const subHeading = layout?.subHeading || "";
  const showCustomerDetails = layout?.showCustomerDetails ?? true;
  const showSku = layout?.showSku ?? true;
  const showDiscount = layout?.showDiscount ?? true;
  const showTax = layout?.showTax ?? true;
  const footerText = layout?.footerText || "Thank you for shopping with us!";
  const termsConditions = layout?.termsConditions || "";
  const bankDetails = layout?.bankDetails || "";

  return (
    <div className="w-[80mm] border border-border bg-card text-card-foreground p-4 font-mono text-xs shadow-inner rounded max-h-[75vh] overflow-y-auto">
      <div className="text-center space-y-1 mb-3">
        <h2 className="text-sm font-bold uppercase text-foreground">{businessName}</h2>
        {subHeading && <p className="text-[10px] font-semibold text-primary">{subHeading}</p>}
        <p className="text-[11px] font-bold tracking-wider text-foreground uppercase">{headerText}</p>
        <p className="text-[10px] text-muted-foreground">{sale.branch?.name}</p>
        {sale.branch?.address && <p className="text-[10px] text-muted-foreground">{sale.branch.address}</p>}
        {sale.branch?.phone && <p className="text-[10px] text-muted-foreground">Tel: {sale.branch.phone}</p>}
      </div>

      <div className="border-b border-dashed border-border pb-2 mb-2 space-y-0.5 text-[10px] text-muted-foreground">
        <p><span className="font-bold text-foreground">Invoice #:</span> {sale.invoiceNumber}</p>
        <p><span className="font-bold text-foreground">Date:</span> {new Date(sale.saleDate).toLocaleString()}</p>
        {showCustomerDetails && (
          <>
            <p><span className="font-bold text-foreground">Cust:</span> {sale.customer?.name || "Walk-in Customer"}</p>
            {sale.customer?.phone && <p><span className="font-bold text-foreground">Tel:</span> {sale.customer.phone}</p>}
          </>
        )}
      </div>

      <table className="w-full text-[10px] mb-2 text-foreground">
        <thead>
          <tr className="border-b border-dashed border-border text-muted-foreground">
            <th className="text-left py-1 font-semibold">Item</th>
            {showSku && <th className="text-left py-1 font-semibold">SKU</th>}
            <th className="text-right py-1 font-semibold" style={{ width: "35px", textAlign: 'right' }}>Qty</th>
            <th className="text-right py-1 font-semibold" style={{ width: "60px", textAlign: 'right' }}>Total</th>
          </tr>
        </thead>
        <tbody>
          {sale.saleLines?.map((line) => {
            const imeiText = line.productImeis && line.productImeis.length > 0
              ? line.productImeis.map((i: any) => i.imeiNumber).join(", ")
              : (line.imeiNumber || "");
            return (
              <tr key={line.id} className="border-b border-dotted border-border/40">
                <td className="py-1 max-w-[120px]">
                  <span className="block truncate">{line.variant?.product?.name || line.variant?.name}</span>
                  {imeiText && (
                    <span className="block text-[8px] text-muted-foreground font-mono leading-tight">
                      SN: {imeiText}
                    </span>
                  )}
                </td>
                {showSku && <td className="py-1 text-[9px] text-muted-foreground">{line.variant?.sku || "-"}</td>}
                <td className="text-right py-1" style={{ textAlign: 'right' }}>{line.quantity}</td>
                <td className="text-right py-1" style={{ textAlign: 'right' }}>{cur}{line.subtotal.toFixed(2)}</td>
              </tr>
            );
          })}
        </tbody>
      </table>

      <div className="border-t border-dashed border-border pt-2 space-y-1 text-[10px] text-right text-muted-foreground">
        {showDiscount && sale.discountAmount > 0 && (
          <p>Discount: -{cur}{sale.discountAmount.toFixed(2)}</p>
        )}
        {showTax && sale.taxAmount > 0 && (
          <p>Tax: +{cur}{sale.taxAmount.toFixed(2)}</p>
        )}
        <p className="font-bold text-xs text-foreground">Total: {cur}{sale.grandTotal.toFixed(2)}</p>
        <p className="text-emerald-500 font-semibold">Paid: {cur}{sale.amountPaid.toFixed(2)}</p>
        {sale.grandTotal - sale.amountPaid > 0 && (
          <p className="text-destructive font-semibold">
            Balance Due: {cur}{(sale.grandTotal - sale.amountPaid).toFixed(2)}
          </p>
        )}
      </div>

      {bankDetails && (
        <div className="border border-dashed border-border p-2 mt-3 text-[9px] whitespace-pre-line rounded bg-muted/20">
          <span className="font-bold block text-foreground">Bank Details:</span>
          {bankDetails}
        </div>
      )}

      {termsConditions && (
        <div className="border border-dashed border-border p-2 mt-2 text-[9px] whitespace-pre-line rounded bg-muted/20">
          <span className="font-bold block text-foreground">Terms & Conditions:</span>
          {termsConditions}
        </div>
      )}

      <div className="border-t border-dashed border-border pt-3 mt-3 text-center text-[9px] text-muted-foreground">
        <p>{footerText}</p>
        <p className="text-[8px] opacity-75">Powered by HKR ERP</p>
      </div>
    </div>
  );
}
