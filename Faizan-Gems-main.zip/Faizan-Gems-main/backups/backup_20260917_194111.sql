-- MySQL dump 10.13  Distrib 26.7.0, for macos27.0 (arm64)
--
-- Host: localhost    Database: gem_ecommerce
-- ------------------------------------------------------
-- Server version	26.7.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_spent` decimal(12,2) NOT NULL DEFAULT '0.00',
  `acquisitions` int NOT NULL DEFAULT '0',
  `tier` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Regular Customer',
  `location` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sri Lanka',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `clients_email_key` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_blocks`
--

DROP TABLE IF EXISTS `content_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `content_blocks` (
  `id` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_blocks_section_key_key` (`section`,`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_blocks`
--

LOCK TABLES `content_blocks` WRITE;
/*!40000 ALTER TABLE `content_blocks` DISABLE KEYS */;
INSERT INTO `content_blocks` VALUES ('block-about-brand_slogan','about','brand_slogan','From the Heart of Sri Lanka to the World.','2026-09-17 19:30:41.712'),('block-about-brand_tagline','about','brand_tagline','Natural Gemstones • Custom Jewellery • Trusted Service','2026-09-17 19:30:41.715'),('block-about-founder_credentials','about','founder_credentials','BSc in Psychology & Counselling','2026-09-17 19:30:41.724'),('block-about-founder_greeting','about','founder_greeting','Assalamu Alaikum and warm greetings,','2026-09-17 19:30:41.725'),('block-about-founder_image','about','founder_image','/uploads/gemstones/gem-1789653639242-gt09cd.webp','2026-09-17 19:30:41.724'),('block-about-founder_name','about','founder_name','Riyas Abdul Aziz (JP)','2026-09-17 19:30:41.722'),('block-about-founder_p1','about','founder_p1','It is my great pleasure to welcome you to Faizan Gems (Pvt) Ltd, a Sri Lankan gemstone trading and jewellery company built on trust, authenticity, quality and customer satisfaction.','2026-09-17 19:30:41.726'),('block-about-founder_p2','about','founder_p2','Sri Lanka is world-renowned for its exceptional natural gemstones, particularly its beautiful sapphires. At Faizan Gems, our aim is to share this valuable heritage with customers in Sri Lanka and around the world through carefully selected natural gemstones and professionally crafted custom jewellery.','2026-09-17 19:30:41.727'),('block-about-founder_p3','about','founder_p3','Our business is not only about buying and selling gemstones. We are committed to building long-term relationships with our customers by providing honest information, reliable service and quality products. Whether you are looking for a natural Sri Lankan sapphire, a gemstone for investment, or a unique custom-made ring, pendant, bracelet or other jewellery, our team is ready to assist you.','2026-09-17 19:30:41.727'),('block-about-founder_p4','about','founder_p4','We continuously strive to improve our standards, expand our international presence and introduce the beauty of Sri Lankan gemstones to new markets.','2026-09-17 19:30:41.728'),('block-about-founder_p5','about','founder_p5','I sincerely thank all our customers, business partners and supporters for their trust in Faizan Gems. We look forward to growing together and creating lasting value through Sri Lankan gemstones and fine craftsmanship.','2026-09-17 19:30:41.729'),('block-about-founder_title','about','founder_title','CEO / Founder','2026-09-17 19:30:41.723'),('block-about-headoffice_address','about','headoffice_address','283/2, N.C. Road, Trincomalee, Sri Lanka.','2026-09-17 19:30:41.731'),('block-about-headoffice_badge','about','headoffice_badge','Corporate Headquarters & Flagship','2026-09-17 19:30:41.731'),('block-about-headoffice_desc','about','headoffice_desc','Our main showroom and gemological facility where stones are inspected, certified, and dispatched worldwide.','2026-09-17 19:30:41.732'),('block-about-headoffice_phone','about','headoffice_phone','076 111 9823','2026-09-17 19:30:41.733'),('block-about-headoffice_title','about','headoffice_title','Head Office – Trincomalee','2026-09-17 19:30:41.730'),('block-about-jewellery_desc','about','jewellery_desc','In addition to gemstone trading, we offer custom jewellery manufacturing, creating unique rings, earrings, pendants, bracelets and necklaces according to our customers’ requirements. Our jewellery combines carefully selected natural gemstones with quality craftsmanship to create beautiful and timeless pieces.','2026-09-17 19:30:41.718'),('block-about-kalutara_address','about','kalutara_address','20A, Galle Road, Kalutara, Sri Lanka.','2026-09-17 19:30:41.735'),('block-about-kalutara_badge','about','kalutara_badge','Regional Trading Office','2026-09-17 19:30:41.734'),('block-about-kalutara_desc','about','kalutara_desc','Our western province gemstone trading and client consultation centre along the historic coastal gemstone corridor.','2026-09-17 19:30:41.736'),('block-about-kalutara_phone','about','kalutara_phone','076 867 1219','2026-09-17 19:30:41.736'),('block-about-kalutara_title','about','kalutara_title','Kalutara Office','2026-09-17 19:30:41.733'),('block-about-mission_statement','about','mission_statement','Faizan Gems (Pvt) Ltd is committed to sourcing and trading genuine natural gemstones, especially Sri Lankan sapphires, while creating high-quality custom jewellery that combines the beauty of natural gemstones with modern craftsmanship. We aim to provide our local and international customers with authenticity, transparency, competitive value, and reliable service from gemstone selection to the final jewellery piece.','2026-09-17 19:30:41.721'),('block-about-page_intro','about','page_intro','Faizan Gems (Pvt) Ltd is a Sri Lankan gemstone trading and jewellery company specializing in the buying and selling of natural gemstones, with a special focus on Sri Lankan sapphires.','2026-09-17 19:30:41.716'),('block-about-trading_desc','about','trading_desc','We source and trade carefully selected natural gemstones from Sri Lanka, including Blue Sapphires, Yellow Sapphires, Padparadscha Sapphires, Ruby, Chrysoberyl, Cat’s Eye, Emerald, Aquamarine, Garnet and other precious and semi-precious gemstones.','2026-09-17 19:30:41.717'),('block-about-trust_desc','about','trust_desc','At Faizan Gems, we believe that trust, authenticity, quality and customer satisfaction are the foundation of a successful gemstone business. We are committed to providing genuine natural gemstones, transparent service and professional assistance to both local and international customers.','2026-09-17 19:30:41.719'),('block-about-vision_short','about','vision_short','Our vision is to connect the rich Sri Lankan gemstone heritage with customers and jewellery markets around the world, while building long-term relationships based on trust, quality and excellence.','2026-09-17 19:30:41.720'),('block-about-vision_statement','about','vision_statement','To become a trusted and internationally recognized Sri Lankan gemstone and jewellery company, renowned for genuine natural gemstones, exceptional craftsmanship, ethical business practices, and lasting customer relationships.','2026-09-17 19:30:41.721'),('block-banking-account_name','banking','account_name','Faizan Gems (Pvt) Ltd','2026-09-17 19:31:39.024'),('block-banking-account_number','banking','account_number','100048299104','2026-09-17 19:31:39.025'),('block-banking-bank_logo','banking','bank_logo','/uploads/branding/logo-1789653683835-xcn16w.png','2026-09-17 19:31:39.026'),('block-banking-bank_name','banking','bank_name','Commercial Bank of Ceylon PLC','2026-09-17 19:31:39.021'),('block-banking-bank_short_name','banking','bank_short_name','Commercial Bank','2026-09-17 19:31:39.022'),('block-banking-branch_name','banking','branch_name','Colombo Branch','2026-09-17 19:31:39.023'),('block-banking-swift_code','banking','swift_code','COMBCEKLXXX','2026-09-17 19:31:39.025'),('block-collection-ceylon-sapphires.hero_image','collection','ceylon-sapphires.hero_image','/uploads/banners/hero-1789650343151-26p9kx.webp','2026-09-17 18:36:18.565'),('block-collection-ceylon-sapphires.title','collection','ceylon-sapphires.title','Ceylon Sapphires','2026-09-17 18:36:18.564'),('block-collection-colombian-emeralds.hero_image','collection','colombian-emeralds.hero_image','/uploads/banners/hero-1789650360102-nqxlbb.webp','2026-09-17 18:36:18.568'),('block-collection-colombian-emeralds.title','collection','colombian-emeralds.title','Colombian Emeralds','2026-09-17 18:36:18.567'),('block-collection-rare-gems.hero_image','collection','rare-gems.hero_image','/uploads/banners/hero-1789650373656-dlnsbu.webp','2026-09-17 18:36:18.570'),('block-collection-rare-gems.title','collection','rare-gems.title','Rare & Phenomenal','2026-09-17 18:36:18.569'),('block-collection-rubies.hero_image','collection','rubies.hero_image','/uploads/banners/hero-1789650366827-wdlf3h.webp','2026-09-17 18:36:18.567'),('block-collection-rubies.title','collection','rubies.title','Burmese Rubies','2026-09-17 18:36:18.566'),('block-collection-the-golden-monarch-ceylon-yellow-sapphire.hero_image','collection','the-golden-monarch-ceylon-yellow-sapphire.hero_image','/uploads/banners/hero-1789652484567-ksitkn.webp','2026-09-17 19:12:18.136'),('block-collection-the-golden-monarch-ceylon-yellow-sapphire.title','collection','the-golden-monarch-ceylon-yellow-sapphire.title','The Golden Monarch: Ceylon Yellow Sapphire','2026-09-17 19:12:18.135'),('block-collection-the-royal-azure-ceylonese-blue-sapphire.hero_image','collection','the-royal-azure-ceylonese-blue-sapphire.hero_image','/uploads/banners/hero-1789652518368-qf6d5j.webp','2026-09-17 19:12:18.138'),('block-collection-the-royal-azure-ceylonese-blue-sapphire.title','collection','the-royal-azure-ceylonese-blue-sapphire.title','The Royal Azure: Ceylonese Blue Sapphire','2026-09-17 19:12:18.137'),('block-collection-the-verdant-light-serendib-peridot.hero_image','collection','the-verdant-light-serendib-peridot.hero_image','/uploads/banners/hero-1789652532829-c60hao.webp','2026-09-17 19:12:18.139'),('block-collection-the-verdant-light-serendib-peridot.title','collection','the-verdant-light-serendib-peridot.title','The Verdant Light: Serendib Peridot','2026-09-17 19:12:18.138'),('block-collections-cards_list','collections','cards_list','[{\"id\":\"col-1789652413868\",\"slug\":\"the-golden-monarch-ceylon-yellow-sapphire\",\"name\":\"The Golden Monarch: Ceylon Yellow Sapphire\",\"image\":\"/uploads/banners/hero-1789652484567-ksitkn.webp\",\"showOnHome\":true,\"orderIndex\":0},{\"id\":\"col-1789652509357\",\"slug\":\"the-royal-azure-ceylonese-blue-sapphire\",\"name\":\"The Royal Azure: Ceylonese Blue Sapphire\",\"image\":\"/uploads/banners/hero-1789652507558-3na0q0.webp\",\"showOnHome\":true,\"orderIndex\":1},{\"id\":\"col-1789652518958\",\"slug\":\"the-royal-azure-ceylonese-blue-sapphire\",\"name\":\"The Royal Azure: Ceylonese Blue Sapphire\",\"image\":\"/uploads/banners/hero-1789652518368-qf6d5j.webp\",\"showOnHome\":true,\"orderIndex\":2},{\"id\":\"col-1789652535473\",\"slug\":\"the-verdant-light-serendib-peridot\",\"name\":\"The Verdant Light: Serendib Peridot\",\"image\":\"/uploads/banners/hero-1789652532829-c60hao.webp\",\"showOnHome\":true,\"orderIndex\":3}]','2026-09-17 19:12:18.130'),('block-collections.page-eyebrow','collections.page','eyebrow','Faizan Gems Vault Collections','2026-09-17 19:12:18.132'),('block-collections.page-headline','collections.page','headline','Curated Gemstone Portfolios','2026-09-17 19:12:18.132'),('block-collections.page-subheadline','collections.page','subheadline','Browse collections of the world\'s finest natural gemstones — sourced directly from historic alluvial deposits and cut by master craftsmen. Each untreated specimen is individually certified by leading gemological institutes.','2026-09-17 19:12:18.133'),('block-collections.showcase-eyebrow','collections.showcase','eyebrow','World-Renowned Provenance','2026-09-17 19:12:18.133'),('block-collections.showcase-subtitle','collections.showcase','subtitle','Explore the world\'s most exceptional unheated natural gemstones sourced directly from legendary deposits.','2026-09-17 19:12:18.134'),('block-collections.showcase-title','collections.showcase','title','Our Signature Portfolios','2026-09-17 19:12:18.134'),('block-homepage-collections_eyebrow','homepage','collections_eyebrow','Our Collections','2026-09-17 19:01:59.370'),('block-homepage-collections_headline','homepage','collections_headline','Explore Our Gemstone Collections','2026-09-17 19:01:59.371'),('block-homepage-collections_subheadline','homepage','collections_subheadline','Browse collections of the world\'s finest natural gemstones - sourced directly from the mines and cut by expert craftsmen.','2026-09-17 19:01:59.372'),('block-homepage-consultation_button_text','homepage','consultation_button_text','Book a Free Consultation','2026-09-17 19:01:59.394'),('block-homepage-consultation_desc','homepage','consultation_desc','Our gemstone experts are happy to help — visit our Trincomalee showroom or book a free video call consultation.','2026-09-17 19:01:59.393'),('block-homepage-consultation_eyebrow','homepage','consultation_eyebrow','Need Help Choosing?','2026-09-17 19:01:59.392'),('block-homepage-consultation_headline','homepage','consultation_headline','Looking for a Specific Gemstone?','2026-09-17 19:01:59.393'),('block-homepage-hero_cta_primary_link','homepage','hero_cta_primary_link','/shop','2026-09-17 19:01:59.356'),('block-homepage-hero_cta_primary_text','homepage','hero_cta_primary_text','Browse Gemstones','2026-09-17 19:01:59.355'),('block-homepage-hero_cta_secondary_link','homepage','hero_cta_secondary_link','/shop','2026-09-17 19:01:59.359'),('block-homepage-hero_cta_secondary_text','homepage','hero_cta_secondary_text','Our Collection','2026-09-17 19:01:59.357'),('block-homepage-hero_eyebrow','homepage','hero_eyebrow','Untreated Natural Gemstones • Certified Authentic','2026-09-17 19:01:59.353'),('block-homepage-hero_headline','homepage','hero_headline','Discover Rare Natural Gemstones','2026-09-17 19:01:59.354'),('block-homepage-hero_image','homepage','hero_image','/uploads/banners/hero-1789651834163-md9w3c.webp','2026-09-17 19:01:59.360'),('block-homepage-hero_subheadline','homepage','hero_subheadline','Natural unheated sapphires, rubies, emeralds, and fine gemstones. Certified for quality, color, and authenticity.','2026-09-17 19:01:59.355'),('block-homepage-loupe_cta_link','homepage','loupe_cta_link','/shop','2026-09-17 19:01:59.381'),('block-homepage-loupe_cta_text','homepage','loupe_cta_text','View a Gemstone Up Close →','2026-09-17 19:01:59.380'),('block-homepage-loupe_eyebrow','homepage','loupe_eyebrow','See Every Detail Online','2026-09-17 19:01:59.375'),('block-homepage-loupe_feat1_desc','homepage','loupe_feat1_desc','See the natural details and clarity of each stone up close.','2026-09-17 19:01:59.377'),('block-homepage-loupe_feat1_title','homepage','loupe_feat1_title','10x Zoom Magnification','2026-09-17 19:01:59.376'),('block-homepage-loupe_feat2_desc','homepage','loupe_feat2_desc','View the cut quality, light performance, and sparkle from every angle.','2026-09-17 19:01:59.378'),('block-homepage-loupe_feat2_title','homepage','loupe_feat2_title','Detailed Photo Gallery','2026-09-17 19:01:59.377'),('block-homepage-loupe_feat3_desc','homepage','loupe_feat3_desc','Every gemstone comes with its original lab report and certificate.','2026-09-17 19:01:59.379'),('block-homepage-loupe_feat3_title','homepage','loupe_feat3_title','Lab Certificate Included','2026-09-17 19:01:59.378'),('block-homepage-loupe_headline','homepage','loupe_headline','Zoom In & Inspect Every Gemstone Up Close','2026-09-17 19:01:59.375'),('block-homepage-loupe_image','homepage','loupe_image','/uploads/banners/hero-1789651886835-6o989i.webp','2026-09-17 19:01:59.381'),('block-homepage-loupe_image_caption','homepage','loupe_image_caption','ROYAL BLUE CEYLON SAPPHIRE • CLOSE-UP VIEW','2026-09-17 19:01:59.382'),('block-homepage-loupe_subheadline','homepage','loupe_subheadline','Can\'t visit in person? No problem. Our high-resolution image viewer lets you examine every detail of the gemstone — just like a professional gemologist would.','2026-09-17 19:01:59.376'),('block-homepage-metric1_lbl','homepage','metric1_lbl','Certified Natural','2026-09-17 19:01:59.361'),('block-homepage-metric1_val','homepage','metric1_val','100%','2026-09-17 19:01:59.361'),('block-homepage-metric2_lbl','homepage','metric2_lbl','Independent Reports','2026-09-17 19:01:59.363'),('block-homepage-metric2_val','homepage','metric2_val','GIA & GRS','2026-09-17 19:01:59.362'),('block-homepage-metric3_lbl','homepage','metric3_lbl','Worldwide Courier','2026-09-17 19:01:59.366'),('block-homepage-metric3_val','homepage','metric3_val','Armored','2026-09-17 19:01:59.365'),('block-homepage-metric4_lbl','homepage','metric4_lbl','Inspection Period','2026-09-17 19:01:59.367'),('block-homepage-metric4_val','homepage','metric4_val','30 Days','2026-09-17 19:01:59.366'),('block-homepage-story_cta_link','homepage','story_cta_link','/about','2026-09-17 19:01:59.391'),('block-homepage-story_cta_text','homepage','story_cta_text','Read Our Story →','2026-09-17 19:01:59.391'),('block-homepage-story_eyebrow','homepage','story_eyebrow','Our Story','2026-09-17 19:01:59.385'),('block-homepage-story_headline','homepage','story_headline','Crafted by Nature. Delivered with Trust.','2026-09-17 19:01:59.385'),('block-homepage-story_image','homepage','story_image','/uploads/banners/hero-1789651917652-xw752j.webp','2026-09-17 19:01:59.383'),('block-homepage-story_image_badge','homepage','story_image_badge','Ethically Sourced','2026-09-17 19:01:59.383'),('block-homepage-story_image_caption','homepage','story_image_caption','From Sri Lankan mines to expertly cut gemstones.','2026-09-17 19:01:59.384'),('block-homepage-story_p1','homepage','story_p1','At Faizan Gems, we believe the world\'s finest gemstones should stay 100% natural — no heating, no chemical treatment, no artificial enhancements.','2026-09-17 19:01:59.386'),('block-homepage-story_p2','homepage','story_p2','We work directly with miners in Sri Lanka, Colombia, and Thailand. Every stone is bought from small-scale, eco-friendly mining operations — ensuring fair pay for workers and minimal impact on the environment.','2026-09-17 19:01:59.386'),('block-homepage-story_stat1_lbl','homepage','story_stat1_lbl','Natural & Untreated','2026-09-17 19:01:59.387'),('block-homepage-story_stat1_val','homepage','story_stat1_val','100%','2026-09-17 19:01:59.387'),('block-homepage-story_stat2_lbl','homepage','story_stat2_lbl','Generations of Expert Cutters','2026-09-17 19:01:59.389'),('block-homepage-story_stat2_val','homepage','story_stat2_val','3','2026-09-17 19:01:59.388'),('block-homepage-story_stat3_lbl','homepage','story_stat3_lbl','Mine-to-You Direct','2026-09-17 19:01:59.390'),('block-homepage-story_stat3_val','homepage','story_stat3_val','Direct','2026-09-17 19:01:59.390'),('block-homepage-trust1_desc','homepage','trust1_desc','GIA, Gübelin, SSEF & GRS lab reports you can verify online','2026-09-17 19:01:59.369'),('block-homepage-trust1_title','homepage','trust1_title','Independently Certified Labs','2026-09-17 19:01:59.368'),('block-homepage-trust2_desc','homepage','trust2_desc','Not satisfied? Return within 30 days for a full refund — no questions asked','2026-09-17 19:01:59.370'),('block-homepage-trust2_title','homepage','trust2_title','30-Day Money-Back Guarantee','2026-09-17 19:01:59.369'),('block-homepage-vault_cta_text','homepage','vault_cta_text','View All Gemstones','2026-09-17 19:01:59.374'),('block-homepage-vault_eyebrow','homepage','vault_eyebrow','New Arrivals','2026-09-17 19:01:59.373'),('block-homepage-vault_headline','homepage','vault_headline','Certified Natural Gemstones','2026-09-17 19:01:59.373'),('block-homepage-vault_subheadline','homepage','vault_subheadline','One-of-a-kind natural gemstones,','2026-09-17 19:01:59.374');
/*!40000 ALTER TABLE `content_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_addresses`
--

DROP TABLE IF EXISTS `customer_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_addresses` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postal_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sri Lanka',
  `is_default` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_email` (`user_email`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_addresses`
--

LOCK TABLES `customer_addresses` WRITE;
/*!40000 ALTER TABLE `customer_addresses` DISABLE KEYS */;
INSERT INTO `customer_addresses` VALUES ('addr-1789653735380-3637','00669279-6135-4e29-aeeb-446e040db673','admin@faizangems.com','Admin','+94768671219','tgbrbrtb','gt','Colombo','gtbtr','Sri Lanka',0,'2026-09-17 14:02:15','2026-09-17 14:02:15');
/*!40000 ALTER TABLE `customer_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq_items`
--

DROP TABLE IF EXISTS `faq_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faq_items` (
  `id` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'General',
  `order_index` int NOT NULL DEFAULT '0',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq_items`
--

LOCK TABLES `faq_items` WRITE;
/*!40000 ALTER TABLE `faq_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `faq_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gemstones`
--

DROP TABLE IF EXISTS `gemstones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gemstones` (
  `id` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `variety` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `species` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Corundum',
  `carat` decimal(8,2) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `dimensions_length` decimal(8,2) NOT NULL DEFAULT '0.00',
  `dimensions_width` decimal(8,2) NOT NULL DEFAULT '0.00',
  `dimensions_depth` decimal(8,2) NOT NULL DEFAULT '0.00',
  `cut` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cut_detail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `color` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color_grade` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `clarity` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `origin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `origin_country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `treatment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_unheated` tinyint(1) NOT NULL DEFAULT '1',
  `cert_lab` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'GRS',
  `cert_report_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cert_issue_date` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cert_verification_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cert_comments` text COLLATE utf8mb4_unicode_ci,
  `images` json NOT NULL,
  `angles360` json DEFAULT NULL,
  `variants` json DEFAULT NULL,
  `daylight_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `incandescent_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `in_stock` tinyint(1) NOT NULL DEFAULT '1',
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `investment_grade` tinyint(1) NOT NULL DEFAULT '1',
  `rarity_score` int NOT NULL DEFAULT '90',
  `description` text COLLATE utf8mb4_unicode_ci,
  `story` text COLLATE utf8mb4_unicode_ci,
  `gemologist_notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `gemstones_sku_key` (`sku`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gemstones`
--

LOCK TABLES `gemstones` WRITE;
/*!40000 ALTER TABLE `gemstones` DISABLE KEYS */;
INSERT INTO `gemstones` VALUES ('gem-vault-1789652098025','GEM-VAULT-6034','Emerald','Emerald','Natural Emerald','Natural Beryl',12.00,23996.00,0.00,0.00,0.00,'Cushion','Cushion Precision Cut','Green','Intense Vivid','Eye Clean','Madagascar','Madagascar','Traditional Minor Heat',0,'GRS','','','','','[\"/uploads/gemstones/gem-1789652077476-hwzsqu.webp\"]','[\"/uploads/gemstones/gem-1789652077476-hwzsqu.webp\"]','[{\"id\": \"var-1789652098021\", \"price\": 23996, \"stock\": 1, \"weight\": 12}]',NULL,NULL,NULL,1,1,1,96,'','A natural unheated emerald of exceptional provenance and crystalline purity.','Natural internal features consistent with Madagascar geological formation. Verified natural origin.','2026-09-17 19:04:58.040','2026-09-17 19:04:58.040'),('gem-vault-1789652275594','GEM-VAULT-8570','Natural Ruby ','Ruby','Natural Ruby','Natural Corundum',12.34,34999.00,0.00,0.00,0.00,'Emerald Cut','Emerald Cut Precision Cut','Blood Red','Intense Vivid','Eye Clean','Ratnapura, Sri Lanka','Sri Lanka','Unheated / Untreated',1,'GRS','','','','','[\"/uploads/gemstones/gem-1789652273612-r7yc7e.webp\"]','[\"/uploads/gemstones/gem-1789652273612-r7yc7e.webp\"]','[{\"id\": \"var-1789652275593\", \"price\": 34999, \"stock\": 1, \"weight\": 12.34}]',NULL,NULL,NULL,1,1,1,96,'','A natural unheated ruby of exceptional provenance and crystalline purity.','Natural internal features consistent with Sri Lanka geological formation. Verified natural origin.','2026-09-17 19:07:55.611','2026-09-17 19:07:55.611'),('gem-vault-1789652327674','GEM-VAULT-8429','Yellow Sapphire','Sapphire','Natural Sapphire','Natural Corundum',9.87,9999.00,0.00,0.00,0.00,'Cushion','Cushion Precision Cut','Crown Yellow','Intense Vivid','Eye Clean','Madagascar','Madagascar','Unheated / Untreated',1,'GRS','','','','','[\"/uploads/gemstones/gem-1789652324648-d6siq4.webp\"]','[\"/uploads/gemstones/gem-1789652324648-d6siq4.webp\"]','[{\"id\": \"var-1789652327674\", \"price\": 9999, \"stock\": 1, \"weight\": 9.87}]',NULL,NULL,NULL,1,1,1,96,'','A natural unheated sapphire of exceptional provenance and crystalline purity.','Natural internal features consistent with Madagascar geological formation. Verified natural origin.','2026-09-17 19:08:47.688','2026-09-17 19:08:47.688'),('gem-vault-1789652368957','GEM-VAULT-4130','Natural Blue Sapphire','Sapphire','Natural Sapphire','Natural Corundum',8.98,13999.00,0.00,0.00,0.00,'Cushion','Cushion Precision Cut','Peacock Blue','Intense Vivid','Eye Clean','Ratnapura, Srilanka','Srilanka','Unheated / Untreated',1,'GRS','','','','','[\"/uploads/gemstones/gem-1789652354821-4flg6s.webp\"]','[\"/uploads/gemstones/gem-1789652354821-4flg6s.webp\"]','[{\"id\": \"var-1789652368957\", \"price\": 13999, \"stock\": 1, \"weight\": 8.98}]',NULL,NULL,NULL,1,1,1,96,'','A natural unheated sapphire of exceptional provenance and crystalline purity.','Natural internal features consistent with Srilanka geological formation. Verified natural origin.','2026-09-17 19:09:28.972','2026-09-17 19:09:28.972');
/*!40000 ALTER TABLE `gemstones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inquiries`
--

DROP TABLE IF EXISTS `inquiries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inquiries` (
  `id` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gemstone_id` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gemstone_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preferred_location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inquiries`
--

LOCK TABLES `inquiries` WRITE;
/*!40000 ALTER TABLE `inquiries` DISABLE KEYS */;
/*!40000 ALTER TABLE `inquiries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_number` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_phone` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postal_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `courier` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Armored Air Courier',
  `items` json NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `currency` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'wire',
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending_inspection',
  `tracking_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `orders_order_number_key` (`order_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('CUSTOMER','ADMIN') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CUSTOMER',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_key` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('00669279-6135-4e29-aeeb-446e040db673','Admin','admin@faizangems.com','$2b$12$dbaQQ9R2RLr8XNmIqsu9s.XA.zzINARVmZsnJPjQUq5f5PA2xp2RG','+94768671219','ADMIN','2026-09-17 18:16:53.388');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-17 19:41:12
