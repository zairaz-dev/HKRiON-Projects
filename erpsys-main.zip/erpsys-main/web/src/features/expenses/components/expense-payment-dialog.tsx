import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Calendar, CreditCard, Loader2, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Dialog } from "@/components/ui/dialog";
import { User } from "@hkr/types";
import { ExpenseItem } from "../types";
import { useAddExpensePaymentMutation } from "../hooks/use-expenses";
import { usePaymentMethodsQuery } from "@/features/payment-methods/hooks/use-payment-methods";
import { useCurrency } from "@/hooks/use-currency";

interface ExpensePaymentDialogProps {
  isOpen: boolean;
  onClose: () => void;
  expense: ExpenseItem | null;
  currentUser: User;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

export function ExpensePaymentDialog({
  isOpen,
  onClose,
  expense,
  currentUser,
  onSuccess,
  onError,
}: ExpensePaymentDialogProps) {
  const addPaymentMutation = useAddExpensePaymentMutation();
  const businessId = currentUser.businessId || "";
  const { symbol, format } = useCurrency(businessId);
  const { data: paymentMethods = [] } = usePaymentMethodsQuery(businessId);

  const dueAmount = expense ? expense.amount - expense.amountPaid : 0;

  const schema = z.object({
    amount: z.number().min(0.01, "Amount must be greater than 0").max(dueAmount, `Amount cannot exceed due amount of ${format(dueAmount)}`),
    paymentMethodId: z.string().min(1, "Payment method is required"),
    paymentDate: z.string().min(1, "Payment date is required"),
    notes: z.string().optional(),
  });

  type SchemaType = z.infer<typeof schema>;

  const {
    register,
    handleSubmit,
    reset,
    watch,
    setValue,
    formState: { errors },
  } = useForm<SchemaType>({
    resolver: zodResolver(schema),
    defaultValues: {
      amount: 0,
      paymentMethodId: "",
      paymentDate: new Date().toISOString().split("T")[0],
      notes: "",
    },
  });

  const watchPaymentMethodId = watch("paymentMethodId") || "";

  // Pre-fill amount when dialog opens or expense changes
  useEffect(() => {
    if (expense) {
      const due = expense.amount - expense.amountPaid;
      reset({
        amount: due > 0 ? due : 0,
        paymentMethodId: "",
        paymentDate: new Date().toISOString().split("T")[0],
        notes: "",
      });
    }
  }, [expense, reset, isOpen]);

  const onSubmit = async (data: SchemaType) => {
    if (!expense || !currentUser.businessId) return;

    try {
      await addPaymentMutation.mutateAsync({
        expenseId: expense.id,
        businessId: currentUser.businessId,
        data: {
          amount: data.amount,
          paymentMethodId: data.paymentMethodId,
          notes: data.notes || "Recorded payment",
          paymentDate: data.paymentDate,
        },
      });
      onSuccess("Payment recorded successfully!");
      onClose();
    } catch (err: any) {
      onError(err.message || "Failed to record payment.");
    }
  };

  const isLoading = addPaymentMutation.isPending;

  if (!isOpen || !expense) return null;

  return (
    <Dialog
      isOpen={isOpen}
      onClose={onClose}
      size="md"
      title={
        <>
          <CreditCard className="h-5 w-5 text-primary" />
          Record Payment
        </>
      }
    >
      {/* Expense Info Summary */}
      <div className="grid grid-cols-3 gap-2 bg-muted/40 p-3 rounded-lg text-xs mb-4">
        <div>
          <span className="text-muted-foreground block font-medium">Total Amount</span>
          <span className="font-extrabold text-foreground">{format(expense.amount)}</span>
        </div>
        <div>
          <span className="text-muted-foreground block font-medium">Amount Paid</span>
          <span className="font-extrabold text-emerald-600 dark:text-emerald-400">{format(expense.amountPaid)}</span>
        </div>
        <div>
          <span className="text-muted-foreground block font-medium">Due Amount</span>
          <span className="font-extrabold text-amber-600 dark:text-amber-400">{format(dueAmount)}</span>
        </div>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        {/* Paying Amount */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-muted-foreground">
            Paying Amount <span className="text-destructive">*</span>
          </label>
          <Input
            type="number"
            step="0.01"
            placeholder="0.00"
            {...register("amount", { valueAsNumber: true })}
            className="h-9 text-xs"
          />
          {errors.amount && (
            <span className="text-[10px] text-destructive flex items-center gap-1">
              <AlertCircle className="h-3 w-3" /> {errors.amount.message}
            </span>
          )}
        </div>

        {/* Payment Method */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-muted-foreground">
            Payment Method <span className="text-destructive">*</span>
          </label>
          <Select
            {...register("paymentMethodId")}
            value={watchPaymentMethodId}
            onValueChange={(val) => setValue("paymentMethodId", val, { shouldValidate: true })}
            icon={<CreditCard className="h-3.5 w-3.5 text-muted-foreground" />}
          >
            <option value="">Select Method</option>
            {paymentMethods.map((pm) => (
              <option key={pm.id} value={pm.id}>
                {pm.name}
              </option>
            ))}
          </Select>
          {errors.paymentMethodId && (
            <span className="text-[10px] text-destructive flex items-center gap-1">
              <AlertCircle className="h-3 w-3" /> {errors.paymentMethodId.message}
            </span>
          )}
        </div>

        {/* Payment Date */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-muted-foreground flex items-center gap-1.5">
            <Calendar className="h-3.5 w-3.5" /> Payment Date <span className="text-destructive">*</span>
          </label>
          <Input
            type="date"
            {...register("paymentDate")}
            className="h-9 text-xs"
          />
          {errors.paymentDate && (
            <span className="text-[10px] text-destructive flex items-center gap-1">
              <AlertCircle className="h-3 w-3" /> {errors.paymentDate.message}
            </span>
          )}
        </div>

        {/* Notes */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-muted-foreground">Notes</label>
          <textarea
            {...register("notes")}
            rows={2}
            placeholder="Enter notes..."
            className="w-full rounded-md border border-input bg-background px-3 py-2 text-xs shadow-sm focus:outline-none focus:ring-1 focus:ring-ring resize-none"
          />
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end space-x-3 pt-3 border-t border-border/50">
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
            disabled={isLoading}
            className="h-9 text-xs"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={isLoading}
            className="h-9 text-xs flex items-center gap-1.5"
          >
            {isLoading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            Submit Payment
          </Button>
        </div>
      </form>
    </Dialog>
  );
}
