import React from "react";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { User } from "@hkr/types";
import { PaymentMethodItem } from "../types";
import { useDeletePaymentMethodMutation } from "../hooks/use-payment-methods";

interface PaymentMethodDeleteDialogProps {
  isOpen: boolean;
  onClose: () => void;
  paymentMethod: PaymentMethodItem | null;
  currentUser: User;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

export function PaymentMethodDeleteDialog({
  isOpen,
  onClose,
  paymentMethod,
  currentUser,
  onSuccess,
  onError,
}: PaymentMethodDeleteDialogProps) {
  const deleteMutation = useDeletePaymentMethodMutation();

  const handleDelete = async () => {
    if (!paymentMethod || !currentUser.businessId) return;

    try {
      await deleteMutation.mutateAsync({
        id: paymentMethod.id,
        businessId: currentUser.businessId,
      });
      onSuccess(
        paymentMethod.isSystem
          ? "System payment method deactivated successfully!"
          : "Payment method deleted successfully!"
      );
      onClose();
    } catch (err: any) {
      onError(err.message || "Failed to delete payment method.");
    }
  };

  const isLoading = deleteMutation.isPending;

  if (!isOpen || !paymentMethod) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-sm bg-card border border-border rounded-sm shadow-2xl p-6 animate-in zoom-in-95 duration-200">
        <h3 className="text-lg font-bold text-foreground mb-2">
          {paymentMethod.isSystem ? "Deactivate Payment Method?" : "Delete Payment Method?"}
        </h3>
        <p className="text-xs text-muted-foreground mb-5 leading-relaxed">
          {paymentMethod.isSystem ? (
            <>
              Are you sure you want to deactivate the system payment method{" "}
              <strong className="text-foreground">"{paymentMethod.name}"</strong>? This will make it
              unavailable across your business and branches. It cannot be hard deleted.
            </>
          ) : (
            <>
              Are you sure you want to delete the payment method{" "}
              <strong className="text-foreground">"{paymentMethod.name}"</strong>? This action will disable it
              for all branches.
            </>
          )}
        </p>
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={onClose}
            className="flex-1 text-xs"
          >
            Cancel
          </Button>
          <Button
            onClick={handleDelete}
            disabled={isLoading}
            className="flex-1 bg-rose-600 hover:bg-rose-700 text-white text-xs gap-1.5"
          >
            {isLoading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            {paymentMethod.isSystem ? "Deactivate" : "Delete"}
          </Button>
        </div>
      </div>
    </div>
  );
}
