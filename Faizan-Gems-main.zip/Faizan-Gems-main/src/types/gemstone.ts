export type GemstoneType =
  | "Sapphire"
  | "Ruby"
  | "Emerald"
  | "Padparadscha"
  | "Alexandrite"
  | "Spinel"
  | "Tourmaline"
  | "Aquamarine"
  | "Tanzanite"
  | (string & {});

export type GemstoneCut =
  | "Cushion"
  | "Oval"
  | "Emerald Cut"
  | "Round"
  | "Pear"
  | "Radiant"
  | "Baguette"
  | "Heart"
  | "Marquise"
  | "Princess"
  | (string & {});

export type CertificationLab =
  | "GIA"
  | "GRS"
  | "Gübelin"
  | "SSEF"
  | "IGI"
  | (string & {});

/**
 * Extracts the country name from an origin string (e.g. "Ratnapura, Sri Lanka" -> "Sri Lanka", "Muzo, Colombia" -> "Colombia").
 */
export function extractCountryFromOrigin(origin?: string): string {
  if (!origin || !origin.trim()) return "Sri Lanka";
  const trimmed = origin.trim();
  if (trimmed.includes(",")) {
    const parts = trimmed.split(",");
    const country = parts[parts.length - 1].trim();
    if (country) return country;
  }
  return trimmed;
}

/**
 * Maps a gemstone type to its scientific mineral species.
 */
export function getSpeciesForType(type?: string): string {
  const t = (type || "").toLowerCase().trim();
  if (t.includes("sapphire") || t.includes("ruby") || t.includes("padparadscha") || t.includes("corundum")) {
    return "Natural Corundum";
  }
  if (
    t.includes("emerald") ||
    t.includes("aquamarine") ||
    t.includes("morganite") ||
    t.includes("beryl") ||
    t.includes("goshenite") ||
    t.includes("heliodor")
  ) {
    return "Natural Beryl";
  }
  if (t.includes("spinel")) {
    return "Natural Spinel";
  }
  if (t.includes("alexandrite") || t.includes("chrysoberyl") || t.includes("cat's eye") || t.includes("cats eye")) {
    return "Natural Chrysoberyl";
  }
  if (t.includes("tourmaline") || t.includes("paraiba") || t.includes("rubellite") || t.includes("indicolite")) {
    return "Natural Tourmaline";
  }
  if (
    t.includes("garnet") ||
    t.includes("tsavorite") ||
    t.includes("spessartite") ||
    t.includes("rhodolite") ||
    t.includes("demantoid")
  ) {
    return "Natural Garnet";
  }
  if (t.includes("tanzanite") || t.includes("zoisite")) {
    return "Natural Zoisite";
  }
  if (t.includes("topaz")) {
    return "Natural Topaz";
  }
  if (t.includes("quartz") || t.includes("amethyst") || t.includes("citrine")) {
    return "Natural Quartz";
  }
  if (t.includes("peridot")) {
    return "Natural Peridot";
  }
  if (t.includes("zircon")) {
    return "Natural Zircon";
  }
  if (t.includes("opal")) {
    return "Natural Opal";
  }
  return "Natural Precious Mineral";
}

export type TreatmentType =
  | "Unheated / Untreated"
  | "Unheated"
  | "None (Completely Unheated)"
  | "Traditional Minor Heat"
  | "Minor Cedar Oil (Insignificant)"
  | "Untreated Oil-Free"
  | (string & {});

export interface GemstoneVariant {
  id: string;
  weight: number; // in carats, e.g. 0.55
  price: number;  // in USD, e.g. 4500
  stock: number;  // available quantity in vault, e.g. 5
  size?: string;  // dimensions in mm, e.g. "6.6 x 3.4 x 2.1mm"
}

export interface LabCertification {
  lab: CertificationLab;
  reportNumber: string;
  issueDate: string;
  specimenPhotoUrl?: string;
  verificationUrl?: string;
  comments: string;
  originConfirmed: boolean;
  treatmentConfirmed: string;
  hologramVerified: boolean;
}

export interface Gemstone {
  id: string;
  sku: string;
  name: string;
  type: GemstoneType;
  variety: string;
  species: string;
  carat: number;
  price: number; // Base valuation (rendered in USD)
  dimensions?: {
    length: number;
    width: number;
    depth: number;
  };
  cut: GemstoneCut;
  cutDetail: string;
  color: string;
  colorGrade: string;
  clarity: string;
  origin: string;
  originCountry: string;
  treatment: TreatmentType;
  isUnheated: boolean;
  certification: LabCertification;
  images: string[];
  angles360: string[];
  variants?: GemstoneVariant[];
  daylightImage?: string;
  incandescentImage?: string;
  video?: string;
  inStock: boolean;
  featured: boolean;
  investmentGrade: boolean;
  rarityScore: number; // 1 to 100
  description: string;
  story: string;
  gemologistNotes: string;
  createdAt?: string;
}

export interface Collection {
  id: string;
  slug: string;
  title: string;
  tagline: string;
  description: string;
  heroImage: string;
  curatorQuote: string;
}

export type SettingOption =
  | "loose"
  | "ring-platinum"
  | "ring-18k-yellow"
  | "ring-18k-rose"
  | "pendant-platinum";

export interface CartItem {
  gemstone: Gemstone;
  setting: SettingOption;
  ringSize?: string;
  selectedVariant?: GemstoneVariant;
  selectedWeight?: number;
  selectedPrice?: number;
  selectedSize?: string;
  quantity?: number;
  giftBox: boolean;
  tamperSealInspected: boolean;
  notes?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  createdAt: string;
  client: {
    fullName: string;
    email: string;
    phone: string;
    clientId?: string;
  };
  shippingAddress: {
    address: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
  courier: string;
  items: CartItem[];
  subtotal: number;
  total: number;
  currency: string;
  paymentMethod: "wire" | "card" | "escrow";
  status: "pending_inspection" | "vault_packed" | "in_transit" | "delivered";
  trackingNumber: string;
}
