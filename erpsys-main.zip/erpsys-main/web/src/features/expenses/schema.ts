import * as z from "zod";

export const expenseFormSchema = z.object({
  amount: z.number().min(0.01, "Amount must be greater than 0"),
  expenseDate: z.string().min(1, "Expense date is required"),
  paymentStatus: z.enum(["PAID", "DUE", "PARTIAL"]),
  amountPaid: z.number().min(0, "Amount paid cannot be negative").optional(),
  notes: z.string().optional(),
  attachmentUrl: z.string().optional(),
  categoryId: z.string().min(1, "Expense category is required"),
  branchId: z.string().min(1, "Branch is required"),
  paymentMethodId: z.string().optional(),
});

export type ExpenseFormSchema = z.infer<typeof expenseFormSchema>;
