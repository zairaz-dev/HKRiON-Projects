const { PrismaClient } = require('@prisma/client');
const { randomUUID } = require('crypto');
const prisma = new PrismaClient();

async function main() {
  console.log('Finding HKR System Business and Main Branch...');
  const business = await prisma.business.findFirst({
    where: { name: 'HKR System Business' }
  });

  if (!business) {
    console.error('HKR System Business not found! Please run the app dev server or seed first.');
    return;
  }

  const branch = await prisma.branch.findFirst({
    where: { businessId: business.id }
  });

  if (!branch) {
    console.error('Main Branch not found for this business!');
    return;
  }

  const user = await prisma.user.findFirst({
    where: { email: 'superadmin@hkr.com' }
  });

  if (!user) {
    console.error('Super admin user not found!');
    return;
  }

  console.log('Clearing existing categories to avoid unique constraint violations...');
  await prisma.categoryBranch.deleteMany({
    where: { branchId: branch.id }
  });
  await prisma.category.deleteMany({
    where: { businessId: business.id }
  });
  console.log('Existing categories cleared.');

  console.log('Generating 1,000,000 categories (200,000 main, each with 4 subcategories)...');
  
  const chunkSize = 10000;
  let categoryChunk = [];
  let branchChunk = [];
  
  const totalParents = 200000; // 200,000 parent categories * 5 = 1,000,000 total categories
  
  for (let i = 1; i <= totalParents; i++) {
    const parentId = randomUUID();
    const parentName = `Category ${i}`;
    
    categoryChunk.push({
      id: parentId,
      name: parentName,
      description: `Description for ${parentName}`,
      businessId: business.id,
      createdById: user.id,
      isActive: true,
    });
    
    branchChunk.push({
      categoryId: parentId,
      branchId: branch.id,
    });
    
    for (let j = 1; j <= 4; j++) {
      const subId = randomUUID();
      const subName = `Subcategory ${i}-${j}`;
      
      categoryChunk.push({
        id: subId,
        name: subName,
        description: `Description for ${subName}`,
        businessId: business.id,
        parentId: parentId,
        createdById: user.id,
        isActive: true,
      });
      
      branchChunk.push({
        categoryId: subId,
        branchId: branch.id,
      });
    }

    // Bulk insert chunks
    if (categoryChunk.length >= chunkSize) {
      await prisma.category.createMany({
        data: categoryChunk,
        skipDuplicates: true,
      });
      await prisma.categoryBranch.createMany({
        data: branchChunk,
        skipDuplicates: true,
      });
      
      categoryChunk = [];
      branchChunk = [];
      
      if (i % 10000 === 0) {
        console.log(`Successfully generated and inserted ${i * 5} categories...`);
      }
    }
  }

  // Insert any remaining data
  if (categoryChunk.length > 0) {
    await prisma.category.createMany({
      data: categoryChunk,
      skipDuplicates: true,
    });
    await prisma.categoryBranch.createMany({
      data: branchChunk,
      skipDuplicates: true,
    });
  }

  console.log('1,000,000 categories successfully created and linked to Main Branch!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
