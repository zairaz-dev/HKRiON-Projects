import { InquiryService } from "@/services/inquiry.service";
import LeadsCRMView from "@/components/admin/leads/LeadsCRMView";

export const dynamic = "force-dynamic";

export default async function AdminInquiriesPage() {
  const inquiries = await InquiryService.getAll();

  return (
    <div className="w-full">
      <LeadsCRMView initialInquiries={inquiries} />
    </div>
  );
}
