"use strict";
"use client";

import React, { useEffect, useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { authService } from "@/services/auth-service";
import { LoadingSession } from "@/components/ui/loading-session";
import { User } from "@hkr/types";
import {
  superSettingsService,
  SuperPlatformSetting,
  SystemHealthData,
} from "@/services/super-settings-service";
import { subscriptionService } from "@/services/subscription-service";
import { SaasBankSetting } from "@/features/subscriptions";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Settings,
  Globe,
  CreditCard,
  Mail,
  MessageSquare,
  Shield,
  Activity,
  Save,
  CheckCircle,
  AlertTriangle,
  Send,
  Loader2,
  RefreshCw,
  Server,
  Database,
  Cpu,
  Clock,
  Sparkles,
  Zap,
  Landmark,
  Bot,
  Eye,
  EyeOff,
  Key,
  Sliders,
} from "lucide-react";

export default function SuperAdminSettingsPage() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  const [activeTab, setActiveTab] = useState<
    "general" | "payments" | "smtp" | "sms" | "security" | "ai"
  >("general");

  const [settings, setSettings] = useState<SuperPlatformSetting>({
    platformName: "HKRION ERP Suite",
    tagline: "Enterprise Multi-Tenant Cloud ERP",
    supportEmail: "support@hkrion.com",
    supportPhone: "+94 77 123 4567",
    supportWhatsapp: "+94 77 123 4567",
    defaultCurrency: "LKR",
    defaultTimezone: "Asia/Colombo",
    defaultTrialDays: 14,
    subscriptionTaxRate: 18.0,
    payhereMerchantId: "1230179",
    payhereMerchantSecret: "ODk1MjE0NzUzMzk3MjYzODk1MTE2MTA3MjUxOTQxOTg0NDYxMDc0",
    payhereMode: "sandbox",
    smtpHost: "smtp.gmail.com",
    smtpPort: 587,
    smtpSecure: false,
    smtpUser: "",
    smtpPass: "",
    smtpFromEmail: "noreply@hkrion.com",
    smtpFromName: "HKRION Cloud ERP",
    notifyOnNewTenant: true,
    notifyOnBankTransfer: true,
    notifyOnSubExpiry: true,
    smsProvider: "custom_http",
    smsApiKey: "",
    smsSenderId: "HKRION",
    smsApiUrl: "",
    maintenanceMode: false,
    maintenanceMessage:
      "System is currently undergoing scheduled maintenance. Please check back shortly.",
    allowPublicSignups: true,
    enableGoogleAuth: true,
    googleClientId: "",
    googleClientSecret: "",
    enableAiAssistant: false,
    openRouterApiKey: "",
    openRouterModel: "google/gemini-2.0-flash-exp:free",
    aiMaxTokens: 500,
    aiTemperature: 0.7,
    aiSystemPrompt:
      "You are HKRION ERP AI Copilot, a helpful business assistant for enterprise ERP management. Provide concise, professional and actionable insights in English or Tamil based on the user's language.",
    aiAllowedRoles: ["SUPER_ADMIN", "ADMIN", "MANAGER", "CASHIER"],
  });

  const [bankSetting, setBankSetting] = useState<SaasBankSetting>({
    id: "",
    bankName: "Commercial Bank of Ceylon",
    accountName: "HKRION SYSTEMS PVT LTD",
    accountNumber: "800234567890",
    branchName: "Colombo Corporate Branch",
    swiftCode: "CCEYLKX",
    instructions: "Please include your Business Name and Invoice # in the deposit remark/slip.",
    isActive: true,
  });

  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  // Test Email Modal State
  const [isTestEmailOpen, setIsTestEmailOpen] = useState(false);
  const [testEmailTo, setTestEmailTo] = useState("");
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const [testEmailStatus, setTestEmailStatus] = useState<string | null>(null);

  // Test SMS Modal State
  const [isTestSmsOpen, setIsTestSmsOpen] = useState(false);
  const [testSmsNumber, setTestSmsNumber] = useState("");
  const [isSendingSms, setIsSendingSms] = useState(false);
  const [testSmsStatus, setTestSmsStatus] = useState<string | null>(null);

  // OpenRouter & AI Testing State
  const [showApiKey, setShowApiKey] = useState(false);
  const [isTestingAi, setIsTestingAi] = useState(false);
  const [aiTestResult, setAiTestResult] = useState<{
    success: boolean;
    message: string;
    reply?: string;
    latencyMs?: number;
  } | null>(null);

  // Health Diagnostics
  const [healthData, setHealthData] = useState<SystemHealthData | null>(null);
  const [isHealthLoading, setIsHealthLoading] = useState(false);

  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 1500);
    } else {
      loadSettings();
    }
  }, []);

  const loadSettings = async () => {
    setIsLoading(true);
    try {
      const [data, bankConfig] = await Promise.all([
        superSettingsService.getSettings(),
        subscriptionService.getSaasBankConfig(),
      ]);
      if (data) setSettings(data);
      if (bankConfig) setBankSetting(bankConfig);
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to load platform settings");
    } finally {
      setIsLoading(false);
    }
  };

  const loadHealth = async () => {
    setIsHealthLoading(true);
    try {
      const data = await superSettingsService.getSystemHealth();
      setHealthData(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsHealthLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === "security") {
      loadHealth();
    }
  }, [activeTab]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSaveSuccess(false);
    setErrorMessage("");

    try {
      await Promise.all([
        superSettingsService.updateSettings(settings),
        subscriptionService.updateSaasBankConfig(bankSetting),
      ]);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3500);
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to update platform settings");
    } finally {
      setIsSaving(false);
    }
  };

  // SMTP Presets Applicator
  const applySmtpPreset = (preset: "gmail" | "sendgrid" | "ses") => {
    if (preset === "gmail") {
      setSettings((prev) => ({
        ...prev,
        smtpHost: "smtp.gmail.com",
        smtpPort: 587,
        smtpSecure: false,
      }));
    } else if (preset === "sendgrid") {
      setSettings((prev) => ({
        ...prev,
        smtpHost: "smtp.sendgrid.net",
        smtpPort: 587,
        smtpSecure: false,
        smtpUser: "apikey",
      }));
    } else if (preset === "ses") {
      setSettings((prev) => ({
        ...prev,
        smtpHost: "email-smtp.us-east-1.amazonaws.com",
        smtpPort: 587,
        smtpSecure: false,
      }));
    }
  };

  const handleSendTestEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSendingEmail(true);
    setTestEmailStatus(null);
    try {
      const res = await superSettingsService.sendTestEmail({
        toEmail: testEmailTo,
      });
      setTestEmailStatus(res.message || "Test email dispatched successfully!");
    } catch (err: any) {
      setTestEmailStatus(`Failed: ${err.message}`);
    } finally {
      setIsSendingEmail(false);
    }
  };

  const handleSendTestSms = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSendingSms(true);
    setTestSmsStatus(null);
    try {
      const res = await superSettingsService.sendTestSms({
        phoneNumber: testSmsNumber,
      });
      setTestSmsStatus(res.message || "Test SMS triggered successfully!");
    } catch (err: any) {
      setTestSmsStatus(`Failed: ${err.message}`);
    } finally {
      setIsSendingSms(false);
    }
  };

  const handleTestAiConnection = async () => {
    setIsTestingAi(true);
    setAiTestResult(null);
    try {
      const res = await superSettingsService.testAiConnection({
        apiKey: settings.openRouterApiKey,
        model: settings.openRouterModel,
      });
      setAiTestResult({
        success: true,
        message: res.message,
        reply: res.reply,
        latencyMs: res.latencyMs,
      });
    } catch (err: any) {
      setAiTestResult({
        success: false,
        message: err.message || "Failed to connect to OpenRouter AI",
      });
    } finally {
      setIsTestingAi(false);
    }
  };

  if (isAuthenticated === null || (isAuthenticated && !currentUser)) {
    return <LoadingSession />;
  }

  if (currentUser?.role !== "super-admin") {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4 text-center">
        <h2 className="text-xl font-bold text-foreground">Access Restricted</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Super Admin privileges are required to access Global Platform Settings.
        </p>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/super/settings" />

      <div className="flex-1 flex flex-col overflow-hidden relative">
        <Navbar title="Global Platform Settings" className="relative z-10" />

        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 relative z-10">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-black tracking-tight font-mono text-foreground flex items-center gap-2">
                <Settings className="w-6 h-6 text-primary" /> Platform & SaaS Settings
              </h1>
              <p className="text-xs text-muted-foreground mt-0.5">
                Centralized control over system branding, payment gateways, SaaS bank transfer details, global SMTP/SMS servers, and maintenance mode.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <Button
                type="button"
                onClick={handleSave}
                disabled={isSaving}
                className="text-xs h-9 px-4 font-bold shadow-lg shadow-primary/20 flex items-center gap-1.5"
              >
                {isSaving ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" /> Saving Changes...
                  </>
                ) : (
                  <>
                    <Save className="w-3.5 h-3.5" /> Save All Settings
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Feedback alerts */}
          {saveSuccess && (
            <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 p-3.5 rounded-xl text-xs flex items-center gap-2 animate-fadeIn">
              <CheckCircle className="w-4 h-4 shrink-0" />
              <span>Platform & SaaS Bank settings updated successfully across all instances!</span>
            </div>
          )}

          {errorMessage && (
            <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 p-3.5 rounded-xl text-xs flex items-center gap-2 animate-fadeIn">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Navigation Tabs */}
          <div className="flex items-center gap-2 border-b border-border pb-1 overflow-x-auto">
            <button
              onClick={() => setActiveTab("general")}
              className={`px-4 py-2 text-xs font-bold font-mono transition-all rounded-t-lg flex items-center gap-2 ${
                activeTab === "general"
                  ? "border-b-2 border-primary text-primary bg-primary/10"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Globe className="w-4 h-4" /> General & Branding
            </button>

            <button
              onClick={() => setActiveTab("payments")}
              className={`px-4 py-2 text-xs font-bold font-mono transition-all rounded-t-lg flex items-center gap-2 ${
                activeTab === "payments"
                  ? "border-b-2 border-primary text-primary bg-primary/10"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <CreditCard className="w-4 h-4" /> Payment Gateways, Bank & Tax
            </button>

            <button
              onClick={() => setActiveTab("smtp")}
              className={`px-4 py-2 text-xs font-bold font-mono transition-all rounded-t-lg flex items-center gap-2 ${
                activeTab === "smtp"
                  ? "border-b-2 border-primary text-primary bg-primary/10"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Mail className="w-4 h-4" /> SMTP & Email Alerts
            </button>

            <button
              onClick={() => setActiveTab("sms")}
              className={`px-4 py-2 text-xs font-bold font-mono transition-all rounded-t-lg flex items-center gap-2 ${
                activeTab === "sms"
                  ? "border-b-2 border-primary text-primary bg-primary/10"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <MessageSquare className="w-4 h-4" /> SMS Gateway
            </button>

            <button
              onClick={() => setActiveTab("security")}
              className={`px-4 py-2 text-xs font-bold font-mono transition-all rounded-t-lg flex items-center gap-2 ${
                activeTab === "security"
                  ? "border-b-2 border-primary text-primary bg-primary/10"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Shield className="w-4 h-4" /> Security & System Health
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("ai")}
              className={`px-4 py-2 text-xs font-bold font-mono transition-all rounded-t-lg flex items-center gap-2 ${
                activeTab === "ai"
                  ? "border-b-2 border-primary text-primary bg-primary/10"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Sparkles className="w-4 h-4 text-amber-400" /> AI Copilot & OpenRouter
            </button>
          </div>

          {isLoading ? (
            <div className="p-12 text-center text-muted-foreground">
              <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-primary" />
              <p className="text-xs">Loading platform configuration...</p>
            </div>
          ) : (
            <form onSubmit={handleSave} className="space-y-6">
              {/* TAB 1: GENERAL & BRANDING */}
              {activeTab === "general" && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="bg-card/40 backdrop-blur-md border-border/60">
                    <CardContent className="p-6 space-y-4">
                      <div className="border-b border-border pb-2">
                        <h3 className="text-sm font-bold text-foreground flex items-center gap-2 font-mono">
                          <Globe className="w-4 h-4 text-primary" /> Platform Branding
                        </h3>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          Public identity and branding details for the SaaS ERP.
                        </p>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-muted-foreground font-mono">
                          Platform Name *
                        </label>
                        <Input
                          value={settings.platformName}
                          onChange={(e) =>
                            setSettings({ ...settings, platformName: e.target.value })
                          }
                          className="h-9 text-xs font-bold"
                          required
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-muted-foreground font-mono">
                          Tagline / Slogan
                        </label>
                        <Input
                          value={settings.tagline || ""}
                          onChange={(e) =>
                            setSettings({ ...settings, tagline: e.target.value })
                          }
                          className="h-9 text-xs"
                          placeholder="e.g. Enterprise Multi-Tenant Cloud ERP"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">
                            Default Currency
                          </label>
                          <select
                            value={settings.defaultCurrency}
                            onChange={(e) =>
                              setSettings({ ...settings, defaultCurrency: e.target.value })
                            }
                            className="w-full h-9 px-3 text-xs rounded-md bg-secondary/50 border border-border text-foreground font-mono"
                          >
                            <option value="LKR">LKR (Sri Lankan Rupee)</option>
                            <option value="USD">USD (US Dollar)</option>
                            <option value="INR">INR (Indian Rupee)</option>
                            <option value="AED">AED (UAE Dirham)</option>
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">
                            Default Trial Period
                          </label>
                          <div className="relative">
                            <Input
                              type="number"
                              min={1}
                              max={365}
                              value={settings.defaultTrialDays}
                              onChange={(e) =>
                                setSettings({
                                  ...settings,
                                  defaultTrialDays: parseInt(e.target.value) || 14,
                                })
                              }
                              className="h-9 text-xs font-mono pr-12"
                            />
                            <span className="absolute right-3 top-2.5 text-[10px] text-muted-foreground font-mono">
                              Days
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-muted-foreground font-mono">
                          System Timezone
                        </label>
                        <Input
                          value={settings.defaultTimezone}
                          onChange={(e) =>
                            setSettings({ ...settings, defaultTimezone: e.target.value })
                          }
                          className="h-9 text-xs font-mono"
                          placeholder="e.g. Asia/Colombo"
                        />
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-card/40 backdrop-blur-md border-border/60">
                    <CardContent className="p-6 space-y-4">
                      <div className="border-b border-border pb-2">
                        <h3 className="text-sm font-bold text-foreground flex items-center gap-2 font-mono">
                          <MessageSquare className="w-4 h-4 text-primary" /> Support & Contact Info
                        </h3>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          Helpdesk and customer care contact channels shown to tenants.
                        </p>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-muted-foreground font-mono">
                          Customer Support Email *
                        </label>
                        <Input
                          type="email"
                          value={settings.supportEmail}
                          onChange={(e) =>
                            setSettings({ ...settings, supportEmail: e.target.value })
                          }
                          className="h-9 text-xs"
                          required
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-muted-foreground font-mono">
                          Support Hotline Phone
                        </label>
                        <Input
                          value={settings.supportPhone || ""}
                          onChange={(e) =>
                            setSettings({ ...settings, supportPhone: e.target.value })
                          }
                          className="h-9 text-xs font-mono"
                          placeholder="e.g. +94 77 123 4567"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-muted-foreground font-mono">
                          Support WhatsApp Number
                        </label>
                        <Input
                          value={settings.supportWhatsapp || ""}
                          onChange={(e) =>
                            setSettings({ ...settings, supportWhatsapp: e.target.value })
                          }
                          className="h-9 text-xs font-mono"
                          placeholder="e.g. +94 77 123 4567"
                        />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* TAB 2: PAYMENT GATEWAYS, BANK & TAX */}
              {activeTab === "payments" && (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* PayHere Gateway */}
                    <Card className="bg-card/40 backdrop-blur-md border-border/60">
                      <CardContent className="p-6 space-y-4">
                        <div className="flex items-center justify-between border-b border-border pb-2">
                          <div>
                            <h3 className="text-sm font-bold text-foreground flex items-center gap-2 font-mono">
                              <CreditCard className="w-4 h-4 text-primary" /> PayHere.lk Gateway Settings
                            </h3>
                            <p className="text-xs text-muted-foreground mt-0.5">
                              Sri Lankan Online Gateway for Cards, FriMi, Genie & eZ Cash.
                            </p>
                          </div>
                          <span className="text-[10px] font-bold bg-primary/20 text-primary px-2 py-0.5 rounded font-mono">
                            🇱🇰 SRI LANKA
                          </span>
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">
                            PayHere Environment Mode
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              onClick={() => setSettings({ ...settings, payhereMode: "sandbox" })}
                              className={`p-2.5 rounded-lg border text-xs font-mono font-bold transition-all ${
                                settings.payhereMode === "sandbox"
                                  ? "border-amber-500 bg-amber-500/10 text-amber-400"
                                  : "border-border bg-secondary/40 text-muted-foreground"
                              }`}
                            >
                              SANDBOX (Test Mode)
                            </button>

                            <button
                              type="button"
                              onClick={() => setSettings({ ...settings, payhereMode: "live" })}
                              className={`p-2.5 rounded-lg border text-xs font-mono font-bold transition-all ${
                                settings.payhereMode === "live"
                                  ? "border-emerald-500 bg-emerald-500/10 text-emerald-400"
                                  : "border-border bg-secondary/40 text-muted-foreground"
                              }`}
                            >
                              LIVE (Production)
                            </button>
                          </div>
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">
                            Merchant ID
                          </label>
                          <Input
                            value={settings.payhereMerchantId || ""}
                            onChange={(e) =>
                              setSettings({ ...settings, payhereMerchantId: e.target.value })
                            }
                            className="h-9 text-xs font-mono"
                            placeholder="Enter PayHere Merchant ID"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">
                            Merchant Secret
                          </label>
                          <Input
                            type="password"
                            value={settings.payhereMerchantSecret || ""}
                            onChange={(e) =>
                              setSettings({ ...settings, payhereMerchantSecret: e.target.value })
                            }
                            className="h-9 text-xs font-mono"
                            placeholder="Enter PayHere Merchant Secret"
                          />
                        </div>
                      </CardContent>
                    </Card>

                    {/* SaaS Bank Account Settings */}
                    <Card className="bg-card/40 backdrop-blur-md border-border/60">
                      <CardContent className="p-6 space-y-4">
                        <div className="border-b border-border pb-2">
                          <h3 className="text-sm font-bold text-foreground flex items-center gap-2 font-mono">
                            <Landmark className="w-4 h-4 text-primary" /> Direct SaaS Bank Account Details
                          </h3>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            Bank details displayed to customers during manual Bank Transfer checkout.
                          </p>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-xs font-bold text-muted-foreground font-mono">
                              Bank Name *
                            </label>
                            <Input
                              value={bankSetting.bankName}
                              onChange={(e) =>
                                setBankSetting({ ...bankSetting, bankName: e.target.value })
                              }
                              className="h-9 text-xs"
                              required
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-xs font-bold text-muted-foreground font-mono">
                              Branch Name *
                            </label>
                            <Input
                              value={bankSetting.branchName}
                              onChange={(e) =>
                                setBankSetting({ ...bankSetting, branchName: e.target.value })
                              }
                              className="h-9 text-xs"
                              required
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-xs font-bold text-muted-foreground font-mono">
                              Beneficiary Account Name *
                            </label>
                            <Input
                              value={bankSetting.accountName}
                              onChange={(e) =>
                                setBankSetting({ ...bankSetting, accountName: e.target.value })
                              }
                              className="h-9 text-xs font-mono"
                              required
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-xs font-bold text-muted-foreground font-mono">
                              Account Number *
                            </label>
                            <Input
                              value={bankSetting.accountNumber}
                              onChange={(e) =>
                                setBankSetting({ ...bankSetting, accountNumber: e.target.value })
                              }
                              className="h-9 text-xs font-mono"
                              required
                            />
                          </div>
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">
                            SWIFT / IFSC / Bank Code
                          </label>
                          <Input
                            value={bankSetting.swiftCode || ""}
                            onChange={(e) =>
                              setBankSetting({ ...bankSetting, swiftCode: e.target.value })
                            }
                            className="h-9 text-xs font-mono"
                            placeholder="e.g. CCEYLKX"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">
                            Customer Instructions / Remark Note
                          </label>
                          <Input
                            value={bankSetting.instructions || ""}
                            onChange={(e) =>
                              setBankSetting({ ...bankSetting, instructions: e.target.value })
                            }
                            className="h-9 text-xs"
                            placeholder="e.g. Please include your Business Name and Invoice # in the deposit slip remark."
                          />
                        </div>
                      </CardContent>
                    </Card>

                    {/* Subscription Tax Rate */}
                    <Card className="bg-card/40 backdrop-blur-md border-border/60 md:col-span-2">
                      <CardContent className="p-6 space-y-4">
                        <div className="border-b border-border pb-2">
                          <h3 className="text-sm font-bold text-foreground flex items-center gap-2 font-mono">
                            <Zap className="w-4 h-4 text-primary" /> SaaS Tax & Billing Quotas
                          </h3>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            Automated taxation rates applied to all subscription invoices.
                          </p>
                        </div>

                        <div className="max-w-md space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">
                            Subscription Tax / GST Rate (%)
                          </label>
                          <div className="relative">
                            <Input
                              type="number"
                              step="0.1"
                              min={0}
                              max={100}
                              value={settings.subscriptionTaxRate}
                              onChange={(e) =>
                                setSettings({
                                  ...settings,
                                  subscriptionTaxRate: parseFloat(e.target.value) || 0,
                                })
                              }
                              className="h-9 text-xs font-mono pr-10"
                            />
                            <span className="absolute right-3 top-2.5 text-xs text-muted-foreground font-mono">
                              %
                            </span>
                          </div>
                          <p className="text-[11px] text-muted-foreground mt-1">
                            Applied automatically to plan checkouts (e.g. 18% GST/VAT).
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              )}

              {/* TAB 3: SMTP & EMAIL ALERTS */}
              {activeTab === "smtp" && (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="bg-card/40 backdrop-blur-md border-border/60">
                      <CardContent className="p-6 space-y-4">
                        <div className="flex items-center justify-between border-b border-border pb-2">
                          <div>
                            <h3 className="text-sm font-bold text-foreground flex items-center gap-2 font-mono">
                              <Mail className="w-4 h-4 text-primary" /> SMTP Server Credentials
                            </h3>
                            <p className="text-xs text-muted-foreground mt-0.5">
                              Outbound mail server configuration for dispatching system notifications.
                            </p>
                          </div>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => setIsTestEmailOpen(true)}
                            className="text-xs h-7 gap-1 font-bold"
                          >
                            <Send className="w-3 h-3 text-primary" /> Test SMTP
                          </Button>
                        </div>

                        {/* Quick Presets */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono">
                            Quick Provider Presets
                          </label>
                          <div className="grid grid-cols-3 gap-2">
                            <button
                              type="button"
                              onClick={() => applySmtpPreset("gmail")}
                              className="p-1.5 rounded border border-border text-[11px] font-mono hover:border-primary/50 text-foreground"
                            >
                              Gmail SMTP
                            </button>
                            <button
                              type="button"
                              onClick={() => applySmtpPreset("sendgrid")}
                              className="p-1.5 rounded border border-border text-[11px] font-mono hover:border-primary/50 text-foreground"
                            >
                              SendGrid
                            </button>
                            <button
                              type="button"
                              onClick={() => applySmtpPreset("ses")}
                              className="p-1.5 rounded border border-border text-[11px] font-mono hover:border-primary/50 text-foreground"
                            >
                              Amazon SES
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-3 gap-3">
                          <div className="col-span-2 space-y-1">
                            <label className="text-xs font-bold text-muted-foreground font-mono">
                              SMTP Host
                            </label>
                            <Input
                              value={settings.smtpHost || ""}
                              onChange={(e) =>
                                setSettings({ ...settings, smtpHost: e.target.value })
                              }
                              className="h-9 text-xs font-mono"
                              placeholder="smtp.gmail.com"
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-xs font-bold text-muted-foreground font-mono">
                              Port
                            </label>
                            <Input
                              type="number"
                              value={settings.smtpPort || 587}
                              onChange={(e) =>
                                setSettings({
                                  ...settings,
                                  smtpPort: parseInt(e.target.value) || 587,
                                })
                              }
                              className="h-9 text-xs font-mono"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-xs font-bold text-muted-foreground font-mono">
                              SMTP Username
                            </label>
                            <Input
                              value={settings.smtpUser || ""}
                              onChange={(e) =>
                                setSettings({ ...settings, smtpUser: e.target.value })
                              }
                              className="h-9 text-xs"
                              placeholder="user@domain.com"
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-xs font-bold text-muted-foreground font-mono">
                              SMTP Password / App Key
                            </label>
                            <Input
                              type="password"
                              value={settings.smtpPass || ""}
                              onChange={(e) =>
                                setSettings({ ...settings, smtpPass: e.target.value })
                              }
                              className="h-9 text-xs font-mono"
                              placeholder="••••••••••••"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-xs font-bold text-muted-foreground font-mono">
                              Sender Name
                            </label>
                            <Input
                              value={settings.smtpFromName || ""}
                              onChange={(e) =>
                                setSettings({ ...settings, smtpFromName: e.target.value })
                              }
                              className="h-9 text-xs"
                              placeholder="HKRION Cloud ERP"
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-xs font-bold text-muted-foreground font-mono">
                              From Email Address
                            </label>
                            <Input
                              value={settings.smtpFromEmail || ""}
                              onChange={(e) =>
                                setSettings({ ...settings, smtpFromEmail: e.target.value })
                              }
                              className="h-9 text-xs font-mono"
                              placeholder="noreply@hkrion.com"
                            />
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="bg-card/40 backdrop-blur-md border-border/60">
                      <CardContent className="p-6 space-y-4">
                        <div className="border-b border-border pb-2">
                          <h3 className="text-sm font-bold text-foreground flex items-center gap-2 font-mono">
                            <Sparkles className="w-4 h-4 text-primary" /> Automated Email Triggers
                          </h3>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            Configure which system events dispatch automatic email notifications.
                          </p>
                        </div>

                        <div className="space-y-3 pt-2">
                          <div className="flex items-center justify-between p-3 rounded-lg border border-border/60 bg-secondary/30">
                            <div>
                              <div className="text-xs font-bold text-foreground">
                                New Business Signup Alerts
                              </div>
                              <div className="text-[11px] text-muted-foreground">
                                Alert Super Admin via email whenever a new tenant registers.
                              </div>
                            </div>
                            <input
                              type="checkbox"
                              checked={settings.notifyOnNewTenant}
                              onChange={(e) =>
                                setSettings({ ...settings, notifyOnNewTenant: e.target.checked })
                              }
                              className="w-4 h-4 accent-primary rounded cursor-pointer"
                            />
                          </div>

                          <div className="flex items-center justify-between p-3 rounded-lg border border-border/60 bg-secondary/30">
                            <div>
                              <div className="text-xs font-bold text-foreground">
                                Bank Transfer Deposit Alerts
                              </div>
                              <div className="text-[11px] text-muted-foreground">
                                Notify Admin immediately when a customer uploads a payment slip.
                              </div>
                            </div>
                            <input
                              type="checkbox"
                              checked={settings.notifyOnBankTransfer}
                              onChange={(e) =>
                                setSettings({
                                  ...settings,
                                  notifyOnBankTransfer: e.target.checked,
                                })
                              }
                              className="w-4 h-4 accent-primary rounded cursor-pointer"
                            />
                          </div>

                          <div className="flex items-center justify-between p-3 rounded-lg border border-border/60 bg-secondary/30">
                            <div>
                              <div className="text-xs font-bold text-foreground">
                                Subscription Expiry Reminders
                              </div>
                              <div className="text-[11px] text-muted-foreground">
                                Send warning emails to tenants 3 days before their plan expires.
                              </div>
                            </div>
                            <input
                              type="checkbox"
                              checked={settings.notifyOnSubExpiry}
                              onChange={(e) =>
                                setSettings({ ...settings, notifyOnSubExpiry: e.target.checked })
                              }
                              className="w-4 h-4 accent-primary rounded cursor-pointer"
                            />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              )}

              {/* TAB 4: SMS GATEWAY */}
              {activeTab === "sms" && (
                <div className="max-w-2xl">
                  <Card className="bg-card/40 backdrop-blur-md border-border/60">
                    <CardContent className="p-6 space-y-4">
                      <div className="flex items-center justify-between border-b border-border pb-2">
                        <div>
                          <h3 className="text-sm font-bold text-foreground flex items-center gap-2 font-mono">
                            <MessageSquare className="w-4 h-4 text-primary" /> Global SMS Gateway
                          </h3>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            Connect your preferred SMS provider for OTPs and tenant alerts.
                          </p>
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => setIsTestSmsOpen(true)}
                          className="text-xs h-7 gap-1 font-bold"
                        >
                          <Send className="w-3 h-3 text-primary" /> Test SMS
                        </Button>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-muted-foreground font-mono">
                          SMS Provider Gateway
                        </label>
                        <select
                          value={settings.smsProvider || "custom_http"}
                          onChange={(e) =>
                            setSettings({ ...settings, smsProvider: e.target.value })
                          }
                          className="w-full h-9 px-3 text-xs rounded-md bg-secondary/50 border border-border text-foreground font-mono"
                        >
                          <option value="custom_http">Custom HTTP Gateway / Webhook</option>
                          <option value="dialog">Dialog eZ SMS Gateway</option>
                          <option value="mobitel">Mobitel mSMS Gateway</option>
                          <option value="textware">Textware / SendSMS.lk</option>
                          <option value="twilio">Twilio Global</option>
                        </select>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">
                            Sender Mask / ID
                          </label>
                          <Input
                            value={settings.smsSenderId || ""}
                            onChange={(e) =>
                              setSettings({ ...settings, smsSenderId: e.target.value })
                            }
                            className="h-9 text-xs font-mono"
                            placeholder="e.g. HKRION"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">
                            API Key / Auth Token
                          </label>
                          <Input
                            type="password"
                            value={settings.smsApiKey || ""}
                            onChange={(e) =>
                              setSettings({ ...settings, smsApiKey: e.target.value })
                            }
                            className="h-9 text-xs font-mono"
                            placeholder="••••••••••••"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-muted-foreground font-mono">
                          Gateway API Endpoint URL
                        </label>
                        <Input
                          value={settings.smsApiUrl || ""}
                          onChange={(e) =>
                            setSettings({ ...settings, smsApiUrl: e.target.value })
                          }
                          className="h-9 text-xs font-mono"
                          placeholder="https://api.sms-gateway.com/send"
                        />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* TAB 5: SECURITY & SYSTEM HEALTH */}
              {activeTab === "security" && (
                <div className="space-y-6">
                  {/* System Health Monitor */}
                  <Card className="bg-card/40 backdrop-blur-md border-border/60">
                    <CardContent className="p-6 space-y-4">
                      <div className="flex items-center justify-between border-b border-border pb-2">
                        <div>
                          <h3 className="text-sm font-bold text-foreground flex items-center gap-2 font-mono">
                            <Activity className="w-4 h-4 text-emerald-400" /> Live System Diagnostics & Server Health
                          </h3>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            Real-time memory allocation, server uptime, and database responsiveness.
                          </p>
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={loadHealth}
                          disabled={isHealthLoading}
                          className="text-xs h-7 gap-1 font-mono"
                        >
                          <RefreshCw
                            className={`w-3 h-3 ${isHealthLoading ? "animate-spin" : ""}`}
                          />{" "}
                          Refresh
                        </Button>
                      </div>

                      {healthData ? (
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-1">
                          <div className="p-3.5 rounded-xl border border-border/60 bg-background/50 space-y-1">
                            <div className="text-[10px] font-mono uppercase text-muted-foreground font-bold flex items-center gap-1.5">
                              <Server className="w-3.5 h-3.5 text-primary" /> Server Status
                            </div>
                            <div className="text-lg font-black text-emerald-400 font-mono">
                              {healthData.serverStatus}
                            </div>
                            <div className="text-[10px] text-muted-foreground font-mono">
                              Node.js {healthData.nodeVersion} ({healthData.platform})
                            </div>
                          </div>

                          <div className="p-3.5 rounded-xl border border-border/60 bg-background/50 space-y-1">
                            <div className="text-[10px] font-mono uppercase text-muted-foreground font-bold flex items-center gap-1.5">
                              <Clock className="w-3.5 h-3.5 text-amber-400" /> Server Uptime
                            </div>
                            <div className="text-lg font-black text-foreground font-mono">
                              {healthData.uptimeFormatted}
                            </div>
                            <div className="text-[10px] text-muted-foreground font-mono">
                              Continuous uptime
                            </div>
                          </div>

                          <div className="p-3.5 rounded-xl border border-border/60 bg-background/50 space-y-1">
                            <div className="text-[10px] font-mono uppercase text-muted-foreground font-bold flex items-center gap-1.5">
                              <Cpu className="w-3.5 h-3.5 text-blue-400" /> Memory (Heap Used)
                            </div>
                            <div className="text-lg font-black text-foreground font-mono">
                              {healthData.memory.heapUsedMb} MB
                            </div>
                            <div className="text-[10px] text-muted-foreground font-mono">
                              RSS: {healthData.memory.rssMb} MB
                            </div>
                          </div>

                          <div className="p-3.5 rounded-xl border border-border/60 bg-background/50 space-y-1">
                            <div className="text-[10px] font-mono uppercase text-muted-foreground font-bold flex items-center gap-1.5">
                              <Database className="w-3.5 h-3.5 text-emerald-400" /> PostgreSQL DB
                            </div>
                            <div className="text-lg font-black text-emerald-400 font-mono">
                              {healthData.databaseStatus}
                            </div>
                            <div className="text-[10px] text-muted-foreground font-mono">
                              {healthData.stats.totalTenants} Tenants | {healthData.stats.totalUsers} Users
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="p-4 text-center text-xs text-muted-foreground">
                          Loading server health metrics...
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Security & Access Controls */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="bg-card/40 backdrop-blur-md border-border/60">
                      <CardContent className="p-6 space-y-4">
                        <div className="border-b border-border pb-2">
                          <h3 className="text-sm font-bold text-foreground flex items-center gap-2 font-mono">
                            <Shield className="w-4 h-4 text-rose-400" /> Maintenance & Availability
                          </h3>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            Control system maintenance downtime and registration policies.
                          </p>
                        </div>

                        <div className="flex items-center justify-between p-3.5 rounded-xl border border-rose-500/30 bg-rose-500/5">
                          <div>
                            <div className="text-xs font-bold text-foreground">
                              Maintenance Mode
                            </div>
                            <div className="text-[11px] text-muted-foreground">
                              Temporarily locks tenant access showing maintenance banner.
                            </div>
                          </div>
                          <input
                            type="checkbox"
                            checked={settings.maintenanceMode}
                            onChange={(e) =>
                              setSettings({ ...settings, maintenanceMode: e.target.checked })
                            }
                            className="w-5 h-5 accent-rose-500 rounded cursor-pointer"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">
                            Maintenance Broadcast Message
                          </label>
                          <Input
                            value={settings.maintenanceMessage || ""}
                            onChange={(e) =>
                              setSettings({
                                ...settings,
                                maintenanceMessage: e.target.value,
                              })
                            }
                            className="h-9 text-xs"
                            placeholder="Maintenance explanation shown to tenants"
                          />
                        </div>

                        <div className="flex items-center justify-between p-3.5 rounded-xl border border-border/60 bg-secondary/30">
                          <div>
                            <div className="text-xs font-bold text-foreground">
                              Allow New Business Registrations
                            </div>
                            <div className="text-[11px] text-muted-foreground">
                              Toggle public signup capability on the login page.
                            </div>
                          </div>
                          <input
                            type="checkbox"
                            checked={settings.allowPublicSignups}
                            onChange={(e) =>
                              setSettings({
                                ...settings,
                                allowPublicSignups: e.target.checked,
                              })
                            }
                            className="w-5 h-5 accent-primary rounded cursor-pointer"
                          />
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="bg-card/40 backdrop-blur-md border-border/60">
                      <CardContent className="p-6 space-y-4">
                        <div className="border-b border-border pb-2">
                          <h3 className="text-sm font-bold text-foreground flex items-center gap-2 font-mono">
                            <Sparkles className="w-4 h-4 text-primary" /> Google Login OAuth Integration
                          </h3>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            Enable one-click Google Sign-In for all users across the platform.
                          </p>
                        </div>

                        <div className="flex items-center justify-between p-3.5 rounded-xl border border-border/60 bg-secondary/30">
                          <div>
                            <div className="text-xs font-bold text-foreground">
                              Enable Google OAuth Login
                            </div>
                            <div className="text-[11px] text-muted-foreground">
                              Allows login via Google Identity Services.
                            </div>
                          </div>
                          <input
                            type="checkbox"
                            checked={settings.enableGoogleAuth}
                            onChange={(e) =>
                              setSettings({
                                ...settings,
                                enableGoogleAuth: e.target.checked,
                              })
                            }
                            className="w-5 h-5 accent-primary rounded cursor-pointer"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">
                            Google Client ID
                          </label>
                          <Input
                            value={settings.googleClientId || ""}
                            onChange={(e) =>
                              setSettings({ ...settings, googleClientId: e.target.value })
                            }
                            className="h-9 text-xs font-mono"
                            placeholder="xxxx.apps.googleusercontent.com"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">
                            Google Client Secret
                          </label>
                          <Input
                            type="password"
                            value={settings.googleClientSecret || ""}
                            onChange={(e) =>
                              setSettings({
                                ...settings,
                                googleClientSecret: e.target.value,
                              })
                            }
                            className="h-9 text-xs font-mono"
                            placeholder="••••••••••••"
                          />
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              )}

              {/* TAB 6: AI COPILOT & OPENROUTER */}
              {activeTab === "ai" && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Left Column: Core OpenRouter Setup & Connectivity */}
                  <Card className="bg-card/40 backdrop-blur-md border-border/60">
                    <CardContent className="p-6 space-y-4">
                      <div className="border-b border-border pb-2">
                        <h3 className="text-sm font-bold text-foreground flex items-center gap-2 font-mono">
                          <Bot className="w-4 h-4 text-primary" /> OpenRouter API & Engine Configuration
                        </h3>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          Configure OpenRouter to power the HKRION ERP AI Copilot with multi-LLM support.
                        </p>
                      </div>

                      {/* Master Enable Switch */}
                      <div className="flex items-center justify-between p-3.5 rounded-xl border border-border/60 bg-secondary/30">
                        <div>
                          <div className="text-xs font-bold text-foreground flex items-center gap-1.5">
                            Enable AI Copilot Globally
                            {settings.enableAiAssistant && (
                              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                                ACTIVE
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-muted-foreground">
                            When enabled, the floating AI Copilot button appears for staff in dashboard and ERP pages.
                          </div>
                        </div>
                        <input
                          type="checkbox"
                          checked={settings.enableAiAssistant ?? false}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              enableAiAssistant: e.target.checked,
                            })
                          }
                          className="w-5 h-5 accent-primary rounded cursor-pointer"
                        />
                      </div>

                      {/* OpenRouter API Key */}
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <label className="text-xs font-bold text-muted-foreground font-mono flex items-center gap-1.5">
                            <Key className="w-3.5 h-3.5" /> OpenRouter API Key *
                          </label>
                          <a
                            href="https://openrouter.ai/keys"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[11px] text-primary hover:underline"
                          >
                            Get Key from OpenRouter.ai →
                          </a>
                        </div>
                        <div className="relative">
                          <Input
                            type={showApiKey ? "text" : "password"}
                            value={settings.openRouterApiKey || ""}
                            onChange={(e) =>
                              setSettings({
                                ...settings,
                                openRouterApiKey: e.target.value,
                              })
                            }
                            className="h-9 text-xs font-mono pr-10"
                            placeholder="sk-or-v1-xxxxxxxxxxxxxxxx"
                          />
                          <button
                            type="button"
                            onClick={() => setShowApiKey(!showApiKey)}
                            className="absolute right-2 top-2 text-muted-foreground hover:text-foreground"
                          >
                            {showApiKey ? (
                              <EyeOff className="w-4 h-4" />
                            ) : (
                              <Eye className="w-4 h-4" />
                            )}
                          </button>
                        </div>
                      </div>

                      {/* Model Selector & Presets */}
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-muted-foreground font-mono flex items-center gap-1.5">
                          <Cpu className="w-3.5 h-3.5" /> OpenRouter Model ID *
                        </label>
                        <Input
                          value={settings.openRouterModel || ""}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              openRouterModel: e.target.value,
                            })
                          }
                          className="h-9 text-xs font-mono"
                          placeholder="e.g. google/gemini-2.0-flash-exp:free"
                        />

                        {/* Quick Presets */}
                        <div className="space-y-1 pt-1">
                          <span className="text-[10px] uppercase font-bold text-muted-foreground font-mono">
                            Quick Model Presets:
                          </span>
                          <div className="flex flex-wrap gap-1.5">
                            {[
                              { label: "Gemini 2.0 Flash (Free)", value: "google/gemini-2.0-flash-exp:free" },
                              { label: "Llama 3.3 70B (Free)", value: "meta-llama/llama-3.3-70b-instruct:free" },
                              { label: "DeepSeek Chat (Budget)", value: "deepseek/deepseek-chat" },
                              { label: "GPT-4o Mini", value: "openai/gpt-4o-mini" },
                              { label: "Claude 3.5 Sonnet", value: "anthropic/claude-3.5-sonnet" },
                            ].map((preset) => (
                              <button
                                key={preset.value}
                                type="button"
                                onClick={() =>
                                  setSettings({
                                    ...settings,
                                    openRouterModel: preset.value,
                                  })
                                }
                                className={`px-2 py-1 text-[10px] rounded-md font-mono border transition-all ${
                                  settings.openRouterModel === preset.value
                                    ? "bg-primary/20 text-primary border-primary font-bold"
                                    : "bg-secondary/40 text-muted-foreground border-border hover:text-foreground"
                                }`}
                              >
                                {preset.label}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Test Connection Button & Result */}
                      <div className="pt-2 border-t border-border/60 space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-muted-foreground">
                            Verify OpenRouter connectivity:
                          </span>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            disabled={isTestingAi || !settings.openRouterApiKey}
                            onClick={handleTestAiConnection}
                            className="text-xs h-8 font-mono border-primary/40 text-primary hover:bg-primary/10"
                          >
                            {isTestingAi ? (
                              <>
                                <Loader2 className="w-3.5 h-3.5 animate-spin mr-1.5" /> Testing Ping...
                              </>
                            ) : (
                              <>
                                <Zap className="w-3.5 h-3.5 mr-1.5 text-amber-400" /> Test AI Connection
                              </>
                            )}
                          </Button>
                        </div>

                        {aiTestResult && (
                          <div
                            className={`p-3 rounded-xl border text-xs animate-fadeIn space-y-1 ${
                              aiTestResult.success
                                ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400"
                                : "bg-rose-500/10 border-rose-500/30 text-rose-400"
                            }`}
                          >
                            <div className="flex items-center gap-1.5 font-bold">
                              {aiTestResult.success ? (
                                <CheckCircle className="w-4 h-4 shrink-0" />
                              ) : (
                                <AlertTriangle className="w-4 h-4 shrink-0" />
                              )}
                              <span>{aiTestResult.message}</span>
                            </div>
                            {aiTestResult.reply && (
                              <div className="text-[11px] opacity-90 pl-5 italic font-mono">
                                Model response: &quot;{aiTestResult.reply}&quot;
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Right Column: AI Behavior, Persona & Role Permissions */}
                  <Card className="bg-card/40 backdrop-blur-md border-border/60">
                    <CardContent className="p-6 space-y-4">
                      <div className="border-b border-border pb-2">
                        <h3 className="text-sm font-bold text-foreground flex items-center gap-2 font-mono">
                          <Sliders className="w-4 h-4 text-primary" /> Copilot Persona & Parameters
                        </h3>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          Tailor the AI assistant behavior, token budgets, and ERP role access.
                        </p>
                      </div>

                      {/* Max Tokens and Temperature */}
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono flex items-center justify-between">
                            <span>Max Output Tokens</span>
                            <span className="text-[10px] text-emerald-400 font-normal">Cost Saver: 400-500</span>
                          </label>
                          <Input
                            type="number"
                            min={150}
                            max={2000}
                            step={50}
                            value={settings.aiMaxTokens ?? 500}
                            onChange={(e) =>
                              setSettings({
                                ...settings,
                                aiMaxTokens: parseInt(e.target.value, 10) || 500,
                              })
                            }
                            className="h-9 text-xs font-mono"
                          />
                          <div className="flex items-center gap-1 pt-0.5">
                            {[
                              { label: "300 (Fast)", val: 300 },
                              { label: "500 (Balanced)", val: 500 },
                              { label: "800 (Detailed)", val: 800 },
                            ].map((preset) => (
                              <button
                                key={preset.val}
                                type="button"
                                onClick={() =>
                                  setSettings({ ...settings, aiMaxTokens: preset.val })
                                }
                                className={`px-1.5 py-0.5 text-[9px] rounded font-mono border transition-all ${
                                  settings.aiMaxTokens === preset.val
                                    ? "bg-primary/20 text-primary border-primary font-bold"
                                    : "bg-secondary/40 text-muted-foreground border-border hover:text-foreground"
                                }`}
                              >
                                {preset.label}
                              </button>
                            ))}
                          </div>
                          <p className="text-[10px] text-muted-foreground pt-0.5">
                            Lower tokens drastically reduce OpenRouter costs and speed up response time.
                          </p>
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">
                            Temperature ({settings.aiTemperature ?? 0.7})
                          </label>
                          <Input
                            type="number"
                            min={0.0}
                            max={1.0}
                            step={0.1}
                            value={settings.aiTemperature ?? 0.7}
                            onChange={(e) =>
                              setSettings({
                                ...settings,
                                aiTemperature: parseFloat(e.target.value) || 0.7,
                              })
                            }
                            className="h-9 text-xs font-mono"
                          />
                          <p className="text-[10px] text-muted-foreground">
                            Lower = factual precision; Higher = creative phrasing.
                          </p>
                        </div>
                      </div>

                      {/* System Prompt / Persona */}
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-muted-foreground font-mono">
                          AI System Prompt & Instructions
                        </label>
                        <textarea
                          rows={6}
                          value={settings.aiSystemPrompt || ""}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              aiSystemPrompt: e.target.value,
                            })
                          }
                          className="w-full text-xs font-mono p-3 rounded-md bg-secondary/50 border border-border text-foreground focus:outline-none focus:ring-1 focus:ring-primary resize-none"
                          placeholder="You are HKRION ERP AI Copilot..."
                        />
                        <p className="text-[10px] text-muted-foreground">
                          Base personality prompt. Real-time ERP database facts (today&apos;s sales, stock levels) are injected automatically.
                        </p>
                      </div>

                      {/* Role Access Control */}
                      <div className="space-y-2 pt-2 border-t border-border/60">
                        <label className="text-xs font-bold text-muted-foreground font-mono">
                          Allowed User Roles
                        </label>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          {["SUPER_ADMIN", "ADMIN", "MANAGER", "CASHIER"].map((role) => {
                            const currentRoles = settings.aiAllowedRoles || [
                              "SUPER_ADMIN",
                              "ADMIN",
                              "MANAGER",
                              "CASHIER",
                            ];
                            const isChecked = currentRoles.includes(role);
                            return (
                              <label
                                key={role}
                                className="flex items-center gap-2 p-2 rounded-lg bg-secondary/30 border border-border/50 cursor-pointer hover:bg-secondary/50"
                              >
                                <input
                                  type="checkbox"
                                  checked={isChecked}
                                  onChange={(e) => {
                                    const nextRoles = e.target.checked
                                      ? [...currentRoles, role]
                                      : currentRoles.filter((r) => r !== role);
                                    setSettings({
                                      ...settings,
                                      aiAllowedRoles: nextRoles,
                                    });
                                  }}
                                  className="w-4 h-4 accent-primary rounded"
                                />
                                <span className="font-mono text-[11px]">{role}</span>
                              </label>
                            );
                          })}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </form>
          )}
        </main>
      </div>

      {/* Test Email Modal */}
      {isTestEmailOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="max-w-md w-full bg-card border border-border rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-border pb-2">
              <h3 className="text-sm font-bold text-foreground font-mono flex items-center gap-1.5">
                <Mail className="w-4 h-4 text-primary" /> Test SMTP Mail Dispatch
              </h3>
              <button
                onClick={() => {
                  setIsTestEmailOpen(false);
                  setTestEmailStatus(null);
                }}
                className="text-muted-foreground hover:text-foreground text-xs"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSendTestEmail} className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-muted-foreground font-mono">
                  Recipient Email Address *
                </label>
                <Input
                  type="email"
                  required
                  value={testEmailTo}
                  onChange={(e) => setTestEmailTo(e.target.value)}
                  placeholder="admin@example.com"
                  className="h-9 text-xs"
                />
              </div>

              {testEmailStatus && (
                <div
                  className={`p-3 rounded-lg text-xs font-mono ${
                    testEmailStatus.startsWith("Failed")
                      ? "bg-rose-500/10 border border-rose-500/20 text-rose-400"
                      : "bg-emerald-500/10 border border-emerald-500/20 text-emerald-400"
                  }`}
                >
                  {testEmailStatus}
                </div>
              )}

              <div className="flex justify-end gap-2 pt-2 border-t border-border">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setIsTestEmailOpen(false);
                    setTestEmailStatus(null);
                  }}
                  className="text-xs h-8"
                >
                  Close
                </Button>
                <Button
                  type="submit"
                  disabled={isSendingEmail || !testEmailTo}
                  size="sm"
                  className="text-xs h-8 font-bold"
                >
                  {isSendingEmail ? (
                    <>
                      <Loader2 className="w-3 h-3 animate-spin mr-1" /> Sending...
                    </>
                  ) : (
                    "Dispatch Email"
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Test SMS Modal */}
      {isTestSmsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="max-w-md w-full bg-card border border-border rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-border pb-2">
              <h3 className="text-sm font-bold text-foreground font-mono flex items-center gap-1.5">
                <MessageSquare className="w-4 h-4 text-primary" /> Test SMS Dispatch
              </h3>
              <button
                onClick={() => {
                  setIsTestSmsOpen(false);
                  setTestSmsStatus(null);
                }}
                className="text-muted-foreground hover:text-foreground text-xs"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSendTestSms} className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-muted-foreground font-mono">
                  Recipient Mobile Number *
                </label>
                <Input
                  required
                  value={testSmsNumber}
                  onChange={(e) => setTestSmsNumber(e.target.value)}
                  placeholder="+94 77 123 4567"
                  className="h-9 text-xs font-mono"
                />
              </div>

              {testSmsStatus && (
                <div
                  className={`p-3 rounded-lg text-xs font-mono ${
                    testSmsStatus.startsWith("Failed")
                      ? "bg-rose-500/10 border border-rose-500/20 text-rose-400"
                      : "bg-emerald-500/10 border border-emerald-500/20 text-emerald-400"
                  }`}
                >
                  {testSmsStatus}
                </div>
              )}

              <div className="flex justify-end gap-2 pt-2 border-t border-border">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setIsTestSmsOpen(false);
                    setTestSmsStatus(null);
                  }}
                  className="text-xs h-8"
                >
                  Close
                </Button>
                <Button
                  type="submit"
                  disabled={isSendingSms || !testSmsNumber}
                  size="sm"
                  className="text-xs h-8 font-bold"
                >
                  {isSendingSms ? (
                    <>
                      <Loader2 className="w-3 h-3 animate-spin mr-1" /> Sending...
                    </>
                  ) : (
                    "Dispatch SMS"
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
