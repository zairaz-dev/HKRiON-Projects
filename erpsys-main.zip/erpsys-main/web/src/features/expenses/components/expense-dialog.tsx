import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { X, Calendar, CreditCard, Loader2, Tag, Building2, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Dialog } from "@/components/ui/dialog";
import { User } from "@hkr/types";
import { expenseFormSchema, ExpenseFormSchema } from "../schema";
import { ExpenseItem } from "../types";
import { useCreateExpenseMutation, useUpdateExpenseMutation } from "../hooks/use-expenses";
import { useExpenseCategoriesQuery } from "@/features/expense-categories/hooks/use-expense-categories";
import { useBranchesQuery } from "@/features/expense-categories/hooks/use-expense-categories";
import { usePaymentMethodsQuery } from "@/features/payment-methods/hooks/use-payment-methods";

interface ExpenseDialogProps {
  isOpen: boolean;
  onClose: () => void;
  expense?: ExpenseItem | null;
  currentUser: User;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

export function ExpenseDialog({
  isOpen,
  onClose,
  expense,
  currentUser,
  onSuccess,
  onError,
}: ExpenseDialogProps) {
  const isEditMode = !!expense;
  const businessId = currentUser.businessId || "";

  const { data: categories = [] } = useExpenseCategoriesQuery(businessId);
  const { data: branches = [] } = useBranchesQuery(businessId, currentUser.id);
  const { data: paymentMethods = [] } = usePaymentMethodsQuery(businessId);

  const createMutation = useCreateExpenseMutation();
  const updateMutation = useUpdateExpenseMutation();

  const {
    register,
    handleSubmit,
    reset,
    watch,
    setValue,
    formState: { errors },
  } = useForm<ExpenseFormSchema>({
    resolver: zodResolver(expenseFormSchema),
    defaultValues: {
      amount: 0,
      expenseDate: new Date().toISOString().split("T")[0],
      paymentStatus: "PAID",
      amountPaid: 0,
      notes: "",
      attachmentUrl: "",
      categoryId: "",
      branchId: "",
      paymentMethodId: "",
    },
  });

  const watchAmount = watch("amount") || 0;
  const watchPaymentStatus = watch("paymentStatus");
  const watchCategoryId = watch("categoryId") || "";
  const watchBranchId = watch("branchId") || "";
  const watchPaymentMethodId = watch("paymentMethodId") || "";

  // Sync amountPaid based on paymentStatus and amount changes
  useEffect(() => {
    if (watchPaymentStatus === "PAID") {
      setValue("amountPaid", watchAmount, { shouldValidate: true });
    } else if (watchPaymentStatus === "DUE") {
      setValue("amountPaid", 0, { shouldValidate: true });
    }
  }, [watchAmount, watchPaymentStatus, setValue]);

  // Reset form with default or edited values
  useEffect(() => {
    if (expense) {
      reset({
        amount: expense.amount,
        expenseDate: new Date(expense.expenseDate).toISOString().split("T")[0],
        paymentStatus: expense.paymentStatus,
        amountPaid: expense.amountPaid,
        notes: expense.notes || "",
        attachmentUrl: expense.attachmentUrl || "",
        categoryId: expense.categoryId,
        branchId: expense.branchId,
        paymentMethodId: expense.payments?.[0]?.paymentMethod?.id || "",
      });
    } else {
      reset({
        amount: 0,
        expenseDate: new Date().toISOString().split("T")[0],
        paymentStatus: "PAID",
        amountPaid: 0,
        notes: "",
        attachmentUrl: "",
        categoryId: "",
        branchId: "",
        paymentMethodId: "",
      });
    }
  }, [expense, reset, isOpen]);

  const onSubmit = async (data: ExpenseFormSchema) => {
    const payload = {
      ...data,
      amountPaid: data.paymentStatus === "PAID" ? data.amount : data.amountPaid || 0,
      businessId,
      createdById: isEditMode ? undefined : currentUser.id,
      updatedById: isEditMode ? currentUser.id : undefined,
    };

    try {
      if (isEditMode && expense) {
        await updateMutation.mutateAsync({ id: expense.id, data: payload });
        onSuccess("Expense updated successfully!");
      } else {
        await createMutation.mutateAsync(payload);
        onSuccess("Expense created successfully!");
      }
      onClose();
    } catch (err: any) {
      onError(err.message || "Failed to save expense.");
    }
  };

  const isLoading = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog
      isOpen={isOpen}
      onClose={onClose}
      size="lg"
      title={
        <>
          <CreditCard className="h-5 w-5 text-primary" />
          {isEditMode ? "Edit Expense" : "Add Expense"}
        </>
      }
    >
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        {/* Category Selection */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-muted-foreground flex items-center gap-1.5">
            <Tag className="h-3.5 w-3.5" /> Category <span className="text-destructive">*</span>
          </label>
          <Select
            {...register("categoryId")}
            value={watchCategoryId}
            onValueChange={(val) => setValue("categoryId", val, { shouldValidate: true })}
            showSearch={true}
            icon={<Tag className="h-3.5 w-3.5 text-muted-foreground" />}
          >
            <option value="">Select Category</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </Select>
          {errors.categoryId && (
            <span className="text-[10px] text-destructive flex items-center gap-1">
              <AlertCircle className="h-3 w-3" /> {errors.categoryId.message}
            </span>
          )}
        </div>

        {/* Branch Selection */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-muted-foreground flex items-center gap-1.5">
            <Building2 className="h-3.5 w-3.5" /> Branch <span className="text-destructive">*</span>
          </label>
          <Select
            {...register("branchId")}
            value={watchBranchId}
            onValueChange={(val) => setValue("branchId", val, { shouldValidate: true })}
            showSearch={true}
            icon={<Building2 className="h-3.5 w-3.5 text-muted-foreground" />}
          >
            <option value="">Select Branch</option>
            {branches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </Select>
          {errors.branchId && (
            <span className="text-[10px] text-destructive flex items-center gap-1">
              <AlertCircle className="h-3 w-3" /> {errors.branchId.message}
            </span>
          )}
        </div>

        <div className="grid grid-cols-2 gap-4">
          {/* Amount */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              Total Amount <span className="text-destructive">*</span>
            </label>
            <Input
              type="number"
              step="0.01"
              placeholder="0.00"
              {...register("amount", { valueAsNumber: true })}
              className="h-9 text-xs"
            />
            {errors.amount && (
              <span className="text-[10px] text-destructive flex items-center gap-1">
                <AlertCircle className="h-3 w-3" /> {errors.amount.message}
              </span>
            )}
          </div>

          {/* Date */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground flex items-center gap-1.5">
              <Calendar className="h-3.5 w-3.5" /> Date <span className="text-destructive">*</span>
            </label>
            <Input
              type="date"
              {...register("expenseDate")}
              className="h-9 text-xs"
            />
            {errors.expenseDate && (
              <span className="text-[10px] text-destructive flex items-center gap-1">
                <AlertCircle className="h-3 w-3" /> {errors.expenseDate.message}
              </span>
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {/* Payment Status */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              Payment Status <span className="text-destructive">*</span>
            </label>
            <Select
              {...register("paymentStatus")}
              value={watchPaymentStatus}
              onValueChange={(val) => setValue("paymentStatus", val as any, { shouldValidate: true })}
            >
              <option value="PAID">Paid</option>
              <option value="PARTIAL">Partial</option>
              <option value="DUE">Due</option>
            </Select>
          </div>

          {/* Payment Method - only for Paid/Partial */}
          {watchPaymentStatus !== "DUE" && (
            <div className="space-y-1.5 animate-in fade-in slide-in-from-top-1 duration-150">
              <label className="text-xs font-semibold text-muted-foreground">
                Payment Method
              </label>
              <Select
                {...register("paymentMethodId")}
                value={watchPaymentMethodId}
                onValueChange={(val) => setValue("paymentMethodId", val, { shouldValidate: true })}
                icon={<CreditCard className="h-3.5 w-3.5 text-muted-foreground" />}
              >
                <option value="">Select Method</option>
                {paymentMethods.map((pm) => (
                  <option key={pm.id} value={pm.id}>
                    {pm.name}
                  </option>
                ))}
              </Select>
            </div>
          )}
        </div>

        {/* Paid Amount */}
        <div className="space-y-1.5 animate-in fade-in duration-150">
          <label className="text-xs font-semibold text-muted-foreground">
            Paid Amount <span className="text-destructive">*</span>
          </label>
          <Input
            type="number"
            step="0.01"
            placeholder="0.00"
            disabled={watchPaymentStatus !== "PARTIAL"}
            {...register("amountPaid", { valueAsNumber: true })}
            className="h-9 text-xs disabled:bg-muted/30 disabled:text-muted-foreground/60 disabled:cursor-not-allowed"
          />
          {errors.amountPaid && (
            <span className="text-[10px] text-destructive flex items-center gap-1">
              <AlertCircle className="h-3 w-3" /> {errors.amountPaid.message}
            </span>
          )}
        </div>

        {/* Notes */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-muted-foreground">Notes</label>
          <textarea
            {...register("notes")}
            rows={3}
            placeholder="Enter notes/description..."
            className="w-full rounded-md border border-input bg-background px-3 py-2 text-xs shadow-sm focus:outline-none focus:ring-1 focus:ring-ring resize-none"
          />
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end space-x-3 pt-3 border-t border-border/50">
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
            disabled={isLoading}
            className="h-9 text-xs"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={isLoading}
            className="h-9 text-xs flex items-center gap-1.5"
          >
            {isLoading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            {isEditMode ? "Save Changes" : "Create Expense"}
          </Button>
        </div>
      </form>
    </Dialog>
  );
}
