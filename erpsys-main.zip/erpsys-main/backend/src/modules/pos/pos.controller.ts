import { Controller, Post, Put, Body, Get, Param, Query, UseGuards, Delete, Req } from '@nestjs/common';
import { PosService } from './pos.service';
import { CreateInvoiceDto } from './dto/create-invoice.dto';
import { UpdateSaleDto } from './dto/update-sale.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';
import { ApiBody, ApiResponse } from '@nestjs/swagger';
import { CheckoutBodySchema, CustomerAdvanceBodySchema, AddSalePaymentBodySchema, PosResponseSchema } from '../../docs/pos.docs';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('pos')
export class PosController {
  constructor(private readonly posService: PosService) {}

  @Permissions(Permission.SALE_CREATE)
  @Post('checkout')
  @ApiBody({ schema: CheckoutBodySchema })
  @ApiResponse({ status: 201, description: 'Checkout completed and invoice generated successfully', schema: PosResponseSchema })
  async checkout(@Req() req: any, @Body() dto: CreateInvoiceDto) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      dto.businessId = user.businessId;
    }
    if (!dto.createdById) {
      dto.createdById = user.id;
    }
    return this.posService.checkout(dto);
  }

  @Permissions(Permission.SALE_VIEW)
  @Get('sales')
  async getSales(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
    @Query('customerId') customerId?: string,
    @Query('status') status?: 'HOLD' | 'DRAFT' | 'FINAL',
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('search') search?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.posService.getSales(bId, {
      branchId,
      customerId,
      status,
      page: page ? Number(page) : undefined,
      limit: limit ? Number(limit) : undefined,
      search,
      userId: user.id,
      userRole: user.role,
    });
  }

  @Permissions(Permission.SALE_VIEW)
  @Get('sales/:id')
  async getSaleById(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    const branchIds = user?.branches?.map((b: any) => b.branchId || b.id) || [];
    return this.posService.getSaleById(id, bId, { userId: user?.id, userRole: user?.role, branchIds });
  }

  @Permissions(Permission.SALE_CREATE)
  @Post('advances')
  @ApiBody({ schema: CustomerAdvanceBodySchema })
  @ApiResponse({ status: 201, description: 'Customer advance added successfully' })
  async addCustomerAdvance(
    @Req() req: any,
    @Body() body: {
      customerId: string;
      amount: number;
      paymentMethodId: string;
      transactionNo?: string;
      notes?: string;
      branchId: string;
      businessId: string;
      createdById?: string;
    },
  ) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }
    if (!body.createdById) {
      body.createdById = user.id;
    }
    return this.posService.addCustomerAdvance(body);
  }

  @Permissions(Permission.SALE_VIEW)
  @Get('advances/:customerId')
  async getCustomerAdvances(
    @Req() req: any,
    @Param('customerId') customerId: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.posService.getCustomerAdvances(customerId, bId);
  }

  @Permissions(Permission.SALE_CREATE)
  @Delete('sales/:id')
  async deleteSale(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.posService.deleteSale(id, bId);
  }

  @Permissions(Permission.SALE_CREATE)
  @Put('sales/:id')
  async updateSale(
    @Req() req: any,
    @Param('id') id: string,
    @Body() dto: UpdateSaleDto,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.posService.updateSale(id, bId, dto);
  }

  @Permissions(Permission.SALE_CREATE)
  @Post('sales/:id/payments')
  @ApiBody({ schema: AddSalePaymentBodySchema })
  @ApiResponse({ status: 201, description: 'Sale payment added successfully' })
  async addSalePayment(
    @Req() req: any,
    @Param('id') saleId: string,
    @Body() body: {
      amount: number;
      paymentMethodId: string;
      transactionNo?: string;
      notes?: string;
      businessId: string;
      createdById?: string;
    },
  ) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }
    if (!body.createdById) {
      body.createdById = user.id;
    }
    return this.posService.addSalePayment(saleId, body);
  }

  @Permissions(Permission.SALE_VIEW)
  @Get('sales/:id/payments')
  async getSalePayments(
    @Req() req: any,
    @Param('id') saleId: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.posService.getSalePayments(saleId, bId);
  }

  @Permissions(Permission.SALE_CREATE)
  @Delete('payments/:paymentId')
  async deleteSalePayment(
    @Req() req: any,
    @Param('paymentId') paymentId: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.posService.deleteSalePayment(paymentId, bId);
  }
}

