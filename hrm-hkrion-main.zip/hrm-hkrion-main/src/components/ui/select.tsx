"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import { Check, ChevronDown, Search, X } from "lucide-react";

export interface SelectOption {
  value: string;
  label: string;
  icon?: React.ReactNode;
  badge?: string;
  description?: string;
  disabled?: boolean;
}

interface SelectContextValue {
  value: string;
  onValueChange: (val: string) => void;
  isOpen: boolean;
  setIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  triggerRef: React.RefObject<HTMLButtonElement | null>;
  selectedLabel: string | null;
  setSelectedLabel: React.Dispatch<React.SetStateAction<string | null>>;
  disabled?: boolean;
}

const SelectContext = React.createContext<SelectContextValue | null>(null);

export function useSelect() {
  const context = React.useContext(SelectContext);
  if (!context) {
    throw new Error("Select compound components must be used within <Select />");
  }
  return context;
}

export interface SelectProps {
  value?: string;
  defaultValue?: string;
  onValueChange?: (val: string) => void;
  onChange?: (e: { target: { name?: string; value: string } }) => void;
  name?: string;
  disabled?: boolean;
  required?: boolean;
  placeholder?: string;
  options?: SelectOption[];
  className?: string;
  size?: "default" | "sm";
  searchable?: boolean;
  children?: React.ReactNode;
}

export function Select({
  value: controlledValue,
  defaultValue = "",
  onValueChange,
  onChange,
  name,
  disabled = false,
  required = false,
  placeholder = "Select an option...",
  options,
  className,
  size = "default",
  searchable = false,
  children,
}: SelectProps) {
  const [uncontrolledValue, setUncontrolledValue] = React.useState(defaultValue);
  const [isOpen, setIsOpen] = React.useState(false);
  const [selectedLabel, setSelectedLabel] = React.useState<string | null>(null);
  const triggerRef = React.useRef<HTMLButtonElement>(null);

  const isControlled = controlledValue !== undefined;
  const currentValue = isControlled ? controlledValue : uncontrolledValue;

  const handleValueChange = React.useCallback(
    (newVal: string) => {
      if (!isControlled) {
        setUncontrolledValue(newVal);
      }
      onValueChange?.(newVal);
      if (onChange) {
        onChange({ target: { name, value: newVal } });
      }
    },
    [isControlled, name, onChange, onValueChange]
  );

  // If simple `options` array is provided, render shorthand UI
  if (options) {
    const selectedOption = options.find((o) => o.value === currentValue);
    const displayLabel = selectedOption?.label || selectedLabel || placeholder;
    const hasValue = !!selectedOption || (currentValue !== "" && currentValue !== undefined);

    return (
      <SelectContext.Provider
        value={{
          value: currentValue,
          onValueChange: handleValueChange,
          isOpen,
          setIsOpen,
          triggerRef,
          selectedLabel,
          setSelectedLabel,
          disabled,
        }}
      >
        <div className={cn("relative inline-block w-full text-left", className)}>
          {name && (
            <input
              type="hidden"
              name={name}
              value={currentValue}
              required={required}
            />
          )}

          <SelectTrigger
            ref={triggerRef}
            disabled={disabled}
            size={size}
            className={className}
          >
            <span className="flex items-center gap-2 truncate">
              {selectedOption?.icon && (
                <span className="shrink-0 text-text-muted">{selectedOption.icon}</span>
              )}
              <span className={cn("truncate", !hasValue && "text-text-muted font-normal")}>
                {displayLabel}
              </span>
              {selectedOption?.badge && (
                <span className="ml-1.5 px-1.5 py-0.2 rounded text-[10px] font-semibold bg-surface-secondary text-text-secondary border border-border">
                  {selectedOption.badge}
                </span>
              )}
            </span>
          </SelectTrigger>

          <SelectContent searchable={searchable || options.length > 8}>
            {options.map((opt) => (
              <SelectItem
                key={opt.value}
                value={opt.value}
                disabled={opt.disabled}
                badge={opt.badge}
                description={opt.description}
                icon={opt.icon}
              >
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </div>
      </SelectContext.Provider>
    );
  }

  // Compound component mode
  return (
    <SelectContext.Provider
      value={{
        value: currentValue,
        onValueChange: handleValueChange,
        isOpen,
        setIsOpen,
        triggerRef,
        selectedLabel,
        setSelectedLabel,
        disabled,
      }}
    >
      <div className={cn("relative inline-block w-full text-left", className)}>
        {name && (
          <input
            type="hidden"
            name={name}
            value={currentValue}
            required={required}
          />
        )}
        {children}
      </div>
    </SelectContext.Provider>
  );
}

export interface SelectTriggerProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  size?: "default" | "sm";
  error?: boolean;
}

export const SelectTrigger = React.forwardRef<HTMLButtonElement, SelectTriggerProps>(
  ({ className, children, size = "default", error = false, disabled, ...props }, ref) => {
    const { isOpen, setIsOpen, disabled: contextDisabled } = useSelect();
    const isDisabled = disabled || contextDisabled;

    return (
      <button
        ref={ref}
        type="button"
        disabled={isDisabled}
        aria-expanded={isOpen}
        onClick={() => !isDisabled && setIsOpen(!isOpen)}
        className={cn(
          "flex w-full items-center justify-between gap-2 rounded-[8px] border border-border bg-surface px-3 py-2 text-sm text-text-primary transition-all duration-150 outline-none select-none cursor-pointer text-left hover:border-border-strong hover:bg-surface-secondary/40 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary disabled:cursor-not-allowed disabled:opacity-50",
          size === "sm" ? "h-9 text-xs px-2.5" : "h-10",
          error && "border-error focus:ring-error/20 focus:border-error",
          isOpen && "border-primary ring-2 ring-primary/20 bg-surface",
          className
        )}
        {...props}
      >
        <div className="flex-1 truncate">{children}</div>
        <ChevronDown
          className={cn(
            "h-4 w-4 shrink-0 text-text-muted transition-transform duration-200",
            isOpen && "rotate-180 text-primary"
          )}
        />
      </button>
    );
  }
);
SelectTrigger.displayName = "SelectTrigger";

export function SelectValue({ placeholder = "Select...", className }: { placeholder?: string; className?: string }) {
  const { value, selectedLabel } = useSelect();
  const display = selectedLabel || value;
  return (
    <span className={cn("truncate block", !display && "text-text-muted font-normal", className)}>
      {display || placeholder}
    </span>
  );
}

export interface SelectContentProps extends React.HTMLAttributes<HTMLDivElement> {
  searchable?: boolean;
  align?: "start" | "center" | "end";
  maxHeight?: number | string;
}

export const SelectContent = React.forwardRef<HTMLDivElement, SelectContentProps>(
  ({ className, children, searchable = false, align = "start", maxHeight = 280, ...props }, ref) => {
    const { isOpen, setIsOpen, triggerRef } = useSelect();
    const contentRef = React.useRef<HTMLDivElement>(null);
    const [search, setSearch] = React.useState("");

    React.useEffect(() => {
      function handleClickOutside(event: MouseEvent) {
        if (
          triggerRef.current &&
          !triggerRef.current.contains(event.target as Node) &&
          contentRef.current &&
          !contentRef.current.contains(event.target as Node)
        ) {
          setIsOpen(false);
        }
      }

      function handleKeyDown(event: KeyboardEvent) {
        if (event.key === "Escape") {
          setIsOpen(false);
        }
      }

      if (isOpen) {
        document.addEventListener("mousedown", handleClickOutside);
        document.addEventListener("keydown", handleKeyDown);
      }

      return () => {
        document.removeEventListener("mousedown", handleClickOutside);
        document.removeEventListener("keydown", handleKeyDown);
      };
    }, [isOpen, setIsOpen, triggerRef]);

    // Reset search on close
    React.useEffect(() => {
      if (!isOpen) setSearch("");
    }, [isOpen]);

    return (
      <AnimatePresence>
        {isOpen && (
          <motion.div
            ref={contentRef}
            initial={{ opacity: 0, scale: 0.96, y: -4 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -4 }}
            transition={{ duration: 0.15, ease: "easeOut" }}
            className={cn(
              "absolute z-50 mt-1.5 w-full min-w-[160px] rounded-xl border border-border bg-surface/98 p-1 text-text-primary shadow-[0_12px_36px_rgba(0,0,0,0.12),0_4px_12px_rgba(0,0,0,0.06)] backdrop-blur-md dark:shadow-[0_12px_40px_rgba(0,0,0,0.6)] focus:outline-none overflow-hidden",
              align === "end" ? "right-0" : "left-0",
              className
            )}
            {...(props as any)}
          >
            {searchable && (
              <div className="p-1.5 border-b border-border mb-1">
                <div className="relative">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-text-muted" />
                  <input
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search options..."
                    className="w-full pl-8 pr-6 py-1 text-xs bg-surface-secondary rounded-md border-0 text-text-primary placeholder:text-text-muted focus:ring-1 focus:ring-primary focus:outline-none"
                    autoFocus
                  />
                  {search && (
                    <button
                      type="button"
                      onClick={() => setSearch("")}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  )}
                </div>
              </div>
            )}

            <div
              style={{ maxHeight }}
              className="overflow-y-auto space-y-0.5 custom-scrollbar p-0.5"
            >
              {children}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    );
  }
);
SelectContent.displayName = "SelectContent";

export interface SelectItemProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  value: string;
  icon?: React.ReactNode;
  badge?: string;
  description?: string;
}

export const SelectItem = React.forwardRef<HTMLButtonElement, SelectItemProps>(
  ({ className, children, value: itemValue, icon, badge, description, disabled, onClick, ...props }, ref) => {
    const { value, onValueChange, setIsOpen, setSelectedLabel } = useSelect();
    const isSelected = value === itemValue;

    const handleSelect = (e: React.MouseEvent<HTMLButtonElement>) => {
      if (disabled) return;
      onClick?.(e);
      onValueChange(itemValue);
      if (typeof children === "string") {
        setSelectedLabel(children);
      }
      setIsOpen(false);
    };

    return (
      <button
        ref={ref}
        type="button"
        role="option"
        aria-selected={isSelected}
        disabled={disabled}
        onClick={handleSelect}
        className={cn(
          "relative flex w-full cursor-pointer select-none items-center justify-between rounded-lg px-2.5 py-1.5 text-xs font-medium outline-none transition-colors duration-100 disabled:pointer-events-none disabled:opacity-40 text-left",
          isSelected
            ? "bg-primary-soft text-primary font-semibold"
            : "text-text-primary hover:bg-surface-secondary hover:text-text-primary focus:bg-surface-secondary",
          className
        )}
        {...props}
      >
        <div className="flex items-center gap-2 min-w-0 flex-1">
          {icon && <span className="shrink-0 text-text-muted">{icon}</span>}
          <div className="truncate">
            <span className="block truncate">{children}</span>
            {description && (
              <span className="block text-[10px] text-text-muted font-normal truncate">
                {description}
              </span>
            )}
          </div>
          {badge && (
            <span className="ml-1.5 px-1.5 py-0.2 rounded text-[10px] font-semibold bg-surface-secondary text-text-secondary border border-border shrink-0">
              {badge}
            </span>
          )}
        </div>

        <div className="ml-2 shrink-0">
          {isSelected && (
            <Check className="h-3.5 w-3.5 text-primary stroke-[2.5]" />
          )}
        </div>
      </button>
    );
  }
);
SelectItem.displayName = "SelectItem";

export function SelectLabel({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-text-muted", className)}
      {...props}
    >
      {children}
    </div>
  );
}

export function SelectSeparator({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("-mx-1 my-1 h-px bg-border", className)} {...props} />;
}
