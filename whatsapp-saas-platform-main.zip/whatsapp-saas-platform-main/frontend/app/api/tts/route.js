import { NextResponse } from 'next/server';
import { synthesizeSpeech } from '@/lib/voiceService';

export async function POST(req) {
  try {
    const { text, apiKey, voice, provider } = await req.json();

    if (!text) {
      return NextResponse.json({ error: 'Text is required' }, { status: 400 });
    }

    const audioDataUrl = await synthesizeSpeech({
      text,
      apiKey: apiKey || process.env.OPENAI_API_KEY || '',
      voice: voice || 'nova',
      provider: provider || 'free_google',
    });

    return NextResponse.json({ success: true, audio: audioDataUrl });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
