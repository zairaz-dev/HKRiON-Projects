import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { UpgradeSubscriptionDto } from './dto/upgrade-subscription.dto';
import { UpdateSubscriptionStatusDto } from './dto/update-status.dto';
import { SubmitBankTransferDto } from './dto/submit-bank-transfer.dto';
import { UpdateSaasBankSettingDto } from './dto/update-bank-setting.dto';
import { BillingInterval, SubscriptionStatus, SubPaymentStatus } from '@prisma/client';
import * as crypto from 'crypto';

@Injectable()
export class SubscriptionsService {
  constructor(private readonly prisma: PrismaService) {}

  private async getPlatformSettings() {
    const settings = await this.prisma.superPlatformSetting.findFirst();
    const taxRate = settings?.subscriptionTaxRate ? settings.subscriptionTaxRate / 100 : 0.18;
    const merchantId = (settings?.payhereMerchantId || process.env.PAYHERE_MERCHANT_ID || '1230179').trim();
    const merchantSecret = (settings?.payhereMerchantSecret || process.env.PAYHERE_MERCHANT_SECRET || 'ODk1MjE0NzUzMzk3MjYzODk1MTE2MTA3MjUxOTQxOTg0NDYxMDc0').trim();
    const isSandbox = (settings?.payhereMode || process.env.PAYHERE_MODE || 'sandbox') !== 'live';
    return { settings, taxRate, merchantId, merchantSecret, isSandbox };
  }

  async assignTrialSubscription(businessId: string, tx?: any) {
    const prismaClient = tx || this.prisma;

    // Check if subscription already exists
    const existing = await prismaClient.subscription.findUnique({
      where: { businessId },
    });
    if (existing) return existing;

    let trialPlan = await prismaClient.plan.findUnique({
      where: { slug: 'trial' },
    });

    if (!trialPlan) {
      trialPlan = await prismaClient.plan.findFirst({
        where: { isActive: true },
        orderBy: { sortOrder: 'asc' },
      });
    }

    if (!trialPlan) {
      throw new NotFoundException('No available subscription plans found to assign');
    }

    const trialDays = trialPlan.trialDays || 14;
    const startDate = new Date();
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + trialDays);

    return prismaClient.subscription.create({
      data: {
        businessId,
        planId: trialPlan.id,
        status: SubscriptionStatus.TRIAL,
        billingInterval: BillingInterval.MONTHLY,
        startDate,
        endDate,
        trialEndsAt: endDate,
        isAutoRenew: false,
      },
      include: {
        plan: true,
      },
    });
  }

  async getCurrentSubscription(businessId: string) {
    let sub = await this.prisma.subscription.findUnique({
      where: { businessId },
      include: {
        plan: true,
        invoices: {
          orderBy: { createdAt: 'desc' },
          take: 10,
        },
      },
    });

    // If no subscription found, auto-assign trial
    if (!sub) {
      sub = (await this.assignTrialSubscription(businessId)) as any;
    }

    // Check if subscription expired
    const now = new Date();
    if (sub && sub.endDate < now && sub.status !== SubscriptionStatus.EXPIRED && sub.status !== SubscriptionStatus.CANCELLED) {
      sub = await this.prisma.subscription.update({
        where: { id: sub.id },
        data: { status: SubscriptionStatus.EXPIRED },
        include: {
          plan: true,
          invoices: {
            orderBy: { createdAt: 'desc' },
            take: 10,
          },
        },
      });
    }

    // Calculate live usage statistics
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    const [branchesCount, usersCount, productsCount, monthlyInvoicesCount] = await Promise.all([
      this.prisma.branch.count({ where: { businessId } }),
      this.prisma.user.count({ where: { businessId } }),
      this.prisma.product.count({ where: { businessId } }),
      this.prisma.sale.count({
        where: {
          businessId,
          createdAt: { gte: startOfMonth },
        },
      }),
    ]);

    const plan = sub.plan;

    return {
      subscription: sub,
      plan,
      usage: {
        branches: {
          used: branchesCount,
          max: plan.maxBranches,
          percentage: plan.maxBranches === -1 ? 0 : Math.min(100, Math.round((branchesCount / plan.maxBranches) * 100)),
        },
        users: {
          used: usersCount,
          max: plan.maxUsers,
          percentage: plan.maxUsers === -1 ? 0 : Math.min(100, Math.round((usersCount / plan.maxUsers) * 100)),
        },
        products: {
          used: productsCount,
          max: plan.maxProducts,
          percentage: plan.maxProducts === -1 ? 0 : Math.min(100, Math.round((productsCount / plan.maxProducts) * 100)),
        },
        invoices: {
          used: monthlyInvoicesCount,
          max: plan.maxInvoicesMonthly,
          percentage: plan.maxInvoicesMonthly === -1 ? 0 : Math.min(100, Math.round((monthlyInvoicesCount / plan.maxInvoicesMonthly) * 100)),
        },
      },
      invoices: sub.invoices,
    };
  }

  async upgradePlan(businessId: string, dto: UpgradeSubscriptionDto) {
    const plan = await this.prisma.plan.findUnique({
      where: { id: dto.planId },
    });
    if (!plan || !plan.isActive) {
      throw new BadRequestException('Invalid or inactive plan selected');
    }

    let sub = await this.prisma.subscription.findUnique({
      where: { businessId },
    });

    if (!sub) {
      sub = (await this.assignTrialSubscription(businessId)) as any;
    }

    const { taxRate } = await this.getPlatformSettings();
    const price = dto.billingInterval === BillingInterval.YEARLY ? plan.priceYearly : plan.priceMonthly;
    const taxAmount = Number((price * taxRate).toFixed(2));
    const totalAmount = Number((price + taxAmount).toFixed(2));

    const now = new Date();
    // Calculate new end date (extend from current active end date if not expired, or start from today)
    const baseDate = sub && sub.endDate > now && sub.status === SubscriptionStatus.ACTIVE ? new Date(sub.endDate) : new Date(now);
    const newEndDate = new Date(baseDate);

    if (dto.billingInterval === BillingInterval.YEARLY) {
      newEndDate.setFullYear(newEndDate.getFullYear() + 1);
    } else {
      newEndDate.setMonth(newEndDate.getMonth() + 1);
    }

    const invoiceNumber = `SUB-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}-${Date.now().toString(36).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;

    return this.prisma.$transaction(async (tx) => {
      const updatedSub = await tx.subscription.update({
        where: { id: sub.id },
        data: {
          planId: plan.id,
          status: SubscriptionStatus.ACTIVE,
          billingInterval: dto.billingInterval,
          startDate: now,
          endDate: newEndDate,
          trialEndsAt: null,
          isAutoRenew: true,
        },
        include: {
          plan: true,
        },
      });

      const invoice = await tx.subscriptionInvoice.create({
        data: {
          invoiceNumber,
          subscriptionId: sub.id,
          businessId,
          planId: plan.id,
          billingInterval: dto.billingInterval,
          amount: price,
          taxAmount,
          totalAmount,
          currency: plan.currency || 'LKR',
          paymentStatus: SubPaymentStatus.PAID,
          paymentMethod: dto.paymentMethod || 'Super Admin Override',
          transactionId: dto.transactionId || `ADMIN-MANUAL-${Date.now().toString().slice(-6)}`,
          paidAt: now,
          notes: dto.notes || `Subscription upgraded to ${plan.name} (${dto.billingInterval}) by Super Admin`,
        },
      });

      return {
        subscription: updatedSub,
        invoice,
      };
    });
  }

  async getAllSubscriptions() {
    const subscriptions = await this.prisma.subscription.findMany({
      include: {
        business: {
          select: {
            id: true,
            name: true,
            phone: true,
            createdAt: true,
            users: {
              where: { role: { role: 'admin' } },
              select: { name: true, email: true },
              take: 1,
            },
          },
        },
        plan: true,
        invoices: {
          orderBy: { createdAt: 'desc' },
          take: 1,
        },
      },
      orderBy: { updatedAt: 'desc' },
    });

    return subscriptions.map((s) => ({
      id: s.id,
      businessId: s.businessId,
      businessName: s.business?.name || 'N/A',
      ownerName: s.business?.users[0]?.name || 'N/A',
      ownerEmail: s.business?.users[0]?.email || 'N/A',
      planName: s.plan.name,
      planSlug: s.plan.slug,
      status: s.status,
      billingInterval: s.billingInterval,
      startDate: s.startDate,
      endDate: s.endDate,
      trialEndsAt: s.trialEndsAt,
      latestInvoice: s.invoices[0] || null,
      createdAt: s.createdAt,
    }));
  }

  async updateSubscriptionStatus(id: string, dto: UpdateSubscriptionStatusDto) {
    const sub = await this.prisma.subscription.findUnique({ where: { id } });
    if (!sub) {
      throw new NotFoundException('Subscription not found');
    }

    const updateData: any = {
      status: dto.status,
    };
    if (dto.endDate) {
      updateData.endDate = new Date(dto.endDate);
    }
    if (dto.planId) {
      const plan = await this.prisma.plan.findUnique({ where: { id: dto.planId } });
      if (!plan) throw new BadRequestException('Selected plan not found');
      updateData.planId = dto.planId;
    }

    return this.prisma.subscription.update({
      where: { id },
      data: updateData,
      include: { plan: true, business: true },
    });
  }

  async generatePayHereParams(
    businessId: string,
    planId: string,
    billingInterval: BillingInterval,
    user: any,
    requestedCurrency?: string,
  ) {
    const plan = await this.prisma.plan.findUnique({ where: { id: planId } });
    if (!plan || !plan.isActive) {
      throw new BadRequestException('Invalid or inactive plan');
    }

    if (plan.isCustom && plan.businessId !== businessId) {
      throw new BadRequestException('This custom enterprise contract plan is not authorized for this business');
    }

    const business = await this.prisma.business.findUnique({ where: { id: businessId } });
    if (!business) {
      throw new NotFoundException('Business not found');
    }

    let sub = await this.prisma.subscription.findUnique({ where: { businessId } });
    if (!sub) {
      sub = (await this.assignTrialSubscription(businessId)) as any;
    }

    const { taxRate, merchantId, merchantSecret, isSandbox } = await this.getPlatformSettings();

    const currency = requestedCurrency?.toUpperCase() === 'USD' ? 'USD' : 'LKR';
    const price = currency === 'USD'
      ? (billingInterval === BillingInterval.YEARLY ? (plan.priceYearlyUsd || 0) : (plan.priceMonthlyUsd || 0))
      : (billingInterval === BillingInterval.YEARLY ? plan.priceYearly : plan.priceMonthly);

    const taxAmount = Number((price * taxRate).toFixed(2));
    const totalAmount = Number((price + taxAmount).toFixed(2));
    const formattedAmount = totalAmount.toFixed(2);

    const now = new Date();
    const invoiceNumber = `SUB-PH-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}-${Date.now().toString(36).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;

    // Clean up stale PENDING invoices older than 15 mins for this business
    await this.prisma.subscriptionInvoice.deleteMany({
      where: {
        businessId,
        paymentStatus: SubPaymentStatus.PENDING,
        createdAt: { lt: new Date(Date.now() - 15 * 60 * 1000) },
      },
    }).catch(() => {});

    // Create a PENDING invoice record with target plan & interval
    await this.prisma.subscriptionInvoice.create({
      data: {
        invoiceNumber,
        subscriptionId: sub!.id,
        businessId,
        planId: plan.id,
        billingInterval,
        amount: price,
        taxAmount,
        totalAmount,
        currency,
        paymentStatus: SubPaymentStatus.PENDING,
        paymentMethod: 'PayHere',
        notes: `Online PayHere Subscription to ${plan.name} (${billingInterval}) [${currency}]`,
      },
    });

    // PayHere MD5 signature calculation:
    // strtoupper(md5(merchant_id + order_id + amount_formatted + currency + strtoupper(md5(merchant_secret))))
    const hashedSecret = crypto.createHash('md5').update(merchantSecret).digest('hex').toUpperCase();
    const hashString = `${merchantId}${invoiceNumber}${formattedAmount}${currency}${hashedSecret}`;
    const hash = crypto.createHash('md5').update(hashString).digest('hex').toUpperCase();

    const nameParts = (user.name || 'Merchant User').split(' ');
    const firstName = nameParts[0] || 'Business';
    const lastName = nameParts.slice(1).join(' ') || 'Owner';

    return {
      sandbox: isSandbox,
      merchant_id: merchantId,
      return_url: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/settings/subscription?payment=success`,
      cancel_url: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/settings/subscription?payment=cancelled`,
      notify_url: `${process.env.BACKEND_URL || 'http://localhost:3000'}/subscriptions/payhere/notify`,
      order_id: invoiceNumber,
      items: `${plan.name} (${billingInterval})`,
      amount: formattedAmount,
      currency,
      hash,
      first_name: firstName,
      last_name: lastName,
      email: user.email || 'billing@example.com',
      phone: business.phone || '0771234567',
      address: 'Main Office',
      city: 'Colombo',
      country: 'Sri Lanka',
      delivery_address: 'Main Office',
      delivery_city: 'Colombo',
      delivery_country: 'Sri Lanka',
      custom_1: businessId,
      custom_2: plan.id,
    };
  }

  async processPayHereNotification(data: any) {
    const {
      merchant_id,
      order_id,
      payment_id,
      payhere_amount,
      payhere_currency,
      status_code,
      md5sig,
      custom_1: businessId,
      custom_2: planId,
      method,
    } = data;

    const { merchantSecret } = await this.getPlatformSettings();
    const hashedSecret = crypto.createHash('md5').update(merchantSecret).digest('hex').toUpperCase();
    const localHashString = `${merchant_id}${order_id}${payhere_amount}${payhere_currency}${status_code}${hashedSecret}`;
    const localMd5Sig = crypto.createHash('md5').update(localHashString).digest('hex').toUpperCase();

    // Verify Checksum
    if (localMd5Sig !== md5sig) {
      console.error('PayHere IPN Checksum verification failed!');
      throw new BadRequestException('Invalid checksum signature');
    }

    // status_code 2 means Success / Charged
    if (status_code === '2' || status_code === 2) {
      const invoice = await this.prisma.subscriptionInvoice.findUnique({
        where: { invoiceNumber: order_id },
        include: { plan: true, subscription: { include: { plan: true } } },
      });

      if (!invoice) {
        console.error(`Invoice ${order_id} not found in PayHere notification`);
        return { status: 'invoice_not_found' };
      }

      if (invoice.paymentStatus === SubPaymentStatus.PAID || (invoice.paymentStatus as string) === 'PAID') {
        console.log(`Invoice ${order_id} has already been processed and marked as PAID.`);
        return { status: 'already_processed' };
      }

      const targetPlanId = invoice.planId || planId || invoice.subscription.planId;
      const targetBillingInterval = invoice.billingInterval || invoice.subscription.billingInterval;
      const plan = await this.prisma.plan.findUnique({ where: { id: targetPlanId } });
      const sub = invoice.subscription;

      const now = new Date();
      const baseDate = sub && sub.endDate > now && sub.status === SubscriptionStatus.ACTIVE ? new Date(sub.endDate) : new Date(now);
      const newEndDate = new Date(baseDate);

      if (targetBillingInterval === BillingInterval.YEARLY) {
        newEndDate.setFullYear(newEndDate.getFullYear() + 1);
      } else {
        newEndDate.setMonth(newEndDate.getMonth() + 1);
      }

      await this.prisma.$transaction([
        this.prisma.subscription.update({
          where: { id: sub.id },
          data: {
            planId: targetPlanId,
            status: SubscriptionStatus.ACTIVE,
            billingInterval: targetBillingInterval,
            startDate: now,
            endDate: newEndDate,
            trialEndsAt: null,
            isAutoRenew: true,
          },
        }),
        this.prisma.subscriptionInvoice.update({
          where: { id: invoice.id },
          data: {
            paymentStatus: SubPaymentStatus.PAID,
            transactionId: payment_id || `PH-${Date.now()}`,
            paymentMethod: method ? `PayHere (${method})` : 'PayHere',
            currency: payhere_currency || invoice.currency || 'LKR',
            paidAt: now,
          },
        }),
      ]);

      console.log(`Subscription for business ${businessId || invoice.businessId} activated via PayHere!`);
    }

    return { status: 'ok' };
  }

  async completePayHereOrder(businessId: string, orderId: string, transactionId?: string) {
    let invoice = await this.prisma.subscriptionInvoice.findUnique({
      where: { invoiceNumber: orderId },
      include: { plan: true, subscription: { include: { plan: true } } },
    });

    if (!invoice) {
      throw new NotFoundException(`Invoice with number ${orderId} not found`);
    }

    if (invoice.businessId !== businessId) {
      throw new BadRequestException('Invoice does not belong to your business organization');
    }

    if (invoice.paymentStatus === SubPaymentStatus.PAID) {
      return { status: 'success', subscription: invoice.subscription, invoice };
    }

    // Wait up to 3 seconds for webhook (IPN) arrival
    for (let i = 0; i < 3; i++) {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      invoice = await this.prisma.subscriptionInvoice.findUnique({
        where: { invoiceNumber: orderId },
        include: { plan: true, subscription: { include: { plan: true } } },
      });
      if (invoice?.paymentStatus === SubPaymentStatus.PAID) {
        return { status: 'success', subscription: invoice.subscription, invoice };
      }
    }

    const { isSandbox } = await this.getPlatformSettings();
    if (process.env.NODE_ENV === 'development' && isSandbox) {
      // Local development fallback: simulate IPN activation only in sandbox dev mode
      console.warn(`[DEV SIMULATION] Simulating IPN activation for sandbox order: ${orderId}`);
      const targetPlanId = invoice.planId || invoice.subscription.planId;
      const targetBillingInterval = invoice.billingInterval || invoice.subscription.billingInterval;
      const sub = invoice.subscription;
      const now = new Date();
      const baseDate = sub && sub.endDate > now && sub.status === SubscriptionStatus.ACTIVE ? new Date(sub.endDate) : new Date(now);
      const newEndDate = new Date(baseDate);

      if (targetBillingInterval === BillingInterval.YEARLY) {
        newEndDate.setFullYear(newEndDate.getFullYear() + 1);
      } else {
        newEndDate.setMonth(newEndDate.getMonth() + 1);
      }

      const [updatedSub, updatedInvoice] = await this.prisma.$transaction([
        this.prisma.subscription.update({
          where: { id: sub.id },
          data: {
            planId: targetPlanId,
            status: SubscriptionStatus.ACTIVE,
            billingInterval: targetBillingInterval,
            startDate: now,
            endDate: newEndDate,
            trialEndsAt: null,
            isAutoRenew: true,
          },
        }),
        this.prisma.subscriptionInvoice.update({
          where: { id: invoice.id },
          data: {
            paymentStatus: SubPaymentStatus.PAID,
            transactionId: transactionId || `PH-DEV-${Date.now()}`,
            paymentMethod: 'PayHere (Dev Sandbox)',
            paidAt: now,
          },
        }),
      ]);

      return {
        status: 'success',
        subscription: updatedSub,
        invoice: updatedInvoice,
      };
    }

    return {
      status: 'pending',
      message: 'Payment verification from PayHere is currently pending confirmation.',
      invoice,
    };
  }

  // --- Bank Transfer & SaaS Bank Settings Management ---

  async getSaasBankConfig() {
    let config = await this.prisma.saasBankSetting.findFirst({
      where: { isActive: true },
      orderBy: { createdAt: 'desc' },
    });

    if (!config) {
      config = await this.prisma.saasBankSetting.create({
        data: {
          bankName: 'Commercial Bank of Ceylon',
          accountName: 'HKRION SYSTEMS PVT LTD',
          accountNumber: '800234567890',
          branchName: 'Colombo Corporate Branch',
          swiftCode: 'CCEYLKX',
          instructions: 'Please include your Business Name and Invoice # in the deposit slip/remark.',
          isActive: true,
        },
      });
    }

    return config;
  }

  async updateSaasBankConfig(dto: UpdateSaasBankSettingDto) {
    const existing = await this.prisma.saasBankSetting.findFirst({
      orderBy: { createdAt: 'desc' },
    });

    if (existing) {
      return this.prisma.saasBankSetting.update({
        where: { id: existing.id },
        data: { ...dto },
      });
    }

    return this.prisma.saasBankSetting.create({
      data: { ...dto },
    });
  }

  async submitBankTransfer(businessId: string, dto: SubmitBankTransferDto) {
    const plan = await this.prisma.plan.findUnique({ where: { id: dto.planId } });
    if (!plan || !plan.isActive) {
      throw new BadRequestException('Invalid or inactive plan');
    }

    if (plan.isCustom && plan.businessId !== businessId) {
      throw new BadRequestException('This custom enterprise contract plan is not authorized for this business');
    }

    const business = await this.prisma.business.findUnique({ where: { id: businessId } });
    if (!business) {
      throw new NotFoundException('Business not found');
    }

    let sub = await this.prisma.subscription.findUnique({ where: { businessId } });
    if (!sub) {
      sub = (await this.assignTrialSubscription(businessId)) as any;
    }

    const { taxRate } = await this.getPlatformSettings();
    const price = dto.billingInterval === BillingInterval.YEARLY ? plan.priceYearly : plan.priceMonthly;
    const taxAmount = Number((price * taxRate).toFixed(2));
    const totalAmount = Number((price + taxAmount).toFixed(2));

    const now = new Date();
    const invoiceNumber = `SUB-BT-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}-${Date.now().toString(36).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;

    // Clean up stale PENDING invoices older than 15 mins for this business
    await this.prisma.subscriptionInvoice.deleteMany({
      where: {
        businessId,
        paymentStatus: SubPaymentStatus.PENDING,
        createdAt: { lt: new Date(Date.now() - 15 * 60 * 1000) },
      },
    }).catch(() => {});

    const invoice = await this.prisma.subscriptionInvoice.create({
      data: {
        invoiceNumber,
        subscriptionId: sub!.id,
        businessId,
        planId: plan.id,
        billingInterval: dto.billingInterval,
        amount: price,
        taxAmount,
        totalAmount,
        currency: plan.currency || 'LKR',
        paymentStatus: SubPaymentStatus.PENDING,
        paymentMethod: 'Bank Transfer',
        transactionId: dto.transactionId,
        proofUrl: dto.proofUrl,
        notes: dto.notes || `Bank Transfer upgrade to ${plan.name} (${dto.billingInterval})`,
      },
    });

    return {
      message: 'Bank transfer deposit slip submitted. Awaiting Super Admin verification.',
      invoice,
    };
  }

  async getBankTransferRequests() {
    const invoices = await this.prisma.subscriptionInvoice.findMany({
      where: {
        paymentMethod: 'Bank Transfer',
      },
      include: {
        plan: true,
        subscription: {
          include: {
            plan: true,
            business: {
              select: {
                id: true,
                name: true,
                phone: true,
                users: {
                  take: 1,
                  select: { name: true, email: true },
                },
              },
            },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return invoices.map((inv: any) => ({
      id: inv.id,
      invoiceNumber: inv.invoiceNumber,
      businessId: inv.businessId,
      businessName: inv.subscription?.business?.name || 'N/A',
      businessPhone: inv.subscription?.business?.phone || 'N/A',
      businessEmail: inv.subscription?.business?.users?.[0]?.email || 'N/A',
      planName: inv.plan?.name || inv.subscription?.plan?.name || 'N/A',
      planId: inv.planId || inv.subscription?.planId,
      billingInterval: inv.billingInterval || inv.subscription?.billingInterval,
      currentPlanName: inv.subscription?.plan?.name,
      amount: inv.amount,
      taxAmount: inv.taxAmount,
      totalAmount: inv.totalAmount,
      currency: inv.currency,
      paymentStatus: inv.paymentStatus,
      paymentMethod: inv.paymentMethod,
      transactionId: inv.transactionId,
      proofUrl: inv.proofUrl,
      adminNotes: inv.adminNotes,
      paidAt: inv.paidAt,
      approvedAt: inv.approvedAt,
      createdAt: inv.createdAt,
    }));
  }

  async approveBankTransfer(invoiceId: string, adminUserId?: string) {
    const invoice = await this.prisma.subscriptionInvoice.findUnique({
      where: { id: invoiceId },
      include: { plan: true, subscription: { include: { plan: true } } },
    });

    if (!invoice) {
      throw new NotFoundException('Invoice record not found');
    }

    if (invoice.paymentStatus === SubPaymentStatus.PAID) {
      return { message: 'Invoice already approved and marked as paid', invoice };
    }

    const sub = invoice.subscription;
    const targetPlanId = invoice.planId || sub.planId;
    const targetBillingInterval = invoice.billingInterval || sub.billingInterval;

    const now = new Date();
    const baseDate = sub && sub.endDate > now && sub.status === SubscriptionStatus.ACTIVE ? new Date(sub.endDate) : new Date(now);
    const newEndDate = new Date(baseDate);

    if (targetBillingInterval === BillingInterval.YEARLY) {
      newEndDate.setFullYear(newEndDate.getFullYear() + 1);
    } else {
      newEndDate.setMonth(newEndDate.getMonth() + 1);
    }

    const [updatedSub, updatedInvoice] = await this.prisma.$transaction([
      this.prisma.subscription.update({
        where: { id: sub.id },
        data: {
          planId: targetPlanId,
          status: SubscriptionStatus.ACTIVE,
          billingInterval: targetBillingInterval,
          startDate: now,
          endDate: newEndDate,
          trialEndsAt: null,
          isAutoRenew: true,
        },
      }),
      this.prisma.subscriptionInvoice.update({
        where: { id: invoice.id },
        data: {
          paymentStatus: SubPaymentStatus.PAID,
          approvedAt: now,
          approvedById: adminUserId || null,
          paidAt: now,
          adminNotes: 'Approved by Super Admin',
        },
      }),
    ]);

    return {
      message: 'Bank transfer approved successfully. Subscription activated.',
      subscription: updatedSub,
      invoice: updatedInvoice,
    };
  }

  async rejectBankTransfer(invoiceId: string, reason: string, adminUserId?: string) {
    const invoice = await this.prisma.subscriptionInvoice.findUnique({
      where: { id: invoiceId },
    });

    if (!invoice) {
      throw new NotFoundException('Invoice record not found');
    }

    const updated = await this.prisma.subscriptionInvoice.update({
      where: { id: invoiceId },
      data: {
        paymentStatus: SubPaymentStatus.FAILED,
        adminNotes: reason || 'Rejected by Super Admin: Invalid deposit proof',
        approvedById: adminUserId || null,
      },
    });

    return {
      message: 'Bank transfer request rejected',
      invoice: updated,
    };
  }
}
