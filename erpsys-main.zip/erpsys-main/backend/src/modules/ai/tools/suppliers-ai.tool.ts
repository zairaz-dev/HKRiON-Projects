import { Injectable, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class SuppliersAiTool {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Get supplier information, outstanding payables, and recent purchase volume
   */
  async getSuppliersContext(businessId: string, userRole = 'CASHIER', limit = 5) {
    // Role protection: Cashiers should not view wholesale supplier payables
    const normalizedRole = userRole.toUpperCase().replace(/[-\s]/g, '_');
    if (normalizedRole === 'CASHIER') {
      return {
        accessRestricted: true,
        message: 'Supplier financial and purchase information is restricted from CASHIER role.',
      };
    }

    const [totalSuppliersCount, suppliers] = await Promise.all([
      this.prisma.supplier.count({ where: { businessId } }),
      this.prisma.supplier.findMany({
        where: { businessId },
        orderBy: { createdAt: 'desc' },
        take: 15,
        include: {
          purchases: {
            select: { grandTotal: true, amountPaid: true },
          },
        },
      }),
    ]);

    let totalPayableDues = 0;

    const enriched = suppliers.map((s: any) => {
      const purchaseList: any[] = s.purchases || [];
      const totalBilled = purchaseList.reduce((sum: number, p: any) => sum + Number(p.grandTotal || 0), 0);
      const totalPaid = purchaseList.reduce((sum: number, p: any) => sum + Number(p.amountPaid || 0), 0);
      const outstandingDue = Math.max(0, totalBilled - totalPaid);

      totalPayableDues += outstandingDue;

      return {
        name: s.name,
        phone: s.phone || 'N/A',
        totalPurchases: purchaseList.length,
        totalPurchasedAmount: totalBilled,
        payableDueToSupplier: outstandingDue,
      };
    });

    enriched.sort((a, b) => b.payableDueToSupplier - a.payableDueToSupplier);

    return {
      totalActiveSuppliers: totalSuppliersCount,
      totalOutstandingPayablesToSuppliers: totalPayableDues,
      topPayableSuppliers: enriched.slice(0, limit),
    };
  }
}
