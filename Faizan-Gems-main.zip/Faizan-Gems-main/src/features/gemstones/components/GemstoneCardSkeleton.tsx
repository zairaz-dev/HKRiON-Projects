"use client";

import React from "react";

interface GemstoneCardSkeletonProps {
  className?: string;
}

export function GemstoneCardSkeleton({ className = "" }: GemstoneCardSkeletonProps) {
  return (
    <div className={`flex flex-col bg-white border border-[#E8E4DC] rounded-xs overflow-hidden transition-all duration-300 shadow-xs ${className}`}>
      {/* Aspect 4:5 Image Frame Placeholder with Luxury Shimmer */}
      <div className="relative aspect-[4/5] w-full bg-[#F2EFE9] animate-shimmer overflow-hidden">
        {/* Subtle Top Badge */}
        <div className="absolute top-2 sm:top-3.5 left-2 sm:left-3.5 z-10">
          <div className="w-14 sm:w-16 h-3.5 sm:h-4 bg-[#E2DDD3]/80 rounded-xs" />
        </div>

        {/* Wishlist Circle Placeholder */}
        <div className="absolute top-2 sm:top-3.5 right-2 sm:right-3.5 z-10">
          <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-full bg-white/70 shadow-xs" />
        </div>
      </div>

      {/* Content Container */}
      <div className="p-2.5 sm:p-5 flex flex-col flex-grow justify-between space-y-3 bg-white">
        <div>
          {/* Origin & Carat Line */}
          <div className="flex items-center justify-between mb-2">
            <div className="w-20 sm:w-24 h-2.5 sm:h-3 bg-[#EFECE5] rounded-xs animate-pulse" />
            <div className="w-10 sm:w-14 h-2.5 sm:h-3 bg-[#E8E4DC] rounded-xs animate-pulse" />
          </div>

          {/* Title */}
          <div className="w-4/5 h-3.5 sm:h-5 bg-[#E2DDD3] rounded-xs mb-1.5 animate-pulse" />

          {/* Cut & Color Description */}
          <div className="w-1/2 h-2.5 sm:h-3.5 bg-[#F2EFE9] rounded-xs animate-pulse" />
        </div>

        {/* Price & Action Footer */}
        <div className="mt-2.5 sm:mt-4 pt-2 sm:pt-3.5 border-t border-[#F0ECE1] flex items-end justify-between gap-2">
          <div className="space-y-1">
            <div className="w-12 h-2 bg-[#EFECE5] rounded-xs" />
            <div className="w-20 sm:w-28 h-4 sm:h-5 bg-[#E8DFC8] rounded-xs animate-pulse" />
          </div>

          <div className="w-14 sm:w-20 h-6 sm:h-8 bg-[#EAE6DD] rounded-xs" />
        </div>
      </div>
    </div>
  );
}

export default GemstoneCardSkeleton;
