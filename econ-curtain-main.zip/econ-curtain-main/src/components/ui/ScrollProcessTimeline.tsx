"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, ArrowRight } from "lucide-react";

const processSteps = [
  {
    step: "01",
    title: "Consultation",
    subtitle: "Share Your Vision",
    desc: "Connect with our design team or request an expert site recommendation based on light control, energy efficiency, and privacy requirements.",
    detail: "Free telephone or in-person consultation with swatch samples."
  },
  {
    step: "02",
    title: "Site Measurement",
    subtitle: "Precision Laser Surveying",
    desc: "Our certified technicians conduct millimeter-accurate laser measurements of window frames, patio enclosures, or structural anchor points.",
    detail: "Guarantees flawless custom edge-to-edge fitting with zero light leaks."
  },
  {
    step: "03",
    title: "Design Selection",
    subtitle: "Curated Fabrics & Motors",
    desc: "Select your preferred fabrics, colors, transparency levels, and motorization hubs (Somfy, Alexa, Google Home, remote controls).",
    detail: "Choose from anti-glare screens, 100% blackout textiles, or marine PVC."
  },
  {
    step: "04",
    title: "Installation",
    subtitle: "Turnkey Professional Fitting",
    desc: "Flawless, clean, and silent installation performed by trained technicians. We mount extrusions, test motorized limits, and clean up the work area.",
    detail: "Quick 1-day installation for most residential & commercial projects."
  },
  {
    step: "05",
    title: "Support & Warranty",
    subtitle: "Dedicated After-Sales Care",
    desc: "Enjoy ongoing warranty coverage, motor programming assistance, and dedicated maintenance support for complete peace of mind.",
    detail: "Multi-year warranty on motors, mechanisms, and UV fabric durability."
  }
];

export default function ScrollProcessTimeline() {
  const [activeStep, setActiveStep] = useState(0);

  return (
    <section className="py-24 md:py-32 bg-slate-950 px-4 sm:px-6 lg:px-8 relative border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16 md:mb-24">
          <span className="text-primary text-xs font-black uppercase tracking-widest block mb-3">
            Hassle-Free Turnkey Workflow
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            Our 5-Step Process
          </h2>
          <div className="w-20 h-1 bg-primary mx-auto rounded-full mt-4 mb-6"></div>
          <p className="text-slate-400 max-w-2xl mx-auto text-base sm:text-lg font-light">
            From initial measurement to final installation, we manage every detail with precision.
          </p>
        </div>

        {/* Timeline Stepper Navigation Bar */}
        <div className="relative mb-16 max-w-5xl mx-auto">
          {/* Progress Bar Line */}
          <div className="hidden md:block absolute top-1/2 left-0 right-0 h-1 bg-slate-800 -translate-y-1/2 rounded-full z-0">
            <motion.div
              className="h-full bg-gradient-to-r from-yellow-400 to-amber-500 rounded-full"
              initial={{ width: "0%" }}
              animate={{ width: `${(activeStep / (processSteps.length - 1)) * 100}%` }}
              transition={{ duration: 0.5, ease: "easeInOut" }}
            />
          </div>

          {/* Stepper Buttons (Desktop & Mobile horizontal scrollable) */}
          <div className="relative z-10 flex justify-between items-center gap-2 overflow-x-auto pb-4 md:pb-0 scrollbar-none">
            {processSteps.map((s, index) => {
              const isActive = activeStep === index;
              const isPast = activeStep > index;

              return (
                <button
                  key={s.step}
                  onClick={() => setActiveStep(index)}
                  className="flex flex-col items-center group shrink-0 focus:outline-none touch-manipulation px-2"
                >
                  <div
                    className={`w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center font-black text-sm sm:text-base border-2 transition-all duration-300 shadow-xl ${
                      isActive
                        ? "bg-amber-400 text-slate-950 border-white scale-110 shadow-amber-500/30"
                        : isPast
                        ? "bg-slate-900 text-primary border-primary"
                        : "bg-slate-900 text-slate-500 border-slate-800 group-hover:border-slate-700"
                    }`}
                  >
                    {isPast ? <CheckCircle2 size={20} /> : s.step}
                  </div>
                  <span
                    className={`text-[11px] sm:text-xs font-bold mt-2 sm:mt-3 transition-colors block text-center max-w-[70px] sm:max-w-none leading-tight ${
                      isActive ? "text-amber-400 font-bold" : "text-slate-400 group-hover:text-white"
                    }`}
                  >
                    {s.title}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Step Detail Display Card */}
        <div className="max-w-4xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeStep}
              initial={{ opacity: 0.2, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0.2, y: -10 }}
              transition={{ duration: 0.4 }}
              className="bg-slate-900/90 backdrop-blur-md p-8 sm:p-12 rounded-3xl border border-slate-800 shadow-2xl relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 text-9xl font-black text-slate-800/20 select-none pointer-events-none pr-6 pt-2">
                {processSteps[activeStep].step}
              </div>

              <div className="relative z-10">
                <span className="text-primary text-xs font-bold uppercase tracking-widest block mb-2">
                  Step {processSteps[activeStep].step} of 05
                </span>
                <h3 className="text-2xl sm:text-4xl font-bold text-white mb-2">
                  {processSteps[activeStep].title} — {processSteps[activeStep].subtitle}
                </h3>
                <p className="text-slate-300 text-base sm:text-lg leading-relaxed font-light mt-4 mb-8">
                  {processSteps[activeStep].desc}
                </p>

                <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center gap-3 text-sm text-slate-300 font-medium mb-8">
                  <CheckCircle2 size={20} className="text-primary shrink-0" />
                  <span>{processSteps[activeStep].detail}</span>
                </div>

                {/* Step Controls */}
                <div className="flex justify-between items-center border-t border-slate-800/80 pt-6">
                  <button
                    onClick={() => setActiveStep((prev) => Math.max(0, prev - 1))}
                    disabled={activeStep === 0}
                    className="text-sm font-semibold text-slate-400 hover:text-white disabled:opacity-30 disabled:pointer-events-none transition-colors px-4 py-2"
                  >
                    ← Previous Step
                  </button>

                  <button
                    onClick={() => setActiveStep((prev) => Math.min(processSteps.length - 1, prev + 1))}
                    disabled={activeStep === processSteps.length - 1}
                    className="flex items-center gap-2 text-sm font-bold bg-primary text-slate-950 hover:bg-yellow-400 px-6 py-2.5 rounded-full disabled:opacity-30 disabled:pointer-events-none transition-all shadow-lg"
                  >
                    <span>Next Step</span>
                    <ArrowRight size={16} />
                  </button>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
