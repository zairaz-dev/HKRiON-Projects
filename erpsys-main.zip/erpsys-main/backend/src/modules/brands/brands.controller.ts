import {
  Controller,
  Post,
  Body,
  Get,
  Put,
  Delete,
  Param,
  Query,
  UseInterceptors,
  UploadedFile,
  UseGuards,
  Req,
  ForbiddenException,
} from '@nestjs/common';
import { BrandsService } from './brands.service';
import { FileInterceptor } from '@nestjs/platform-express';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';
import {
  ApiTags,
  ApiOperation,
  ApiBody,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiQuery,
  ApiConsumes,
} from '@nestjs/swagger';
import {
  CreateBrandBodySchema,
  UpdateBrandBodySchema,
  BrandResponseSchema,
} from '../../docs/brands.docs';
import { CreateBrandDto } from './dto/create-brand.dto';
import { UpdateBrandDto } from './dto/update-brand.dto';
import { getImageUploadOptions } from '../../common/utils/upload.util';
import { join } from 'path';
import * as fs from 'fs';

@ApiTags('Brands')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('brands')
export class BrandsController {
  constructor(private readonly brandsService: BrandsService) {}

  @Permissions(Permission.BRAND_CREATE)
  @Post()
  @UseInterceptors(FileInterceptor('logo', getImageUploadOptions('brands')))
  @ApiConsumes('multipart/form-data', 'application/json')
  @ApiOperation({ summary: 'Create a new brand' })
  @ApiBody({ schema: CreateBrandBodySchema })
  @ApiResponse({
    status: 201,
    description: 'Brand created successfully',
    schema: BrandResponseSchema,
  })
  async createBrand(
    @Req() req: any,
    @UploadedFile() file: any,
    @Body() body: CreateBrandDto,
  ) {
    const { name, description, businessId, branchIds, isActive, logoUrl, createdById } = body;

    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }

    // Convert branchIds array
    let parsedBranchIds: string[] = [];
    if (branchIds) {
      if (Array.isArray(branchIds)) {
        parsedBranchIds = branchIds;
      } else if (typeof branchIds === 'string') {
        try {
          const parsed = JSON.parse(branchIds);
          if (Array.isArray(parsed)) {
            parsedBranchIds = parsed;
          } else {
            parsedBranchIds = [branchIds];
          }
        } catch {
          parsedBranchIds = branchIds
            .split(',')
            .map((id: string) => id.trim())
            .filter(Boolean);
        }
      }
    }

    // Determine final logoUrl: uploaded file takes priority, otherwise use logoUrl text field
    let finalLogoUrl = logoUrl || null;
    if (file) {
      finalLogoUrl = `/uploads/brands/${file.filename}`;
    }

    const parsedIsActive =
      isActive !== undefined ? isActive === 'true' || isActive === true : true;

    return this.brandsService.createBrand({
      name,
      description,
      logoUrl: finalLogoUrl,
      isActive: parsedIsActive,
      businessId: bId,
      branchIds: parsedBranchIds,
      createdById: createdById || user.id,
    });
  }

  @Permissions(Permission.BRAND_VIEW)
  @Get()
  @ApiOperation({ summary: 'Get paginated list of brands' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiQuery({ name: 'branchId', required: false, type: String })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'search', required: false, type: String })
  @ApiResponse({
    status: 200,
    description: 'List of brands retrieved successfully',
  })
  async getBrands(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('search') search?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    if (!bId) {
      return {
        data: [],
        meta: {
          totalItems: 0,
          totalPages: 1,
          currentPage: 1,
          limit: limit ? Number(limit) : 10,
        },
      };
    }
    return this.brandsService.getBrands(bId, {
      branchId,
      page: page ? Number(page) : undefined,
      limit: limit ? Number(limit) : undefined,
      search,
    });
  }

  @Permissions(Permission.BRAND_VIEW)
  @Get(':id')
  @ApiOperation({ summary: 'Get brand details by ID' })
  @ApiParam({ name: 'id', description: 'Brand UUID' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiResponse({
    status: 200,
    description: 'Brand details retrieved successfully',
    schema: BrandResponseSchema,
  })
  async getBrandById(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    if (!bId) {
      throw new ForbiddenException('Business ID is required.');
    }
    return this.brandsService.getBrandById(id, bId);
  }

  @Permissions(Permission.BRAND_UPDATE)
  @Put(':id')
  @UseInterceptors(FileInterceptor('logo', getImageUploadOptions('brands')))
  @ApiConsumes('multipart/form-data', 'application/json')
  @ApiOperation({ summary: 'Update brand details' })
  @ApiParam({ name: 'id', description: 'Brand UUID' })
  @ApiBody({ schema: UpdateBrandBodySchema })
  @ApiResponse({
    status: 200,
    description: 'Brand updated successfully',
    schema: BrandResponseSchema,
  })
  async updateBrand(
    @Param('id') id: string,
    @Req() req: any,
    @UploadedFile() file: any,
    @Body() body: UpdateBrandDto,
  ) {
    const { name, description, businessId, branchIds, isActive, logoUrl, updatedById } = body;

    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }

    const updateData: any = {};

    if (name !== undefined) updateData.name = name;
    if (description !== undefined) updateData.description = description;

    if (isActive !== undefined) {
      updateData.isActive = isActive === 'true' || isActive === true;
    }

    if (branchIds !== undefined) {
      let parsedBranchIds: string[] = [];
      if (Array.isArray(branchIds)) {
        parsedBranchIds = branchIds;
      } else if (typeof branchIds === 'string') {
        try {
          const parsed = JSON.parse(branchIds);
          if (Array.isArray(parsed)) {
            parsedBranchIds = parsed;
          } else {
            parsedBranchIds = [branchIds];
          }
        } catch {
          parsedBranchIds = branchIds
            .split(',')
            .map((id: string) => id.trim())
            .filter(Boolean);
        }
      }
      updateData.branchIds = parsedBranchIds;
    }

    // Handle logo update
    if (file) {
      updateData.logoUrl = `/uploads/brands/${file.filename}`;

      // Clean up the old logo file from the server if it was local
      try {
        const oldBrand = await this.brandsService.getBrandById(id, bId);
        if (oldBrand.logoUrl && oldBrand.logoUrl.startsWith('/uploads/')) {
          const oldFilePath = join(process.cwd(), oldBrand.logoUrl);
          if (fs.existsSync(oldFilePath)) {
            fs.unlinkSync(oldFilePath);
          }
        }
      } catch (err) {
        // Old file deletion error shouldn't block update
      }
    } else if (logoUrl !== undefined) {
      updateData.logoUrl = logoUrl === 'null' || !logoUrl ? null : logoUrl;
    }

    if (updatedById !== undefined) {
      updateData.updatedById = updatedById;
    }

    return this.brandsService.updateBrand(id, bId, updateData);
  }

  @Permissions(Permission.BRAND_DELETE)
  @Delete(':id')
  @ApiOperation({ summary: 'Delete brand' })
  @ApiParam({ name: 'id', description: 'Brand UUID' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiResponse({
    status: 200,
    description: 'Brand deleted successfully',
  })
  async deleteBrand(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    if (!bId) {
      throw new ForbiddenException('Business ID is required.');
    }

    // Delete local logo file when brand is deleted
    try {
      const brand = await this.brandsService.getBrandById(id, bId);
      if (brand.logoUrl && brand.logoUrl.startsWith('/uploads/')) {
        const filePath = join(process.cwd(), brand.logoUrl);
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
        }
      }
    } catch (err) {
      // File cleanup error shouldn't block delete
    }

    return this.brandsService.deleteBrand(id, bId);
  }
}
