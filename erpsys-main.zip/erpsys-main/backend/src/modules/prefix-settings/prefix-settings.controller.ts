import { Controller, Get, Patch, Body, Query, UseGuards, Req } from '@nestjs/common';
import { PrefixSettingsService } from './prefix-settings.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('prefix-settings')
export class PrefixSettingsController {
  constructor(private readonly prefixSettingsService: PrefixSettingsService) {}

  @Get()
  async getPrefixes(@Req() req: any, @Query('businessId') businessId?: string) {
    const user = req.user;
    const bId = user.role === 'super-admin' && businessId ? businessId : user.businessId;
    return this.prefixSettingsService.getPrefixes(bId);
  }

  @Patch()
  async updatePrefixes(@Req() req: any, @Body() body: any) {
    const user = req.user;
    const bId = user.role === 'super-admin' && body.businessId ? body.businessId : user.businessId;
    return this.prefixSettingsService.updatePrefixes(bId, body);
  }
}
