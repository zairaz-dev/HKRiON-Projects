import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { purchaseService } from "@/services/purchase-service";
import { queryKeys } from "@/lib/query-keys";

export function usePurchasesQuery(
  businessId: string,
  filters: {
    branchId?: string;
    supplierId?: string;
    page?: number;
    limit?: number;
    search?: string;
  },
) {
  return useQuery({
    queryKey: queryKeys.purchases.list(
      businessId,
      filters.branchId,
      filters.supplierId,
      filters.page,
      filters.limit,
      filters.search,
    ),
    queryFn: () => purchaseService.getPurchases(businessId, filters),
    enabled: !!businessId,
  });
}

export function useCreatePurchaseMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: Parameters<typeof purchaseService.createPurchase>[0]) =>
      purchaseService.createPurchase(data),
    onSuccess: () => {
      // Invalidate both purchases and products since products stock will change!
      queryClient.invalidateQueries({ queryKey: queryKeys.purchases.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
    },
  });
}

export function useUpdatePurchaseMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Parameters<typeof purchaseService.updatePurchase>[1] }) =>
      purchaseService.updatePurchase(id, data),
    onSuccess: () => {
      // Invalidate both purchases and products since products stock will change!
      queryClient.invalidateQueries({ queryKey: queryKeys.purchases.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
    },
  });
}

export function usePurchaseDetailQuery(id: string, businessId: string) {
  return useQuery({
    queryKey: queryKeys.purchases.detail(id),
    queryFn: () => purchaseService.getPurchaseById(id, businessId),
    enabled: !!id && !!businessId,
  });
}

export function usePurchaseReturnsQuery(
  businessId: string,
  filters: {
    branchId?: string;
    supplierId?: string;
    page?: number;
    limit?: number;
    search?: string;
  },
) {
  return useQuery({
    queryKey: queryKeys.purchases.returnsList(
      businessId,
      filters.branchId,
      filters.supplierId,
      filters.page,
      filters.limit,
      filters.search,
    ),
    queryFn: () => purchaseService.getPurchaseReturns(businessId, filters),
    enabled: !!businessId,
  });
}

export function useCreatePurchaseReturnMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: Parameters<typeof purchaseService.createPurchaseReturn>[0]) =>
      purchaseService.createPurchaseReturn(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.purchases.returnsAll });
      queryClient.invalidateQueries({ queryKey: queryKeys.purchases.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
    },
  });
}

export function usePurchaseReturnDetailQuery(id: string, businessId: string) {
  return useQuery({
    queryKey: queryKeys.purchases.returnDetail(id),
    queryFn: () => purchaseService.getPurchaseReturnById(id, businessId),
    enabled: !!id && !!businessId,
  });
}
