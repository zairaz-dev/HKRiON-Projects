import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class UnitsService {
  constructor(private readonly prisma: PrismaService) {}

  async createUnit(data: {
    name: string;
    code: string;
    description?: string;
    isActive?: boolean;
    businessId: string;
    branchIds?: string[];
    parentId?: string | null;
    conversionFactor?: number | null;
    createdById?: string;
  }) {
    // 0. Field validations
    const trimmedName = data.name?.trim();
    if (!trimmedName) {
      throw new BadRequestException('Unit name is required');
    }
    if (trimmedName.length < 2 || trimmedName.length > 100) {
      throw new BadRequestException('Unit name must be between 2 and 100 characters');
    }

    const trimmedCode = data.code?.trim().toUpperCase();
    if (!trimmedCode) {
      throw new BadRequestException('Unit code is required');
    }
    if (trimmedCode.length < 1 || trimmedCode.length > 20) {
      throw new BadRequestException('Unit code must be between 1 and 20 characters');
    }

    if (!data.businessId || !data.businessId.trim()) {
      throw new BadRequestException('Business ID is required');
    }

    if (data.description && data.description.length > 500) {
      throw new BadRequestException('Description cannot exceed 500 characters');
    }

    // 1. Verify parent unit exists if parentId is provided
    if (data.parentId) {
      const parent = await this.prisma.unit.findFirst({
        where: { id: data.parentId, businessId: data.businessId },
      });
      if (!parent) {
        throw new BadRequestException('Parent unit not found');
      }
      if (!data.conversionFactor || data.conversionFactor <= 0) {
        throw new BadRequestException('Conversion factor must be greater than 0 when parent unit is specified');
      }
    }

    // 2. Verify all branches belong to the business
    if (data.branchIds && data.branchIds.length > 0) {
      const validBranches = await this.prisma.branch.findMany({
        where: {
          id: { in: data.branchIds },
          businessId: data.businessId,
        },
      });
      if (validBranches.length !== data.branchIds.length) {
        throw new BadRequestException('One or more selected branches are invalid');
      }
    }

    // 3. Check for duplicate code in the same business
    const existingCode = await this.prisma.unit.findFirst({
      where: {
        code: { equals: trimmedCode, mode: 'insensitive' },
        businessId: data.businessId,
      },
    });

    if (existingCode) {
      throw new BadRequestException('A unit with this code already exists in this business');
    }

    // 4. Check for duplicate name in the same business
    const existingName = await this.prisma.unit.findFirst({
      where: {
        name: { equals: trimmedName, mode: 'insensitive' },
        businessId: data.businessId,
      },
    });

    if (existingName) {
      throw new BadRequestException('A unit with this name already exists in this business');
    }

    // 5. Create Unit and its UnitBranch relations in a transaction
    return this.prisma.$transaction(async (tx) => {
      const unit = await tx.unit.create({
        data: {
          name: trimmedName,
          code: trimmedCode,
          description: data.description ? data.description.trim() : null,
          ...(data.isActive !== undefined && { isActive: data.isActive }),
          businessId: data.businessId,
          parentId: data.parentId || null,
          conversionFactor: data.parentId ? data.conversionFactor : null,
          createdById: data.createdById || null,
          branches: data.branchIds && data.branchIds.length > 0
            ? {
                create: data.branchIds.map((branchId) => ({
                  branchId,
                })),
              }
            : undefined,
        },
        include: {
          parent: true,
          subUnits: true,
          branches: {
            include: {
              branch: true,
            },
          },
        },
      });

      return unit;
    });
  }

  async getUnits(businessId: string, branchId?: string) {
    const whereClause: any = {
      businessId,
    };

    if (branchId) {
      whereClause.OR = [
        { branches: { none: {} } },
        { branches: { some: { branchId } } },
      ];
    }

    return this.prisma.unit.findMany({
      where: whereClause,
      include: {
        parent: true,
        subUnits: true,
        branches: {
          include: {
            branch: {
              select: {
                id: true,
                name: true,
              },
            },
          },
        },
      },
      orderBy: {
        createdAt: 'asc',
      },
    });
  }

  async getUnitById(id: string, businessId: string) {
    const unit = await this.prisma.unit.findFirst({
      where: { id, businessId },
      include: {
        parent: true,
        subUnits: true,
        branches: {
          include: {
            branch: true,
          },
        },
      },
    });

    if (!unit) {
      throw new BadRequestException('Unit not found');
    }

    return unit;
  }

  async updateUnit(
    id: string,
    businessId: string,
    data: {
      name?: string;
      code?: string;
      description?: string;
      isActive?: boolean;
      branchIds?: string[];
      parentId?: string | null;
      conversionFactor?: number | null;
      updatedById?: string;
    },
  ) {
    const unit = await this.getUnitById(id, businessId);

    // 0. Field validations
    let trimmedName: string | undefined = undefined;
    if (data.name !== undefined) {
      trimmedName = data.name.trim();
      if (!trimmedName) {
        throw new BadRequestException('Unit name cannot be empty');
      }
      if (trimmedName.length < 2 || trimmedName.length > 100) {
        throw new BadRequestException('Unit name must be between 2 and 100 characters');
      }
    }

    let trimmedCode: string | undefined = undefined;
    if (data.code !== undefined) {
      trimmedCode = data.code.trim().toUpperCase();
      if (!trimmedCode) {
        throw new BadRequestException('Unit code cannot be empty');
      }
      if (trimmedCode.length < 1 || trimmedCode.length > 20) {
        throw new BadRequestException('Unit code must be between 1 and 20 characters');
      }
    }

    if (data.description !== undefined && data.description !== null && data.description.length > 500) {
      throw new BadRequestException('Description cannot exceed 500 characters');
    }

    // 1. Verify parent unit if parentId is changing
    if (data.parentId !== undefined && data.parentId !== null && data.parentId !== unit.parentId) {
      if (data.parentId === id) {
        throw new BadRequestException('A unit cannot be its own parent');
      }
      const parent = await this.prisma.unit.findFirst({
        where: { id: data.parentId, businessId },
      });
      if (!parent) {
        throw new BadRequestException('Parent unit not found');
      }
      const factor = data.conversionFactor !== undefined ? data.conversionFactor : unit.conversionFactor;
      if (!factor || factor <= 0) {
        throw new BadRequestException('Conversion factor must be greater than 0 when parent unit is specified');
      }

      // Circular hierarchy check: target parent cannot be a descendant of this unit
      let currentParent: { id: string; parentId: string | null } | null = parent;
      while (currentParent && currentParent.parentId) {
        if (currentParent.parentId === id) {
          throw new BadRequestException('Circular hierarchy detected: cannot set a sub-unit as parent');
        }
        currentParent = await this.prisma.unit.findFirst({
          where: { id: currentParent.parentId, businessId },
          select: { id: true, parentId: true },
        });
      }
    }

    // 2. Verify all branches belong to the business if branchIds are changing
    if (data.branchIds && data.branchIds.length > 0) {
      const validBranches = await this.prisma.branch.findMany({
        where: {
          id: { in: data.branchIds },
          businessId,
        },
      });
      if (validBranches.length !== data.branchIds.length) {
        throw new BadRequestException('One or more selected branches are invalid');
      }
    }

    // 3. Check for duplicate code if code is changing
    if (trimmedCode && trimmedCode !== unit.code) {
      const existing = await this.prisma.unit.findFirst({
        where: {
          id: { not: id },
          code: { equals: trimmedCode, mode: 'insensitive' },
          businessId,
        },
      });
      if (existing) {
        throw new BadRequestException('A unit with this code already exists in this business');
      }
    }

    // 4. Check for duplicate name if name is changing
    if (trimmedName && trimmedName !== unit.name) {
      const existing = await this.prisma.unit.findFirst({
        where: {
          id: { not: id },
          name: { equals: trimmedName, mode: 'insensitive' },
          businessId,
        },
      });
      if (existing) {
        throw new BadRequestException('A unit with this name already exists in this business');
      }
    }

    return this.prisma.$transaction(async (tx) => {
      // Update UnitBranch relations if branchIds are provided
      if (data.branchIds !== undefined) {
        // Remove existing connections
        await tx.unitBranch.deleteMany({
          where: { unitId: id },
        });

        // Add new connections
        if (data.branchIds.length > 0) {
          await tx.unitBranch.createMany({
            data: data.branchIds.map((branchId) => ({
              unitId: id,
              branchId,
            })),
          });
        }
      }

      // Prepare update data for Unit fields
      const updateData: any = {};
      if (trimmedName !== undefined) updateData.name = trimmedName;
      if (trimmedCode !== undefined) updateData.code = trimmedCode;
      if (data.description !== undefined) updateData.description = data.description ? data.description.trim() : null;
      if (data.isActive !== undefined) updateData.isActive = data.isActive;
      if (data.parentId !== undefined) {
        updateData.parentId = data.parentId || null;
        updateData.conversionFactor = data.parentId ? (data.conversionFactor !== undefined ? data.conversionFactor : unit.conversionFactor) : null;
      } else if (data.parentId === null) {
        updateData.parentId = null;
        updateData.conversionFactor = null;
      } else if (data.conversionFactor !== undefined) {
        updateData.conversionFactor = unit.parentId ? data.conversionFactor : null;
      }
      if (data.updatedById !== undefined) updateData.updatedById = data.updatedById;

      const updated = await tx.unit.update({
        where: { id },
        data: updateData,
        include: {
          parent: true,
          subUnits: true,
          branches: {
            include: {
              branch: true,
            },
          },
        },
      });

      return updated;
    });
  }

  async deleteUnit(id: string, businessId: string) {
    const unit = await this.getUnitById(id, businessId);

    // 1. Check if unit has sub-units
    if (unit.subUnits && unit.subUnits.length > 0) {
      throw new BadRequestException('Cannot delete unit because it has sub-units assigned. Please delete or re-assign sub-units first.');
    }

    // 2. Check if unit is associated with products
    const productCount = await this.prisma.product.count({
      where: { unitId: id },
    });

    if (productCount > 0) {
      throw new BadRequestException(
        `Cannot delete unit because it is associated with ${productCount} product(s). Please reassign or remove the products first.`
      );
    }

    await this.prisma.unit.delete({
      where: { id },
    });

    return { success: true };
  }
}
