import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import * as express from 'express';
import { join } from 'path';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { apiReference } from '@scalar/nestjs-api-reference';

let spinnerTimer: any;
function startSpinner() {
  const chars = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
  let i = 0;
  process.stdout.write('\n'); // Start on a new line
  spinnerTimer = setInterval(() => {
    process.stdout.write(`\r\x1b[36m${chars[i]}\x1b[0m \x1b[1mHKRION ERP backend is booting up, please wait...\x1b[0m`);
    i = (i + 1) % chars.length;
  }, 80);
}

function stopSpinner() {
  if (spinnerTimer) {
    clearInterval(spinnerTimer);
    process.stdout.write('\r\x1b[K'); // Clear the line
  }
}

function printSuccessBanner() {
  console.log('\r\x1b[32m✔ HKRION ERP backend started successfully!\x1b[0m');
  console.log('\x1b[35m' + '='.repeat(60) + '\x1b[0m');
  console.log('  🚀 \x1b[1mServer Status\x1b[0m : \x1b[32mActive\x1b[0m (Port 4000)');
  console.log('  📖 \x1b[1mAPI Reference\x1b[0m : \x1b[36mhttp://localhost:4000/reference\x1b[0m');
  console.log('\x1b[35m' + '='.repeat(60) + '\x1b[0m\n');
}

async function bootstrap() {
  startSpinner();

  const app = await NestFactory.create(AppModule, { 
    bodyParser: false,
    logger: ['error', 'warn'], // suppress all NestJS start LOGS
  });
  
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ limit: '10mb', extended: true }));
  
  // Serve uploads folder statically
  app.use('/uploads', express.static(join(__dirname, '..', 'uploads')));
  
  // Enable CORS so the Next.js frontend can connect
  app.enableCors({
    origin: '*',
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    preflightContinue: false,
    optionsSuccessStatus: 204,
  });

  // Setup Swagger OpenAPI document
  const config = new DocumentBuilder()
    .setTitle('HKRION ERP API')
    .setDescription('HKRION ERP Backend API Reference')
    .setVersion('1.0')
    .addBearerAuth()
    .build();

  const document = SwaggerModule.createDocument(app, config);

  // Auto-group paths by their first path segment (tagging them)
  if (document && document.paths) {
    Object.keys(document.paths).forEach((pathKey) => {
      const pathItem = (document.paths as any)[pathKey];
      // Get the first segment of the path, e.g. /auth/register -> auth
      const segments = pathKey.split('/').filter(Boolean);
      if (segments.length > 0) {
        let tag = segments[0];
        // Capitalize first letter and replace hyphens with spaces for user-friendly tags
        tag = tag.charAt(0).toUpperCase() + tag.slice(1).replace(/-/g, ' ');

        // Assign this tag to all operations under this path
        Object.keys(pathItem).forEach((method) => {
          const operation = pathItem[method];
          if (operation && typeof operation === 'object') {
            if (!operation.tags) {
              operation.tags = [];
            }
            if (!operation.tags.includes(tag)) {
              operation.tags.push(tag);
            }
          }
        });
      }
    });
  }

  // Setup Scalar API Reference
  app.use(
    '/reference',
    apiReference({
      content: document,
      theme: 'purple',
    }),
  );

  await app.listen(4000);
  stopSpinner();
  printSuccessBanner();
}
bootstrap();
