import { Module } from '@nestjs/common';
import { SupplierAdvancesService } from './supplier-advances.service';
import { SupplierAdvancesController } from './supplier-advances.controller';
import { PrismaModule } from '../prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [SupplierAdvancesController],
  providers: [SupplierAdvancesService],
  exports: [SupplierAdvancesService],
})
export class SupplierAdvancesModule {}
