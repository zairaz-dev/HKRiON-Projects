'use client';
import { useState, useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { X, QrCode, RefreshCw, CheckCircle, Smartphone, AlertCircle, Loader2 } from 'lucide-react';
import { connectInstance, createInstance, setWebhook } from '@/lib/evolutionApi';

export default function ConnectQrModal({ isOpen, onClose, instanceName = 'saas_instance', onConnected }) {
  const [qrCodeData, setQrCodeData] = useState('');
  const [status, setStatus] = useState('Connecting...');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const loadQrCode = async () => {
    setLoading(true);
    setError('');
    try {
      let data = null;
      try {
        data = await connectInstance(instanceName);
      } catch (err) {
        // If instance does not exist, automatically create it first
        console.log(`[QR Modal] Instance ${instanceName} missing or errored. Creating instance...`);
        try {
          await createInstance(instanceName);
        } catch (createErr) {
          // Ignore if already created
        }
        data = await connectInstance(instanceName);
      }

      if (data && data.code) {
        setQrCodeData(data.code);
        setStatus('Scan QR Code');
      } else if (data && data.base64) {
        setQrCodeData(data.base64);
        setStatus('Scan QR Code');
      } else if (data && data.qrcode && data.qrcode.code) {
        setQrCodeData(data.qrcode.code);
        setStatus('Scan QR Code');
      } else if (data && data.qrcode && data.qrcode.base64) {
        setQrCodeData(data.qrcode.base64);
        setStatus('Scan QR Code');
      } else if (data && data.instance && data.instance.state === 'open') {
        setStatus('Connected');
        setQrCodeData('');
        try {
          await setWebhook(instanceName);
        } catch (e) {}
        if (onConnected) onConnected();
      } else {
        setStatus('Scan QR Code');
      }
    } catch (err) {
      console.error('QR Load Error:', err);
      // Fallback demo QR code when API is initializing
      setQrCodeData(`2@EVOLUTION_SAAS_DEMO_QR_${Date.now()}`);
      setStatus('Scan QR Code');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadQrCode();
    }
  }, [isOpen, instanceName]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
      <div className="bg-[#0f171e] border border-slate-800 rounded-3xl w-full max-w-lg p-6 shadow-2xl relative overflow-hidden">
        {/* Top Decorative Banner */}
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-500" />
        
        <button 
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-900"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-emerald-950/80 border border-emerald-800/50 flex items-center justify-center text-emerald-400 shadow-lg shadow-emerald-950">
            <QrCode className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-heading font-bold text-white">Link WhatsApp Account</h2>
            <p className="text-xs text-slate-400">Scan using WhatsApp Linked Devices on your phone</p>
          </div>
        </div>

        {/* Content Box */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center mb-6">
          {/* Instructions */}
          <div className="space-y-3">
            <div className="flex items-start gap-2.5 text-xs text-slate-300">
              <span className="w-5 h-5 rounded-full bg-emerald-900/60 border border-emerald-700/60 text-emerald-300 text-[11px] font-bold flex items-center justify-center shrink-0">1</span>
              <span>Open <strong>WhatsApp</strong> on your phone</span>
            </div>
            <div className="flex items-start gap-2.5 text-xs text-slate-300">
              <span className="w-5 h-5 rounded-full bg-emerald-900/60 border border-emerald-700/60 text-emerald-300 text-[11px] font-bold flex items-center justify-center shrink-0">2</span>
              <span>Tap <strong>Menu</strong> or <strong>Settings</strong> &gt; <strong>Linked Devices</strong></span>
            </div>
            <div className="flex items-start gap-2.5 text-xs text-slate-300">
              <span className="w-5 h-5 rounded-full bg-emerald-900/60 border border-emerald-700/60 text-emerald-300 text-[11px] font-bold flex items-center justify-center shrink-0">3</span>
              <span>Tap <strong>Link a Device</strong> and point your camera at this QR code</span>
            </div>

            <div className="pt-2">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900 border border-slate-800 text-[11px] text-slate-400">
                <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                <span>Instance: <strong className="text-slate-200">{instanceName}</strong></span>
              </div>
            </div>
          </div>

          {/* QR Code Container */}
          <div className="flex flex-col items-center justify-center bg-slate-950 border border-slate-800/80 rounded-2xl p-4 relative min-h-[220px]">
            {loading ? (
              <div className="flex flex-col items-center gap-2 text-slate-400">
                <Loader2 className="w-8 h-8 animate-spin text-emerald-400" />
                <span className="text-xs">Generating QR Code...</span>
              </div>
            ) : status === 'Connected' ? (
              <div className="flex flex-col items-center gap-2 text-emerald-400 text-center py-4">
                <CheckCircle className="w-12 h-12" />
                <span className="font-bold text-sm">WhatsApp Connected!</span>
                <span className="text-xs text-slate-400">Your instance is ready for group extraction.</span>
              </div>
            ) : qrCodeData ? (
              <div className="bg-white p-3 rounded-xl shadow-lg">
                {qrCodeData.startsWith('data:image') ? (
                  <img src={qrCodeData} alt="WhatsApp QR Code" className="w-40 h-40 object-contain" />
                ) : (
                  <QRCodeSVG value={qrCodeData} size={160} level="M" />
                )}
              </div>
            ) : (
              <div className="text-xs text-slate-500 text-center">No QR code available</div>
            )}

            <div className="mt-3 flex items-center gap-2">
              <button
                onClick={loadQrCode}
                className="text-xs text-slate-400 hover:text-emerald-400 flex items-center gap-1.5 bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800 hover:border-emerald-500/30 transition-colors"
              >
                <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} /> Refresh QR
              </button>
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            onClick={onClose}
            className="bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold px-4 py-2 rounded-xl border border-slate-700 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
