Act as a Senior NestJS Architect.

Implement a complete Authentication and Authorization system in my existing NestJS project without breaking the current API.

Requirements:

## 1. JWT Authentication

- Verify existing JWT implementation.
- Create or improve JwtStrategy.
- Create JwtAuthGuard.
- Protect all private APIs using:

@UseGuards(JwtAuthGuard)

Public APIs:

- POST /auth/login
- POST /auth/register
- POST /auth/refresh (if exists)

Everything else must require authentication.

---

## 2. Role Based Authorization

Create:

- Role Enum
- @Roles() Decorator
- RolesGuard

Example Roles:

SUPER_ADMIN
ADMIN
MANAGER
CASHIER
INVENTORY_MANAGER
ACCOUNTANT
SALES

Example:

@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(Role.SUPER_ADMIN)

---

## 3. Permission System

Create Permission Enum.

Example:

PRODUCT_VIEW
PRODUCT_CREATE
PRODUCT_UPDATE
PRODUCT_DELETE

CATEGORY_VIEW
CATEGORY_CREATE
CATEGORY_UPDATE
CATEGORY_DELETE

BRAND_VIEW
BRAND_CREATE
BRAND_UPDATE
BRAND_DELETE

CUSTOMER_VIEW
CUSTOMER_CREATE

SUPPLIER_VIEW
SUPPLIER_CREATE

PURCHASE_VIEW
PURCHASE_CREATE

SALE_VIEW
SALE_CREATE

REPORT_VIEW

SETTINGS_VIEW

USER_MANAGE

---

## 4. Permission Decorator

Create:

@Permissions()

Example:

@Permissions(Permission.PRODUCT_CREATE)

---

## 5. Permissions Guard

Create PermissionGuard.

Flow:

JWT Guard

↓

Role Guard

↓

Permission Guard

↓

Controller

---

## 6. Folder Structure

src/common/

guards/
jwt-auth.guard.ts
roles.guard.ts
permissions.guard.ts

decorators/
roles.decorator.ts
permissions.decorator.ts
public.decorator.ts

enums/
role.enum.ts
permission.enum.ts

---

## 7. Apply Guards

Protect every controller.

Example:

Products

GET
Permission:
PRODUCT_VIEW

POST
PRODUCT_CREATE

PATCH
PRODUCT_UPDATE

DELETE
PRODUCT_DELETE

Do the same for every module.

---

## 8. Current User

Create decorator

@CurrentUser()

Example:

const user = CurrentUser();

without manually reading request.user.

---

## 9. Error Responses

Unauthorized

401

Forbidden

403

Keep consistent response format.

---

## 10. Do NOT Break Existing APIs

Do not change routes.

Do not change business logic.

Do not change Prisma schema.

Only add authentication and authorization.

---

## 11. Generate Report

At the end generate:

✔ Files Created

✔ Files Modified

✔ Controllers Protected

✔ Public Routes

✔ Protected Routes

✔ Roles

✔ Permissions

✔ Security Improvements

Follow NestJS official best practices.
