import { diskStorage } from 'multer';
import { extname, join } from 'path';
import * as fs from 'fs';
import { BadRequestException } from '@nestjs/common';

/**
 * Creates disk storage configuration for a given subfolder under /uploads
 */
export function createImageStorage(subfolder: string) {
  return diskStorage({
    destination: (req: any, file: any, cb: any) => {
      const uploadPath = join(process.cwd(), 'uploads', subfolder);
      if (!fs.existsSync(uploadPath)) {
        fs.mkdirSync(uploadPath, { recursive: true });
      }
      cb(null, uploadPath);
    },
    filename: (req: any, file: any, cb: any) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
      cb(null, `${uniqueSuffix}${extname(file.originalname).toLowerCase()}`);
    },
  });
}

/**
 * Image MIME type validator (JPG, JPEG, PNG, WEBP, SVG, GIF)
 */
export function imageFileFilter(req: any, file: any, cb: any) {
  const allowedMimeTypes = [
    'image/jpeg',
    'image/png',
    'image/webp',
    'image/svg+xml',
    'image/gif',
  ];
  const allowedExtensions = ['.jpg', '.jpeg', '.png', '.webp', '.svg', '.gif'];
  const ext = extname(file.originalname || '').toLowerCase();

  if (!allowedMimeTypes.includes(file.mimetype) || !allowedExtensions.includes(ext)) {
    return cb(
      new BadRequestException(
        'Only image files (JPG, PNG, WEBP, SVG, GIF) are allowed for upload.',
      ),
      false,
    );
  }
  cb(null, true);
}

/**
 * Image upload limits (Default 5MB)
 */
export const imageUploadLimits = {
  fileSize: 5 * 1024 * 1024, // 5 MB
};

/**
 * Helper to get complete Multer options for an image field
 */
export function getImageUploadOptions(subfolder: string) {
  return {
    storage: createImageStorage(subfolder),
    fileFilter: imageFileFilter,
    limits: imageUploadLimits,
  };
}
