# HKRION (Pvt) Ltd - Enterprise Production Deployment Guide (VPS + aaPanel + PM2 + MySQL)

This official deployment guide provides a complete, step-by-step walkthrough for hosting and maintaining **HKRION (Pvt) Ltd Next.js 16 Application** on a **Linux VPS Server (Ubuntu 22.04 / 24.04)** using **aaPanel**, **PM2**, **Prisma ORM**, and **MySQL**.

---

## 📋 Prerequisites & Initial Server Setup

Ensure your Linux VPS (Contabo / DigitalOcean / AWS) has **aaPanel** installed with the following services:

1. **Web Server**: Apache or NGINX (Installed via aaPanel App Store)
2. **Node.js**: Node v18+ or v20+ LTS (Installed via aaPanel Node.js Version Manager)
3. **Process Manager**: PM2 (`npm install -g pm2`)
4. **Database Server**: MySQL 8.0 / MariaDB (Installed via aaPanel App Store)

---

## 🔐 Environment Variables (`.env`) Setup

Create the `.env` file in your root project directory (`/www/wwwroot/hkrion.com/.env`) with your MySQL credentials:

```env
# ===================================================
# HKRION (Pvt) Ltd - Database Environment Variables
# ===================================================

# Individual Database Credentials
DB_HOST="127.0.0.1"
DB_PORT="3306"
DB_USER="hkrion"
DB_PASSWORD="your_secure_mysql_password"
DB_NAME="hkrion"

# Prisma Connection URL (MANDATORY FOR PRISMA)
DATABASE_URL="mysql://hkrion:your_secure_mysql_password@127.0.0.1:3306/hkrion"

# Server / App Environment Settings
NODE_ENV="production"
NEXT_PUBLIC_APP_URL="https://hkrion.com"
```

> **⚠️ Security Note:** Never commit `.env` to your public GitHub/Git repository!

---

## 🚀 One-Click Copy-Paste Initial Deployment Script

Run this command sequence in your Linux SSH Terminal (`root@vps:/www/wwwroot/hkrion.com#`):

```bash
# 1. Navigate to Project Root Directory
cd /www/wwwroot/hkrion.com

# 2. Install All Node Dependencies
npm install

# 3. Fix Directory Permissions & Create Upload Directories (Prevents EACCES Permission Errors)
chmod -R 755 node_modules/
mkdir -p public/uploads/avatars public/uploads/resumes
chmod -R 777 public/uploads

# 4. Generate Prisma Client & Sync MySQL Database Schema
node node_modules/prisma/build/index.js generate
node node_modules/prisma/build/index.js db push

# 5. Seed Initial Database (RBAC Roles, Default Admin/User Accounts & Job Openings)
npx tsx scripts/seed.ts

# 6. Build Production Bundle & Launch App with PM2
npm run build
pm2 start npm --name "hkrion-app" -- start -- -p 3000
pm2 save
pm2 startup
```

---

## ⚙️ aaPanel Reverse Proxy & NGINX Configs

### 1. Reverse Proxy Setup
1. Open **aaPanel** ➔ **Website** ➔ **Add site** (Domain: `hkrion.com`).
2. Click **Settings** on the site ➔ **Reverse proxy** tab ➔ **Add reverse proxy**:
   - **Proxy Name**: `HkrionProxy`
   - **Target URL**: `http://127.0.0.1:3000`
   - **Sent Domain**: `$host`
3. Save & Submit.

### 2. Enable Large File & Image Uploads (Up to 20MB & Instant Serving)
By default, NGINX limits request payload to 2MB. To allow user avatars & resume uploads and ensure uploaded files display instantly without PM2 restarts:
1. In aaPanel Website **Settings** ➔ Open **Configuration** (NGINX config).
2. Inside `server { ... }` block, add:
   ```nginx
   # Allow up to 20MB file upload
   client_max_body_size 20M;

   # Direct Static Serving for Uploaded Images & Resumes
   location /uploads/ {
       alias /www/wwwroot/hkrion.com/public/uploads/;
       expires 30d;
       add_header Cache-Control "public, no-transform";
       access_log off;
   }
   ```
3. Save and **Reload NGINX**.

### 3. SSL / Free Let's Encrypt Certificate
1. In Website **Settings** ➔ Open **SSL** tab ➔ Select **Let's Encrypt**.
2. Select your domain name, click **Apply**, and enable **Force HTTPS**.

---

## 🔄 Applying Code Updates (Quick Re-Deploying)

When you make changes to code locally and upload/pull new updates to VPS, run this update script:

```bash
cd /www/wwwroot/hkrion.com
git pull # Or upload updated zip
npm install
chmod -R 777 public/uploads
node node_modules/prisma/build/index.js generate
node node_modules/prisma/build/index.js db push
npm run build
pm2 restart hkrion-app
```

---

## 🛠️ Maintenance & Useful PM2 Commands

| Command                      | Action                                     |
| :--------------------------- | :----------------------------------------- |
| `pm2 status`                 | View status of all running Node processes  |
| `pm2 logs hkrion-app`        | Stream real-time production server logs    |
| `pm2 restart hkrion-app`     | Restart application with zero downtime     |
| `pm2 stop hkrion-app`        | Stop application process                   |
| `pm2 delete hkrion-app`      | Delete application process from PM2 memory |
| `curl http://127.0.0.1:3000` | Test local application response            |

---

## 🐞 Common Deployment Troubleshooting

- **Symlink Permission Denied (`/node_modules/.bin/prisma: Permission denied`)**:
  - *Fix*: Execute Prisma directly via Node runtime: `node node_modules/prisma/build/index.js generate` & `node node_modules/prisma/build/index.js db push`.
- **Environment variable not found: DATABASE_URL**:
  - *Fix*: Ensure `.env` file exists at `/www/wwwroot/hkrion.com/.env` containing `DATABASE_URL="mysql://user:pass@127.0.0.1:3306/dbname"`.
- **Image / Resume Upload Error (`EACCES: permission denied`)**:
  - *Fix*: Run `mkdir -p public/uploads/avatars public/uploads/resumes && chmod -R 777 public/uploads`.
- **413 Request Entity Too Large Error on File Upload**:
  - *Fix*: Add `client_max_body_size 20M;` to NGINX website config in aaPanel.

---

_Updated & Verified for HKRION (Pvt) Ltd Production System._
