import { NextRequest, NextResponse } from "next/server";
import { SettingsService } from "@/services/settings.service";
import { SessionManager } from "@/core/auth/session";

export async function POST(req: NextRequest) {
  try {
    const session = await SessionManager.getCurrentSession();
    if (!session || session.role !== "ADMIN") {
      return NextResponse.redirect(new URL("/login?error=Unauthorized", req.url), { status: 303 });
    }

    const contentType = req.headers.get("content-type") || "";
    let data: Record<string, string> = {};
    let redirectTab = "social";

    if (contentType.includes("application/x-www-form-urlencoded")) {
      const formData = await req.formData();
      formData.forEach((value, key) => {
        data[key] = value.toString().trim();
      });
      redirectTab = (data._tab as string) || "social";
    } else if (contentType.includes("application/json")) {
      data = await req.json();
      redirectTab = (data._tab as string) || "social";
    }

    // Clean up internal keys
    delete data._tab;

    await SettingsService.updateSettings(data);

    if (contentType.includes("application/json")) {
      return NextResponse.json({ success: true, message: "Settings updated successfully" });
    }

    return NextResponse.redirect(
      new URL(`/admin/settings?tab=${encodeURIComponent(redirectTab)}&success=${encodeURIComponent("Settings saved successfully!")}`, req.url),
      { status: 303 }
    );
  } catch (error) {
    console.error("Error updating settings:", error);
    return NextResponse.redirect(
      new URL(`/admin/settings?error=${encodeURIComponent("Failed to update settings. Please try again.")}`, req.url),
      { status: 303 }
    );
  }
}

export async function GET() {
  try {
    const settings = await SettingsService.getSettings();
    return NextResponse.json(settings);
  } catch (error) {
    console.error("Error fetching settings:", error);
    return NextResponse.json({ error: "Failed to fetch settings" }, { status: 500 });
  }
}
