/**
 * Central site configuration and default values for Faizan Gems.
 * Serves as the single source of truth for contact details, banking info,
 * showroom addresses, and fallback values used across the application.
 */

export const SITE_CONFIG = {
  name: "Faizan Gems",
  legalName: "Faizan Gems (Pvt) Ltd",
  slogan: "From the Heart of Sri Lanka to the World.",
  tagline: "Natural Gemstones • Custom Jewellery • Trusted Service",

  contact: {
    phone: "+94 76 1119 823",
    cleanPhone: "94761119823",
    secondaryPhone: "+94 76 8671 219",
    landline: "+94 76 8671 219",
    email: "faizangems2025@gmail.com",
    adminEmail: "admin@faizangems.com",
    responseTime: "Direct response within 2 business hours",
    hours: "Monday - Saturday, 9:00 AM - 6:00 PM",
  },

  showroom: {
    address: "No. 283/2, N.C Road, Trincomalee",
    city: "Trincomalee",
    country: "Sri Lanka",
    fullAddress: "283/2, N.C. Road, Trincomalee, Sri Lanka.",
    badge: "Corporate Headquarters & Flagship",
    phone: "076 111 9823",
  },

  branches: {
    kalutara: {
      title: "Kalutara Office",
      badge: "Regional Trading Office",
      address: "20A, Galle Road, Kalutara, Sri Lanka.",
      phone: "076 867 1219",
    },
  },

  banking: {
    bankName: "Commercial Bank of Ceylon PLC",
    bankShortName: "Commercial Bank",
    branchName: "Colombo Branch",
    accountName: "Faizan Gems (Pvt) Ltd",
    accountNumber: "100048299104",
    formattedAccountNumber: "1000 4829 9104",
    swiftCode: "COMBCEKLXXX",
    bankLogo: "/uploads/branding/logo-1789653683835-xcn16w.png",
  },

  founder: {
    name: "Riyas Abdul Aziz (JP)",
    title: "CEO / Founder",
    credentials: "BSc in Psychology & Counselling",
    greeting: "Assalamu Alaikum and warm greetings,",
    image: "/uploads/gemstones/gem-1789653683835-gt09cd.webp",
  },

  branding: {
    headerLogo: "/faizan-gems-logo.png",
    footerLogo: "/faizan-gems-logo.png",
  },

  exchangeRates: {
    defaultLkrRate: 300,
  },
} as const;

export const DEFAULT_LKR_RATE = SITE_CONFIG.exchangeRates.defaultLkrRate;

export const HERO_ROUTES = ["/", "/about"] as const;

export function isHeroRoute(pathname?: string | null): boolean {
  if (!pathname) return false;
  return HERO_ROUTES.includes(pathname as (typeof HERO_ROUTES)[number]);
}
