"use client";

import { useState, useEffect } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import { updateProfile, updatePassword } from "@/actions/settings";
import { 
  User, 
  KeyRound, 
  Camera, 
  Check, 
  AlertTriangle, 
  Loader2, 
  ShieldCheck, 
  UserCog, 
  Mail, 
  Phone, 
  Building, 
  Calendar, 
  Palette, 
  Sun, 
  Moon, 
  Laptop, 
  ChevronRight, 
  Lock, 
  Eye, 
  EyeOff, 
  Trash2,
  Sparkles,
  Info
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/ui/page-header";
import { useTheme } from "@/components/theme-provider";
import { toast } from "sonner";

type UserData = {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone: string | null;
  role: "SUPER_ADMIN" | "MANAGER" | "EMPLOYEE";
  profileImage: string | null;
  createdAt: Date;
  position: {
    title: string;
  } | null;
};

type TabType = "profile" | "security" | "appearance";

export default function SettingsClient({ user }: { user: UserData }) {
  const searchParams = useSearchParams();
  const router = useRouter();
  
  const tabParam = searchParams.get("tab") as TabType | null;
  const initialTab: TabType = (tabParam === "security" || tabParam === "appearance") ? tabParam : "profile";
  
  const [activeTab, setActiveTab] = useState<TabType>(initialTab);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(user.profileImage);

  // Password fields state
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [newPassword, setNewPassword] = useState("");

  const { theme, setTheme } = useTheme();

  // Sync tab with URL
  useEffect(() => {
    const current = searchParams.get("tab") as TabType | null;
    if (current === "profile" || current === "security" || current === "appearance") {
      setActiveTab(current);
    }
  }, [searchParams]);

  const handleTabChange = (newTab: TabType) => {
    setActiveTab(newTab);
    setError(null);
    router.push(`/dashboard/settings?tab=${newTab}`, { scroll: false });
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError("Image size must be less than 5MB");
        toast.error("Image size must be less than 5MB");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    setPreviewImage(null);
  };

  const handleProfileSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    const formData = new FormData(e.currentTarget);
    const res = await updateProfile(formData);

    if (res.error) {
      setError(res.error);
      toast.error(res.error);
    } else {
      toast.success("Profile updated successfully!");
      router.refresh();
    }
    setIsLoading(false);
  };

  const handlePasswordSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    const formData = new FormData(e.currentTarget);
    const pass = formData.get("newPassword") as string;
    const confirm = formData.get("confirmPassword") as string;

    if (pass !== confirm) {
      setError("New passwords do not match.");
      toast.error("New passwords do not match.");
      setIsLoading(false);
      return;
    }

    const res = await updatePassword(formData);

    if (res.error) {
      setError(res.error);
      toast.error(res.error);
    } else {
      toast.success("Password updated successfully!");
      (e.target as HTMLFormElement).reset();
      setNewPassword("");
    }
    setIsLoading(false);
  };

  // Password strength calculation
  const getPasswordStrength = (pass: string) => {
    if (!pass) return { score: 0, label: "", color: "" };
    let score = 0;
    if (pass.length >= 8) score += 1;
    if (/[A-Z]/.test(pass)) score += 1;
    if (/[0-9]/.test(pass)) score += 1;
    if (/[^A-Za-z0-9]/.test(pass)) score += 1;

    switch (score) {
      case 1:
        return { score: 1, label: "Weak", color: "bg-error" };
      case 2:
        return { score: 2, label: "Fair", color: "bg-amber-500" };
      case 3:
        return { score: 3, label: "Good", color: "bg-primary" };
      case 4:
        return { score: 4, label: "Strong", color: "bg-success" };
      default:
        return { score: 1, label: "Too Short", color: "bg-error" };
    }
  };

  const passwordStrength = getPasswordStrength(newPassword);

  return (
    <div className="space-y-6">
      
      {/* 1. Header & Breadcrumb */}
      <PageHeader 
        title="Account Settings"
        description="Manage your personal profile details, authentication credentials, and workspace appearance."
      />

      {/* 2. Modern Tab Navigation Bar */}
      <div className="flex items-center gap-2 border-b border-border pb-px overflow-x-auto">
        <button
          type="button"
          onClick={() => handleTabChange("profile")}
          className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === "profile"
              ? "border-primary text-primary font-semibold bg-primary-soft/30 rounded-t-lg"
              : "border-transparent text-text-secondary hover:text-text-primary hover:border-border"
          }`}
        >
          <User className="h-4 w-4" />
          <span>Personal Profile</span>
        </button>

        <button
          type="button"
          onClick={() => handleTabChange("security")}
          className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === "security"
              ? "border-primary text-primary font-semibold bg-primary-soft/30 rounded-t-lg"
              : "border-transparent text-text-secondary hover:text-text-primary hover:border-border"
          }`}
        >
          <KeyRound className="h-4 w-4" />
          <span>Security & Password</span>
        </button>

        <button
          type="button"
          onClick={() => handleTabChange("appearance")}
          className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === "appearance"
              ? "border-primary text-primary font-semibold bg-primary-soft/30 rounded-t-lg"
              : "border-transparent text-text-secondary hover:text-text-primary hover:border-border"
          }`}
        >
          <Palette className="h-4 w-4" />
          <span>Appearance & Theme</span>
        </button>
      </div>

      {/* Error Alert Banner */}
      {error && (
        <div className="p-4 rounded-xl bg-error-bg border border-error-border text-error text-sm flex items-start gap-3 shadow-2xs animate-in fade-in">
          <AlertTriangle className="h-5 w-5 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-semibold text-xs">Action Failed</p>
            <p className="text-xs mt-0.5 leading-relaxed">{error}</p>
          </div>
        </div>
      )}

      {/* 3. TAB 1: PERSONAL PROFILE */}
      {activeTab === "profile" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Form Card (8 cols) */}
          <div className="lg:col-span-8 space-y-6">
            <Card className="bg-surface border-border shadow-xs overflow-hidden">
              <CardHeader className="p-5 sm:p-6 border-b border-border">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-primary-soft text-primary">
                      <User className="h-4.5 w-4.5" />
                    </div>
                    <div>
                      <CardTitle className="text-base font-semibold">Personal Information & Photo</CardTitle>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-[10px] font-mono">
                    Profile
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-5 sm:p-6 space-y-6">
                <form onSubmit={handleProfileSubmit} className="space-y-6">
                  
                  {/* Avatar Uploader */}
                  <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 pb-2">
                    <div className="flex flex-col items-center gap-2 shrink-0">
                      <div className="relative group">
                        <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-border bg-surface-secondary flex items-center justify-center shadow-xs transition-all group-hover:border-primary">
                          {previewImage ? (
                            <img src={previewImage} alt="Profile Preview" className="w-full h-full object-cover" />
                          ) : (
                            <div className="flex flex-col items-center justify-center text-primary font-bold text-xl">
                              {user.firstName.charAt(0)}{user.lastName.charAt(0)}
                            </div>
                          )}
                        </div>
                        <label 
                          htmlFor="profileImage"
                          className="absolute bottom-0 right-0 p-2 bg-primary text-white rounded-full shadow-md hover:bg-primary-hover transition-transform active:scale-95 cursor-pointer"
                          title="Upload new photo"
                        >
                          <Camera className="w-3.5 h-3.5" />
                          <input
                            type="file"
                            id="profileImage"
                            name="profileImage"
                            accept="image/*"
                            onChange={handleImageChange}
                            className="hidden"
                          />
                        </label>
                      </div>

                      {previewImage ? (
                        <button 
                          type="button" 
                          onClick={handleRemoveImage}
                          className="text-[11px] text-error hover:underline flex items-center gap-1 cursor-pointer pt-0.5"
                        >
                          <Trash2 className="h-3 w-3" />
                          <span>Remove Photo</span>
                        </button>
                      ) : (
                        <span className="text-[10px] text-text-muted">Max 5MB (PNG, JPG)</span>
                      )}
                    </div>

                    <div className="flex-1 space-y-1 text-center sm:text-left">
                      <h4 className="text-sm font-semibold text-text-primary">
                        {user.firstName} {user.lastName}
                      </h4>
                      <p className="text-xs text-text-secondary">
                        Update your employee display photo. This picture will appear on your topbar profile, audit trails, and task comments.
                      </p>
                      <div className="pt-2 flex flex-wrap items-center gap-2 justify-center sm:justify-start">
                        <label 
                          htmlFor="profileImage"
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-surface-secondary border border-border rounded-lg text-xs font-medium text-text-primary hover:bg-surface transition-colors cursor-pointer"
                        >
                          <Camera className="h-3.5 w-3.5 text-text-secondary" />
                          <span>Choose New Image</span>
                        </label>
                      </div>
                    </div>
                  </div>

                  {/* Name Fields */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label htmlFor="firstName" className="text-xs font-semibold text-text-primary">
                        First Name <span className="text-error">*</span>
                      </Label>
                      <Input
                        id="firstName"
                        name="firstName"
                        type="text"
                        required
                        defaultValue={user.firstName}
                        placeholder="e.g. Alex"
                        className="h-10 text-sm bg-surface-secondary/40 focus:bg-surface transition-colors"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <Label htmlFor="lastName" className="text-xs font-semibold text-text-primary">
                        Last Name <span className="text-error">*</span>
                      </Label>
                      <Input
                        id="lastName"
                        name="lastName"
                        type="text"
                        required
                        defaultValue={user.lastName}
                        placeholder="e.g. Mercer"
                        className="h-10 text-sm bg-surface-secondary/40 focus:bg-surface transition-colors"
                      />
                    </div>
                  </div>

                  {/* Email & Phone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label htmlFor="email" className="text-xs font-semibold text-text-primary">
                        Email Address <span className="text-error">*</span>
                      </Label>
                      <div className="relative">
                        <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-text-muted" />
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          required
                          defaultValue={user.email}
                          placeholder="name@hkrion.com"
                          className="pl-10 h-10 text-sm bg-surface-secondary/40 focus:bg-surface transition-colors font-mono"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <Label htmlFor="phone" className="text-xs font-semibold text-text-primary">
                        Phone Number
                      </Label>
                      <div className="relative">
                        <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-text-muted" />
                        <Input
                          id="phone"
                          name="phone"
                          type="tel"
                          defaultValue={user.phone || ""}
                          placeholder="+94 77 123 4567"
                          className="pl-10 h-10 text-sm bg-surface-secondary/40 focus:bg-surface transition-colors font-mono"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <div className="pt-2 flex justify-end">
                    <Button 
                      type="submit" 
                      disabled={isLoading} 
                      className="gap-2 shadow-sm font-semibold cursor-pointer"
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          <span>Saving Profile...</span>
                        </>
                      ) : (
                        <>
                          <Check className="h-4 w-4" />
                          <span>Save Changes</span>
                        </>
                      )}
                    </Button>
                  </div>

                </form>
              </CardContent>
            </Card>
          </div>

          {/* Right Summary Card (4 cols) */}
          <div className="lg:col-span-4 space-y-6">
            <Card className="bg-surface border-border shadow-xs overflow-hidden">
              <CardHeader className="p-5 sm:p-6 border-b border-border">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-teal-500/10 text-teal-600 dark:text-teal-400">
                      <Building className="h-4.5 w-4.5" />
                    </div>
                    <div>
                      <CardTitle className="text-base font-semibold">Account & Placement</CardTitle>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-[10px] font-mono">
                    System
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-5 sm:p-6 space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-surface-secondary/50 border border-border">
                    <span className="text-xs text-text-secondary">System Role</span>
                    <Badge variant={user.role === "SUPER_ADMIN" ? "default" : "outline"} className="text-xs font-semibold">
                      {user.role}
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-surface-secondary/50 border border-border">
                    <span className="text-xs text-text-secondary">Job Position</span>
                    <span className="text-xs font-semibold text-text-primary">
                      {user.position?.title || "Staff Member"}
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-surface-secondary/50 border border-border">
                    <span className="text-xs text-text-secondary">Member Since</span>
                    <span className="text-xs font-mono text-text-primary">
                      {new Date(user.createdAt).toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                      })}
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-primary-soft/30 border border-primary/20 text-xs text-text-secondary flex items-start gap-2.5">
                  <Info className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                  <p className="text-[11px] leading-relaxed">
                    To modify organizational roles or managerial hierarchy, contact your system administrator.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

        </div>
      )}

      {/* 4. TAB 2: SECURITY & PASSWORD */}
      {activeTab === "security" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Password Form Card (8 cols) */}
          <div className="lg:col-span-8 space-y-6">
            <Card className="bg-surface border-border shadow-xs overflow-hidden">
              <CardHeader className="p-5 sm:p-6 border-b border-border">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-primary-soft text-primary">
                      <KeyRound className="h-4.5 w-4.5" />
                    </div>
                    <div>
                      <CardTitle className="text-base font-semibold">Change Account Password</CardTitle>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-[10px] font-mono">
                    Security
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-5 sm:p-6 space-y-6">
                <form onSubmit={handlePasswordSubmit} className="space-y-4">
                  
                  {/* Current Password */}
                  <div className="space-y-1.5">
                    <Label htmlFor="currentPassword" className="text-xs font-semibold text-text-primary">
                      Current Password <span className="text-error">*</span>
                    </Label>
                    <div className="relative">
                      <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-text-muted" />
                      <Input
                        id="currentPassword"
                        name="currentPassword"
                        type={showCurrentPassword ? "text" : "password"}
                        required
                        placeholder="••••••••"
                        className="pl-10 pr-10 h-10 text-sm bg-surface-secondary/40 focus:bg-surface transition-colors"
                      />
                      <button
                        type="button"
                        onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary transition-colors cursor-pointer"
                        tabIndex={-1}
                      >
                        {showCurrentPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  {/* New Password */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label htmlFor="newPassword" className="text-xs font-semibold text-text-primary">
                        New Password <span className="text-error">*</span>
                      </Label>
                      <div className="relative">
                        <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-text-muted" />
                        <Input
                          id="newPassword"
                          name="newPassword"
                          type={showNewPassword ? "text" : "password"}
                          required
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          placeholder="Min. 8 characters"
                          className="pl-10 pr-10 h-10 text-sm bg-surface-secondary/40 focus:bg-surface transition-colors"
                        />
                        <button
                          type="button"
                          onClick={() => setShowNewPassword(!showNewPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary transition-colors cursor-pointer"
                          tabIndex={-1}
                        >
                          {showNewPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>

                      {/* Live Password Strength Indicator */}
                      {newPassword && (
                        <div className="space-y-1 pt-1">
                          <div className="flex items-center justify-between text-[11px]">
                            <span className="text-text-muted">Strength:</span>
                            <span className="font-medium text-text-primary">{passwordStrength.label}</span>
                          </div>
                          <div className="h-1.5 w-full bg-surface-secondary rounded-full overflow-hidden flex gap-1">
                            <div className={`h-full rounded-full transition-all ${passwordStrength.score >= 1 ? passwordStrength.color : 'bg-transparent'} flex-1`} />
                            <div className={`h-full rounded-full transition-all ${passwordStrength.score >= 2 ? passwordStrength.color : 'bg-transparent'} flex-1`} />
                            <div className={`h-full rounded-full transition-all ${passwordStrength.score >= 3 ? passwordStrength.color : 'bg-transparent'} flex-1`} />
                            <div className={`h-full rounded-full transition-all ${passwordStrength.score >= 4 ? passwordStrength.color : 'bg-transparent'} flex-1`} />
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <Label htmlFor="confirmPassword" className="text-xs font-semibold text-text-primary">
                        Confirm New Password <span className="text-error">*</span>
                      </Label>
                      <div className="relative">
                        <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-text-muted" />
                        <Input
                          id="confirmPassword"
                          name="confirmPassword"
                          type={showConfirmPassword ? "text" : "password"}
                          required
                          placeholder="Re-enter password"
                          className="pl-10 pr-10 h-10 text-sm bg-surface-secondary/40 focus:bg-surface transition-colors"
                        />
                        <button
                          type="button"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary transition-colors cursor-pointer"
                          tabIndex={-1}
                        >
                          {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <div className="pt-2 flex justify-end">
                    <Button 
                      type="submit" 
                      disabled={isLoading} 
                      className="gap-2 shadow-sm font-semibold cursor-pointer"
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          <span>Updating Password...</span>
                        </>
                      ) : (
                        <>
                          <Check className="h-4 w-4" />
                          <span>Update Password</span>
                        </>
                      )}
                    </Button>
                  </div>

                </form>
              </CardContent>
            </Card>
          </div>

          {/* Security Guidelines Card (4 cols) */}
          <div className="lg:col-span-4 space-y-6">
            <Card className="bg-surface border-border shadow-xs overflow-hidden">
              <CardHeader className="p-5 sm:p-6 border-b border-border">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                      <ShieldCheck className="h-4.5 w-4.5" />
                    </div>
                    <div>
                      <CardTitle className="text-base font-semibold">Security Standards</CardTitle>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-[10px] font-mono">
                    Active
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-5 sm:p-6 space-y-4">
                <div className="space-y-2.5 text-xs text-text-secondary leading-relaxed">
                  <div className="flex items-start gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-success mt-1.5 shrink-0" />
                    <span>Must be at least 8 characters in length.</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-success mt-1.5 shrink-0" />
                    <span>Include a combination of uppercase, lowercase, and numbers.</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-success mt-1.5 shrink-0" />
                    <span>All password changes are logged in the HKRiON audit trail.</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

        </div>
      )}

      {/* 5. TAB 3: APPEARANCE & THEME */}
      {activeTab === "appearance" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          <div className="lg:col-span-8 space-y-6">
            <Card className="bg-surface border-border shadow-xs overflow-hidden">
              <CardHeader className="p-5 sm:p-6 border-b border-border">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-primary-soft text-primary">
                      <Palette className="h-4.5 w-4.5" />
                    </div>
                    <div>
                      <CardTitle className="text-base font-semibold">Display Theme Preferences</CardTitle>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-[10px] font-mono">
                    Theme
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-5 sm:p-6 space-y-6">
                
                <p className="text-xs text-text-secondary">
                  Choose your preferred color interface for HKRiON HRM. Settings apply instantly across all dashboard views.
                </p>

                {/* 3 Theme Options */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  
                  {/* Light */}
                  <button
                    type="button"
                    onClick={() => setTheme("light")}
                    className={`p-4 rounded-2xl border-2 text-left space-y-3 transition-all cursor-pointer ${
                      theme === "light"
                        ? "border-primary bg-primary-soft/20 shadow-xs"
                        : "border-border bg-surface-secondary/40 hover:border-text-secondary/40"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="p-2 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400">
                        <Sun className="h-5 w-5" />
                      </div>
                      {theme === "light" && (
                        <span className="h-2 w-2 rounded-full bg-primary" />
                      )}
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold text-text-primary">Light Mode</h4>
                      <p className="text-[11px] text-text-secondary mt-0.5">High daylight contrast</p>
                    </div>
                  </button>

                  {/* Dark */}
                  <button
                    type="button"
                    onClick={() => setTheme("dark")}
                    className={`p-4 rounded-2xl border-2 text-left space-y-3 transition-all cursor-pointer ${
                      theme === "dark"
                        ? "border-primary bg-primary-soft/20 shadow-xs"
                        : "border-border bg-surface-secondary/40 hover:border-text-secondary/40"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="p-2 rounded-xl bg-surface-secondary text-text-secondary">
                        <Moon className="h-5 w-5" />
                      </div>
                      {theme === "dark" && (
                        <span className="h-2 w-2 rounded-full bg-primary" />
                      )}
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold text-text-primary">Dark Mode</h4>
                      <p className="text-[11px] text-text-secondary mt-0.5">Deep forest night theme</p>
                    </div>
                  </button>

                  {/* System */}
                  <button
                    type="button"
                    onClick={() => setTheme("system")}
                    className={`p-4 rounded-2xl border-2 text-left space-y-3 transition-all cursor-pointer ${
                      theme === "system"
                        ? "border-primary bg-primary-soft/20 shadow-xs"
                        : "border-border bg-surface-secondary/40 hover:border-text-secondary/40"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="p-2 rounded-xl bg-teal-500/10 text-teal-600 dark:text-teal-400">
                        <Laptop className="h-5 w-5" />
                      </div>
                      {theme === "system" && (
                        <span className="h-2 w-2 rounded-full bg-primary" />
                      )}
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold text-text-primary">System Sync</h4>
                      <p className="text-[11px] text-text-secondary mt-0.5">Matches OS settings</p>
                    </div>
                  </button>

                </div>

              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-4 space-y-6">
            <Card className="bg-surface border-border shadow-xs overflow-hidden">
              <CardHeader className="p-5 sm:p-6 border-b border-border">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-primary-soft text-primary">
                      <Sparkles className="h-4.5 w-4.5" />
                    </div>
                    <div>
                      <CardTitle className="text-base font-semibold">HKRiON Portal Info</CardTitle>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-[10px] font-mono">
                    v1.0.0
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-5 sm:p-6 space-y-3 text-xs text-text-secondary">
                <p>
                  Internal Enterprise Human Resource & Operations Workspace for HKRiON (Pvt) Ltd.
                </p>
                <div className="pt-2 text-[11px] text-text-muted border-t border-border flex items-center justify-between">
                  <span>Environment</span>
                  <span className="font-mono font-semibold text-text-primary">Production Build</span>
                </div>
              </CardContent>
            </Card>
          </div>

        </div>
      )}

    </div>
  );
}
