import { CreateInvoiceLineDto, CreateInvoicePaymentDto } from './create-invoice.dto';

export class UpdateSaleDto {
  customerId?: string;
  discountType?: string;
  discountAmount?: number;
  taxAmount?: number;
  grandTotal: number;
  notes?: string;
  saleLines: CreateInvoiceLineDto[];
  payments?: CreateInvoicePaymentDto[];
  useAdvance?: boolean;
}
