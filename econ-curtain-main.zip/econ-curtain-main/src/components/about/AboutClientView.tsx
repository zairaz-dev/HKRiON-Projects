"use client";

import { useEffect, useState, useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { motion, useInView } from "framer-motion";
import {
  ArrowRight,
  PhoneCall,
  Compass,
  Check,
} from "lucide-react";
import { AboutPageContentData } from "@/services/about.service";

// Count-up helper component
function CountUpNumber({
  end,
  suffix = "",
  duration = 2000,
}: {
  end: number;
  suffix?: string;
  duration?: number;
}) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-40px" });

  useEffect(() => {
    if (!isInView) return;

    let startTime: number | null = null;
    let animationFrameId: number;

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Smooth easeOutExpo curve for realistic acceleration/deceleration
      const easeProgress = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      const currentVal = Math.floor(easeProgress * end);

      setCount(currentVal);

      if (progress < 1) {
        animationFrameId = requestAnimationFrame(animate);
      } else {
        setCount(end);
      }
    };

    animationFrameId = requestAnimationFrame(animate);

    return () => {
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, [isInView, end, duration]);

  return (
    <span ref={ref} className="tabular-nums">
      {count}
      {suffix}
    </span>
  );
}

const spacesData = [
  {
    id: "residential",
    title: "Homes",
    subtitle: "Residential Interiors",
    desc: "Custom zebra blinds, blackout drapery, and sheer curtains designed for privacy, warmth, and natural light control.",
    image: "/gallery_1.png",
    tag: "Villas & Apartments",
  },
  {
    id: "commercial",
    title: "Workspaces",
    subtitle: "Commercial & Corporate Offices",
    desc: "Anti-glare UV sunscreen roller blinds engineered for high-rise glass facades, conference rooms, and hospitality suites.",
    image: "/gallery_2.png",
    tag: "Offices & Hotels",
  },
  {
    id: "outdoor",
    title: "Outdoor Spaces",
    subtitle: "Patio, Terraces & Restaurants",
    desc: "Motorized retractable canopy awnings and crystal clear monsoon PVC screens creating all-weather outdoor living.",
    image: "/icon_restaurant_1786043029527.png",
    tag: "Terraces & Dining",
  },
];

const expertisePillars = [
  {
    number: "01",
    title: "Custom Solutions",
    desc: "Every window, balcony, and outdoor architecture is unique. We tailor edge-to-edge solutions built precisely for your dimensions.",
  },
  {
    number: "02",
    title: "Quality Materials",
    desc: "We handpick UV-resistant, flame-retardant, and easy-clean textiles engineered for extreme tropical sunlight and rain.",
  },
  {
    number: "03",
    title: "Precision Installation",
    desc: "Our certified technicians conduct millimeter-accurate laser measurement and dust-free turnkey fitting.",
  },
  {
    number: "04",
    title: "Complete Support",
    desc: "From initial design consultation to ongoing motor hub programming and dedicated warranty coverage.",
  },
];

const materialHighlights = [
  {
    title: "Motorized Zebra & Roller Blind Fabrics",
    desc: "High-grade woven textiles with anti-glare solar coatings.",
    image: "/icon_blinds_1786042796413.png",
  },
  {
    title: "Custom Acoustic Blackout Drapery",
    desc: "100% total light barrier with acoustic insulation layers.",
    image: "/icon_curtains_1786042819663.png",
  },
  {
    title: "Architectural Tensioned Shade Sails",
    desc: "Heavy-duty steel cables & high-density polyethylene mesh.",
    image: "/icon_outdoor_1786042845349.png",
  },
  {
    title: "Monsoon Crystal Clear PVC Screens",
    desc: "Optical-grade heavy vinyl protecting terraces from rain & wind.",
    image: "/gallery_4.png",
  },
];

interface AboutClientViewProps {
  content: AboutPageContentData;
}

export default function AboutClientView({ content }: AboutClientViewProps) {
  const whyPointsList = content.whyPoints
    ? content.whyPoints.split(",").map((p) => p.trim()).filter(Boolean)
    : [];

  return (
    <div className="flex flex-col w-full overflow-x-hidden bg-slate-950 text-slate-100 selection:bg-amber-500 selection:text-slate-950">
      {/* 01. CINEMATIC HERO */}
      <section className="relative min-h-[85vh] md:min-h-screen flex items-center justify-center pt-28 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Background Visual with Scale Motion (1.08 -> 1.00) */}
        <motion.div
          initial={{ scale: 1.08 }}
          animate={{ scale: 1.0 }}
          transition={{ duration: 2.0, ease: [0.16, 1, 0.3, 1] }}
          className="absolute inset-0 bg-cover bg-center bg-no-repeat pointer-events-none"
          style={{ backgroundImage: "url('/hero_banner_1786018413238.png')" }}
        />
        {/* Dark Overlay */}
        <div className="absolute inset-0 bg-linear-to-b from-slate-950/90 via-slate-950/80 to-slate-950 pointer-events-none" />

        <div className="relative z-10 max-w-5xl mx-auto text-center flex flex-col items-center pt-6">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 1, y: 0 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-400 text-xs font-black uppercase tracking-widest mb-8"
          >
            <Compass size={14} /> {content.heroBadge || "ABOUT SHADEIT BLINDS"}
          </motion.div>

          {/* Main Headline */}
          <motion.h1
            initial={{ opacity: 1, y: 0 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.2 }}
            className="text-4xl sm:text-6xl md:text-7xl font-extrabold text-white mb-6 leading-tight tracking-tight drop-shadow-2xl"
          >
            {content.heroTitleLine1} <br />
            <span className="text-transparent bg-clip-text bg-linear-to-r from-yellow-400 via-amber-300 to-yellow-500">
              {content.heroTitleHighlight}
            </span>
          </motion.h1>

          {/* Subtext */}
          <motion.p
            initial={{ opacity: 1, y: 0 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.35 }}
            className="text-base sm:text-xl text-slate-300 max-w-2xl mx-auto font-light leading-relaxed mb-10 drop-shadow-md"
          >
            {content.heroSubtitle}
          </motion.p>

          {/* Scroll Indicator */}
          <motion.div
            initial={{ opacity: 1 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8, duration: 1 }}
            className="flex flex-col items-center text-slate-400 text-xs tracking-widest uppercase font-medium gap-2"
          >
            <span className="animate-bounce text-amber-400">↓ Explore Our Story</span>
          </motion.div>
        </div>
      </section>

      {/* 02. BIG BRAND STATEMENT */}
      <section className="py-24 md:py-32 bg-slate-900 px-4 sm:px-6 lg:px-8 border-y border-slate-800 text-center relative overflow-hidden">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 1, y: 0 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.05 }}
            transition={{ duration: 0.8 }}
            className="space-y-6"
          >
            <h2 className="text-3xl sm:text-5xl md:text-6xl font-light text-white leading-tight tracking-tight">
              &quot;{content.statementPrefix} <br />
              <span className="font-extrabold text-transparent bg-clip-text bg-linear-to-r from-yellow-400 to-amber-500">
                {content.statementHighlight}&quot;
              </span>
            </h2>
            <p className="text-slate-300 text-base sm:text-xl font-light max-w-3xl mx-auto leading-relaxed">
              {content.statementDescription}
            </p>
          </motion.div>
        </div>
      </section>

      {/* 03. OUR STORY */}
      <section className="py-24 md:py-32 bg-slate-950 px-4 sm:px-6 lg:px-8 border-b border-slate-900">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left: Featured Image */}
          <motion.div
            initial={{ opacity: 1, scale: 1 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, amount: 0.05 }}
            transition={{ duration: 0.8 }}
            className="relative rounded-3xl overflow-hidden shadow-2xl border border-slate-800 group h-105 sm:h-130"
          >
            <Image
              src={content.storyImageUrl || "/gallery_1.png"}
              alt="SHADEIT Craftsmanship"
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-cover group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-linear-to-t from-slate-950 via-slate-950/30 to-transparent opacity-85" />
            <div className="absolute bottom-6 left-6 right-6 p-5 rounded-2xl bg-slate-900/95 backdrop-blur-md border border-white/10 text-white flex items-center justify-between">
              <div>
                <span className="text-amber-400 text-xs font-bold uppercase tracking-wider block mb-1">
                  {content.storyCardTag || "Established Excellence"}
                </span>
                <p className="font-semibold text-sm sm:text-base">
                  {content.storyCardTitle || "Custom Automated Window Systems"}
                </p>
              </div>
              <span className="text-2xl font-black text-amber-400">
                {content.storyCardYears || "10+ Yrs"}
              </span>
            </div>
          </motion.div>

          {/* Right: Story Content */}
          <motion.div
            initial={{ opacity: 1, x: 0 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.05 }}
            transition={{ duration: 0.8 }}
            className="space-y-6"
          >
            <span className="text-amber-400 text-xs font-black uppercase tracking-widest block">
              {content.storyBadge || "OUR STORY"}
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white leading-tight">
              {content.storyTitle}
            </h2>
            <div className="w-20 h-1 bg-amber-400 rounded-full" />

            <div className="space-y-4">
              <p className="text-slate-300 text-base sm:text-lg leading-relaxed font-light">
                Light & Shade provides sophisticated and innovative window solutions, including curtains, blinds, shades, and fly screens, designed to enhance residential, commercial, and hospitality spaces. With a strong focus on quality, our experienced team delivers personalized service at every stage, from product selection to professional installation, ensuring a smooth and seamless transformation of your space.
              </p>
              <p className="text-slate-400 text-sm sm:text-base leading-relaxed font-light">
                Guided by creativity, transparency, and integrity, we design functional and elegant products that reflect each client’s unique style and requirements. Whether you are a homeowner, business owner, interior designer, or hospitality professional, Light & Shade is your trusted partner in enhancing interiors and exteriors with comfort, style, and innovation.
              </p>
              <p className="text-slate-400 text-sm sm:text-base leading-relaxed font-light">
                With years of industry experience, Light & Shade has grown from a passionate beginning into a trusted provider of premium window solutions. Our diverse portfolio of residential and commercial projects reflects our dedication to delivering beautiful, durable, functional, and customized solutions. Choose Light & Shade for lasting elegance, exceptional quality, and innovation in every window treatment.
              </p>
            </div>

            <div className="pt-4 flex items-center gap-6">
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-center">
                <span className="text-3xl font-black text-amber-400 block">
                  <CountUpNumber end={content.storyStat1Value} suffix="+" />
                </span>
                <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">
                  {content.storyStat1Label || "Years Experience"}
                </span>
              </div>
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-center">
                <span className="text-3xl font-black text-amber-400 block">
                  <CountUpNumber end={content.storyStat2Value} suffix="+" />
                </span>
                <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">
                  {content.storyStat2Label || "Projects Completed"}
                </span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 04. "INSIDE OUR WORK" */}
      <section className="py-24 md:py-32 bg-slate-900 px-4 sm:px-6 lg:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="text-amber-400 text-xs font-black uppercase tracking-widest block mb-2">
              Inside Our Work
            </span>
            <h2 className="text-3xl sm:text-5xl font-extrabold text-white mb-4">
              Spaces We Transform
            </h2>
            <div className="w-20 h-1 bg-amber-400 mx-auto rounded-full mb-6" />
            <p className="text-slate-400 max-w-2xl mx-auto text-base sm:text-lg font-light">
              Explore how our shading architectures elevate homes, workspaces, and outdoor entertainment venues.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {spacesData.map((space, idx) => (
              <motion.div
                key={space.id}
                initial={{ opacity: 1, y: 0 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.05 }}
                transition={{ duration: 0.7, delay: idx * 0.15 }}
                className="group bg-slate-950 rounded-3xl overflow-hidden border border-slate-800 hover:border-amber-400/50 transition-all duration-500 flex flex-col justify-between shadow-2xl hover:-translate-y-1.5"
              >
                <div className="relative h-64 overflow-hidden">
                  <Image
                    src={space.image}
                    alt={space.title}
                    fill
                    sizes="(max-width: 768px) 100vw, 33vw"
                    className="object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-linear-to-t from-slate-950 via-slate-950/20 to-transparent" />
                  <span className="absolute top-4 left-4 bg-slate-900/90 backdrop-blur-md text-amber-400 text-xs font-extrabold px-3 py-1 rounded-full border border-white/10 shadow-lg">
                    {space.tag}
                  </span>
                </div>

                <div className="p-8 flex flex-col grow justify-between">
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-1 group-hover:text-amber-400 transition-colors">
                      {space.title}
                    </h3>
                    <p className="text-xs text-amber-400/80 font-semibold mb-4 uppercase tracking-wider">
                      {space.subtitle}
                    </p>
                    <p className="text-slate-400 text-sm leading-relaxed font-light mb-6">
                      {space.desc}
                    </p>
                  </div>
                  <Link
                    href="/products"
                    className="inline-flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-widest group-hover:underline"
                  >
                    <span>View Solutions</span>
                    <ArrowRight size={16} />
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 05. OUR EXPERTISE */}
      <section className="py-24 md:py-32 bg-slate-950 px-4 sm:px-6 lg:px-8 border-b border-slate-900">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="text-amber-400 text-xs font-black uppercase tracking-widest block mb-2">
              Our Core Pillars
            </span>
            <h2 className="text-3xl sm:text-5xl font-extrabold text-white mb-4">
              Our Expertise & Commitment
            </h2>
            <div className="w-20 h-1 bg-amber-400 mx-auto rounded-full mb-6" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {expertisePillars.map((p, idx) => (
              <motion.div
                key={p.number}
                initial={{ opacity: 1, y: 0 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.05 }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                className="bg-slate-900/90 p-8 rounded-3xl border border-slate-800 hover:border-amber-400/50 transition-all group flex flex-col justify-between shadow-xl"
              >
                <div>
                  <span className="text-3xl font-black text-amber-400/50 group-hover:text-amber-400 transition-colors block mb-4">
                    {p.number}
                  </span>
                  <h3 className="text-xl font-bold text-white mb-3">{p.title}</h3>
                  <p className="text-slate-400 text-sm leading-relaxed font-light">{p.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 06. VERIFIED NUMBERS */}
      <section className="py-16 bg-linear-to-r from-slate-900 via-slate-950 to-slate-900 border-y border-slate-800 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 1, y: 0 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.05 }}
            transition={{ duration: 0.8 }}
            className="grid grid-cols-1 sm:grid-cols-3 gap-8 text-center items-center"
          >
            <div className="space-y-1">
              <div className="text-4xl sm:text-5xl font-black text-transparent bg-clip-text bg-linear-to-r from-yellow-400 to-amber-500">
                <CountUpNumber end={content.storyStat1Value} suffix="+" />
              </div>
              <p className="text-sm font-bold uppercase tracking-wider text-slate-300">Years Experience</p>
              <p className="text-xs text-slate-500 font-light">Industry leading craftsmanship</p>
            </div>

            <div className="space-y-1 sm:border-x sm:border-slate-800 px-4">
              <div className="text-4xl sm:text-5xl font-black text-transparent bg-clip-text bg-linear-to-r from-yellow-400 to-amber-500">
                <CountUpNumber end={content.storyStat2Value} suffix="+" />
              </div>
              <p className="text-sm font-bold uppercase tracking-wider text-slate-300">Projects Completed</p>
              <p className="text-xs text-slate-500 font-light">Villas, offices & hotels</p>
            </div>

            <div className="space-y-1">
              <div className="text-4xl sm:text-5xl font-black text-transparent bg-clip-text bg-linear-to-r from-yellow-400 to-amber-500">
                <CountUpNumber end={100} suffix="%" />
              </div>
              <p className="text-sm font-bold uppercase tracking-wider text-slate-300">Commitment To Quality</p>
              <p className="text-xs text-slate-500 font-light">Certified fitting guaranteed</p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 07. MISSION & VISION */}
      <section className="py-24 md:py-32 bg-slate-950 px-4 sm:px-6 lg:px-8 border-b border-slate-900">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Mission */}
          <motion.div
            initial={{ opacity: 1, y: 0 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.05 }}
            transition={{ duration: 0.7 }}
            className="bg-slate-900 p-10 rounded-3xl border border-slate-800 shadow-2xl flex flex-col justify-between"
          >
            <div>
              <span className="text-amber-400 text-xs font-black uppercase tracking-widest block mb-4">
                OUR MISSION
              </span>
              <h3 className="text-2xl sm:text-3xl font-bold text-white mb-4">
                {content.missionTitle}
              </h3>
              <p className="text-slate-300 text-base leading-relaxed font-light">
                We passionately transform living spaces into glamorous and vibrant environments by delivering innovative, protective, and durable products that add lasting value for all our stakeholders.
              </p>
            </div>
          </motion.div>

          {/* Vision */}
          <motion.div
            initial={{ opacity: 1, y: 0 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.05 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="bg-slate-900 p-10 rounded-3xl border border-slate-800 shadow-2xl flex flex-col justify-between"
          >
            <div>
              <span className="text-amber-400 text-xs font-black uppercase tracking-widest block mb-4">
                OUR VISION
              </span>
              <h3 className="text-2xl sm:text-3xl font-bold text-white mb-4">
                {content.visionTitle}
              </h3>
              <p className="text-slate-300 text-base leading-relaxed font-light">
                To become the most innovative and trusted provider of protective solutions for the built environment.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 08. PRODUCT MATERIAL SHOWCASE */}
      <section className="py-24 md:py-32 bg-slate-900 px-4 sm:px-6 lg:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="text-amber-400 text-xs font-black uppercase tracking-widest block mb-2">
              Material Story
            </span>
            <h2 className="text-3xl sm:text-5xl font-extrabold text-white mb-4">
              Quality You Can See. <br />
              <span className="text-transparent bg-clip-text bg-linear-to-r from-yellow-400 to-amber-500">
                Quality You Can Feel.
              </span>
            </h2>
            <div className="w-20 h-1 bg-amber-400 mx-auto rounded-full mb-6" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {materialHighlights.map((m, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 1, scale: 1 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true, amount: 0.05 }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                className="group bg-slate-950 rounded-3xl overflow-hidden border border-slate-800 hover:border-amber-400/50 transition-all shadow-xl"
              >
                <div className="relative h-48 overflow-hidden">
                  <Image
                    src={m.image}
                    alt={m.title}
                    fill
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 25vw"
                    className="object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-linear-to-t from-slate-950 via-transparent to-transparent opacity-80" />
                </div>
                <div className="p-6">
                  <h4 className="font-bold text-white text-base mb-2 group-hover:text-amber-400 transition-colors">
                    {m.title}
                  </h4>
                  <p className="text-slate-400 text-xs font-light leading-relaxed">{m.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 09. WHY SHADEIT? */}
      <section className="py-24 md:py-32 bg-slate-950 px-4 sm:px-6 lg:px-8 border-b border-slate-900 text-center">
        <div className="max-w-5xl mx-auto">
          <span className="text-amber-400 text-xs font-black uppercase tracking-widest block mb-3">
            {content.whyBadge || "WHY SHADEIT"}
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white mb-6">
            {content.whyTitle}
          </h2>
          <div className="w-20 h-1 bg-amber-400 mx-auto rounded-full mb-12" />

          {whyPointsList.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {whyPointsList.map((item, idx) => (
                <div
                  key={idx}
                  className="p-5 rounded-2xl bg-slate-900 border border-slate-800 text-amber-400 font-bold text-xs sm:text-sm flex flex-col items-center justify-center gap-2 shadow-lg"
                >
                  <Check size={20} className="text-amber-400" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* 10. CINEMATIC CTA */}
      <section className="py-32 bg-linear-to-r from-slate-900 via-slate-950 to-slate-900 relative overflow-hidden px-4 text-center">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,var(--tw-gradient-stops))] from-amber-500/10 via-transparent to-transparent pointer-events-none" />

        <div className="relative z-10 max-w-4xl mx-auto space-y-6">
          <span className="text-amber-400 text-xs font-black uppercase tracking-widest block">
            {content.ctaBadge || "Elevate Your Space"}
          </span>
          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white leading-tight tracking-tight">
            {content.ctaTitle}
          </h2>
          <p className="text-slate-300 text-lg sm:text-xl max-w-2xl mx-auto font-light leading-relaxed">
            {content.ctaSubtitle}
          </p>

          <div className="pt-6 flex justify-center">
            <Link
              href={content.ctaButtonLink || "/contact"}
              className="px-10 py-5 bg-linear-to-r from-primary via-amber-500 to-yellow-500 text-slate-950 font-extrabold rounded-full text-lg hover:brightness-110 transition-all shadow-2xl flex items-center justify-center gap-3 active:scale-95"
            >
              <PhoneCall size={22} />
              <span>{content.ctaButtonText || "Get Free Consultation"}</span>
              <ArrowRight size={20} />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
