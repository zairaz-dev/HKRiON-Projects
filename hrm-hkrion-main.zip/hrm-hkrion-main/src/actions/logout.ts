"use server";

import { deleteSession, getSession } from "@/lib/session";
import { redirect } from "next/navigation";
import { logAudit } from "@/lib/audit";

export async function logout() {
  const session = await getSession();
  if (session) {
    await logAudit(session.userId, "USER_LOGOUT", `User logged out successfully`);
  }
  await deleteSession();
  redirect("/login");
}
