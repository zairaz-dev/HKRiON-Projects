export const CreateSupplierBodySchema = {
  type: 'object',
  properties: {
    name: { type: 'string', example: 'Global Distributors' },
    businessName: { type: 'string', example: 'Global Dist. Ltd.' },
    email: { type: 'string', example: 'sales@globaldist.com' },
    phone: { type: 'string', example: '+1234567800' },
    taxNumber: { type: 'string', example: 'TAX554433' },
    openingBalance: { type: 'number', example: 2000 },
    address: { type: 'string', example: '789 Industrial Area, NY' },
    businessId: { type: 'string', example: 'business-uuid-123' },
    branchIds: { type: 'array', items: { type: 'string' }, example: ['branch-uuid-1'] },
    createdById: { type: 'string', example: 'user-uuid-123' }
  },
  required: ['name', 'businessId']
};

export const UpdateSupplierBodySchema = {
  type: 'object',
  properties: {
    name: { type: 'string', example: 'Global Distributors Inc.' },
    businessName: { type: 'string', example: 'Global Distributors Inc.' },
    email: { type: 'string', example: 'info@globaldist.com' },
    phone: { type: 'string', example: '+1234567800' },
    taxNumber: { type: 'string', example: 'TAX554433' },
    openingBalance: { type: 'number', example: 2500 },
    address: { type: 'string', example: '789 Industrial Area Suite B, NY' },
    businessId: { type: 'string', example: 'business-uuid-123' },
    branchIds: { type: 'array', items: { type: 'string' }, example: ['branch-uuid-1'] },
    updatedById: { type: 'string', example: 'user-uuid-123' }
  },
  required: ['businessId']
};

export const SupplierResponseSchema = {
  type: 'object',
  properties: {
    id: { type: 'string', example: 'supplier-uuid-123' },
    name: { type: 'string', example: 'Global Distributors' },
    businessName: { type: 'string', example: 'Global Dist. Ltd.' },
    email: { type: 'string', example: 'sales@globaldist.com' },
    phone: { type: 'string', example: '+1234567800' },
    taxNumber: { type: 'string', example: 'TAX554433' },
    openingBalance: { type: 'number', example: 2000 },
    address: { type: 'string', example: '789 Industrial Area, NY' },
    businessId: { type: 'string', example: 'business-uuid-123' }
  }
};
