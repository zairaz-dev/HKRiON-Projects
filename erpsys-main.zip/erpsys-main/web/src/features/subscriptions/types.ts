export type SubscriptionStatus = 'TRIAL' | 'ACTIVE' | 'PAST_DUE' | 'EXPIRED' | 'CANCELLED';
export type BillingInterval = 'MONTHLY' | 'YEARLY';
export type SubPaymentStatus = 'PENDING' | 'PAID' | 'FAILED' | 'REFUNDED';

export interface Plan {
  id: string;
  name: string;
  slug: string;
  description?: string | null;
  priceMonthly: number;
  priceYearly: number;
  priceMonthlyUsd?: number;
  priceYearlyUsd?: number;
  currency: string;
  trialDays: number;
  maxBranches: number;
  maxUsers: number;
  maxProducts: number;
  maxInvoicesMonthly: number;
  enablePos: boolean;
  enableImei: boolean;
  enableAccounting: boolean;
  enableSms: boolean;
  enableApiAccess: boolean;
  isActive: boolean;
  isPopular: boolean;
  isCustom?: boolean;
  businessId?: string | null;
  business?: { id: string; name: string; email?: string; phone?: string } | null;
  sortOrder: number;
  subscriptions?: Array<{ id: string; status: SubscriptionStatus; businessId: string }>;
  createdAt?: string;
  updatedAt?: string;
}

export interface SubscriptionInvoice {
  id: string;
  invoiceNumber: string;
  subscriptionId: string;
  businessId: string;
  amount: number;
  taxAmount: number;
  totalAmount: number;
  currency?: string;
  paymentStatus: SubPaymentStatus;
  paymentMethod?: string | null;
  transactionId?: string | null;
  proofUrl?: string | null;
  adminNotes?: string | null;
  approvedAt?: string | null;
  paidAt?: string | null;
  notes?: string | null;
  createdAt: string;
}

export interface SaasBankSetting {
  id: string;
  bankName: string;
  accountName: string;
  accountNumber: string;
  branchName: string;
  swiftCode?: string | null;
  qrImageUrl?: string | null;
  instructions?: string | null;
  isActive: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface BankTransferRequestItem {
  id: string;
  invoiceNumber: string;
  businessId: string;
  businessName: string;
  businessPhone: string;
  businessEmail: string;
  planName: string;
  planId: string;
  billingInterval: BillingInterval;
  amount: number;
  taxAmount: number;
  totalAmount: number;
  paymentStatus: SubPaymentStatus;
  paymentMethod?: string | null;
  transactionId?: string | null;
  proofUrl?: string | null;
  adminNotes?: string | null;
  paidAt?: string | null;
  approvedAt?: string | null;
  createdAt: string;
}

export interface Subscription {
  id: string;
  businessId: string;
  planId: string;
  status: SubscriptionStatus;
  billingInterval: BillingInterval;
  startDate: string;
  endDate: string;
  trialEndsAt?: string | null;
  cancelledAt?: string | null;
  isAutoRenew: boolean;
  plan: Plan;
  invoices?: SubscriptionInvoice[];
  createdAt: string;
  updatedAt: string;
}

export interface UsageItem {
  used: number;
  max: number;
  percentage: number;
}

export interface SubscriptionUsage {
  branches: UsageItem;
  users: UsageItem;
  products: UsageItem;
  invoices: UsageItem;
}

export interface CurrentSubscriptionResponse {
  subscription: Subscription;
  plan: Plan;
  usage: SubscriptionUsage;
  invoices: SubscriptionInvoice[];
}

export interface UpgradeSubscriptionInput {
  planId: string;
  billingInterval: BillingInterval;
  paymentMethod?: string;
  transactionId?: string;
  notes?: string;
}

export interface SuperSubscriptionItem {
  id: string;
  businessId: string;
  businessName: string;
  ownerName: string;
  ownerEmail: string;
  planName: string;
  planSlug: string;
  status: SubscriptionStatus;
  billingInterval: BillingInterval;
  startDate: string;
  endDate: string;
  trialEndsAt?: string | null;
  latestInvoice?: SubscriptionInvoice | null;
  createdAt: string;
}
