import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import {
  verifyCustomerSessionToken,
  verifySessionToken,
  CUSTOMER_SESSION_COOKIE_NAME,
  SESSION_COOKIE_NAME,
  CustomerSessionUser,
  AdminSessionUser,
} from "@/lib/auth";
import {
  getCustomerAddresses,
  saveCustomerAddress,
  updateCustomerAddress,
  deleteCustomerAddress,
} from "@/lib/data/addresses-db";

interface AuthContext {
  customerSession: CustomerSessionUser | null;
  adminSession: AdminSessionUser | null;
  effectiveEmail: string;
  effectiveUserId: string;
}

async function resolveAddressAuth(
  overrideEmail?: string | null
): Promise<{ auth: AuthContext | null; errorResponse: NextResponse | null }> {
  const cookieStore = await cookies();
  const customerToken = cookieStore.get(CUSTOMER_SESSION_COOKIE_NAME)?.value;
  const adminToken = cookieStore.get(SESSION_COOKIE_NAME)?.value;

  const customerSession = customerToken ? verifyCustomerSessionToken(customerToken) : null;
  const adminSession = adminToken ? verifySessionToken(adminToken) : null;

  if (!customerSession && !adminSession) {
    return {
      auth: null,
      errorResponse: NextResponse.json(
        { error: "Authentication required to access saved addresses." },
        { status: 401 }
      ),
    };
  }

  // If customer is logged in, their identity is strictly locked to their session
  if (customerSession) {
    return {
      auth: {
        customerSession,
        adminSession,
        effectiveEmail: customerSession.email.trim().toLowerCase(),
        effectiveUserId: customerSession.id,
      },
      errorResponse: null,
    };
  }

  // If admin is authenticated, they can manage on behalf of a specific user or admin email
  const adminTargetEmail = overrideEmail?.trim().toLowerCase() || adminSession!.email.trim().toLowerCase();
  return {
    auth: {
      customerSession: null,
      adminSession,
      effectiveEmail: adminTargetEmail,
      effectiveUserId: "admin-vault-officer",
    },
    errorResponse: null,
  };
}

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const queryEmail = url.searchParams.get("email");

    const { auth, errorResponse } = await resolveAddressAuth(queryEmail);
    if (errorResponse) return errorResponse;

    const addresses = await getCustomerAddresses(auth!.effectiveEmail, auth!.effectiveUserId);
    return NextResponse.json({ addresses });
  } catch (error) {
    console.error("Error in GET /api/account/addresses:", error);
    return NextResponse.json({ error: "Failed to fetch addresses" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { auth, errorResponse } = await resolveAddressAuth(body.email);
    if (errorResponse) return errorResponse;

    const {
      fullName,
      phone,
      address,
      city,
      district,
      postalCode,
      country = "Sri Lanka",
      isDefault,
    } = body;

    if (!address || !city || !district) {
      return NextResponse.json(
        { error: "Address, city, and state/district are required." },
        { status: 400 }
      );
    }

    const saved = await saveCustomerAddress({
      userId: auth!.effectiveUserId,
      userEmail: auth!.effectiveEmail,
      fullName: (fullName || "").trim(),
      phone: (phone || "").trim(),
      address: address.trim(),
      city: city.trim(),
      district: district.trim(),
      postalCode: postalCode ? postalCode.trim() : "",
      country: (country || "Sri Lanka").trim(),
      isDefault: Boolean(isDefault),
    });

    if (!saved) {
      return NextResponse.json({ error: "Failed to save address" }, { status: 500 });
    }

    return NextResponse.json({ success: true, address: saved });
  } catch (error) {
    console.error("Error in POST /api/account/addresses:", error);
    return NextResponse.json({ error: "Failed to save address" }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { auth, errorResponse } = await resolveAddressAuth(body.email);
    if (errorResponse) return errorResponse;

    const { id, fullName, phone, address, city, district, postalCode, country, isDefault } = body;
    if (!id) {
      return NextResponse.json({ error: "Address ID is required" }, { status: 400 });
    }

    if (!address || !city || !district) {
      return NextResponse.json(
        { error: "Address, city, and state/district are required." },
        { status: 400 }
      );
    }

    const updated = await updateCustomerAddress(id, auth!.effectiveEmail, {
      fullName: (fullName || "").trim(),
      phone: (phone || "").trim(),
      address: address.trim(),
      city: city.trim(),
      district: district.trim(),
      postalCode: postalCode ? postalCode.trim() : "",
      country: country !== undefined ? country.trim() : undefined,
      isDefault: isDefault !== undefined ? Boolean(isDefault) : undefined,
    });

    if (!updated) {
      return NextResponse.json({ error: "Failed to update address" }, { status: 500 });
    }

    return NextResponse.json({ success: true, address: updated });
  } catch (error) {
    console.error("Error in PUT /api/account/addresses:", error);
    return NextResponse.json({ error: "Failed to update address" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const url = new URL(request.url);
    const id = url.searchParams.get("id");
    const queryEmail = url.searchParams.get("email");

    const { auth, errorResponse } = await resolveAddressAuth(queryEmail);
    if (errorResponse) return errorResponse;

    if (!id) {
      return NextResponse.json({ error: "Address ID is required" }, { status: 400 });
    }

    const success = await deleteCustomerAddress(id, auth!.effectiveEmail);
    return NextResponse.json({ success });
  } catch (error) {
    console.error("Error in DELETE /api/account/addresses:", error);
    return NextResponse.json({ error: "Failed to delete address" }, { status: 500 });
  }
}
