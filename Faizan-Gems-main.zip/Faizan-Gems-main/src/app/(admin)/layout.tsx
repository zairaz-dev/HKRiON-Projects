import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Faizan Gems | Vault & Estate Administrative Gateway",
  description: "Secure administrative management, gemstone inventory vault, client concierge, and cryptographic audit.",
};

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
