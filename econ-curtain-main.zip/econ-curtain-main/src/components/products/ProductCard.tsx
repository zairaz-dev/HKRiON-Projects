"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Check, MessageSquare, ArrowRight, X, ChevronLeft, ChevronRight, Maximize2 } from "lucide-react";
import { generateProductWhatsAppLink } from "@/lib/whatsapp";

interface ProductCardProps {
  product: {
    id: string;
    name: string;
    category: string;
    description: string;
    image: string;
    images?: string;
    features: string[];
    isActive: boolean;
  };
  priority?: boolean;
  whatsappNumber: string;
}

export default function ProductCard({ product, priority = false, whatsappNumber }: ProductCardProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Parse images
  let allImages: string[] = [product.image];
  if (product.images) {
    try {
      const parsed = JSON.parse(product.images);
      if (Array.isArray(parsed) && parsed.length > 0) {
        allImages = parsed;
      }
    } catch {
      // fallback to just the main image
    }
  }

  const nextImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev + 1) % allImages.length);
  };

  const prevImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev - 1 + allImages.length) % allImages.length);
  };

  return (
    <>
      {/* Product Card */}
      <div
        className="bg-slate-900/90 rounded-3xl overflow-hidden border border-slate-800/90 hover:border-amber-400/60 transition-all duration-300 group flex flex-col h-full shadow-2xl hover:-translate-y-1.5 opacity-100 cursor-pointer"
        onClick={() => setIsModalOpen(true)}
      >
        {/* Product Image */}
        <div className="relative h-60 overflow-hidden bg-slate-950">
          <Image
            src={allImages[0] || product.image}
            alt={product.name}
            fill
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, (max-width: 1280px) 33vw, 25vw"
            className="object-cover group-hover:scale-110 transition-transform duration-700"
            unoptimized
            priority={priority}
          />
          <div className="absolute inset-0 bg-linear-to-t from-slate-950 via-slate-950/20 to-transparent" />
          
          <div className="absolute top-3 right-3 flex flex-col gap-2 items-end">
            <span className="bg-slate-950/85 backdrop-blur-md text-amber-400 border border-amber-400/30 text-xs font-bold px-3 py-1 rounded-full shadow-lg">
              {product.category}
            </span>
          </div>

          <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity bg-black/60 p-2 rounded-full backdrop-blur-sm border border-white/10 text-white">
             <Maximize2 size={16} />
          </div>
        </div>

        {/* Product Body */}
        <div className="p-6 flex flex-col grow justify-between">
          <div>
            <h3 className="text-xl font-bold text-white mb-2 group-hover:text-amber-400 transition-colors">
              {product.name}
            </h3>
            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed mb-6 font-light">
              {product.description}
            </p>

            {/* Feature Bullets */}
            <div className="pt-4 border-t border-slate-800 mb-6">
              <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-2.5">
                Key Specifications:
              </h4>
              <ul className="space-y-1.5">
                {product.features.map((feature, i) => (
                  <li key={i} className="text-xs text-slate-300 flex items-center gap-2 font-light">
                    <Check size={14} className="text-amber-400 shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-4 border-t border-slate-800/80 flex flex-col gap-2" onClick={(e) => e.stopPropagation()}>
            <a
              href={generateProductWhatsAppLink({
                name: product.name,
                category: product.category,
                description: product.description,
                imageUrl: product.image,
                features: product.features,
              }, whatsappNumber)}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full bg-linear-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-white font-bold py-2.5 px-4 rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95"
            >
              <MessageSquare size={15} />
              <span>Inquire on WhatsApp</span>
            </a>
            <Link
              href="/contact"
              className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-medium py-2.5 px-4 rounded-xl text-xs flex items-center justify-center gap-2 border border-slate-700/80 transition-all active:scale-95"
            >
              <span>Book Site Visit</span>
              <ArrowRight size={14} />
            </Link>
          </div>
        </div>
      </div>

      {/* Image Gallery Modal */}
      {isModalOpen && (
        <div 
          className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200"
          onClick={() => setIsModalOpen(false)}
        >
          <div 
            className="relative w-full max-w-5xl h-[80vh] flex flex-col bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="absolute top-0 left-0 right-0 z-10 flex items-center justify-between p-4 bg-linear-to-b from-black/80 to-transparent">
               <div>
                  <h3 className="text-lg font-bold text-white drop-shadow-md">{product.name}</h3>
                  <span className="text-amber-400 text-xs drop-shadow-md font-medium">{product.category}</span>
               </div>
               <button 
                  onClick={() => setIsModalOpen(false)}
                  className="p-2 bg-black/50 hover:bg-white/20 rounded-full text-white backdrop-blur-md transition-colors"
               >
                 <X size={20} />
               </button>
            </div>

            {/* Main Image Display */}
            <div className="relative flex-grow flex items-center justify-center bg-black/50">
               {allImages.length > 1 && (
                 <>
                   <button 
                     onClick={prevImage}
                     className="absolute left-4 z-10 p-3 bg-black/50 hover:bg-amber-500 hover:text-slate-950 text-white rounded-full backdrop-blur-md transition-all shadow-lg"
                   >
                     <ChevronLeft size={24} />
                   </button>
                   <button 
                     onClick={nextImage}
                     className="absolute right-4 z-10 p-3 bg-black/50 hover:bg-amber-500 hover:text-slate-950 text-white rounded-full backdrop-blur-md transition-all shadow-lg"
                   >
                     <ChevronRight size={24} />
                   </button>
                 </>
               )}

               <div className="relative w-full h-full max-h-full">
                  <Image 
                    src={allImages[currentImageIndex]}
                    alt={`${product.name} - ${currentImageIndex + 1}`}
                    fill
                    className="object-contain"
                    unoptimized
                  />
               </div>
            </div>

            {/* Thumbnails Row */}
            {allImages.length > 1 && (
              <div className="bg-slate-950 p-4 border-t border-slate-800 flex items-center justify-center gap-3 overflow-x-auto">
                 {allImages.map((img, idx) => (
                   <button
                     key={idx}
                     onClick={() => setCurrentImageIndex(idx)}
                     className={`relative w-20 h-20 shrink-0 rounded-lg overflow-hidden border-2 transition-all ${
                       currentImageIndex === idx ? "border-amber-500 scale-105 shadow-[0_0_15px_rgba(245,158,11,0.3)]" : "border-slate-800 opacity-60 hover:opacity-100"
                     }`}
                   >
                     <Image src={img} alt="thumbnail" fill className="object-cover" unoptimized />
                   </button>
                 ))}
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
