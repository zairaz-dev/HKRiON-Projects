'use client';

import { useState, useEffect } from 'react';
import { 
  MapPin, 
  Clock, 
  DollarSign, 
  Send, 
  CheckCircle2, 
  X, 
  Upload, 
  Sparkles, 
  Heart, 
  Zap, 
  Users, 
  Laptop,
  ArrowRight,
  Award
} from 'lucide-react';

interface JobPosition {
  id: string;
  title: string;
  department: 'engineering' | 'design' | 'product' | 'internship';
  location: string;
  type: string;
  salary: string;
  description: string;
  requirements: string[];
  responsibilities: string[];
  badge: string;
}

const culturePerks = [
  {
    icon: Laptop,
    title: 'Work-Life Flexibility',
    desc: 'Choose 100% remote work or hybrid options with flexible working hours.'
  },
  {
    icon: DollarSign,
    title: 'Competitive Compensation',
    desc: 'Above-market salaries, performance bonuses, and annual increments.'
  },
  {
    icon: Zap,
    title: 'Cutting-Edge Tech Stack',
    desc: 'Build with Next.js 16, React 19, TypeScript, Docker, AWS, and IoT hardware.'
  },
  {
    icon: Award,
    title: 'Learning & Certification Budget',
    desc: 'Company-sponsored AWS, Cloud, and technical certification courses.'
  },
  {
    icon: Heart,
    title: 'Health & Wellness Benefits',
    desc: 'Comprehensive medical insurance and wellness stipends for team members.'
  },
  {
    icon: Users,
    title: 'Collaborative Mentorship',
    desc: 'Work directly alongside senior enterprise software architects & founders.'
  }
];

export default function CareersSection() {
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [selectedJob, setSelectedJob] = useState<JobPosition | null>(null);
  const [appliedSuccess, setAppliedSuccess] = useState<boolean>(false);
  const [fileName, setFileName] = useState<string>('');
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Application Form State
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    experience: '1-3 Years',
    portfolioUrl: '',
    coverNote: ''
  });

  const [dynamicJobs, setDynamicJobs] = useState<JobPosition[]>([]);
  const [loadingJobs, setLoadingJobs] = useState<boolean>(true);

  useEffect(() => {
    async function loadJobs() {
      try {
        const res = await fetch('/api/jobs');
        const data = await res.json();
        if (data.jobs && data.jobs.length > 0) {
          setDynamicJobs(data.jobs);
        }
      } catch (err) {
        console.error('Error loading dynamic jobs:', err);
      } finally {
        setLoadingJobs(false);
      }
    }
    loadJobs();
  }, []);

  const filteredJobs = departmentFilter === 'all'
    ? dynamicJobs
    : dynamicJobs.filter(job => job.department === departmentFilter);

  const handleSubmitApplication = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!selectedJob) return;

    if (!resumeFile) {
      setFormError('Please upload your resume file (PDF/DOC/DOCX).');
      return;
    }

    setSubmitting(true);

    try {
      const data = new FormData();
      data.append('jobId', selectedJob.id);
      data.append('jobTitle', selectedJob.title);
      data.append('fullName', formData.fullName);
      data.append('email', formData.email);
      data.append('phone', formData.phone);
      data.append('experience', formData.experience);
      data.append('portfolioUrl', formData.portfolioUrl);
      data.append('coverNote', formData.coverNote);
      data.append('resume', resumeFile);

      const res = await fetch('/api/careers/apply', {
        method: 'POST',
        body: data,
      });

      const resData = await res.json();

      if (!res.ok || resData.error) {
        setFormError(resData.error || 'Failed to submit application.');
        return;
      }

      setAppliedSuccess(true);
      setTimeout(() => {
        setAppliedSuccess(false);
        setSelectedJob(null);
        setFormData({
          fullName: '',
          email: '',
          phone: '',
          experience: '1-3 Years',
          portfolioUrl: '',
          coverNote: ''
        });
        setFileName('');
        setResumeFile(null);
      }, 4000);
    } catch {
      setFormError('An error occurred while submitting your application.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="py-24 bg-black text-white relative overflow-hidden">
      
      {/* Background Ambient Lasers */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-150 h-150 bg-[#1ABE56]/10 blur-[180px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-20">
        
        {/* Careers Hero Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          
          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight">
            Build the Future of <span className="gradient-text">Enterprise Software</span>
          </h1>
          <p className="text-neutral-300 text-base sm:text-lg leading-relaxed">
            Join a forward-thinking software powerhouse crafting intelligent ERPs, IoT automation systems, and high-speed cloud platforms.
          </p>
        </div>

        {/* Company Culture & Perks Grid */}
        <div className="space-y-8">
          <div className="text-center space-y-2">
            <h2 className="text-2xl sm:text-3xl font-bold">Why Build Your Career With Us?</h2>
            <p className="text-xs sm:text-sm text-neutral-400 max-w-xl mx-auto">
              We empower software engineers and designers to innovate without limits in a high-growth environment.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {culturePerks.map((perk, idx) => {
              const PerkIcon = perk.icon;
              return (
                <div
                  key={idx}
                  className="glass-card p-6 rounded-3xl border border-[#1ABE56]/30 bg-neutral-950/80 hover:border-[#1ABE56] hover:bg-black transition-all group shadow-xl"
                >
                  <div className="w-12 h-12 rounded-2xl bg-[#1ABE56]/15 border border-[#1ABE56]/30 flex items-center justify-center mb-4 group-hover:bg-[#1ABE56] transition-all shrink-0">
                    <PerkIcon className="w-6 h-6 text-[#1ABE56] group-hover:text-black transition-colors" />
                  </div>
                  <h3 className="text-lg font-bold text-white mb-1 group-hover:text-[#1ABE56] transition-colors">
                    {perk.title}
                  </h3>
                  <p className="text-xs text-neutral-400 leading-relaxed font-mono">
                    {perk.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Open Positions Section */}
        <div className="space-y-10 pt-8 border-t border-neutral-900">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <span className="text-xs font-mono text-[#1ABE56] uppercase tracking-widest font-bold">HIRING PORTAL</span>
              <h2 className="text-3xl font-extrabold text-white mt-1">Open Positions ({filteredJobs.length})</h2>
            </div>

            {/* Department Filter Buttons */}
            <div className="flex flex-wrap items-center gap-2">
              {[
                { label: 'All Roles', value: 'all' },
                { label: 'Engineering', value: 'engineering' },
                { label: 'Design', value: 'design' },
                { label: 'Product & ERP', value: 'product' },
                { label: 'Internships', value: 'internship' }
              ].map((btn) => (
                <button
                  key={btn.value}
                  onClick={() => setDepartmentFilter(btn.value)}
                  className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer ${
                    departmentFilter === btn.value
                      ? 'bg-[#1ABE56] text-black shadow-[0_0_20px_#1ABE56] border border-white'
                      : 'bg-neutral-950 text-neutral-400 border border-neutral-800 hover:border-[#1ABE56]/50 hover:text-white'
                  }`}
                >
                  {btn.label}
                </button>
              ))}
            </div>
          </div>

          {/* Job Openings Grid */}
          {loadingJobs ? (
            <div className="p-12 text-center glass-card rounded-3xl border border-neutral-900 bg-neutral-950 font-mono text-xs text-neutral-400">
              Loading active job openings from database...
            </div>
          ) : filteredJobs.length === 0 ? (
            <div className="p-12 text-center glass-card rounded-3xl border border-neutral-900 bg-neutral-950 font-mono text-xs text-neutral-400">
              No active job openings available under this department at the moment.
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {filteredJobs.map((job) => (
              <div
                key={job.id}
                className="glass-card p-6 sm:p-8 rounded-3xl border border-[#1ABE56]/30 hover:border-[#1ABE56] bg-neutral-950/90 transition-all duration-300 group flex flex-col justify-between hover:shadow-2xl hover:shadow-[#1ABE56]/20 relative overflow-hidden"
              >
                <div>
                  <div className="flex items-start justify-between mb-4">
                    <span className="text-[10px] font-mono text-[#1ABE56] bg-[#1ABE56]/15 px-3 py-1 rounded-full border border-[#1ABE56]/30 font-bold uppercase tracking-wider">
                      {job.badge}
                    </span>
                    <span className="text-xs font-mono text-neutral-400 flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-[#1ABE56]" />
                      {job.location}
                    </span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-bold text-white group-hover:text-[#1ABE56] transition-colors mb-2">
                    {job.title}
                  </h3>

                  <p className="text-xs text-neutral-300 leading-relaxed mb-6 font-mono">
                    {job.description}
                  </p>

                  <div className="grid grid-cols-2 gap-3 mb-6 font-mono text-xs text-neutral-400">
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-[#1ABE56]" />
                      <span>{job.type}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-[#1ABE56] font-bold">
                      <DollarSign className="w-3.5 h-3.5" />
                      <span>{job.salary}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                  <span className="text-xs font-mono text-neutral-400">
                    Immediate Start
                  </span>

                  <button
                    onClick={() => setSelectedJob(job)}
                    className="glow-btn px-5 py-2.5 rounded-xl text-xs font-bold text-white flex items-center gap-2 cursor-pointer shadow-lg"
                  >
                    <span>Apply Now</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
        </div>

      </div>

      {/* Job Application Modal Drawer */}
      {selectedJob && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl animate-fade-in">
          <div className="relative w-full max-w-2xl glass-card rounded-3xl border border-[#1ABE56] bg-neutral-950 p-6 sm:p-8 shadow-2xl shadow-[#1ABE56]/30 max-h-[90vh] overflow-y-auto space-y-6">
            
            {/* Close Modal */}
            <button
              onClick={() => setSelectedJob(null)}
              className="absolute top-6 right-6 p-2 rounded-full bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800 border border-neutral-800 transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Title */}
            <div>
              <span className="text-xs font-mono text-[#1ABE56] uppercase tracking-widest font-bold">ONLINE APPLICATION</span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
                Apply for {selectedJob.title}
              </h2>
              <p className="text-xs font-mono text-neutral-400 mt-1">
                {selectedJob.location} • {selectedJob.type} • {selectedJob.salary}
              </p>
            </div>

            {appliedSuccess ? (
              <div className="p-8 text-center glass-card rounded-2xl border border-[#1ABE56] bg-[#1ABE56]/10 space-y-4 animate-fade-in">
                <div className="w-16 h-16 rounded-full bg-[#1ABE56] text-black flex items-center justify-center mx-auto shadow-lg shadow-[#1ABE56]/40">
                  <CheckCircle2 className="w-10 h-10 stroke-[2.5]" />
                </div>
                <h3 className="text-2xl font-bold text-white">Application Received!</h3>
                <p className="text-sm text-neutral-300 max-w-md mx-auto font-mono">
                  Thank you for applying to HKRION (Pvt) Ltd. Our talent acquisition team will review your resume and contact you shortly.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmitApplication} className="space-y-4">
                {formError && (
                  <div className="p-4 rounded-xl bg-red-950/80 border border-red-500/50 text-red-300 text-xs flex items-center gap-2">
                    <X className="w-4 h-4 text-red-400 shrink-0 cursor-pointer" onClick={() => setFormError(null)} />
                    <span>{formError}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono text-neutral-300">Full Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Ahamed Ilham"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-neutral-900 border border-[#1ABE56]/30 text-white placeholder-neutral-500 text-xs font-mono focus:outline-none focus:border-[#1ABE56]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono text-neutral-300">Email Address *</label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. ilham@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-neutral-900 border border-[#1ABE56]/30 text-white placeholder-neutral-500 text-xs font-mono focus:outline-none focus:border-[#1ABE56]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono text-neutral-300">Phone Number *</label>
                    <input
                      type="tel"
                      required
                      placeholder="+94 77 50 14 217"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-neutral-900 border border-[#1ABE56]/30 text-white placeholder-neutral-500 text-xs font-mono focus:outline-none focus:border-[#1ABE56]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono text-neutral-300">Years of Experience</label>
                    <select
                      value={formData.experience}
                      onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-neutral-900 border border-[#1ABE56]/30 text-white text-xs font-mono focus:outline-none focus:border-[#1ABE56]"
                    >
                      <option value="Fresh Graduate">Fresh Graduate / Student</option>
                      <option value="1-3 Years">1 - 3 Years</option>
                      <option value="3-5 Years">3 - 5 Years</option>
                      <option value="5+ Years">5+ Years Senior</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono text-neutral-300">Portfolio / GitHub / LinkedIn URL</label>
                  <input
                    type="url"
                    placeholder="https://github.com/yourprofile or https://linkedin.com/in/..."
                    value={formData.portfolioUrl}
                    onChange={(e) => setFormData({ ...formData, portfolioUrl: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-neutral-900 border border-[#1ABE56]/30 text-white placeholder-neutral-500 text-xs font-mono focus:outline-none focus:border-[#1ABE56]"
                  />
                </div>

                {/* File Upload Input */}
                <div className="space-y-1">
                  <label className="text-xs font-mono text-neutral-300">Upload Resume (PDF / DOCX) *</label>
                  <div className="relative border-2 border-dashed border-[#1ABE56]/40 rounded-xl p-4 text-center bg-neutral-900/80 hover:border-[#1ABE56] transition-colors cursor-pointer">
                    <input
                      type="file"
                      required
                      accept=".pdf,.doc,.docx"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          setFileName(file.name);
                          setResumeFile(file);
                        }
                      }}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                    <div className="flex flex-col items-center justify-center space-y-1">
                      <Upload className="w-6 h-6 text-[#1ABE56]" />
                      <span className="text-xs font-mono text-neutral-300">
                        {fileName ? `Selected: ${fileName}` : 'Click or Drag & Drop Resume File Here'}
                      </span>
                      <span className="text-[10px] font-mono text-neutral-500">MAX FILE SIZE 10MB</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono text-neutral-300">Cover Note / Why HKRION?</label>
                  <textarea
                    rows={3}
                    placeholder="Tell us briefly why you want to join HKRION and your key technical highlights..."
                    value={formData.coverNote}
                    onChange={(e) => setFormData({ ...formData, coverNote: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-neutral-900 border border-[#1ABE56]/30 text-white placeholder-neutral-500 text-xs font-mono focus:outline-none focus:border-[#1ABE56]"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="glow-btn w-full py-3.5 rounded-xl font-bold text-black bg-[#1ABE56] flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#1ABE56]/30 hover:scale-[1.02] transition-all disabled:opacity-60"
                  >
                    <Send className="w-4 h-4 text-black" />
                    <span>{submitting ? 'Submitting Application...' : 'Submit Online Application'}</span>
                  </button>
                </div>
              </form>
            )}

          </div>
        </div>
      )}

    </section>
  );
}
