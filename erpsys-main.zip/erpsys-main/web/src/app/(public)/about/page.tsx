"use strict";
"use client";

import React, { useEffect, useState } from "react";
import {
  Shield,
  Zap,
  Cpu,
  Globe,
  Award,
  ArrowRight,
  Info,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { cmsService } from "@/services/cms-service";

export default function AboutPage() {
  const [data, setData] = useState({
    badge: "About Our Platform",
    headline: "Empowering Businesses with Next-Gen ERP Technology",
    subtitle: "HKRION ERP is a premium monorepo-based Enterprise Resource Planning suite designed to streamline retail, inventory, finances, and operations.",
    mission: "We believe that enterprise management software shouldn't be slow, bloated, or complicated. Our mission is to provide businesses of all sizes with a lightning-fast, modular, and exceptionally beautiful ERP platform.",
    architectureStory: "By utilizing a modern monorepo architecture with NestJS and Next.js, HKRION delivers a seamless native-like performance both on the web and as a desktop shell.",
    stats: [
      { label: "Active Businesses", value: "2,500+" },
      { label: "Daily Transactions", value: "$1.2M+" },
      { label: "Server Uptime", value: "99.99%" },
      { label: "Support Resolution", value: "< 2 Hrs" },
    ],
    values: [
      {
        title: "High Performance",
        description: "Optimized for speed and efficiency with a native-feeling desktop and web experience.",
        icon: "Zap",
        color: "text-amber-500 bg-amber-500/10 border-amber-500/20",
      },
      {
        title: "Ironclad Security",
        description: "Your business data is fully encrypted and protected with enterprise-grade security protocols.",
        icon: "Shield",
        color: "text-primary bg-primary/10 border-primary/20",
      },
      {
        title: "Modular Design",
        description: "Scale your business seamlessly by mounting only the modules you need, when you need them.",
        icon: "Cpu",
        color: "text-primary bg-primary/10 border-primary/20",
      },
      {
        title: "Global Scalability",
        description: "Multi-currency, multi-country, and multi-warehouse support built directly into the core.",
        icon: "Globe",
        color: "text-cyan-500 bg-cyan-500/10 border-cyan-500/20",
      },
    ],
  });

  useEffect(() => {
    cmsService.getPageBySlug("about")
      .then((page) => {
        if (page?.content) {
          try {
            const parsed = JSON.parse(page.content);
            if (parsed && typeof parsed === "object") {
              setData((prev) => ({
                ...prev,
                ...parsed,
                values: parsed.values || prev.values,
                stats: parsed.stats || prev.stats,
              }));
            }
          } catch {
            // markdown content
          }
        }
      })
      .catch(() => {});
  }, []);

  const getValueIcon = (iconName: string) => {
    switch (iconName?.toLowerCase()) {
      case "zap": return Zap;
      case "shield": return Shield;
      case "cpu": return Cpu;
      case "globe": return Globe;
      default: return Zap;
    }
  };

  return (
    <div className="bg-transparent text-foreground flex flex-col items-center justify-center p-4 sm:p-6 relative">
      <div className="w-full max-w-5xl mt-6 relative z-10 space-y-16 pb-16">
        {/* Header Section */}
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-sm bg-primary/10 border border-primary/20 text-primary text-[10px] font-bold tracking-wider uppercase font-mono">
            <Info className="w-3.5 h-3.5" /> {data.badge}
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-foreground tracking-tight leading-tight">
            {data.headline}
          </h1>
          <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
            {data.subtitle}
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {data.stats.map((stat, idx) => (
            <Card key={idx} className="bg-card/40 border-border p-6 text-center rounded-sm backdrop-blur-md">
              <p className="text-[10px] font-semibold text-muted-foreground/60 font-mono uppercase tracking-wider">{stat.label}</p>
              <h3 className="text-xl sm:text-3xl font-bold text-foreground mt-1 tracking-tight font-mono">{stat.value}</h3>
            </Card>
          ))}
        </div>

        {/* Story Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h2 className="text-xl sm:text-2xl font-bold text-foreground tracking-tight">Our Mission</h2>
            <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
              {data.mission}
            </p>
            <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
              {data.architectureStory}
            </p>
            <div className="flex items-center gap-4 pt-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-primary font-mono">
                <Award className="w-4 h-4" /> ISO 27001 Certified
              </div>
              <div className="w-1.5 h-1.5 rounded-full bg-border" />
              <div className="flex items-center gap-2 text-xs font-semibold text-primary font-mono">
                <Globe className="w-4 h-4" /> Sri Lanka & Global Cloud
              </div>
            </div>
          </div>

          {/* Interactive Graphic Card */}
          <div className="relative group">
            <div className="absolute -inset-0.5 bg-primary/20 rounded-sm blur opacity-20 group-hover:opacity-30 transition duration-500" />
            <Card className="bg-card/40 border-border/80 p-8 relative space-y-6 rounded-sm backdrop-blur-md">
              <div className="space-y-2">
                <div className="w-10 h-10 rounded-sm bg-primary/15 text-primary flex items-center justify-center border border-primary/20">
                  <Cpu className="w-5 h-5" />
                </div>
                <h4 className="text-sm font-bold text-foreground tracking-wider uppercase font-mono mt-4">Platform Architecture</h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Engineered with an isolated multi-tenant sandbox environment. Workspaces (POS, Inventory, Finance) run on dedicated virtual layers for maximum security and zero downtime.
                </p>
              </div>
              <div className="space-y-1.5 font-mono text-[10px] text-muted-foreground/60 border-t border-border/60 pt-4">
                <div>// Core Technologies</div>
                <div className="flex gap-2 text-primary font-bold">
                  <span>• NestJS API</span>
                  <span>• Next.js Web</span>
                  <span>• Prisma ORM</span>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* Core Values Section */}
        <div className="space-y-8">
          <div className="text-center max-w-md mx-auto space-y-1">
            <h2 className="text-xl sm:text-2xl font-bold text-foreground tracking-tight">Our Core Values</h2>
            <p className="text-xs text-muted-foreground mt-1">The principles that guide our product development and engineering.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {data.values.map((val, idx) => {
              const Icon = getValueIcon(val.icon);
              return (
                <Card key={idx} className="bg-card/40 border-border/70 backdrop-blur-md p-6 flex gap-4 items-start rounded-sm hover:border-primary/40 transition-colors">
                  <div className="p-2.5 rounded-sm border bg-primary/10 border-primary/20 text-primary flex-shrink-0">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-foreground">{val.title}</h4>
                    <p className="text-xs text-muted-foreground leading-relaxed">{val.description}</p>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        {/* CTA Banner Card */}
        <Card className="relative overflow-hidden border border-border bg-card/60 backdrop-blur-md p-8 sm:p-10 rounded-sm">
          <div className="absolute top-[-20%] right-[-10%] w-[300px] h-[300px] rounded-full bg-primary/5 blur-[80px] pointer-events-none" />
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-2 text-center md:text-left">
              <h3 className="text-lg sm:text-xl font-bold text-foreground">Ready to grow your business?</h3>
              <p className="text-xs text-muted-foreground max-w-md">
                Get started today by registering your business on our platform or talk to our consultants.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
              <Link href="/register" className="w-full sm:w-auto">
                <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground text-xs h-10 px-6 rounded-sm font-semibold shadow-md shadow-primary/20">
                  Get Started
                </Button>
              </Link>
              <Link href="/contact" className="w-full sm:w-auto">
                <Button variant="outline" className="w-full bg-card/40 border-border hover:bg-muted text-xs h-10 px-6 rounded-sm font-semibold text-foreground transition-all gap-1.5">
                  Contact Us <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
