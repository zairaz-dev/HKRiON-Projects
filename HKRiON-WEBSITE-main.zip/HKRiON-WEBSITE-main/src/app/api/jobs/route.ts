import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

interface RawJobPosting {
  id: string;
  title: string;
  department: string;
  location: string;
  type: string;
  salary: string;
  badge: string;
  description: string;
  requirements: string;
  responsibilities: string;
  status: string;
  createdAt: Date | string;
}

const DEFAULT_SEED_JOBS = [
  {
    id: 'fullstack-nextjs',
    title: 'Senior Full-Stack Next.js Developer',
    department: 'engineering',
    location: 'Remote / Colombo',
    type: 'Full-Time',
    salary: 'LKR 250,000 - 400,000 / mo',
    badge: 'Urgent Hiring',
    description: 'We are seeking an experienced Full-Stack Engineer skilled in Next.js 16, TypeScript, React 19, and Node.js REST/GraphQL APIs to build enterprise SaaS & ERP platforms.',
    requirements: JSON.stringify([
      '3+ years experience with Next.js, React, and TypeScript',
      'Strong expertise in MySQL / PostgreSQL relational databases & Prisma ORM',
      'Experience building RESTful APIs & Microservices architecture',
      'Familiarity with Tailwind CSS, Serverless deployment, and AWS/Docker'
    ]),
    responsibilities: JSON.stringify([
      'Architect and build high-speed enterprise Web & ERP applications',
      'Collaborate with UI/UX designers and backend engineers',
      'Optimize database queries and system performance for 99.9% uptime'
    ]),
    status: 'ACTIVE',
  },
  {
    id: 'mobile-dev',
    title: 'Mobile Application Developer (Flutter / React Native)',
    department: 'engineering',
    location: 'Hybrid (Colombo / Remote)',
    type: 'Full-Time',
    salary: 'LKR 200,000 - 350,000 / mo',
    badge: 'Featured',
    description: 'Join our mobile team to craft fluid, cross-platform Android & iOS applications using Flutter or React Native with offline sync capabilities.',
    requirements: JSON.stringify([
      '2+ years experience building mobile apps with Flutter or React Native',
      'Experience with state management (Bloc, Provider, Redux, Zustand)',
      'Understanding of REST APIs, WebSockets, and Push Notifications',
      'Published apps on Google Play Store or Apple App Store'
    ]),
    responsibilities: JSON.stringify([
      'Develop pixel-perfect mobile interfaces with 60 FPS animations',
      'Integrate biometric security, local SQLite caching, and push alerts',
      'Maintain continuous CI/CD build deployments'
    ]),
    status: 'ACTIVE',
  },
  {
    id: 'erp-architect',
    title: 'Enterprise ERP Solutions Engineer',
    department: 'product',
    location: 'Colombo Tech Hub',
    type: 'Full-Time',
    salary: 'LKR 300,000 - 500,000 / mo',
    badge: 'Enterprise Core',
    description: 'Lead the architecture and implementation of HKRION POS, ERP, and HRM inventory systems for enterprise retail & logistics clients.',
    requirements: JSON.stringify([
      '4+ years in software engineering & enterprise business logic',
      'Deep knowledge of MySQL database indexing, ACID transactions, & security',
      'Experience with HR payroll, attendance telemetry, & inventory workflows'
    ]),
    responsibilities: JSON.stringify([
      'Design modular ERP schemas and automated financial reporting engines',
      'Conduct client technical audits and customize ERP modules',
      'Manage database backups, migration scripts, and zero-downtime releases'
    ]),
    status: 'ACTIVE',
  },
  {
    id: 'ui-ux-designer',
    title: 'UI/UX & Product Designer',
    department: 'design',
    location: 'Hybrid / Remote',
    type: 'Full-Time',
    salary: 'LKR 180,000 - 300,000 / mo',
    badge: 'Creative Team',
    description: 'Design intuitive wireframes, glassmorphic UI design systems, and interactive prototypes in Figma for web apps, ERP dashboards, and mobile apps.',
    requirements: JSON.stringify([
      'Proficiency in Figma, design systems, wireframing, & interactive prototyping',
      'Strong eye for modern dark modes, micro-interactions, & typography',
      'Basic understanding of HTML/CSS capabilities to work with developers'
    ]),
    responsibilities: JSON.stringify([
      'Create high-fidelity visual mockups & reusable component libraries',
      'Conduct user research and simplify complex ERP workflows',
      'Export production-ready assets and design specs'
    ]),
    status: 'ACTIVE',
  },
  {
    id: 'iot-engineer',
    title: 'IoT & Hardware Automation Engineer',
    department: 'engineering',
    location: 'Hybrid / Tech Hub',
    type: 'Full-Time',
    salary: 'LKR 220,000 - 380,000 / mo',
    badge: 'Hardware & Telemetry',
    description: 'Build low-latency MQTT/WebSocket hardware telemetry bridges connecting smart sensors, micro-controllers, and cloud monitoring dashboards.',
    requirements: JSON.stringify([
      'Experience with IoT micro-controllers (ESP32, Raspberry Pi, Arduino)',
      'Knowledge of MQTT, WebSockets, Modbus, and Serial RS485 communication',
      'Proficiency in Node.js, C/C++, or Python for telemetry parsing'
    ]),
    responsibilities: JSON.stringify([
      'Integrate industrial smart sensors with cloud database vaults',
      'Develop real-time threshold alert & remote relay control scripts',
      'Perform hardware testing and gateway deployment'
    ]),
    status: 'ACTIVE',
  },
  {
    id: 'intern-engineer',
    title: 'Software Engineering Intern (Web / Mobile / IoT)',
    department: 'internship',
    location: 'Hybrid / Remote',
    type: 'Internship (6 Months)',
    salary: 'LKR 50,000 - 80,000 / mo',
    badge: 'Growth Program',
    description: 'A paid 6-month intensive internship program for passionate undergraduates or fresh graduates looking to master Next.js, Node.js, and Cloud development.',
    requirements: JSON.stringify([
      'Undergraduate or recent graduate in Computer Science, IT, or Software Engineering',
      'Good foundational knowledge of JavaScript, React, or Python',
      'Enthusiasm to learn enterprise code standards, Git workflow, & Next.js 16'
    ]),
    responsibilities: JSON.stringify([
      'Assist senior engineers in building production components',
      'Write clean, unit-tested code and documentation',
      'Participate in daily agile standups and code reviews'
    ]),
    status: 'ACTIVE',
  }
];

export async function GET() {
  try {
    let jobs: RawJobPosting[] = [];
    try {
      jobs = await prisma.$queryRaw<RawJobPosting[]>`
        SELECT id, title, department, location, type, salary, badge, description, requirements, responsibilities, status, createdAt
        FROM JobPosting
        WHERE status = 'ACTIVE'
        ORDER BY createdAt DESC
      `;
    } catch {
      jobs = [];
    }

    // Seed default jobs if DB table is empty
    if (jobs.length === 0) {
      for (const j of DEFAULT_SEED_JOBS) {
        try {
          await prisma.$executeRaw`
            INSERT INTO JobPosting (id, title, department, location, type, salary, badge, description, requirements, responsibilities, status, createdAt, updatedAt)
            VALUES (${j.id}, ${j.title}, ${j.department}, ${j.location}, ${j.type}, ${j.salary}, ${j.badge}, ${j.description}, ${j.requirements}, ${j.responsibilities}, ${j.status}, NOW(), NOW())
          `;
        } catch {
          // ignore duplicate seed errors
        }
      }

      try {
        jobs = await prisma.$queryRaw<RawJobPosting[]>`
          SELECT id, title, department, location, type, salary, badge, description, requirements, responsibilities, status, createdAt
          FROM JobPosting
          WHERE status = 'ACTIVE'
          ORDER BY createdAt DESC
        `;
      } catch {
        jobs = [];
      }
    }

    // Format requirements & responsibilities
    const formattedJobs = jobs.map((job) => {
      let parsedReqs: string[] = [];
      let parsedResps: string[] = [];

      try {
        parsedReqs = typeof job.requirements === 'string' ? JSON.parse(job.requirements) : [];
      } catch {
        parsedReqs = job.requirements ? job.requirements.split('\n') : [];
      }

      try {
        parsedResps = typeof job.responsibilities === 'string' ? JSON.parse(job.responsibilities) : [];
      } catch {
        parsedResps = job.responsibilities ? job.responsibilities.split('\n') : [];
      }

      return {
        ...job,
        requirements: parsedReqs,
        responsibilities: parsedResps,
      };
    });

    return NextResponse.json({ success: true, jobs: formattedJobs });
  } catch (error) {
    console.error('Error fetching public job postings:', error);
    return NextResponse.json({ error: 'Failed to fetch job postings' }, { status: 500 });
  }
}
