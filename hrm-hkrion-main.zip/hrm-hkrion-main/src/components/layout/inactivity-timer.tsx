"use client";

import { useEffect, useState } from "react";
import { logout } from "@/actions/logout";
import { Modal } from "@/components/ui/modal";
import { Button } from "@/components/ui/button";
import { Clock } from "lucide-react";

export default function InactivityTimer() {
  const [showModal, setShowModal] = useState(false);
  const [timeLeft, setTimeLeft] = useState(60);

  useEffect(() => {
    let timeoutId: NodeJS.Timeout;
    let intervalId: NodeJS.Timeout;

    // 29 minutes of inactivity before warning
    const INACTIVITY_TIME = 29 * 60 * 1000; 
    const WARNING_TIME = 60; // 60 seconds countdown

    const handleLogout = async () => {
      await logout();
    };

    const startWarning = () => {
      setShowModal(true);
      setTimeLeft(WARNING_TIME);
      
      intervalId = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(intervalId);
            handleLogout();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    };

    const resetTimer = () => {
      clearTimeout(timeoutId);
      clearInterval(intervalId);
      
      timeoutId = setTimeout(() => {
        startWarning();
      }, INACTIVITY_TIME);
    };

    // Initialize the timer
    resetTimer();

    // Events to track inactivity (passive tracking when modal is closed)
    const events = ["mousemove", "keydown", "scroll", "click", "touchstart"];
    
    const handleUserActivity = () => {
      if (!document.getElementById("inactivity-modal")) {
        resetTimer();
      }
    };

    events.forEach(event => {
      window.addEventListener(event, handleUserActivity);
    });

    return () => {
      clearTimeout(timeoutId);
      clearInterval(intervalId);
      events.forEach(event => {
        window.removeEventListener(event, handleUserActivity);
      });
    };
  }, []);

  const handleDismiss = () => {
    setShowModal(false);
  };

  return (
    <Modal
      isOpen={showModal}
      onClose={handleDismiss}
      size="sm"
    >
      <div id="inactivity-modal" className="flex flex-col items-center justify-center py-4 text-center">
        <div className="h-12 w-12 rounded-full bg-primary-soft flex items-center justify-center text-primary mb-5 border border-primary/20 shadow-sm">
          <Clock className="h-6 w-6" />
        </div>
        <h3 className="text-lg font-semibold text-text-primary mb-2">Session Expiring Soon</h3>
        <p className="text-sm text-text-secondary mb-6 leading-relaxed">
          Your session is about to expire due to inactivity. You will be securely logged out in <strong className="text-text-primary font-bold">{timeLeft} seconds</strong>.
        </p>
        <Button 
          onClick={handleDismiss} 
          className="w-full text-base py-2.5 h-auto font-medium cursor-pointer"
        >
          Stay Logged In
        </Button>
      </div>
    </Modal>
  );
}
