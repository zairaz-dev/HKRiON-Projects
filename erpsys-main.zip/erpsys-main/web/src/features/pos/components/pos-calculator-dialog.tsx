"use client";

import React, { useState, useEffect } from "react";
import { Dialog } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Calculator, Delete, Equal, RotateCcw } from "lucide-react";

interface POSCalculatorDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export function POSCalculatorDialog({ isOpen, onClose }: POSCalculatorDialogProps) {
  const [display, setDisplay] = useState("0");
  const [equation, setEquation] = useState("");
  const [prevResult, setPrevResult] = useState<number | null>(null);

  useEffect(() => {
    if (isOpen) {
      setDisplay("0");
      setEquation("");
      setPrevResult(null);
    }
  }, [isOpen]);

  const handleDigit = (digit: string) => {
    setDisplay((prev) => (prev === "0" || prev === "Error" ? digit : prev + digit));
  };

  const handleDecimal = () => {
    if (!display.includes(".")) {
      setDisplay((prev) => prev + ".");
    }
  };

  const handleOperator = (op: string) => {
    if (display === "Error") return;
    setEquation(`${display} ${op} `);
    setDisplay("0");
  };

  const handleClear = () => {
    setDisplay("0");
    setEquation("");
    setPrevResult(null);
  };

  const handleBackspace = () => {
    if (display.length <= 1 || display === "Error") {
      setDisplay("0");
    } else {
      setDisplay((prev) => prev.slice(0, -1));
    }
  };

  const handlePercentage = () => {
    try {
      const num = parseFloat(display);
      if (!isNaN(num)) {
        setDisplay(String(num / 100));
      }
    } catch {
      setDisplay("Error");
    }
  };

  const handleCalculate = () => {
    if (!equation) return;
    try {
      const fullExpr = `${equation}${display}`.replace(/×/g, "*").replace(/÷/g, "/");
      // Safe arithmetic evaluation
      const tokens = fullExpr.trim().split(/\s+/);
      if (tokens.length >= 3) {
        const num1 = parseFloat(tokens[0]);
        const op = tokens[1];
        const num2 = parseFloat(tokens[2]);
        let res = 0;
        if (op === "+") res = num1 + num2;
        else if (op === "-") res = num1 - num2;
        else if (op === "*" || op === "×") res = num1 * num2;
        else if (op === "/" || op === "÷") {
          if (num2 === 0) throw new Error("Div by 0");
          res = num1 / num2;
        } else {
          res = num2;
        }

        const formatted = Number.isInteger(res) ? String(res) : String(Number(res.toFixed(4)));
        setDisplay(formatted);
        setEquation("");
        setPrevResult(res);
      }
    } catch {
      setDisplay("Error");
      setEquation("");
    }
  };

  // Keyboard support when calculator modal is open
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key >= "0" && e.key <= "9") {
        e.preventDefault();
        handleDigit(e.key);
      } else if (e.key === ".") {
        e.preventDefault();
        handleDecimal();
      } else if (e.key === "+" || e.key === "-") {
        e.preventDefault();
        handleOperator(e.key);
      } else if (e.key === "*") {
        e.preventDefault();
        handleOperator("×");
      } else if (e.key === "/") {
        e.preventDefault();
        handleOperator("÷");
      } else if (e.key === "Enter" || e.key === "=") {
        e.preventDefault();
        handleCalculate();
      } else if (e.key === "Backspace") {
        e.preventDefault();
        handleBackspace();
      } else if (e.key === "Escape") {
        e.preventDefault();
        onClose();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, display, equation]);

  return (
    <Dialog isOpen={isOpen} onClose={onClose} title="Terminal Calculator" size="md">
      <div className="flex flex-col gap-3 py-2 select-none">
        {/* Screen Display */}
        <div className="bg-muted/60 border border-border rounded p-3 text-right">
          <div className="text-xs text-muted-foreground font-mono h-4 truncate">
            {equation || (prevResult !== null ? `Ans = ${prevResult}` : "")}
          </div>
          <div className="text-2xl font-black font-mono tracking-wider text-foreground truncate mt-1">
            {display}
          </div>
        </div>

        {/* Calculator Button Grid */}
        <div className="grid grid-cols-4 gap-2 pt-1">
          {/* Row 1 */}
          <Button
            type="button"
            variant="outline"
            onClick={handleClear}
            className="h-12 text-sm font-bold text-rose-500 hover:text-rose-400 hover:bg-rose-500/10 border-border"
          >
            C
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={handleBackspace}
            className="h-12 text-sm font-bold border-border"
            title="Backspace"
          >
            <Delete className="h-4 w-4" />
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={handlePercentage}
            className="h-12 text-sm font-bold border-border text-primary"
          >
            %
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => handleOperator("÷")}
            className="h-12 text-base font-bold bg-muted/40 hover:bg-primary/20 text-primary border-border"
          >
            ÷
          </Button>

          {/* Row 2 */}
          <Button
            type="button"
            variant="outline"
            onClick={() => handleDigit("7")}
            className="h-12 text-base font-bold border-border bg-background"
          >
            7
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => handleDigit("8")}
            className="h-12 text-base font-bold border-border bg-background"
          >
            8
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => handleDigit("9")}
            className="h-12 text-base font-bold border-border bg-background"
          >
            9
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => handleOperator("×")}
            className="h-12 text-base font-bold bg-muted/40 hover:bg-primary/20 text-primary border-border"
          >
            ×
          </Button>

          {/* Row 3 */}
          <Button
            type="button"
            variant="outline"
            onClick={() => handleDigit("4")}
            className="h-12 text-base font-bold border-border bg-background"
          >
            4
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => handleDigit("5")}
            className="h-12 text-base font-bold border-border bg-background"
          >
            5
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => handleDigit("6")}
            className="h-12 text-base font-bold border-border bg-background"
          >
            6
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => handleOperator("-")}
            className="h-12 text-base font-bold bg-muted/40 hover:bg-primary/20 text-primary border-border"
          >
            -
          </Button>

          {/* Row 4 */}
          <Button
            type="button"
            variant="outline"
            onClick={() => handleDigit("1")}
            className="h-12 text-base font-bold border-border bg-background"
          >
            1
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => handleDigit("2")}
            className="h-12 text-base font-bold border-border bg-background"
          >
            2
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => handleDigit("3")}
            className="h-12 text-base font-bold border-border bg-background"
          >
            3
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => handleOperator("+")}
            className="h-12 text-base font-bold bg-muted/40 hover:bg-primary/20 text-primary border-border"
          >
            +
          </Button>

          {/* Row 5 */}
          <Button
            type="button"
            variant="outline"
            onClick={() => handleDigit("0")}
            className="h-12 text-base font-bold border-border bg-background col-span-2"
          >
            0
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={handleDecimal}
            className="h-12 text-base font-bold border-border bg-background"
          >
            .
          </Button>
          <Button
            type="button"
            onClick={handleCalculate}
            className="h-12 text-base font-bold bg-primary text-black hover:bg-primary/90"
          >
            =
          </Button>
        </div>
      </div>
    </Dialog>
  );
}
