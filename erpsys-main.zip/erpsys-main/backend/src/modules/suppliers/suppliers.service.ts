import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateSupplierDto } from './dto/create-supplier.dto';
import { UpdateSupplierDto } from './dto/update-supplier.dto';

@Injectable()
export class SuppliersService {
  constructor(private prisma: PrismaService) {}

  async create(createDto: CreateSupplierDto) {
    const { branchIds, ...data } = createDto;

    return this.prisma.supplier.create({
      data: {
        ...data,
        branches: branchIds && branchIds.length > 0
          ? {
              create: branchIds.map((branchId) => ({
                branchId,
              })),
            }
          : undefined,
      },
      include: {
        branches: {
          include: {
            branch: true,
          },
        },
      },
    });
  }

  async findAll(businessId: string, branchId?: string) {
    const whereClause: any = { businessId };

    if (branchId) {
      whereClause.branches = {
        some: { branchId },
      };
    }

    const suppliers = await this.prisma.supplier.findMany({
      where: whereClause,
      include: {
        branches: {
          include: {
            branch: true,
          },
        },
        purchases: {
          select: {
            id: true,
            purchaseNumber: true,
            grandTotal: true,
            amountPaid: true,
            purchaseDate: true,
            paymentStatus: true,
            status: true,
          },
          orderBy: {
            purchaseDate: 'asc',
          },
        },
        purchasePayments: {
          select: {
            id: true,
            amount: true,
          },
        },
        advances: {
          select: {
            id: true,
            amountRemaining: true,
          },
        },
        purchaseReturns: {
          select: {
            id: true,
            grandTotal: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    return suppliers.map((supplier) => {
      const totalPurchases = (supplier.purchases || [])
        .filter((p: any) => p.status !== 'CANCELLED')
        .reduce((sum: number, p: any) => sum + p.grandTotal, 0);
      const totalPayments = (supplier.purchasePayments || []).reduce((sum: number, p: any) => sum + p.amount, 0);
      const totalReturns = (supplier.purchaseReturns || []).reduce((sum: number, r: any) => sum + r.grandTotal, 0);
      const remainingAdvances = (supplier.advances || []).reduce((sum: number, a: any) => sum + a.amountRemaining, 0);
      const totalDue = Math.max(0, (totalPurchases + (supplier.openingBalance || 0)) - (totalPayments + totalReturns + remainingAdvances));
      
      const { purchases, purchasePayments, advances, purchaseReturns, ...rest } = supplier;
      return {
        ...rest,
        outstandingDue: totalDue,
      };
    });
  }

  async findOne(id: string, businessId: string) {
    const supplier = await this.prisma.supplier.findFirst({
      where: { id, businessId },
      include: {
        branches: {
          include: {
            branch: true,
          },
        },
        purchases: {
          select: {
            id: true,
            purchaseNumber: true,
            grandTotal: true,
            amountPaid: true,
            purchaseDate: true,
            paymentStatus: true,
            status: true,
          },
          orderBy: {
            purchaseDate: 'asc',
          },
        },
        purchasePayments: {
          select: {
            id: true,
            paymentNumber: true,
            amount: true,
            paymentDate: true,
            notes: true,
            transactionNo: true,
            purchaseId: true,
            purchase: {
              select: {
                purchaseNumber: true,
              },
            },
            paymentMethod: {
              select: {
                id: true,
                name: true,
                code: true,
              },
            },
          },
          orderBy: {
            paymentDate: 'desc',
          },
        },
        advances: {
          select: {
            id: true,
            advanceNumber: true,
            amount: true,
            amountRemaining: true,
            advanceDate: true,
            notes: true,
            transactionNo: true,
            paymentMethod: {
              select: {
                id: true,
                name: true,
                code: true,
              },
            },
            allocations: {
              select: {
                id: true,
                amount: true,
                purchase: {
                  select: {
                    purchaseNumber: true,
                  },
                },
              },
            },
          },
          orderBy: {
            advanceDate: 'desc',
          },
        },
        purchaseReturns: {
          select: {
            id: true,
            returnNumber: true,
            returnDate: true,
            grandTotal: true,
            purchaseId: true,
            notes: true,
          },
          orderBy: {
            returnDate: 'desc',
          },
        },
      },
    });

    if (!supplier) {
      throw new NotFoundException('Supplier not found');
    }

    const totalPurchases = (supplier.purchases || [])
      .filter((p: any) => p.status !== 'CANCELLED')
      .reduce((sum: number, p: any) => sum + p.grandTotal, 0);
    const totalPayments = (supplier.purchasePayments || []).reduce((sum: number, p: any) => sum + p.amount, 0);
    const totalReturns = (supplier.purchaseReturns || []).reduce((sum: number, r: any) => sum + r.grandTotal, 0);
    const remainingAdvances = (supplier.advances || []).reduce((sum: number, a: any) => sum + a.amountRemaining, 0);
    const totalDue = Math.max(0, (totalPurchases + (supplier.openingBalance || 0)) - (totalPayments + totalReturns + remainingAdvances));

    return {
      ...supplier,
      outstandingDue: totalDue,
    };
  }

  async update(id: string, updateDto: UpdateSupplierDto) {
    const { branchIds, businessId, ...data } = updateDto;

    // Verify it exists
    if (businessId) {
      await this.findOne(id, businessId);
    }

    return this.prisma.$transaction(async (tx) => {
      // Delete existing branch mappings if branchIds is provided
      if (branchIds !== undefined) {
        await tx.supplierBranch.deleteMany({
          where: { supplierId: id },
        });
      }

      return tx.supplier.update({
        where: { id },
        data: {
          ...data,
          branches: branchIds && branchIds.length > 0
            ? {
                create: branchIds.map((branchId) => ({
                  branchId,
                })),
              }
            : undefined,
        },
        include: {
          branches: {
            include: {
              branch: true,
            },
          },
        },
      });
    });
  }

  async remove(id: string, businessId: string) {
    await this.findOne(id, businessId);

    return this.prisma.supplier.delete({
      where: { id },
    });
  }
}
