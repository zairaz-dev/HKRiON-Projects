'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { useRouter } from 'next/navigation';
import DashboardSidebar from '@/components/DashboardSidebar';
import {
  Users,
  UserPlus,
  Shield,
  Briefcase,
  UserCheck,
  Search,
  RefreshCw,
  Edit,
  Trash2,
  Mail,
  CheckCircle,
  AlertCircle,
  X,
  Calendar,
  Camera,
  Upload,
  Loader2
} from 'lucide-react';

interface RoleOption {
  id: string;
  name: string;
  description: string | null;
}

interface UserItem {
  id: string;
  name: string;
  email: string;
  avatar: string | null;
  roleId: string | null;
  roleName: string;
  roleDescription: string | null;
  createdAt: string;
}

export default function UserManagementPage() {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [users, setUsers] = useState<UserItem[]>([]);
  const [roles, setRoles] = useState<RoleOption[]>([]);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRoleFilter, setSelectedRoleFilter] = useState<string>('ALL');

  // Add/Edit Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserItem | null>(null);
  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [userPassword, setUserPassword] = useState('');
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [selectedRoleId, setSelectedRoleId] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Delete Modal State
  const [deletingUser, setDeletingUser] = useState<UserItem | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  // Toast Notification
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const usersRes = await fetch('/api/admin/users');
      if (usersRes.status === 401 || usersRes.status === 403) {
        router.push('/login');
        return;
      }
      const usersData = await usersRes.json();
      if (usersData.users) {
        setUsers(usersData.users);
      }
      if (usersData.currentUserId) {
        setCurrentUserId(usersData.currentUserId);
      }

      const rolesRes = await fetch('/api/admin/roles');
      const rolesData = await rolesRes.json();
      if (rolesData.roles) {
        setRoles(rolesData.roles);
      }
    } catch (err) {
      console.error('Error fetching users/roles:', err);
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleOpenAddModal = () => {
    setEditingUser(null);
    setUserName('');
    setUserEmail('');
    setUserPassword('');
    setAvatarUrl(null);
    const empRole = roles.find((r) => r.name.toUpperCase() === 'EMPLOYEE');
    setSelectedRoleId(empRole ? empRole.id : roles[0]?.id || '');
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (user: UserItem) => {
    setEditingUser(user);
    setUserName(user.name);
    setUserEmail(user.email);
    setUserPassword('');
    setAvatarUrl(user.avatar || null);
    setSelectedRoleId(user.roleId || '');
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingImage(true);
    setFormError(null);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      const data = await res.json();

      if (!res.ok || data.error) {
        setFormError(data.error || 'Failed to upload image.');
        return;
      }

      setAvatarUrl(data.url);
      showToast('Profile image uploaded successfully!');
    } catch {
      setFormError('Failed to upload profile image.');
    } finally {
      setUploadingImage(false);
    }
  };

  const handleSaveUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!userName.trim() || !userEmail.trim()) {
      setFormError('Name and Email are required.');
      return;
    }

    if (!editingUser && !userPassword) {
      setFormError('Password is required for new user creation.');
      return;
    }

    setSubmitting(true);
    try {
      const isEdit = !!editingUser;
      const url = '/api/admin/users';
      const method = isEdit ? 'PUT' : 'POST';
      const body = isEdit
        ? { id: editingUser.id, name: userName, email: userEmail, password: userPassword, roleId: selectedRoleId, avatar: avatarUrl }
        : { name: userName, email: userEmail, password: userPassword, roleId: selectedRoleId, avatar: avatarUrl };

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await res.json();

      if (!res.ok || data.error) {
        setFormError(data.error || 'Failed to save user account.');
        return;
      }

      setIsModalOpen(false);
      showToast(isEdit ? 'User details updated successfully!' : 'New user account created successfully!');
      fetchData();
    } catch {
      setFormError('An error occurred while saving user data.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteUser = async () => {
    if (!deletingUser) return;
    setSubmitting(true);
    setDeleteError(null);

    try {
      const res = await fetch(`/api/admin/users?id=${deletingUser.id}`, {
        method: 'DELETE',
      });

      const data = await res.json();

      if (!res.ok || data.error) {
        setDeleteError(data.error || 'Failed to delete user.');
        return;
      }

      setDeletingUser(null);
      showToast('User account deleted successfully');
      fetchData();
    } catch {
      setDeleteError('An error occurred while deleting user.');
    } finally {
      setSubmitting(false);
    }
  };

  const filteredUsers = users.filter((u) => {
    const matchesSearch =
      u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.roleName.toLowerCase().includes(searchTerm.toLowerCase());

    if (selectedRoleFilter === 'ALL') return matchesSearch;
    return matchesSearch && u.roleName.toUpperCase() === selectedRoleFilter.toUpperCase();
  });

  const totalUsersCount = users.length;
  const adminCount = users.filter((u) => u.roleName.toUpperCase() === 'ADMIN').length;
  const employeeCount = users.filter((u) => u.roleName.toUpperCase() === 'EMPLOYEE').length;
  const customerCount = users.filter((u) => u.roleName.toUpperCase() === 'CUSTOMER').length;

  return (
    <div className="min-h-screen bg-black text-white radial-bg flex">
      {/* Sidebar Navigation */}
      <DashboardSidebar
        userRole="ADMIN"
        userName="HKRION Admin"
        userEmail="admin@hkrion.com"
        activeTab="users"
      />

      {/* Main Content Area */}
      <div className="flex-1 lg:ml-64 flex flex-col min-w-0 min-h-screen">
        {/* Toast Alert */}
        {toastMessage && (
          <div
            className={`fixed top-5 right-5 z-50 px-4 py-3 rounded-xl border flex items-center gap-3 shadow-2xl backdrop-blur-md animate-fade-in ${
              toastMessage.type === 'success'
                ? 'bg-emerald-950/90 border-emerald-500/50 text-emerald-300'
                : 'bg-red-950/90 border-red-500/50 text-red-300'
            }`}
          >
            {toastMessage.type === 'success' ? (
              <CheckCircle className="w-5 h-5 text-emerald-400" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-400" />
            )}
            <span className="text-xs font-semibold">{toastMessage.text}</span>
          </div>
        )}

        {/* Header Bar */}
        <header className="border-b border-[#1ABE56]/20 bg-black/80 backdrop-blur-md sticky top-0 z-30 px-6 py-4 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold font-mono tracking-wide text-white flex items-center gap-2">
              <Users className="w-6 h-6 text-[#1ABE56]" />
              User <span className="text-[#1ABE56]">Management & RBAC</span>
            </h1>
            <p className="text-xs text-neutral-400">
              Manage system access accounts, assign operational roles, and upload profile pictures
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={fetchData}
              className="px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-[#1ABE56]/40 text-neutral-300 hover:text-white text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-[#1ABE56]' : ''}`} />
              Refresh
            </button>

            <button
              onClick={handleOpenAddModal}
              className="glow-btn px-4 py-2.5 rounded-xl text-xs font-semibold text-white flex items-center gap-2 cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              <span>Add New User</span>
            </button>
          </div>
        </header>

        {/* Dashboard Main View */}
        <main className="p-6 sm:p-8 space-y-8 flex-1">
          {/* Key Metric Overview Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="glass-card p-5 rounded-2xl border border-[#1ABE56]/30 bg-black/80 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-[#1ABE56]/20 flex items-center justify-center shrink-0">
                <Users className="w-6 h-6 text-[#1ABE56]" />
              </div>
              <div>
                <p className="text-xs font-mono uppercase text-neutral-400">Total Registered Users</p>
                <h3 className="text-2xl font-bold text-white">{totalUsersCount}</h3>
              </div>
            </div>

            <div className="glass-card p-5 rounded-2xl border border-emerald-500/30 bg-black/80 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center shrink-0">
                <Shield className="w-6 h-6 text-emerald-400" />
              </div>
              <div>
                <p className="text-xs font-mono uppercase text-neutral-400">Administrators</p>
                <h3 className="text-2xl font-bold text-white">{adminCount}</h3>
              </div>
            </div>

            <div className="glass-card p-5 rounded-2xl border border-blue-500/30 bg-black/80 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center shrink-0">
                <Briefcase className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <p className="text-xs font-mono uppercase text-neutral-400">Engineers & Staff</p>
                <h3 className="text-2xl font-bold text-white">{employeeCount}</h3>
              </div>
            </div>

            <div className="glass-card p-5 rounded-2xl border border-purple-500/30 bg-black/80 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center shrink-0">
                <UserCheck className="w-6 h-6 text-purple-400" />
              </div>
              <div>
                <p className="text-xs font-mono uppercase text-neutral-400">Client Accounts</p>
                <h3 className="text-2xl font-bold text-white">{customerCount}</h3>
              </div>
            </div>
          </div>

          {/* Search Bar & Filter Pills */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
              <div className="relative w-full sm:w-80">
                <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  placeholder="Search user by name, email, or role..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-500 focus:outline-none focus:border-[#1ABE56] text-xs transition-colors"
                />
              </div>

              {/* Role filter buttons */}
              <div className="flex items-center p-1 rounded-xl bg-neutral-900 border border-neutral-800 text-xs">
                {['ALL', 'ADMIN', 'EMPLOYEE', 'CUSTOMER'].map((r) => (
                  <button
                    key={r}
                    onClick={() => setSelectedRoleFilter(r)}
                    className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                      selectedRoleFilter === r
                        ? 'bg-[#1ABE56]/20 text-[#1ABE56] font-semibold border border-[#1ABE56]/40'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>

            <div className="text-xs text-neutral-400 font-mono">
              Showing {filteredUsers.length} of {users.length} System Accounts
            </div>
          </div>

          {/* Users Table View */}
          <div className="glass-card rounded-2xl border border-[#1ABE56]/20 bg-black/90 overflow-hidden shadow-2xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-900/90 text-neutral-400 uppercase font-mono border-b border-neutral-800">
                  <tr>
                    <th className="px-6 py-4">User Identity & Profile</th>
                    <th className="px-6 py-4">Assigned Role</th>
                    <th className="px-6 py-4">Account ID</th>
                    <th className="px-6 py-4">Joined Date</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800/60">
                  {filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-12 text-center text-neutral-500">
                        No system users matching &quot;{searchTerm}&quot;.
                      </td>
                    </tr>
                  ) : (
                    filteredUsers.map((user) => {
                      const isCurrentUser = user.id === currentUserId;
                      return (
                        <tr key={user.id} className="hover:bg-neutral-900/40 transition-colors">
                          {/* User Avatar & Name */}
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              {user.avatar ? (
                                <img
                                  src={user.avatar}
                                  alt={user.name}
                                  className="w-10 h-10 rounded-full object-cover border border-[#1ABE56]/50 shadow-md shrink-0"
                                />
                              ) : (
                                <div className="w-10 h-10 rounded-full bg-[#1ABE56]/20 border border-[#1ABE56]/40 flex items-center justify-center text-[#1ABE56] font-bold text-xs font-mono shrink-0">
                                  {user.name.slice(0, 2).toUpperCase()}
                                </div>
                              )}

                              <div>
                                <div className="font-semibold text-white flex items-center gap-1.5">
                                  <span>{user.name}</span>
                                  {isCurrentUser && (
                                    <span className="px-1.5 py-0.2 text-[9px] font-mono rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                                      You
                                    </span>
                                  )}
                                </div>
                                <div className="text-neutral-400 font-mono flex items-center gap-1">
                                  <Mail className="w-3 h-3 text-neutral-500" />
                                  <span>{user.email}</span>
                                </div>
                              </div>
                            </div>
                          </td>

                          {/* Role Badge */}
                          <td className="px-6 py-4">
                            {user.roleName.toUpperCase() === 'ADMIN' ? (
                              <span className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 inline-flex items-center gap-1.5">
                                <Shield className="w-3.5 h-3.5 text-emerald-400" />
                                ADMIN
                              </span>
                            ) : user.roleName.toUpperCase() === 'EMPLOYEE' ? (
                              <span className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/30 inline-flex items-center gap-1.5">
                                <Briefcase className="w-3.5 h-3.5 text-blue-400" />
                                EMPLOYEE
                              </span>
                            ) : (
                              <span className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-purple-500/10 text-purple-400 border border-purple-500/30 inline-flex items-center gap-1.5">
                                <UserCheck className="w-3.5 h-3.5 text-purple-400" />
                                {user.roleName}
                              </span>
                            )}
                          </td>

                          {/* ID */}
                          <td className="px-6 py-4 font-mono text-neutral-400 truncate max-w-xs">
                            {user.id}
                          </td>

                          {/* Date */}
                          <td className="px-6 py-4 text-neutral-400 font-mono">
                            <div className="flex items-center gap-1">
                              <Calendar className="w-3.5 h-3.5 text-neutral-500" />
                              <span>{new Date(user.createdAt).toLocaleDateString()}</span>
                            </div>
                          </td>

                          {/* Actions */}
                          <td className="px-6 py-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => handleOpenEditModal(user)}
                                className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white transition-colors cursor-pointer"
                                title="Edit User Account & Avatar"
                              >
                                <Edit className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => {
                                  setDeletingUser(user);
                                  setDeleteError(null);
                                }}
                                disabled={isCurrentUser}
                                className="p-2 rounded-xl bg-neutral-900 hover:bg-red-950/60 border border-neutral-800 hover:border-red-500/40 text-neutral-400 hover:text-red-400 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                                title={isCurrentUser ? 'Cannot delete your active session account' : 'Delete User Account'}
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>

      {/* CREATE / EDIT USER MODAL WITH PROFILE IMAGE UPLOAD */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="bg-neutral-950 border border-[#1ABE56]/40 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl space-y-0">
            {/* Header */}
            <div className="p-6 border-b border-neutral-900 flex items-center justify-between bg-black/40">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#1ABE56]/20 border border-[#1ABE56]/40 flex items-center justify-center">
                  <UserPlus className="w-5 h-5 text-[#1ABE56]" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white font-mono">
                    {editingUser ? `Edit Account: ${editingUser.name}` : 'Add New System Account'}
                  </h3>
                  <p className="text-xs text-neutral-400">
                    Configure identity, role permissions, and profile picture
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-2 rounded-xl text-neutral-400 hover:text-white bg-neutral-900 border border-neutral-800 hover:border-neutral-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSaveUser} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
              {formError && (
                <div className="p-4 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 text-xs flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 shrink-0 text-red-400" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Profile Image Upload Picker */}
              <div className="flex flex-col items-center justify-center space-y-3 pb-2 border-b border-neutral-900">
                <div className="relative group">
                  {avatarUrl ? (
                    <img
                      src={avatarUrl}
                      alt="Profile preview"
                      className="w-20 h-20 rounded-full object-cover border-2 border-[#1ABE56] shadow-xl"
                    />
                  ) : (
                    <div className="w-20 h-20 rounded-full bg-neutral-900 border-2 border-dashed border-neutral-700 flex flex-col items-center justify-center text-neutral-400 font-mono text-xs">
                      <Camera className="w-6 h-6 text-[#1ABE56] mb-1" />
                      <span>No Photo</span>
                    </div>
                  )}

                  {/* Upload overlay */}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploadingImage}
                    className="absolute inset-0 rounded-full bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white text-[10px] font-mono cursor-pointer border border-[#1ABE56]/50"
                  >
                    {uploadingImage ? (
                      <Loader2 className="w-5 h-5 animate-spin text-[#1ABE56]" />
                    ) : (
                      <>
                        <Upload className="w-4 h-4 mb-0.5" />
                        <span>Change</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Hidden File Input */}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png, image/jpeg, image/webp, image/gif"
                  onChange={handleImageFileChange}
                  className="hidden"
                />

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploadingImage}
                    className="px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 hover:border-[#1ABE56]/40 text-neutral-300 hover:text-white text-xs font-mono flex items-center gap-1.5 cursor-pointer"
                  >
                    {uploadingImage ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-[#1ABE56]" />
                    ) : (
                      <Upload className="w-3.5 h-3.5 text-[#1ABE56]" />
                    )}
                    <span>{avatarUrl ? 'Change Avatar' : 'Upload Profile Picture'}</span>
                  </button>

                  {avatarUrl && (
                    <button
                      type="button"
                      onClick={() => setAvatarUrl(null)}
                      className="px-2.5 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 hover:border-red-500/40 text-neutral-400 hover:text-red-400 text-xs font-mono cursor-pointer"
                    >
                      Remove
                    </button>
                  )}
                </div>
              </div>

              {/* Full Name */}
              <div className="space-y-2">
                <label className="text-xs font-mono text-neutral-300 uppercase font-semibold">
                  Full Name <span className="text-[#1ABE56]">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Alexander Pierce"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-500 focus:outline-none focus:border-[#1ABE56] text-xs"
                />
              </div>

              {/* Email Address */}
              <div className="space-y-2">
                <label className="text-xs font-mono text-neutral-300 uppercase font-semibold">
                  Email Address <span className="text-[#1ABE56]">*</span>
                </label>
                <input
                  type="email"
                  required
                  placeholder="user@hkrion.com"
                  value={userEmail}
                  onChange={(e) => setUserEmail(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-500 focus:outline-none focus:border-[#1ABE56] text-xs font-mono"
                />
              </div>

              {/* Password */}
              <div className="space-y-2">
                <label className="text-xs font-mono text-neutral-300 uppercase font-semibold flex items-center justify-between">
                  <span>{editingUser ? 'Password (Leave blank to keep unchanged)' : 'Initial Account Password'}</span>
                  {!editingUser && <span className="text-[#1ABE56]">*</span>}
                </label>
                <input
                  type="password"
                  required={!editingUser}
                  placeholder={editingUser ? '•••••••••••• (Unchanged)' : 'Enter strong password...'}
                  value={userPassword}
                  onChange={(e) => setUserPassword(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-500 focus:outline-none focus:border-[#1ABE56] text-xs font-mono"
                />
              </div>

              {/* Role Dropdown Selector */}
              <div className="space-y-2">
                <label className="text-xs font-mono text-neutral-300 uppercase font-semibold">
                  Assign System Role <span className="text-[#1ABE56]">*</span>
                </label>
                <select
                  value={selectedRoleId}
                  onChange={(e) => setSelectedRoleId(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white focus:outline-none focus:border-[#1ABE56] text-xs font-mono cursor-pointer"
                >
                  <option value="">Select a Role...</option>
                  {roles.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.name} {r.description ? `- ${r.description}` : ''}
                    </option>
                  ))}
                </select>
              </div>

              {/* Footer */}
              <div className="pt-4 border-t border-neutral-900 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-neutral-300 text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting || uploadingImage}
                  className="glow-btn px-6 py-2.5 rounded-xl text-xs font-semibold text-white flex items-center gap-2 cursor-pointer disabled:opacity-60"
                >
                  {submitting && <RefreshCw className="w-4 h-4 animate-spin" />}
                  <span>{editingUser ? 'Save Changes' : 'Create Account'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE USER CONFIRMATION MODAL */}
      {deletingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="bg-neutral-950 border border-red-500/40 rounded-2xl w-full max-w-md p-6 space-y-6 shadow-2xl">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-red-950/80 border border-red-500/40 flex items-center justify-center shrink-0">
                <AlertCircle className="w-6 h-6 text-red-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-mono">
                  Delete Account &quot;{deletingUser.name}&quot;?
                </h3>
                <p className="text-xs text-neutral-400 mt-1">
                  This action is permanent and will remove access credentials from MySQL Database.
                </p>
              </div>
            </div>

            {deleteError && (
              <div className="p-3 rounded-xl bg-red-950/80 border border-red-500/50 text-red-300 text-xs">
                {deleteError}
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setDeletingUser(null)}
                className="px-4 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteUser}
                disabled={submitting}
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-semibold flex items-center gap-2 cursor-pointer disabled:opacity-60"
              >
                {submitting && <RefreshCw className="w-4 h-4 animate-spin" />}
                <span>Confirm Delete</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
