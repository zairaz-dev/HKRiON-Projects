# HKRION (Pvt) Ltd - Static Asset Storage

Place all project static images, logos, product mockups, and banners in this directory.

## Directory Structure:

- `public/assets/images/` — Hero banners, product mockups, enterprise dashboards.
- `public/assets/logos/` — HKRION brand logos, client logos.
- `public/assets/icons/` — Custom SVG icons & graphics.

## Next.js Usage Example:

```tsx
import Image from 'next/image';

<Image
  src="/assets/images/dashboard-mockup.png"
  alt="HKRION Dashboard"
  width={1280}
  height={720}
/>
```
