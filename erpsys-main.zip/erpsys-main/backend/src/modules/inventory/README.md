# Inventory Module

This module handles backend stock and warehouse management:
- SKU creation and product catalog management
- Stock adjustments and logs
- Low stock alert notifications
- Supplier purchase order processing

## Files to create
- `inventory.controller.ts`: Handles product and stock API endpoints.
- `inventory.service.ts`: Handles stock updates and catalog logic.
- `inventory.module.ts`: NestJS module declaration.
- `dto/create-product.dto.ts`: Input validation for products.
