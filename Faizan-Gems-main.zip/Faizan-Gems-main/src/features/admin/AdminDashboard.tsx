"use client";

import React, { useState, useEffect, useMemo, useCallback } from "react";
import { useRouter, usePathname } from "next/navigation";
import { Gemstone, extractCountryFromOrigin, getSpeciesForType } from "@/types/gemstone";
import { useCurrency } from "@/features/currency/context/CurrencyContext";
import {
  AdminTab,
  AdminOrder,
  AdminOrderStatus,
  SalonInquiry,
  VIPClient,
  AdminUser,
  NewGemstoneForm,
  AdminDashboardProps,
} from "./types";
import { AdminSidebar } from "./components/AdminSidebar";
import { AdminTopbar } from "./components/AdminTopbar";
import { OverviewTab } from "./tabs/OverviewTab";
import { InventoryTab } from "./tabs/InventoryTab";
import { OrdersTab } from "./tabs/OrdersTab";
import { ClientsTab } from "./tabs/ClientsTab";
import { InquiriesTab } from "./tabs/InquiriesTab";
import { CmsTab } from "./tabs/CmsTab";
import { SecurityTab } from "./tabs/SecurityTab";
import { useToast } from "@/components/ui/LuxuryToast";

export default function AdminDashboard({ initialTab = "overview" }: AdminDashboardProps) {
  const router = useRouter();
  const pathname = usePathname();
  const { formatPrice } = useCurrency();
  const { toast, confirm } = useToast();

  // Resolve active tab from URL pathname or initial prop
  const currentTab = useMemo<AdminTab>(() => {
    const p = pathname?.toLowerCase() || "";
    if (p.includes("/inventory")) return "inventory";
    if (p === "/orders" || p === "/orders/") return "orders";
    if (p.includes("/clients")) return "clients";
    if (p.includes("/inquiries")) return "inquiries";
    if (p.includes("/cms")) return "cms";
    if (p.includes("/vault-security") || p.includes("/security") || p.includes("/vaultsecurity")) return "vault_security";
    if (p.includes("/admindashboard")) return "overview";
    if (p === "/admin" || p === "/admin/") return "overview";
    return initialTab;
  }, [pathname, initialTab]);

  const [activeTab, setActiveTab] = useState<AdminTab>(currentTab);

  useEffect(() => {
    setActiveTab(currentTab);
  }, [currentTab]);

  // Handle browser Back / Forward history navigation smoothly
  useEffect(() => {
    const handlePopState = () => {
      const p = window.location.pathname.toLowerCase();
      if (p.includes("/inventory")) setActiveTab("inventory");
      else if (p === "/orders" || p === "/orders/") setActiveTab("orders");
      else if (p.includes("/clients")) setActiveTab("clients");
      else if (p.includes("/inquiries")) setActiveTab("inquiries");
      else if (p.includes("/cms")) setActiveTab("cms");
      else if (p.includes("/vault-security") || p.includes("/security") || p.includes("/vaultsecurity")) setActiveTab("vault_security");
      else if (p.includes("/admindashboard") || p === "/admin" || p === "/admin/") setActiveTab("overview");
    };

    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);

  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null);

  // Gemstones Inventory State
  const [gemstonesList, setGemstonesList] = useState<Gemstone[]>([]);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Orders State
  const [ordersList, setOrdersList] = useState<AdminOrder[]>([]);

  // Clients State (Connected to MySQL)
  const [clientsList, setClientsList] = useState<VIPClient[]>([]);
  const [isLoadingClients, setIsLoadingClients] = useState(false);

  // Inquiries State (Connected to MySQL)
  const [inquiriesList, setInquiriesList] = useState<SalonInquiry[]>([]);
  const [isLoadingInquiries, setIsLoadingInquiries] = useState(false);

  // Fetch Inquiries from MySQL
  const loadInquiries = useCallback(async () => {
    setIsLoadingInquiries(true);
    try {
      const res = await fetch("/api/inquiries");
      if (res.ok) {
        const data = await res.json();
        if (data.inquiries && Array.isArray(data.inquiries)) {
          setInquiriesList(data.inquiries);
        }
      }
    } catch {
      // Keep existing list if offline
    } finally {
      setIsLoadingInquiries(false);
    }
  }, []);

  // Check Admin Session on Mount
  useEffect(() => {
    fetch("/api/admin/me")
      .then((res) => {
        if (res.ok) return res.json();
        throw new Error("Unauthorized");
      })
      .then((data) => {
        if (data.authenticated) {
          setIsAuthenticated(true);
          setAdminUser(data.user);
        } else {
          setIsAuthenticated(false);
          router.replace("/login?from=/admin");
        }
      })
      .catch(() => {
        setIsAuthenticated(false);
        router.replace("/login?from=/admin");
      });
  }, [router]);

  // Fetch Gemstones from MySQL
  const loadGemstones = useCallback(async () => {
    try {
      const res = await fetch("/api/gemstones");
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          setGemstonesList(data);
        }
      }
    } catch {
      // Retain existing list if offline
    }
  }, []);

  // Fetch Orders from MySQL
  const [isLoadingOrders, setIsLoadingOrders] = useState(false);
  const loadOrders = useCallback(async () => {
    setIsLoadingOrders(true);
    try {
      const res = await fetch("/api/orders");
      if (res.ok) {
        const data = await res.json();
        if (data.orders && Array.isArray(data.orders)) {
          setOrdersList(data.orders);
        }
      }
    } catch {
      // Retain existing list if offline
    } finally {
      setIsLoadingOrders(false);
    }
  }, []);

  // Fetch Clients from MySQL
  const loadClients = useCallback(async () => {
    setIsLoadingClients(true);
    try {
      const res = await fetch("/api/clients");
      if (res.ok) {
        const data = await res.json();
        if (data.clients && Array.isArray(data.clients)) {
          setClientsList(data.clients);
        }
      }
    } catch {
      // Retain existing list if offline
    } finally {
      setIsLoadingClients(false);
    }
  }, []);

  // Automatically refresh data when a tab/page is clicked or opened
  const refreshTabData = useCallback((tab: AdminTab) => {
    switch (tab) {
      case "overview":
        loadGemstones();
        loadOrders();
        loadClients();
        loadInquiries();
        break;
      case "inventory":
        loadGemstones();
        break;
      case "orders":
        loadOrders();
        break;
      case "clients":
        loadClients();
        break;
      case "inquiries":
        loadInquiries();
        break;
      default:
        break;
    }
  }, [loadGemstones, loadOrders, loadClients, loadInquiries]);

  // Tab change handler that smoothly pushes URL and triggers fresh database refresh
  const handleTabChange = useCallback((tab: AdminTab) => {
    setActiveTab(tab);
    refreshTabData(tab);
    if (typeof window !== "undefined") {
      const tabPaths: Record<AdminTab, string> = {
        overview: "/admindashboard",
        inventory: "/inventory",
        orders: "/orders",
        clients: "/clients",
        inquiries: "/inquiries",
        cms: "/cms",
        vault_security: "/vault-security",
      };
      const targetHref = tabPaths[tab] || "/admindashboard";
      if (window.location.pathname !== targetHref) {
        window.history.pushState(null, "", targetHref);
      }
    }
  }, [refreshTabData]);

  // Automatically refresh relevant data whenever activeTab changes (mount, URL routing, or browser back/forward)
  useEffect(() => {
    refreshTabData(activeTab);
  }, [activeTab, refreshTabData]);

  // Background polling: check for new customer orders every 25s to power live notifications
  useEffect(() => {
    const timer = setInterval(() => {
      loadOrders();
    }, 25000);
    return () => clearInterval(timer);
  }, [loadOrders]);

  // Helper to identify confirmed/paid transactions
  const isConfirmedPaidOrder = (status?: string | null): boolean => {
    if (!status) return false;
    return ["accepted", "vault_packed", "in_transit", "delivered"].includes(status);
  };

  // Derived Metrics: Total Sales strictly reflects confirmed, paid transactions
  const totalRevenue = useMemo(
    () =>
      ordersList
        .filter((order) => isConfirmedPaidOrder(order.status))
        .reduce((acc, order) => acc + order.total, 0),
    [ordersList]
  );

  const totalVaultValue = useMemo(
    () => gemstonesList.reduce((acc, gem) => acc + gem.price, 0),
    [gemstonesList]
  );

  const activeShipments = useMemo(
    () => ordersList.filter((o) => o.status === "in_transit" || o.status === "vault_packed").length,
    [ordersList]
  );

  const newInquiriesCount = useMemo(
    () => inquiriesList.filter((i) => i.status === "new").length,
    [inquiriesList]
  );

  // Handlers
  const handleLogout = async () => {
    try {
      await fetch("/api/admin/logout", { method: "POST" });
    } finally {
      setIsAuthenticated(false);
      setAdminUser(null);
      router.push("/login");
      router.refresh();
    }
  };

  const handleAddGemstone = async (newGem: NewGemstoneForm) => {
    const primaryVariant = newGem.variants?.[0];
    const imageList =
      newGem.images && newGem.images.length > 0
        ? newGem.images
        : newGem.imageUrl
        ? [newGem.imageUrl]
        : [];

    const parseDimensions = (sizeStr?: string) => {
      if (!sizeStr) return undefined;
      const matches = sizeStr.match(/(\d+(\.\d+)?)/g);
      if (matches && matches.length >= 2) {
        const l = parseFloat(matches[0]);
        const w = parseFloat(matches[1]);
        const d = matches[2] ? parseFloat(matches[2]) : 0;
        if (l > 0 && w > 0) {
          return {
            length: l,
            width: w,
            depth: d,
          };
        }
      }
      return undefined;
    };

    const determinedCountry = newGem.originCountry?.trim() || extractCountryFromOrigin(newGem.origin);
    const determinedSpecies = newGem.species?.trim() || getSpeciesForType(newGem.type);
    const primaryPrice = primaryVariant ? Number(primaryVariant.price) : Number(newGem.price);
    const primaryCarat = primaryVariant ? Number(primaryVariant.weight) : Number(newGem.carat);
    
    // Dynamic rarity score: calculate based on specimen value/weight if not specified
    const calculatedRarity = newGem.rarityScore
      ? Number(newGem.rarityScore)
      : primaryPrice >= 300000 || primaryCarat >= 2.5
      ? 96
      : primaryPrice >= 100000
      ? 93
      : 89;

    const currentMonthYear = new Date().toLocaleDateString("en-US", {
      month: "long",
      year: "numeric",
    });

    const created: Gemstone = {
      id: `gem-vault-${Date.now()}`,
      sku: `GEM-VAULT-${Math.floor(1000 + Math.random() * 9000)}`,
      name: newGem.name || `Faizan Gems Natural ${newGem.type || "Gemstone"}`,
      type: newGem.type,
      variety: newGem.variety || newGem.name || `Natural ${newGem.type || "Gemstone"}`,
      species: determinedSpecies,
      carat: primaryCarat,
      price: primaryPrice,
      dimensions: parseDimensions(primaryVariant?.size || newGem.size),
      cut: newGem.cut,
      cutDetail: newGem.cutDetail || `${newGem.cut} Precision Cut`,
      color: newGem.color,
      colorGrade: newGem.colorGrade || "Intense Vivid",
      clarity: newGem.clarity,
      origin: newGem.origin,
      originCountry: determinedCountry,
      treatment: newGem.treatment || "None (Completely Unheated)",
      isUnheated: Boolean(newGem.isUnheated ?? (newGem.treatment ? newGem.treatment.toLowerCase().includes("unheated") : true)),
      certification: {
        lab: "",
        reportNumber: "",
        issueDate: "",
        verificationUrl: "",
        comments: "",
        originConfirmed: true,
        treatmentConfirmed: newGem.treatment || "None (Completely Unheated)",
        hologramVerified: false,
      },
      images: imageList,
      angles360: imageList,
      variants: newGem.variants && newGem.variants.length > 0 ? newGem.variants : undefined,
      video: newGem.video || undefined,
      inStock: newGem.variants ? newGem.variants.some((v) => v.stock > 0) : (newGem.inStock ?? true),
      featured: true,
      investmentGrade: calculatedRarity >= 95,
      rarityScore: calculatedRarity,
      description: newGem.description,
      story: `A natural unheated ${newGem.type?.toLowerCase() || "gemstone"} of exceptional provenance and crystalline purity.`,
      gemologistNotes: `Natural internal features consistent with ${determinedCountry} geological formation. Verified natural origin.`,
    };

    // Optimistically add to state
    setGemstonesList((prev) => [created, ...prev]);

    // Persist to MySQL database
    try {
      const res = await fetch("/api/gemstones", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(created),
      });
      if (res.ok) {
        await loadGemstones();
        toast.success(
          "Gemstone Added",
          `${created.name} (${created.carat} ct) added to inventory.`
        );
      } else {
        toast.warning("Saved Locally", "Saved locally; database sync in progress.");
      }
    } catch (err) {
      console.warn("Failed to persist gemstone to database:", err);
      toast.error("Save Error", "Failed to save gemstone to database.");
    }
  };

  const handleDeleteGemstone = async (id: string) => {
    const specimen = gemstonesList.find((g) => g.id === id);
    const confirmed = await confirm({
      title: "Delete Gemstone?",
      message: `Are you sure you want to delete ${specimen?.name || "this gemstone"} from inventory? This action cannot be undone.`,
      confirmLabel: "Delete Gemstone",
      cancelLabel: "Cancel",
      variant: "danger",
      badgeText: "Cannot Be Undone",
    });

    if (confirmed) {
      // Optimistically remove from state
      setGemstonesList((prev) => prev.filter((g) => g.id !== id));

      try {
        const res = await fetch(`/api/gemstones/${id}`, {
          method: "DELETE",
        });
        if (res.ok) {
          await loadGemstones();
          toast.success(
            "Gemstone Deleted",
            `${specimen?.name || "Gemstone"} has been removed from inventory.`
          );
        } else {
          console.error("Failed to delete gemstone:", await res.text());
          await loadGemstones();
          toast.error("Delete Failed", "Unable to remove gemstone from database.");
        }
      } catch (err) {
        console.warn("Failed to delete gemstone from database:", err);
        await loadGemstones();
        toast.error("Network Error", "Failed to communicate with server.");
      }
    }
  };

  const handleUpdateGemstone = async (id: string, updatedData: Partial<Gemstone>) => {
    // Optimistically update local state
    setGemstonesList((prev) =>
      prev.map((g) => (g.id === id ? { ...g, ...updatedData } : g))
    );

    try {
      const res = await fetch(`/api/gemstones/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedData),
      });
      if (res.ok) {
        await loadGemstones();
        toast.success("Gemstone Updated", "Gemstone details have been updated.");
      } else {
        console.error("Failed to update gemstone:", await res.text());
        await loadGemstones();
        toast.error("Update Failed", "Unable to update gemstone in inventory.");
      }
    } catch (err) {
      console.warn("Failed to update gemstone in database:", err);
      await loadGemstones();
      toast.error("Network Error", "Failed to communicate with server.");
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, newStatus: AdminOrderStatus) => {
    // Optimistic state update
    setOrdersList((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, status: newStatus } : ord))
    );

    try {
      const res = await fetch("/api/orders", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: orderId, status: newStatus }),
      });
      if (res.ok) {
        await Promise.all([loadOrders(), loadGemstones()]);
        toast.info("Shipment Status Updated", `Order ${orderId} updated to ${newStatus}.`);
      }
    } catch (err) {
      console.warn("Failed to persist order status in MySQL:", err);
      toast.error("Status Update Failed", "Could not sync order status with database.");
    }
  };

  const handleUpdateInquiryStatus = async (
    inquiryId: string,
    newStatus: "new" | "scheduled" | "resolved"
  ) => {
    // Optimistic UI update
    setInquiriesList((prev) =>
      prev.map((inq) => (inq.id === inquiryId ? { ...inq, status: newStatus } : inq))
    );

    try {
      await fetch("/api/inquiries", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: inquiryId, status: newStatus }),
      });
    } catch {
      // Revert if error
      loadInquiries();
    }
  };

  if (isAuthenticated === null) {
    return (
      <div className="h-screen w-full bg-[#0F0F13] flex flex-col items-center justify-center text-center p-6 select-none animate-in fade-in duration-300">
        <div className="relative mb-5">
          <div className="w-12 h-12 rounded-full border border-[#C5A880]/20 border-t-[#C5A880] animate-spin" />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-2.5 h-2.5 rounded-full bg-[#C5A880] shadow-[0_0_12px_#C5A880]" />
          </div>
        </div>
        <p className="font-sans font-medium text-lg text-white tracking-wider">
          Faizan Gems
        </p>
        <p className="text-[11px] font-mono text-[#8C867D] mt-1.5 tracking-widest uppercase">
          Loading Workspace...
        </p>
      </div>
    );
  }

  return (
    <div className="h-screen w-full bg-[#0F0F13] text-[#FAF8F5] font-sans admin-dashboard-root antialiased overflow-hidden flex selection:bg-[#C5A880] selection:text-[#0D0D11]">
      {/* 1. Immovable Left Sidebar */}
      <AdminSidebar
        activeTab={activeTab}
        setActiveTab={handleTabChange}
        isMobileSidebarOpen={isMobileSidebarOpen}
        setIsMobileSidebarOpen={setIsMobileSidebarOpen}
        gemstonesCount={gemstonesList.length}
        activeShipments={activeShipments}
        clientsCount={clientsList.length}
        newInquiriesCount={newInquiriesCount}
      />

      {/* 2. Immovable Topbar */}
      <AdminTopbar
        activeTab={activeTab}
        setActiveTab={handleTabChange}
        setIsMobileSidebarOpen={setIsMobileSidebarOpen}
        onOpenAddModal={() => {
          handleTabChange("inventory");
          setIsAddModalOpen(true);
        }}
        adminUser={adminUser}
        handleLogout={handleLogout}
        onUpdateAdminUser={(updated) => setAdminUser(updated)}
        ordersList={ordersList}
      />

      {/* 3. Center Content Column (Contained Scrollable Viewport) */}
      <div className="flex-1 w-full md:pl-64 lg:pl-72 h-screen flex flex-col overflow-hidden">
        <main className="w-full h-[calc(100dvh-4rem)] mt-16 overflow-y-auto overscroll-contain admin-scroll">
          <div key={activeTab} className="w-full max-w-[1720px] mx-auto space-y-8 px-4 sm:px-6 lg:px-8 xl:px-10 py-6 sm:py-8 pb-10">
            {activeTab === "overview" && (
              <OverviewTab
                adminUser={adminUser}
                gemstonesList={gemstonesList}
                ordersList={ordersList}
                totalRevenue={totalRevenue}
                totalVaultValue={totalVaultValue}
                activeShipments={activeShipments}
                newInquiriesCount={newInquiriesCount}
                formatPrice={formatPrice}
                setActiveTab={handleTabChange}
                onOpenAddModal={() => {
                  handleTabChange("inventory");
                  setIsAddModalOpen(true);
                }}
              />
            )}

            {activeTab === "inventory" && (
              <InventoryTab
                gemstonesList={gemstonesList}
                totalVaultValue={totalVaultValue}
                formatPrice={formatPrice}
                isAddModalOpen={isAddModalOpen}
                setIsAddModalOpen={setIsAddModalOpen}
                onAddGemstone={handleAddGemstone}
                onDeleteGemstone={handleDeleteGemstone}
                onUpdateGemstone={handleUpdateGemstone}
              />
            )}

            {activeTab === "orders" && (
              <OrdersTab
                ordersList={ordersList}
                formatPrice={formatPrice}
                onUpdateOrderStatus={handleUpdateOrderStatus}
                onRefreshOrders={loadOrders}
                isLoadingOrders={isLoadingOrders}
              />
            )}

            {activeTab === "clients" && (
              <ClientsTab
                clientsList={clientsList}
                formatPrice={formatPrice}
                isLoading={isLoadingClients}
                onRefresh={loadClients}
              />
            )}

            {activeTab === "inquiries" && (
              <InquiriesTab
                inquiriesList={inquiriesList}
                newInquiriesCount={newInquiriesCount}
                onUpdateInquiryStatus={handleUpdateInquiryStatus}
                onRefresh={loadInquiries}
                isLoading={isLoadingInquiries}
              />
            )}

            {activeTab === "cms" && (
              <CmsTab setActiveTab={handleTabChange} />
            )}

            {activeTab === "vault_security" && (
              <SecurityTab adminUser={adminUser} />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
