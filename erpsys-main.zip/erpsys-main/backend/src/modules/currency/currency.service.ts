import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Currency } from '../../types';

@Injectable()
export class CurrencyService {
  constructor(private readonly prisma: PrismaService) {}

  async findAll(): Promise<Currency[]> {
    const currencies = await this.prisma.currency.findMany({
      where: { isActive: true },
      orderBy: { code: 'asc' },
    });
    return currencies.map((c) => ({
      ...c,
      createdAt: c.createdAt.toISOString(),
    }));
  }
}
