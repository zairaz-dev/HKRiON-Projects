import React, { useEffect, useState, useRef } from "react";
import { createPortal } from "react-dom";
import { 
  Search, 
  Bell, 
  Menu, 
  Sun, 
  Moon, 
  ShoppingCart, 
  User as UserIcon, 
  LogOut,
  ChevronDown 
} from "lucide-react";
import Link from "next/link";
import { cn, getFullAssetUrl } from "@/lib/utils";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";
import { GlobalSearchDialog } from "./global-search-dialog";

/**
 * ==========================================================================
 * NavbarProps Interface
 * ==========================================================================
 */
interface NavbarProps {
  /**
   * The main title of the current page (e.g. "Dashboard", "Point of Sale").
   */
  title?: string;
  /**
   * Optional subtitle representing the section or view (e.g. "Overview", "Register 01").
   */
  subtitle?: string;
  /**
   * Additional CSS classes to apply to the header element.
   */
  className?: string;
}

/**
 * ==========================================================================
 * Reusable Navbar Component
 * ==========================================================================
 * 
 * Renders the top navigation bar for the dashboard layout.
 * Features:
 * - Search bar input with custom focus state.
 * - Theme toggle button (Light/Dark mode) with local persistence.
 * - Notification bell button with active indicator badge.
 * - Uniform height buttons (h-9) across all actions.
 * - Current logged-in user profile trigger with portal popup menu (Profile & Logout).
 * - Glassmorphism design and sticky position at the top of the viewport.
 */
export function Navbar({ className }: NavbarProps) {
  const [theme, setTheme] = useState("dark");
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [coords, setCoords] = useState<{ top: number; right: number } | null>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  // Global keyboard shortcut for search (Ctrl+K / Cmd+K and /)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl+K or Cmd+K
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
      // Quick '/' trigger when not in an input
      if (e.key === '/' && !['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Load current user on mount
  useEffect(() => {
    setCurrentUser(authService.getCurrentUser());
  }, []);

  const updatePosition = () => {
    if (triggerRef.current) {
      const rect = triggerRef.current.getBoundingClientRect();
      setCoords({
        top: rect.bottom + 6,
        right: Math.max(8, window.innerWidth - rect.right),
      });
    }
  };

  useEffect(() => {
    if (isUserMenuOpen) {
      updatePosition();
      window.addEventListener("scroll", updatePosition, true);
      window.addEventListener("resize", updatePosition);
      return () => {
        window.removeEventListener("scroll", updatePosition, true);
        window.removeEventListener("resize", updatePosition);
      };
    }
  }, [isUserMenuOpen]);

  const handleLogout = () => {
    authService.logout();
    window.location.href = "/login";
  };

  // Load theme from localStorage on mount and apply appropriate class
  useEffect(() => {
    const savedTheme = localStorage.getItem("theme") || "dark";
    setTheme(savedTheme);
    if (savedTheme === "light") {
      document.documentElement.classList.add("light");
      document.documentElement.classList.remove("dark");
    } else {
      document.documentElement.classList.add("dark");
      document.documentElement.classList.remove("light");
    }
  }, []);

  // Toggle between light and dark themes
  const toggleTheme = () => {
    const newTheme = theme === "dark" ? "light" : "dark";
    setTheme(newTheme);
    localStorage.setItem("theme", newTheme);
    if (newTheme === "light") {
      document.documentElement.classList.add("light");
      document.documentElement.classList.remove("dark");
    } else {
      document.documentElement.classList.add("dark");
      document.documentElement.classList.remove("light");
    }
  };

  return (
    <header className={cn(
      "h-16 border-b border-border bg-background/80 backdrop-blur-md px-3 sm:px-4 flex items-center justify-between sticky top-0 z-30",
      className
    )}>
      {/* Left Side: Mobile Menu Toggle */}
      <div className="flex items-center gap-3">
        {/* Mobile toggle button for sidebar */}
        <button 
          className="md:hidden text-slate-400 hover:text-white transition-colors p-1 -ml-1" 
          onClick={() => {
            document.dispatchEvent(new CustomEvent('toggle-sidebar'));
          }}
          aria-label="Toggle Sidebar"
        >
          <Menu className="w-6 h-6" />
        </button>
      </div>

      {/* Right Side Options (Search, POS Button, Theme Toggle, Notifications & User Dropdown) */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Search Bar Trigger - Desktop */}
        <button
          type="button"
          onClick={() => setIsSearchOpen(true)}
          className="relative hidden lg:flex items-center h-9 w-52 xl:w-64 rounded-sm border border-border bg-card/40 hover:bg-card/70 hover:border-primary/40 px-3 text-xs text-muted-foreground transition-all group cursor-pointer"
          aria-label="Search transactions, SKU, customers"
        >
          <Search className="w-3.5 h-3.5 text-muted-foreground group-hover:text-primary transition-colors shrink-0 mr-2.5" />
          <span className="truncate group-hover:text-foreground transition-colors">Search transaction, SKU...</span>
          <span className="ml-auto inline-flex items-center gap-0.5 rounded border border-border/80 bg-muted/60 px-1.5 py-0.5 text-[10px] font-mono font-medium text-muted-foreground group-hover:text-foreground transition-colors">
            <span className="text-[9px]">⌘</span>K
          </span>
        </button>

        {/* Mobile & Tablet Search Icon Button */}
        <button
          type="button"
          onClick={() => setIsSearchOpen(true)}
          className="lg:hidden w-9 h-9 rounded-sm border border-border bg-card/40 flex items-center justify-center hover:bg-accent hover:text-primary transition text-muted-foreground"
          aria-label="Open Search"
        >
          <Search className="w-4 h-4" />
        </button>

        {/* POS Button */}
        <Link
          href="/pos"
          className="flex items-center gap-1.5 px-2.5 sm:px-3 h-9 rounded-sm border border-primary/20 bg-primary/10 hover:bg-primary/20 text-primary text-xs font-semibold shadow-sm hover:shadow-primary/5 transition duration-200"
        >
          <ShoppingCart className="w-3.5 h-3.5" />
          <span>POS</span>
        </Link>

        {/* Theme Toggle Button */}
        <button
          onClick={toggleTheme}
          className="w-9 h-9 rounded-sm border border-border bg-card/40 flex items-center justify-center hover:bg-accent transition"
          aria-label="Toggle Theme"
        >
          {theme === "dark" ? (
            <Sun className="w-4 h-4 text-muted-foreground" />
          ) : (
            <Moon className="w-4 h-4 text-muted-foreground" />
          )}
        </button>

        {/* Notifications Icon Button */}
        <button 
          className="relative w-9 h-9 rounded-sm border border-border bg-card/40 flex items-center justify-center hover:bg-accent transition"
          aria-label="Notifications"
        >
          <Bell className="w-4 h-4 text-muted-foreground" />
          <span className="absolute top-2 right-2.5 w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
        </button>

        {/* Divider */}
        <div className="h-6 w-[1px] bg-border/80 shrink-0 mx-1" />

        {/* User Details Dropdown Container */}
        <div className="relative">
          {/* User Profile Trigger Button (Height h-9 matching all other buttons) */}
          <button
            ref={triggerRef}
            type="button"
            onClick={() => setIsUserMenuOpen((prev) => !prev)}
            className={cn(
              "h-9 px-2 sm:px-2.5 rounded-sm border border-border bg-card/40 flex items-center gap-2 hover:bg-accent hover:border-border transition duration-150 shrink-0 select-none",
              isUserMenuOpen && "bg-accent border-primary/40 ring-1 ring-primary/20"
            )}
            aria-expanded={isUserMenuOpen}
            aria-haspopup="true"
          >
            <div className="w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center shrink-0 overflow-hidden border border-primary/25 shadow-xs">
              {currentUser?.avatar ? (
                <img
                  src={getFullAssetUrl(currentUser.avatar) || currentUser.avatar}
                  alt={currentUser.name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.currentTarget as HTMLElement).style.display = "none";
                  }}
                />
              ) : (
                <UserIcon className="w-3.5 h-3.5" />
              )}
            </div>
            <div className="hidden sm:block text-left min-w-0 max-w-[120px] md:max-w-[140px]">
              <p className="text-xs font-semibold text-foreground truncate leading-tight">
                {currentUser?.name || "Loading..."}
              </p>
              <p className="text-[9px] font-mono text-muted-foreground uppercase leading-tight truncate">
                {currentUser?.role || "USER"}
              </p>
            </div>
            <ChevronDown
              className={cn(
                "w-3.5 h-3.5 text-muted-foreground transition-transform duration-200 shrink-0",
                isUserMenuOpen && "rotate-180 text-foreground"
              )}
            />
          </button>
        </div>

        {/* Popup Dropdown Menu via Portal to escape all parent stacking contexts */}
        {isUserMenuOpen && coords && typeof document !== "undefined" &&
          createPortal(
            <>
              {/* Backdrop Overlay to close on outside click */}
              <div
                className="fixed inset-0 z-[9998]"
                onClick={() => setIsUserMenuOpen(false)}
              />

              {/* Dropdown Floating Panel */}
              <div
                className="fixed z-[9999] w-60 rounded-sm border border-border bg-card/95 backdrop-blur-xl p-1 shadow-2xl animate-in fade-in-0 zoom-in-95 duration-150"
                style={{
                  top: `${coords.top}px`,
                  right: `${coords.right}px`,
                }}
              >
                {/* User Header Summary with Profile Image */}
                <div className="flex items-center gap-3 px-3 py-2.5 border-b border-border/60 mb-1">
                  <div className="w-10 h-10 rounded-full bg-primary/20 text-primary flex items-center justify-center shrink-0 overflow-hidden border border-primary/30 shadow-xs">
                    {currentUser?.avatar ? (
                      <img
                        src={getFullAssetUrl(currentUser.avatar) || currentUser.avatar}
                        alt={currentUser.name}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.currentTarget as HTMLElement).style.display = "none";
                        }}
                      />
                    ) : (
                      <UserIcon className="w-5 h-5" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-bold text-foreground truncate">
                      {currentUser?.name || "User"}
                    </p>
                    {currentUser?.email ? (
                      <p className="text-[10px] text-muted-foreground truncate font-mono mt-0.5">
                        {currentUser.email}
                      </p>
                    ) : null}
                    <div className="mt-1 inline-flex items-center px-1.5 py-0.5 rounded-full text-[9px] font-bold font-mono uppercase bg-primary/15 text-primary border border-primary/25">
                      {currentUser?.role || "USER"}
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="space-y-0.5">
                  {/* Profile Link */}
                  <Link
                    href={currentUser?.id ? `/users/view?id=${currentUser.id}` : "/users"}
                    onClick={() => setIsUserMenuOpen(false)}
                    className="flex w-full items-center gap-2.5 px-2.5 py-2 text-xs rounded-sm font-medium text-foreground/90 hover:bg-accent hover:text-foreground transition-colors group cursor-pointer"
                  >
                    <UserIcon className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors shrink-0" />
                    <span>Profile</span>
                  </Link>

                  {/* Logout Button */}
                  <button
                    type="button"
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      handleLogout();
                    }}
                    className="flex w-full items-center gap-2.5 px-2.5 py-2 text-xs rounded-sm font-medium text-rose-500 hover:bg-rose-500/10 hover:text-rose-400 transition-colors group text-left cursor-pointer"
                  >
                    <LogOut className="w-4 h-4 text-rose-500 group-hover:scale-105 transition-transform shrink-0" />
                    <span>Logout</span>
                  </button>
                </div>
              </div>
            </>,
            document.body
          )
        }
      </div>

      {/* Global Search / Command Palette Dialog */}
      <GlobalSearchDialog
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        businessId={currentUser?.businessId}
      />
    </header>
  );
}
