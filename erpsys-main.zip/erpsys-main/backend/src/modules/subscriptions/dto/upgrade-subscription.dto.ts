import { IsEnum, IsNotEmpty, IsOptional, IsString } from 'class-validator';
import { BillingInterval } from '@prisma/client';

export class UpgradeSubscriptionDto {
  @IsString()
  @IsNotEmpty()
  planId: string;

  @IsEnum(BillingInterval)
  @IsNotEmpty()
  billingInterval: BillingInterval;

  @IsString()
  @IsOptional()
  paymentMethod?: string; // "Razorpay", "Stripe", "Cash", "UPI", "Bank Transfer"

  @IsString()
  @IsOptional()
  transactionId?: string;

  @IsString()
  @IsOptional()
  notes?: string;
}
