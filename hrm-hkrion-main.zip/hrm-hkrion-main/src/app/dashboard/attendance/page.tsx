import { getTodayAttendance, getAttendanceRecords } from "@/actions/attendance";
import AttendanceClient from "./attendance-client";
import { getSession } from "@/lib/session";
import { redirect } from "next/navigation";

export default async function AttendancePage() {
  const session = await getSession();
  
  if (!session) {
    redirect("/login");
  }

  const [todayRes, recordsRes] = await Promise.all([
    getTodayAttendance(),
    getAttendanceRecords(),
  ]);

  const isSuperAdmin = session.role === "SUPER_ADMIN";

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <AttendanceClient 
        todayAttendance={todayRes.data || null}
        records={recordsRes.data || []}
        isSuperAdmin={isSuperAdmin}
      />
    </div>
  );
}
