import { IsString, IsNotEmpty, IsEnum, IsOptional } from 'class-validator';
import { BillingInterval } from '@prisma/client';

export class SubmitBankTransferDto {
  @IsString()
  @IsNotEmpty()
  planId: string;

  @IsEnum(BillingInterval)
  billingInterval: BillingInterval;

  @IsString()
  @IsNotEmpty()
  transactionId: string; // UTR or Deposit Reference Number

  @IsString()
  @IsOptional()
  proofUrl?: string; // Uploaded Bank Slip / Screenshot URL

  @IsString()
  @IsOptional()
  notes?: string;
}
