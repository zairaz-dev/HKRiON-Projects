import {
  IsString,
  IsNotEmpty,
  IsOptional,
  IsBoolean,
  IsNumber,
  Min,
  MaxLength,
  IsArray,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import { GroupPriceDto, VariantDto } from './create-product.dto';

export class UpdateProductDto {
  @IsOptional()
  @IsString()
  @MaxLength(150, { message: 'Product name cannot exceed 150 characters' })
  name?: string;

  @IsOptional()
  @IsString()
  @MaxLength(1000)
  description?: string;

  @IsOptional()
  @IsString()
  imageUrl?: string;

  @IsOptional()
  @IsBoolean()
  isActive?: boolean;

  @IsOptional()
  @IsBoolean()
  enableStock?: boolean;

  @IsOptional()
  @IsBoolean()
  enableImei?: boolean;

  @IsOptional()
  @IsBoolean()
  isImei?: boolean;

  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Alert quantity cannot be negative' })
  alertQuantity?: number;

  @IsOptional()
  @IsBoolean()
  notForSelling?: boolean;

  @IsOptional()
  @IsNumber()
  @Min(0)
  weight?: number;

  @IsOptional()
  @IsString()
  categoryId?: string | null;

  @IsOptional()
  @IsString()
  brandId?: string | null;

  @IsOptional()
  @IsString()
  unitId?: string | null;

  @IsOptional()
  @IsString()
  warrantyId?: string | null;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  branchIds?: string[];

  // For SINGLE type
  @IsOptional()
  @IsString()
  @MaxLength(50)
  sku?: string;

  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Purchase price must be 0 or greater' })
  purchasePrice?: number;

  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Selling price must be 0 or greater' })
  sellingPrice?: number;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => GroupPriceDto)
  groupPrices?: GroupPriceDto[];

  // For VARIABLE type
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => VariantDto)
  variants?: VariantDto[];

  @IsString()
  @IsNotEmpty({ message: 'Business ID is required' })
  businessId: string;

  @IsOptional()
  @IsString()
  updatedById?: string;
}
