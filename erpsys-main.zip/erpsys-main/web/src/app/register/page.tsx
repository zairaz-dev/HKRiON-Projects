"use strict";
"use client";

import React, { useState, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { useGoogleLogin } from "@react-oauth/google";
import { 
  User as UserIcon, 
  Lock, 
  Mail, 
  Eye, 
  EyeOff, 
  Loader2, 
  ArrowLeft, 
  Layers, 
  Shield, 
  Building, 
  Phone, 
  Globe, 
  Briefcase, 
  CheckCircle2, 
  Sparkles, 
  ArrowRight, 
  TrendingUp,
  Coins
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import Link from "next/link";
import { authService } from "@/services/auth-service";
import { lookupService } from "@/services/lookup-service";
import { PageContainer } from "@/components/ui/page-container";
import { Country, Currency, PhoneCode } from "@hkr/types";

const isGoogleEnabled = process.env.NEXT_PUBLIC_ENABLE_GOOGLE_LOGIN !== 'false' && !!process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID;

function GoogleLinkBtn({ onSuccess, onError, disabled }: { onSuccess: (accessToken: string) => void; onError: (errMsg?: string) => void; disabled: boolean }) {
  const loginWithGoogle = useGoogleLogin({
    onSuccess: async (tokenResponse) => {
      onSuccess(tokenResponse.access_token);
    },
    onError: () => {
      onError("Google connection failed.");
    }
  });

  return (
    <Button
      type="button"
      variant="outline"
      onClick={() => loginWithGoogle()}
      disabled={disabled}
      className="w-full border-border hover:bg-accent text-xs gap-2 h-10 text-foreground bg-card/40"
    >
      <svg className="w-4 h-4" viewBox="0 0 24 24">
        <path fill="#ea4335" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
        <path fill="#fbbc05" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
        <path fill="#4285f4" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
        <path fill="#34a853" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
      </svg>
      Link Google Account
    </Button>
  );
}

function RegisterForm() {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const searchParams = useSearchParams();
  const [googleToken, setGoogleToken] = useState("");
  const [isGoogleSignup, setIsGoogleSignup] = useState(false);

  useEffect(() => {
    const tokenParam = searchParams.get("google_token");
    const emailParam = searchParams.get("email");
    const nameParam = searchParams.get("name");

    if (tokenParam && emailParam) {
      setGoogleToken(tokenParam);
      setEmail(emailParam);
      if (nameParam) setOwnerName(nameParam);
      setIsGoogleSignup(true);
    }
  }, [searchParams]);


  
  // Step 1: Business Details
  const [businessName, setBusinessName] = useState("");
  const [industry, setIndustry] = useState("retail");
  const [businessPhone, setBusinessPhone] = useState("");
  
  const [countries, setCountries] = useState<Country[]>([]);
  const [countryId, setCountryId] = useState("");

  const [currencies, setCurrencies] = useState<Currency[]>([]);
  const [currencyId, setCurrencyId] = useState("");

  const [phoneCodes, setPhoneCodes] = useState<PhoneCode[]>([]);
  const [phoneCodeId, setPhoneCodeId] = useState("");
  
  // Step 2: Owner Account
  const [ownerName, setOwnerName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const [isElectron, setIsElectron] = useState(false);

  const handleGoogleSuccess = async (accessToken: string) => {
    setIsLoading(true);
    setError("");
    try {
      const response = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      if (!response.ok) {
        throw new Error('Failed to fetch user info from Google');
      }
      const payload = await response.json();
      setGoogleToken(accessToken);
      setEmail(payload.email);
      if (payload.name) setOwnerName(payload.name);
      setIsGoogleSignup(true);
    } catch (err: any) {
      setError(err.message || 'Failed to link Google account');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (authService.isAuthenticated()) {
      window.location.href = "/dashboard";
      return;
    }
    // Detect if running inside Electron
    if (typeof window !== "undefined" && window.navigator.userAgent.toLowerCase().includes("electron")) {
      setIsElectron(true);
    }
    const fetchData = async () => {
      try {
        const [countriesList, currenciesList, phoneCodesList] = await Promise.all([
          lookupService.getCountries(),
          lookupService.getCurrencies(),
          lookupService.getPhoneCodes(),
        ]);
        
        setCountries(countriesList);
        if (countriesList.length > 0) {
          setCountryId(countriesList[0].id);
        }

        setCurrencies(currenciesList);
        if (currenciesList.length > 0) {
          setCurrencyId(currenciesList[0].id);
        }

        setPhoneCodes(phoneCodesList);
        if (phoneCodesList.length > 0) {
          setPhoneCodeId(phoneCodesList[0].id);
        }
      } catch (err) {
        console.error("Failed to load geographic data:", err);
      }
    };
    fetchData();
  }, []);

  const handleNextStep = () => {
    setError("");
    if (!businessName.trim()) {
      setError("Please enter your Business Name.");
      return;
    }
    if (!businessPhone.trim()) {
      setError("Please enter your Business Phone Number.");
      return;
    }
    if (!countryId) {
      setError("Please select an Operating Country.");
      return;
    }
    if (!currencyId) {
      setError("Please select a Base Currency.");
      return;
    }
    if (!phoneCodeId) {
      setError("Please select a Phone Country Code.");
      return;
    }
    setStep(2);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (isGoogleSignup) {
      if (!ownerName.trim() || !email.trim()) {
        setError("Missing owner details from Google.");
        return;
      }
      setIsLoading(true);
      try {
        await authService.registerBusinessGoogle({
          businessName,
          industry,
          phone: businessPhone,
          phoneCodeId,
          countryId,
          currencyId,
          token: googleToken,
        });

        // Log in automatically after successful registration
        await authService.loginWithGoogle(googleToken);

        setStep(3);
        setTimeout(() => {
          window.location.href = "/dashboard";
        }, 2500);
      } catch (err: any) {
        setError(err.message || "Failed to register business with Google. Please try again.");
      } finally {
        setIsLoading(false);
      }
      return;
    }

    if (!ownerName.trim() || !email.trim() || !password || !confirmPassword) {
      setError("Please fill in all owner account fields.");
      return;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    if (password.length < 6) {
      setError("Password must be at least 6 characters long.");
      return;
    }

    setIsLoading(true);

    try {
      // Register the business and admin user in the backend
      await authService.registerBusiness({
        businessName,
        industry,
        phone: businessPhone,
        phoneCodeId,
        countryId,
        currencyId,
        ownerName,
        email,
        password,
      });
      
      // Log in automatically after successful registration
      await authService.login(email, password);
      
      setStep(3);
      setTimeout(() => {
        window.location.href = "/dashboard";
      }, 2500);
    } catch (err: any) {
      setError(err.message || "Failed to register business. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <PageContainer size="lg" className="justify-center min-h-[calc(100vh-4rem)] select-none">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center w-full max-w-6xl mx-auto my-auto py-6">
        
        {/* Left Side: Premium Feature Highlights (Hidden on Mobile) */}
        <div className="lg:col-span-5 hidden lg:flex flex-col space-y-8 text-left pr-4">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-xs font-semibold text-primary">
              <Sparkles className="w-3.5 h-3.5" />
              HKR ION ERP v1.0
            </div>
            <h1 className="text-4xl xl:text-5xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-foreground to-foreground/80 leading-tight">
              Empower Your Business Growth
            </h1>
            <p className="text-muted-foreground text-base max-w-md">
              A comprehensive and modern platform built to manage your inventory, sales, invoicing, and team operations effortlessly.
            </p>
          </div>

          {/* Core Benefit Items */}
          <div className="space-y-4">
            <div className="flex gap-4 p-4 rounded-xl border border-border bg-card/25 backdrop-blur-sm hover:border-border/80 transition-all duration-300 group">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-primary/20 to-primary/10 border border-primary/30 flex items-center justify-center text-primary group-hover:scale-110 transition-transform duration-300">
                <Layers className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-semibold text-foreground">Smart POS & Invoicing</h3>
                <p className="text-xs text-muted-foreground">Fast cashier interface, instant receipt generation, and multiple payment options.</p>
              </div>
            </div>

            <div className="flex gap-4 p-4 rounded-xl border border-border bg-card/25 backdrop-blur-sm hover:border-border/80 transition-all duration-300 group">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-primary/20 to-primary/10 border border-primary/30 flex items-center justify-center text-primary group-hover:scale-110 transition-transform duration-300">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-semibold text-foreground">Real-time Stock Control</h3>
                <p className="text-xs text-muted-foreground">Track levels, low-stock alerts, and manage product variants in one dashboard.</p>
              </div>
            </div>

            <div className="flex gap-4 p-4 rounded-xl border border-border bg-card/25 backdrop-blur-sm hover:border-border/80 transition-all duration-300 group">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-primary/20 to-primary/10 border border-primary/30 flex items-center justify-center text-primary group-hover:scale-110 transition-transform duration-300">
                <Coins className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-semibold text-foreground">Financial Insights</h3>
                <p className="text-xs text-muted-foreground">Comprehensive reports on profit, expenses, sales tax, and growth trends.</p>
              </div>
            </div>

            <div className="flex gap-4 p-4 rounded-xl border border-border bg-card/25 backdrop-blur-sm hover:border-border/80 transition-all duration-300 group">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-primary/20 to-primary/10 border border-primary/30 flex items-center justify-center text-primary group-hover:scale-110 transition-transform duration-300">
                <Shield className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-semibold text-foreground">Enterprise Security</h3>
                <p className="text-xs text-muted-foreground">Advanced role-based access controls protecting sensitive operational data.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Onboarding Card */}
        <div className="lg:col-span-7 w-full max-w-xl mx-auto">
          <Card className="glass border-border shadow-2xl relative backdrop-blur-xl bg-card/40">
            
            {/* Back Button (Only on Step 1) */}
            {step === 1 && !isElectron && (
              <div className="absolute top-4 left-4">
                <Link href="/">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="w-8 h-8 rounded-lg text-muted-foreground hover:bg-accent hover:text-foreground transition-all duration-200"
                    aria-label="Back to Home"
                  >
                    <ArrowLeft className="w-4 h-4" />
                  </Button>
                </Link>
              </div>
            )}

            <CardHeader className="space-y-2 text-center pt-8 pb-6">
              <div className="mx-auto w-12 h-12 flex items-center justify-center mb-2">
                <img src="/logo.png" alt="HKRiON ERP Logo" className="w-full h-full object-contain" />
              </div>
              <CardTitle className="text-2xl font-bold tracking-tight text-foreground">
                Register Your Business
              </CardTitle>
              <CardDescription className="text-muted-foreground text-sm">
                Get started with HKRiON ERP by setting up your company profile
              </CardDescription>
            </CardHeader>

            {/* Stepper Progress Bar */}
            {step < 3 && (
              <div className="flex items-center justify-between mb-6 px-6">
                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-mono text-xs font-bold transition-all duration-300 ${step >= 1 ? 'bg-gradient-to-tr from-primary to-primary/80 text-primary-foreground shadow-lg shadow-primary/20' : 'bg-muted border border-border text-muted-foreground/60'}`}>
                    1
                  </div>
                  <div className="flex flex-col text-left">
                    <span className={`text-[10px] font-mono uppercase tracking-wider font-bold transition-colors ${step >= 1 ? 'text-primary' : 'text-muted-foreground/60'}`}>Step 1</span>
                    <span className={`text-xs font-semibold transition-colors ${step >= 1 ? 'text-foreground' : 'text-muted-foreground'}`}>Business Info</span>
                  </div>
                </div>
                
                <div className={`flex-1 h-[2px] mx-4 transition-all duration-500 ${step > 1 ? 'bg-gradient-to-r from-primary to-primary/80' : 'bg-border'}`} />

                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-mono text-xs font-bold transition-all duration-300 ${step >= 2 ? 'bg-gradient-to-tr from-primary to-primary/80 text-primary-foreground shadow-lg shadow-primary/20' : 'bg-muted border border-border text-muted-foreground/60'}`}>
                    2
                  </div>
                  <div className="flex flex-col text-left">
                    <span className={`text-[10px] font-mono uppercase tracking-wider font-bold transition-colors ${step >= 2 ? 'text-primary' : 'text-muted-foreground/60'}`}>Step 2</span>
                    <span className={`text-xs font-semibold transition-colors ${step >= 2 ? 'text-foreground' : 'text-muted-foreground'}`}>Owner Account</span>
                  </div>
                </div>
              </div>
            )}
            
            <CardContent>
              {/* Step 3: Success Setup State */}
              {step === 3 ? (
                <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-sm text-emerald-400 font-medium text-center space-y-4 py-12 animate-in zoom-in-95 duration-300">
                  <div className="mx-auto w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center animate-bounce shadow-lg shadow-emerald-500/10">
                    <CheckCircle2 className="w-10 h-10 text-emerald-400" />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-lg font-bold text-white">Business Registered!</h3>
                    <p className="text-slate-400 text-xs">
                      Creating workspace environment for <strong className="text-emerald-400">{businessName}</strong>
                    </p>
                  </div>
                  <div className="flex items-center justify-center gap-2 text-slate-400 text-xs font-mono">
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-primary" />
                    Initializing modules, redirecting...
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Error Message */}
                  {error && (
                    <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-xs text-red-400 font-medium text-center animate-shake">
                      {error}
                    </div>
                  )}

                  {/* Step 1: Business Details Form */}
                  {step === 1 && (
                    <div className="space-y-4 text-left animate-in fade-in slide-in-from-right-3 duration-350">
                      
                      {/* Business Name */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-muted-foreground font-mono uppercase tracking-wider">
                          Business / Company Name
                        </label>
                        <div className="relative">
                          <Building className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/60" />
                          <Input 
                            type="text" 
                            placeholder="HKR Technologies" 
                            value={businessName}
                            onChange={(e) => setBusinessName(e.target.value)}
                            className="pl-10 focus:border-primary transition-all"
                            disabled={isLoading}
                          />
                        </div>
                      </div>

                      {/* Industry Type */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-muted-foreground font-mono uppercase tracking-wider">
                          Industry Category
                        </label>
                        <div className="relative">
                          <Briefcase className="absolute left-3.5 top-[13px] w-4 h-4 text-muted-foreground/60 z-10" />
                          <Select 
                            value={industry} 
                            onValueChange={setIndustry} 
                            disabled={isLoading}
                            className="pl-10"
                          >
                            <option value="retail">Retail Store</option>
                            <option value="wholesale">Wholesale & Distribution</option>
                            <option value="services">Professional Services</option>
                            <option value="restaurant">Restaurant & F&B</option>
                            <option value="manufacturing">Manufacturing</option>
                            <option value="other">Other Business Type</option>
                          </Select>
                        </div>
                      </div>

                      {/* Operating Country */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-muted-foreground font-mono uppercase tracking-wider">
                          Operating Country
                        </label>
                        <div className="relative">
                          <Globe className="absolute left-3.5 top-[13px] w-4 h-4 text-muted-foreground/60 z-10" />
                          <Select 
                            value={countryId} 
                            onValueChange={setCountryId} 
                            disabled={isLoading}
                            className="pl-10"
                            showSearch={true}
                          >
                            {countries.map((c) => (
                              <option key={c.id} value={c.id}>
                                {c.name}
                              </option>
                            ))}
                          </Select>
                        </div>
                      </div>

                      {/* Base Currency */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-muted-foreground font-mono uppercase tracking-wider">
                          Base Currency
                        </label>
                        <div className="relative">
                          <Coins className="absolute left-3.5 top-[13px] w-4 h-4 text-muted-foreground/60 z-10" />
                          <Select 
                            value={currencyId} 
                            onValueChange={setCurrencyId} 
                            disabled={isLoading}
                            className="pl-10"
                            showSearch={true}
                          >
                            {currencies.map((c) => (
                              <option key={c.id} value={c.id}>
                                {`QA - ${c.code} (${c.symbol}) - ${c.name.split(" - ")[0]}`}
                              </option>
                            ))}
                          </Select>
                        </div>
                      </div>

                      {/* Contact Phone (Split Input: Phone Code Dropdown + Phone Number Input) */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-muted-foreground font-mono uppercase tracking-wider">
                          Contact Phone Number
                        </label>
                        <div className="flex gap-2">
                          <div className="w-[140px] shrink-0 relative">
                            <Phone className="absolute left-3 top-[13px] w-4 h-4 text-muted-foreground/60 z-10" />
                            <Select
                              value={phoneCodeId}
                              onValueChange={setPhoneCodeId}
                              disabled={isLoading}
                              className="pl-9 text-xs"
                              showSearch={true}
                            >
                              {phoneCodes.map((p) => (
                                <option key={p.id} value={p.id}>
                                  {p.name ? (p.name.includes(p.code) ? p.name : `${p.name} (${p.code})`) : p.code}
                                </option>
                              ))}
                            </Select>
                          </div>
                          <div className="flex-1">
                            <Input 
                              type="tel" 
                              placeholder="98765 43210" 
                              value={businessPhone}
                              onChange={(e) => setBusinessPhone(e.target.value)}
                              className="focus:border-primary transition-all"
                              disabled={isLoading}
                            />
                          </div>
                        </div>
                      </div>

                      {/* Next Button */}
                      <Button 
                        type="button" 
                        onClick={handleNextStep}
                        className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium h-10 mt-6 shadow-lg shadow-primary/20 transition duration-300 gap-2"
                      >
                        Continue to Account Setup
                        <ArrowRight className="w-4 h-4" />
                      </Button>
                    </div>
                  )}

                  {/* Step 2: Owner Account Details Form */}
                  {step === 2 && (
                    <form onSubmit={handleSubmit} className="space-y-4 text-left animate-in fade-in slide-in-from-left-3 duration-350">
                      
                      {/* Google Connection Info */}
                      {isGoogleSignup && (
                        <div className="p-3 rounded-lg bg-primary/10 border border-primary/20 text-xs text-primary font-medium text-center flex items-center justify-between mb-4">
                          <span>Connected with Google: <strong>{email}</strong></span>
                          <Button
                            type="button"
                            variant="ghost"
                            className="h-6 px-2 text-[10px] text-red-400 hover:text-red-300"
                            onClick={() => {
                              setIsGoogleSignup(false);
                              setGoogleToken("");
                              setEmail("");
                              setOwnerName("");
                            }}
                          >
                            Disconnect
                          </Button>
                        </div>
                      )}

                      {/* Owner Full Name */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-muted-foreground font-mono uppercase tracking-wider">
                          Owner / Administrator Name
                        </label>
                        <div className="relative">
                          <UserIcon className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/60" />
                          <Input 
                            type="text" 
                            placeholder="Alex Johnson" 
                            value={ownerName}
                            onChange={(e) => setOwnerName(e.target.value)}
                            className="pl-10 focus:border-primary transition-all"
                            disabled={isLoading || isGoogleSignup}
                          />
                        </div>
                      </div>

                      {/* Email Field */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-muted-foreground font-mono uppercase tracking-wider">
                          Business Email Address (Username)
                        </label>
                        <div className="relative">
                          <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/60" />
                          <Input 
                            type="email" 
                            placeholder="alex@company.com" 
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="pl-10 focus:border-primary transition-all"
                            disabled={isLoading || isGoogleSignup}
                          />
                        </div>
                      </div>

                      {/* Password Fields - Hidden if Google signup */}
                      {!isGoogleSignup ? (
                        <>
                          {/* Password Field */}
                          <div className="space-y-1.5">
                            <label className="text-xs font-semibold text-muted-foreground font-mono uppercase tracking-wider">
                              Security Password
                            </label>
                            <div className="relative">
                              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/60" />
                              <Input 
                                type={showPassword ? "text" : "password"} 
                                placeholder="••••••••" 
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="pl-10 pr-10 focus:border-primary transition-all"
                                disabled={isLoading}
                              />
                              <button
                                type="button"
                                onClick={() => setShowPassword(!showPassword)}
                                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground focus:outline-none"
                                disabled={isLoading}
                              >
                                {showPassword ? (
                                  <EyeOff className="w-4 h-4" />
                                ) : (
                                  <Eye className="w-4 h-4" />
                                )}
                              </button>
                            </div>
                          </div>

                          {/* Confirm Password Field */}
                          <div className="space-y-1.5">
                            <label className="text-xs font-semibold text-muted-foreground font-mono uppercase tracking-wider">
                              Confirm Password
                            </label>
                            <div className="relative">
                              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/60" />
                              <Input 
                                type={showConfirmPassword ? "text" : "password"} 
                                placeholder="••••••••" 
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)}
                                className="pl-10 pr-10 focus:border-primary transition-all"
                                disabled={isLoading}
                              />
                              <button
                                type="button"
                                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground focus:outline-none"
                                disabled={isLoading}
                              >
                                {showConfirmPassword ? (
                                  <EyeOff className="w-4 h-4" />
                                ) : (
                                  <Eye className="w-4 h-4" />
                                )}
                              </button>
                            </div>
                          </div>

                          {/* Google Setup Button */}
                          {isGoogleEnabled && (
                            <>
                              <div className="flex items-center my-3">
                                <div className="flex-1 border-t border-border" />
                                <span className="px-3 text-[10px] uppercase font-mono text-muted-foreground/60 tracking-wider">
                                  Or speed up with
                                </span>
                                <div className="flex-1 border-t border-border" />
                              </div>
                              <GoogleLinkBtn 
                                onSuccess={handleGoogleSuccess} 
                                onError={(err) => setError(err || "Google connection failed.")} 
                                disabled={isLoading} 
                              />
                            </>
                          )}
                        </>
                      ) : null}

                      {/* Navigation buttons */}
                      <div className="flex gap-3 pt-4">
                        <Button 
                          type="button"
                          variant="outline"
                          onClick={() => setStep(1)}
                          disabled={isLoading}
                          className="flex-1 h-10 font-medium"
                        >
                          Back
                        </Button>

                        <Button 
                          type="submit" 
                          className="flex-[2] bg-primary hover:bg-primary/90 text-primary-foreground font-medium h-10 shadow-lg shadow-primary/20 transition duration-300 gap-2"
                          disabled={isLoading}
                        >
                          {isLoading ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              Setting Up Workspace...
                            </>
                          ) : (
                            <>
                              Register & Setup
                              <Sparkles className="w-4 h-4 text-primary-foreground/80" />
                            </>
                          )}
                        </Button>
                      </div>
                    </form>
                  )}
                </div>
              )}
            </CardContent>

            {step < 3 && (
              <CardFooter className="flex flex-col space-y-4 border-t border-border pt-4 pb-6">
                <p className="text-xs text-muted-foreground text-center">
                  Already have an account?{" "}
                  <Link href="/login" className="text-primary hover:underline font-medium">
                    Sign In
                  </Link>
                </p>
              </CardFooter>
            )}
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}

export default function RegisterPage() {
  return (
    <Suspense fallback={
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    }>
      <RegisterForm />
    </Suspense>
  );
}
