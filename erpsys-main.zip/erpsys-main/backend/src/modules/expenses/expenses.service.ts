import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateExpenseDto } from './dto/create-expense.dto';
import { UpdateExpenseDto } from './dto/update-expense.dto';

@Injectable()
export class ExpensesService {
  constructor(private prisma: PrismaService) {}

  async create(createDto: CreateExpenseDto) {
    const { paymentMethodId, amountPaid, ...data } = createDto;

    return this.prisma.$transaction(async (tx) => {
      // 1. Generate Ref No if not provided using max sequence
      let finalRefNo = data.refNo;
      if (!finalRefNo) {
        const year = new Date().getFullYear();
        const lastExpense = await tx.expense.findFirst({
          where: {
            businessId: data.businessId,
            refNo: {
              startsWith: `EXP-${year}-`,
            },
          },
          orderBy: {
            refNo: 'desc',
          },
        });

        let seqNum = 1;
        if (lastExpense && lastExpense.refNo) {
          const parts = lastExpense.refNo.split('-');
          const lastSeq = parseInt(parts[parts.length - 1], 10);
          if (!isNaN(lastSeq)) {
            seqNum = lastSeq + 1;
          }
        }
        finalRefNo = `EXP-${year}-${seqNum.toString().padStart(4, '0')}`;
      }

      // 2. Determine initial payment status and paid amount
      const actualAmountPaid = amountPaid || 0;
      let calculatedStatus = data.paymentStatus;
      if (actualAmountPaid >= data.amount) {
        calculatedStatus = 'PAID';
      } else if (actualAmountPaid > 0) {
        calculatedStatus = 'PARTIAL';
      } else {
        calculatedStatus = 'DUE';
      }

      // 3. Create the expense
      const expense = await tx.expense.create({
        data: {
          ...data,
          refNo: finalRefNo,
          amountPaid: actualAmountPaid,
          paymentStatus: calculatedStatus,
          expenseDate: data.expenseDate ? new Date(data.expenseDate) : new Date(),
        },
        include: {
          category: true,
          branch: true,
        },
      });

      // 4. Create initial payment record if paid amount > 0
      if (actualAmountPaid > 0 && paymentMethodId) {
        await tx.expensePayment.create({
          data: {
            expenseId: expense.id,
            amount: actualAmountPaid,
            paymentMethodId,
            paymentDate: data.expenseDate ? new Date(data.expenseDate) : new Date(),
            notes: 'Initial Payment',
          },
        });
      }

      return expense;
    });
  }

  async addPayment(
    id: string,
    businessId: string,
    data: {
      amount: number;
      paymentMethodId: string;
      paymentDate?: string | Date;
      notes?: string;
    },
  ) {
    return this.prisma.$transaction(async (tx) => {
      // 1. Fetch expense
      const expense = await tx.expense.findFirst({
        where: { id, businessId },
      });

      if (!expense) {
        throw new NotFoundException('Expense not found');
      }

      // 2. Create payment record
      await tx.expensePayment.create({
        data: {
          expenseId: id,
          amount: data.amount,
          paymentMethodId: data.paymentMethodId,
          paymentDate: data.paymentDate ? new Date(data.paymentDate) : new Date(),
          notes: data.notes || 'Payment recorded',
        },
      });

      // 3. Recalculate amountPaid and update status
      const newAmountPaid = expense.amountPaid + data.amount;
      let calculatedStatus = expense.paymentStatus;
      if (newAmountPaid >= expense.amount) {
        calculatedStatus = 'PAID';
      } else if (newAmountPaid > 0) {
        calculatedStatus = 'PARTIAL';
      } else {
        calculatedStatus = 'DUE';
      }

      return tx.expense.update({
        where: { id },
        data: {
          amountPaid: newAmountPaid,
          paymentStatus: calculatedStatus,
        },
        include: {
          category: true,
          branch: true,
          payments: {
            include: {
              paymentMethod: true,
            },
          },
        },
      });
    });
  }

  async findAll(
    businessId: string,
    filters: {
      branchId?: string;
      categoryId?: string;
      search?: string;
      page?: number;
      limit?: number;
    },
  ) {
    const { branchId, categoryId, search, page = 1, limit = 10 } = filters;
    const skip = (page - 1) * limit;

    const where: any = { businessId };

    if (branchId && branchId !== 'all') {
      where.branchId = branchId;
    }

    if (categoryId && categoryId !== 'all') {
      where.categoryId = categoryId;
    }

    if (search) {
      where.OR = [
        { refNo: { contains: search, mode: 'insensitive' } },
        { notes: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [total, items] = await Promise.all([
      this.prisma.expense.count({ where }),
      this.prisma.expense.findMany({
        where,
        skip,
        take: limit,
        include: {
          category: true,
          branch: true,
          payments: {
            include: {
              paymentMethod: true,
            },
          },
        },
        orderBy: {
          expenseDate: 'desc',
        },
      }),
    ]);

    return {
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
      items,
    };
  }

  async findOne(id: string, businessId: string) {
    const expense = await this.prisma.expense.findFirst({
      where: { id, businessId },
      include: {
        category: true,
        branch: true,
        payments: {
          include: {
            paymentMethod: true,
          },
        },
      },
    });

    if (!expense) {
      throw new NotFoundException('Expense not found');
    }

    return expense;
  }

  async update(id: string, updateDto: UpdateExpenseDto) {
    const { businessId, ...data } = updateDto;

    // Check existence
    await this.findOne(id, businessId);

    return this.prisma.expense.update({
      where: { id },
      data: {
        ...data,
        expenseDate: data.expenseDate ? new Date(data.expenseDate) : undefined,
      },
      include: {
        category: true,
        branch: true,
      },
    });
  }

  async remove(id: string, businessId: string) {
    // Check existence
    await this.findOne(id, businessId);

    return this.prisma.expense.delete({
      where: { id },
    });
  }

  async deletePayment(paymentId: string, businessId: string) {
    return this.prisma.$transaction(async (tx) => {
      // 1. Fetch payment
      const payment = await tx.expensePayment.findFirst({
        where: { id: paymentId },
        include: { expense: true },
      });

      if (!payment || payment.expense.businessId !== businessId) {
        throw new NotFoundException('Payment record not found');
      }

      // 2. Delete payment record
      await tx.expensePayment.delete({
        where: { id: paymentId },
      });

      // 3. Recalculate amountPaid and update status on the expense
      const newAmountPaid = Math.max(0, payment.expense.amountPaid - payment.amount);
      let calculatedStatus = payment.expense.paymentStatus;
      if (newAmountPaid >= payment.expense.amount) {
        calculatedStatus = 'PAID';
      } else if (newAmountPaid > 0) {
        calculatedStatus = 'PARTIAL';
      } else {
        calculatedStatus = 'DUE';
      }

      return tx.expense.update({
        where: { id: payment.expenseId },
        data: {
          amountPaid: newAmountPaid,
          paymentStatus: calculatedStatus,
        },
      });
    });
  }
}
