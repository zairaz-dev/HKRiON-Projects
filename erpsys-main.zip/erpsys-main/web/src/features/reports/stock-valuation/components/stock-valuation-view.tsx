import React from "react";
import {
  Layers,
  Printer,
  Package,
  DollarSign,
  AlertTriangle,
  Building2,
  TrendingUp,
  Search
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useStockValuationQuery } from "../hooks/use-stock-valuation";
import { useCurrency } from "@/hooks/use-currency";

interface StockValuationViewProps {
  businessId: string;
  branchId?: string;
  searchQuery?: string;
  onSearchChange?: (val: string) => void;
}

export function StockValuationView({
  businessId,
  branchId,
  searchQuery = "",
  onSearchChange,
}: StockValuationViewProps) {
  const { symbol } = useCurrency(businessId);
  const { data, isLoading } = useStockValuationQuery(businessId, {
    branchId,
    search: searchQuery,
  });

  const handlePrint = () => {
    window.print();
  };

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="text-center space-y-2">
          <div className="w-8 h-8 border-4 border-zinc-700 border-t-emerald-500 rounded-full animate-spin mx-auto" />
          <span className="text-sm text-muted-foreground block">Calculating Stock Valuation...</span>
        </div>
      </div>
    );
  }

  const {
    totalStockUnits = 0,
    totalCostValue = 0,
    totalSellingValue = 0,
    potentialProfitMargin = 0,
    items = [],
    lowStockItems = [],
  } = data || {};

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Action Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold tracking-tight flex items-center gap-2">
            <Layers className="h-5 w-5 text-primary" /> Stock Valuation & Inventory Summary
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Total active stock units, purchase cost value, selling value, and margin breakdown.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onSearchChange && (
            <div className="relative w-48 sm:w-60">
              <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search product or SKU..."
                className="pl-8 h-8 text-xs"
              />
            </div>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={handlePrint}
            className="gap-1.5 text-xs h-8 shrink-0"
          >
            <Printer className="h-3.5 w-3.5" /> Print Valuation
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-card border border-border/60 rounded-sm p-4 space-y-1 shadow-sm">
          <span className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
            <Package className="h-3 w-3 text-primary" /> Total Stock Units
          </span>
          <p className="text-2xl font-black text-foreground font-mono">
            {totalStockUnits.toLocaleString()} <span className="text-xs font-sans font-normal text-muted-foreground">units</span>
          </p>
        </div>

        <div className="bg-card border border-border/60 rounded-sm p-4 space-y-1 shadow-sm">
          <span className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
            <DollarSign className="h-3 w-3 text-amber-500" /> Total Purchase Cost Value
          </span>
          <p className="text-2xl font-black text-amber-500 font-mono">
            {symbol}{totalCostValue.toFixed(2)}
          </p>
        </div>

        <div className="bg-card border border-border/60 rounded-sm p-4 space-y-1 shadow-sm">
          <span className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
            <DollarSign className="h-3 w-3 text-emerald-500" /> Total Selling Value
          </span>
          <p className="text-2xl font-black text-emerald-500 font-mono">
            {symbol}{totalSellingValue.toFixed(2)}
          </p>
        </div>

        <div className="bg-card border border-border/60 rounded-sm p-4 space-y-1 shadow-sm">
          <span className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
            <TrendingUp className="h-3 w-3 text-primary" /> Potential Net Profit Margin
          </span>
          <p className="text-2xl font-black text-primary font-mono">
            {symbol}{potentialProfitMargin.toFixed(2)}
          </p>
        </div>
      </div>

      {/* Low Stock Alert Warning Box */}
      {lowStockItems.length > 0 && (
        <div className="p-4 rounded-sm bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-400 space-y-2">
          <div className="flex items-center gap-2 font-bold text-sm">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            <span>Low Stock Alert ({lowStockItems.length} Products running low)</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 text-xs">
            {lowStockItems.slice(0, 6).map((item: any) => (
              <div key={item.variantId} className="bg-background/60 p-2 rounded-sm border border-amber-500/20 flex justify-between items-center">
                <span className="truncate font-medium">{item.productName}</span>
                <span className="font-bold font-mono px-1.5 py-0.5 rounded-sm bg-amber-500/20 text-amber-600 dark:text-amber-300">
                  {item.stockQty} remaining
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Stock Items Breakdown Table */}
      <div className="space-y-2">
        <span className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider block">
          Inventory Items Valuation Breakdown ({items.length} Variants)
        </span>
        <div className="border border-border/60 rounded-sm overflow-hidden shadow-sm">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-muted/40 border-b border-border/60">
                <th className="p-3 font-semibold text-muted-foreground">Product & SKU</th>
                <th className="p-3 font-semibold text-muted-foreground">Branch</th>
                <th className="p-3 font-semibold text-muted-foreground text-center">Remaining Stock</th>
                <th className="p-3 font-semibold text-muted-foreground text-right">Unit Cost ({symbol})</th>
                <th className="p-3 font-semibold text-muted-foreground text-right">Total Cost Value</th>
                <th className="p-3 font-semibold text-muted-foreground text-right pr-4">Total Selling Value</th>
              </tr>
            </thead>
            <tbody>
              {items.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-muted-foreground">
                    No active stock items found.
                  </td>
                </tr>
              ) : (
                items.map((item: any, idx: number) => (
                  <tr key={`${item.variantId}-${idx}`} className="border-b border-border/40 hover:bg-muted/15 transition-colors">
                    <td className="p-3">
                      <span className="font-semibold text-foreground block">{item.productName}</span>
                      <span className="text-[10px] font-mono text-muted-foreground">SKU: {item.sku}</span>
                    </td>
                    <td className="p-3">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-secondary text-secondary-foreground text-[10px] font-bold">
                        <Building2 className="h-3 w-3" /> {item.branchName}
                      </span>
                    </td>
                    <td className="p-3 text-center font-bold font-mono">
                      {item.stockQty}
                    </td>
                    <td className="p-3 text-right font-mono">
                      {symbol}{item.costPrice.toFixed(2)}
                    </td>
                    <td className="p-3 text-right font-mono text-amber-500 font-semibold">
                      {symbol}{item.totalCost.toFixed(2)}
                    </td>
                    <td className="p-3 text-right font-mono text-emerald-500 font-bold pr-4">
                      {symbol}{item.totalSelling.toFixed(2)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
