import { Controller, Post, Body, Get, Param, Query, UseGuards, Req } from '@nestjs/common';
import { StockAdjustmentsService } from './stock-adjustments.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';
import { AdjustmentType } from '@prisma/client';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('stock-adjustments')
export class StockAdjustmentsController {
  constructor(private readonly stockAdjustmentsService: StockAdjustmentsService) {}

  @Permissions(Permission.PRODUCT_CREATE)
  @Post()
  async createStockAdjustment(@Req() req: any, @Body() body: any) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }

    const {
      adjustmentDate,
      type,
      reason,
      branchId,
      businessId,
      notes,
      createdById,
      adjustmentLines,
    } = body;

    return this.stockAdjustmentsService.createStockAdjustment({
      adjustmentDate: adjustmentDate ? new Date(adjustmentDate) : undefined,
      type: type as AdjustmentType,
      reason,
      branchId,
      businessId,
      notes,
      createdById: createdById || user.id,
      adjustmentLines,
    });
  }

  @Permissions(Permission.PRODUCT_VIEW)
  @Get()
  async getStockAdjustments(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
    @Query('type') type?: AdjustmentType,
    @Query('search') search?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.stockAdjustmentsService.getStockAdjustments(bId, {
      branchId,
      type,
      search,
      page: page ? Number(page) : undefined,
      limit: limit ? Number(limit) : undefined,
    });
  }

  @Permissions(Permission.PRODUCT_VIEW)
  @Get(':id')
  async getStockAdjustmentById(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.stockAdjustmentsService.getStockAdjustmentById(id, bId);
  }
}

