# HKRION ERP Standalone Backend (API)

This is a standalone NestJS backend application, separated from the monorepo for easier VPS deployment.

## Local Run Instructions

1. **Install Dependencies**:

   ```bash
   pnpm install
   # or
   npm install --legacy-peer-deps
   ```

2. **Generate Prisma Client**:

   ```bash
   npx prisma generate
   ```

3. **Database Schema Push**:
   Connect to your local PostgreSQL database and push the schema:

   ```bash
   npx prisma db push
   ```

4. **Run in Development Mode**:

   ```bash
   pnpm start:dev
   # or
   npm run start:dev
   ```

5. **Build and Run in Production Mode**:
   ```bash
   pnpm build
   pnpm start:prod
   # or
   npm run build
   npm run start:prod
   ```

---

## VPS Deployment Instructions

### 1. File Upload

Upload the `backend` folder to your VPS (via GitHub, FTP, or SCP). *(Note: Exclude `node_modules` and `dist` directories during upload).*

### 2. Environment Variables Setup (`.env`)

Create a `.env` file on your VPS and configure your production database credentials:

```env
DB_HOST="YOUR_PRODUCTION_DB_HOST"
DB_PORT="5432"
DB_USER="YOUR_PRODUCTION_DB_USER"
DB_PASSWORD="YOUR_PRODUCTION_DB_PASSWORD"
DB_NAME="YOUR_PRODUCTION_DB_NAME"
DB_SCHEMA="public"
DATABASE_URL="postgresql://${DB_USER}:${DB_PASSWORD}@${DB_HOST}:${DB_PORT}/${DB_NAME}?schema=${DB_SCHEMA}"
```

### 3. Deployment Commands

In your VPS terminal, navigate to the project directory and run the following commands:

```bash
# 1. Install dependencies
pnpm install

# 2. Generate Prisma client
npx prisma generate

# 3. Apply database schema / migrations
chmod -R +x node_modules/.pnpm/@prisma+engines*
chmod -R +x node_modules/.bin
npx prisma db push

# 4. Build the API
pnpm build

# 5. Run in background using PM2 (Process Manager)
pm2 restart hkr-erp-api

# or

pm2 restart all
```

*(Note: If PM2 is not installed, install it globally via `npm install -g pm2`)*

### Prisma Studio (Optional)

```bash
npx prisma studio
```
