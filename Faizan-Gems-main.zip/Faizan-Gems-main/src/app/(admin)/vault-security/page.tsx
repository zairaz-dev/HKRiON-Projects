import AdminDashboard from "@/features/admin/AdminDashboard";

export default function VaultSecurityPage() {
  return <AdminDashboard initialTab="vault_security" />;
}
