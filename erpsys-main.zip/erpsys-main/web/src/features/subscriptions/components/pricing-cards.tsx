"use strict";
"use client";

import React, { useState, useEffect, useMemo } from 'react';
import { Plan, BillingInterval } from '../types';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Check,
  Zap,
  Building,
  Rocket,
  Shield,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useUserCountry } from '@/hooks/use-user-country';
import { UpgradeModal } from './upgrade-modal';
import { ContactSalesDialog } from '@/components/contact-sales-dialog';

interface PricingCardsProps {
  plans: Plan[];
  currentPlanId?: string;
  initialCurrency?: 'LKR' | 'USD';
  onUpgradeSuccess?: () => void;
}

export function PricingCards({ plans, currentPlanId, initialCurrency, onUpgradeSuccess }: PricingCardsProps) {
  const { isSriLanka } = useUserCountry();
  const currency: 'LKR' | 'USD' = initialCurrency || (isSriLanka ? 'LKR' : 'USD');
  const [interval, setInterval] = useState<BillingInterval>('MONTHLY');
  const [selectedPlanForUpgrade, setSelectedPlanForUpgrade] = useState<Plan | null>(null);
  const [isContactSalesOpen, setIsContactSalesOpen] = useState(false);

  // Dynamically calculate savings percentage based on standard SaaS plans (excluding custom deals & trial)
  const maxSavingsPercent = useMemo(() => {
    let maxPercent = 0;
    plans.forEach((plan) => {
      if (plan.isCustom || plan.slug === 'trial') return;
      const monthly = currency === "USD" ? (plan.priceMonthlyUsd || 0) : plan.priceMonthly;
      const yearly = currency === "USD" ? (plan.priceYearlyUsd || 0) : plan.priceYearly;
      if (monthly > 0 && yearly > 0) {
        const fullYear = monthly * 12;
        if (fullYear > yearly) {
          const percent = Math.round(((fullYear - yearly) / fullYear) * 100);
          if (percent > maxPercent) {
            maxPercent = percent;
          }
        }
      }
    });
    return maxPercent > 0 ? maxPercent : 17;
  }, [plans, currency]);

  // If user has a custom plan or is on a custom plan, exclude generic enterprise plan and place the custom deal at the 4th position
  const displayedPlans = useMemo(() => {
    const hasCustom = plans.some((p) => p.isCustom) || plans.some((p) => p.id === currentPlanId && p.isCustom);
    if (hasCustom) {
      const filtered = plans.filter(
        (p) => p.slug !== 'enterprise' && !(p.name?.toLowerCase().includes('enterprise') && !p.isCustom)
      );
      return [...filtered].sort((a, b) => {
        if (a.isCustom && !b.isCustom) return 1;
        if (!a.isCustom && b.isCustom) return -1;
        return (a.sortOrder || 0) - (b.sortOrder || 0);
      });
    }
    return plans;
  }, [plans, currentPlanId]);

  return (
    <div className="space-y-6">
      {/* Billing Interval Toggle (Centered - Exact Pricing Page Logic, No Currency Switcher) */}
      <div className="flex items-center justify-center pt-2">
        <div className="bg-card/70 p-1 rounded-sm border border-border/80 backdrop-blur-md flex items-center gap-1 shadow-md">
          <button
            type="button"
            onClick={() => setInterval('MONTHLY')}
            className={cn(
              "px-4 py-1.5 rounded-sm text-xs font-mono font-bold transition-all",
              interval === 'MONTHLY'
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground'
            )}
          >
            Monthly Billing
          </button>
          <button
            type="button"
            onClick={() => setInterval('YEARLY')}
            className={cn(
              "px-4 py-1.5 rounded-sm text-xs font-mono font-bold transition-all flex items-center gap-2",
              interval === 'YEARLY'
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground'
            )}
          >
            Yearly Billing
            <span
              className={cn(
                "px-1.5 py-0.5 rounded-sm text-[9px] font-extrabold font-mono transition-colors border",
                interval === 'YEARLY'
                  ? 'bg-black/25 text-black border-black/30 shadow-sm'
                  : 'bg-primary/20 text-primary border-primary/30'
              )}
            >
              SAVE {maxSavingsPercent}%
            </span>
          </button>
        </div>
      </div>

      {/* Pricing Cards Grid (Exact Pricing Page Compact Dimensions & Layout) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 items-stretch">
        {displayedPlans.map((plan, idx) => {
          const isCurrent = currentPlanId === plan.id;
          const isPopular = plan.isPopular && !isCurrent && !plan.isCustom;
          const isCustom = plan.isCustom && !isCurrent;
          const price = currency === "USD"
            ? (interval === "YEARLY"
                ? (plan.priceYearlyUsd || (plan.priceMonthlyUsd || 0) * 10)
                : (plan.priceMonthlyUsd || 0))
            : (interval === "YEARLY"
                ? (plan.priceYearly || plan.priceMonthly * 10)
                : plan.priceMonthly);
          const currencyPrefix = currency === "USD" ? "$" : "Rs.";

          return (
            <Card
              key={plan.id}
              className={cn(
                "backdrop-blur-md p-5 sm:p-6 flex flex-col justify-between h-full relative transition-all duration-300 rounded-sm",
                isCurrent
                  ? "border-2 border-emerald-500 bg-card/70 shadow-xl shadow-emerald-500/10 ring-1 ring-emerald-500/40 relative lg:-translate-y-1"
                  : isCustom
                  ? "border-2 border-amber-500/80 bg-card/70 shadow-xl shadow-amber-500/10 ring-1 ring-amber-500/30 relative lg:-translate-y-1"
                  : isPopular
                  ? "border-2 border-primary bg-card/70 shadow-xl shadow-primary/10 relative lg:-translate-y-1"
                  : "border border-border/70 bg-card/40 hover:border-border"
              )}
            >
              {/* Badges on Top (Matching Pricing Page rounded-sm font-mono) */}
              {isCurrent && (
                <span className="absolute top-0 right-1/2 translate-x-1/2 -translate-y-1/2 bg-emerald-500 text-black text-[9px] font-extrabold font-mono tracking-wider uppercase px-3 py-1 rounded-sm border border-emerald-400 shadow-md flex items-center gap-1">
                  <Shield className="w-3 h-3" /> CURRENT PLAN
                </span>
              )}
              {isCustom && (
                <span className="absolute top-0 right-1/2 translate-x-1/2 -translate-y-1/2 bg-amber-500 text-black text-[9px] font-black font-mono tracking-wider uppercase px-3 py-1 rounded-sm border border-amber-400 shadow-md flex items-center gap-1 whitespace-nowrap">
                  <Sparkles className="w-3 h-3" /> EXCLUSIVE CONTRACT DEAL
                </span>
              )}
              {isPopular && (
                <span className="absolute top-0 right-1/2 translate-x-1/2 -translate-y-1/2 bg-primary text-primary-foreground text-[9px] font-extrabold font-mono tracking-wider uppercase px-3 py-1 rounded-sm border border-primary/30 shadow-md flex items-center gap-1">
                  <Sparkles className="w-3 h-3" /> MOST POPULAR
                </span>
              )}

              <div className="space-y-4">
                {/* Icon & Plan Type Badge */}
                <div className="flex items-center justify-between">
                  <div
                    className={cn(
                      "w-9 h-9 rounded-sm border flex items-center justify-center",
                      isCurrent
                        ? "bg-emerald-500/15 text-emerald-400 border-emerald-500/30"
                        : isCustom
                        ? "bg-amber-500/15 text-amber-400 border-amber-500/30"
                        : isPopular
                        ? "bg-primary/15 text-primary border-primary/30"
                        : "bg-secondary text-primary border-border"
                    )}
                  >
                    {idx === 0 && <Building className="w-4 h-4" />}
                    {idx === 1 && <Rocket className="w-4 h-4" />}
                    {idx === 2 && <Zap className="w-4 h-4" />}
                    {idx >= 3 && <Shield className="w-4 h-4" />}
                  </div>
                  <span
                    className={cn(
                      "text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded-sm border",
                      isCurrent
                        ? "text-emerald-400 bg-emerald-500/10 border-emerald-500/20"
                        : isCustom
                        ? "text-amber-400 bg-amber-500/10 border-amber-500/20"
                        : "text-primary bg-primary/10 border-primary/20"
                    )}
                  >
                    {isCustom ? "CUSTOM CONTRACT" : plan.trialDays ? `${plan.trialDays}-DAY TRIAL` : "FULL ACCESS"}
                  </span>
                </div>

                {/* Name & Description */}
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-foreground tracking-tight">{plan.name}</h3>
                  <p className="text-xs text-muted-foreground mt-1 leading-relaxed min-h-[36px] line-clamp-2">
                    {plan.description || "Enterprise grade capabilities for your organization."}
                  </p>
                </div>

                {/* Price Section */}
                <div className="pt-1">
                  {plan.slug === "enterprise" && !plan.isCustom ? (
                    <div>
                      <div className="text-2xl sm:text-3xl font-extrabold font-mono text-foreground tracking-tight">
                        Custom
                      </div>
                      <p className="text-[10px] text-muted-foreground font-mono mt-0.5">
                        Tailored quote for your scale
                      </p>
                    </div>
                  ) : (
                    <div>
                      {currency === "USD" && !Number.isInteger(price) ? (
                        <div className="flex items-start font-mono tracking-tight">
                          <span className="text-4xl sm:text-5xl font-black text-foreground leading-none">
                            {Math.floor(price)}
                          </span>
                          <div className="flex flex-col justify-between self-stretch ml-0.5 py-0.5 select-none font-mono">
                            <span className="text-lg sm:text-xl font-black text-foreground leading-none">
                              .{Number((price % 1).toFixed(2)).toFixed(2).split(".")[1]}
                            </span>
                            <span className="text-[10px] sm:text-[11px] font-bold text-muted-foreground leading-none mt-1">
                              $/ {interval === "YEARLY" ? "year" : "month"}
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-baseline gap-1 font-mono">
                          <span className="text-xs font-bold text-muted-foreground">
                            {currencyPrefix}
                          </span>
                          <span className="text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight">
                            {price.toLocaleString(undefined, {
                              minimumFractionDigits: currency === "USD" && !Number.isInteger(price) ? 2 : 0,
                              maximumFractionDigits: 2,
                            })}
                          </span>
                          <span className="text-xs text-muted-foreground font-mono">
                            /{interval === "YEARLY" ? "year" : "mo"}
                          </span>
                        </div>
                      )}
                      {interval === "YEARLY" && (
                        <p className="text-[10px] text-primary font-mono mt-0.5">
                          Billed annually (2 months free)
                        </p>
                      )}
                    </div>
                  )}
                </div>

                {/* Compact Features List (Exact Pricing Page Style) */}
                <div className="border-t border-border/60 pt-4 space-y-2.5 text-xs">
                  <div className="flex items-center gap-2.5 text-muted-foreground">
                    <Check className="w-3.5 h-3.5 text-primary shrink-0" />
                    <span>
                      <strong className="text-foreground">{plan.maxBranches <= 0 ? "Unlimited" : plan.maxBranches}</strong> Store Locations
                    </span>
                  </div>
                  <div className="flex items-center gap-2.5 text-muted-foreground">
                    <Check className="w-3.5 h-3.5 text-primary shrink-0" />
                    <span>
                      <strong className="text-foreground">{plan.maxUsers <= 0 ? "Unlimited" : plan.maxUsers}</strong> Staff Accounts
                    </span>
                  </div>
                  <div className="flex items-center gap-2.5 text-muted-foreground">
                    <Check className="w-3.5 h-3.5 text-primary shrink-0" />
                    <span>
                      <strong className="text-foreground">{plan.maxProducts <= 0 ? "Unlimited" : plan.maxProducts.toLocaleString()}</strong> Inventory SKUs
                    </span>
                  </div>
                  <div className="flex items-center gap-2.5 text-muted-foreground">
                    <Check className="w-3.5 h-3.5 text-primary shrink-0" />
                    <span>
                      <strong className="text-foreground">{plan.maxInvoicesMonthly <= 0 ? "Unlimited" : plan.maxInvoicesMonthly.toLocaleString()}</strong> Monthly Invoices
                    </span>
                  </div>
                  <div className="flex items-center gap-2.5 text-muted-foreground">
                    <Check className="w-3.5 h-3.5 text-primary shrink-0" />
                    <span>POS Terminal & Billing System</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-muted-foreground">
                    <Check className="w-3.5 h-3.5 text-primary shrink-0" />
                    <span>{plan.enableImei ? "IMEI Tracker & Accounting" : "PayHere & Bank Slip Checkout"}</span>
                  </div>
                </div>
              </div>

              {/* CTA Action Button */}
              <div className="pt-6">
                {isCurrent ? (
                  <Button
                    type="button"
                    disabled
                    className="w-full text-xs h-10 rounded-sm font-bold font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 cursor-default flex items-center justify-center gap-1.5"
                  >
                    <Shield className="w-3.5 h-3.5" />
                    <span>Active Plan</span>
                  </Button>
                ) : isCustom ? (
                  <Button
                    type="button"
                    onClick={() => setSelectedPlanForUpgrade(plan)}
                    className="w-full text-xs h-10 rounded-sm font-bold font-mono bg-amber-500 hover:bg-amber-600 text-black shadow-md shadow-amber-500/20 flex items-center justify-center gap-1.5 transition-all"
                  >
                    <span>Subscribe to Contract</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Button>
                ) : plan.slug === "enterprise" ? (
                  <Button
                    type="button"
                    onClick={() => setIsContactSalesOpen(true)}
                    className="w-full text-xs h-10 rounded-sm font-bold font-mono transition-all border border-primary/40 bg-primary/10 hover:bg-primary text-foreground hover:text-primary-foreground shadow-sm flex items-center justify-center gap-1.5"
                  >
                    <span>Contact Sales</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Button>
                ) : (
                  <Button
                    type="button"
                    onClick={() => setSelectedPlanForUpgrade(plan)}
                    className={cn(
                      "w-full text-xs h-10 rounded-sm font-bold font-mono transition-all flex items-center justify-center gap-1.5",
                      isPopular
                        ? "bg-primary hover:bg-primary/90 text-primary-foreground shadow-md shadow-primary/20"
                        : "bg-secondary hover:bg-secondary/80 text-foreground border border-border"
                    )}
                  >
                    <span>{plan.priceMonthly === 0 ? "Start Free Trial" : "Upgrade Plan"}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Button>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      {/* Upgrade Modal */}
      {selectedPlanForUpgrade && (
        <UpgradeModal
          plan={selectedPlanForUpgrade}
          initialInterval={interval}
          currency={currency}
          isOpen={!!selectedPlanForUpgrade}
          onClose={() => setSelectedPlanForUpgrade(null)}
          onSuccess={onUpgradeSuccess}
        />
      )}

      {/* Contact Sales Modal */}
      <ContactSalesDialog
        isOpen={isContactSalesOpen}
        onClose={() => setIsContactSalesOpen(false)}
        defaultPlanName="Enterprise Plan"
      />
    </div>
  );
}

