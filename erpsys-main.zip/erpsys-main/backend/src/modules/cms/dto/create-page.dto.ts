import { IsBoolean, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class CreateCmsPageDto {
  @IsNotEmpty()
  @IsString()
  slug: string;

  @IsNotEmpty()
  @IsString()
  title: string;

  @IsNotEmpty()
  @IsString()
  content: string;

  @IsOptional()
  @IsString()
  metaDescription?: string;

  @IsOptional()
  @IsBoolean()
  isPublished?: boolean;
}

import { PartialType } from '@nestjs/swagger';

export class UpdateCmsPageDto extends PartialType(CreateCmsPageDto) {}
