"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import {
  Users,
  ArrowLeft,
  Loader2,
  CheckCircle,
  AlertCircle,
  Building2,
  Coins,
  FileText,
  Trash2,
  Plus,
  Link2,
  Upload,
  RotateCcw,
  Printer,
  Filter,
  CreditCard,
  Calendar,
  Phone,
  Mail,
  DollarSign,
  TrendingUp,
  History,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { DataTable, ColumnDef, ActionsDropdown } from "@/components/ui/table";
import { authService } from "@/services/auth-service";
import { supplierService } from "@/services/supplier-service";
import { getFullAssetUrl } from "@/lib/utils";
import { User } from "@hkr/types";

import { useSupplierDetailQuery, useBranchesQuery } from "@/features/suppliers";
import { usePurchasesQuery } from "@/features/purchases";
import {
  useSupplierPaymentsQuery,
  useDeleteSupplierPaymentMutation,
  SupplierPaymentDialog
} from "@/features/supplier-payments";
import { usePaymentMethodsQuery } from "@/features/payment-methods";
import {
  useSupplierAdvancesQuery,
  useDeleteSupplierAdvanceMutation,
  useDeleteSupplierAdvanceAllocationMutation,
  useRefundSupplierAdvanceMutation,
  SupplierAdvanceDialog
} from "@/features/supplier-advances";
import { useCurrency } from "@/hooks/use-currency";

function SupplierViewPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const id = searchParams.get("id") as string;

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    if (typeof window !== "undefined") {
      return authService.getCurrentUser();
    }
    return null;
  });
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(() => {
    if (typeof window !== "undefined") {
      return authService.isAuthenticated();
    }
    return null;
  });

  // Photo upload state
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState<boolean>(false);

  // Success / Error notifications
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Tab State: "invoices" | "payments" | "advances" | "returns" | "statement"
  const [activeTab, setActiveTab] = useState<"invoices" | "payments" | "advances" | "returns" | "statement">("invoices");
  const [statementFilter, setStatementFilter] = useState<"all" | "month" | "30days" | "year">("all");

  // Dialog open states
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState<boolean>(false);
  const [isAdvanceDialogOpen, setIsAdvanceDialogOpen] = useState<boolean>(false);

  // Main Advance refund state
  const [isRefundOpen, setIsRefundOpen] = useState<boolean>(false);
  const [refundAmount, setRefundAmount] = useState<number>(0);
  const [refundNotes, setRefundNotes] = useState<string>("");
  const [selectedBranchId, setSelectedBranchId] = useState<string>("");
  const [selectedPaymentMethodId, setSelectedPaymentMethodId] = useState<string>("");
  const refundMutation = useRefundSupplierAdvanceMutation();

  // Auth check
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  const businessId = currentUser?.businessId || "";
  const { symbol, format } = useCurrency(businessId);

  // Queries
  const { data: supplier, isLoading: supplierLoading, error: supplierError, refetch: refetchSupplier } = useSupplierDetailQuery(id, businessId);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !id) return;

    if (file.size > 5 * 1024 * 1024) {
      setError("Image file size must be under 5MB.");
      return;
    }

    try {
      setIsUploadingPhoto(true);
      await supplierService.uploadImage(file, id);
      setSuccessMessage("Supplier profile photo updated successfully!");
      refetchSupplier();
    } catch (err: any) {
      setError(err.message || "Failed to upload photo.");
    } finally {
      setIsUploadingPhoto(false);
    }
  };
  const { data: purchasesResponse, isLoading: purchasesLoading } = usePurchasesQuery(businessId, { supplierId: id, limit: 100 });
  const { data: payments = [], isLoading: paymentsLoading } = useSupplierPaymentsQuery(businessId, { supplierId: id });
  const { data: advances = [], isLoading: advancesLoading } = useSupplierAdvancesQuery(businessId, { supplierId: id });

  const { data: branches = [] } = useBranchesQuery(businessId);
  const { data: paymentMethods = [] } = usePaymentMethodsQuery(businessId, selectedBranchId || undefined, true);

  useEffect(() => {
    if (branches.length > 0 && !selectedBranchId) {
      setSelectedBranchId(branches[0].id);
    }
  }, [branches, selectedBranchId]);

  useEffect(() => {
    if (paymentMethods.length > 0 && !selectedPaymentMethodId) {
      setSelectedPaymentMethodId(paymentMethods[0].id);
    }
  }, [paymentMethods, selectedPaymentMethodId]);

  const remainingAdvance = (advances || []).reduce((sum: number, a: any) => sum + (a.amountRemaining || 0), 0);

  const handleRefundSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !businessId) return;

    if (refundAmount <= 0) {
      setError("Please enter a valid refund amount.");
      return;
    }

    if (refundAmount > remainingAdvance) {
      setError(`Refund amount cannot exceed available advance credit of ${format(remainingAdvance)}.`);
      return;
    }

    if (!selectedBranchId) {
      setError("Please select a branch.");
      return;
    }

    if (!selectedPaymentMethodId) {
      setError("Please select a payment method.");
      return;
    }

    try {
      await refundMutation.mutateAsync({
        supplierId: id,
        amount: refundAmount,
        paymentMethodId: selectedPaymentMethodId,
        branchId: selectedBranchId,
        businessId,
        notes: refundNotes,
      });

      setSuccessMessage(`Successfully refunded ${format(refundAmount)} from supplier advance!`);
      setIsRefundOpen(false);
      setRefundAmount(0);
      setRefundNotes("");
      refetchSupplier();
    } catch (err: any) {
      setError(err.message || "Failed to process advance refund.");
    }
  };

  // Delete mutations
  const deletePaymentMutation = useDeleteSupplierPaymentMutation();
  const deleteAdvanceMutation = useDeleteSupplierAdvanceMutation();
  const deleteAllocationMutation = useDeleteSupplierAdvanceAllocationMutation();

  const purchasesList = purchasesResponse?.data || [];

  const handleDeletePayment = async (paymentId: string) => {
    if (!window.confirm("Are you sure you want to delete this payment record? This will increase the remaining due on its corresponding invoice.")) {
      return;
    }

    try {
      await deletePaymentMutation.mutateAsync({ id: paymentId, businessId });
      setSuccessMessage("Payment record deleted successfully!");
    } catch (err: any) {
      setError(err.message || "Failed to delete payment record.");
    }
  };

  const handleDeleteAdvance = async (advanceId: string) => {
    if (!window.confirm("Are you sure you want to delete this advance payment record? This will fail if parts of it are already allocated to purchase invoices.")) {
      return;
    }

    try {
      await deleteAdvanceMutation.mutateAsync({ id: advanceId, businessId });
      setSuccessMessage("Supplier advance payment record deleted successfully!");
    } catch (err: any) {
      setError(err.message || "Failed to delete advance payment record.");
    }
  };

  const handleDeleteAllocation = async (allocationId: string) => {
    if (!window.confirm("Are you sure you want to delete this advance allocation? The corresponding purchase invoice remaining due will increase.")) {
      return;
    }

    try {
      await deleteAllocationMutation.mutateAsync({ id: allocationId, businessId });
      setSuccessMessage("Advance allocation removed successfully!");
    } catch (err: any) {
      setError(err.message || "Failed to remove advance allocation.");
    }
  };

  // Auto-dismiss notifications
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  // Calculate totals
  const totalPurchasesSum = purchasesList.reduce((sum: number, p: any) => sum + p.grandTotal, 0);
  const totalPaidSum = payments.reduce((sum: number, pay: any) => sum + pay.amount, 0) +
                       advances.reduce((sum: number, adv: any) => sum + adv.amount, 0);

  // Purchases columns definition
  const purchaseColumns: ColumnDef<any>[] = [
    {
      header: "Invoice / Bill #",
      render: (p) => <span className="font-mono font-bold text-foreground">{p.purchaseNumber}</span>,
    },
    {
      header: "Date",
      render: (p) => (
        <span className="text-xs">
          {new Date(p.purchaseDate).toLocaleDateString("en-IN", {
            day: "2-digit",
            month: "short",
            year: "numeric"
          })}
        </span>
      ),
    },
    {
      header: "Branch",
      render: (p) => (
        <span className="inline-flex items-center gap-1 text-xs font-semibold text-foreground/80">
          <Building2 className="h-3.5 w-3.5 text-muted-foreground/60" />
          {p.branch?.name || "N/A"}
        </span>
      ),
    },
    {
      header: "Grand Total",
      align: "right",
      render: (p) => <span className="font-mono text-xs font-bold inline-block w-full text-right">{format(p.grandTotal)}</span>,
    },
    {
      header: "Paid",
      align: "right",
      render: (p) => <span className="font-mono text-xs font-semibold text-emerald-600 dark:text-emerald-400 inline-block w-full text-right">{format(p.amountPaid)}</span>,
    },
    {
      header: "Due",
      align: "right",
      render: (p) => {
        const remaining = Math.max(0, p.grandTotal - p.amountPaid);
        return (
          <span className={`font-mono text-xs font-bold inline-block w-full text-right ${remaining > 0.01 ? "text-rose-500 font-extrabold" : "text-muted-foreground"}`}>
            {format(remaining)}
          </span>
        );
      },
    },
    {
      header: "Payment Status",
      render: (p) => {
        let badgeClass = "bg-rose-500/10 text-rose-500 border-rose-500/20";
        if (p.paymentStatus === "PAID") {
          badgeClass = "bg-emerald-500/10 text-emerald-500 border-emerald-500/20";
        } else if (p.paymentStatus === "PARTIAL") {
          badgeClass = "bg-amber-500/10 text-amber-500 border-amber-500/20";
        }
        return (
          <span className={`inline-flex items-center px-2 py-0.5 rounded border text-[10px] font-extrabold tracking-wide uppercase ${badgeClass}`}>
            {p.paymentStatus}
          </span>
        );
      },
    },
    {
      header: "Actions",
      render: (p) => (
        <ActionsDropdown
          actions={[
            {
              label: "Edit Purchase",
              onClick: () => router.push(`/purchases/edit?id=${p.id}`),
              icon: <FileText className="h-3.5 w-3.5" />,
            }
          ]}
        />
      ),
    }
  ];

  // Payments columns definition
  const paymentColumns: ColumnDef<any>[] = [
    {
      header: "Payment Receipt #",
      render: (pay) => <span className="font-mono font-bold text-foreground">{pay.paymentNumber}</span>,
    },
    {
      header: "Date",
      render: (pay) => (
        <span className="text-xs">
          {new Date(pay.paymentDate).toLocaleDateString("en-IN", {
            day: "2-digit",
            month: "short",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit"
          })}
        </span>
      ),
    },
    {
      header: "Amount Paid",
      align: "right",
      render: (pay) => (
        <span className="font-mono text-xs font-black text-emerald-500 bg-emerald-500/5 px-2 py-0.5 rounded border border-emerald-500/10 inline-block">
          {format(pay.amount)}
        </span>
      ),
    },
    {
      header: "Method",
      render: (pay) => (
        <span className="text-xs font-semibold uppercase bg-secondary text-secondary-foreground px-1.5 py-0.5 rounded border border-border">
          {pay.paymentMethod?.name || "N/A"}
        </span>
      ),
    },
    {
      header: "Reference / Ref No",
      render: (pay) => <span className="font-mono text-xs text-muted-foreground">{pay.transactionNo || "None"}</span>,
    },
    {
      header: "Notes",
      render: (pay) => <span className="text-xs text-muted-foreground italic truncate max-w-[150px] inline-block">{pay.notes || "None"}</span>,
    },
    {
      header: "Actions",
      render: (pay) => (
        <Button
          variant="ghost"
          size="icon"
          onClick={() => handleDeletePayment(pay.id)}
          className="h-8 w-8 text-destructive hover:bg-destructive/10 rounded"
          title="Delete payment receipt"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      ),
    }
  ];

  // Advances columns definition
  const advanceColumns: ColumnDef<any>[] = [
    {
      header: "Advance Receipt #",
      render: (adv) => <span className="font-mono font-bold text-foreground">{adv.advanceNumber}</span>,
    },
    {
      header: "Date",
      render: (adv) => (
        <span className="text-xs">
          {new Date(adv.advanceDate).toLocaleDateString("en-IN", {
            day: "2-digit",
            month: "short",
            year: "numeric"
          })}
        </span>
      ),
    },
    {
      header: "Paid Amount",
      align: "right",
      render: (adv) => <span className="font-mono text-xs font-bold text-emerald-500 inline-block w-full text-right">{format(adv.amount)}</span>,
    },
    {
      header: "Remaining Unused",
      align: "right",
      render: (adv) => (
        <span className={`font-mono text-xs font-black px-2 py-0.5 rounded border inline-block ${
          adv.amountRemaining > 0.01 
            ? "text-blue-500 bg-blue-500/5 border-blue-500/10" 
            : "text-muted-foreground bg-muted/20 border-border"
        }`}>
          {format(adv.amountRemaining)}
        </span>
      ),
    },
    {
      header: "Method",
      render: (adv) => (
        <span className="text-xs font-semibold uppercase bg-secondary text-secondary-foreground px-1.5 py-0.5 rounded border border-border">
          {adv.paymentMethod?.name || "N/A"}
        </span>
      ),
    },
    {
      header: "Allocations Ledger",
      render: (adv) => (
        <div className="flex flex-col gap-1 max-w-[200px]">
          {adv.allocations && adv.allocations.length > 0 ? (
            adv.allocations.map((alloc: any) => (
              <div key={alloc.id} className="flex items-center justify-between gap-2 text-[10px] bg-secondary/50 px-2 py-0.5 rounded border border-border/40">
                <span className="font-bold text-foreground/70 flex items-center gap-1">
                  <Link2 className="h-3 w-3 text-muted-foreground" /> {alloc.purchase?.purchaseNumber || "Bill"}
                </span>
                <span className="font-mono font-bold text-rose-500">{format(alloc.amount)}</span>
                <button
                  onClick={() => handleDeleteAllocation(alloc.id)}
                  className="text-destructive hover:text-red-400 p-0.5 rounded"
                  title="Remove allocation mapping"
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              </div>
            ))
          ) : (
            <span className="text-[10px] text-muted-foreground italic">No invoice mappings yet</span>
          )}
        </div>
      ),
    },
    {
      header: "Actions",
      render: (adv) => (
        <Button
          variant="ghost"
          size="icon"
          onClick={() => handleDeleteAdvance(adv.id)}
          className="h-8 w-8 text-destructive hover:bg-destructive/10 rounded"
          disabled={adv.allocations?.length > 0}
          title={adv.allocations?.length > 0 ? "Delete allocation records first" : "Delete advance receipt"}
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      ),
    },
  ];

  // Purchase Returns columns definition
  const returnColumns: ColumnDef<any>[] = [
    {
      header: "Return #",
      render: (r) => (
        <span className="font-mono font-bold text-foreground text-xs">
          {r.returnNumber}
        </span>
      ),
    },
    {
      header: "Date",
      render: (r) => (
        <span className="text-xs text-muted-foreground flex items-center gap-1.5 font-medium whitespace-nowrap">
          <Calendar className="h-3.5 w-3.5" />
          {new Date(r.returnDate).toLocaleDateString("en-IN", {
            day: "2-digit",
            month: "short",
            year: "numeric",
          })}
        </span>
      ),
    },
    {
      header: "Grand Total",
      render: (r) => (
        <span className="font-extrabold text-rose-500 font-mono text-xs">
          {format(r.grandTotal)}
        </span>
      ),
    },
    {
      header: "Notes",
      render: (r) => (
        <span className="text-xs text-foreground/80 max-w-[250px] truncate block" title={r.notes || ""}>
          {r.notes || "-"}
        </span>
      ),
    },
  ];

  // Calculate Ledger Entries for Supplier Account Statement
  const ledgerEntries = React.useMemo(() => {
    if (!supplier) return [];

    interface RawSupplierEvent {
      date: string;
      type: "OPENING_BALANCE" | "PURCHASE" | "PAYMENT" | "ADVANCE" | "RETURN";
      ref: string;
      description: string;
      debit: number;
      credit: number;
    }

    const events: RawSupplierEvent[] = [];

    // 1. Initial Opening Balance
    const openingSettlements = (payments || [])
      .filter((p: any) => p.notes?.includes("Settlement of Opening Balance"))
      .reduce((sum: number, p: any) => sum + p.amount, 0);
    const initialOpening = (supplier.openingBalance || 0) + openingSettlements;

    if (initialOpening > 0) {
      events.push({
        date: supplier.createdAt || new Date().toISOString(),
        type: "OPENING_BALANCE",
        ref: "OPENING",
        description: "Initial Balance (Pre-existing Payable Owed)",
        debit: initialOpening,
        credit: 0,
      });
    }

    // 2. Purchase Bills (from supplier.purchases or purchasesList)
    const allPurchases = supplier.purchases || purchasesList || [];
    allPurchases.forEach((p: any) => {
      if (p.status === "CANCELLED") return;
      events.push({
        date: p.purchaseDate,
        type: "PURCHASE",
        ref: p.purchaseNumber,
        description: `Purchase Bill #${p.purchaseNumber}`,
        debit: p.grandTotal,
        credit: 0,
      });
    });

    // 3. Payments Made
    (payments || []).forEach((pay: any) => {
      events.push({
        date: pay.paymentDate,
        type: "PAYMENT",
        ref: pay.paymentNumber,
        description: pay.notes || `Payment Made (${pay.paymentMethod?.name || "Direct"})`,
        debit: 0,
        credit: pay.amount,
      });
    });

    // 4. Advances Given
    (advances || []).forEach((adv: any) => {
      events.push({
        date: adv.advanceDate,
        type: "ADVANCE",
        ref: adv.advanceNumber,
        description: adv.notes || `Advance Deposit (${adv.paymentMethod?.name || "Cash"})`,
        debit: 0,
        credit: adv.amount,
      });
    });

    // 5. Purchase Returns
    const allReturns = supplier.purchaseReturns || [];
    allReturns.forEach((ret: any) => {
      events.push({
        date: ret.returnDate,
        type: "RETURN",
        ref: ret.returnNumber,
        description: ret.notes || `Goods Return #${ret.returnNumber}`,
        debit: 0,
        credit: ret.grandTotal,
      });
    });

    // Sort chronologically
    events.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    // Apply period filter
    const now = new Date();
    const filteredEvents = events.filter((ev) => {
      const d = new Date(ev.date);
      if (statementFilter === "month") {
        return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
      }
      if (statementFilter === "30days") {
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(now.getDate() - 30);
        return d >= thirtyDaysAgo;
      }
      if (statementFilter === "year") {
        return d.getFullYear() === now.getFullYear();
      }
      return true;
    });

    // Compute running balance
    let running = 0;
    return filteredEvents.map((ev) => {
      running += ev.debit - ev.credit;
      return {
        ...ev,
        balance: running,
      };
    });
  }, [supplier, purchasesList, payments, advances, statementFilter]);

  // Ledger Table Columns Definition
  const ledgerColumns: ColumnDef<any>[] = [
    {
      header: "Date",
      render: (item) => (
        <span className="text-xs text-muted-foreground flex items-center gap-1.5 font-medium whitespace-nowrap">
          <Calendar className="h-3.5 w-3.5" />
          {new Date(item.date).toLocaleDateString("en-IN", {
            day: "2-digit",
            month: "short",
            year: "numeric",
          })}
        </span>
      ),
    },
    {
      header: "Type",
      render: (item) => {
        let badgeStyle = "bg-primary/10 text-primary border-primary/20";
        if (item.type === "PURCHASE") {
          badgeStyle = "bg-rose-500/10 text-rose-500 border-rose-500/20";
        } else if (item.type === "PAYMENT") {
          badgeStyle = "bg-emerald-500/10 text-emerald-500 border-emerald-500/20";
        } else if (item.type === "ADVANCE") {
          badgeStyle = "bg-blue-500/10 text-blue-500 border-blue-500/20";
        } else if (item.type === "RETURN") {
          badgeStyle = "bg-amber-500/10 text-amber-500 border-amber-500/20";
        }
        return (
          <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold border uppercase tracking-wider ${badgeStyle}`}>
            {item.type.replace("_", " ")}
          </span>
        );
      },
    },
    {
      header: "Ref / Voucher",
      render: (item) => (
        <span className="font-mono text-xs font-bold text-foreground">
          {item.ref}
        </span>
      ),
    },
    {
      header: "Description",
      render: (item) => (
        <span className="text-xs text-foreground/80 max-w-[280px] truncate block" title={item.description}>
          {item.description}
        </span>
      ),
    },
    {
      header: "Credit (Paid -)",
      align: "right",
      render: (item) => (
        <span className={`font-mono text-xs inline-block w-full text-right ${item.credit > 0 ? "font-bold text-emerald-500" : "text-muted-foreground/50"}`}>
          {item.credit > 0 ? format(item.credit) : "-"}
        </span>
      ),
    },
    {
      header: "Debit (Owed +)",
      align: "right",
      render: (item) => (
        <span className={`font-mono text-xs inline-block w-full text-right ${item.debit > 0 ? "font-bold text-rose-500" : "text-muted-foreground/50"}`}>
          {item.debit > 0 ? format(item.debit) : "-"}
        </span>
      ),
    },
    {
      header: "Running Balance",
      align: "right",
      render: (item) => (
        <span className={`font-mono text-xs font-black inline-block w-full text-right ${item.balance > 0 ? "text-rose-500" : "text-emerald-500"}`}>
          {format(Math.abs(item.balance))}
        </span>
      ),
    },
  ];

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3 p-6 max-w-sm border border-border/40 rounded-xl bg-card/60 backdrop-blur-sm">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <h2 className="text-lg font-bold">Unauthorized Access</h2>
          <p className="text-sm text-muted-foreground">Redirecting to login...</p>
          <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
        </div>
      </div>
    );
  }

  if (supplierLoading || (!supplier && !supplierError)) {
    return (
      <div className="flex h-screen bg-background text-foreground overflow-hidden">
        <Sidebar activePath="/suppliers" />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Navbar title="Supplier Profile" />
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center space-y-2">
              <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
              <span className="text-sm text-muted-foreground">Loading supplier profile...</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (supplierError || !supplier) {
    return (
      <div className="flex h-screen bg-background text-foreground overflow-hidden">
        <Sidebar activePath="/suppliers" />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Navbar title="Supplier Profile" />
          <div className="flex-1 flex items-center justify-center p-6">
            <div className="text-center space-y-4 max-w-md p-6 border border-border rounded-xl bg-card">
              <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
              <h2 className="text-lg font-bold">Failed to load supplier</h2>
              <p className="text-sm text-muted-foreground">{(supplierError as any)?.message || "Supplier details could not be found."}</p>
              <Button onClick={() => router.push("/suppliers")}>Back to Suppliers</Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/suppliers" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Supplier Account Ledger" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">

          {/* Back button and Top Header */}
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-4">
              <Button variant="secondary" size="sm" className="h-9 gap-1.5" onClick={() => router.push("/suppliers")}>
                <ArrowLeft className="h-4 w-4" /> Back
              </Button>
              <h1 className="text-2xl font-extrabold tracking-tight">Supplier Profile</h1>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                className="h-9 border-primary/40 hover:border-primary text-primary hover:bg-primary/5 font-semibold gap-1.5"
                onClick={() => setIsPaymentDialogOpen(true)}
              >
                <Coins className="h-4 w-4" /> Record Payment
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="h-9 border-border/60 text-muted-foreground hover:text-foreground hover:bg-accent font-semibold gap-1.5"
                onClick={() => setActiveTab("payments")}
              >
                <History className="h-4 w-4" /> Payments History
              </Button>
              {remainingAdvance > 0 && (
                <Button
                  size="sm"
                  className="h-9 bg-amber-600 hover:bg-amber-700 text-white font-bold gap-1.5 shadow-sm"
                  onClick={() => {
                    setRefundAmount(remainingAdvance);
                    setRefundNotes("");
                    setIsRefundOpen(true);
                  }}
                >
                  <RotateCcw className="h-4 w-4" /> Refund Advance
                </Button>
              )}
            </div>
          </div>

          {/* Banner Notifications */}
          {successMessage && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400">
              <CheckCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          {/* Profile Overview Card */}
          <Card className="border border-border/60 bg-card/40 backdrop-blur-md">
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                <div className="flex items-center gap-4">
                  {/* Circular Avatar */}
                  <div className="relative shrink-0">
                    <div className="h-16 w-16 sm:h-20 sm:w-20 rounded-full border-2 border-primary/30 bg-secondary/40 overflow-hidden flex items-center justify-center shadow-md">
                      {supplier.image ? (
                        <img
                          src={getFullAssetUrl(supplier.image) || supplier.image}
                          alt={supplier.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="text-xl sm:text-2xl font-black text-primary uppercase font-mono">
                          {supplier.name.substring(0, 2)}
                        </div>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isUploadingPhoto}
                      className="absolute bottom-0 right-0 p-1.5 rounded-full bg-primary text-primary-foreground hover:bg-primary/90 shadow-md cursor-pointer transition-transform hover:scale-105"
                      title="Upload Supplier Photo"
                    >
                      {isUploadingPhoto ? <Loader2 className="w-3 h-3 animate-spin" /> : <Upload className="w-3 h-3" />}
                    </button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/png, image/jpeg, image/webp"
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h2 className="text-xl font-bold text-foreground">{supplier.name}</h2>
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold border uppercase ${
                        supplier.isActive ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20" : "bg-destructive/10 text-destructive border-destructive/20"
                      }`}>
                        {supplier.isActive ? "Active" : "Inactive"}
                      </span>
                    </div>
                    {supplier.businessName && (
                      <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                        <Building2 className="h-3.5 w-3.5" /> {supplier.businessName}
                      </p>
                    )}
                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground pt-1">
                      {supplier.phone && (
                        <span className="flex items-center gap-1">
                          <Phone className="h-3.5 w-3.5" /> {supplier.phone}
                        </span>
                      )}
                      {supplier.email && (
                        <span className="flex items-center gap-1">
                          <Mail className="h-3.5 w-3.5" /> {supplier.email}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-6 border-t lg:border-t-0 lg:border-l border-border/60 pt-4 lg:pt-0 lg:pl-6">
                  <div>
                    <span className="text-[10px] font-bold text-muted-foreground uppercase block">Tax Number</span>
                    <span className="text-sm font-bold text-foreground font-mono">
                      {supplier.taxNumber || "None"}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-muted-foreground uppercase block">Opening Balance</span>
                    <span className="text-sm font-bold text-foreground font-mono">
                      {format(supplier.openingBalance || 0)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-muted-foreground uppercase block">Status</span>
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border mt-1 ${
                      supplier.isActive
                        ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
                        : "bg-destructive/10 text-destructive border-destructive/20"
                    }`}>
                      {supplier.isActive ? "Active" : "Inactive"}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Metric Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="border border-border/40 bg-background/50">
              <CardContent className="p-4 flex items-center gap-4">
                <div className="h-10 w-10 rounded-lg bg-blue-500/10 flex items-center justify-center shrink-0">
                  <TrendingUp className="h-5 w-5 text-blue-500" />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-muted-foreground uppercase block">Total Purchases</span>
                  <span className="text-lg font-black text-foreground">{format(totalPurchasesSum)}</span>
                </div>
              </CardContent>
            </Card>

            <Card className="border border-border/40 bg-background/50">
              <CardContent className="p-4 flex items-center gap-4">
                <div className="h-10 w-10 rounded-lg bg-emerald-500/10 flex items-center justify-center shrink-0">
                  <DollarSign className="h-5 w-5 text-emerald-500" />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-muted-foreground uppercase block">Total Paid</span>
                  <span className="text-lg font-black text-foreground">{format(totalPaidSum)}</span>
                </div>
              </CardContent>
            </Card>

            <Card className="border border-border/40 bg-background/50">
              <CardContent className="p-4 flex items-center gap-4">
                <div className="h-10 w-10 rounded-lg bg-rose-500/10 flex items-center justify-center shrink-0">
                  <CreditCard className="h-5 w-5 text-rose-500" />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-muted-foreground uppercase block">Balance Due</span>
                  <span className="text-lg font-black text-foreground">{format(supplier.outstandingDue || 0)}</span>
                </div>
              </CardContent>
            </Card>

            <Card className="border border-border/40 bg-background/50">
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="h-10 w-10 rounded-lg bg-yellow-500/10 flex items-center justify-center shrink-0">
                    <Coins className="h-5 w-5 text-yellow-500" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-muted-foreground uppercase block">Advance Credits</span>
                    <span className="text-lg font-black text-foreground">
                      {format(remainingAdvance)}
                    </span>
                  </div>
                </div>
                {remainingAdvance > 0 && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-8 px-2.5 text-xs font-bold text-amber-600 dark:text-amber-400 border-amber-500/30 hover:bg-amber-500/10"
                    onClick={() => {
                      setRefundAmount(remainingAdvance);
                      setRefundNotes("");
                      setIsRefundOpen(true);
                    }}
                  >
                    <RotateCcw className="h-3.5 w-3.5 mr-1" /> Refund
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Details Tabs Section */}
          <div className="space-y-4">
            
            <div className="flex border-b border-border/60 gap-1 overflow-x-auto">
              <button
                onClick={() => setActiveTab("invoices")}
                className={`py-2.5 px-4 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
                  activeTab === "invoices"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <FileText className="h-4 w-4" /> Invoices History
              </button>
              <button
                onClick={() => setActiveTab("payments")}
                className={`py-2.5 px-4 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
                  activeTab === "payments"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <CreditCard className="h-4 w-4" /> Payments History
              </button>
              <button
                onClick={() => setActiveTab("advances")}
                className={`py-2.5 px-4 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
                  activeTab === "advances"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <Coins className="h-4 w-4" /> Advances History
              </button>
              <button
                onClick={() => setActiveTab("returns")}
                className={`py-2.5 px-4 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
                  activeTab === "returns"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <RotateCcw className="h-4 w-4" /> Purchase Returns
              </button>
              <button
                onClick={() => setActiveTab("statement")}
                className={`py-2.5 px-4 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
                  activeTab === "statement"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <FileText className="h-4 w-4" /> Ledger Statement
              </button>
            </div>

            {/* Invoices Tab */}
            {activeTab === "invoices" && (
              purchasesLoading ? (
                <div className="flex h-40 items-center justify-center">
                  <Loader2 className="h-6 w-6 animate-spin text-primary mr-2" /> Loading invoices...
                </div>
              ) : (
                <DataTable
                  data={purchasesList}
                  columns={purchaseColumns}
                  searchKeys={["purchaseNumber"]}
                  reportTitle={`${supplier.name} Invoices Report`}
                />
              )
            )}

            {/* Payments Tab */}
            {activeTab === "payments" && (
              paymentsLoading ? (
                <div className="flex h-40 items-center justify-center">
                  <Loader2 className="h-6 w-6 animate-spin text-primary mr-2" /> Loading payments...
                </div>
              ) : (
                <DataTable
                  data={payments}
                  columns={paymentColumns}
                  searchKeys={["paymentNumber"]}
                  reportTitle={`${supplier.name} Payments Report`}
                />
              )
            )}

            {/* Advances Tab */}
            {activeTab === "advances" && (
              advancesLoading ? (
                <div className="flex h-40 items-center justify-center">
                  <Loader2 className="h-6 w-6 animate-spin text-primary mr-2" /> Loading advances...
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex justify-end">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setIsAdvanceDialogOpen(true)}
                      className="h-8 px-3 text-xs font-bold gap-1.5 border-border/60 hover:bg-accent"
                    >
                      <Plus className="h-3.5 w-3.5 text-primary" /> Record Advance
                    </Button>
                  </div>
                  <DataTable
                    data={advances}
                    columns={advanceColumns}
                    searchKeys={["advanceNumber"]}
                    reportTitle={`${supplier.name} Advances Report`}
                  />
                </div>
              )
            )}

            {/* Returns Tab */}
            {activeTab === "returns" && (
              <DataTable
                data={supplier.purchaseReturns || []}
                columns={returnColumns}
                searchKeys={["returnNumber"]}
                reportTitle={`${supplier.name} Purchase Returns Report`}
              />
            )}

            {/* Ledger Statement Tab */}
            {activeTab === "statement" && (
              <div className="space-y-4">
                {/* Ledger Data Table with integrated Period Filter & Search in top bar */}
                <DataTable
                  data={ledgerEntries}
                  columns={ledgerColumns}
                  searchPlaceholder="Search Statement..."
                  searchKeys={["ref", "description", "type"]}
                  extraFilters={
                    <div className="w-52 shrink-0">
                      <Select
                        value={statementFilter}
                        onValueChange={(val) => setStatementFilter(val as any)}
                        icon={<Filter className="h-3.5 w-3.5 text-muted-foreground" />}
                        className="h-9 text-xs w-full bg-background/50"
                      >
                        <option value="all">All Time Transactions</option>
                        <option value="month">This Month</option>
                        <option value="30days">Last 30 Days</option>
                        <option value="year">This Year</option>
                      </Select>
                    </div>
                  }
                  serverSide={false}
                  reportTitle={`${supplier.name} - Supplier Account Statement`}
                />

                {/* Statement Summary Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                  <div className="p-4 rounded-sm bg-card border border-border/50">
                    <span className="text-[10px] font-bold text-muted-foreground uppercase block">Total Credits (Paid / Advances / Returns)</span>
                    <span className="text-lg font-black text-emerald-600 dark:text-emerald-400">
                      {format(ledgerEntries.reduce((sum: number, item: any) => sum + (item.credit || 0), 0))}
                    </span>
                  </div>
                  <div className="p-4 rounded-sm bg-card border border-border/50">
                    <span className="text-[10px] font-bold text-muted-foreground uppercase block">Total Debits (Purchases / Owed)</span>
                    <span className="text-lg font-black text-rose-600 dark:text-rose-400">
                      {format(ledgerEntries.reduce((sum: number, item: any) => sum + (item.debit || 0), 0))}
                    </span>
                  </div>
                  <div className="p-4 rounded-sm bg-card border border-border/50">
                    <span className="text-[10px] font-bold text-muted-foreground uppercase block">Closing Net Balance</span>
                    <span className={`text-lg font-black ${
                      (ledgerEntries[ledgerEntries.length - 1]?.balance || 0) > 0
                        ? "text-rose-600 dark:text-rose-400"
                        : "text-emerald-600 dark:text-emerald-400"
                    }`}>
                      {format(Math.abs(ledgerEntries[ledgerEntries.length - 1]?.balance || 0))} {(ledgerEntries[ledgerEntries.length - 1]?.balance || 0) > 0 ? "Payable Due" : "Advance Credit"}
                    </span>
                  </div>
                </div>
              </div>
            )}

          </div>

        </main>
      </div>

      {/* Pay Invoice dialog popup */}
      {currentUser && (
        <SupplierPaymentDialog
          isOpen={isPaymentDialogOpen}
          onClose={() => setIsPaymentDialogOpen(false)}
          purchase={null}
          supplier={supplier}
          currentUser={currentUser}
          onSuccess={setSuccessMessage}
          onError={setError}
        />
      )}

      {/* Record Advance dialog popup */}
      {currentUser && supplier && (
        <SupplierAdvanceDialog
          isOpen={isAdvanceDialogOpen}
          onClose={() => setIsAdvanceDialogOpen(false)}
          supplier={supplier}
          currentUser={currentUser}
          onSuccess={setSuccessMessage}
          onError={setError}
        />
      )}

      {/* Main Advance Refund Modal Dialog */}
      {isRefundOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="bg-card border border-border rounded-xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between p-4 border-b border-border bg-amber-500/10">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-amber-500/20 text-amber-500">
                  <RotateCcw className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-foreground">Refund Supplier Advance</h3>
                  <p className="text-xs text-muted-foreground">Return unused advance money from supplier</p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsRefundOpen(false)}
                className="h-8 w-8 p-0 rounded-full"
              >
                ✕
              </Button>
            </div>

            <form onSubmit={handleRefundSubmit}>
              <div className="p-4 space-y-4">
                {/* Available Advance Banner */}
                <div className="p-3 rounded-lg bg-secondary/50 border border-border flex justify-between items-center">
                  <div>
                    <span className="text-[11px] font-bold uppercase text-muted-foreground block">Available Advance Balance</span>
                    <span className="text-lg font-black text-emerald-500">{format(remainingAdvance)}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">Active Deposit</span>
                </div>

                {/* Branch Selection */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground">Branch *</label>
                  <select
                    value={selectedBranchId}
                    onChange={(e) => setSelectedBranchId(e.target.value)}
                    className="w-full h-10 px-3 py-2 bg-background border border-input text-foreground rounded text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                    required
                  >
                    {branches.map((b: any) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Payment Method Selection */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground">Refund Received via *</label>
                  <select
                    value={selectedPaymentMethodId}
                    onChange={(e) => setSelectedPaymentMethodId(e.target.value)}
                    className="w-full h-10 px-3 py-2 bg-background border border-input text-foreground rounded text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                  >
                    {paymentMethods.map((pm: any) => (
                      <option key={pm.id} value={pm.id}>
                        {pm.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Refund Amount */}
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-semibold text-muted-foreground">Refund Amount ({symbol}) *</label>
                    <button
                      type="button"
                      onClick={() => setRefundAmount(remainingAdvance)}
                      className="text-[11px] font-bold text-primary hover:underline"
                    >
                      Refund Full ({format(remainingAdvance)})
                    </button>
                  </div>
                  <Input
                    type="number"
                    step="any"
                    max={remainingAdvance}
                    min={1}
                    value={refundAmount || ""}
                    onChange={(e) => setRefundAmount(Number(e.target.value))}
                    placeholder="0.00"
                    required
                  />
                  {refundAmount > remainingAdvance && (
                    <span className="text-xs text-rose-500 font-semibold">
                      Refund amount cannot exceed available balance of {format(remainingAdvance)}.
                    </span>
                  )}
                </div>

                {/* Refund Reason / Notes */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground">Refund Notes (Optional)</label>
                  <Input
                    type="text"
                    value={refundNotes}
                    onChange={(e) => setRefundNotes(e.target.value)}
                    placeholder="e.g. Returned advance from supplier"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2.5 p-4 border-t border-border bg-background/20">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsRefundOpen(false)}
                  disabled={refundMutation.isPending}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  size="sm"
                  className="bg-amber-600 hover:bg-amber-700 text-white font-bold"
                  disabled={
                    refundMutation.isPending ||
                    refundAmount <= 0 ||
                    refundAmount > remainingAdvance
                  }
                >
                  {refundMutation.isPending ? (
                    <>
                      <Loader2 className="h-3.5 w-3.5 animate-spin mr-1.5" /> Processing...
                    </>
                  ) : (
                    `Confirm Refund ${refundAmount > 0 ? format(refundAmount) : ""}`
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default function SupplierViewPage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen w-screen items-center justify-center bg-[#121216]">
        <div className="flex flex-col items-center gap-2">
          <div className="w-8 h-8 border-4 border-zinc-700 border-t-emerald-500 rounded-full animate-spin" />
          <p className="text-sm text-zinc-400">Loading...</p>
        </div>
      </div>
    }>
      <SupplierViewPageContent />
    </Suspense>
  );
}
