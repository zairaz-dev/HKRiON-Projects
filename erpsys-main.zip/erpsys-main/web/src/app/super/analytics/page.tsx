"use strict";
"use client";

import React, { useEffect, useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { authService } from "@/services/auth-service";
import { LoadingSession } from "@/components/ui/loading-session";
import { User } from "@hkr/types";
import {
  superAnalyticsService,
  SystemAnalyticsOverview,
  MonthlyTrend,
} from "@/services/super-analytics-service";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  BarChart3,
  TrendingUp,
  Building2,
  Users,
  CreditCard,
  Layers,
  Smartphone,
  ShieldCheck,
  Activity,
  RefreshCw,
  Download,
  Calendar,
  Sparkles,
  Server,
  Database,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  ExternalLink,
  ChevronRight,
  ShoppingBag,
} from "lucide-react";
import Link from "next/link";

export default function SuperAdminAnalyticsPage() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  const [overview, setOverview] = useState<SystemAnalyticsOverview | null>(null);
  const [trends, setTrends] = useState<MonthlyTrend[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [dateFilter, setDateFilter] = useState<"30d" | "6m" | "1y" | "all">("6m");
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 1500);
    } else {
      loadData();
    }
  }, []);

  const loadData = async () => {
    setIsRefreshing(true);
    try {
      const [overviewData, trendsData] = await Promise.all([
        superAnalyticsService.getOverview(),
        superAnalyticsService.getTrends(),
      ]);
      setOverview(overviewData);
      setTrends(trendsData);
      setErrorMessage("");
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to load system analytics");
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  const handleExportSummary = () => {
    if (!overview) return;
    const csvContent = [
      ["Metric", "Value"],
      ["Total Businesses", overview.totalBusinesses],
      ["Active Businesses", overview.activeBusinesses],
      ["Trial Businesses", overview.trialBusinesses],
      ["Total Users", overview.totalUsers],
      ["Total Branches", overview.totalBranches],
      ["Monthly Recurring Revenue (LKR)", overview.mrrLkr],
      ["Annual Recurring Revenue (LKR)", overview.arrLkr],
      ["Total Global Sales Processed (LKR)", overview.totalGlobalSalesAmount],
      ["Total Invoices Processed", overview.totalGlobalSalesCount],
      ["Total Products in System", overview.totalProductsCount],
      ["Total IMEI Serial Items", overview.totalImeisCount],
      ["Server Database Status", overview.systemHealth.databaseStatus],
      ["Export Date", new Date().toISOString()],
    ]
      .map((row) => row.join(","))
      .join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `HKRION_System_Analytics_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (isAuthenticated === null || (isLoading && !overview)) {
    return <LoadingSession />;
  }

  // Format currency
  const formatLkr = (amount: number) => {
    return new Intl.NumberFormat("en-LK", {
      style: "currency",
      currency: "LKR",
      maximumFractionDigits: 0,
    }).format(amount || 0);
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat("en-US").format(num || 0);
  };

  // Max sales amount for trend scale
  const maxTrendAmount = Math.max(
    ...trends.map((t) => t.salesAmount),
    1
  );

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden font-sans">
      <Sidebar activePath="/super/analytics" />

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Navbar title="Platform System Analytics" className="relative z-10" />

        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 relative z-10">
          {/* Header Bar */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-border/80 pb-5">
            <div>
              <h1 className="text-2xl font-extrabold tracking-tight font-mono text-foreground flex items-center gap-2.5">
                <Activity className="w-6 h-6 text-primary" /> System & SaaS Analytics
              </h1>
              <p className="text-xs text-muted-foreground mt-1">
                Real-time tenant growth, SaaS subscription MRR, global transaction throughput, and cloud health.
              </p>
            </div>

            <div className="flex items-center gap-2.5 flex-wrap">
              {/* Date Filter */}
              <div className="bg-card/60 backdrop-blur-md p-1 rounded-sm border border-border inline-flex items-center gap-1 text-xs font-mono">
                <button
                  onClick={() => setDateFilter("30d")}
                  className={`px-2.5 py-1 rounded-sm transition-colors ${
                    dateFilter === "30d"
                      ? "bg-primary text-primary-foreground font-bold"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  30 Days
                </button>
                <button
                  onClick={() => setDateFilter("6m")}
                  className={`px-2.5 py-1 rounded-sm transition-colors ${
                    dateFilter === "6m"
                      ? "bg-primary text-primary-foreground font-bold"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  6 Months
                </button>
                <button
                  onClick={() => setDateFilter("all")}
                  className={`px-2.5 py-1 rounded-sm transition-colors ${
                    dateFilter === "all"
                      ? "bg-primary text-primary-foreground font-bold"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  All Time
                </button>
              </div>

              {/* Refresh Button */}
              <Button
                variant="outline"
                size="sm"
                onClick={loadData}
                disabled={isRefreshing}
                className="text-xs h-8 px-3 rounded-sm font-bold gap-1.5 border-border hover:bg-secondary"
              >
                <RefreshCw
                  className={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin text-primary" : ""}`}
                />
                Refresh
              </Button>

              {/* Export CSV */}
              <Button
                size="sm"
                onClick={handleExportSummary}
                className="text-xs h-8 px-3.5 rounded-sm font-bold gap-1.5 shadow-md shadow-primary/20 bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                <Download className="w-3.5 h-3.5" /> Export Report (.CSV)
              </Button>
            </div>
          </div>

          {errorMessage && (
            <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 p-3 rounded-sm text-xs flex items-center gap-2">
              <span>{errorMessage}</span>
            </div>
          )}

          {/* ========================================================================= */}
          {/* ROW 1: PRIMARY KPI SUMMARY CARDS                                          */}
          {/* ========================================================================= */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Card 1: Total Tenants */}
            <Card className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-5 space-y-3 hover:border-primary/50 transition-colors">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono font-bold text-muted-foreground uppercase tracking-wider">
                  Total Tenants
                </span>
                <div className="w-8 h-8 rounded-sm bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                  <Building2 className="w-4 h-4" />
                </div>
              </div>
              <div>
                <h3 className="text-2xl sm:text-3xl font-extrabold font-mono text-foreground">
                  {formatNumber(overview?.totalBusinesses || 0)}
                </h3>
                <div className="flex items-center gap-2 mt-1.5 text-xs">
                  <span className="text-emerald-400 font-mono font-bold flex items-center gap-0.5">
                    <ArrowUpRight className="w-3.5 h-3.5" /> +{overview?.newBusinessesThisMonth || 0}
                  </span>
                  <span className="text-muted-foreground text-[11px]">this month</span>
                </div>
              </div>
              <div className="pt-2 border-t border-border/50 flex items-center justify-between text-[11px] font-mono text-muted-foreground">
                <span>Active: <strong className="text-foreground">{overview?.activeBusinesses || 0}</strong></span>
                <span>Trial: <strong className="text-amber-400">{overview?.trialBusinesses || 0}</strong></span>
              </div>
            </Card>

            {/* Card 2: MRR (Monthly Recurring Revenue) */}
            <Card className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-5 space-y-3 hover:border-primary/50 transition-colors">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono font-bold text-muted-foreground uppercase tracking-wider">
                  Monthly Revenue (MRR)
                </span>
                <div className="w-8 h-8 rounded-sm bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <CreditCard className="w-4 h-4" />
                </div>
              </div>
              <div>
                <h3 className="text-2xl sm:text-3xl font-extrabold font-mono text-emerald-400">
                  {formatLkr(overview?.mrrLkr || 0)}
                </h3>
                <div className="flex items-center gap-2 mt-1.5 text-xs text-muted-foreground">
                  <span>ARR Projection:</span>
                  <strong className="text-foreground font-mono">{formatLkr(overview?.arrLkr || 0)}</strong>
                </div>
              </div>
              <div className="pt-2 border-t border-border/50 flex items-center justify-between text-[11px] font-mono text-muted-foreground">
                <span>Active Subs: <strong className="text-foreground">{overview?.activeSubscriptions || 0}</strong></span>
                <Link href="/super/subscriptions" className="text-primary hover:underline flex items-center gap-0.5">
                  Manage <ChevronRight className="w-3 h-3" />
                </Link>
              </div>
            </Card>

            {/* Card 3: Global Sales Processed */}
            <Card className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-5 space-y-3 hover:border-primary/50 transition-colors">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono font-bold text-muted-foreground uppercase tracking-wider">
                  Global GMV Processed
                </span>
                <div className="w-8 h-8 rounded-sm bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
                  <TrendingUp className="w-4 h-4" />
                </div>
              </div>
              <div>
                <h3 className="text-2xl sm:text-3xl font-extrabold font-mono text-foreground">
                  {formatLkr(overview?.totalGlobalSalesAmount || 0)}
                </h3>
                <div className="flex items-center gap-2 mt-1.5 text-xs text-muted-foreground">
                  <span>This month:</span>
                  <strong className="text-foreground font-mono">{formatLkr(overview?.salesThisMonthAmount || 0)}</strong>
                </div>
              </div>
              <div className="pt-2 border-t border-border/50 flex items-center justify-between text-[11px] font-mono text-muted-foreground">
                <span>Total Invoices: <strong className="text-foreground">{formatNumber(overview?.totalGlobalSalesCount || 0)}</strong></span>
                <span>POS Active</span>
              </div>
            </Card>

            {/* Card 4: Server Health & Uptime */}
            <Card className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-5 space-y-3 hover:border-primary/50 transition-colors">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono font-bold text-muted-foreground uppercase tracking-wider">
                  Cloud Infrastructure
                </span>
                <div className="w-8 h-8 rounded-sm bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
                  <Server className="w-4 h-4" />
                </div>
              </div>
              <div>
                <h3 className="text-2xl sm:text-3xl font-extrabold font-mono text-foreground flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" /> 99.9%
                </h3>
                <div className="flex items-center gap-2 mt-1.5 text-xs text-emerald-400 font-mono font-bold">
                  <span>Uptime SLA Guaranteed</span>
                </div>
              </div>
              <div className="pt-2 border-t border-border/50 flex items-center justify-between text-[11px] font-mono text-muted-foreground">
                <span>DB: <strong className="text-emerald-400">HEALTHY</strong></span>
                <span>RAM: <strong className="text-foreground">{overview?.systemHealth?.memoryUsageMb || 0} MB</strong></span>
              </div>
            </Card>
          </div>

          {/* ========================================================================= */}
          {/* ROW 2: INTERACTIVE CHARTS & PLAN DISTRIBUTION                             */}
          {/* ========================================================================= */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Left: Monthly Growth & GMV Bar Trend (8 cols) */}
            <div className="lg:col-span-8">
              <Card className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-6 space-y-5 h-full flex flex-col justify-between">
                <div className="flex items-center justify-between border-b border-border/80 pb-3">
                  <div>
                    <h3 className="text-sm font-bold text-foreground font-mono flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-primary" /> Monthly ERP Transaction Volume & Tenant Signups
                    </h3>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      Aggregated sales volume processed across all retail stores per month.
                    </p>
                  </div>
                  <div className="flex items-center gap-4 text-xs font-mono">
                    <div className="flex items-center gap-1.5">
                      <span className="w-3 h-3 rounded-sm bg-primary" />
                      <span className="text-muted-foreground">Sales (LKR)</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-3 h-3 rounded-sm bg-cyan-400" />
                      <span className="text-muted-foreground">New Stores</span>
                    </div>
                  </div>
                </div>

                {/* Visual Bars Container */}
                <div className="pt-4 flex-1 flex items-end justify-between gap-3 min-h-[220px]">
                  {trends.length === 0 ? (
                    <div className="w-full text-center text-xs text-muted-foreground py-10">
                      No monthly trend history recorded yet.
                    </div>
                  ) : (
                    trends.map((t, idx) => {
                      const heightPercent = maxTrendAmount > 0 ? Math.max(Math.round((t.salesAmount / maxTrendAmount) * 100), 12) : 12;
                      return (
                        <div key={idx} className="flex-1 flex flex-col items-center gap-2 group">
                          {/* Hover Tooltip Box */}
                          <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-background/95 border border-border px-2.5 py-1.5 rounded-sm shadow-xl text-[10px] font-mono text-center pointer-events-none whitespace-nowrap z-20">
                            <p className="font-bold text-foreground">{formatLkr(t.salesAmount)}</p>
                            <p className="text-muted-foreground">{t.salesCount} Invoices • +{t.newTenants} Stores</p>
                          </div>

                          {/* Bar Graphic */}
                          <div className="w-full max-w-[48px] bg-secondary/40 rounded-t-sm relative h-44 flex items-end justify-center overflow-hidden border border-border/50 group-hover:border-primary transition-colors">
                            <div
                              style={{ height: `${heightPercent}%` }}
                              className="w-full bg-gradient-to-t from-primary/80 to-primary rounded-t-sm transition-all duration-500 relative"
                            >
                              {t.newTenants > 0 && (
                                <div className="absolute top-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-cyan-400 shadow-sm" title={`${t.newTenants} new stores`} />
                              )}
                            </div>
                          </div>

                          {/* Label */}
                          <span className="text-[11px] font-mono font-bold text-muted-foreground group-hover:text-primary transition-colors">
                            {t.month}
                          </span>
                        </div>
                      );
                    })
                  )}
                </div>

                <div className="pt-3 border-t border-border/50 flex items-center justify-between text-xs text-muted-foreground font-mono">
                  <span>Total System Invoices: <strong>{formatNumber(overview?.totalGlobalSalesCount || 0)}</strong></span>
                  <span>Peak Throughput: <strong>Fast Sub-Second POS</strong></span>
                </div>
              </Card>
            </div>

            {/* Right: Subscription Tier Breakdown (4 cols) */}
            <div className="lg:col-span-4">
              <Card className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-6 space-y-5 h-full flex flex-col justify-between">
                <div className="border-b border-border/80 pb-3">
                  <h3 className="text-sm font-bold text-foreground font-mono flex items-center gap-2">
                    <Layers className="w-4 h-4 text-primary" /> Plan Tier Distribution
                  </h3>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Breakdown of active subscription quotas & tiers.
                  </p>
                </div>

                <div className="space-y-4 flex-1">
                  {overview?.plansDistribution?.length === 0 ? (
                    <div className="text-xs text-muted-foreground py-6 text-center">
                      No plans configured yet.
                    </div>
                  ) : (
                    overview?.plansDistribution?.map((p, pIdx) => {
                      const totalActive = overview.activeSubscriptions || 1;
                      const percent = Math.round((p.count / totalActive) * 100) || 0;

                      return (
                        <div key={p.planId || pIdx} className="space-y-1.5">
                          <div className="flex items-center justify-between text-xs font-mono">
                            <span className="font-bold text-foreground flex items-center gap-1.5">
                              <span className="w-2 h-2 rounded-full bg-primary" /> {p.planName}
                            </span>
                            <span className="text-muted-foreground">
                              {p.count} stores ({percent}%)
                            </span>
                          </div>
                          <div className="w-full bg-secondary/50 h-2 rounded-full overflow-hidden">
                            <div
                              style={{ width: `${Math.max(percent, p.count > 0 ? 8 : 0)}%` }}
                              className="bg-primary h-full rounded-full transition-all duration-500"
                            />
                          </div>
                          <div className="text-[10px] font-mono text-muted-foreground flex justify-between">
                            <span>Contribution:</span>
                            <strong className="text-emerald-400">{formatLkr(p.revenueMonthly)} / mo</strong>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

                <div className="pt-3 border-t border-border/50">
                  <Link href="/super/subscriptions">
                    <Button variant="outline" className="w-full text-xs h-8 rounded-sm font-bold border-border hover:bg-secondary gap-1.5">
                      <CreditCard className="w-3.5 h-3.5 text-primary" /> Configure Subscription Tiers
                    </Button>
                  </Link>
                </div>
              </Card>
            </div>
          </div>

          {/* ========================================================================= */}
          {/* ROW 3: ERP OPERATIONAL ACTIVITY COUNTERS                                   */}
          {/* ========================================================================= */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <Card className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-4 text-center space-y-1">
              <div className="w-8 h-8 rounded-sm bg-primary/10 text-primary mx-auto flex items-center justify-center border border-primary/20">
                <Users className="w-4 h-4" />
              </div>
              <p className="text-[10px] font-mono uppercase text-muted-foreground font-bold pt-1">Total System Users</p>
              <h4 className="text-xl font-extrabold font-mono text-foreground">{formatNumber(overview?.totalUsers || 0)}</h4>
              <p className="text-[10px] text-muted-foreground">Cashiers & Admins</p>
            </Card>

            <Card className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-4 text-center space-y-1">
              <div className="w-8 h-8 rounded-sm bg-blue-500/10 text-blue-400 mx-auto flex items-center justify-center border border-blue-500/20">
                <Building2 className="w-4 h-4" />
              </div>
              <p className="text-[10px] font-mono uppercase text-muted-foreground font-bold pt-1">Total Outlets / Stores</p>
              <h4 className="text-xl font-extrabold font-mono text-foreground">{formatNumber(overview?.totalBranches || 0)}</h4>
              <p className="text-[10px] text-muted-foreground">Connected Branches</p>
            </Card>

            <Card className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-4 text-center space-y-1">
              <div className="w-8 h-8 rounded-sm bg-emerald-500/10 text-emerald-400 mx-auto flex items-center justify-center border border-emerald-500/20">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <p className="text-[10px] font-mono uppercase text-muted-foreground font-bold pt-1">Catalog SKUs</p>
              <h4 className="text-xl font-extrabold font-mono text-foreground">{formatNumber(overview?.totalProductsCount || 0)}</h4>
              <p className="text-[10px] text-muted-foreground">Products in Database</p>
            </Card>

            <Card className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-4 text-center space-y-1">
              <div className="w-8 h-8 rounded-sm bg-purple-500/10 text-purple-400 mx-auto flex items-center justify-center border border-purple-500/20">
                <Smartphone className="w-4 h-4" />
              </div>
              <p className="text-[10px] font-mono uppercase text-muted-foreground font-bold pt-1">IMEI Serial Items</p>
              <h4 className="text-xl font-extrabold font-mono text-foreground">{formatNumber(overview?.totalImeisCount || 0)}</h4>
              <p className="text-[10px] text-muted-foreground">Warranty Tracked</p>
            </Card>
          </div>

          {/* ========================================================================= */}
          {/* ROW 4: RECENT REGISTERED TENANTS                                          */}
          {/* ========================================================================= */}
          <Card className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-border/80 pb-3">
              <div>
                <h3 className="text-sm font-bold text-foreground font-mono flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-primary" /> Recent Business Registrations
                </h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Latest tenants and retail stores onboarded onto HKRION Cloud ERP.
                </p>
              </div>
              <Link href="/super">
                <Button variant="outline" size="sm" className="text-xs h-8 rounded-sm font-bold border-border hover:bg-secondary gap-1">
                  View All Businesses <ChevronRight className="w-3.5 h-3.5" />
                </Button>
              </Link>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse font-sans">
                <thead>
                  <tr className="border-b border-border/60 text-muted-foreground font-mono text-[11px]">
                    <th className="py-2.5 px-3">Business / Store</th>
                    <th className="py-2.5 px-3">Industry</th>
                    <th className="py-2.5 px-3">Plan Tier</th>
                    <th className="py-2.5 px-3">Branches</th>
                    <th className="py-2.5 px-3">Users</th>
                    <th className="py-2.5 px-3">Joined Date</th>
                    <th className="py-2.5 px-3 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {overview?.recentSignups?.map((b) => (
                    <tr key={b.id} className="hover:bg-secondary/30 transition-colors">
                      <td className="py-3 px-3 font-bold text-foreground flex items-center gap-2">
                        <div className="w-6 h-6 rounded-sm bg-primary/10 text-primary flex items-center justify-center font-mono text-[10px]">
                          {b.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <span>{b.name}</span>
                          <span className="block text-[10px] text-muted-foreground font-mono">{b.phone}</span>
                        </div>
                      </td>
                      <td className="py-3 px-3 text-muted-foreground font-mono text-[11px]">
                        {b.industry}
                      </td>
                      <td className="py-3 px-3">
                        <span className="text-[10px] font-mono font-bold bg-primary/10 text-primary px-2 py-0.5 rounded-sm border border-primary/20">
                          {b.planName}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-mono text-[11px] text-foreground font-bold">
                        {b.branchCount}
                      </td>
                      <td className="py-3 px-3 font-mono text-[11px] text-foreground font-bold">
                        {b.userCount}
                      </td>
                      <td className="py-3 px-3 text-muted-foreground font-mono text-[11px]">
                        {new Date(b.createdAt).toLocaleDateString("en-US", {
                          month: "short",
                          day: "numeric",
                          year: "numeric",
                        })}
                      </td>
                      <td className="py-3 px-3 text-right">
                        <span
                          className={`text-[9px] font-mono uppercase px-2 py-0.5 rounded-sm font-bold border ${
                            b.isActive
                              ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                              : "bg-rose-500/10 text-rose-400 border-rose-500/20"
                          }`}
                        >
                          {b.isActive ? "ACTIVE" : "SUSPENDED"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          {/* ========================================================================= */}
          {/* ROW 5: SERVER PERFORMANCE & DATABASE DIAGNOSTICS                         */}
          {/* ========================================================================= */}
          <Card className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-6 space-y-4">
            <div className="border-b border-border/80 pb-3">
              <h3 className="text-sm font-bold text-foreground font-mono flex items-center gap-2">
                <Database className="w-4 h-4 text-primary" /> PostgreSQL Database & Server Diagnostics
              </h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                Technical parameters for system health, uptime, memory, and database connectivity.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
              <div className="p-3 bg-secondary/30 rounded-sm border border-border/60 space-y-1">
                <span className="text-muted-foreground text-[10px]">Database Engine</span>
                <p className="font-bold text-foreground flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> PostgreSQL + Prisma ORM
                </p>
              </div>

              <div className="p-3 bg-secondary/30 rounded-sm border border-border/60 space-y-1">
                <span className="text-muted-foreground text-[10px]">Node.js Heap Memory</span>
                <p className="font-bold text-foreground">
                  {overview?.systemHealth?.memoryUsageMb || 0} MB Active
                </p>
              </div>

              <div className="p-3 bg-secondary/30 rounded-sm border border-border/60 space-y-1">
                <span className="text-muted-foreground text-[10px]">Estimated Live Sessions</span>
                <p className="font-bold text-foreground flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-primary" /> {overview?.systemHealth?.activeSessionsEstimate || 1} Active Cashiers
                </p>
              </div>

              <div className="p-3 bg-secondary/30 rounded-sm border border-border/60 space-y-1">
                <span className="text-muted-foreground text-[10px]">Security Protocols</span>
                <p className="font-bold text-emerald-400 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5" /> TLS 1.3 + JWT Protected
                </p>
              </div>
            </div>
          </Card>
        </main>
      </div>
    </div>
  );
}
