import "dotenv/config";
import mysql from "mysql2/promise";
import bcrypt from "bcryptjs";

async function main() {
  const connectionUri = process.env.DATABASE_URL;
  if (!connectionUri) throw new Error("DATABASE_URL is not set in .env");

  const adminEmail = (process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  if (!adminEmail) throw new Error("ADMIN_EMAIL is not set in .env");

  const adminPassword = process.env.ADMIN_PASSWORD;
  if (!adminPassword) throw new Error("ADMIN_PASSWORD is not set in .env");

  const adminName = process.env.ADMIN_NAME || "Admin";
  const adminPhone = (process.env.ADMIN_PHONE || "").trim();
  if (!adminPhone) throw new Error("ADMIN_PHONE is not set in .env");

  console.log("💎 Faizan Gems — Vault Database Seeder");
  console.log("==================================================");

  let connection;
  try {
    connection = await mysql.createConnection(connectionUri);
    console.log("✔ Connected to MySQL database successfully.");

    // Compute secure bcrypt hash (cost factor 12)
    const passwordHash = await bcrypt.hash(adminPassword, 12);

    const adminId = globalThis.crypto.randomUUID();

    // Upsert admin user
    const query = `
      INSERT INTO users (id, name, email, password_hash, phone, role, created_at)
      VALUES (?, ?, ?, ?, ?, 'ADMIN', NOW(3))
      ON DUPLICATE KEY UPDATE
        name = VALUES(name),
        password_hash = VALUES(password_hash),
        phone = VALUES(phone),
        role = 'ADMIN'
    `;

    await connection.execute(query, [
      adminId,
      adminName,
      adminEmail,
      passwordHash,
      adminPhone,
    ]);

    // Fetch the updated/inserted admin record for verification
    const [rows] = await connection.execute(
      "SELECT id, name, email, role, phone, created_at FROM users WHERE email = ? LIMIT 1",
      [adminEmail]
    );

    const seededUser = Array.isArray(rows) && rows.length > 0 ? rows[0] : null;
    console.log("✔ Vault Admin account seeded successfully into `users` table!");
    console.log("--------------------------------------------------");
    if (seededUser) {
      console.log(`  • ID:       ${seededUser.id}`);
      console.log(`  • Name:     ${seededUser.name}`);
      console.log(`  • Email:    ${seededUser.email}`);
      console.log(`  • Role:     ${seededUser.role}`);
      console.log(`  • Phone:    ${seededUser.phone || "N/A"}`);
      console.log(`  • Created:  ${seededUser.created_at}`);
    }
    const appUrl = process.env.NEXTAUTH_URL || process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
    console.log(`🔑 Ready for login at: ${appUrl}/admin`);
    console.log(`   Email:    ${adminEmail}`);
    console.log(`   Password: ${adminPassword}`);
    console.log("==================================================");
  } catch (error) {
    console.error("❌ Error seeding vault admin account:", error);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

main().catch((err) => {
  console.error("Fatal seed error:", err);
  process.exit(1);
});
