import { redirect } from "next/navigation";
import { getSession } from "@/lib/session";
import { getPayrollOverview } from "@/actions/payroll";
import PayrollClient from "./payroll-client";

export const metadata = {
  title: "Payroll | HKRiON HRM",
};

export default async function PayrollPage() {
  const session = await getSession();

  // Only SUPER_ADMIN and MANAGER should access this
  if (!session || session.role === "EMPLOYEE") {
    redirect("/dashboard");
  }

  const { users, error } = await getPayrollOverview();

  if (error || !users) {
    return (
      <div className="p-6">
        <div className="bg-error-bg text-error p-4 rounded-xl border border-error-border">
          <p className="font-semibold">Failed to load payroll data</p>
          <p className="text-sm">{error}</p>
        </div>
      </div>
    );
  }

  // Calculate totals
  const totalPayroll = users.reduce((acc, emp) => {
    const activeComp = emp.compensations?.[0];
    if (activeComp) {
      return acc + Number(activeComp.baseSalary);
    }
    return acc;
  }, 0);

  return (
    <div className="max-w-7xl mx-auto animate-in fade-in duration-300">
      <PayrollClient 
        employees={users} 
        totalPayroll={totalPayroll}
        isAdmin={session.role === "SUPER_ADMIN"} 
      />
    </div>
  );
}
