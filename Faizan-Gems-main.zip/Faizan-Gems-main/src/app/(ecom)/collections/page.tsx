"use client";

import React, { useMemo } from "react";
import Image from "next/image";
import Link from "next/link";
import { getParsedCollectionCards } from "@/lib/data/collections";
import { useCMS } from "@/features/cms/useCMS";
import { CollectionCardSkeleton } from "@/features/collections/components/CollectionCardSkeleton";
import {
  GemIcon,
  ScaleIcon,
} from "@/components/ui/LuxuryIcons";

export default function CollectionsPage() {
  const { getBlock, isLoading } = useCMS();

  // CMS Content
  const eyebrow = getBlock("collections.page.eyebrow", "Faizan Gems Vault Collections");
  const headline = getBlock("collections.page.headline", "Curated Gemstone Portfolios");
  const subheadline = getBlock(
    "collections.page.subheadline",
    "Browse collections of the world's finest natural gemstones — sourced directly from historic alluvial deposits and cut by master craftsmen. Each untreated specimen is individually certified by leading gemological institutes."
  );

  const rawCardsJson = getBlock("collections.cards_list", "");
  const collectionCards = useMemo(() => {
    return getParsedCollectionCards(rawCardsJson);
  }, [rawCardsJson]);

  return (
    <div className="bg-[#FAF8F5] min-h-screen py-8 lg:py-12 selection:bg-[#C5A880] selection:text-[#0D0D11]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* ========================================================================= */}
        {/* 1. SHOP-STYLE EDITORIAL PAGE HEADER (No Background Image) */}
        {/* ========================================================================= */}
        <div className="mb-8 border-b border-[#E8E4DC] pb-6">
          <div className="mb-3 inline-flex items-center gap-2 px-3 py-1 bg-[#F5EFE6] border border-[#C5A880]/40 text-[#6D5228] text-[11px] font-sans tracking-wide">
            <span className="w-1.5 h-1.5 rounded-full bg-[#C5A880]" />
            <span>Vault Provenance Guaranteed • 100% Natural &amp; Unheated</span>
          </div>
          <span className="text-[11px] font-sans tracking-wide-luxury uppercase text-[#9A7B4F] block mb-1">
            {eyebrow}
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-[#18181D] font-normal">
            {headline}
          </h1>
          <p className="mt-2 text-xs sm:text-sm text-[#6B655C] font-sans max-w-2xl leading-relaxed">
            {subheadline}
          </p>
        </div>

        {/* ========================================================================= */}
        {/* 2. SUMMARY & JUMP TOOLBAR */}
        {/* ========================================================================= */}
        <div className="bg-white border border-[#E8E4DC] p-4 mb-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-4 text-xs font-sans text-[#554F47]">
            <span>
              Curated Portfolios:{" "}
              {isLoading ? (
                <span className="inline-block w-36 h-3.5 bg-[#E8E4DC] rounded-xs animate-pulse align-middle ml-1" />
              ) : (
                <strong className="text-[#18181D] font-medium">{collectionCards.length} Signature Collections</strong>
              )}
            </span>
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto justify-end">
            <Link
              href="/shop"
              className="px-5 py-2.5 bg-[#18181D] hover:bg-[#C5A880] text-white hover:text-[#0D0D11] text-xs font-sans uppercase tracking-wider transition-colors"
            >
              Explore Complete Store →
            </Link>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* 3. SIGNATURE EDITORIAL COLLECTION SHOWCASES */}
        {/* ========================================================================= */}
        <div className="mb-20">
          {isLoading ? (
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6 lg:gap-8">
              {[...Array(6)].map((_, i) => (
                <CollectionCardSkeleton key={i} />
              ))}
            </div>
          ) : collectionCards.length === 0 ? (
            <div className="bg-white border border-[#E8E4DC] p-12 text-center rounded-sm max-w-lg mx-auto shadow-sm">
              <h3 className="font-serif text-2xl text-[#18181D] font-normal mb-2">No Collections Available</h3>
              <p className="text-xs sm:text-sm text-[#8C867D] font-sans leading-relaxed mb-6">
                No collections are currently published. Check back soon or explore our complete catalog of certified natural gemstones.
              </p>
              <Link
                href="/shop"
                className="inline-block px-6 py-3 bg-[#18181D] hover:bg-[#C5A880] text-white hover:text-[#0D0D11] text-xs uppercase font-sans tracking-wider rounded-sm transition-colors"
              >
                Browse All Gemstones →
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6 lg:gap-8">
              {collectionCards.map((card) => (
                <Link
                  key={card.id}
                  href={`/collections/${card.slug}`}
                  className="group relative flex flex-col bg-white border border-[#E8E4DC] hover:border-[#C5A880] overflow-hidden shadow-xs hover:shadow-lg transition-all duration-300 rounded-sm"
                >
                  {/* Minimalist Image Frame */}
                  <div className="relative aspect-[4/3] sm:aspect-[16/11] w-full overflow-hidden bg-[#16161D]">
                    <Image
                      src={card.image}
                      alt={card.name}
                      fill
                      sizes="(max-width: 640px) 50vw, (max-width: 1200px) 50vw, 33vw"
                      unoptimized={card.image.startsWith("/uploads")}
                      className="object-cover opacity-95 transition-transform duration-700 ease-out group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent" />
                    <div className="absolute bottom-3 sm:bottom-5 inset-x-3 sm:inset-x-5 text-center">
                      <h3 className="font-serif text-sm sm:text-xl lg:text-2xl font-normal text-white leading-snug group-hover:text-[#E0CFA9] transition-colors line-clamp-2">
                        {card.name}
                      </h3>
                      <span className="hidden sm:inline-flex items-center gap-1 text-[10px] text-[#C5A880] uppercase tracking-wider font-sans font-medium mt-1">
                        Explore Collection &rarr;
                      </span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4. THE PILLARS OF CURATION (Educational Authority) */}
      {/* ========================================================================= */}
      <section className="py-20 bg-[#0F0F14] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-xs font-sans tracking-wide-luxury uppercase text-[#C5A880] block mb-2">
              Gemological Integrity
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl text-white font-light">
              The Faizan Gems Curation Standards
            </h2>
            <div className="w-12 h-0.5 bg-[#C5A880] mx-auto my-3" />
            <p className="text-xs text-[#A8A39D] font-sans leading-relaxed">
              Every specimen in our collections satisfies our non-negotiable criteria before vault admission.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 max-w-4xl mx-auto gap-8">
            <div className="p-8 bg-[#14141A] border border-[#262634] rounded-sm space-y-4">
              <div className="w-10 h-10 rounded-full bg-[#1C1C26] border border-[#C5A880]/40 flex items-center justify-center text-[#C5A880]">
                <GemIcon className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-xl text-white">I. Unheated Purity</h3>
              <p className="text-xs text-[#8C867D] font-sans leading-relaxed">
                Less than 1% of the world&apos;s colored corundums possess rich natural color without thermal baking. Our signature collections prioritize completely unheated and untreated gemstones.
              </p>
            </div>

            <div className="p-8 bg-[#14141A] border border-[#262634] rounded-sm space-y-4">
              <div className="w-10 h-10 rounded-full bg-[#1C1C26] border border-[#C5A880]/40 flex items-center justify-center text-[#C5A880]">
                <ScaleIcon className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-xl text-white">II. Master Lapidary</h3>
              <p className="text-xs text-[#8C867D] font-sans leading-relaxed">
                Each crystal is analyzed with optical refractor index modeling and hand-faceted by master lapidaries in Sri Lanka to maximize internal scintillation, brilliance, and color depth.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 5. BESPOKE SOURCING & PRIVATE CONCIERGE CTA */}
      {/* ========================================================================= */}
      <section className="py-20 bg-[#FAF8F5] border-t border-[#E8E4DC]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <span className="text-xs font-sans tracking-wide-luxury uppercase text-[#9A7B4F] block font-medium">
            Private Client Services
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl text-[#18181D] font-light">
            Seeking a Specific Provenance or Investment Carat?
          </h2>
          <p className="text-xs sm:text-sm text-[#6B655C] font-sans max-w-2xl mx-auto leading-relaxed">
            Our directors provide private consultation for family trusts, connoisseurs, and bespoke jewelers. We discreetly source natural unheated specimens directly from artisanal mines.
          </p>
          <div className="pt-2 flex flex-wrap items-center justify-center gap-4">
            <Link
              href="/contact"
              className="px-8 py-3.5 bg-[#18181D] hover:bg-[#C5A880] text-white hover:text-[#0D0D11] text-xs uppercase font-sans font-semibold tracking-wider rounded-sm transition-all shadow-md active:scale-95"
            >
              Book Private Consultation
            </Link>
            <Link
              href="/about"
              className="px-8 py-3.5 bg-white border border-[#18181D] text-[#18181D] hover:bg-[#EFECE6] text-xs uppercase font-sans tracking-wider rounded-sm transition-all active:scale-95"
            >
              Our Mine-to-Vault Heritage
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
