'use client';
import { QrCode, Server, ShieldCheck, Zap } from 'lucide-react';

export default function TopHeader({ onOpenQrModal, onOpenConfigModal, connectionStatus }) {
  return (
    <header className="h-16 bg-[#0d151c]/80 backdrop-blur-md border-b border-slate-800/80 px-6 flex items-center justify-between sticky top-0 z-30">
      <div className="flex items-center gap-3">
        <h2 className="font-heading font-extrabold text-lg text-white">
          WhatsApp Extractor SaaS
        </h2>
        <span className="text-[11px] font-medium text-slate-400 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded-full">
          Cloud Dashboard
        </span>
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={onOpenConfigModal}
          className="bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-xs font-semibold px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-colors"
        >
          <Server className="w-3.5 h-3.5 text-cyan-400" /> API Settings
        </button>

        <button
          onClick={onOpenQrModal}
          className="emerald-glow-btn text-slate-950 font-bold text-xs px-3.5 py-1.5 rounded-xl flex items-center gap-1.5 transition-all"
        >
          <QrCode className="w-3.5 h-3.5" /> Connect WhatsApp
        </button>
      </div>
    </header>
  );
}
