import { Gemstone } from "@/types/gemstone";

/**
 * Static gemstone catalog (empty by default; curated dynamically via MySQL database).
 */
export const GEMSTONES: Gemstone[] = [];
