import React from "react";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Printer,
  Calendar,
  Building2,
  PieChart,
  ShoppingBag,
  CreditCard,
  Layers
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useProfitLossQuery } from "../hooks/use-profit-loss";
import { useCurrency } from "@/hooks/use-currency";

interface ProfitLossViewProps {
  businessId: string;
  startDate?: string;
  endDate?: string;
  branchId?: string;
}

export function ProfitLossView({
  businessId,
  startDate,
  endDate,
  branchId,
}: ProfitLossViewProps) {
  const { symbol } = useCurrency(businessId);
  const { data, isLoading } = useProfitLossQuery(businessId, {
    startDate,
    endDate,
    branchId,
  });

  const handlePrint = () => {
    window.print();
  };

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="text-center space-y-2">
          <div className="w-8 h-8 border-4 border-zinc-700 border-t-emerald-500 rounded-full animate-spin mx-auto" />
          <span className="text-sm text-muted-foreground block">Computing Profit & Loss Statement...</span>
        </div>
      </div>
    );
  }

  const {
    totalSalesGross = 0,
    totalSalesReturns = 0,
    netSalesRevenue = 0,
    cogs = 0,
    grossProfit = 0,
    totalExpenses = 0,
    netProfit = 0,
    marginPercentage = 0,
  } = data || {};

  const isNetProfitPositive = netProfit >= 0;

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Action Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-extrabold tracking-tight flex items-center gap-2">
            <PieChart className="h-5 w-5 text-primary" /> Profit & Loss Statement
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Financial summary of revenue, cost of goods sold, operating expenses, and net profit.
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handlePrint}
          className="gap-1.5 text-xs h-8"
        >
          <Printer className="h-3.5 w-3.5" /> Print Statement
        </Button>
      </div>

      {/* Main Net Profit Summary Highlight Card */}
      <div className={`p-6 rounded-sm border ${isNetProfitPositive ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400" : "bg-rose-500/10 border-rose-500/30 text-rose-600 dark:text-rose-400"} flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl`}>
        <div className="space-y-1">
          <span className="text-xs font-bold uppercase tracking-wider block opacity-80">
            Net Operating Result
          </span>
          <div className="flex items-center gap-2">
            {isNetProfitPositive ? (
              <TrendingUp className="h-8 w-8 text-emerald-500" />
            ) : (
              <TrendingDown className="h-8 w-8 text-rose-500" />
            )}
            <span className="text-3xl md:text-4xl font-black font-mono">
              {symbol}{Math.abs(netProfit).toFixed(2)}
            </span>
          </div>
          <p className="text-xs font-medium opacity-90">
            {isNetProfitPositive ? "NET PROFIT" : "NET LOSS"} ({marginPercentage.toFixed(2)}% Net Margin)
          </p>
        </div>

        <div className="grid grid-cols-2 gap-4 text-xs font-mono bg-background/50 p-3 rounded-sm border border-border/50">
          <div>
            <span className="text-[10px] text-muted-foreground uppercase block">Gross Sales</span>
            <span className="font-bold text-foreground">{symbol}{totalSalesGross.toFixed(2)}</span>
          </div>
          <div>
            <span className="text-[10px] text-muted-foreground uppercase block">Sales Returns</span>
            <span className="font-bold text-rose-500">(-) {symbol}{totalSalesReturns.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* Financial Statement Grid Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Revenue Card */}
        <div className="bg-card border border-border/60 rounded-sm p-5 space-y-3 shadow-sm">
          <div className="flex items-center justify-between border-b border-border pb-2">
            <span className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1.5">
              <ShoppingBag className="h-4 w-4 text-emerald-500" /> Total Net Revenue
            </span>
            <span className="text-xs font-mono font-bold text-emerald-500">Income</span>
          </div>
          
          <div className="space-y-2 text-xs">
            <div className="flex justify-between text-muted-foreground">
              <span>Gross Sales (POS + Invoices):</span>
              <span className="font-mono text-foreground font-semibold">{symbol}{totalSalesGross.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-muted-foreground">
              <span>Sales Returns Deduction:</span>
              <span className="font-mono text-rose-500 font-semibold">(-) {symbol}{totalSalesReturns.toFixed(2)}</span>
            </div>
            <div className="border-t border-border pt-2 flex justify-between font-bold text-sm">
              <span>Net Sales Revenue:</span>
              <span className="font-mono text-foreground">{symbol}{netSalesRevenue.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* COGS & Gross Profit Card */}
        <div className="bg-card border border-border/60 rounded-sm p-5 space-y-3 shadow-sm">
          <div className="flex items-center justify-between border-b border-border pb-2">
            <span className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1.5">
              <Layers className="h-4 w-4 text-amber-500" /> Cost of Goods (COGS)
            </span>
            <span className="text-xs font-mono font-bold text-amber-500">Cost</span>
          </div>
          
          <div className="space-y-2 text-xs">
            <div className="flex justify-between text-muted-foreground">
              <span>FIFO Product Purchase Cost:</span>
              <span className="font-mono text-foreground font-semibold">{symbol}{cogs.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-muted-foreground">
              <span>Net Sales Revenue:</span>
              <span className="font-mono text-foreground font-semibold">{symbol}{netSalesRevenue.toFixed(2)}</span>
            </div>
            <div className="border-t border-border pt-2 flex justify-between font-bold text-sm">
              <span>Gross Operating Profit:</span>
              <span className="font-mono text-emerald-500">{symbol}{grossProfit.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Expenses & Net Profit Card */}
        <div className="bg-card border border-border/60 rounded-sm p-5 space-y-3 shadow-sm">
          <div className="flex items-center justify-between border-b border-border pb-2">
            <span className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1.5">
              <CreditCard className="h-4 w-4 text-rose-500" /> Expenses & Net Profit
            </span>
            <span className="text-xs font-mono font-bold text-rose-500">Expense</span>
          </div>
          
          <div className="space-y-2 text-xs">
            <div className="flex justify-between text-muted-foreground">
              <span>Gross Operating Profit:</span>
              <span className="font-mono text-foreground font-semibold">{symbol}{grossProfit.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-muted-foreground">
              <span>Total Operating Expenses:</span>
              <span className="font-mono text-rose-500 font-semibold">(-) {symbol}{totalExpenses.toFixed(2)}</span>
            </div>
            <div className="border-t border-border pt-2 flex justify-between font-bold text-sm">
              <span>Final Net Profit:</span>
              <span className={`font-mono ${isNetProfitPositive ? "text-emerald-500" : "text-rose-500"}`}>
                {symbol}{netProfit.toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
