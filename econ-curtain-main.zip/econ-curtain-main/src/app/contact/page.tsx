import { ContactService, ContactPageContentData } from "@/services/contact.service";
import { ProductService } from "@/services/product.service";
import { Phone, Mail, MapPin, Send, Clock, CheckCircle2, AlertCircle, MessageSquare } from "lucide-react";
import PhoneInputClient from "@/components/contact/PhoneInputClient";

export const dynamic = "force-dynamic";

interface ContactPageProps {
  searchParams?: Promise<{ success?: string; error?: string }>;
}

export default async function ContactPage({ searchParams }: ContactPageProps) {
  const params = await searchParams;
  const successMsg = params?.success;
  const errorMsg = params?.error;

  const content: ContactPageContentData = await ContactService.getContent();
  const products = await ProductService.getAll();

  return (
    <div className="flex flex-col w-full bg-slate-50 min-h-screen">
      {/* Page Header */}
      <section className="bg-slate-900 py-20 px-4 border-b border-slate-800 text-white">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            {content.headerTitlePrefix}{" "}
            <span className="text-amber-400">{content.headerTitleHighlight}</span>
          </h1>
          <p className="text-slate-300 max-w-2xl mx-auto text-lg font-light leading-relaxed">
            {content.headerSubtitle}
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
            {/* Contact Information */}
            <div className="lg:col-span-2 space-y-8">
              <div>
                <h2 className="text-3xl font-bold text-slate-900 mb-2">
                  {content.sectionTitle}
                </h2>
                <div className="w-12 h-1 bg-amber-500 rounded-full mb-8"></div>
                <p className="text-slate-600 mb-8 leading-relaxed">
                  {content.sectionDescription}
                </p>
              </div>

              <div className="space-y-6">
                {/* Phone */}
                <a
                  href={`tel:${content.phone.replace(/[^0-9+]/g, "")}`}
                  className="flex items-start gap-4 p-4 rounded-2xl bg-white shadow-sm border border-slate-100 hover:border-amber-400/50 hover:shadow-md transition-all group"
                >
                  <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-600 group-hover:bg-amber-500 group-hover:text-slate-950 flex items-center justify-center shrink-0 transition-colors">
                    <Phone size={24} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 text-base">Phone</h3>
                    <p className="text-slate-600 text-sm mt-1 font-medium">{content.phone}</p>
                    <p className="text-slate-400 text-xs mt-0.5">{content.phoneSubtitle}</p>
                  </div>
                </a>

                {/* Email */}
                <a
                  href={`mailto:${content.email}`}
                  className="flex items-start gap-4 p-4 rounded-2xl bg-white shadow-sm border border-slate-100 hover:border-amber-400/50 hover:shadow-md transition-all group"
                >
                  <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-600 group-hover:bg-amber-500 group-hover:text-slate-950 flex items-center justify-center shrink-0 transition-colors">
                    <Mail size={24} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 text-base">Email</h3>
                    <p className="text-slate-600 text-sm mt-1 font-medium">{content.email}</p>
                    <p className="text-slate-400 text-xs mt-0.5">{content.emailSubtitle}</p>
                  </div>
                </a>

                {/* WhatsApp Direct */}
                {content.whatsapp && (
                  <a
                    href={`https://wa.me/${content.whatsapp.replace(/[^0-9]/g, "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-start gap-4 p-4 rounded-2xl bg-white shadow-sm border border-slate-100 hover:border-emerald-400/50 hover:shadow-md transition-all group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-emerald-500/10 text-emerald-600 group-hover:bg-emerald-500 group-hover:text-white flex items-center justify-center shrink-0 transition-colors">
                      <MessageSquare size={24} />
                    </div>
                    <div>
                      <h3 className="font-semibold text-slate-900 text-base">WhatsApp</h3>
                      <p className="text-slate-600 text-sm mt-1 font-medium">{content.whatsapp}</p>
                      <p className="text-slate-400 text-xs mt-0.5">Click for instant chat</p>
                    </div>
                  </a>
                )}

                {/* Showroom */}
                <div className="flex items-start gap-4 p-4 rounded-2xl bg-white shadow-sm border border-slate-100">
                  <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center shrink-0">
                    <MapPin size={24} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 text-base">Showroom</h3>
                    <p className="text-slate-600 text-sm mt-1">{content.addressLine1}</p>
                    <p className="text-slate-400 text-xs mt-0.5">{content.addressLine2}</p>
                  </div>
                </div>

                {/* Working Hours */}
                <div className="flex items-start gap-4 p-4 rounded-2xl bg-white shadow-sm border border-slate-100">
                  <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center shrink-0">
                    <Clock size={24} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 text-base">Working Hours</h3>
                    <p className="text-slate-600 text-sm mt-1">{content.workingHoursLine1}</p>
                    <p className="text-slate-400 text-xs mt-0.5">{content.workingHoursLine2}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Inquiry Form */}
            <div className="lg:col-span-3">
              <div className="bg-white p-8 md:p-10 rounded-3xl shadow-xl border border-slate-100 relative overflow-hidden">
                <div className="relative z-10">
                  <h2 className="text-3xl font-bold text-slate-900 mb-2">{content.formTitle}</h2>
                  <p className="text-slate-500 mb-8">{content.formSubtitle}</p>

                  {/* Status Alerts */}
                  {successMsg && (
                    <div className="mb-6 p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-medium flex items-center gap-3">
                      <CheckCircle2 size={20} className="shrink-0 text-emerald-600" />
                      <span>{successMsg}</span>
                    </div>
                  )}

                  {errorMsg && (
                    <div className="mb-6 p-4 rounded-2xl bg-red-50 border border-red-200 text-red-800 text-sm font-medium flex items-center gap-3">
                      <AlertCircle size={20} className="shrink-0 text-red-600" />
                      <span>{errorMsg}</span>
                    </div>
                  )}

                  {/* Native HTML Form (100% Reliable, 0ms JS Dependency) */}
                  <form method="POST" action="/api/inquiries" className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label htmlFor="name" className="text-sm font-semibold text-slate-900">
                          Full Name *
                        </label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          required
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all bg-slate-50 focus:bg-white text-slate-900"
                          placeholder="John Doe"
                        />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="email" className="text-sm font-semibold text-slate-900">
                          Email Address
                        </label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          pattern="^[a-zA-Z0-9._%+\-]+@gmail\.com$"
                          title="Please provide a valid @gmail.com address"
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all bg-slate-50 focus:bg-white text-slate-900"
                          placeholder="john@gmail.com"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label htmlFor="phone" className="text-sm font-semibold text-slate-900">
                          Phone Number *
                        </label>
                        <PhoneInputClient />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="service" className="text-sm font-semibold text-slate-900">
                          Product / Service Required
                        </label>
                        <select
                          id="service"
                          name="service"
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all bg-slate-50 focus:bg-white text-slate-800"
                          defaultValue=""
                        >
                          <option value="" disabled>
                            Select a product/service...
                          </option>
                          {products.map((product) => (
                            <option key={product.id} value={product.name}>
                              {product.name}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="message" className="text-sm font-semibold text-slate-900">
                        Your Message
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        rows={4}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all bg-slate-50 focus:bg-white text-slate-900 resize-none"
                        placeholder="Tell us about your requirements, dimensions, or location..."
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-4 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-base transition-all shadow-lg hover:shadow-amber-500/25 flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                    >
                      <Send size={18} />
                      <span>{content.formButtonText}</span>
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
