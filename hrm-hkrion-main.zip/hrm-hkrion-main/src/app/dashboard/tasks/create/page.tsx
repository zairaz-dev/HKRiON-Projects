import { getSession } from "@/lib/session";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { Role } from "@prisma/client";
import CreateTaskClient from "./create-task-client";

export default async function CreateTaskPage() {
  const session = await getSession();

  if (!session || session.role === Role.EMPLOYEE) {
    redirect("/dashboard/tasks");
  }

  const users = await prisma.user.findMany({
    select: {
      id: true,
      firstName: true,
      lastName: true,
      email: true,
      role: true,
      profileImage: true,
      position: {
        select: {
          title: true,
        },
      },
    },
    orderBy: { firstName: "asc" },
  });

  const existingTasks = await prisma.task.findMany({
    select: {
      id: true,
      title: true,
      category: true,
      health: true,
      priority: true,
      dueDate: true,
    },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-20">
      <CreateTaskClient users={users} existingTasks={existingTasks} />
    </div>
  );
}

