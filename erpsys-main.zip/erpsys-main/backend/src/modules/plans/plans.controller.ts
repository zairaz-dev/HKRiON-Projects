import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  Req,
  UseGuards,
  ForbiddenException,
} from '@nestjs/common';
import { PlansService } from './plans.service';
import { CreatePlanDto } from './dto/create-plan.dto';
import { UpdatePlanDto } from './dto/update-plan.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';
import { Public } from '../../common/decorators/public.decorator';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../prisma/prisma.service';

@Controller('plans')
export class PlansController {
  constructor(
    private readonly plansService: PlansService,
    private readonly jwtService: JwtService,
    private readonly prisma: PrismaService,
  ) {}

  private async getAuthUser(req: any) {
    const authHeader = req.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
    const token = authHeader.split(' ')[1];
    try {
      const payload = this.jwtService.verify(token, {
        secret: process.env.JWT_SECRET || 'HKR_SUPER_SECRET_KEY_2026_ERP_SECURE_TOKEN_AUTH',
      });
      if (!payload?.sub) return null;
      return this.prisma.user.findUnique({
        where: { id: payload.sub },
        include: { role: true },
      });
    } catch {
      return null;
    }
  }

  @Public()
  @Get()
  async getPublicPlans(
    @Req() req: any,
    @Query('all') all?: string,
    @Query('businessId') businessId?: string,
  ) {
    const isRequestingAll = all === 'true';
    const isRequestingBusiness = !!businessId;

    if (isRequestingAll || isRequestingBusiness) {
      const user = await this.getAuthUser(req);

      if (isRequestingAll) {
        if (!user || user.role?.role !== Role.SUPER_ADMIN) {
          throw new ForbiddenException('Super Admin access required to view all plans and business data');
        }
        return this.plansService.getAllPlans(true);
      }

      if (isRequestingBusiness) {
        if (!user) {
          throw new ForbiddenException('Authentication required to view dedicated custom plans');
        }
        if (user.businessId !== businessId && user.role?.role !== Role.SUPER_ADMIN) {
          throw new ForbiddenException('Access denied to custom enterprise plans of other organizations');
        }
        return this.plansService.getAllPlans(false, businessId);
      }
    }

    return this.plansService.getAllPlans(false);
  }

  @Public()
  @Get(':id')
  async getPlanById(@Param('id') id: string) {
    return this.plansService.getPlanById(id);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.SUPER_ADMIN)
  @Post()
  async createPlan(@Body() dto: CreatePlanDto) {
    return this.plansService.createPlan(dto);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.SUPER_ADMIN)
  @Put(':id')
  async updatePlan(@Param('id') id: string, @Body() dto: UpdatePlanDto) {
    return this.plansService.updatePlan(id, dto);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.SUPER_ADMIN)
  @Delete(':id')
  async deletePlan(@Param('id') id: string) {
    return this.plansService.deletePlan(id);
  }
}
