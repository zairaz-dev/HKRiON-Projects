import React from "react";
import dynamic from "next/dynamic";
import "react-quill/dist/quill.snow.css";

// Dynamically import ReactQuill with SSR disabled to prevent Node.js hydration error
const ReactQuill = dynamic(() => import("react-quill"), {
  ssr: false,
  loading: () => (
    <div className="h-28 w-full border border-border/50 bg-background/50 rounded-md animate-pulse flex items-center justify-center text-xs text-muted-foreground">
      Loading Editor...
    </div>
  ),
});

export interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  disabled?: boolean;
}

export function RichTextEditor({
  value,
  onChange,
  placeholder,
  disabled,
}: RichTextEditorProps) {
  // Config modules for Quill toolbar
  const modules = {
    toolbar: [
      ["bold", "italic", "underline", "blockquote"],
      [{ list: "ordered" }, { list: "bullet" }],
      ["link", "clean"],
    ],
  };

  return (
    <div className="rich-text-editor-container w-full">
      <style>{`
        /* Custom CSS overrides to adapt Quill editor to our dark/light theme */
        .rich-text-editor-container .ql-toolbar.ql-snow {
          border: 1px solid hsl(var(--border) / 0.4);
          background-color: hsl(var(--secondary) / 0.3);
          border-top-left-radius: 0.375rem;
          border-top-right-radius: 0.375rem;
          padding: 6px 8px;
        }
        .rich-text-editor-container .ql-container.ql-snow {
          border: 1px solid hsl(var(--border) / 0.4);
          background-color: hsl(var(--background) / 0.5);
          border-top: none;
          border-bottom-left-radius: 0.375rem;
          border-bottom-right-radius: 0.375rem;
          font-family: inherit;
          font-size: 0.75rem;
        }
        .rich-text-editor-container .ql-editor {
          min-height: 80px;
          max-height: 180px;
          overflow-y: auto;
          color: hsl(var(--foreground));
          padding: 8px 12px;
        }
        .rich-text-editor-container .ql-editor.ql-blank::before {
          color: hsl(var(--muted-foreground) / 0.6);
          font-style: normal;
          left: 12px;
          right: 12px;
        }
        .rich-text-editor-container .ql-snow .ql-stroke {
          stroke: hsl(var(--muted-foreground));
          stroke-width: 1.5px;
        }
        .rich-text-editor-container .ql-snow .ql-fill {
          fill: hsl(var(--muted-foreground));
        }
        .rich-text-editor-container .ql-snow .ql-picker {
          color: hsl(var(--muted-foreground));
        }
        .rich-text-editor-container .ql-snow .ql-picker-options {
          background-color: hsl(var(--card));
          border: 1px solid hsl(var(--border) / 0.5);
        }
        .rich-text-editor-container .ql-snow .ql-picker-item:hover,
        .rich-text-editor-container .ql-snow .ql-picker-item.ql-selected {
          color: hsl(var(--primary));
        }
        .rich-text-editor-container .ql-snow .ql-active .ql-stroke {
          stroke: hsl(var(--primary));
          stroke-width: 2px;
        }
        .rich-text-editor-container .ql-snow .ql-active .ql-fill {
          fill: hsl(var(--primary));
        }
        .rich-text-editor-container .ql-snow a {
          color: hsl(var(--primary));
        }
        .rich-text-editor-container .ql-snow .ql-stroke.ql-thin,
        .rich-text-editor-container .ql-snow .ql-transparent {
          stroke: none;
        }
      `}</style>
      <ReactQuill
        theme="snow"
        value={value}
        onChange={onChange}
        placeholder={placeholder || "Product specifications, details, etc."}
        readOnly={disabled}
        modules={modules}
      />
    </div>
  );
}
