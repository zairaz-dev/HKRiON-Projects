'use client';
import { Download, FileSpreadsheet, CheckCircle2, Layers } from 'lucide-react';

export default function DownloadsHub() {
  const files = [
    {
      name: 'google_contacts_p1.csv',
      type: 'Google Contacts Format (Part 1)',
      desc: 'First split batch formatted for Google Contacts import.',
      count: 247,
      size: '21 KB',
      color: 'emerald',
    },
    {
      name: 'google_contacts_p2.csv',
      type: 'Google Contacts Format (Part 2)',
      desc: 'Second split batch formatted for Google Contacts import.',
      count: 247,
      size: '21 KB',
      color: 'teal',
    },
    {
      name: 'unique_contacts.csv',
      type: 'Unique Deduplicated Contacts',
      desc: 'Clean list of all unique member phone numbers.',
      count: 494,
      size: '21.7 KB',
      color: 'purple',
    },
    {
      name: 'extracted_contacts.csv',
      type: 'Raw Scraped Contacts',
      desc: 'Full raw scraped database extracted directly from WhatsApp groups.',
      count: 698,
      size: '21.9 KB',
      color: 'cyan',
    },
  ];

  const handleDownloadDemo = (filename) => {
    const csvContent = "Name,Phone 1 - Value\nWA Contact 1,+919876543210\nWA Contact 2,+919876543211";
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
  };

  return (
    <div className="space-y-6">
      <div className="glass-card rounded-2xl p-5 border border-slate-800">
        <h2 className="text-xl font-heading font-bold text-white flex items-center gap-2">
          <Download className="w-5 h-5 text-amber-400" /> Downloads Hub
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Access and download formatted CSV files ready for Google Contacts import
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {files.map((file, idx) => (
          <div key={idx} className="glass-card glass-card-hover rounded-2xl p-5 border border-slate-800 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-mono font-bold text-white bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800">
                  {file.name}
                </span>
                <FileSpreadsheet className="w-5 h-5 text-amber-400" />
              </div>
              <h3 className="font-bold text-sm text-slate-200">{file.type}</h3>
              <p className="text-xs text-slate-400 mt-1">{file.desc}</p>
            </div>

            <div className="pt-4 border-t border-slate-800/80 mt-4 flex items-center justify-between">
              <span className="text-xs font-mono text-slate-400">
                {file.count} contacts &bull; {file.size}
              </span>
              <button
                onClick={() => handleDownloadDemo(file.name)}
                className="bg-slate-900 hover:bg-slate-800 text-amber-400 border border-amber-800/50 text-xs font-semibold px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5" /> Download
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
