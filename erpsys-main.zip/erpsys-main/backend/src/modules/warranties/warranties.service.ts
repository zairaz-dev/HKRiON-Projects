import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { DurationType } from '@prisma/client';

@Injectable()
export class WarrantiesService {
  constructor(private readonly prisma: PrismaService) {}

  async createWarranty(data: {
    name: string;
    description?: string;
    duration: number;
    durationType: DurationType;
    isActive?: boolean;
    businessId: string;
    branchIds?: string[];
    createdById?: string;
  }) {
    // 0. Field validations
    const trimmedName = data.name?.trim();
    if (!trimmedName) {
      throw new BadRequestException('Warranty name is required');
    }
    if (trimmedName.length < 2 || trimmedName.length > 100) {
      throw new BadRequestException('Warranty name must be between 2 and 100 characters');
    }

    if (!data.businessId || !data.businessId.trim()) {
      throw new BadRequestException('Business ID is required');
    }

    const durationNum = Number(data.duration);
    if (!durationNum || durationNum <= 0 || durationNum > 1000 || !Number.isInteger(durationNum)) {
      throw new BadRequestException('Duration must be an integer between 1 and 1000');
    }

    if (!Object.values(DurationType).includes(data.durationType)) {
      throw new BadRequestException('Invalid duration type. Must be DAYS, MONTHS, or YEARS');
    }

    if (data.description && data.description.length > 500) {
      throw new BadRequestException('Description cannot exceed 500 characters');
    }

    // 1. Check for duplicate name in the same business
    const existing = await this.prisma.warranty.findFirst({
      where: {
        name: { equals: trimmedName, mode: 'insensitive' },
        businessId: data.businessId,
      },
    });

    if (existing) {
      throw new BadRequestException('A warranty with this name already exists in this business');
    }

    // 2. Verify branches belong to the business
    if (data.branchIds && data.branchIds.length > 0) {
      const validBranches = await this.prisma.branch.findMany({
        where: {
          id: { in: data.branchIds },
          businessId: data.businessId,
        },
      });
      if (validBranches.length !== data.branchIds.length) {
        throw new BadRequestException('One or more selected branches are invalid');
      }
    }

    // 3. Create Warranty and its branch connections in a transaction
    return this.prisma.$transaction(async (tx) => {
      const warranty = await tx.warranty.create({
        data: {
          name: trimmedName,
          description: data.description ? data.description.trim() : null,
          duration: durationNum,
          durationType: data.durationType,
          ...(data.isActive !== undefined && { isActive: data.isActive }),
          businessId: data.businessId,
          createdById: data.createdById || null,
          branches: data.branchIds && data.branchIds.length > 0
            ? {
                create: data.branchIds.map((branchId) => ({
                  branchId,
                })),
              }
            : undefined,
        },
        include: {
          branches: {
            include: {
              branch: true,
            },
          },
        },
      });

      return warranty;
    });
  }

  async getWarranties(businessId: string, branchId?: string) {
    const whereClause: any = {
      businessId,
    };

    if (branchId) {
      whereClause.OR = [
        { branches: { none: {} } },
        { branches: { some: { branchId } } },
      ];
    }

    return this.prisma.warranty.findMany({
      where: whereClause,
      include: {
        branches: {
          include: {
            branch: {
              select: {
                id: true,
                name: true,
              },
            },
          },
        },
      },
      orderBy: {
        createdAt: 'asc',
      },
    });
  }

  async getWarrantyById(id: string, businessId: string) {
    const warranty = await this.prisma.warranty.findFirst({
      where: { id, businessId },
      include: {
        branches: {
          include: {
            branch: true,
          },
        },
      },
    });

    if (!warranty) {
      throw new BadRequestException('Warranty not found');
    }

    return warranty;
  }

  async updateWarranty(
    id: string,
    businessId: string,
    data: {
      name?: string;
      description?: string;
      duration?: number;
      durationType?: DurationType;
      isActive?: boolean;
      branchIds?: string[];
      updatedById?: string;
    },
  ) {
    const warranty = await this.getWarrantyById(id, businessId);

    // 0. Field validations
    let trimmedName: string | undefined = undefined;
    if (data.name !== undefined) {
      trimmedName = data.name.trim();
      if (!trimmedName) {
        throw new BadRequestException('Warranty name cannot be empty');
      }
      if (trimmedName.length < 2 || trimmedName.length > 100) {
        throw new BadRequestException('Warranty name must be between 2 and 100 characters');
      }
    }

    let durationNum: number | undefined = undefined;
    if (data.duration !== undefined) {
      durationNum = Number(data.duration);
      if (!durationNum || durationNum <= 0 || durationNum > 1000 || !Number.isInteger(durationNum)) {
        throw new BadRequestException('Duration must be an integer between 1 and 1000');
      }
    }

    if (data.durationType !== undefined && !Object.values(DurationType).includes(data.durationType)) {
      throw new BadRequestException('Invalid duration type. Must be DAYS, MONTHS, or YEARS');
    }

    if (data.description !== undefined && data.description !== null && data.description.length > 500) {
      throw new BadRequestException('Description cannot exceed 500 characters');
    }

    // 1. Check duplicate name if name is changing
    if (trimmedName && trimmedName.toLowerCase() !== warranty.name.toLowerCase()) {
      const existing = await this.prisma.warranty.findFirst({
        where: {
          id: { not: id },
          name: { equals: trimmedName, mode: 'insensitive' },
          businessId,
        },
      });
      if (existing) {
        throw new BadRequestException('A warranty with this name already exists in this business');
      }
    }

    // 2. Verify branches belong to the business if branchIds are changing
    if (data.branchIds && data.branchIds.length > 0) {
      const validBranches = await this.prisma.branch.findMany({
        where: {
          id: { in: data.branchIds },
          businessId,
        },
      });
      if (validBranches.length !== data.branchIds.length) {
        throw new BadRequestException('One or more selected branches are invalid');
      }
    }

    return this.prisma.$transaction(async (tx) => {
      // 3. Update branches if branchIds are provided
      if (data.branchIds !== undefined) {
        await tx.warrantyBranch.deleteMany({
          where: { warrantyId: id },
        });

        if (data.branchIds.length > 0) {
          await tx.warrantyBranch.createMany({
            data: data.branchIds.map((branchId) => ({
              warrantyId: id,
              branchId,
            })),
          });
        }
      }

      // 4. Update Warranty basic fields
      const updateData: any = {};
      if (trimmedName !== undefined) updateData.name = trimmedName;
      if (data.description !== undefined) updateData.description = data.description ? data.description.trim() : null;
      if (durationNum !== undefined) updateData.duration = durationNum;
      if (data.durationType !== undefined) updateData.durationType = data.durationType;
      if (data.isActive !== undefined) updateData.isActive = data.isActive;
      if (data.updatedById !== undefined) updateData.updatedById = data.updatedById;

      const updated = await tx.warranty.update({
        where: { id },
        data: updateData,
        include: {
          branches: {
            include: {
              branch: true,
            },
          },
        },
      });

      return updated;
    });
  }

  async deleteWarranty(id: string, businessId: string) {
    await this.getWarrantyById(id, businessId);

    // 1. Check if warranty is associated with products
    const productCount = await this.prisma.product.count({
      where: { warrantyId: id },
    });

    if (productCount > 0) {
      throw new BadRequestException(
        `Cannot delete warranty because it is associated with ${productCount} product(s). Please reassign or remove the products first.`
      );
    }

    await this.prisma.warranty.delete({
      where: { id },
    });

    return { success: true };
  }
}
