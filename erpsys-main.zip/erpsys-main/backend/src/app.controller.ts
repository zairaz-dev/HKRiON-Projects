import { Controller, Get, Req } from '@nestjs/common';
import { AppService } from './app.service';
import { Request } from 'express';
import { Public } from './common/decorators/public.decorator';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Public()
  @Get()
  getHello(): string {
    return this.appService.getHello();
  }

  @Public()
  @Get('geo/country')
  getCountry(@Req() req: Request) {
    const cfCountry = (req.headers['cf-ipcountry'] || req.headers['x-vercel-ip-country'] || req.headers['x-country-code']) as string | undefined;
    const country = cfCountry ? cfCountry.trim().toUpperCase() : null;

    return {
      success: true,
      country,
      isSriLanka: country ? country === 'LK' : null,
      source: cfCountry ? 'cloudflare' : 'none',
    };
  }
}
