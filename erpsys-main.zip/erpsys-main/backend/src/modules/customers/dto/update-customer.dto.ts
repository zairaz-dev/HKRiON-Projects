import {
  IsString,
  IsOptional,
  Length,
  IsEmail,
  IsNumber,
  Min,
} from 'class-validator';

export class UpdateCustomerDto {
  @IsOptional()
  @IsString()
  @Length(2, 100, { message: 'Customer name must be between 2 and 100 characters' })
  name?: string;

  @IsOptional()
  @IsString()
  image?: string;

  @IsOptional()
  @IsString()
  @Length(0, 100, { message: 'Business name cannot exceed 100 characters' })
  businessName?: string;

  @IsOptional()
  @IsEmail({}, { message: 'Invalid email address' })
  email?: string;

  @IsOptional()
  @IsString()
  phone?: string;

  @IsOptional()
  @IsString()
  @Length(0, 500, { message: 'Tax number cannot exceed 500 characters' })
  taxNumber?: string;

  @IsOptional()
  @IsNumber({}, { message: 'Opening balance must be a number' })
  @Min(0, { message: 'Opening balance must be 0 or greater' })
  openingBalance?: number;

  @IsOptional()
  @IsNumber({}, { message: 'Credit limit must be a number' })
  @Min(0, { message: 'Credit limit must be 0 or greater' })
  creditLimit?: number;

  @IsOptional()
  @IsString()
  @Length(0, 500, { message: 'Address cannot exceed 500 characters' })
  address?: string;

  @IsOptional()
  @IsString()
  customerGroupId?: string;

  @IsOptional()
  @IsString()
  businessId?: string;

  @IsOptional()
  branchIds?: string[];

  @IsOptional()
  isActive?: boolean | string;

  @IsOptional()
  allowCredit?: boolean | string;

  @IsOptional()
  @IsString()
  updatedById?: string;
}
