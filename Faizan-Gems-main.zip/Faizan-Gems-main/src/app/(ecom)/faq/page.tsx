"use client";

import React, { useState } from "react";
import Link from "next/link";
import { ChevronDownIcon, LoupeIcon } from "@/components/ui/LuxuryIcons";
import { useCMS } from "@/features/cms/useCMS";

export default function FAQPage() {
  const { faqs: cmsFaqs, isLoading } = useCMS();
  const [openIdx, setOpenIdx] = useState<number | null>(0);
  const [activeCategory, setActiveCategory] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState("");

  const items = cmsFaqs;

  const categories = ["All", ...Array.from(new Set(items.map((i) => i.category || "General").filter(Boolean)))];

  const filteredItems = items.filter((item) => {
    const matchesCategory = activeCategory === "All" || item.category === activeCategory;
    const matchesSearch =
      !searchQuery ||
      item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="bg-[#FAF8F5] min-h-screen py-12 lg:py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 space-y-3">
          <span className="text-[11px] font-sans tracking-wide-luxury uppercase text-[#9A7B4F] block">
            Client Assurance & FAQ
          </span>
          <h1 className="font-serif text-3xl sm:text-5xl text-[#18181D]">
            The Nine Principles of Trust
          </h1>
          <p className="text-xs sm:text-sm text-[#6B655C] font-sans leading-relaxed">
            We believe an informed connoisseur is our best client. Here are direct answers to the fundamental questions regarding provenance, quality, transit, and security.
          </p>
        </div>

        {/* Filter and Search Bar */}
        <div className="mb-8 space-y-4">
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search knowledge repository (e.g. provenance, delivery, wire, payment)..."
              className="w-full pl-10 pr-4 py-3 bg-white border border-[#E8E4DC] text-xs font-sans text-[#18181D] placeholder-[#8C867D] focus:outline-none focus:border-[#C5A880] shadow-sm"
            />
            <LoupeIcon className="w-4 h-4 text-[#8C867D] absolute left-3.5 top-3.5" />
          </div>

          {categories.length > 1 && (
            <div className="flex flex-wrap items-center gap-2 pt-1">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-3 py-1.5 rounded-full text-xs font-sans transition-all ${
                    activeCategory === cat
                      ? "bg-[#18181D] text-[#E0CFA9] font-medium"
                      : "bg-white border border-[#E8E4DC] text-[#6B655C] hover:text-[#18181D]"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Accordion List */}
        <div className="bg-white border border-[#E8E4DC] shadow-sm divide-y divide-[#F2EFE9]">
          {isLoading ? (
            [...Array(4)].map((_, i) => (
              <div key={i} className="p-6 space-y-2.5">
                <div className="w-20 h-2.5 bg-[#E8E4DC] rounded-xs animate-pulse" />
                <div className="w-3/4 h-4 bg-[#E8E4DC] rounded-xs animate-pulse" />
              </div>
            ))
          ) : filteredItems.length === 0 ? (
            <div className="p-8 text-center text-xs text-[#8C867D] font-sans">
              No frequently asked questions match your criteria.
            </div>
          ) : (
            filteredItems.map((item, idx) => (
              <div key={item.id || idx} className="p-6 transition-colors hover:bg-[#FAF8F5]/50">
                <button
                  onClick={() => setOpenIdx(openIdx === idx ? null : idx)}
                  className="w-full text-left flex items-start justify-between gap-4"
                >
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-[#9A7B4F] block mb-1">
                      {item.category || "General"}
                    </span>
                    <h3 className="font-serif text-base sm:text-lg text-[#18181D] font-medium leading-snug">
                      {item.question}
                    </h3>
                  </div>
                  <span className={`w-6 h-6 rounded-full flex items-center justify-center text-[#8C867D] transition-transform flex-shrink-0 ${
                    openIdx === idx ? "rotate-180 text-[#C5A880]" : ""
                  }`}>
                    <ChevronDownIcon className="w-4 h-4" />
                  </span>
                </button>

                {openIdx === idx && (
                  <div className="mt-3 text-xs sm:text-sm text-[#554F47] font-sans leading-relaxed pt-2 border-t border-[#F2EFE9] animate-in fade-in duration-200">
                    <p>{item.answer}</p>
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Concierge Contact Banner */}
        <div className="mt-12 bg-[#18181D] text-white p-8 border border-[#2A2A32] text-center space-y-4 shadow-lg">
          <h4 className="font-serif text-2xl text-white">Have a Specific Gemological Inquiry?</h4>
          <p className="text-xs sm:text-sm text-[#D3CBBF] font-sans max-w-lg mx-auto">
            Our Graduate Gemologists are pleased to discuss any technical query, spectral report, or private acquisition request.
          </p>
          <div className="pt-2">
            <Link
              href="/contact"
              className="inline-block px-8 py-3 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-xs uppercase tracking-luxury font-sans font-medium transition-colors"
            >
              Consult with Senior Gemologist &rarr;
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
