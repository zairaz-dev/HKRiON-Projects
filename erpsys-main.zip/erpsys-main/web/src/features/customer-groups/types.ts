export interface BranchItem {
  id: string;
  name: string;
}

export interface CustomerGroupBranchItem {
  branchId: string;
  branch: BranchItem;
}

export interface SellingPriceGroupItem {
  id: string;
  name: string;
}

export interface CustomerGroupItem {
  id: string;
  name: string;
  percentageDiscount: number;
  sellingPriceGroupId: string | null;
  sellingPriceGroup?: SellingPriceGroupItem | null;
  isActive: boolean;
  businessId: string;
  createdAt: string;
  updatedAt: string;
  branches?: CustomerGroupBranchItem[];
}
