import * as z from "zod";

export const expenseCategoryFormSchema = z.object({
  name: z
    .string()
    .min(1, "Category name is required")
    .max(100, "Category name must be under 100 characters"),
  code: z.string().optional(),
  description: z.string().optional(),
  parentId: z.string().nullable().optional(),
  branchIds: z.array(z.string()),
  isActive: z.boolean(),
});

export type ExpenseCategoryFormSchema = z.infer<typeof expenseCategoryFormSchema>;
