import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(private readonly prisma: PrismaService) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: process.env.JWT_SECRET || 'HKR_SUPER_SECRET_KEY_2026_ERP_SECURE_TOKEN_AUTH',
    });
  }

  async validate(payload: any) {
    // Fetch user details including role and role's permissions from database
    const user = await this.prisma.user.findUnique({
      where: { id: payload.sub },
      include: {
        role: {
          include: {
            rolePermissions: true,
          },
        },
      },
    });

    if (!user || user.isActive === false) {
      throw new UnauthorizedException('User account is inactive or disabled');
    }

    if (user.businessId) {
      const business = await this.prisma.business.findUnique({
        where: { id: user.businessId },
      });
      if (business && business.isActive === false) {
        throw new UnauthorizedException('Business account is inactive or disabled');
      }
    }

    const roleSlug = user.role?.role;
    const permissions = user.role?.rolePermissions.map((rp) => rp.permissionId) || [];

    const { passwordHash, ...userWithoutHash } = user;

    return {
      ...userWithoutHash,
      role: roleSlug,
      permissions,
    };
  }
}
