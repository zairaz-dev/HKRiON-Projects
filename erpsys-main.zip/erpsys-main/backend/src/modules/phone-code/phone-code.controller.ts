import { Controller, Get, UseGuards } from '@nestjs/common';
import { PhoneCodeService } from './phone-code.service';
import { PhoneCode } from '../../types';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Public } from '../../common/decorators/public.decorator';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Public()
@Controller('phone-codes')
export class PhoneCodeController {
  constructor(private readonly phoneCodeService: PhoneCodeService) {}

  @Get()
  async findAll(): Promise<PhoneCode[]> {
    return this.phoneCodeService.findAll();
  }
}
