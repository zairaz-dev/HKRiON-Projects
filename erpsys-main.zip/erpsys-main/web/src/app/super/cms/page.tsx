"use strict";
"use client";

import React, { useEffect, useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { authService } from "@/services/auth-service";
import { LoadingSession } from "@/components/ui/loading-session";
import { User } from "@hkr/types";
import {
  cmsService,
  CmsHero,
  CmsFeature,
  CmsSpotlight,
  CmsFaq,
  CmsTestimonial,
  CmsPage,
  CmsPost,
} from "@/services/cms-service";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  FileText,
  Globe,
  Sparkles,
  HelpCircle,
  MessageSquare,
  BookOpen,
  Plus,
  Edit2,
  Trash2,
  Save,
  CheckCircle,
  AlertTriangle,
  Loader2,
  Eye,
  Star,
  Layers,
  ShoppingBag,
  Smartphone,
  Building2,
  CreditCard,
  BarChart3,
  X,
  ExternalLink,
  ShieldCheck,
  Monitor,
  ArrowLeft,
  Search,
  Check,
  Info,
  Mail,
  Phone,
  MapPin,
  Clock,
  Shield,
  Zap,
  Cpu,
  Award,
} from "lucide-react";
import Link from "next/link";

export default function SuperAdminCmsPage() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Page Directory vs Page Editor State
  // selectedPageKey: null (shows All Pages Directory), "home", "about", "contact", "pricing", "privacy", "refund", "terms", "posts", or custom page slug
  const [selectedPageKey, setSelectedPageKey] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  // Sub-tabs for Home Page Editor
  const [homeSubTab, setHomeSubTab] = useState<
    "hero" | "spotlights" | "features" | "faqs" | "testimonials"
  >("hero");

  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  // Data States
  const [hero, setHero] = useState<CmsHero>({
    heroTitle: "The Complete Intelligent ERP Platform Built For Growth",
    heroSubtitle:
      "Streamline multi-branch point of sale, inventory tracking with IMEI verification, customer accounting, and automated Sri Lankan tax invoicing in one ultra-fast system.",
    badgeText: "NEXT-GEN CLOUD ERP FOR MODERN RETAIL & ENTERPRISE",
    announcementText: "Special Launch Offer: Get 20% OFF on all Yearly Subscription Plans! 🚀",
    announcementLink: "#pricing",
    announcementActive: true,
    primaryCtaText: "Start 14-Day Free Trial",
    primaryCtaLink: "/register",
    secondaryCtaText: "Explore Features",
    secondaryCtaLink: "#features",
  });

  const [spotlights, setSpotlights] = useState<CmsSpotlight[]>([]);
  const [features, setFeatures] = useState<CmsFeature[]>([]);
  const [faqs, setFaqs] = useState<CmsFaq[]>([]);
  const [testimonials, setTestimonials] = useState<CmsTestimonial[]>([]);
  const [pages, setPages] = useState<CmsPage[]>([]);
  const [posts, setPosts] = useState<CmsPost[]>([]);

  // About & Contact Page parsed state
  const [aboutData, setAboutData] = useState<{
    badge: string;
    headline: string;
    subtitle: string;
    mission: string;
    architectureStory: string;
    stats: Array<{ label: string; value: string }>;
    values: Array<{ title: string; description: string; icon: string }>;
  }>({
    badge: "About Our Platform",
    headline: "Empowering Businesses with Next-Gen ERP Technology",
    subtitle: "HKRION ERP is a premium monorepo-based Enterprise Resource Planning suite designed to streamline retail, inventory, finances, and operations.",
    mission: "We believe that enterprise management software shouldn't be slow, bloated, or complicated. Our mission is to provide businesses of all sizes with a lightning-fast, modular, and exceptionally beautiful ERP platform.",
    architectureStory: "By utilizing a modern monorepo architecture with NestJS and Next.js, HKRION delivers a seamless native-like performance both on the web and as a desktop shell.",
    stats: [
      { label: "Active Businesses", value: "2,500+" },
      { label: "Daily Transactions", value: "$1.2M+" },
      { label: "Server Uptime", value: "99.99%" },
      { label: "Support Resolution", value: "< 2 Hrs" },
    ],
    values: [
      { title: "High Performance", description: "Optimized for speed and efficiency with a native-feeling desktop and web experience.", icon: "Zap" },
      { title: "Ironclad Security", description: "Your business data is fully encrypted and protected with enterprise-grade security protocols.", icon: "Shield" },
      { title: "Modular Design", description: "Scale your business seamlessly by mounting only the modules you need, when you need them.", icon: "Cpu" },
      { title: "Global Scalability", description: "Multi-currency, multi-country, and multi-warehouse support built directly into the core.", icon: "Globe" },
    ],
  });

  const [contactData, setContactData] = useState<{
    badge: string;
    headline: string;
    subtitle: string;
    email: string;
    phone: string;
    whatsapp: string;
    address: string;
    workingHours: string;
    whatsappLink: string;
  }>({
    badge: "Get In Touch",
    headline: "Contact Our Support Team",
    subtitle: "Have questions about HKRION ERP? We're here to help. Send us a message or contact our direct hotline.",
    email: "support@hkrion.com",
    phone: "+94 11 234 5678",
    whatsapp: "+94 77 123 4567",
    address: "Level 14, World Trade Center, Echelon Square, Colombo 00100, Sri Lanka",
    workingHours: "Monday - Friday: 8:30 AM - 6:30 PM (IST)\n24/7 Emergency Cloud Hotline for Active Subscribers",
    whatsappLink: "https://wa.me/94771234567",
  });

  // Modals
  const [isSpotlightModalOpen, setIsSpotlightModalOpen] = useState(false);
  const [editingSpotlight, setEditingSpotlight] = useState<CmsSpotlight | null>(null);

  const [isFeatureModalOpen, setIsFeatureModalOpen] = useState(false);
  const [editingFeature, setEditingFeature] = useState<CmsFeature | null>(null);

  const [isFaqModalOpen, setIsFaqModalOpen] = useState(false);
  const [editingFaq, setEditingFaq] = useState<CmsFaq | null>(null);

  const [isTestimonialModalOpen, setIsTestimonialModalOpen] = useState(false);
  const [editingTestimonial, setEditingTestimonial] = useState<CmsTestimonial | null>(null);

  const [isPageModalOpen, setIsPageModalOpen] = useState(false);
  const [editingPage, setEditingPage] = useState<CmsPage | null>(null);

  const [isPostModalOpen, setIsPostModalOpen] = useState(false);
  const [editingPost, setEditingPost] = useState<CmsPost | null>(null);

  const RESERVED_SLUGS = [
    "login", "register", "dashboard", "api", "super", "admin", "pricing",
    "pos", "about", "contact", "privacy", "refund", "terms", "posts", "settings",
    "reports", "users", "products", "inventory", "sales", "purchases"
  ];

  const isSafeUrl = (url?: string) => {
    if (!url) return true;
    const trimmed = url.trim().toLowerCase();
    return !trimmed.startsWith("javascript:") && !trimmed.startsWith("data:") && !trimmed.startsWith("vbscript:");
  };

  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed || (user && (user.role as string) !== "super-admin")) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 1500);
      return;
    } else {
      loadAllCmsData();
    }
  }, []);

  const loadAllCmsData = async () => {
    setIsLoading(true);
    try {
      const [heroData, spotlightData, featData, faqData, testData, pageData, postData] =
        await Promise.all([
          cmsService.getHero().catch(() => null),
          cmsService.getAllSpotlights().catch(() => []),
          cmsService.getAllFeatures().catch(() => []),
          cmsService.getAllFaqs().catch(() => []),
          cmsService.getAllTestimonials().catch(() => []),
          cmsService.getAllPages().catch(() => []),
          cmsService.getAllPosts().catch(() => []),
        ]);

      if (heroData) setHero(heroData);
      setSpotlights(spotlightData);
      setFeatures(featData);
      setFaqs(faqData);
      setTestimonials(testData);
      setPages(pageData);
      setPosts(postData);

      // Extract about and contact data if present in pages
      const aboutPage = pageData.find((p) => p.slug === "about");
      if (aboutPage?.content) {
        try {
          const parsed = JSON.parse(aboutPage.content);
          if (parsed && typeof parsed === "object") {
            setAboutData((prev) => ({ ...prev, ...parsed }));
          }
        } catch {
          // not json
        }
      }

      const contactPage = pageData.find((p) => p.slug === "contact");
      if (contactPage?.content) {
        try {
          const parsed = JSON.parse(contactPage.content);
          if (parsed && typeof parsed === "object") {
            setContactData((prev) => ({ ...prev, ...parsed }));
          }
        } catch {
          // not json
        }
      }
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to load CMS content");
    } finally {
      setIsLoading(false);
    }
  };

  const showSuccessFeedback = (msg = "Changes saved and published live!") => {
    setSaveSuccess(true);
    setErrorMessage("");
    setTimeout(() => setSaveSuccess(false), 3500);
  };

  // --- Home Handlers ---
  const handleSaveHero = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isSafeUrl(hero.primaryCtaLink) || !isSafeUrl(hero.secondaryCtaLink) || !isSafeUrl(hero.announcementLink)) {
      setErrorMessage("Invalid URL protocol detected. Javascript and data URLs are not permitted.");
      return;
    }
    setIsSaving(true);
    try {
      await cmsService.updateHero(hero);
      showSuccessFeedback("Hero & Top Announcement published live!");
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to update Hero section");
    } finally {
      setIsSaving(false);
    }
  };

  // --- About Us Save ---
  const handleSaveAbout = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      const existing = pages.find((p) => p.slug === "about");
      const payload: Partial<CmsPage> = {
        slug: "about",
        title: "About HKRION ERP",
        metaDescription: aboutData.subtitle,
        content: JSON.stringify(aboutData),
        isPublished: true,
      };

      if (existing?.id) {
        await cmsService.updatePage(existing.id, payload);
      } else {
        await cmsService.createPage(payload as CmsPage);
      }
      const updatedPages = await cmsService.getAllPages();
      setPages(updatedPages);
      showSuccessFeedback("About Us page published live!");
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to save About page");
    } finally {
      setIsSaving(false);
    }
  };

  // --- Contact Us Save ---
  const handleSaveContact = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isSafeUrl(contactData.whatsappLink)) {
      setErrorMessage("Invalid URL protocol in WhatsApp link.");
      return;
    }
    setIsSaving(true);
    try {
      const existing = pages.find((p) => p.slug === "contact");
      const payload: Partial<CmsPage> = {
        slug: "contact",
        title: "Contact Support & Sales",
        metaDescription: contactData.subtitle,
        content: JSON.stringify(contactData),
        isPublished: true,
      };

      if (existing?.id) {
        await cmsService.updatePage(existing.id, payload);
      } else {
        await cmsService.createPage(payload as CmsPage);
      }
      const updatedPages = await cmsService.getAllPages();
      setPages(updatedPages);
      showSuccessFeedback("Contact Us page published live!");
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to save Contact page");
    } finally {
      setIsSaving(false);
    }
  };

  // --- Spotlights Handlers ---
  const handleSaveSpotlight = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSpotlight) return;
    if (!isSafeUrl(editingSpotlight.ctaLink) || !isSafeUrl(editingSpotlight.imageUrl)) {
      setErrorMessage("Invalid URL protocol detected in spotlight links.");
      return;
    }
    try {
      const parsed = JSON.parse(editingSpotlight.bulletPointsJson);
      if (!Array.isArray(parsed)) {
        setErrorMessage("Bullet Points must be a valid JSON array of objects.");
        return;
      }
    } catch {
      setErrorMessage("Invalid Bullet Points JSON format. Example: [{\"icon\":\"...\",\"title\":\"...\",\"description\":\"...\"}]");
      return;
    }

    try {
      if (editingSpotlight.id) {
        await cmsService.updateSpotlight(editingSpotlight.id, editingSpotlight);
      } else {
        await cmsService.createSpotlight(editingSpotlight);
      }
      setIsSpotlightModalOpen(false);
      setEditingSpotlight(null);
      const data = await cmsService.getAllSpotlights();
      setSpotlights(data);
      showSuccessFeedback("Spotlight tab updated successfully!");
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to save spotlight");
    }
  };

  const handleDeleteSpotlight = async (id: string) => {
    try {
      await cmsService.deleteSpotlight(id);
      setSpotlights(spotlights.filter((s) => s.id !== id));
      showSuccessFeedback("ERP Module tab deleted!");
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to delete module tab");
    }
  };

  // --- Features Handlers ---
  const handleSaveFeature = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingFeature) return;
    try {
      if (editingFeature.id) {
        await cmsService.updateFeature(editingFeature.id, editingFeature);
      } else {
        await cmsService.createFeature(editingFeature);
      }
      setIsFeatureModalOpen(false);
      setEditingFeature(null);
      const data = await cmsService.getAllFeatures();
      setFeatures(data);
      showSuccessFeedback("Feature card saved!");
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to save feature");
    }
  };

  const handleDeleteFeature = async (id: string) => {
    try {
      await cmsService.deleteFeature(id);
      setFeatures(features.filter((f) => f.id !== id));
      showSuccessFeedback("Feature card deleted!");
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to delete feature");
    }
  };

  // --- FAQ Handlers ---
  const handleSaveFaq = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingFaq) return;
    try {
      if (editingFaq.id) {
        await cmsService.updateFaq(editingFaq.id, editingFaq);
      } else {
        await cmsService.createFaq(editingFaq);
      }
      setIsFaqModalOpen(false);
      setEditingFaq(null);
      const data = await cmsService.getAllFaqs();
      setFaqs(data);
      showSuccessFeedback("FAQ item saved!");
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to save FAQ");
    }
  };

  const handleDeleteFaq = async (id: string) => {
    try {
      await cmsService.deleteFaq(id);
      setFaqs(faqs.filter((f) => f.id !== id));
      showSuccessFeedback("FAQ item deleted!");
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to delete FAQ");
    }
  };

  // --- Testimonial Handlers ---
  const handleSaveTestimonial = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTestimonial) return;
    if (!isSafeUrl(editingTestimonial.avatarUrl)) {
      setErrorMessage("Invalid avatar image URL protocol.");
      return;
    }
    try {
      if (editingTestimonial.id) {
        await cmsService.updateTestimonial(editingTestimonial.id, editingTestimonial);
      } else {
        await cmsService.createTestimonial(editingTestimonial);
      }
      setIsTestimonialModalOpen(false);
      setEditingTestimonial(null);
      const data = await cmsService.getAllTestimonials();
      setTestimonials(data);
      showSuccessFeedback("Testimonial review saved!");
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to save testimonial");
    }
  };

  const handleDeleteTestimonial = async (id: string) => {
    try {
      await cmsService.deleteTestimonial(id);
      setTestimonials(testimonials.filter((t) => t.id !== id));
      showSuccessFeedback("Testimonial review deleted!");
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to delete testimonial");
    }
  };

  // --- Generic Page Handlers (Privacy, Refund, Terms, Custom) ---
  const handleSavePage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPage) return;
    const normalizedSlug = editingPage.slug.trim().toLowerCase();
    if (
      !editingPage.id &&
      RESERVED_SLUGS.includes(normalizedSlug) &&
      !["privacy", "refund", "terms", "about", "contact"].includes(normalizedSlug)
    ) {
      setErrorMessage(`The slug '${normalizedSlug}' is a reserved system route. Please choose another slug.`);
      return;
    }

    try {
      if (editingPage.id) {
        await cmsService.updatePage(editingPage.id, editingPage);
      } else {
        await cmsService.createPage(editingPage);
      }
      setIsPageModalOpen(false);
      setEditingPage(null);
      const data = await cmsService.getAllPages();
      setPages(data);
      showSuccessFeedback("Page content published live!");
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to save page");
    }
  };

  const handleDeletePage = async (id: string) => {
    try {
      await cmsService.deletePage(id);
      setPages(pages.filter((p) => p.id !== id));
      if (selectedPageKey === id) setSelectedPageKey(null);
      showSuccessFeedback("Page deleted!");
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to delete page");
    }
  };

  // --- Posts Handlers ---
  const handleSavePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPost) return;
    if (!isSafeUrl(editingPost.coverImage)) {
      setErrorMessage("Invalid cover image URL protocol.");
      return;
    }
    try {
      if (editingPost.id) {
        await cmsService.updatePost(editingPost.id, editingPost);
      } else {
        await cmsService.createPost(editingPost);
      }
      setIsPostModalOpen(false);
      setEditingPost(null);
      const data = await cmsService.getAllPosts();
      setPosts(data);
      showSuccessFeedback("Changelog post published!");
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to save post");
    }
  };

  const handleDeletePost = async (id: string) => {
    try {
      await cmsService.deletePost(id);
      setPosts(posts.filter((p) => p.id !== id));
      showSuccessFeedback("Post deleted!");
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to delete post");
    }
  };


  if (isAuthenticated === null) {
    return <LoadingSession />;
  }

  // Define the core pages registry for Directory view
  const coreDirectoryPages = [
    {
      key: "home",
      title: "Home / Landing Page",
      route: "/",
      badge: "MAIN LANDING",
      badgeColor: "bg-primary/15 text-primary border-primary/20",
      description: "Headline, Top Announcement Bar, 4 Core ERP Modules, Feature Grid, FAQs, and Verified Reviews.",
      icon: Globe,
      updatedAt: hero.updatedAt || "Real-time",
    },
    {
      key: "about",
      title: "About Us Platform Story",
      route: "/about",
      badge: "COMPANY INFO",
      badgeColor: "bg-blue-500/15 text-blue-400 border-blue-500/20",
      description: "Mission statement, monorepo cloud architecture story, key company stats, and 4 core values.",
      icon: Info,
      updatedAt: pages.find((p) => p.slug === "about")?.updatedAt || "Real-time",
    },
    {
      key: "contact",
      title: "Contact & Support Hub",
      route: "/contact",
      badge: "HELP & SALES",
      badgeColor: "bg-emerald-500/15 text-emerald-400 border-emerald-500/20",
      description: "Direct support email, phone hotline, Colombo HQ address, operating hours, and WhatsApp chat link.",
      icon: Phone,
      updatedAt: pages.find((p) => p.slug === "contact")?.updatedAt || "Real-time",
    },
    {
      key: "pricing",
      title: "Pricing & Subscription Plans",
      route: "/pricing",
      badge: "SUBSCRIPTIONS",
      badgeColor: "bg-purple-500/15 text-purple-400 border-purple-500/20",
      description: "Monthly / Yearly billing switch, PayHere payment checkout, tiered feature limits, and subscription plans.",
      icon: CreditCard,
      updatedAt: "Dynamic Database",
    },
    {
      key: "privacy",
      title: "Privacy Policy & Compliance",
      route: "/privacy",
      badge: "LEGAL & SECURITY",
      badgeColor: "bg-amber-500/15 text-amber-400 border-amber-500/20",
      description: "Row-level tenant isolation, TLS 1.3 encryption, no-sale data guarantee, and data ownership rights.",
      icon: Shield,
      updatedAt: pages.find((p) => p.slug === "privacy")?.updatedAt || "Real-time",
    },
    {
      key: "refund",
      title: "Refund & Cancellation Policy",
      route: "/refund",
      badge: "BILLING POLICY",
      badgeColor: "bg-amber-500/15 text-amber-400 border-amber-500/20",
      description: "14-day free trial terms, PayHere dispute resolution, bank slip verification, and cancellation guidelines.",
      icon: FileText,
      updatedAt: pages.find((p) => p.slug === "refund")?.updatedAt || "Real-time",
    },
    {
      key: "terms",
      title: "Terms of Service (EULA)",
      route: "/terms",
      badge: "LEGAL TERMS",
      badgeColor: "bg-amber-500/15 text-amber-400 border-amber-500/20",
      description: "Software license terms, user quotas, acceptable use guidelines, and 99.9% uptime SLA guarantee.",
      icon: BookOpen,
      updatedAt: pages.find((p) => p.slug === "terms")?.updatedAt || "Real-time",
    },
    {
      key: "posts",
      title: "Changelog & Product Updates",
      route: "/posts",
      badge: "PUBLIC ROADMAP",
      badgeColor: "bg-cyan-500/15 text-cyan-400 border-cyan-500/20",
      description: "Product release announcements, version tags (e.g. v2.5.0), and feature change summaries.",
      icon: Sparkles,
      updatedAt: posts[0]?.publishedAt || "Real-time",
    },
  ];

  // Custom pages from database (excluding standard slugs)
  const standardSlugs = ["privacy", "refund", "terms", "about", "contact"];
  const customPages = pages.filter((p) => !standardSlugs.includes(p.slug));

  const allDirectoryItems = [
    ...coreDirectoryPages,
    ...customPages.map((p) => ({
      key: p.slug,
      title: p.title,
      route: `/${p.slug}`,
      badge: "CUSTOM PAGE",
      badgeColor: "bg-secondary text-foreground border-border",
      description: p.metaDescription || "Custom content page.",
      icon: FileText,
      updatedAt: p.updatedAt || "Real-time",
      isCustom: true,
      rawPage: p,
    })),
  ];

  const filteredDirectory = allDirectoryItems.filter(
    (item) =>
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.route.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden font-sans">
      <Sidebar activePath="/super/cms" />

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Navbar title="CMS & Pages Manager" className="relative z-10" />

        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 relative z-10">
          {/* Top Feedback Alerts */}
          {saveSuccess && (
            <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 p-3 rounded-sm text-xs flex items-center gap-2 animate-fadeIn shadow-lg">
              <CheckCircle className="w-4 h-4 shrink-0" />
              <span>Changes successfully saved and published live to the public website!</span>
            </div>
          )}

          {errorMessage && (
            <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 p-3 rounded-sm text-xs flex items-center gap-2 animate-fadeIn shadow-lg">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* ========================================================================= */}
          {/* VIEW 1: ALL WEBSITE PAGES DIRECTORY (WHEN NO PAGE IS ACTIVELY SELECTED) */}
          {/* ========================================================================= */}
          {selectedPageKey === null ? (
            <div className="space-y-6">
              {/* Directory Header */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-border/80 pb-5">
                <div>
                  <h1 className="text-2xl font-extrabold tracking-tight font-mono text-foreground flex items-center gap-2.5">
                    <Globe className="w-6 h-6 text-primary" /> Website Pages Directory
                  </h1>
                  <p className="text-xs text-muted-foreground mt-1">
                    Select any page below to edit its content, images, announcement bars, policies, and contact information.
                  </p>
                </div>

                <div className="flex items-center gap-2.5">
                  <Button
                    onClick={() => {
                      setEditingPage({
                        slug: `page_${Date.now()}`,
                        title: "New Custom Page",
                        metaDescription: "Description of the new page for search engines.",
                        content: `# New Page Title\n\nWrite your content in Markdown here...`,
                        isPublished: true,
                      });
                      setIsPageModalOpen(true);
                    }}
                    className="text-xs h-9 px-4 font-bold rounded-sm gap-1.5 shadow-md shadow-primary/20"
                  >
                    <Plus className="w-3.5 h-3.5" /> Create Custom Page
                  </Button>
                  <a
                    href="/"
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs h-9 px-3.5 border border-border bg-card/60 hover:bg-card text-foreground rounded-sm font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5 text-primary" /> Live Site <ExternalLink className="w-3 h-3 text-muted-foreground" />
                  </a>
                </div>
              </div>

              {/* Search & Filter Bar */}
              <div className="flex items-center justify-between gap-4">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search pages by name or route (e.g. /about, refund, pos)..."
                    className="pl-9 h-9 text-xs rounded-sm bg-card/40 border-border/70"
                  />
                </div>
                <div className="text-[11px] font-mono text-muted-foreground">
                  Showing <strong>{filteredDirectory.length}</strong> pages
                </div>
              </div>

              {/* Pages Grid */}
              {isLoading ? (
                <div className="p-16 text-center text-muted-foreground">
                  <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-primary" />
                  <p className="text-xs font-mono">Loading website pages from PostgreSQL database...</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                  {filteredDirectory.map((pageItem: any) => {
                    const IconComp = pageItem.icon || FileText;
                    return (
                      <Card
                        key={pageItem.key}
                        onClick={() => setSelectedPageKey(pageItem.key)}
                        className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-5 flex flex-col justify-between hover:border-primary/60 hover:shadow-xl hover:shadow-primary/5 transition-all duration-300 cursor-pointer group"
                      >
                        <div className="space-y-3.5">
                          <div className="flex items-center justify-between">
                            <div className="w-9 h-9 rounded-sm bg-primary/10 border border-primary/20 flex items-center justify-center text-primary group-hover:scale-105 transition-transform">
                              <IconComp className="w-4 h-4" />
                            </div>
                            <span
                              className={`text-[9px] font-mono font-bold uppercase px-2 py-0.5 rounded-sm border ${pageItem.badgeColor}`}
                            >
                              {pageItem.badge}
                            </span>
                          </div>

                          <div className="space-y-1">
                            <h3 className="text-sm font-bold text-foreground group-hover:text-primary transition-colors flex items-center gap-1.5">
                              {pageItem.title}
                            </h3>
                            <p className="text-[11px] font-mono text-primary font-bold">
                              {pageItem.route}
                            </p>
                            <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed pt-1">
                              {pageItem.description}
                            </p>
                          </div>
                        </div>

                        <div className="pt-4 mt-4 border-t border-border/50 flex items-center justify-between">
                          <span className="text-[10px] font-mono text-muted-foreground">
                            Live ✓
                          </span>
                          <div className="flex items-center gap-1.5">
                            <Button
                              size="sm"
                              variant="default"
                              className="text-xs h-7 px-3 rounded-sm font-bold gap-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                            >
                              <Edit2 className="w-3 h-3" /> Edit Page
                            </Button>
                            <a
                              href={pageItem.route}
                              target="_blank"
                              rel="noreferrer"
                              onClick={(e) => e.stopPropagation()}
                              className="p-1.5 rounded-sm hover:bg-secondary text-muted-foreground hover:text-foreground"
                              title="Open live page in new tab"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                          </div>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              )}
            </div>
          ) : (
            /* ========================================================================= */
            /* VIEW 2: DEDICATED PAGE EDITOR (WHEN A PAGE IS CLICKED & OPENED)          */
            /* ========================================================================= */
            <div className="space-y-6">
              {/* Page Editor Navigation Header */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-card/60 backdrop-blur-md p-4 rounded-sm border border-border/80">
                <div className="flex items-center gap-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedPageKey(null)}
                    className="text-xs h-8 px-3 rounded-sm font-bold gap-1.5 border-border hover:bg-secondary"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" /> All Pages
                  </Button>
                  <div className="h-5 w-[1px] bg-border" />
                  <div>
                    <h2 className="text-sm font-bold text-foreground font-mono flex items-center gap-2">
                      <Edit2 className="w-3.5 h-3.5 text-primary" />
                      Editing:{" "}
                      <span className="text-primary">
                        {allDirectoryItems.find((p) => p.key === selectedPageKey)?.title || selectedPageKey}
                      </span>
                    </h2>
                    <p className="text-[10px] font-mono text-muted-foreground">
                      Route: {allDirectoryItems.find((p) => p.key === selectedPageKey)?.route || `/${selectedPageKey}`}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2.5">
                  {/* Quick page switcher dropdown */}
                  <select
                    value={selectedPageKey}
                    onChange={(e) => setSelectedPageKey(e.target.value)}
                    className="h-8 px-2.5 text-xs rounded-sm bg-secondary/50 border border-border text-foreground font-mono outline-none"
                  >
                    {allDirectoryItems.map((item) => (
                      <option key={item.key} value={item.key}>
                        {item.title} ({item.route})
                      </option>
                    ))}
                  </select>

                  <a
                    href={allDirectoryItems.find((p) => p.key === selectedPageKey)?.route || "/"}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs h-8 px-3 border border-border bg-card hover:bg-secondary text-foreground rounded-sm font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <Eye className="w-3 h-3 text-primary" /> Preview Live <ExternalLink className="w-2.5 h-2.5 text-muted-foreground" />
                  </a>
                </div>
              </div>

              {/* --------------------------------------------------------------------- */}
              {/* PAGE 1: HOME PAGE EDITOR                                              */}
              {/* --------------------------------------------------------------------- */}
              {selectedPageKey === "home" && (
                <div className="space-y-6">
                  {/* Home Sub-tabs */}
                  <div className="flex items-center gap-2 border-b border-border pb-1 overflow-x-auto">
                    <button
                      onClick={() => setHomeSubTab("hero")}
                      className={`px-3.5 py-1.5 text-xs font-bold font-mono transition-all rounded-t-sm flex items-center gap-1.5 ${
                        homeSubTab === "hero"
                          ? "border-b-2 border-primary text-primary bg-primary/10"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      <Globe className="w-3.5 h-3.5" /> Hero & Top Banner
                    </button>
                    <button
                      onClick={() => setHomeSubTab("spotlights")}
                      className={`px-3.5 py-1.5 text-xs font-bold font-mono transition-all rounded-t-sm flex items-center gap-1.5 ${
                        homeSubTab === "spotlights"
                          ? "border-b-2 border-primary text-primary bg-primary/10"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      <Monitor className="w-3.5 h-3.5" /> Core ERP Modules ({spotlights.length})
                    </button>
                    <button
                      onClick={() => setHomeSubTab("features")}
                      className={`px-3.5 py-1.5 text-xs font-bold font-mono transition-all rounded-t-sm flex items-center gap-1.5 ${
                        homeSubTab === "features"
                          ? "border-b-2 border-primary text-primary bg-primary/10"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      <Sparkles className="w-3.5 h-3.5" /> Core Feature Grid ({features.length})
                    </button>
                    <button
                      onClick={() => setHomeSubTab("faqs")}
                      className={`px-3.5 py-1.5 text-xs font-bold font-mono transition-all rounded-t-sm flex items-center gap-1.5 ${
                        homeSubTab === "faqs"
                          ? "border-b-2 border-primary text-primary bg-primary/10"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      <HelpCircle className="w-3.5 h-3.5" /> FAQs ({faqs.length})
                    </button>
                    <button
                      onClick={() => setHomeSubTab("testimonials")}
                      className={`px-3.5 py-1.5 text-xs font-bold font-mono transition-all rounded-t-sm flex items-center gap-1.5 ${
                        homeSubTab === "testimonials"
                          ? "border-b-2 border-primary text-primary bg-primary/10"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      <MessageSquare className="w-3.5 h-3.5" /> Testimonials ({testimonials.length})
                    </button>
                  </div>

                  {/* Subtab 1: Hero */}
                  {homeSubTab === "hero" && (
                    <form onSubmit={handleSaveHero} className="space-y-5 max-w-4xl">
                      <Card className="bg-card/40 backdrop-blur-md border-border/70 rounded-sm">
                        <CardContent className="p-6 space-y-4">
                          <div className="flex items-center justify-between border-b border-border pb-2">
                            <div>
                              <h3 className="text-sm font-bold text-foreground flex items-center gap-2 font-mono">
                                <Sparkles className="w-4 h-4 text-primary" /> Top Promo & Announcement Bar
                              </h3>
                              <p className="text-xs text-muted-foreground mt-0.5">
                                Notification banner rendered at the absolute top of the page.
                              </p>
                            </div>
                            <label className="flex items-center gap-2 text-xs cursor-pointer">
                              <input
                                type="checkbox"
                                checked={hero.announcementActive}
                                onChange={(e) =>
                                  setHero({ ...hero, announcementActive: e.target.checked })
                                }
                                className="w-4 h-4 accent-primary rounded"
                              />
                              <span className="font-mono text-muted-foreground font-bold">Enable Banner</span>
                            </label>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                            <div className="md:col-span-2 space-y-1">
                              <label className="text-xs font-bold text-muted-foreground font-mono">
                                Announcement Offer Text
                              </label>
                              <Input
                                value={hero.announcementText || ""}
                                onChange={(e) =>
                                  setHero({ ...hero, announcementText: e.target.value })
                                }
                                className="h-9 text-xs rounded-sm"
                                placeholder="Special Launch Offer: 20% OFF on all Yearly Plans! 🚀"
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="text-xs font-bold text-muted-foreground font-mono">
                                Target Link
                              </label>
                              <Input
                                value={hero.announcementLink || ""}
                                onChange={(e) =>
                                  setHero({ ...hero, announcementLink: e.target.value })
                                }
                                className="h-9 text-xs font-mono rounded-sm"
                                placeholder="#pricing or /register"
                              />
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="bg-card/40 backdrop-blur-md border-border/70 rounded-sm">
                        <CardContent className="p-6 space-y-4">
                          <div className="border-b border-border pb-2">
                            <h3 className="text-sm font-bold text-foreground flex items-center gap-2 font-mono">
                              <Globe className="w-4 h-4 text-primary" /> Hero Headlines & Call to Actions
                            </h3>
                            <p className="text-xs text-muted-foreground mt-0.5">
                              Main headline, subtitle description, and interactive action buttons.
                            </p>
                          </div>

                          <div className="space-y-1">
                            <label className="text-xs font-bold text-muted-foreground font-mono">
                              Badge Tagline
                            </label>
                            <Input
                              value={hero.badgeText || ""}
                              onChange={(e) => setHero({ ...hero, badgeText: e.target.value })}
                              className="h-9 text-xs font-mono text-primary rounded-sm"
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-xs font-bold text-muted-foreground font-mono">
                              Main Headline (Hero Title) *
                            </label>
                            <Input
                              value={hero.heroTitle}
                              onChange={(e) => setHero({ ...hero, heroTitle: e.target.value })}
                              className="h-10 text-sm font-extrabold text-foreground rounded-sm"
                              required
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-xs font-bold text-muted-foreground font-mono">
                              Sub-headline Description
                            </label>
                            <textarea
                              rows={3}
                              value={hero.heroSubtitle || ""}
                              onChange={(e) => setHero({ ...hero, heroSubtitle: e.target.value })}
                              className="w-full p-3 text-xs rounded-sm bg-secondary/40 border border-border text-foreground focus:ring-1 focus:ring-primary outline-none"
                            />
                          </div>

                          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2">
                            <div className="space-y-1">
                              <label className="text-xs font-bold text-muted-foreground font-mono">
                                Primary CTA Text
                              </label>
                              <Input
                                value={hero.primaryCtaText || ""}
                                onChange={(e) =>
                                  setHero({ ...hero, primaryCtaText: e.target.value })
                                }
                                className="h-9 text-xs font-bold rounded-sm"
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="text-xs font-bold text-muted-foreground font-mono">
                                Primary CTA Link
                              </label>
                              <Input
                                value={hero.primaryCtaLink || ""}
                                onChange={(e) =>
                                  setHero({ ...hero, primaryCtaLink: e.target.value })
                                }
                                className="h-9 text-xs font-mono rounded-sm"
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="text-xs font-bold text-muted-foreground font-mono">
                                Secondary CTA Text
                              </label>
                              <Input
                                value={hero.secondaryCtaText || ""}
                                onChange={(e) =>
                                  setHero({ ...hero, secondaryCtaText: e.target.value })
                                }
                                className="h-9 text-xs rounded-sm"
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="text-xs font-bold text-muted-foreground font-mono">
                                Secondary CTA Link
                              </label>
                              <Input
                                value={hero.secondaryCtaLink || ""}
                                onChange={(e) =>
                                  setHero({ ...hero, secondaryCtaLink: e.target.value })
                                }
                                className="h-9 text-xs font-mono rounded-sm"
                              />
                            </div>
                          </div>

                          <div className="pt-4 flex justify-end">
                            <Button
                              type="submit"
                              disabled={isSaving}
                              className="text-xs h-9 px-5 font-bold rounded-sm shadow-md shadow-primary/20 flex items-center gap-1.5"
                            >
                              {isSaving ? (
                                <>
                                  <Loader2 className="w-3.5 h-3.5 animate-spin" /> Publishing...
                                </>
                              ) : (
                                <>
                                  <Save className="w-3.5 h-3.5" /> Save Hero Section
                                </>
                              )}
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    </form>
                  )}

                  {/* Subtab 2: Core ERP Modules */}
                  {homeSubTab === "spotlights" && (
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <p className="text-xs text-muted-foreground">
                          Manage interactive showcase tabs and screenshots for POS, Inventory & IMEI, Multi-Branch, and Accounting modules.
                        </p>
                        <Button
                          onClick={() => {
                            setEditingSpotlight({
                              tabKey: `tab_${Date.now()}`,
                              tabLabel: "New ERP Module Tab",
                              title: "New ERP Module Capability",
                              subtitle: "Detailed description of the new ERP module capability.",
                              badge: "ENTERPRISE",
                              iconName: "ShoppingBag",
                              imageUrl: "/images/hero-dashboard.jpg",
                              bulletPointsJson: JSON.stringify([
                                { icon: "Sparkles", title: "Key Benefit #1", description: "Seamless real-time ledger updates." },
                                { icon: "ShieldCheck", title: "Key Benefit #2", description: "Enterprise-grade reliability and encrypted backups." },
                              ]),
                              ctaText: "Start Free Trial",
                              ctaLink: "/register",
                              sortOrder: spotlights.length + 1,
                              isActive: true,
                            });
                            setIsSpotlightModalOpen(true);
                          }}
                          className="text-xs h-8 font-bold rounded-sm flex items-center gap-1.5"
                        >
                          <Plus className="w-3.5 h-3.5" /> Add ERP Module Tab
                        </Button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {spotlights.map((spot) => (
                          <Card
                            key={spot.id || spot.tabKey}
                            className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm overflow-hidden flex flex-col justify-between"
                          >
                            <div className="p-5 space-y-3.5">
                              <div className="flex items-center justify-between">
                                <span className="text-[10px] font-mono font-bold bg-primary/10 text-primary px-2.5 py-0.5 rounded-sm border border-primary/20">
                                  TAB: {spot.tabLabel}
                                </span>
                                <span className="text-[9px] font-mono uppercase bg-secondary px-2 py-0.5 rounded-sm border border-border">
                                  {spot.badge || "MODULE"}
                                </span>
                              </div>
                              <div>
                                <h4 className="text-sm font-bold text-foreground">{spot.title}</h4>
                                <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
                                  {spot.subtitle}
                                </p>
                              </div>
                              <div className="rounded-sm overflow-hidden border border-border/60 h-28 bg-card/80 relative">
                                <img
                                  src={spot.imageUrl}
                                  alt={spot.title}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                            </div>
                            <div className="p-3.5 bg-secondary/20 border-t border-border/50 flex items-center justify-between">
                              <span className="text-[10px] font-mono text-muted-foreground">Order: #{spot.sortOrder}</span>
                              <div className="flex items-center gap-1.5">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => {
                                    setEditingSpotlight(spot);
                                    setIsSpotlightModalOpen(true);
                                  }}
                                  className="text-xs h-7 px-2.5 rounded-sm"
                                >
                                  <Edit2 className="w-3 h-3 text-primary mr-1" /> Edit
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => spot.id && handleDeleteSpotlight(spot.id)}
                                  className="text-xs h-7 px-2.5 rounded-sm hover:bg-rose-500/10 hover:text-rose-400"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Subtab 3: Features */}
                  {homeSubTab === "features" && (
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <p className="text-xs text-muted-foreground">
                          Core feature cards displayed on the intelligent modules grid.
                        </p>
                        <Button
                          onClick={() => {
                            setEditingFeature({
                              title: "",
                              description: "",
                              iconName: "ShoppingBag",
                              badge: "NEW",
                              category: "Core Modules",
                              sortOrder: features.length + 1,
                              isActive: true,
                            });
                            setIsFeatureModalOpen(true);
                          }}
                          className="text-xs h-8 font-bold rounded-sm flex items-center gap-1.5"
                        >
                          <Plus className="w-3.5 h-3.5" /> Add Feature Card
                        </Button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {features.map((feat) => (
                          <Card
                            key={feat.id}
                            className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-4 flex flex-col justify-between"
                          >
                            <div className="space-y-2">
                              <div className="flex justify-between items-center">
                                <span className="text-[9px] font-mono bg-primary/10 text-primary px-2 py-0.5 rounded-sm font-bold border border-primary/20">
                                  {feat.badge || feat.category}
                                </span>
                                <span className="text-[10px] font-mono text-muted-foreground">#{feat.sortOrder}</span>
                              </div>
                              <h4 className="text-xs font-bold text-foreground">{feat.title}</h4>
                              <p className="text-[11px] text-muted-foreground line-clamp-3 leading-relaxed">
                                {feat.description}
                              </p>
                            </div>
                            <div className="pt-3 mt-3 border-t border-border/40 flex justify-end gap-1.5">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setEditingFeature(feat);
                                  setIsFeatureModalOpen(true);
                                }}
                                className="text-xs h-7 px-2.5 rounded-sm"
                              >
                                <Edit2 className="w-3 h-3 text-primary mr-1" /> Edit
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => feat.id && handleDeleteFeature(feat.id)}
                                className="text-xs h-7 px-2.5 rounded-sm hover:bg-rose-500/10 hover:text-rose-400"
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Subtab 4: FAQs */}
                  {homeSubTab === "faqs" && (
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <p className="text-xs text-muted-foreground">
                          Frequently Asked Questions rendered in the interactive accordion.
                        </p>
                        <Button
                          onClick={() => {
                            setEditingFaq({
                              question: "",
                              answer: "",
                              category: "General",
                              sortOrder: faqs.length + 1,
                              isActive: true,
                            });
                            setIsFaqModalOpen(true);
                          }}
                          className="text-xs h-8 font-bold rounded-sm flex items-center gap-1.5"
                        >
                          <Plus className="w-3.5 h-3.5" /> Add FAQ Item
                        </Button>
                      </div>

                      <div className="space-y-3">
                        {faqs.map((faq) => (
                          <Card
                            key={faq.id}
                            className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-4 flex items-start justify-between gap-4"
                          >
                            <div className="space-y-1 flex-1">
                              <span className="text-[9px] font-mono bg-secondary px-2 py-0.5 rounded-sm border border-border">
                                {faq.category || "General"}
                              </span>
                              <h4 className="text-xs font-bold text-foreground pt-1">{faq.question}</h4>
                              <p className="text-xs text-muted-foreground leading-relaxed">{faq.answer}</p>
                            </div>
                            <div className="flex items-center gap-1.5 shrink-0">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setEditingFaq(faq);
                                  setIsFaqModalOpen(true);
                                }}
                                className="text-xs h-7 px-2.5 rounded-sm"
                              >
                                <Edit2 className="w-3 h-3 text-primary mr-1" /> Edit
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => faq.id && handleDeleteFaq(faq.id)}
                                className="text-xs h-7 px-2.5 rounded-sm hover:bg-rose-500/10 hover:text-rose-400"
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Subtab 5: Testimonials */}
                  {homeSubTab === "testimonials" && (
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <p className="text-xs text-muted-foreground">
                          Verified customer reviews and business testimonials.
                        </p>
                        <Button
                          onClick={() => {
                            setEditingTestimonial({
                              clientName: "",
                              clientRole: "Managing Director",
                              businessName: "",
                              rating: 5,
                              content: "",
                              sortOrder: testimonials.length + 1,
                              isActive: true,
                            });
                            setIsTestimonialModalOpen(true);
                          }}
                          className="text-xs h-8 font-bold rounded-sm flex items-center gap-1.5"
                        >
                          <Plus className="w-3.5 h-3.5" /> Add Review
                        </Button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {testimonials.map((t) => (
                          <Card
                            key={t.id}
                            className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-4 flex flex-col justify-between"
                          >
                            <div className="space-y-2">
                              <div className="flex text-amber-400">
                                {Array.from({ length: t.rating || 5 }).map((_, i) => (
                                  <Star key={i} className="w-3 h-3 fill-current" />
                                ))}
                              </div>
                              <p className="text-xs text-foreground italic leading-relaxed">
                                &quot;{t.content}&quot;
                              </p>
                              <div className="pt-2 border-t border-border/40">
                                <strong className="text-xs block text-foreground">{t.clientName}</strong>
                                <span className="text-[10px] text-muted-foreground font-mono">
                                  {t.clientRole}, {t.businessName}
                                </span>
                              </div>
                            </div>
                            <div className="pt-3 mt-3 border-t border-border/40 flex justify-end gap-1.5">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setEditingTestimonial(t);
                                  setIsTestimonialModalOpen(true);
                                }}
                                className="text-xs h-7 px-2.5 rounded-sm"
                              >
                                <Edit2 className="w-3 h-3 text-primary mr-1" /> Edit
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => t.id && handleDeleteTestimonial(t.id)}
                                className="text-xs h-7 px-2.5 rounded-sm hover:bg-rose-500/10 hover:text-rose-400"
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* --------------------------------------------------------------------- */}
              {/* PAGE 2: ABOUT US PAGE EDITOR                                          */}
              {/* --------------------------------------------------------------------- */}
              {selectedPageKey === "about" && (
                <form onSubmit={handleSaveAbout} className="space-y-5 max-w-4xl">
                  <Card className="bg-card/40 backdrop-blur-md border-border/70 rounded-sm">
                    <CardContent className="p-6 space-y-4">
                      <div className="border-b border-border pb-2">
                        <h3 className="text-sm font-bold text-foreground font-mono flex items-center gap-2">
                          <Info className="w-4 h-4 text-primary" /> About Us Story & Platform Mission
                        </h3>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          Editable content for the public <span className="font-mono text-primary font-bold">/about</span> page.
                        </p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">Badge Pill</label>
                          <Input
                            value={aboutData.badge}
                            onChange={(e) => setAboutData({ ...aboutData, badge: e.target.value })}
                            className="h-9 text-xs font-mono text-primary rounded-sm"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">Main Headline</label>
                          <Input
                            value={aboutData.headline}
                            onChange={(e) => setAboutData({ ...aboutData, headline: e.target.value })}
                            className="h-9 text-xs font-bold rounded-sm"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-muted-foreground font-mono">Intro Subtitle</label>
                        <textarea
                          rows={2}
                          value={aboutData.subtitle}
                          onChange={(e) => setAboutData({ ...aboutData, subtitle: e.target.value })}
                          className="w-full p-2.5 text-xs rounded-sm bg-secondary/40 border border-border text-foreground"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-muted-foreground font-mono">Mission Statement</label>
                        <textarea
                          rows={3}
                          value={aboutData.mission}
                          onChange={(e) => setAboutData({ ...aboutData, mission: e.target.value })}
                          className="w-full p-2.5 text-xs rounded-sm bg-secondary/40 border border-border text-foreground"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-muted-foreground font-mono">Architecture & Technology Story</label>
                        <textarea
                          rows={3}
                          value={aboutData.architectureStory}
                          onChange={(e) => setAboutData({ ...aboutData, architectureStory: e.target.value })}
                          className="w-full p-2.5 text-xs rounded-sm bg-secondary/40 border border-border text-foreground"
                        />
                      </div>

                      {/* Stats list */}
                      <div className="pt-2">
                        <label className="text-xs font-bold text-muted-foreground font-mono block mb-2">Company Key Stats (4 Metrics)</label>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                          {aboutData.stats.map((st, sIdx) => (
                            <div key={sIdx} className="space-y-1 p-2.5 bg-secondary/30 rounded-sm border border-border/60">
                              <Input
                                value={st.value}
                                onChange={(e) => {
                                  const updated = [...aboutData.stats];
                                  updated[sIdx].value = e.target.value;
                                  setAboutData({ ...aboutData, stats: updated });
                                }}
                                className="h-7 text-xs font-mono font-bold"
                                placeholder="Value (e.g. 2,500+)"
                              />
                              <Input
                                value={st.label}
                                onChange={(e) => {
                                  const updated = [...aboutData.stats];
                                  updated[sIdx].label = e.target.value;
                                  setAboutData({ ...aboutData, stats: updated });
                                }}
                                className="h-7 text-[10px]"
                                placeholder="Label (e.g. Active Stores)"
                              />
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="pt-4 flex justify-end">
                        <Button
                          type="submit"
                          disabled={isSaving}
                          className="text-xs h-9 px-5 font-bold rounded-sm shadow-md shadow-primary/20 flex items-center gap-1.5"
                        >
                          {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                          Save & Publish About Us
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </form>
              )}

              {/* --------------------------------------------------------------------- */}
              {/* PAGE 3: CONTACT US PAGE EDITOR                                        */}
              {/* --------------------------------------------------------------------- */}
              {selectedPageKey === "contact" && (
                <form onSubmit={handleSaveContact} className="space-y-5 max-w-4xl">
                  <Card className="bg-card/40 backdrop-blur-md border-border/70 rounded-sm">
                    <CardContent className="p-6 space-y-4">
                      <div className="border-b border-border pb-2">
                        <h3 className="text-sm font-bold text-foreground font-mono flex items-center gap-2">
                          <Phone className="w-4 h-4 text-primary" /> Contact Channels & Support Info
                        </h3>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          Editable support hotlines, Colombo headquarters, and working hours for <span className="font-mono text-primary font-bold">/contact</span>.
                        </p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">Badge Pill</label>
                          <Input
                            value={contactData.badge}
                            onChange={(e) => setContactData({ ...contactData, badge: e.target.value })}
                            className="h-9 text-xs font-mono text-primary rounded-sm"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">Main Headline</label>
                          <Input
                            value={contactData.headline}
                            onChange={(e) => setContactData({ ...contactData, headline: e.target.value })}
                            className="h-9 text-xs font-bold rounded-sm"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-muted-foreground font-mono">Subtitle Description</label>
                        <textarea
                          rows={2}
                          value={contactData.subtitle}
                          onChange={(e) => setContactData({ ...contactData, subtitle: e.target.value })}
                          className="w-full p-2.5 text-xs rounded-sm bg-secondary/40 border border-border text-foreground"
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">Support Email *</label>
                          <Input
                            value={contactData.email}
                            onChange={(e) => setContactData({ ...contactData, email: e.target.value })}
                            className="h-9 text-xs rounded-sm"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">Direct Phone Hotline *</label>
                          <Input
                            value={contactData.phone}
                            onChange={(e) => setContactData({ ...contactData, phone: e.target.value })}
                            className="h-9 text-xs font-mono rounded-sm"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-muted-foreground font-mono">WhatsApp Support Number</label>
                          <Input
                            value={contactData.whatsapp}
                            onChange={(e) => setContactData({ ...contactData, whatsapp: e.target.value })}
                            className="h-9 text-xs font-mono rounded-sm"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-muted-foreground font-mono">Colombo Office Physical Address</label>
                        <Input
                          value={contactData.address}
                          onChange={(e) => setContactData({ ...contactData, address: e.target.value })}
                          className="h-9 text-xs rounded-sm"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-muted-foreground font-mono">Operating Hours & Emergency Hotline</label>
                        <textarea
                          rows={2}
                          value={contactData.workingHours}
                          onChange={(e) => setContactData({ ...contactData, workingHours: e.target.value })}
                          className="w-full p-2.5 text-xs rounded-sm bg-secondary/40 border border-border text-foreground font-mono"
                        />
                      </div>

                      <div className="pt-4 flex justify-end">
                        <Button
                          type="submit"
                          disabled={isSaving}
                          className="text-xs h-9 px-5 font-bold rounded-sm shadow-md shadow-primary/20 flex items-center gap-1.5"
                        >
                          {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                          Save & Publish Contact Channels
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </form>
              )}

              {/* --------------------------------------------------------------------- */}
              {/* PAGE 4: PRICING & SUBSCRIPTION PLANS LINK                             */}
              {/* --------------------------------------------------------------------- */}
              {selectedPageKey === "pricing" && (
                <div className="max-w-4xl space-y-4">
                  <Card className="bg-card/40 backdrop-blur-md border-border/70 rounded-sm p-6 space-y-4">
                    <div className="border-b border-border pb-3">
                      <h3 className="text-sm font-bold text-foreground font-mono flex items-center gap-2">
                        <CreditCard className="w-4 h-4 text-primary" /> Pricing & Subscription Plans Management
                      </h3>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        Pricing tiers are dynamically driven by the central Subscriptions engine in PostgreSQL database.
                      </p>
                    </div>

                    <div className="p-4 bg-primary/10 border border-primary/20 rounded-sm text-xs space-y-2">
                      <p className="text-foreground font-bold">
                        To add new plans, adjust monthly/yearly LKR prices, or modify SKU/Branch limits:
                      </p>
                      <p className="text-muted-foreground">
                        Use the dedicated <strong>Subscription Plans Manager</strong> to configure live checkout tiers with PayHere.lk.
                      </p>
                    </div>

                    <div className="pt-2 flex items-center gap-3">
                      <Link href="/super/subscriptions">
                        <Button className="text-xs h-9 px-4 font-bold rounded-sm gap-1.5 shadow-md shadow-primary/20">
                          <CreditCard className="w-3.5 h-3.5" /> Open Subscription Plans Manager
                        </Button>
                      </Link>
                      <a
                        href="/pricing"
                        target="_blank"
                        rel="noreferrer"
                        className="text-xs h-9 px-4 border border-border bg-secondary/50 hover:bg-secondary text-foreground rounded-sm font-bold flex items-center gap-1.5"
                      >
                        <Eye className="w-3.5 h-3.5 text-primary" /> View Live /pricing Page
                      </a>
                    </div>
                  </Card>
                </div>
              )}

              {/* --------------------------------------------------------------------- */}
              {/* PAGE 5: POSTS / CHANGELOG                                             */}
              {/* --------------------------------------------------------------------- */}
              {selectedPageKey === "posts" && (
                <div className="space-y-4 max-w-4xl">
                  <div className="flex justify-between items-center">
                    <p className="text-xs text-muted-foreground">
                      Product changelog, releases, and roadmap announcements.
                    </p>
                    <Button
                      onClick={() => {
                        setEditingPost({
                          title: "",
                          slug: `release-${Date.now()}`,
                          excerpt: "",
                          content: "",
                          versionTag: "v2.5.0",
                          category: "Changelog",
                          isPublished: true,
                        });
                        setIsPostModalOpen(true);
                      }}
                      className="text-xs h-8 font-bold rounded-sm flex items-center gap-1.5"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add Changelog Post
                    </Button>
                  </div>

                  <div className="space-y-3">
                    {posts.map((post) => (
                      <Card
                        key={post.id}
                        className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-4 flex items-center justify-between gap-4"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-[9px] font-mono bg-primary/10 text-primary px-2 py-0.5 rounded-sm font-bold border border-primary/20">
                              {post.versionTag || post.category}
                            </span>
                            <span className="text-[10px] text-muted-foreground font-mono">
                              /{post.slug}
                            </span>
                          </div>
                          <h4 className="text-sm font-bold text-foreground">{post.title}</h4>
                          <p className="text-xs text-muted-foreground line-clamp-1">{post.excerpt}</p>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setEditingPost(post);
                              setIsPostModalOpen(true);
                            }}
                            className="text-xs h-7 px-2.5 rounded-sm"
                          >
                            <Edit2 className="w-3 h-3 text-primary mr-1" /> Edit
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => post.id && handleDeletePost(post.id)}
                            className="text-xs h-7 px-2.5 rounded-sm hover:bg-rose-500/10 hover:text-rose-400"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {/* --------------------------------------------------------------------- */}
              {/* PAGE 6: LEGAL & CUSTOM MARKDOWN PAGES (Privacy, Refund, Terms, etc.)  */}
              {/* --------------------------------------------------------------------- */}
              {selectedPageKey &&
                !["home", "about", "contact", "pricing", "posts"].includes(selectedPageKey) && (
                  <div className="max-w-4xl space-y-4">
                    {(() => {
                      const currentPageObj = pages.find((p) => p.slug === selectedPageKey) || {
                        slug: selectedPageKey,
                        title: `${selectedPageKey.toUpperCase()} Page`,
                        metaDescription: "Legal policy or custom content page.",
                        content: `# ${selectedPageKey.toUpperCase()}\n\nContent for this page...`,
                        isPublished: true,
                      };

                      return (
                        <form
                          onSubmit={async (e) => {
                            e.preventDefault();
                            setIsSaving(true);
                            try {
                              if (currentPageObj.id) {
                                await cmsService.updatePage(currentPageObj.id, currentPageObj);
                              } else {
                                await cmsService.createPage(currentPageObj);
                              }
                              const data = await cmsService.getAllPages();
                              setPages(data);
                              showSuccessFeedback(`${currentPageObj.title} saved live!`);
                            } catch (err: any) {
                              setErrorMessage(err.message || "Failed to save page");
                            } finally {
                              setIsSaving(false);
                            }
                          }}
                          className="space-y-4"
                        >
                          <Card className="bg-card/40 backdrop-blur-md border-border/70 rounded-sm">
                            <CardContent className="p-6 space-y-4">
                              <div className="flex items-center justify-between border-b border-border pb-2">
                                <div>
                                  <h3 className="text-sm font-bold text-foreground font-mono flex items-center gap-2">
                                    <FileText className="w-4 h-4 text-primary" /> {currentPageObj.title}
                                  </h3>
                                  <p className="text-xs text-muted-foreground mt-0.5">
                                    Live Route: <span className="font-mono text-primary font-bold">/{currentPageObj.slug}</span>
                                  </p>
                                </div>
                                <label className="flex items-center gap-2 text-xs cursor-pointer">
                                  <input
                                    type="checkbox"
                                    checked={currentPageObj.isPublished ?? true}
                                    onChange={(e) => {
                                      const updated = { ...currentPageObj, isPublished: e.target.checked };
                                      setPages(pages.map((p) => (p.slug === selectedPageKey ? updated : p)));
                                    }}
                                    className="w-4 h-4 accent-primary rounded"
                                  />
                                  <span className="font-mono text-muted-foreground font-bold">Published Live</span>
                                </label>
                              </div>

                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                <div className="space-y-1">
                                  <label className="text-xs font-bold text-muted-foreground font-mono">Page Title *</label>
                                  <Input
                                    required
                                    value={currentPageObj.title}
                                    onChange={(e) => {
                                      const updated = { ...currentPageObj, title: e.target.value };
                                      setPages(pages.map((p) => (p.slug === selectedPageKey ? updated : p)));
                                    }}
                                    className="h-9 text-xs font-bold rounded-sm"
                                  />
                                </div>
                                <div className="space-y-1">
                                  <label className="text-xs font-bold text-muted-foreground font-mono">Route Slug *</label>
                                  <Input
                                    required
                                    disabled={standardSlugs.includes(currentPageObj.slug)}
                                    value={currentPageObj.slug}
                                    onChange={(e) => {
                                      const updated = { ...currentPageObj, slug: e.target.value };
                                      setPages(pages.map((p) => (p.slug === selectedPageKey ? updated : p)));
                                    }}
                                    className="h-9 text-xs font-mono rounded-sm"
                                  />
                                </div>
                              </div>

                              <div className="space-y-1">
                                <label className="text-xs font-bold text-muted-foreground font-mono">Meta Description (SEO)</label>
                                <Input
                                  value={currentPageObj.metaDescription || ""}
                                  onChange={(e) => {
                                    const updated = { ...currentPageObj, metaDescription: e.target.value };
                                    setPages(pages.map((p) => (p.slug === selectedPageKey ? updated : p)));
                                  }}
                                  className="h-9 text-xs rounded-sm"
                                  placeholder="Summary of page for search engines"
                                />
                              </div>

                              <div className="space-y-1">
                                <div className="flex items-center justify-between">
                                  <label className="text-xs font-bold text-muted-foreground font-mono">
                                    Page Markdown Body *
                                  </label>
                                  <span className="text-[10px] text-muted-foreground font-mono">Supports GitHub Markdown & HTML</span>
                                </div>
                                <textarea
                                  required
                                  rows={14}
                                  value={currentPageObj.content}
                                  onChange={(e) => {
                                    const updated = { ...currentPageObj, content: e.target.value };
                                    setPages(pages.map((p) => (p.slug === selectedPageKey ? updated : p)));
                                  }}
                                  className="w-full p-3 font-mono text-xs rounded-sm bg-secondary/40 border border-border text-foreground leading-relaxed focus:ring-1 focus:ring-primary outline-none"
                                />
                              </div>

                              <div className="pt-4 flex justify-between items-center border-t border-border">
                                {currentPageObj.id && !standardSlugs.includes(currentPageObj.slug) ? (
                                  <Button
                                    type="button"
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handleDeletePage(currentPageObj.id!)}
                                    className="text-xs h-8 rounded-sm hover:bg-rose-500/10 hover:text-rose-400 border-border"
                                  >
                                    <Trash2 className="w-3.5 h-3.5 mr-1" /> Delete Page
                                  </Button>
                                ) : <div />}

                                <Button
                                  type="submit"
                                  disabled={isSaving}
                                  className="text-xs h-9 px-5 font-bold rounded-sm shadow-md shadow-primary/20 flex items-center gap-1.5"
                                >
                                  {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                                  Save & Publish Page
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        </form>
                      );
                    })()}
                  </div>
                )}
            </div>
          )}
        </main>
      </div>

      {/* ========================================================================= */}
      {/* MODALS: SPOTLIGHT / FEATURE / FAQ / TESTIMONIAL / POST / PAGE              */}
      {/* ========================================================================= */}

      {/* ERP Module Showcase Modal */}
      {isSpotlightModalOpen && editingSpotlight && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="max-w-xl w-full bg-card border border-border/80 rounded-sm p-5 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-border pb-2">
              <h3 className="text-sm font-bold text-foreground font-mono flex items-center gap-1.5">
                <Monitor className="w-4 h-4 text-primary" /> {editingSpotlight.id ? "Edit ERP Module Showcase" : "New ERP Module Showcase"}
              </h3>
              <button
                onClick={() => setIsSpotlightModalOpen(false)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveSpotlight} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-muted-foreground font-mono">Tab Key (Identifier) *</label>
                  <Input
                    required
                    value={editingSpotlight.tabKey}
                    onChange={(e) => setEditingSpotlight({ ...editingSpotlight, tabKey: e.target.value })}
                    className="h-8 text-xs font-mono rounded-sm"
                    placeholder="pos, imei, branch, finance"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-muted-foreground font-mono">Tab Button Label *</label>
                  <Input
                    required
                    value={editingSpotlight.tabLabel}
                    onChange={(e) => setEditingSpotlight({ ...editingSpotlight, tabLabel: e.target.value })}
                    className="h-8 text-xs font-bold rounded-sm"
                    placeholder="e.g. Point of Sale (POS)"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-muted-foreground font-mono">Headline Title *</label>
                <Input
                  required
                  value={editingSpotlight.title}
                  onChange={(e) => setEditingSpotlight({ ...editingSpotlight, title: e.target.value })}
                  className="h-8 text-xs font-bold rounded-sm"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-muted-foreground font-mono">Subtitle Description *</label>
                <textarea
                  required
                  rows={2}
                  value={editingSpotlight.subtitle}
                  onChange={(e) => setEditingSpotlight({ ...editingSpotlight, subtitle: e.target.value })}
                  className="w-full p-2 text-xs rounded-sm bg-secondary/40 border border-border text-foreground"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-muted-foreground font-mono">Badge Tag</label>
                  <Input
                    value={editingSpotlight.badge || ""}
                    onChange={(e) => setEditingSpotlight({ ...editingSpotlight, badge: e.target.value })}
                    className="h-8 text-xs rounded-sm"
                    placeholder="RETAIL & STORE CHECKOUT"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-muted-foreground font-mono">Showcase Image URL *</label>
                  <Input
                    required
                    value={editingSpotlight.imageUrl}
                    onChange={(e) => setEditingSpotlight({ ...editingSpotlight, imageUrl: e.target.value })}
                    className="h-8 text-xs font-mono rounded-sm"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-muted-foreground font-mono">Bullet Points JSON Array *</label>
                  <span className="text-[10px] text-muted-foreground font-mono">[&#123;&quot;icon&quot;:&quot;...&quot;,&quot;title&quot;:&quot;...&quot;,&quot;description&quot;:&quot;...&quot;&#125;]</span>
                </div>
                <textarea
                  required
                  rows={4}
                  value={editingSpotlight.bulletPointsJson}
                  onChange={(e) => setEditingSpotlight({ ...editingSpotlight, bulletPointsJson: e.target.value })}
                  className="w-full p-2 font-mono text-[11px] rounded-sm bg-secondary/40 border border-border text-foreground"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-border">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsSpotlightModalOpen(false)}
                  className="text-xs h-8 rounded-sm"
                >
                  Cancel
                </Button>
                <Button type="submit" size="sm" className="text-xs h-8 font-bold rounded-sm">
                  Save ERP Module Tab
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Feature Modal */}
      {isFeatureModalOpen && editingFeature && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="max-w-md w-full bg-card border border-border/80 rounded-sm p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-border pb-2">
              <h3 className="text-sm font-bold text-foreground font-mono">
                {editingFeature.id ? "Edit Feature Card" : "New Feature Card"}
              </h3>
              <button
                onClick={() => setIsFeatureModalOpen(false)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveFeature} className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-muted-foreground font-mono">Feature Title *</label>
                <Input
                  required
                  value={editingFeature.title}
                  onChange={(e) => setEditingFeature({ ...editingFeature, title: e.target.value })}
                  className="h-8 text-xs rounded-sm"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-muted-foreground font-mono">Description *</label>
                <textarea
                  required
                  rows={3}
                  value={editingFeature.description}
                  onChange={(e) => setEditingFeature({ ...editingFeature, description: e.target.value })}
                  className="w-full p-2 text-xs rounded-sm bg-secondary/40 border border-border text-foreground"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-muted-foreground font-mono">Category</label>
                  <Input
                    value={editingFeature.category || ""}
                    onChange={(e) => setEditingFeature({ ...editingFeature, category: e.target.value })}
                    className="h-8 text-xs rounded-sm"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-muted-foreground font-mono">Badge</label>
                  <Input
                    value={editingFeature.badge || ""}
                    onChange={(e) => setEditingFeature({ ...editingFeature, badge: e.target.value })}
                    className="h-8 text-xs rounded-sm"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-border">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsFeatureModalOpen(false)}
                  className="text-xs h-8 rounded-sm"
                >
                  Cancel
                </Button>
                <Button type="submit" size="sm" className="text-xs h-8 font-bold rounded-sm">
                  Save Card
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* FAQ Modal */}
      {isFaqModalOpen && editingFaq && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="max-w-md w-full bg-card border border-border/80 rounded-sm p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-border pb-2">
              <h3 className="text-sm font-bold text-foreground font-mono">
                {editingFaq.id ? "Edit FAQ Item" : "New FAQ Item"}
              </h3>
              <button
                onClick={() => setIsFaqModalOpen(false)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveFaq} className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-muted-foreground font-mono">Question *</label>
                <Input
                  required
                  value={editingFaq.question}
                  onChange={(e) => setEditingFaq({ ...editingFaq, question: e.target.value })}
                  className="h-8 text-xs rounded-sm"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-muted-foreground font-mono">Answer *</label>
                <textarea
                  required
                  rows={4}
                  value={editingFaq.answer}
                  onChange={(e) => setEditingFaq({ ...editingFaq, answer: e.target.value })}
                  className="w-full p-2 text-xs rounded-sm bg-secondary/40 border border-border text-foreground"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-muted-foreground font-mono">Category</label>
                <Input
                  value={editingFaq.category || ""}
                  onChange={(e) => setEditingFaq({ ...editingFaq, category: e.target.value })}
                  className="h-8 text-xs rounded-sm"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-border">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsFaqModalOpen(false)}
                  className="text-xs h-8 rounded-sm"
                >
                  Cancel
                </Button>
                <Button type="submit" size="sm" className="text-xs h-8 font-bold rounded-sm">
                  Save FAQ
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Testimonial Modal */}
      {isTestimonialModalOpen && editingTestimonial && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="max-w-md w-full bg-card border border-border/80 rounded-sm p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-border pb-2">
              <h3 className="text-sm font-bold text-foreground font-mono">
                {editingTestimonial.id ? "Edit Review" : "New Review"}
              </h3>
              <button
                onClick={() => setIsTestimonialModalOpen(false)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveTestimonial} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-muted-foreground font-mono">Client Name *</label>
                  <Input
                    required
                    value={editingTestimonial.clientName}
                    onChange={(e) => setEditingTestimonial({ ...editingTestimonial, clientName: e.target.value })}
                    className="h-8 text-xs rounded-sm"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-muted-foreground font-mono">Business Name *</label>
                  <Input
                    required
                    value={editingTestimonial.businessName}
                    onChange={(e) => setEditingTestimonial({ ...editingTestimonial, businessName: e.target.value })}
                    className="h-8 text-xs rounded-sm"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-muted-foreground font-mono">Review Text *</label>
                <textarea
                  required
                  rows={3}
                  value={editingTestimonial.content}
                  onChange={(e) => setEditingTestimonial({ ...editingTestimonial, content: e.target.value })}
                  className="w-full p-2 text-xs rounded-sm bg-secondary/40 border border-border text-foreground"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-border">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsTestimonialModalOpen(false)}
                  className="text-xs h-8 rounded-sm"
                >
                  Cancel
                </Button>
                <Button type="submit" size="sm" className="text-xs h-8 font-bold rounded-sm">
                  Save Review
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Post Modal */}
      {isPostModalOpen && editingPost && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="max-w-lg w-full bg-card border border-border/80 rounded-sm p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-border pb-2">
              <h3 className="text-sm font-bold text-foreground font-mono">
                {editingPost.id ? "Edit Post" : "New Post"}
              </h3>
              <button
                onClick={() => setIsPostModalOpen(false)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSavePost} className="space-y-3 text-xs">
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2 space-y-1">
                  <label className="font-bold text-muted-foreground font-mono">Title *</label>
                  <Input
                    required
                    value={editingPost.title}
                    onChange={(e) =>
                      setEditingPost({
                        ...editingPost,
                        title: e.target.value,
                        slug: e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
                      })
                    }
                    className="h-8 text-xs rounded-sm"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-muted-foreground font-mono">Version Tag</label>
                  <Input
                    value={editingPost.versionTag || ""}
                    onChange={(e) => setEditingPost({ ...editingPost, versionTag: e.target.value })}
                    className="h-8 text-xs font-mono rounded-sm"
                    placeholder="v2.5.0"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-muted-foreground font-mono">Excerpt</label>
                <Input
                  value={editingPost.excerpt || ""}
                  onChange={(e) => setEditingPost({ ...editingPost, excerpt: e.target.value })}
                  className="h-8 text-xs rounded-sm"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-muted-foreground font-mono">Content (Markdown) *</label>
                <textarea
                  required
                  rows={6}
                  value={editingPost.content}
                  onChange={(e) => setEditingPost({ ...editingPost, content: e.target.value })}
                  className="w-full p-2.5 font-mono text-xs rounded-sm bg-secondary/40 border border-border text-foreground"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-border">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsPostModalOpen(false)}
                  className="text-xs h-8 rounded-sm"
                >
                  Cancel
                </Button>
                <Button type="submit" size="sm" className="text-xs h-8 font-bold rounded-sm">
                  Save Post
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Create Custom Page Modal */}
      {isPageModalOpen && editingPage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="max-w-lg w-full bg-card border border-border/80 rounded-sm p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-border pb-2">
              <h3 className="text-sm font-bold text-foreground font-mono">
                {editingPage.id ? "Edit Custom Page" : "Create New Custom Page"}
              </h3>
              <button
                onClick={() => setIsPageModalOpen(false)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSavePage} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-muted-foreground font-mono">Page Title *</label>
                  <Input
                    required
                    value={editingPage.title}
                    onChange={(e) =>
                      setEditingPage({
                        ...editingPage,
                        title: e.target.value,
                        slug: editingPage.id ? editingPage.slug : e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
                      })
                    }
                    className="h-8 text-xs font-bold rounded-sm"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-muted-foreground font-mono">Slug Route *</label>
                  <Input
                    required
                    value={editingPage.slug}
                    onChange={(e) => setEditingPage({ ...editingPage, slug: e.target.value })}
                    className="h-8 text-xs font-mono rounded-sm"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-muted-foreground font-mono">Meta Description</label>
                <Input
                  value={editingPage.metaDescription || ""}
                  onChange={(e) => setEditingPage({ ...editingPage, metaDescription: e.target.value })}
                  className="h-8 text-xs rounded-sm"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-muted-foreground font-mono">Markdown Content *</label>
                <textarea
                  required
                  rows={8}
                  value={editingPage.content}
                  onChange={(e) => setEditingPage({ ...editingPage, content: e.target.value })}
                  className="w-full p-2.5 font-mono text-xs rounded-sm bg-secondary/40 border border-border text-foreground"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-border">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsPageModalOpen(false)}
                  className="text-xs h-8 rounded-sm"
                >
                  Cancel
                </Button>
                <Button type="submit" size="sm" className="text-xs h-8 font-bold rounded-sm">
                  Publish Custom Page
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
