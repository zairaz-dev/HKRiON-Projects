import { Module } from '@nestjs/common';
import { SalesPurchasesController } from './sales-purchases.controller';
import { SalesPurchasesService } from './sales-purchases.service';
import { PrismaModule } from '../../prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [SalesPurchasesController],
  providers: [SalesPurchasesService],
  exports: [SalesPurchasesService],
})
export class SalesPurchasesModule {}
