export const AUTH_CONSTANTS = {
  SESSION_COOKIE_NAME: "shadeit_auth_session",
  USER_STORAGE_KEY: "shadeit_user",
  JWT_SECRET: process.env.JWT_SECRET || "shadeit-blinds-super-secret-jwt-key-2026",
  SESSION_MAX_AGE_SECONDS: 60 * 60 * 24 * 7, // 7 days
  DEFAULT_ADMIN_EMAIL: "admin@shadeitblinds.com",
  ROLES: {
    ADMIN: "ADMIN",
    CUSTOMER: "CUSTOMER",
  },
} as const;
