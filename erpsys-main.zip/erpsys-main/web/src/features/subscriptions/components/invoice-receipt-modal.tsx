"use strict";
"use client";

import React from 'react';
import { SubscriptionInvoice } from '../types';
import { Button } from '@/components/ui/button';
import { getFullAssetUrl } from '@/lib/utils';
import { X, Printer, CheckCircle, Clock, XCircle, ShieldCheck } from 'lucide-react';

interface InvoiceReceiptModalProps {
  invoice: SubscriptionInvoice | null;
  businessName?: string;
  planName?: string;
  isOpen: boolean;
  onClose: () => void;
}

export function InvoiceReceiptModal({
  invoice,
  businessName = 'Your Business',
  planName = 'SaaS Plan',
  isOpen,
  onClose,
}: InvoiceReceiptModalProps) {
  if (!isOpen || !invoice) return null;

  const handlePrint = () => {
    window.print();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'PAID':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            <CheckCircle className="w-3.5 h-3.5" /> PAID
          </span>
        );
      case 'PENDING':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <Clock className="w-3.5 h-3.5" /> PENDING VERIFICATION
          </span>
        );
      case 'FAILED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30">
            <XCircle className="w-3.5 h-3.5" /> REJECTED / FAILED
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded text-xs bg-secondary text-foreground">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-2xl bg-card border border-border rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[95vh]">
        {/* Modal Top Bar (Hidden on print) */}
        <div className="flex items-center justify-between px-6 py-3.5 border-b border-border bg-background/50 print:hidden">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-muted-foreground uppercase font-mono tracking-wider">
              TAX INVOICE RECEIPT
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handlePrint}
              className="text-xs h-8 flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" /> Print / Save PDF
            </Button>
            <button
              onClick={onClose}
              className="text-muted-foreground hover:text-foreground transition-colors p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Body */}
        <div className="p-8 overflow-y-auto space-y-6 bg-card text-foreground font-sans print:p-0 print:bg-white print:text-black">
          {/* Company & Invoice Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start border-b border-border pb-6 gap-4">
            <div>
              <div className="text-2xl font-black tracking-tight text-primary font-mono">
                HKRION ERP
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">
                HKRION SYSTEMS (PVT) LTD
              </p>
              <p className="text-xs text-muted-foreground">
                Colombo, Sri Lanka | support@hkrion.com
              </p>
            </div>
            <div className="sm:text-right space-y-1">
              <div className="text-sm font-extrabold font-mono text-foreground">
                {invoice.invoiceNumber}
              </div>
              <div className="text-xs text-muted-foreground">
                Date: {new Date(invoice.createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
              </div>
              <div className="pt-1">
                {getStatusBadge(invoice.paymentStatus)}
              </div>
            </div>
          </div>

          {/* Bill To Info */}
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div className="space-y-1">
              <span className="font-bold text-muted-foreground uppercase tracking-wider font-mono text-[10px]">
                BILLED TO:
              </span>
              <div className="text-sm font-bold text-foreground">{businessName}</div>
              <div className="text-muted-foreground">Subscription Account</div>
            </div>
            <div className="space-y-1 sm:text-right">
              <span className="font-bold text-muted-foreground uppercase tracking-wider font-mono text-[10px]">
                PAYMENT DETAILS:
              </span>
              <div className="font-medium text-foreground">
                Method: {invoice.paymentMethod || 'Bank Transfer'}
              </div>
              <div className="font-mono text-muted-foreground text-[11px]">
                Ref / Trans ID: {invoice.transactionId || 'N/A'}
              </div>
              {invoice.paidAt && (
                <div className="text-emerald-500 font-medium text-[11px]">
                  Paid on: {new Date(invoice.paidAt).toLocaleDateString()}
                </div>
              )}
            </div>
          </div>

          {/* Invoice Line Items Table */}
          {(() => {
            const symbol = invoice.currency === 'USD' ? '$' : 'Rs.';
            const currencyCode = invoice.currency === 'USD' ? 'USD' : 'LKR';
            return (
              <>
                <div className="border border-border rounded-lg overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-secondary/60 text-muted-foreground font-mono text-[11px] uppercase">
                      <tr>
                        <th className="py-2.5 px-4">Item Description</th>
                        <th className="py-2.5 px-4 text-right">Tax (18%)</th>
                        <th className="py-2.5 px-4 text-right">Amount ({currencyCode})</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border font-sans">
                      <tr>
                        <td className="py-3.5 px-4">
                          <div className="font-bold text-foreground">{planName} Subscription</div>
                          <div className="text-muted-foreground text-[11px]">
                            {invoice.notes || 'HKRION ERP Cloud Access & Service Plan'}
                          </div>
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono text-muted-foreground">
                          {symbol} {invoice.taxAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono font-bold text-foreground">
                          {symbol} {invoice.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* Breakdown Totals */}
                <div className="flex justify-end pt-2">
                  <div className="w-64 space-y-2 text-xs">
                    <div className="flex justify-between text-muted-foreground">
                      <span>Subtotal:</span>
                      <span className="font-mono text-foreground">
                        {symbol} {invoice.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>Taxes & GST (18%):</span>
                      <span className="font-mono text-foreground">
                        {symbol} {invoice.taxAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                    <div className="border-t border-border pt-2 flex justify-between text-sm font-extrabold text-foreground">
                      <span>Total Amount:</span>
                      <span className="font-mono text-primary text-base">
                        {symbol} {invoice.totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>
                </div>
              </>
            );
          })()}

          {/* Admin / Rejection Notes if any */}
          {invoice.adminNotes && (
            <div className="bg-secondary/40 border border-border p-3 rounded-lg text-xs space-y-1">
              <span className="font-bold text-muted-foreground uppercase text-[10px] font-mono">
                Verification Remarks:
              </span>
              <p className="text-foreground">{invoice.adminNotes}</p>
            </div>
          )}

          {/* Proof attachment link if available */}
          {invoice.proofUrl && (
            <div className="bg-background/80 border border-border p-3 rounded-lg text-xs flex items-center justify-between">
              <span className="text-muted-foreground font-mono">Uploaded Deposit Slip:</span>
              <a
                href={getFullAssetUrl(invoice.proofUrl) || invoice.proofUrl}
                target="_blank"
                rel="noreferrer"
                className="text-primary hover:underline font-bold"
              >
                View Attachment ↗
              </a>
            </div>
          )}

          {/* Footer note */}
          <div className="border-t border-border pt-4 text-center text-[10px] text-muted-foreground flex items-center justify-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>This is an electronically generated tax invoice receipt by HKRION ERP.</span>
          </div>
        </div>
      </div>
    </div>
  );
}
