"use client";

import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  Monitor,
  Cpu,
  Power,
  RotateCw,
  Printer,
  Sparkles,
  Barcode,
  Keyboard,
  ArrowLeft,
  Volume2,
  VolumeX,
  ShoppingCart,
  Clock,
  Wifi,
  Package,
  TrendingUp,
  Percent,
  CheckCircle,
  Undo
} from "lucide-react";
import Link from "next/link";

interface Product {
  id: string;
  name: string;
  sku: string;
  price: number;
  category: string;
}

const DEMO_PRODUCTS: Product[] = [
  { id: "1", name: "IHM Fusion Pro Laptop", sku: "FUS-8890", price: 145000, category: "Hardware" },
  { id: "2", name: "HoloBeam QR Scanner 5G", sku: "HOL-5520", price: 28000, category: "Peripherals" },
  { id: "3", name: "Thermal Jet Printer Max", sku: "THR-1080", price: 18500, category: "Peripherals" },
  { id: "4", name: "IHM Smart Keyboard Air", sku: "KBD-9040", price: 12500, category: "Accessories" },
  { id: "5", name: "Quantum POS Hub Core", sku: "QNT-3030", price: 220000, category: "Systems" }
];

export default function POSShowcasePage() {
  // Sound controls
  const [soundEnabled, setSoundEnabled] = useState(true);

  // POS State
  const [isPowerOn, setIsPowerOn] = useState(true);
  const [ledColor, setLedColor] = useState<"blue" | "green" | "amber">("blue");
  const [isScanning, setIsScanning] = useState(false);
  const [isPrinting, setIsPrinting] = useState(false);
  const [receiptPrinted, setReceiptPrinted] = useState(false);
  
  // Custom rotation angles for the 3D terminal stage
  const [rotX, setRotX] = useState(12);
  const [rotY, setRotY] = useState(-10);

  // Cart State (displayed inside screen)
  const [cart, setCart] = useState<Array<{ product: Product; qty: number }>>([
    { product: DEMO_PRODUCTS[0], qty: 1 },
    { product: DEMO_PRODUCTS[3], qty: 2 }
  ]);

  const [activeTab, setActiveTab] = useState<"sales" | "inventory" | "terminal">("sales");
  const [scannedMessage, setScannedMessage] = useState<string | null>(null);

  // Refs for audio context
  const audioCtxRef = useRef<AudioContext | null>(null);

  // Date and Time state for terminal topbar
  const [currentTime, setCurrentTime] = useState("");
  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      setCurrentTime(d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Web Audio Synth sounds
  const playSynthBeep = (freq = 1200, duration = 0.08, type: OscillatorType = "sine") => {
    if (!soundEnabled) return;
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === "suspended") {
        ctx.resume();
      }
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.04, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      console.warn("Audio error: ", e);
    }
  };

  // Printing mechanical buzzer hum sound
  const playPrintingSound = () => {
    if (!soundEnabled) return;
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === "suspended") {
        ctx.resume();
      }
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc1.type = "sawtooth";
      osc1.frequency.setValueAtTime(95, ctx.currentTime);

      osc2.type = "triangle";
      osc2.frequency.setValueAtTime(220, ctx.currentTime);

      gain.gain.setValueAtTime(0.02, ctx.currentTime);

      // simulate printer stepper movements by fluctuating frequency
      const printDuration = 1.6;
      for (let timeOffset = 0; timeOffset < printDuration; timeOffset += 0.12) {
        osc1.frequency.setValueAtTime(80 + Math.random() * 40, ctx.currentTime + timeOffset);
        osc2.frequency.setValueAtTime(200 + Math.random() * 60, ctx.currentTime + timeOffset);
      }

      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + printDuration);
      
      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      osc1.start();
      osc2.start();
      osc1.stop(ctx.currentTime + printDuration);
      osc2.stop(ctx.currentTime + printDuration);
    } catch (e) {
      console.warn("Audio error: ", e);
    }
  };

  // Computations
  const subtotal = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.product.price * item.qty, 0);
  }, [cart]);

  const discount = subtotal > 100000 ? subtotal * 0.1 : 0;
  const grandTotal = subtotal - discount;

  // Scanner sweep simulation
  const handleTriggerScan = (productToScan?: Product) => {
    if (!isPowerOn || isScanning) return;
    
    setIsScanning(true);
    playSynthBeep(900, 0.05, "triangle");
    
    setTimeout(() => {
      // Choose random product if none specified
      const p = productToScan || DEMO_PRODUCTS[Math.floor(Math.random() * DEMO_PRODUCTS.length)];
      
      // Update cart
      setCart(current => {
        const idx = current.findIndex(item => item.product.id === p.id);
        if (idx > -1) {
          const updated = [...current];
          updated[idx].qty += 1;
          return updated;
        } else {
          return [...current, { product: p, qty: 1 }];
        }
      });
      
      setIsScanning(false);
      setScannedMessage(`Scanned: ${p.name}`);
      playSynthBeep(1800, 0.15, "sine"); // successful barcode beep sound

      setTimeout(() => setScannedMessage(null), 3000);
    }, 1200); // 1.2s laser sweep time
  };

  // Printer trigger
  const handlePrintReceipt = () => {
    if (!isPowerOn || isPrinting) return;
    setIsPrinting(true);
    setReceiptPrinted(false);
    playPrintingSound();

    setTimeout(() => {
      setIsPrinting(false);
      setReceiptPrinted(true);
      playSynthBeep(1500, 0.1, "sine");
    }, 1800); // printer outputs receipt in 1.8s
  };

  // Clear Cart
  const handleClearCart = () => {
    setCart([]);
    playSynthBeep(600, 0.12, "sine");
  };

  // Keyboard Ripple Effect Simulation
  const [activeKeyIndex, setActiveKeyIndex] = useState<number | null>(null);
  useEffect(() => {
    if (!isPowerOn) return;
    // auto lights wave animation in background for futuristic keyboard
    const interval = setInterval(() => {
      setActiveKeyIndex(Math.floor(Math.random() * 24));
      setTimeout(() => setActiveKeyIndex(null), 300);
    }, 1500);
    return () => clearInterval(interval);
  }, [isPowerOn]);

  return (
    <div className="min-h-screen bg-[#070709] text-white flex flex-col items-center justify-between p-4 overflow-x-hidden font-sans selection:bg-blue-500/30 selection:text-blue-200">
      
      {/* CSS Animation Variables Declarations */}
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        @keyframes laser-sweep {
          0%, 100% { top: 0%; opacity: 0.1; }
          50% { top: 100%; opacity: 0.9; }
        }
        @keyframes receipt-feed {
          0% { height: 0px; opacity: 0; transform: translateY(-10px) rotateX(15deg); }
          100% { height: 160px; opacity: 1; transform: translateY(0px) rotateX(0deg); }
        }
        @keyframes ledPulse {
          0%, 100% { opacity: 0.65; }
          50% { opacity: 0.95; }
        }
        .anim-float {
          animation: float 6s ease-in-out infinite;
        }
        .laser-line {
          animation: laser-sweep 1.2s ease-in-out infinite;
        }
        .receipt-paper {
          animation: receipt-feed 1.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
          transform-origin: top center;
        }
        .led-pulse {
          animation: ledPulse 2s ease-in-out infinite;
        }
        .glass-dark {
          background: rgba(13, 13, 17, 0.7);
          backdrop-filter: blur(12px);
          border: 1px solid rgba(255, 255, 255, 0.05);
        }
        .screen-glare {
          background: linear-gradient(135deg, rgba(255,255,255,0.06) 0%, rgba(255,255,255,0) 60%);
        }
      `}</style>

      {/* TOP HEADER */}
      <header className="w-full max-w-7xl flex flex-col md:flex-row md:items-center justify-between gap-4 py-4 px-6 border-b border-white/5 relative z-20">
        <div className="flex items-center gap-3">
          <Link href="/preview">
            <button className="h-9 w-9 rounded-lg glass-dark flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/5 transition-all">
              <ArrowLeft className="h-4 w-4" />
            </button>
          </Link>
          <div>
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-blue-500 animate-pulse" />
              <h1 className="text-md font-black tracking-widest text-white uppercase font-mono">
                IHM TECH LABS
              </h1>
            </div>
            <p className="text-[10px] text-slate-500 uppercase tracking-widest font-mono mt-0.5">
              Premium Hardware Interactive Showcase
            </p>
          </div>
        </div>

        {/* Global Controls */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`h-9 px-3.5 rounded-lg flex items-center gap-2 text-xs font-mono border transition-all ${
              soundEnabled
                ? "bg-blue-500/10 border-blue-500/30 text-blue-400"
                : "bg-white/5 border-white/5 text-slate-400 hover:text-white"
            }`}
          >
            {soundEnabled ? <Volume2 className="h-3.5 w-3.5" /> : <VolumeX className="h-3.5 w-3.5" />}
            <span>AUDIO: {soundEnabled ? "SYNTH ON" : "MUTED"}</span>
          </button>

          <button
            onClick={() => {
              setIsPowerOn(!isPowerOn);
              playSynthBeep(isPowerOn ? 400 : 1000, 0.25, "square");
            }}
            className={`h-9 px-4 rounded-lg flex items-center gap-2 text-xs font-mono font-bold transition-all ${
              isPowerOn
                ? "bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20"
                : "bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20"
            }`}
          >
            <Power className="h-3.5 w-3.5" />
            <span>TERMINAL: {isPowerOn ? "SHUTDOWN" : "BOOT UP"}</span>
          </button>
        </div>
      </header>

      {/* MAIN LAYOUT */}
      <main className="w-full max-w-7xl grid grid-cols-1 lg:grid-cols-12 gap-8 my-auto py-8 px-4 items-center z-10">
        
        {/* LEFT COLUMN: INTERACTIVE 3D DISPLAY STAGE (8 COLS) */}
        <div className="lg:col-span-8 flex flex-col items-center justify-center relative min-h-[500px]">
          
          {/* BACKGROUND SHADOW & CINEMATIC GLOW */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full bg-blue-500/10 blur-[120px] pointer-events-none led-pulse" />
          
          {/* CAMERA RESET HELPER */}
          <div className="absolute top-0 right-4 z-20 flex gap-2">
            <button
              onClick={() => {
                setRotX(12);
                setRotY(-10);
                playSynthBeep(1000, 0.08, "sine");
              }}
              className="h-8 px-2.5 rounded glass-dark flex items-center gap-1.5 text-[10px] font-mono text-slate-400 hover:text-white hover:border-slate-700 transition"
              title="Reset 3D camera view"
            >
              <RotateCw className="h-3 w-3 animate-spin-hover" />
              Reset View
            </button>
          </div>

          {/* 3D PERSPECTIVE WRAPPER */}
          <div 
            className="w-full flex items-center justify-center p-4"
            style={{ perspective: "1500px" }}
          >
            {/* 3D STAGE CONTAINER */}
            <div
              className="relative transition-all duration-700 ease-out select-none animate-map-float"
              style={{
                transform: `rotateX(${rotX}deg) rotateY(${rotY}deg)`,
                transformStyle: "preserve-3d",
              }}
            >
              
              {/* === THE CORE TERMINAL BODY === */}
              {/* Stand base mount */}
              <div 
                className="absolute left-[30%] bottom-[-15px] w-[40%] h-[30px] rounded-lg shadow-2xl"
                style={{
                  background: "linear-gradient(to top, #09090b, #18181b)",
                  transform: "translateZ(-40px) rotateX(80deg)",
                  boxShadow: "0 25px 50px rgba(0,0,0,0.9)"
                }}
              />

              {/* Main POS Monitor Chassis Frame */}
              <div
                className={`relative w-[480px] h-[310px] rounded-xl bg-[#0e0e11] border-2 transition-all duration-500 flex flex-col p-3.5 shadow-[0_30px_70px_rgba(0,0,0,0.85)] ${
                  !isPowerOn
                    ? "border-slate-800"
                    : ledColor === "blue"
                    ? "border-blue-500/40 shadow-blue-500/5"
                    : ledColor === "green"
                    ? "border-emerald-500/40 shadow-emerald-500/5"
                    : "border-amber-500/40 shadow-amber-500/5"
                }`}
                style={{
                  transformStyle: "preserve-3d",
                }}
              >
                
                {/* GLOWING LED BEZEL EDGES */}
                <div 
                  className={`absolute inset-[-2px] rounded-xl pointer-events-none led-pulse ${
                    !isPowerOn
                      ? "opacity-0"
                      : ledColor === "blue"
                      ? "border border-blue-500 shadow-[0_0_18px_rgba(59,130,246,0.35)]"
                      : ledColor === "green"
                      ? "border border-emerald-500 shadow-[0_0_18px_rgba(34,197,94,0.35)]"
                      : "border border-amber-500 shadow-[0_0_18px_rgba(245,158,11,0.35)]"
                  }`} 
                />

                {/* === TOUCH SCREEN SCREEN CONTAINER === */}
                <div className={`relative flex-1 rounded-lg overflow-hidden flex flex-col transition-all duration-700 bg-black ${
                  !isPowerOn ? "brightness-[0.05] contrast-75" : ""
                }`}>
                  
                  {/* Glass reflection gradient layer */}
                  <div className="absolute inset-0 screen-glare pointer-events-none z-10" />

                  {/* SCREEN POWER ON CONTENT */}
                  {isPowerOn ? (
                    <div className="w-full h-full flex flex-col bg-[#0b0c10] text-[11px]">
                      
                      {/* SCREEN HEADER */}
                      <div className="h-8 bg-[#11131a] border-b border-white/5 flex items-center justify-between px-3 shrink-0">
                        <div className="flex items-center gap-1.5">
                          <Cpu className="h-3 w-3 text-blue-500" />
                          <span className="font-black tracking-widest text-[9px] uppercase font-mono text-white">
                            IHM OS v4.2
                          </span>
                        </div>

                        {/* TAB NAV */}
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => { setActiveTab("sales"); playSynthBeep(1200, 0.05); }}
                            className={`h-5 px-2 rounded-sm text-[9px] font-mono transition-all ${
                              activeTab === "sales" ? "bg-blue-500 text-white font-bold" : "text-slate-400 hover:text-slate-200"
                            }`}
                          >
                            BILLING
                          </button>
                          <button
                            onClick={() => { setActiveTab("inventory"); playSynthBeep(1200, 0.05); }}
                            className={`h-5 px-2 rounded-sm text-[9px] font-mono transition-all ${
                              activeTab === "inventory" ? "bg-blue-500 text-white font-bold" : "text-slate-400 hover:text-slate-200"
                            }`}
                          >
                            PRODUCT CATALOG
                          </button>
                        </div>

                        {/* Topbar widget */}
                        <div className="flex items-center gap-2 text-slate-400 font-mono text-[9px]">
                          <span className="text-blue-500 font-bold flex items-center gap-1">
                            <Wifi className="h-3 w-3" /> ONLINE
                          </span>
                          <span>|</span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" /> {currentTime || "12:00"}
                          </span>
                        </div>
                      </div>

                      {/* SCREEN BODY CONTENT */}
                      <div className="flex-1 flex overflow-hidden">
                        
                        {/* TAB 1: BILLING CART */}
                        {activeTab === "sales" && (
                          <div className="flex-1 flex overflow-hidden">
                            {/* Left Cart items list (65%) */}
                            <div className="w-[62%] border-r border-white/5 p-3 flex flex-col justify-between overflow-hidden">
                              <div className="flex items-center justify-between pb-1.5 border-b border-white/5 shrink-0">
                                <span className="font-bold uppercase tracking-wider text-slate-400 font-mono text-[9px]">
                                  Items In Cart ({cart.reduce((sum, i) => sum + i.qty, 0)})
                                </span>
                                <button
                                  onClick={handleClearCart}
                                  className="text-[9px] font-mono text-red-400 hover:underline"
                                  disabled={cart.length === 0}
                                >
                                  Clear Cart
                                </button>
                              </div>

                              {/* Cart Items list area */}
                              <div className="flex-1 overflow-y-auto py-2 space-y-1.5 scrollbar-thin">
                                {cart.length === 0 ? (
                                  <div className="h-full flex flex-col items-center justify-center text-slate-500/60 font-mono text-center">
                                    <ShoppingCart className="h-8 w-8 mb-1.5 opacity-30 text-blue-500 animate-pulse" />
                                    <span>CART IS EMPTY</span>
                                    <span className="text-[8px] mt-0.5 text-slate-600">Scan products using left panel or scanner</span>
                                  </div>
                                ) : (
                                  cart.map((item, idx) => (
                                    <div key={idx} className="flex items-center justify-between p-1.5 rounded bg-[#151720] border border-white/5">
                                      <div className="min-w-0 flex-1 pr-1.5">
                                        <span className="font-bold text-slate-200 block truncate">{item.product.name}</span>
                                        <span className="text-[8px] text-slate-500 font-mono block">SKU: {item.product.sku}</span>
                                      </div>
                                      
                                      <div className="flex items-center gap-1 px-1.5 shrink-0">
                                        <button 
                                          onClick={() => {
                                            setCart(c => {
                                              const updated = [...c];
                                              if (updated[idx].qty > 1) {
                                                updated[idx].qty -= 1;
                                              } else {
                                                updated.splice(idx, 1);
                                              }
                                              return updated;
                                            });
                                            playSynthBeep(800, 0.04);
                                          }}
                                          className="h-4 w-4 bg-[#202330] rounded flex items-center justify-center text-[10px] text-slate-400 hover:text-white font-bold"
                                        >
                                          -
                                        </button>
                                        <span className="w-5 text-center font-bold text-slate-300 font-mono">{item.qty}</span>
                                        <button 
                                          onClick={() => {
                                            setCart(c => {
                                              const updated = [...c];
                                              updated[idx].qty += 1;
                                              return updated;
                                            });
                                            playSynthBeep(1000, 0.04);
                                          }}
                                          className="h-4 w-4 bg-[#202330] rounded flex items-center justify-center text-[10px] text-slate-400 hover:text-white font-bold"
                                        >
                                          +
                                        </button>
                                      </div>

                                      <span className="w-16 text-right font-mono font-bold text-slate-200 shrink-0">
                                        ₹{(item.product.price * item.qty).toLocaleString("en-IN")}
                                      </span>
                                    </div>
                                  ))
                                )}
                              </div>

                              {/* Notification Bar inside screen */}
                              {scannedMessage && (
                                <div className="p-1 rounded bg-blue-500/10 border border-blue-500/30 text-blue-400 text-[9px] font-mono flex items-center gap-1.5 justify-center mt-1 animate-pulse">
                                  <Barcode className="h-3 w-3" />
                                  <span>{scannedMessage}</span>
                                </div>
                              )}
                            </div>

                            {/* Right summary calculations (38%) */}
                            <div className="w-[38%] bg-[#0e1017] p-3 flex flex-col justify-between">
                              <div className="space-y-2">
                                <span className="font-bold uppercase tracking-wider text-slate-400 font-mono text-[9px] block pb-1 border-b border-white/5">
                                  Summary Details
                                </span>
                                
                                <div className="space-y-1.5 font-mono text-[9.5px]">
                                  <div className="flex justify-between text-slate-400">
                                    <span>Subtotal:</span>
                                    <span>₹{subtotal.toLocaleString("en-IN")}</span>
                                  </div>
                                  {discount > 0 && (
                                    <div className="flex justify-between text-emerald-400">
                                      <span>Bulk Disc (10%):</span>
                                      <span>-₹{discount.toLocaleString("en-IN")}</span>
                                    </div>
                                  )}
                                  <div className="flex justify-between text-slate-400">
                                    <span>Tax (GST 18%):</span>
                                    <span>INCLUDED</span>
                                  </div>
                                </div>
                              </div>

                              <div className="space-y-2.5">
                                <div className="bg-[#151720] p-2 rounded border border-white/5 text-center">
                                  <span className="text-[8px] uppercase tracking-widest text-slate-500 font-mono block">
                                    Grand Total
                                  </span>
                                  <span className="text-sm font-black font-mono text-blue-400 mt-0.5 block">
                                    ₹{grandTotal.toLocaleString("en-IN")}
                                  </span>
                                </div>

                                <div className="grid grid-cols-2 gap-1.5">
                                  <button
                                    onClick={handlePrintReceipt}
                                    disabled={cart.length === 0 || isPrinting}
                                    className="h-8 rounded bg-[#1b1e2a] hover:bg-[#232738] border border-white/5 text-slate-300 font-bold transition flex items-center justify-center gap-1 text-[9px] disabled:opacity-50"
                                  >
                                    <Printer className="h-3 w-3" />
                                    PRINT
                                  </button>
                                  <button
                                    onClick={() => {
                                      if (cart.length === 0) return;
                                      playSynthBeep(1900, 0.35, "sine");
                                      setCart([]);
                                      playSynthBeep(2100, 0.15, "sine");
                                      alert(`Payment Completed! Received: ₹${grandTotal.toLocaleString("en-IN")}`);
                                    }}
                                    disabled={cart.length === 0}
                                    className="h-8 rounded bg-blue-500 hover:bg-blue-400 text-white font-bold transition flex items-center justify-center gap-1 text-[9px] disabled:opacity-50"
                                  >
                                    <CheckCircle className="h-3 w-3" />
                                    PAY NOW
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* TAB 2: INVENTORY PRODUCT CATALOG */}
                        {activeTab === "inventory" && (
                          <div className="flex-1 p-3 flex flex-col justify-between overflow-hidden">
                            <span className="font-bold uppercase tracking-wider text-slate-400 font-mono text-[9px] pb-1 border-b border-white/5 shrink-0 block">
                              Active Hardware Catalog
                            </span>

                            <div className="flex-1 overflow-y-auto py-2 grid grid-cols-2 gap-1.5">
                              {DEMO_PRODUCTS.map((prod) => (
                                <button
                                  key={prod.id}
                                  onClick={() => handleTriggerScan(prod)}
                                  className="p-2 rounded bg-[#12141c] hover:bg-[#1a1d29] border border-white/5 hover:border-blue-500/40 text-left transition-all flex flex-col justify-between h-[65px] group"
                                >
                                  <div>
                                    <span className="font-bold text-slate-200 block truncate group-hover:text-blue-400 transition">
                                      {prod.name}
                                    </span>
                                    <span className="text-[8px] text-slate-500 font-mono uppercase tracking-wide">
                                      SKU: {prod.sku} | {prod.category}
                                    </span>
                                  </div>
                                  <div className="flex justify-between items-center w-full mt-1">
                                    <span className="text-[8px] text-slate-400">Add to terminal</span>
                                    <span className="font-mono font-bold text-blue-400 text-[10px]">
                                      ₹{prod.price.toLocaleString("en-IN")}
                                    </span>
                                  </div>
                                </button>
                              ))}
                            </div>

                            <div className="bg-[#151720] p-2 rounded border border-white/5 text-[9px] font-mono text-slate-400 text-center shrink-0">
                              ℹ️ Click any product to trigger simulated barcode scan animation
                            </div>
                          </div>
                        )}

                      </div>

                      {/* SCREEN STATUS FOOTER */}
                      <div className="h-5 bg-[#0a0a0c] border-t border-white/5 px-3 flex items-center justify-between text-[9px] font-mono text-slate-500 shrink-0">
                        <span>OPERATOR: CASHIER_01</span>
                        <span>FUTURISTIC ERP OS v4.2 REGISTER ACTIVE</span>
                      </div>

                    </div>
                  ) : (
                    /* CRT Screen Shutdown display */
                    <div className="w-full h-full bg-black flex items-center justify-center relative">
                      <div className="h-0.5 w-16 bg-white/40 shadow-[0_0_15px_white] rounded animate-pulse" />
                    </div>
                  )}

                </div>

                {/* === WIRELESS BARCODE SCANNER (LEFT SIDE ATTACHMENT) === */}
                <div
                  className="absolute left-[-42px] top-[40px] w-[40px] h-[160px] rounded-l-xl border-l border-y transition-all duration-500 flex flex-col items-center justify-start py-4"
                  style={{
                    background: "linear-gradient(to right, #050507 0%, #151518 100%)",
                    transform: "rotateY(25deg) translateZ(8px)",
                    transformStyle: "preserve-3d",
                    borderColor: !isPowerOn ? "#1e293b" : ledColor === "blue" ? "rgba(59, 130, 246, 0.4)" : ledColor === "green" ? "rgba(34, 197, 94, 0.4)" : "rgba(245, 158, 11, 0.4)"
                  }}
                >
                  <Barcode className="h-4 w-4 text-slate-500 mt-2" />
                  <span className="text-[7px] text-slate-600 tracking-wider font-mono font-bold uppercase rotate-90 mt-5">
                    SCANNER
                  </span>

                  {/* Red Laser Window */}
                  <div className="mt-8 w-6 h-12 bg-red-950/40 rounded border border-red-500/25 relative overflow-hidden flex items-center justify-center">
                    {/* Glowing Red sweep beam line */}
                    {isPowerOn && (
                      <div 
                        className={`absolute left-0 right-0 h-[2px] bg-red-500 shadow-[0_0_10px_2px_rgba(239,68,68,0.8)] ${
                          isScanning ? "laser-line" : "top-1/2 opacity-30"
                        }`} 
                      />
                    )}
                  </div>
                </div>

                {/* === THERMAL RECEIPT PRINTER (RIGHT SIDE ATTACHMENT) === */}
                <div
                  className="absolute right-[-42px] top-[40px] w-[40px] h-[160px] rounded-r-xl border-r border-y transition-all duration-500 flex flex-col items-center justify-start py-4"
                  style={{
                    background: "linear-gradient(to left, #050507 0%, #151518 100%)",
                    transform: "rotateY(-25deg) translateZ(8px)",
                    transformStyle: "preserve-3d",
                    borderColor: !isPowerOn ? "#1e293b" : ledColor === "blue" ? "rgba(59, 130, 246, 0.4)" : ledColor === "green" ? "rgba(34, 197, 94, 0.4)" : "rgba(245, 158, 11, 0.4)"
                  }}
                >
                  <Printer className="h-4 w-4 text-slate-500 mt-2" />
                  <span className="text-[7px] text-slate-600 tracking-wider font-mono font-bold uppercase -rotate-90 mt-5">
                    PRINTER
                  </span>

                  {/* Printer paper slot slit */}
                  <div className="mt-8 w-7 h-2 bg-[#050506] rounded border border-white/5 relative" />

                  {/* --- ANIMATED FEEDING RECEIPT PAPER SHEET --- */}
                  {(isPrinting || receiptPrinted) && (
                    <div className="absolute top-[125px] w-[32px] overflow-hidden flex justify-center z-30">
                      <div 
                        className="w-[28px] bg-white text-black font-mono p-1 rounded-b shadow-[0_4px_10px_rgba(0,0,0,0.6)] flex flex-col justify-start select-none receipt-paper overflow-hidden"
                        style={{ fontSize: '2px', lineHeight: '3.5px' }}
                      >
                        {/* Printed lines simulation */}
                        <div className="w-full text-center font-bold border-b border-black/10 pb-0.5">IHM TECH</div>
                        <div className="mt-0.5">INV-98240</div>
                        <div className="mt-0.5">----------------</div>
                        <div className="flex justify-between"><span>ITM_01</span><span>x1</span></div>
                        <div className="flex justify-between"><span>ITM_04</span><span>x2</span></div>
                        <div className="mt-0.5">----------------</div>
                        <div className="font-bold flex justify-between"><span>TOTAL</span><span>₹1.7L</span></div>
                        <div className="w-full text-center border-t border-black/10 mt-0.5 pt-0.5">THANK YOU</div>
                        
                        {/* Barcode code lines at bottom of paper */}
                        <div className="mt-1 flex gap-[0.5px] h-3 bg-slate-900 w-full" />
                      </div>
                    </div>
                  )}
                </div>

                {/* Branding Logo label under Screen Bezel */}
                <div className="absolute bottom-1 w-full text-center z-10">
                  <span className="text-[8px] font-bold font-mono tracking-widest text-slate-500/80">
                    IHM TECH TERMINAL X
                  </span>
                </div>

              </div>

              {/* === WIRELESS MATTE BLACK KEYBOARD (IN FRONT) === */}
              <div
                className={`relative w-[340px] h-[75px] rounded-lg mx-auto bg-[#0a0a0c] border border-white/5 p-1.5 shadow-[0_15px_30px_rgba(0,0,0,0.7)] mt-6 transition-all duration-500 ${
                  !isPowerOn ? "border-slate-900" : "hover:border-slate-800"
                }`}
                style={{
                  transform: "rotateX(15deg) translateZ(40px) translateY(8px)",
                  transformStyle: "preserve-3d",
                }}
              >
                {/* Slim Blue/Green/Amber Indicator line */}
                {isPowerOn && (
                  <div 
                    className={`absolute top-0 left-1/2 -translate-x-1/2 w-8 h-[2px] rounded-full led-pulse ${
                      ledColor === "blue" ? "bg-blue-500" : ledColor === "green" ? "bg-emerald-500" : "bg-amber-500"
                    }`}
                  />
                )}

                {/* Chiclet Key Grid */}
                <div className="grid grid-cols-12 gap-1 h-full w-full">
                  {Array.from({ length: 24 }).map((_, i) => (
                    <div
                      key={i}
                      onClick={() => {
                        if (!isPowerOn) return;
                        playSynthBeep(600 + i * 40, 0.06, "sine");
                        setActiveKeyIndex(i);
                        setTimeout(() => setActiveKeyIndex(null), 150);
                      }}
                      className={`rounded-sm flex items-center justify-center cursor-pointer transition-all ${
                        activeKeyIndex === i 
                          ? ledColor === "blue" 
                            ? "bg-blue-500 shadow-[0_0_8px_#3b82f6] text-white scale-95" 
                            : ledColor === "green"
                            ? "bg-emerald-500 shadow-[0_0_8px_#10b981] text-white scale-95"
                            : "bg-amber-500 shadow-[0_0_8px_#f59e0b] text-white scale-95"
                          : "bg-[#14151a] hover:bg-[#1e2029] text-slate-500 text-[6px] font-mono font-bold"
                      }`}
                    >
                      ▪
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>

          {/* DRAG CAMERA CONTROLLER HELPER TEXT */}
          <div className="mt-8 text-center bg-white/5 border border-white/5 rounded-full py-1.5 px-4 max-w-sm flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-blue-500 animate-pulse" />
            <p className="text-[10px] text-slate-400 font-mono">
              Use the sliders on the right to rotate the terminal 3D workspace.
            </p>
          </div>

        </div>

        {/* RIGHT COLUMN: TERMINAL CONTROL CENTER (4 COLS) */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* 1. BRAND HERO DETAILS CARD */}
          <div className="glass-dark rounded-xl p-5 border border-white/5">
            <div className="flex items-center gap-2 text-blue-500">
              <Sparkles className="h-4 w-4 text-blue-400" />
              <span className="text-[9px] font-bold font-mono tracking-wider uppercase">
                Premium Showcase
              </span>
            </div>
            
            <h2 className="text-lg font-black tracking-tight text-white mt-1">
              IHM TECH TERMINAL-X
            </h2>
            
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              A premium, matte-black All-In-One POS terminal with customizable LED glowing edges, curved aerodynamic bezel, built-in thermal jet printer, and holographic laser barcode reader.
            </p>
            
            <div className="mt-4 pt-4 border-t border-white/5 grid grid-cols-2 gap-3 text-center">
              <div className="p-2 rounded bg-white/5 border border-white/5">
                <span className="text-[8px] font-mono text-slate-500 block uppercase">Finish</span>
                <span className="text-xs font-bold text-slate-200 mt-0.5 block">Matte Black</span>
              </div>
              <div className="p-2 rounded bg-white/5 border border-white/5">
                <span className="text-[8px] font-mono text-slate-500 block uppercase">Optics</span>
                <span className="text-xs font-bold text-slate-200 mt-0.5 block">5G Laser Scan</span>
              </div>
            </div>
          </div>

          {/* 2. LED LIGHTING CONTROLLER */}
          <div className="glass-dark rounded-xl p-5 border border-white/5 space-y-3">
            <label className="text-[9px] font-bold font-mono tracking-widest text-slate-400 uppercase block pb-2 border-b border-white/5">
              LED Ambient Glow Color
            </label>
            
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => { setLedColor("blue"); playSynthBeep(1100, 0.08); }}
                className={`py-2 px-3 rounded-lg border text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition-all ${
                  ledColor === "blue" 
                    ? "bg-blue-500/10 border-blue-500 text-blue-400" 
                    : "bg-white/5 border-white/5 text-slate-400 hover:text-white"
                }`}
              >
                <span className="h-2 w-2 rounded-full bg-blue-500" />
                BLUE
              </button>
              
              <button
                onClick={() => { setLedColor("green"); playSynthBeep(1100, 0.08); }}
                className={`py-2 px-3 rounded-lg border text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition-all ${
                  ledColor === "green" 
                    ? "bg-emerald-500/10 border-emerald-500 text-emerald-400" 
                    : "bg-white/5 border-white/5 text-slate-400 hover:text-white"
                }`}
              >
                <span className="h-2 w-2 rounded-full bg-emerald-500" />
                GREEN
              </button>

              <button
                onClick={() => { setLedColor("amber"); playSynthBeep(1100, 0.08); }}
                className={`py-2 px-3 rounded-lg border text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition-all ${
                  ledColor === "amber" 
                    ? "bg-amber-500/10 border-amber-500 text-amber-400" 
                    : "bg-white/5 border-white/5 text-slate-400 hover:text-white"
                }`}
              >
                <span className="h-2 w-2 rounded-full bg-amber-500" />
                AMBER
              </button>
            </div>
          </div>

          {/* 3. ROTATABLE CAMERA CONTROLS */}
          <div className="glass-dark rounded-xl p-5 border border-white/5 space-y-4">
            <label className="text-[9px] font-bold font-mono tracking-widest text-slate-400 uppercase block pb-2 border-b border-white/5">
              3D Workspace Rotations
            </label>

            <div className="space-y-3 font-mono text-[10px]">
              {/* Pitch Slider */}
              <div className="space-y-1">
                <div className="flex justify-between text-slate-400">
                  <span>CAMERA PITCH (X-AXIS):</span>
                  <span className="text-blue-400 font-bold">{rotX}°</span>
                </div>
                <input
                  type="range"
                  min={-20}
                  max={45}
                  value={rotX}
                  onChange={(e) => setRotX(parseInt(e.target.value))}
                  className="w-full h-1 bg-[#1a1b23] rounded-lg appearance-none cursor-pointer accent-blue-500"
                />
              </div>

              {/* Yaw Slider */}
              <div className="space-y-1">
                <div className="flex justify-between text-slate-400">
                  <span>CAMERA YAW (Y-AXIS):</span>
                  <span className="text-blue-400 font-bold">{rotY}°</span>
                </div>
                <input
                  type="range"
                  min={-45}
                  max={45}
                  value={rotY}
                  onChange={(e) => setRotY(parseInt(e.target.value))}
                  className="w-full h-1 bg-[#1a1b23] rounded-lg appearance-none cursor-pointer accent-blue-500"
                />
              </div>
            </div>
          </div>

          {/* 4. WORKSPACE DEMO TRIGGERS */}
          <div className="glass-dark rounded-xl p-5 border border-white/5 space-y-3">
            <label className="text-[9px] font-bold font-mono tracking-widest text-slate-400 uppercase block pb-2 border-b border-white/5">
              Simulate Physical Hardware Actions
            </label>

            <div className="space-y-2">
              <button
                onClick={() => handleTriggerScan()}
                disabled={!isPowerOn || isScanning}
                className="w-full h-10 rounded-lg bg-blue-500 hover:bg-blue-400 text-white font-bold text-xs flex items-center justify-center gap-2 transition disabled:opacity-50"
              >
                <Barcode className="h-4 w-4" />
                TRIGGER BARCODE SCAN
              </button>

              <button
                onClick={handlePrintReceipt}
                disabled={!isPowerOn || isPrinting || cart.length === 0}
                className="w-full h-10 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 text-slate-200 font-bold text-xs flex items-center justify-center gap-2 transition disabled:opacity-50"
              >
                <Printer className="h-4 w-4" />
                PRINT THERMAL RECEIPT
              </button>

              {receiptPrinted && (
                <button
                  onClick={() => {
                    setReceiptPrinted(false);
                    playSynthBeep(700, 0.08, "triangle");
                  }}
                  className="w-full h-8 rounded bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20 text-[10px] font-mono flex items-center justify-center gap-1.5 transition"
                >
                  <Undo className="h-3 w-3" />
                  TEAR OFF RECEIPT PAPER
                </button>
              )}
            </div>
          </div>

        </div>

      </main>

      {/* FOOTER BAR */}
      <footer className="w-full max-w-7xl flex flex-col sm:flex-row items-center justify-between gap-3 py-6 px-6 border-t border-white/5 text-[10px] text-slate-500 font-mono mt-8 relative z-20">
        <span>© 2026 IHM TECH CORPORATION. ALL RIGHTS RESERVED.</span>
        <div className="flex gap-4">
          <span className="hover:text-slate-300 cursor-pointer">PRIVACY</span>
          <span>•</span>
          <span className="hover:text-slate-300 cursor-pointer">DOCUMENTATION</span>
          <span>•</span>
          <span className="hover:text-slate-300 cursor-pointer">SaaS INTEGRATIONS</span>
        </div>
      </footer>

    </div>
  );
}
