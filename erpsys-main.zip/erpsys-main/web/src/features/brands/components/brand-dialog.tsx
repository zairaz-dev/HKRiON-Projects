import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { X, Upload, Loader2, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { User } from "@hkr/types";
import { brandFormSchema, BrandFormSchema } from "../schema";
import { BrandItem, BranchItem } from "../types";
import { useCreateBrandMutation, useUpdateBrandMutation } from "../hooks/use-brands";
import { getFullAssetUrl } from "@/lib/utils";

interface BrandDialogProps {
  isOpen: boolean;
  onClose: () => void;
  brand?: BrandItem | null;
  branches: BranchItem[];
  currentUser: User;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

export function BrandDialog({
  isOpen,
  onClose,
  brand,
  branches,
  currentUser,
  onSuccess,
  onError,
}: BrandDialogProps) {
  const isEditMode = !!brand;
  const createMutation = useCreateBrandMutation();
  const updateMutation = useUpdateBrandMutation();
  const [formError, setFormError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<BrandFormSchema>({
    resolver: zodResolver(brandFormSchema),
    defaultValues: {
      name: "",
      description: "",
      branchIds: [],
      logoUrl: "",
      logoFile: null,
      isActive: true,
      logoUploadType: "file",
    },
  });

  const watchLogoUploadType = watch("logoUploadType");
  const watchLogoUrl = watch("logoUrl");
  const watchBranchIds = watch("branchIds");

  // Populate form if in edit mode
  useEffect(() => {
    setFormError(null);
    if (brand) {
      const assignedBranchIds = brand.branches?.map((bb) => bb.branch.id) || [];
      reset({
        name: brand.name,
        description: brand.description || "",
        branchIds: assignedBranchIds,
        logoUrl: brand.logoUrl || "",
        logoFile: null,
        isActive: brand.isActive,
        logoUploadType: brand.logoUrl?.startsWith("/uploads/") ? "file" : "url",
      });
    } else {
      reset({
        name: "",
        description: "",
        branchIds: [],
        logoUrl: "",
        logoFile: null,
        isActive: true,
        logoUploadType: "file",
      });
    }
  }, [brand, reset, isOpen]);

  const handleToggleBranch = (branchId: string) => {
    const currentBranches = watchBranchIds;
    if (currentBranches.includes(branchId)) {
      setValue(
        "branchIds",
        currentBranches.filter((id) => id !== branchId),
        { shouldValidate: true }
      );
    } else {
      setValue("branchIds", [...currentBranches, branchId], {
        shouldValidate: true,
      });
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        onError("Logo size should be less than 2MB.");
        return;
      }
      setValue("logoFile", file, { shouldValidate: true });

      const reader = new FileReader();
      reader.onloadend = () => {
        setValue("logoUrl", reader.result as string, { shouldValidate: true });
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = async (data: BrandFormSchema) => {
    if (!currentUser.businessId) return;

    const payload: any = {
      name: data.name.trim(),
      description: data.description?.trim() || undefined,
      logoUrl: data.logoUploadType === "url" ? data.logoUrl?.trim() : undefined,
      logoFile: data.logoUploadType === "file" ? data.logoFile : null,
      businessId: currentUser.businessId,
      branchIds: data.branchIds,
      isActive: data.isActive,
    };

    if (isEditMode) {
      payload.updatedById = currentUser.id;
    } else {
      payload.createdById = currentUser.id;
    }

    try {
      if (isEditMode && brand) {
        await updateMutation.mutateAsync({ id: brand.id, brandData: payload });
        onSuccess("Brand updated successfully!");
      } else {
        await createMutation.mutateAsync(payload);
        onSuccess("Brand created successfully!");
      }
      onClose();
    } catch (err: any) {
      const msg = err.message || "Failed to save brand.";
      setFormError(msg);
      onError(msg);
    }
  };

  const isLoading = createMutation.isPending || updateMutation.isPending;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-card border border-border rounded-sm shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between border-b border-border p-5 bg-background/40">
          <h3 className="text-sm font-bold text-foreground tracking-wider uppercase font-mono">
            {isEditMode ? "Edit Brand Details" : "Add Product Brand"}
          </h3>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-5 space-y-4 max-h-[75vh] overflow-y-auto">
          {formError && (
            <div className="p-3 rounded-sm bg-rose-500/15 border border-rose-500/30 text-rose-450 text-xs flex items-center gap-2 animate-in fade-in duration-200">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{formError}</span>
            </div>
          )}
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">Brand Name *</label>
            <Input
              {...register("name")}
              placeholder="e.g. Nike, Apple, Samsung"
              className="text-xs h-9 rounded-sm"
            />
            {errors.name && (
              <span className="text-xs text-rose-500">{errors.name.message}</span>
            )}
          </div>

          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">Description</label>
            <textarea
              {...register("description")}
              placeholder="Provide a brief description of this brand..."
              className="w-full h-20 px-3 py-2 bg-background/50 border border-input text-foreground rounded-sm text-xs focus:outline-none focus:border-primary placeholder:text-muted-foreground/60 transition-all focus:ring-1 focus:ring-primary resize-none"
            />
            {errors.description && (
              <span className="text-xs text-rose-500">{errors.description.message}</span>
            )}
          </div>

          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">Branch Assignment</label>
            <div className="border border-border/45 p-3 rounded-sm bg-background/30 max-h-32 overflow-y-auto space-y-2">
              {branches.map((branch) => {
                const isChecked = watchBranchIds.includes(branch.id);
                return (
                  <label key={branch.id} className="flex items-center gap-2.5 text-xs text-foreground cursor-pointer hover:text-primary transition-colors">
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => handleToggleBranch(branch.id)}
                      className="rounded border-input text-primary focus:ring-primary h-3.5 w-3.5 bg-background"
                    />
                    {branch.name}
                  </label>
                );
              })}
              {branches.length === 0 && (
                <p className="text-xs text-muted-foreground">No branches found.</p>
              )}
            </div>
            <p className="text-[10px] text-muted-foreground">
              Leave all unchecked to make this brand **Global** (Available in all branches).
            </p>
          </div>

          {/* Brand Logo */}
          <div className="space-y-2 border border-border/45 p-3 rounded-sm bg-background/30">
            <div className="flex items-center justify-between">
              <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">Brand Logo</label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setValue("logoUploadType", "file")}
                  className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-sm border transition-all ${
                    watchLogoUploadType === "file"
                      ? "bg-primary/10 border-primary/20 text-primary"
                      : "border-border text-muted-foreground hover:bg-secondary/40"
                  }`}
                >
                  Upload File
                </button>
                <button
                  type="button"
                  onClick={() => setValue("logoUploadType", "url")}
                  className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-sm border transition-all ${
                    watchLogoUploadType === "url"
                      ? "bg-primary/10 border-primary/20 text-primary"
                      : "border-border text-muted-foreground hover:bg-secondary/40"
                  }`}
                >
                  URL Link
                </button>
              </div>
            </div>

            {watchLogoUploadType === "file" ? (
              <div className="flex items-center gap-4">
                <label className="flex flex-col items-center justify-center h-20 w-20 rounded-md border border-dashed border-border hover:border-primary/55 cursor-pointer bg-background/10 hover:bg-background/25 transition-all text-muted-foreground hover:text-foreground">
                  <Upload className="h-5 w-5 mb-1" />
                  <span className="text-[9px] font-semibold">Browse</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </label>

                {watchLogoUrl && (
                  <div className="relative h-20 w-20 rounded-md border border-border overflow-hidden bg-secondary/30 flex items-center justify-center">
                    <img
                      src={getFullAssetUrl(watchLogoUrl) || ""}
                      alt="Preview"
                      className="h-full w-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        setValue("logoUrl", "");
                        setValue("logoFile", null);
                      }}
                      className="absolute top-1 right-1 bg-black/70 hover:bg-black/85 text-white rounded-full p-0.5"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-2">
                <Input
                  value={watchLogoUrl || ""}
                  onChange={(e) => setValue("logoUrl", e.target.value, { shouldValidate: true })}
                  placeholder="https://example.com/logo.png"
                  className="text-xs h-9 rounded-sm"
                />
                {watchLogoUrl && (
                  <div className="h-16 w-16 rounded-md border border-border overflow-hidden bg-secondary/30 flex items-center justify-center">
                    <img
                      src={watchLogoUrl}
                      alt="Preview"
                      className="h-full w-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "";
                      }}
                    />
                  </div>
                )}
              </div>
            )}
            {errors.logoUrl && (
              <span className="text-xs text-rose-500">{errors.logoUrl.message}</span>
            )}
          </div>

          {/* Status */}
          <label className="flex items-center gap-2.5 text-xs text-foreground cursor-pointer pt-2 hover:text-primary transition-colors">
            <input
              type="checkbox"
              {...register("isActive")}
              className="rounded border-input text-primary focus:ring-primary h-3.5 w-3.5 bg-background"
            />
            Is Active (Show in lists)
          </label>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-3 border-t border-border">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1 text-xs h-9 rounded-sm"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isLoading}
              className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground text-xs h-9 rounded-sm px-4 shadow-md shadow-primary/10 flex items-center justify-center gap-1.5"
            >
              {isLoading && <Loader2 className="h-3.5 w-3.5 animate-spin text-primary-foreground" />}
              {isEditMode ? "Save Changes" : "Create Brand"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
