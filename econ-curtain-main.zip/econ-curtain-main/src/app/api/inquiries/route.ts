import { NextResponse } from "next/server";
import { InquiryService } from "@/services/inquiry.service";
import { SafeHttp } from "@/core/http/redirect";
import { RateLimiter } from "@/core/security/rateLimiter";

export async function POST(request: Request) {
  try {
    const clientIp = RateLimiter.getClientIp(request);
    const rateCheck = RateLimiter.check(`inquiry_${clientIp}`, 6, 2 * 60 * 1000);

    const contentType = request.headers.get("content-type") || "";
    const isJson = contentType.includes("application/json");

    if (!rateCheck.allowed) {
      const errorMsg = `Too many submissions. Please wait ${rateCheck.retryAfterSeconds} seconds before sending another message.`;
      if (isJson) {
        return NextResponse.json(
          { success: false, error: errorMsg },
          { status: 429, headers: { "Retry-After": rateCheck.retryAfterSeconds.toString() } }
        );
      }
      return SafeHttp.redirect(`/contact?error=${encodeURIComponent(errorMsg)}`, request, 303);
    }

    let customerName = "";
    let email = "";
    let phone = "";
    let productName = "";
    let message = "";
    let honeypot = "";

    if (isJson) {
      const body = await request.json();
      customerName = (body.customerName || body.name || "").trim();
      email = (body.email || "").trim();
      const rawPhone = (body.phone || "").trim();
      const countryCode = (body.countryCode || "").trim();
      phone = countryCode ? `${countryCode} ${rawPhone}`.trim() : rawPhone;
      productName = (body.service || body.productName || "").trim();
      message = (body.message || "").trim();
      honeypot = body.website || body.honeypot || "";
    } else {
      const formData = await request.formData();
      customerName = ((formData.get("name") as string) || (formData.get("customerName") as string) || "").trim();
      email = ((formData.get("email") as string) || "").trim();
      const rawPhone = ((formData.get("phone") as string) || "").trim();
      const countryCode = ((formData.get("countryCode") as string) || "").trim();
      phone = countryCode ? `${countryCode} ${rawPhone}`.trim() : rawPhone;
      productName = ((formData.get("service") as string) || (formData.get("productName") as string) || "").trim();
      message = ((formData.get("message") as string) || "").trim();
      honeypot = (formData.get("website") as string) || (formData.get("honeypot") as string) || "";
    }

    // Bot detection: If hidden honeypot field is filled, silently discard spam
    if (honeypot) {
      if (isJson) {
        return NextResponse.json({ success: true, message: "Thank you! We will get in touch shortly." });
      }
      return SafeHttp.redirect("/contact?success=Thank+you!+Your+inquiry+has+been+received.", request, 303);
    }

    if (!customerName || !phone) {
      if (isJson) {
        return NextResponse.json({ success: false, error: "Name and Phone are required." }, { status: 400 });
      }
      return SafeHttp.redirect("/contact?error=Name+and+Phone+are+required", request, 303);
    }

    // Basic email format check if email is provided
    if (email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        if (isJson) {
          return NextResponse.json({ success: false, error: "Please provide a valid email address." }, { status: 400 });
        }
        return SafeHttp.redirect("/contact?error=Please+provide+a+valid+email+address", request, 303);
      }
    }

    await InquiryService.create({
      customerName: customerName.substring(0, 100),
      email: email ? email.substring(0, 150) : undefined,
      phone: phone.substring(0, 30),
      productName: productName ? productName.substring(0, 100) : undefined,
      message: message ? message.substring(0, 1000) : undefined,
    });

    if (isJson) {
      return NextResponse.json({ success: true, message: "Thank you! We will get in touch shortly." });
    }

    return SafeHttp.redirect("/contact?success=Thank+you!+Your+inquiry+has+been+received.", request, 303);
  } catch (error) {
    console.error("Inquiry submission error:", error);
    return SafeHttp.redirect("/contact?error=Failed+to+submit+inquiry", request, 303);
  }
}
