import { NextResponse } from "next/server";
import { ContactService } from "@/services/contact.service";
import { SessionManager } from "@/core/auth/session";
import { SafeHttp } from "@/core/http/redirect";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  try {
    const session = await SessionManager.getCurrentSession();
    if (!session) {
      return SafeHttp.redirect("/login", request, 303);
    }

    const contentType = request.headers.get("content-type") || "";
    const isJson = contentType.includes("application/json");

    let payload: Record<string, string> = {};

    if (isJson) {
      payload = await request.json();
    } else {
      const formData = await request.formData();
      formData.forEach((value, key) => {
        payload[key] = value.toString();
      });
    }

    await ContactService.updateContent(payload);

    // Revalidate paths so updates are visible instantly
    revalidatePath("/contact");
    revalidatePath("/admin/contact");
    revalidatePath("/admin");
    revalidatePath("/");

    if (isJson) {
      return NextResponse.json({ success: true, message: "Contact page content updated successfully!" });
    }

    return SafeHttp.redirect(
      `/admin/contact?success=${encodeURIComponent("Contact page content updated successfully!")}`,
      request,
      303
    );
  } catch (error: unknown) {
    console.error("Failed to update contact page content:", error);
    return SafeHttp.redirect(
      `/admin/contact?error=${encodeURIComponent("Failed to update contact page content")}`,
      request,
      303
    );
  }
}
