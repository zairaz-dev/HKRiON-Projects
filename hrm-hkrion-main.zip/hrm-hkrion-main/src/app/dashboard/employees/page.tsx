import { getEmployees, getPotentialManagers } from "@/actions/employees";
import { getPositions } from "@/actions/positions";
import EmployeeClient from "./employee-client";
import { getSession } from "@/lib/session";
import { Role } from "@prisma/client";

import { redirect } from "next/navigation";

export default async function EmployeesPage() {
  const session = await getSession();
  
  if (!session || session.role === Role.EMPLOYEE) {
    redirect("/dashboard");
  }

  const isAdmin = session.role === Role.MANAGER || session.role === Role.SUPER_ADMIN;

  const [employeesRes, positionsRes, managersRes] = await Promise.all([
    getEmployees(),
    getPositions(),
    getPotentialManagers()
  ]);

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <EmployeeClient 
        employees={employeesRes.data || []}
        positions={positionsRes.data || []}
        managers={managersRes.data || []}
        isAdmin={isAdmin}
      />
    </div>
  );
}
