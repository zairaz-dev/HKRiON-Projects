# SHADEIT BLINDS — Project Core Rules & Architectural Guidelines

## 1. Mobile Responsiveness & Layout Rules
- **Mobile-First Standard**: Every single UI component, page, navigation bar, hero section, card, modal, and typography MUST be thoroughly verified for mobile screens (320px to 480px, tablets, and desktops).
- **Zero Horizontal Overflow**: Always enforce `overflow-x-hidden` on top-level wrappers to prevent unintended horizontal scrolling on mobile viewports.
- **Adaptive Layouts**: Multi-column grids must gracefully collapse to single columns on mobile devices (`grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4`).

---

## 2. Universal Host & Network Binding Rules
- **Universal Host Binding (`-H 0.0.0.0`)**: All dev and production server execution commands in `package.json` must explicitly bind to `0.0.0.0` (e.g., `next dev -H 0.0.0.0 -p 3001` and `next start -H 0.0.0.0 -p 3001`). This ensures smooth LAN IP access (`192.168.x.x`) across local networks and testing devices without CORS, HMR origin blocks, or WebSocket disconnects.

---

## 3. Hydration-Safe & Progressive Enhancement (Crucial Rule)
- **Zero Client Hydration Dependency for Critical Actions**:
  - **Authentication (Login/Logout)**: Form submissions MUST use Browser-Native HTML actions (`<form method="POST" action="/api/auth/login">` and `<form method="POST" action="/api/auth/logout">`) that return `303 Redirect`. Critical actions must execute in 0ms, even if client JavaScript hydration is delayed or pending over network connections.
  - **Navigation & Category Filtering**: All category filters must use Next.js `<Link href="/products?cat=..." scroll={false}>` with URL search parameters rather than client-only `useState` hooks.
  - **No Hidden Initial Animations**: Never hide core UI cards or tables with `opacity: 0` in client animations. Essential elements must render with full opacity in SSR/initial HTML so that users never see blank pages during network latency.

---

## 4. Universal Authentication & Cookie Standards
- **Dual-Layer Cookie Persistence**:
  - Server Route Handlers must set cookies with `path: "/"`, `sameSite: "lax"`, and `secure: false` (to support non-SSL LAN IP testing like `http://192.168.1.10:3001`).
  - Client components must also set `document.cookie` directly on the active host as a fallback.
  - All `fetch` calls across the application must explicitly include `credentials: "include"`.
- **Fail-Safe Middleware**: Route protection in `middleware.ts` must parse both structured cookie maps and raw `Cookie` headers so that valid authenticated sessions are never erroneously redirected.

---

## 5. Product Catalog Standards
- **13 Core Products Coverage**: Maintain all 13 core product categories with verified high-resolution images, rich descriptions, key specifications, and direct WhatsApp inquiry CTAs:
  1. Monsoon Blinds
  2. Zebra Blinds
  3. Roller Blinds
  4. Roman Blinds
  5. Curtains
  6. Vertical Blinds
  7. Timber Venetian Blinds
  8. Awning
  9. Canopy
  10. Pergola
  11. Outdoor Teak Sunbed
  12. Outdoor Fabric
  13. Outdoor UV Clear PVC

---

## 6. Build & Code Quality Standards
- **Strict TypeScript & Zero Lints**: All new pages, components, and API routes must compile with `npx tsc --noEmit` and build with `npm run build` with zero errors.
