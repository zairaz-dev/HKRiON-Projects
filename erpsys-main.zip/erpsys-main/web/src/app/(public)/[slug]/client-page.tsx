"use strict";
"use client";

import React, { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { cmsService, CmsPage } from "@/services/cms-service";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ShieldCheck, Clock, FileText, Loader2 } from "lucide-react";

/**
 * Lightweight formatting helper for Markdown content
 */
function MarkdownRenderer({ content }: { content: string }) {
  if (!content) return null;

  // If content is JSON, handle gracefully
  if (content.trim().startsWith("{") && content.trim().endsWith("}")) {
    try {
      const parsed = JSON.parse(content);
      return (
        <div className="space-y-4">
          {parsed.headline && <h2 className="text-xl font-bold text-foreground">{parsed.headline}</h2>}
          {parsed.subtitle && <p className="text-sm text-muted-foreground">{parsed.subtitle}</p>}
          {parsed.mission && <p className="text-sm text-muted-foreground">{parsed.mission}</p>}
          {parsed.email && <p className="text-sm">Email: <span className="text-primary font-mono">{parsed.email}</span></p>}
          {parsed.phone && <p className="text-sm">Phone: <span className="text-primary font-mono">{parsed.phone}</span></p>}
        </div>
      );
    } catch {
      // Not valid JSON, fallback to markdown
    }
  }

  const lines = content.split("\n");

  const formatInline = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*|`.*?`)/g);
    return parts.map((part, i) => {
      if (part.startsWith("**") && part.endsWith("**")) {
        return (
          <strong key={i} className="font-bold text-foreground">
            {part.slice(2, -2)}
          </strong>
        );
      }
      if (part.startsWith("`") && part.endsWith("`")) {
        return (
          <code
            key={i}
            className="px-1.5 py-0.5 rounded bg-secondary/80 text-primary font-mono text-[11px]"
          >
            {part.slice(1, -1)}
          </code>
        );
      }
      return part;
    });
  };

  const elements: React.ReactNode[] = [];
  let inList = false;
  let listItems: React.ReactNode[] = [];

  const flushList = () => {
    if (inList && listItems.length > 0) {
      elements.push(
        <ul
          key={`list-${elements.length}`}
          className="space-y-2 my-3 pl-5 list-disc text-xs md:text-sm text-muted-foreground"
        >
          {listItems}
        </ul>
      );
      listItems = [];
      inList = false;
    }
  };

  lines.forEach((line, index) => {
    const trimmed = line.trim();

    if (trimmed.startsWith("### ")) {
      flushList();
      elements.push(
        <h3
          key={index}
          className="text-sm md:text-base font-bold text-primary mt-6 mb-2 font-mono flex items-center gap-1.5"
        >
          {formatInline(trimmed.replace("### ", ""))}
        </h3>
      );
    } else if (trimmed.startsWith("## ")) {
      flushList();
      elements.push(
        <h2
          key={index}
          className="text-base md:text-lg font-bold text-foreground mt-8 mb-3 border-b border-border/50 pb-2 font-mono"
        >
          {formatInline(trimmed.replace("## ", ""))}
        </h2>
      );
    } else if (trimmed.startsWith("# ")) {
      flushList();
      elements.push(
        <h1
          key={index}
          className="text-xl md:text-2xl font-extrabold text-foreground mt-4 mb-4"
        >
          {formatInline(trimmed.replace("# ", ""))}
        </h1>
      );
    } else if (trimmed === "---" || trimmed === "***") {
      flushList();
      elements.push(<hr key={index} className="my-6 border-border/50" />);
    } else if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
      inList = true;
      listItems.push(
        <li key={index} className="leading-relaxed">
          {formatInline(trimmed.slice(2))}
        </li>
      );
    } else if (trimmed.length > 0) {
      flushList();
      elements.push(
        <p
          key={index}
          className="text-xs md:text-sm text-muted-foreground/90 leading-relaxed my-2"
        >
          {formatInline(trimmed)}
        </p>
      );
    } else {
      flushList();
    }
  });

  flushList();

  return <div className="space-y-1">{elements}</div>;
}

export default function DynamicLegalClientPage({ initialSlug }: { initialSlug?: string }) {
  const params = useParams();
  const router = useRouter();
  const slug = (params?.slug as string) || initialSlug || "";

  const [page, setPage] = useState<CmsPage | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (slug) {
      loadPage(slug);
    }
  }, [slug]);

  const loadPage = async (pageSlug: string) => {
    setIsLoading(true);
    setError("");
    try {
      const data = await cmsService.getPublicPage(pageSlug);
      setPage(data);
    } catch (err: any) {
      setError(err.message || "Page not found");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-transparent text-foreground flex flex-col justify-between selection:bg-emerald-500/30 selection:text-emerald-400">

      {/* Header */}
      <header className="border-b border-border/60 bg-card/30 backdrop-blur-md sticky top-0 z-20">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link
            href="/"
            className="flex items-center gap-2 text-xs font-mono font-bold text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-4 h-4 text-primary" /> Back to Home
          </Link>

          <Link href="/" className="flex items-center gap-2">
            <div className="w-7 h-7 flex items-center justify-center shrink-0">
              <img src="/logo.png" alt="HKRiON ERP Logo" className="w-full h-full object-contain" />
            </div>
            <span className="text-sm font-black font-mono tracking-tight text-primary">
              HKRiON CLOUD ERP
            </span>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl w-full mx-auto px-4 py-12 flex-1 relative z-10">
        {isLoading ? (
          <div className="p-16 text-center text-muted-foreground">
            <Loader2 className="w-8 h-8 animate-spin mx-auto mb-3 text-primary" />
            <p className="text-xs font-mono">Loading official document...</p>
          </div>
        ) : error || !page ? (
          <Card className="bg-card/40 backdrop-blur-md border-border/60 p-8 text-center space-y-4">
            <FileText className="w-12 h-12 text-muted-foreground mx-auto" />
            <h2 className="text-xl font-bold text-foreground">Document Not Found</h2>
            <p className="text-xs text-muted-foreground">
              The requested page <code>/{slug}</code> is currently not published or does not exist.
            </p>
            <Button
              onClick={() => router.push("/")}
              className="text-xs h-9 font-bold"
            >
              Return to Landing Page
            </Button>
          </Card>
        ) : (
          <Card className="bg-card/40 backdrop-blur-md border-border/60 shadow-xl overflow-hidden">
            <div className="p-6 md:p-8 border-b border-border/60 bg-secondary/20">
              <div className="flex items-center gap-2 text-xs font-mono text-primary font-bold mb-2">
                <ShieldCheck className="w-4 h-4" /> Official Verified Policy Document
              </div>
              <h1 className="text-2xl md:text-4xl font-extrabold text-foreground tracking-tight">
                {page.title}
              </h1>
              {page.metaDescription && (
                <p className="text-xs text-muted-foreground mt-2">
                  {page.metaDescription}
                </p>
              )}
              {page.updatedAt && (
                <div className="flex items-center gap-1.5 text-[11px] font-mono text-muted-foreground/80 mt-4">
                  <Clock className="w-3 h-3" /> Last updated: {new Date(page.updatedAt).toLocaleDateString()}
                </div>
              )}
            </div>

            <CardContent className="p-6 md:p-10 prose prose-invert max-w-none text-xs md:text-sm leading-relaxed space-y-4 text-foreground/90 font-sans">
              <MarkdownRenderer content={page.content} />
            </CardContent>
          </Card>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border/60 py-6 text-center text-xs text-muted-foreground font-mono">
        © {new Date().getFullYear()} HKRION SYSTEMS (PVT) LTD. All Rights Reserved.
      </footer>
    </div>
  );
}
