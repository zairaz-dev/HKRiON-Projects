import {
  Controller,
  Post,
  Body,
  Get,
  Put,
  Delete,
  Param,
  Query,
  UseGuards,
  Req,
} from '@nestjs/common';
import { VariationsService } from './variations.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';
import {
  ApiTags,
  ApiOperation,
  ApiBody,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiQuery,
} from '@nestjs/swagger';

import { CreateVariationDto } from './dto/create-variation.dto';
import { UpdateVariationDto } from './dto/update-variation.dto';

@ApiTags('Variations')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('variations')
export class VariationsController {
  constructor(private readonly variationsService: VariationsService) {}

  @Permissions(Permission.PRODUCT_CREATE)
  @Post()
  @ApiOperation({ summary: 'Create product variation template (e.g., Color, Size)' })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        name: { type: 'string', minLength: 2, maxLength: 100, example: 'Color' },
        isActive: { type: 'boolean', example: true },
        businessId: { type: 'string', example: 'biz_123' },
        branchIds: { type: 'array', items: { type: 'string' }, example: ['branch_01'] },
        values: { type: 'array', items: { type: 'string' }, example: ['Red', 'Blue', 'Green'] },
      },
      required: ['name', 'values', 'businessId'],
    },
  })
  @ApiResponse({ status: 201, description: 'Variation created successfully' })
  async createVariation(
    @Req() req: any,
    @Body() body: CreateVariationDto,
  ) {
    const user = req.user;
    if (user.role !== 'super-admin' || !body.businessId) {
      body.businessId = user.businessId;
    }
    if (!body.createdById) {
      body.createdById = user.id;
    }
    return this.variationsService.createVariation(body as any);
  }

  @Permissions(Permission.PRODUCT_VIEW)
  @Get()
  @ApiOperation({ summary: 'Get list of product variations' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiQuery({ name: 'branchId', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Variations retrieved successfully' })
  async getVariations(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.variationsService.getVariations(bId, branchId);
  }

  @Permissions(Permission.PRODUCT_VIEW)
  @Get(':id')
  @ApiOperation({ summary: 'Get variation details by ID' })
  @ApiParam({ name: 'id', description: 'Variation UUID' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Variation retrieved successfully' })
  async getVariationById(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.variationsService.getVariationById(id, bId);
  }

  @Permissions(Permission.PRODUCT_UPDATE)
  @Put(':id')
  @ApiOperation({ summary: 'Update variation details and values' })
  @ApiParam({ name: 'id', description: 'Variation UUID' })
  @ApiResponse({ status: 200, description: 'Variation updated successfully' })
  async updateVariation(
    @Req() req: any,
    @Param('id') id: string,
    @Body() body: UpdateVariationDto,
  ) {
    const user = req.user;
    let bId = body.businessId;
    if (user.role !== 'super-admin' || !bId) {
      bId = user.businessId;
    }
    if (!body.updatedById) {
      body.updatedById = user.id;
    }
    const { businessId, ...data } = body;
    return this.variationsService.updateVariation(id, bId, data as any);
  }

  @Permissions(Permission.PRODUCT_DELETE)
  @Delete(':id')
  @ApiOperation({ summary: 'Delete variation' })
  @ApiParam({ name: 'id', description: 'Variation UUID' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Variation deleted successfully' })
  async deleteVariation(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.variationsService.deleteVariation(id, bId);
  }
}
