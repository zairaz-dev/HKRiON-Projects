import { Controller, Post, Body, Get, Put, Delete, Query, Param, UseGuards, Req, ForbiddenException, BadRequestException, UseInterceptors, UploadedFile, HttpException, HttpStatus } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Public } from '../../common/decorators/public.decorator';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';
import { Role } from '../../common/enums/role.enum';
import { ApiTags, ApiOperation, ApiBody, ApiResponse, ApiBearerAuth, ApiQuery, ApiParam, ApiConsumes } from '@nestjs/swagger';
import { getImageUploadOptions } from '../../common/utils/upload.util';
import {
  LoginBodySchema,
  LoginResponseSchema,
  GoogleLoginBodySchema,
  GoogleLoginResponseSchema,
  CreateUserBodySchema,
  UserResponseSchema,
  UsersListResponseSchema,
  UpdateUserBodySchema,
  DeleteUserResponseSchema,
} from '../../docs/auth.docs';

interface FailedLoginAttempt {
  count: number;
  resetAt: number;
}
const failedLoginAttempts = new Map<string, FailedLoginAttempt>();

@ApiTags('Auth')
@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Public()
  @Post('login')
  @ApiOperation({ summary: 'Login with email & password' })
  @ApiBody({ schema: LoginBodySchema })
  @ApiResponse({
    status: 200,
    description: 'Login successful',
    schema: LoginResponseSchema,
  })
  async login(@Body() body: any, @Req() req: any) {
    const clientIp = req.headers['x-forwarded-for']?.toString().split(',')[0]?.trim() || req.ip || req.socket?.remoteAddress || 'unknown';
    const emailKey = (body.email || '').toLowerCase().trim();
    const trackerKey = `${clientIp}:${emailKey}`;
    const now = Date.now();

    const entry = failedLoginAttempts.get(trackerKey);
    if (entry && entry.resetAt > now && entry.count >= 5) {
      throw new HttpException('Too many failed login attempts. Please try again later.', HttpStatus.TOO_MANY_REQUESTS);
    }

    try {
      const result = await this.authService.login(body.email, body.password, clientIp);
      failedLoginAttempts.delete(trackerKey);
      return result;
    } catch (err: any) {
      const current = failedLoginAttempts.get(trackerKey);
      if (!current || current.resetAt <= now) {
        failedLoginAttempts.set(trackerKey, { count: 1, resetAt: now + 300000 });
      } else {
        current.count += 1;
      }
      throw err;
    }
  }

  @Public()
  @Post('google')
  @ApiOperation({ summary: 'Login or authenticate with Google OAuth Token' })
  @ApiBody({ schema: GoogleLoginBodySchema })
  @ApiResponse({
    status: 200,
    description: 'Google authentication successful',
    schema: GoogleLoginResponseSchema,
  })
  async googleLogin(@Body() body: any, @Req() req: any) {
    const clientIp = req.headers['x-forwarded-for']?.toString().split(',')[0]?.trim() || req.ip || req.socket?.remoteAddress;
    return this.authService.googleLogin(body.token, clientIp);
  }

  @ApiBearerAuth()
  @Get('me')
  @ApiOperation({ summary: 'Get current user profile and up-to-date permissions' })
  async getMe(@Req() req: any) {
    const user = req.user;
    return this.authService.getUserById(user.id);
  }

  @ApiBearerAuth()
  @Permissions(Permission.USER_MANAGE)
  @Get('users')
  @ApiOperation({ summary: 'Get all team users / staff for a business' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiResponse({
    status: 200,
    description: 'List of users retrieved successfully',
    schema: UsersListResponseSchema,
  })
  async getUsers(
    @Req() req: any,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== Role.SUPER_ADMIN) {
      bId = user.businessId;
    }
    if (!bId) {
      return [];
    }
    const result = await this.authService.getUsers(bId);
    return result.filter((u) => u.businessId !== null);
  }

  @ApiBearerAuth()
  @Post('users/upload-avatar')
  @UseInterceptors(FileInterceptor('avatar', getImageUploadOptions('avatars')))
  @ApiConsumes('multipart/form-data')
  @ApiOperation({ summary: 'Upload a user profile avatar image' })
  @ApiResponse({
    status: 201,
    description: 'Avatar image uploaded successfully',
    schema: {
      type: 'object',
      properties: {
        avatarUrl: { type: 'string', example: '/uploads/avatars/1723829000-12345.png' },
      },
    },
  })
  async uploadAvatar(@UploadedFile() file: any) {
    if (!file) {
      throw new BadRequestException('No image file provided');
    }
    return {
      avatarUrl: `/uploads/avatars/${file.filename}`,
    };
  }

  @ApiBearerAuth()
  @Permissions(Permission.USER_MANAGE)
  @Post('users')
  @ApiOperation({ summary: 'Create a new staff / user' })
  @ApiBody({ schema: CreateUserBodySchema })
  @ApiResponse({
    status: 201,
    description: 'User created successfully',
    schema: UserResponseSchema,
  })
  async createUser(
    @Req() req: any,
    @Body() body: any,
  ) {
    const user = req.user;

    // Validate role input type and restrict super-admin creation
    if (body.role !== undefined && body.role !== null) {
      if (typeof body.role !== 'string') {
        throw new BadRequestException('Role must be a valid string');
      }
      if (body.role.trim().toLowerCase() === Role.SUPER_ADMIN && user.role !== Role.SUPER_ADMIN) {
        throw new ForbiddenException('Access denied: Only super admins can create super admin accounts.');
      }
    }

    let bId = body.businessId;
    if (user.role !== Role.SUPER_ADMIN) {
      bId = user.businessId;
      // A non-super admin cannot assign a business they don't own.
      if (body.businessId && body.businessId !== user.businessId) {
        throw new ForbiddenException('Access denied: You can only create users within your own business.');
      }
    }
    return this.authService.register(
      body.email,
      body.password,
      body.name,
      body.role,
      bId,
      body.branchIds,
      body.createdById || user.id,
      body.phone,
      body.avatar,
      body.address,
      body.isActive !== undefined ? body.isActive : true,
    );
  }

  @ApiBearerAuth()
  @Permissions(Permission.USER_MANAGE)
  @Get('users/:id')
  @ApiOperation({ summary: 'Get user details by ID' })
  @ApiParam({ name: 'id', description: 'User UUID' })
  @ApiResponse({
    status: 200,
    description: 'User details retrieved successfully',
    schema: UserResponseSchema,
  })
  async getUserById(@Req() req: any, @Param('id') id: string) {
    const user = req.user;
    const businessId = user.role !== Role.SUPER_ADMIN ? user.businessId : undefined;
    return this.authService.getUserById(id, businessId);
  }

  @ApiBearerAuth()
  @Permissions(Permission.USER_MANAGE)
  @Put('users/:id')
  @ApiOperation({ summary: 'Update existing user profile or role/branches' })
  @ApiParam({ name: 'id', description: 'User UUID' })
  @ApiBody({ schema: UpdateUserBodySchema })
  @ApiResponse({
    status: 200,
    description: 'User updated successfully',
    schema: UserResponseSchema,
  })
  async updateUser(
    @Req() req: any,
    @Param('id') id: string,
    @Body() body: any,
  ) {
    const user = req.user;

    // Validate role input type and restrict super-admin promotion
    if (body.role !== undefined && body.role !== null) {
      if (typeof body.role !== 'string') {
        throw new BadRequestException('Role must be a valid string');
      }
      if (body.role.trim().toLowerCase() === Role.SUPER_ADMIN && user.role !== Role.SUPER_ADMIN) {
        throw new ForbiddenException('Access denied: Only super admins can grant the super admin role.');
      }
    }

    if (user.role !== Role.SUPER_ADMIN) {
      const targetUsers = await this.authService.getUsers(user.businessId);
      const target = targetUsers.find(u => u.id === id);
      if (!target) {
        throw new ForbiddenException('Access denied: You can only update users of your own business.');
      }
      // A non-super admin cannot promote a user to super-admin, nor demote one.
      if (target.role === Role.SUPER_ADMIN) {
        throw new ForbiddenException('Access denied: You cannot modify a super admin account.');
      }
      body.businessId = user.businessId;
    }
    return this.authService.updateUser(id, body);
  }

  @ApiBearerAuth()
  @Permissions(Permission.USER_MANAGE)
  @Delete('users/:id')
  @ApiOperation({ summary: 'Delete user account' })
  @ApiParam({ name: 'id', description: 'User UUID' })
  @ApiResponse({
    status: 200,
    description: 'User deleted successfully',
    schema: DeleteUserResponseSchema,
  })
  async deleteUser(
    @Req() req: any,
    @Param('id') id: string,
  ) {
    const user = req.user;

    // Prevent users from deleting their own account.
    if (user.id === id) {
      throw new BadRequestException('You cannot delete your own account.');
    }

    if (user.role !== Role.SUPER_ADMIN) {
      const targetUsers = await this.authService.getUsers(user.businessId);
      const target = targetUsers.find(u => u.id === id);
      if (!target) {
        throw new ForbiddenException('Access denied: You can only delete users of your own business.');
      }
      if (target.role === Role.SUPER_ADMIN) {
        throw new ForbiddenException('Access denied: You cannot delete a super admin account.');
      }
    } else {
      // Protect against deleting the last remaining super-admin.
      const isLastSuperAdmin = await this.authService.isLastSuperAdmin(id);
      if (isLastSuperAdmin) {
        throw new BadRequestException('You cannot delete the last remaining super admin account.');
      }
    }
    return this.authService.deleteUser(id);
  }
}
