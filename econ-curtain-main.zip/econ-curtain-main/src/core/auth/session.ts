import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { AUTH_CONSTANTS } from "./constants";

export interface SessionPayload {
  userId: string;
  email: string;
  name: string;
  role: string;
  expiresAt: number;
}

export class SessionManager {
  private static readonly SECRET = new TextEncoder().encode(AUTH_CONSTANTS.JWT_SECRET);

  /**
   * Generates a signed JWT session token
   */
  static async createToken(user: { id: string; email: string; name: string; role: string }): Promise<string> {
    const expiresAt = Math.floor(Date.now() / 1000) + AUTH_CONSTANTS.SESSION_MAX_AGE_SECONDS;

    return new SignJWT({
      userId: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      expiresAt,
    })
      .setProtectedHeader({ alg: "HS256" })
      .setIssuedAt()
      .setExpirationTime(`${AUTH_CONSTANTS.SESSION_MAX_AGE_SECONDS}s`)
      .sign(this.SECRET);
  }

  /**
   * Verifies and decodes a signed JWT session token
   */
  static async verifyToken(token: string): Promise<SessionPayload | null> {
    if (!token) return null;
    try {
      const { payload } = await jwtVerify(token, this.SECRET, {
        algorithms: ["HS256"],
      });
      return payload as unknown as SessionPayload;
    } catch {
      return null;
    }
  }

  /**
   * Sets session cookie on a NextResponse object
   */
  static attachCookieToResponse(response: NextResponse, token: string): void {
    const isProduction = process.env.NODE_ENV === "production";
    response.cookies.set({
      name: AUTH_CONSTANTS.SESSION_COOKIE_NAME,
      value: token,
      httpOnly: true, // XSS Mitigation: Prevents client-side script access
      secure: isProduction && process.env.ENABLE_HTTPS === "true", // Secure in HTTPS production, compatible with LAN IP testing
      sameSite: "lax",
      path: "/",
      maxAge: AUTH_CONSTANTS.SESSION_MAX_AGE_SECONDS,
    });
  }

  /**
   * Clears session cookie on a NextResponse object
   */
  static clearCookieOnResponse(response: NextResponse): void {
    const isProduction = process.env.NODE_ENV === "production";
    response.cookies.set({
      name: AUTH_CONSTANTS.SESSION_COOKIE_NAME,
      value: "",
      path: "/",
      maxAge: 0,
      expires: new Date(0),
      httpOnly: true,
      secure: isProduction && process.env.ENABLE_HTTPS === "true",
      sameSite: "lax",
    });
  }

  /**
   * Reads current authenticated session from server request cookies
   */
  static async getCurrentSession(): Promise<SessionPayload | null> {
    try {
      const cookieStore = await cookies();
      const token = cookieStore.get(AUTH_CONSTANTS.SESSION_COOKIE_NAME)?.value;
      if (!token) return null;
      return await this.verifyToken(token);
    } catch {
      return null;
    }
  }
}
