import { Controller, Get, Post, Put, Delete, Patch, Body, Param, UseGuards } from '@nestjs/common';
import { AuthService } from '../auth/auth.service';
import { BusinessService } from '../business/business.service';
import { SuperAnalyticsService } from './super-analytics.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';

@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(Role.SUPER_ADMIN)
@Controller('super')
export class SuperController {
  constructor(
    private readonly authService: AuthService,
    private readonly businessService: BusinessService,
    private readonly analyticsService: SuperAnalyticsService,
  ) {}

  @Get('analytics/overview')
  async getAnalyticsOverview() {
    return this.analyticsService.getOverview();
  }

  @Get('analytics/trends')
  async getAnalyticsTrends() {
    return this.analyticsService.getTrends();
  }

  @Get('businesses')
  async getBusinesses() {
    return this.businessService.getAllBusinesses();
  }

  @Patch('businesses/:id/status')
  async toggleBusinessStatus(
    @Param('id') id: string,
    @Body() body: { isActive: boolean; updatedById?: string },
  ) {
    return this.businessService.toggleBusinessStatus(id, body.isActive, body.updatedById);
  }

  @Get('users')
  async getUsers() {
    return this.authService.getUsers();
  }

  @Post('users')
  async createUser(@Body() body: any) {
    return this.authService.register(
      body.email,
      body.password,
      body.name,
      body.role,
      body.businessId,
      body.branchIds,
      body.createdById,
    );
  }

  @Put('users/:id')
  async updateUser(@Param('id') id: string, @Body() body: any) {
    return this.authService.updateUser(id, body);
  }

  @Delete('users/:id')
  async deleteUser(@Param('id') id: string) {
    return this.authService.deleteUser(id);
  }
}
