"use server";

import { prisma } from "@/lib/db";
import { getSession } from "@/lib/session";
import { revalidatePath } from "next/cache";

export async function markNotificationRead(id: number) {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    await prisma.notification.updateMany({
      where: { id, userId: session.userId },
      data: { isRead: true },
    });

    revalidatePath("/dashboard", "layout");
    return { success: true };
  } catch (error) {
    console.error("Failed to mark notification read:", error);
    return { error: "Failed to update notification" };
  }
}

export async function markAllNotificationsRead() {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    await prisma.notification.updateMany({
      where: { userId: session.userId, isRead: false },
      data: { isRead: true },
    });

    revalidatePath("/dashboard", "layout");
    return { success: true };
  } catch (error) {
    console.error("Failed to mark all notifications read:", error);
    return { error: "Failed to update notifications" };
  }
}
