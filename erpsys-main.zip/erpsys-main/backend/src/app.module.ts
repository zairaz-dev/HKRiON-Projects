import { Module } from '@nestjs/common';
import { APP_GUARD, APP_INTERCEPTOR, APP_FILTER } from '@nestjs/core';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { PrismaExceptionFilter } from './common/filters/prisma-exception.filter';
import { AuthModule } from './modules/auth/auth.module';
import { RolesModule } from './modules/roles/roles.module';
import { BusinessModule } from './modules/business/business.module';
import { PrismaModule } from './modules/prisma/prisma.module';
import { CountryModule } from './modules/country/country.module';
import { CurrencyModule } from './modules/currency/currency.module';
import { PhoneCodeModule } from './modules/phone-code/phone-code.module';
import { BranchesModule } from './modules/branches/branches.module';
import { CategoriesModule } from './modules/categories/categories.module';
import { BrandsModule } from './modules/brands/brands.module';
import { UnitsModule } from './modules/units/units.module';
import { VariationsModule } from './modules/variations/variations.module';
import { SellingPriceGroupsModule } from './modules/selling-price-groups/selling-price-groups.module';
import { WarrantiesModule } from './modules/warranties/warranties.module';
import { ProductsModule } from './modules/products/products.module';
import { CustomerGroupsModule } from './modules/customer-groups/customer-groups.module';
import { CustomersModule } from './modules/customers/customers.module';
import { SuppliersModule } from './modules/suppliers/suppliers.module';
import { ExpenseCategoriesModule } from './modules/expense-categories/expense-categories.module';
import { PaymentMethodsModule } from './modules/payment-methods/payment-methods.module';
import { ExpensesModule } from './modules/expenses/expenses.module';
import { TaxesModule } from './modules/taxes/taxes.module';
import { PurchasesModule } from './modules/purchases/purchases.module';
import { SupplierPaymentsModule } from './modules/supplier-payments/supplier-payments.module';
import { SupplierAdvancesModule } from './modules/supplier-advances/supplier-advances.module';
import { PosModule } from './modules/pos/pos.module';
import { QuotationsModule } from './modules/quotations/quotations.module';
import { CustomerPaymentsModule } from './modules/customer-payments/customer-payments.module';
import { SuperModule } from './modules/super/super.module';
import { StockAdjustmentsModule } from './modules/stock-adjustments/stock-adjustments.module';
import { StockTransfersModule } from './modules/stock-transfers/stock-transfers.module';
import { SalesReturnsModule } from './modules/sales-returns/sales-returns.module';
import { ReportsModule } from './modules/reports/reports.module';
import { DashboardModule } from './modules/dashboard/dashboard.module';
import { InvoiceSettingsModule } from './modules/invoice-settings/invoice-settings.module';
import { PrefixSettingsModule } from './modules/prefix-settings/prefix-settings.module';
import { PosSettingsModule } from './modules/pos-settings/pos-settings.module';
import { ProductSettingsModule } from './modules/product-settings/product-settings.module';
import { SmsSettingsModule } from './modules/sms-settings/sms-settings.module';
import { EmailSettingsModule } from './modules/email-settings/email-settings.module';
import { ImeiModule } from './modules/imei/imei.module';
import { PlansModule } from './modules/plans/plans.module';
import { SubscriptionsModule } from './modules/subscriptions/subscriptions.module';
import { SuperSettingsModule } from './modules/super-settings/super-settings.module';
import { CmsModule } from './modules/cms/cms.module';
import { AiModule } from './modules/ai/ai.module';
import { SearchModule } from './modules/search/search.module';

import { JwtAuthGuard } from './common/guards/jwt-auth.guard';
import { RolesGuard } from './common/guards/roles.guard';
import { PermissionsGuard } from './common/guards/permissions.guard';
import { TenantInterceptor } from './common/interceptors/tenant.interceptor';

@Module({
  imports: [
    PrismaModule,
    AuthModule,
    RolesModule,
    BusinessModule,
    CountryModule,
    CurrencyModule,
    PhoneCodeModule,
    BranchesModule,
    CategoriesModule,
    BrandsModule,
    UnitsModule,
    VariationsModule,
    SellingPriceGroupsModule,
    WarrantiesModule,
    ProductsModule,
    CustomerGroupsModule,
    CustomersModule,
    SuppliersModule,
    ExpenseCategoriesModule,
    PaymentMethodsModule,
    ExpensesModule,
    TaxesModule,
    PurchasesModule,
    SupplierPaymentsModule,
    SupplierAdvancesModule,
    PosModule,
    QuotationsModule,
    CustomerPaymentsModule,
    SuperModule,
    StockAdjustmentsModule,
    StockTransfersModule,
    SalesReturnsModule,
    ReportsModule,
    DashboardModule,
    InvoiceSettingsModule,
    PrefixSettingsModule,
    PosSettingsModule,
    ProductSettingsModule,
    SmsSettingsModule,
    EmailSettingsModule,
    ImeiModule,
    PlansModule,
    SubscriptionsModule,
    SuperSettingsModule,
    CmsModule,
    AiModule,
    SearchModule,
  ],
  controllers: [AppController],
  providers: [
    AppService,
    {
      provide: APP_GUARD,
      useClass: JwtAuthGuard,
    },
    {
      provide: APP_GUARD,
      useClass: RolesGuard,
    },
    {
      provide: APP_GUARD,
      useClass: PermissionsGuard,
    },
    {
      provide: APP_INTERCEPTOR,
      useClass: TenantInterceptor,
    },
    {
      provide: APP_FILTER,
      useClass: PrismaExceptionFilter,
    },
  ],
})
export class AppModule {}

