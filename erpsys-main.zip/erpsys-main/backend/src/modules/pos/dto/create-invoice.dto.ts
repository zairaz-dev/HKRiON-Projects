export class CreateInvoiceLineDto {
  variantId: string;
  quantity: number;
  unitPrice: number;
  discountAmount?: number;
  taxAmount?: number;
  imeiNumber?: string;
  imeis?: string[];
}

export class CreateInvoicePaymentDto {
  amount: number;
  paymentMethodId: string;
  transactionNo?: string;
  notes?: string;
}

export class CreateInvoiceDto {
  invoiceNumber?: string;
  saleDate?: string;
  customerId: string;
  branchId: string;
  businessId: string;
  discountType?: string;
  discountAmount?: number;
  taxAmount?: number;
  grandTotal: number;
  notes?: string;
  createdById?: string;
  status?: 'HOLD' | 'DRAFT' | 'FINAL';
  
  saleLines: CreateInvoiceLineDto[];
  payments: CreateInvoicePaymentDto[];
  useAdvance?: boolean;
}
