import { z } from "zod";

export const customerPaymentFormSchema = z.object({
  amount: z.number().positive("Amount must be greater than zero"),
  paymentDate: z.string().min(1, "Payment date is required"),
  paymentMethodId: z.string().min(1, "Payment method is required"),
  transactionNo: z.string().optional(),
  notes: z.string().optional(),
});

export type CustomerPaymentFormSchema = z.infer<typeof customerPaymentFormSchema>;
