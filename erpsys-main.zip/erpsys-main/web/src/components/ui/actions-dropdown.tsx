"use client";

import React, { useState, useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

export interface ActionItem {
  label?: string;
  onClick?: () => void;
  icon?: React.ReactNode;
  variant?: "default" | "destructive";
  isDivider?: boolean;
}

interface ActionsDropdownProps {
  actions: ActionItem[];
  label?: string;
  className?: string;
  align?: "left" | "right";
}

export function ActionsDropdown({
  actions,
  label = "Actions",
  className,
  align = "right",
}: ActionsDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [coords, setCoords] = useState<{ top: number; left: number } | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  const updatePosition = () => {
    if (triggerRef.current) {
      const rect = triggerRef.current.getBoundingClientRect();
      const dropdownWidth = 192; // 192px matches w-48
      const leftPos =
        align === "right"
          ? rect.right + window.scrollX - dropdownWidth
          : rect.left + window.scrollX;

      setCoords({
        top: rect.bottom + window.scrollY + 6,
        left: Math.max(10, leftPos),
      });
    }
  };

  useEffect(() => {
    if (isOpen) {
      const handle = requestAnimationFrame(() => {
        updatePosition();
      });

      window.addEventListener("scroll", updatePosition, true);
      window.addEventListener("resize", updatePosition);

      return () => {
        cancelAnimationFrame(handle);
        window.removeEventListener("scroll", updatePosition, true);
        window.removeEventListener("resize", updatePosition);
      };
    }
  }, [isOpen]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node) &&
        !(event.target as Element).closest(".actions-dropdown-portal")
      ) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className={cn("relative inline-block text-left", className)} ref={containerRef}>
      <button
        ref={triggerRef}
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "inline-flex items-center justify-center gap-1.5 px-2.5 py-1 text-[11px] font-semibold rounded-md transition-all border shadow-xs",
          "bg-card text-primary border-border hover:bg-accent hover:border-primary/40 hover:text-primary",
          "dark:bg-card/80 dark:border-border/80 dark:text-primary dark:hover:bg-accent",
          "focus:outline-none focus:ring-2 focus:ring-primary/20 active:scale-95",
          isOpen && "bg-accent border-primary/40"
        )}
      >
        <span>{label}</span>
        <ChevronDown className={cn("h-3 w-3 transition-transform duration-200 opacity-80", isOpen && "rotate-180 opacity-100")} />
      </button>

      {isOpen && coords &&
        createPortal(
          <>
            {/* Backdrop overlay for closing on click-outside */}
            <div
              className="fixed inset-0 z-50 actions-dropdown-portal"
              onClick={() => setIsOpen(false)}
            />
            {/* Popover content card using fixed positioning */}
            <div
              className="absolute z-50 w-44 rounded-lg border border-border bg-popover p-1 shadow-xl backdrop-blur-md animate-in fade-in slide-in-from-top-1 duration-150 actions-dropdown-portal text-popover-foreground"
              style={{
                top: `${coords.top}px`,
                left: `${coords.left}px`,
              }}
            >
              <div className="py-0.5 space-y-0.5">
                {actions.map((action, idx) => {
                  if (action.isDivider || !action.label) {
                    return (
                      <div key={idx} className="my-1 border-t border-border/60" />
                    );
                  }

                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        if (action.onClick) action.onClick();
                        setIsOpen(false);
                      }}
                      className={cn(
                        "flex w-full items-center gap-2 px-2.5 py-1.5 text-[11px] rounded-md font-medium text-left transition-colors",
                        action.variant === "destructive"
                          ? "text-destructive hover:bg-destructive/10 dark:text-rose-400 dark:hover:bg-rose-500/10"
                          : "text-foreground/90 hover:bg-accent hover:text-accent-foreground"
                      )}
                    >
                      {action.icon && <span className="h-3.5 w-3.5 text-muted-foreground shrink-0">{action.icon}</span>}
                      <span>{action.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </>,
          document.body
        )
      }
    </div>
  );
}
