import {
  Controller,
  Get,
  Post,
  Put,
  Patch,
  Body,
  Param,
  UseGuards,
  BadRequestException,
  UseInterceptors,
  UploadedFile,
} from '@nestjs/common';
import { SubscriptionsService } from './subscriptions.service';
import { UpgradeSubscriptionDto } from './dto/upgrade-subscription.dto';
import { UpdateSubscriptionStatusDto } from './dto/update-status.dto';
import { SubmitBankTransferDto } from './dto/submit-bank-transfer.dto';
import { UpdateSaasBankSettingDto } from './dto/update-bank-setting.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Public } from '../../common/decorators/public.decorator';
import { BillingInterval } from '@prisma/client';
import { FileInterceptor } from '@nestjs/platform-express';
import { getImageUploadOptions } from '../../common/utils/upload.util';

@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('subscriptions')
export class SubscriptionsController {
  constructor(private readonly subscriptionsService: SubscriptionsService) {}

  @Get('current')
  async getCurrentSubscription(@CurrentUser() user: any) {
    if (!user.businessId) {
      throw new BadRequestException('User does not belong to any business organization');
    }
    return this.subscriptionsService.getCurrentSubscription(user.businessId);
  }

  @Roles(Role.SUPER_ADMIN)
  @Post('upgrade')
  async upgradePlan(@CurrentUser() user: any, @Body() dto: UpgradeSubscriptionDto) {
    const targetBusinessId = (user.role === Role.SUPER_ADMIN && (dto as any).businessId) ? (dto as any).businessId : user.businessId;
    if (!targetBusinessId) {
      throw new BadRequestException('Target business organization is required');
    }
    return this.subscriptionsService.upgradePlan(targetBusinessId, dto);
  }

  // --- Bank Transfer & Proof Upload ---

  @Public()
  @Get('bank-config')
  async getSaasBankConfig() {
    return this.subscriptionsService.getSaasBankConfig();
  }

  @Post('upload-proof')
  @UseInterceptors(FileInterceptor('file', getImageUploadOptions('subscriptions')))
  async uploadProof(@UploadedFile() file: Express.Multer.File) {
    if (!file) {
      throw new BadRequestException('No deposit proof image provided');
    }
    const relativePath = `/uploads/subscriptions/${file.filename}`;
    return {
      url: relativePath,
      filename: file.filename,
    };
  }

  @Post('bank-transfer/submit')
  async submitBankTransfer(
    @CurrentUser() user: any,
    @Body() dto: SubmitBankTransferDto,
  ) {
    if (!user.businessId) {
      throw new BadRequestException('User does not belong to any business organization');
    }
    return this.subscriptionsService.submitBankTransfer(user.businessId, dto);
  }

  // --- PayHere Online Gateway ---

  @Post('payhere/generate-params')
  async generatePayHereParams(
    @CurrentUser() user: any,
    @Body() body: { planId: string; billingInterval: BillingInterval; currency?: string },
  ) {
    if (!user.businessId) {
      throw new BadRequestException('User does not belong to any business organization');
    }
    return this.subscriptionsService.generatePayHereParams(
      user.businessId,
      body.planId,
      body.billingInterval,
      user,
      body.currency,
    );
  }

  @Public()
  @Post('payhere/notify')
  async payhereNotification(@Body() body: any) {
    return this.subscriptionsService.processPayHereNotification(body);
  }

  @Post('payhere/complete-order')
  async completePayHereOrder(
    @CurrentUser() user: any,
    @Body() body: { orderId: string; transactionId?: string },
  ) {
    if (!user.businessId) {
      throw new BadRequestException('User does not belong to any business organization');
    }
    return this.subscriptionsService.completePayHereOrder(
      user.businessId,
      body.orderId,
      body.transactionId,
    );
  }

  // --- Super Admin Portal Endpoints ---

  @Roles(Role.SUPER_ADMIN)
  @Get('super/all')
  async getAllSubscriptions() {
    return this.subscriptionsService.getAllSubscriptions();
  }

  @Roles(Role.SUPER_ADMIN)
  @Patch('super/:id/status')
  async updateSubscriptionStatus(
    @Param('id') id: string,
    @Body() dto: UpdateSubscriptionStatusDto,
  ) {
    return this.subscriptionsService.updateSubscriptionStatus(id, dto);
  }

  @Roles(Role.SUPER_ADMIN)
  @Get('super/bank-requests')
  async getBankTransferRequests() {
    return this.subscriptionsService.getBankTransferRequests();
  }

  @Roles(Role.SUPER_ADMIN)
  @Post('super/bank-requests/:id/approve')
  async approveBankTransfer(
    @Param('id') id: string,
    @CurrentUser() user: any,
  ) {
    return this.subscriptionsService.approveBankTransfer(id, user.id);
  }

  @Roles(Role.SUPER_ADMIN)
  @Post('super/bank-requests/:id/reject')
  async rejectBankTransfer(
    @Param('id') id: string,
    @CurrentUser() user: any,
    @Body() body: { reason?: string },
  ) {
    return this.subscriptionsService.rejectBankTransfer(id, body.reason || '', user.id);
  }

  @Roles(Role.SUPER_ADMIN)
  @Put('super/bank-config')
  async updateSaasBankConfig(@Body() dto: UpdateSaasBankSettingDto) {
    return this.subscriptionsService.updateSaasBankConfig(dto);
  }
}
