import { getPositions } from "@/actions/positions";
import PositionClient from "./position-client";
import { getSession } from "@/lib/session";
import { Role } from "@prisma/client";

import { redirect } from "next/navigation";

export default async function PositionsPage() {
  const session = await getSession();
  
  if (!session || session.role === Role.EMPLOYEE) {
    redirect("/dashboard");
  }

  const isAdmin = session.role === Role.MANAGER || session.role === Role.SUPER_ADMIN;

  const positionsRes = await getPositions();

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PositionClient positions={positionsRes.data || []} isAdmin={isAdmin} />
    </div>
  );
}
