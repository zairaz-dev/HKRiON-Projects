"use client";

import { motion } from "framer-motion";
import { services } from "@/data/services";
import * as Icons from "lucide-react";
import Link from "next/link";

export default function ServicesPage() {
  return (
    <div className="flex flex-col w-full bg-slate-50 min-h-screen">
      {/* Page Header */}
      <section className="bg-secondary py-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <motion.h1 
            initial={{ opacity: 1, y: 0 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-bold text-white mb-4"
          >
            Our <span className="text-primary">Services</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 1, y: 0 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-slate-300 max-w-2xl mx-auto text-lg"
          >
            From concept to completion, we offer comprehensive services to ensure your window coverings and shade systems are perfect.
          </motion.p>
        </div>
      </section>

      {/* Services List */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
            {services.map((service, index) => {
              // Dynamically get the icon component from Lucide
              const IconComponent = Icons[service.icon as keyof typeof Icons] as React.ElementType;
              
              return (
                <motion.div
                  key={service.id}
                  initial={{ opacity: 1, y: 0 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.01 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white p-8 md:p-10 rounded-3xl shadow-sm border border-slate-100 hover:shadow-xl transition-shadow group flex flex-col items-start"
                >
                  <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center text-primary mb-8 group-hover:bg-primary group-hover:text-white transition-colors duration-300">
                    {IconComponent && <IconComponent size={32} />}
                  </div>
                  <h2 className="text-2xl font-bold text-secondary mb-4">{service.title}</h2>
                  <p className="text-slate-600 text-lg leading-relaxed grow">
                    {service.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 4-Step Process Section */}
      <section className="py-20 bg-white border-t border-slate-100 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4">How It Works</h2>
            <div className="w-20 h-1 bg-primary mx-auto rounded-full mb-6"></div>
            <p className="text-slate-600 max-w-2xl mx-auto text-lg">Our streamlined process ensures a hassle-free experience from your first inquiry to final installation.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 relative">
            {/* Connecting Line (Desktop) */}
            <div className="hidden md:block absolute top-1/2 left-0 right-0 h-0.5 bg-slate-100 -translate-y-1/2 z-0"></div>
            
            {[
              { step: "01", title: "Inquiry", desc: "Contact us to discuss your requirements." },
              { step: "02", title: "Consultation", desc: "Free site measurement and design advice." },
              { step: "03", title: "Quotation", desc: "Detailed, transparent pricing with no hidden costs." },
              { step: "04", title: "Installation", desc: "Professional fitting by our expert team." },
            ].map((item, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 1, scale: 1 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true, amount: 0.01 }}
                transition={{ delay: index * 0.15 }}
                className="relative z-10 flex flex-col items-center text-center bg-white p-6 rounded-xl"
              >
                <div className="w-16 h-16 bg-white border-4 border-primary rounded-full flex items-center justify-center text-2xl font-bold text-primary mb-6 shadow-sm">
                  {item.step}
                </div>
                <h3 className="text-xl font-bold text-secondary mb-3">{item.title}</h3>
                <p className="text-slate-600">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-secondary text-center px-4 relative overflow-hidden">
        <div className="absolute inset-0 opacity-5 bg-[url('/gallery_3.png')] bg-cover bg-center" />
        <div className="relative z-10 max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Ready to Get Started?</h2>
          <p className="text-slate-300 text-lg mb-10">Book your free site measurement and consultation today.</p>
          <Link href="/contact" className="inline-block px-8 py-4 bg-primary text-white rounded-full font-semibold hover:bg-yellow-600 transition-colors shadow-lg">
            Book an Appointment
          </Link>
        </div>
      </section>
    </div>
  );
}
