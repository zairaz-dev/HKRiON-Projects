"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { useCart } from "@/features/cart/context/CartContext";
import { useWishlist } from "@/features/wishlist/context/WishlistContext";
import { useCMS } from "@/features/cms/useCMS";
import { useAuth } from "@/features/auth/context/AuthContext";
import { isHeroRoute } from "@/lib/constants/site";
import {
  BagIcon,
  HeartIcon,
  UserIcon,
  MenuIcon,
  CloseIcon,
} from "@/components/ui/LuxuryIcons";

interface HeaderProps {
  initialIsLoggedIn?: boolean;
  initialRole?: "ADMIN" | "CUSTOMER" | null;
}

export function Header({ initialIsLoggedIn = false, initialRole = null }: HeaderProps) {
  const pathname = usePathname();
  const { toggleCart, itemCount } = useCart();
  const { wishlistCount } = useWishlist();
  const { user, isAuthenticated } = useAuth();
  const { getBlock } = useCMS();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Synchronously compute auth state on both server (via cookies) and client (via AuthContext / localStorage)
  const isUserLoggedIn = user ? isAuthenticated : initialIsLoggedIn;
  const activeRole = user?.role || initialRole;
  const userDashboardHref = activeRole === "ADMIN" ? "/admindashboard" : "/account";

  const headerLogo = getBlock("branding.header_logo", "/faizan-gems-logo.png");

  // Close mobile menu on route change
  const [prevPathname, setPrevPathname] = useState(pathname);
  if (prevPathname !== pathname) {
    setPrevPathname(pathname);
    setMobileMenuOpen(false);
  }

  // Prevent background scrolling when mobile menu is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileMenuOpen]);

  // Escape key to close mobile menu
  useEffect(() => {
    if (!mobileMenuOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMobileMenuOpen(false);
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [mobileMenuOpen]);

  // Scroll detection for dynamic navbar background transition
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setIsScrolled(window.scrollY > 20);
  }, [pathname]);

  const isHeroPage = isHeroRoute(pathname);
  const isTransparent = isHeroPage && !isScrolled;

  const navLinks = [
    { label: "Home", href: "/" },
    { label: "Gemstones", href: "/shop" },
    { label: "Collections", href: "/collections" },
    { label: "About", href: "/about" },
    { label: "Contacts", href: "/contact" },
  ];

  return (
    <>
      {/* Main Luxury Navigation Bar */}
      <header
        className={`sticky top-0 z-40 w-full transition-all duration-500 ease-in-out ${
          isTransparent
            ? "luxury-glass-nav-transparent"
            : "luxury-glass-nav-scrolled"
        }`}
      >
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-20 flex items-center justify-between relative">
          {/* Left: Mobile Hamburger & Logo */}
          <div className="flex items-center gap-1 sm:gap-4">
            <div className="flex items-center lg:hidden">
              <button
                onClick={() => setMobileMenuOpen(true)}
                aria-label="Open navigation menu"
                className="min-w-[44px] min-h-[44px] flex items-center justify-center p-2.5 -ml-2 text-white hover:text-[#C5A880] transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#C5A880]"
              >
                <MenuIcon className="w-6 h-6" />
              </button>
            </div>

            <div className="py-1 translate-y-0.5 sm:translate-y-1">
              <Link
                href="/"
                className="inline-flex items-center justify-center transition-opacity hover:opacity-85 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#C5A880]"
                aria-label="Faizan Gems - Shine With Elegance"
              >
                <Image
                  src={headerLogo}
                  alt="Faizan Gems"
                  width={240}
                  height={60}
                  className="h-8 sm:h-11 md:h-12 w-auto object-contain max-w-[150px] sm:max-w-none"
                  priority
                  unoptimized
                />
              </Link>
            </div>
          </div>

          {/* Center: Desktop Nav Links (Absolute Centering for Zero Layout Shift) */}
          <nav className="hidden lg:flex items-center space-x-7 absolute left-1/2 -translate-x-1/2">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`text-xs uppercase tracking-luxury font-sans transition-colors relative py-1 focus-visible:outline-none focus-visible:text-[#C5A880] ${
                  pathname === link.href
                    ? "text-white font-medium after:absolute after:bottom-0 after:left-0 after:right-0 after:h-[1.5px] after:bg-[#C5A880]"
                    : "text-[#D3CBBF] hover:text-[#C5A880]"
                }`}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Action Icons (Wishlist, Bag, Account) */}
          <div className="flex items-center space-x-0.5 sm:space-x-2">
            {/* Wishlist */}
            <Link
              href="/wishlist"
              aria-label="Saved Vault Items"
              className="min-w-[44px] min-h-[44px] flex items-center justify-center p-2 text-[#E7E2D7] hover:text-[#C5A880] transition-colors relative focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#C5A880]"
            >
              <HeartIcon className="w-5 h-5" />
              {wishlistCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-[#C5A880] text-black text-[9px] font-mono font-bold rounded-full flex items-center justify-center pointer-events-none">
                  {wishlistCount}
                </span>
              )}
            </Link>

            {/* Bag */}
            <button
              onClick={toggleCart}
              aria-label="Shopping bag"
              className="min-w-[44px] min-h-[44px] flex items-center justify-center p-2 text-[#E7E2D7] hover:text-[#C5A880] transition-colors relative focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#C5A880]"
            >
              <BagIcon className="w-5 h-5" />
              {itemCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-[#C5A880] text-black text-[9px] font-mono font-bold rounded-full flex items-center justify-center pointer-events-none">
                  {itemCount}
                </span>
              )}
            </button>

            {/* Account / Login Action */}
            {isUserLoggedIn ? (
              <Link
                href={userDashboardHref}
                aria-label={activeRole === "ADMIN" ? "Admin Dashboard" : "Client Portal"}
                title={activeRole === "ADMIN" ? "Admin Dashboard" : "Client Portal"}
                className="min-w-[44px] min-h-[44px] flex items-center justify-center p-2 text-[#E7E2D7] hover:text-[#C5A880] transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#C5A880]"
              >
                <UserIcon className="w-5 h-5" />
              </Link>
            ) : (
              <Link
                href="/login"
                aria-label="Sign In to Client Vault"
                className="min-h-[40px] px-2.5 sm:px-3.5 py-1.5 border border-white/20 hover:border-[#C5A880] text-[#D3CBBF] hover:text-[#C5A880] rounded-sm text-[10px] sm:text-[11px] uppercase tracking-luxury font-sans font-medium transition-colors select-none whitespace-nowrap flex items-center justify-center focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#C5A880]"
              >
                Sign In
              </Link>
            )}
          </div>
        </div>
      </header>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Mobile Navigation Menu"
          className="fixed inset-0 z-50 flex bg-black/70 backdrop-blur-sm lg:hidden animate-luxury-backdrop"
          onClick={() => setMobileMenuOpen(false)}
        >
          <div
            className="w-[85%] max-w-sm bg-black text-white h-full shadow-2xl pt-[max(1.25rem,env(safe-area-inset-top))] pb-[max(1.25rem,env(safe-area-inset-bottom))] pl-[max(1.25rem,env(safe-area-inset-left))] pr-5 sm:px-6 flex flex-col justify-between overflow-y-auto border-r border-white/10 animate-luxury-drawer-left"
            onClick={(e) => e.stopPropagation()}
          >
            <div>
              {/* Drawer Header */}
              <div className="flex items-center justify-between pb-5 border-b border-white/10">
                <Link
                  href="/"
                  onClick={() => setMobileMenuOpen(false)}
                  className="inline-flex items-center"
                >
                  <Image
                    src={headerLogo}
                    alt="Faizan Gems"
                    width={180}
                    height={45}
                    className="h-9 sm:h-10 w-auto object-contain"
                    unoptimized
                  />
                </Link>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  aria-label="Close navigation menu"
                  className="min-w-[44px] min-h-[44px] flex items-center justify-center -mr-2 text-[#8C867D] hover:text-white transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#C5A880]"
                >
                  <CloseIcon className="w-5 h-5" />
                </button>
              </div>

              {/* Navigation Links with 44px+ touch targets */}
              <div className="py-4 space-y-1">
                {navLinks.map((link) => (
                  <Link
                    key={link.href}
                    href={link.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className="flex items-center min-h-[44px] text-sm uppercase tracking-luxury font-sans text-[#E7E2D7] hover:text-[#C5A880] py-3 border-b border-white/10 transition-colors focus-visible:outline-none focus-visible:text-[#C5A880]"
                  >
                    {link.label}
                  </Link>
                ))}
                <Link
                  href="/wishlist"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center justify-between min-h-[44px] text-sm uppercase tracking-luxury font-sans text-[#E7E2D7] hover:text-[#C5A880] py-3 border-b border-white/10 transition-colors focus-visible:outline-none focus-visible:text-[#C5A880]"
                >
                  <span>Saved Vault Specimens</span>
                  {wishlistCount > 0 && (
                    <span className="px-2 py-0.5 bg-[#C5A880] text-black text-[10px] font-mono font-bold rounded-full">
                      {wishlistCount}
                    </span>
                  )}
                </Link>
                {isUserLoggedIn ? (
                  <Link
                    href={userDashboardHref}
                    onClick={() => setMobileMenuOpen(false)}
                    className="flex items-center min-h-[44px] text-sm uppercase tracking-luxury font-sans text-[#E7E2D7] hover:text-[#C5A880] py-3 border-b border-white/10 transition-colors focus-visible:outline-none focus-visible:text-[#C5A880]"
                  >
                    {activeRole === "ADMIN" ? "Admin Dashboard" : "Client Portal"}
                  </Link>
                ) : (
                  <Link
                    href="/login"
                    onClick={() => setMobileMenuOpen(false)}
                    className="flex items-center min-h-[44px] text-sm uppercase tracking-luxury font-sans text-[#E7E2D7] hover:text-[#C5A880] py-3 border-b border-white/10 transition-colors focus-visible:outline-none focus-visible:text-[#C5A880]"
                  >
                    Sign In / Register
                  </Link>
                )}
              </div>
            </div>

            {/* Mobile Drawer Footer */}
            <div className="pt-5 border-t border-white/10 text-xs font-sans text-[#8C867D] space-y-1.5">
              <p className="text-[#D3CBBF]">Trincomalee • Sri Lanka</p>
              <p className="text-[11px] text-[#C5A880]">GIA, Gübelin, SSEF & GRS Certified</p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
