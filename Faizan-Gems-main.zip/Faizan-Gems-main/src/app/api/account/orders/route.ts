import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import pool from "@/lib/db";
import { RowDataPacket } from "mysql2";
import {
  verifyCustomerSessionToken,
  CUSTOMER_SESSION_COOKIE_NAME,
} from "@/lib/auth";

export async function GET() {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get(CUSTOMER_SESSION_COOKIE_NAME)?.value;

    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const session = verifyCustomerSessionToken(token);
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Fetch all orders matching this client's email
    const [rows] = await pool.query<RowDataPacket[]>(
      "SELECT * FROM orders WHERE client_email = ? ORDER BY created_at DESC",
      [session.email]
    );

    const orders = rows.map((order) => {
      let items = [];
      try {
        items = typeof order.items === "string" ? JSON.parse(order.items) : (order.items || []);
      } catch {
        items = [];
      }

      return {
        id: order.order_number || order.id,
        orderNumber: order.order_number,
        date: order.created_at
          ? new Date(order.created_at).toLocaleDateString("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric",
            })
          : "Recently",
        status: order.status || "pending_verification",
        courier: order.courier || "Ferrari Logistics Armored Air",
        trackingNumber: order.tracking_number,
        paymentMethod: order.payment_method || "wire",
        bankReference: (items[0] as any)?.bankReference || order.bank_reference || null,
        paymentSlipUrl: (items[0] as any)?.paymentSlipUrl || order.payment_slip || null,
        total: Number(order.total || 0),
        subtotal: Number(order.subtotal || 0),
        currency: order.currency || "USD",
        items,
        primaryItemName:
          items[0]?.gemstone?.name || items[0]?.name || "Natural Certified Gemstone",
        primaryItemCarat: Number(items[0]?.gemstone?.carat || items[0]?.carat || 0),
        primaryItemImage:
          items[0]?.gemstone?.images?.[0] || null,
        destination: [order.city, order.country].filter(Boolean).join(", ") || "Client Vault",
      };
    });

    return NextResponse.json({ success: true, orders });
  } catch (error) {
    console.error("Account orders fetch error:", error);
    return NextResponse.json({ error: "Failed to fetch orders" }, { status: 500 });
  }
}
