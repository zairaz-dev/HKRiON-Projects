"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";

export function PwaInstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showPrompt, setShowPrompt] = useState(false);
  const [isIos, setIsIos] = useState(false);
  const [showIosGuide, setShowIosGuide] = useState(false);

  useEffect(() => {
    // 1. If already installed as standalone PWA, never show
    if (typeof window === "undefined") return;
    const isStandalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as any).standalone === true ||
      document.referrer.includes("android-app://");

    if (isStandalone) return;

    // 2. Check if dismissed recently (within 7 days)
    try {
      const dismissedAt = localStorage.getItem("faizan_pwa_dismissed");
      if (dismissedAt && Date.now() - parseInt(dismissedAt, 10) < 7 * 24 * 60 * 60 * 1000) {
        return;
      }
    } catch {
      // ignore localStorage errors
    }

    // 3. Detect iOS Safari
    const ua = window.navigator.userAgent.toLowerCase();
    const isIosDevice = /iphone|ipad|ipod/.test(ua) && !(window as any).MSStream;
    const isSafari = /safari/.test(ua) && !/chrome|crios|fxios|edgios/.test(ua);

    if (isIosDevice) {
      setIsIos(true);
      // Wait 3 seconds before gently presenting on iOS so page loads first
      const timer = setTimeout(() => {
        setShowPrompt(true);
      }, 3500);
      return () => clearTimeout(timer);
    }

    // 4. Android / Chrome / Edge native beforeinstallprompt listener
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowPrompt(true);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    };
  }, []);

  const handleDismiss = () => {
    setShowPrompt(false);
    setShowIosGuide(false);
    try {
      localStorage.setItem("faizan_pwa_dismissed", Date.now().toString());
    } catch {
      // ignore
    }
  };

  const handleInstallClick = async () => {
    if (isIos) {
      setShowIosGuide(true);
      return;
    }

    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === "accepted") {
      setShowPrompt(false);
    }
    setDeferredPrompt(null);
  };

  if (!showPrompt) return null;

  return (
    <>
      {/* Floating Luxury PWA Install Banner */}
      <aside
        aria-label="Install App"
        className="fixed bottom-4 sm:bottom-6 left-4 right-4 sm:left-auto sm:right-6 sm:max-w-sm z-40 bg-[#141419]/95 border border-[#C5A880]/50 backdrop-blur-xl shadow-[0_16px_40px_rgba(0,0,0,0.5)] p-4 rounded-md animate-luxury-fade-up text-white"
      >
        {/* Specular Top Line Highlight */}
        <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-gradient-to-r from-transparent via-[#C5A880] to-transparent" />

        <div className="flex items-start gap-3.5">
          {/* Logo App Icon */}
          <div className="relative w-11 h-11 rounded-lg bg-black border border-[#C5A880]/40 overflow-hidden flex-shrink-0 flex items-center justify-center shadow-inner">
            <Image
              src="/favicon/apple-touch-icon.png"
              alt="Faizan Gems App"
              width={44}
              height={44}
              className="object-contain p-1"
            />
          </div>

          {/* Body Content */}
          <div className="flex-1 min-w-0 pr-1">
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C5A880]" />
              <h4 className="font-serif text-sm font-semibold tracking-wide text-white">
                Faizan Gems App
              </h4>
            </div>
            <p className="text-[11px] text-[#A69E92] font-sans leading-relaxed mt-0.5">
              {isIos
                ? "Install on your iPhone or iPad for an immersive showroom vault experience."
                : "Install the official app for instant vault access and seamless browsing."}
            </p>

            {/* Action Buttons */}
            <div className="mt-3 flex items-center gap-2">
              <button
                type="button"
                onClick={handleInstallClick}
                className="px-3.5 py-1.5 bg-gradient-to-r from-[#C5A880] to-[#DFC9A9] text-[#0D0D11] text-[11px] font-sans uppercase tracking-wider font-semibold rounded-sm shadow hover:brightness-105 transition-all"
              >
                {isIos ? "How to Install" : "Install App"}
              </button>
              <button
                type="button"
                onClick={handleDismiss}
                className="px-2.5 py-1.5 text-[11px] font-sans text-[#8C867D] hover:text-white uppercase tracking-wider transition-colors"
              >
                Not Now
              </button>
            </div>
          </div>

          {/* Dismiss Icon */}
          <button
            type="button"
            onClick={handleDismiss}
            aria-label="Dismiss install banner"
            className="text-[#8C867D] hover:text-white p-1 transition-colors -mr-1 -mt-1"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
      </aside>

      {/* iOS Step-by-Step Installation Modal */}
      {showIosGuide && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-luxury-backdrop"
          onClick={() => setShowIosGuide(false)}
        >
          <div
            className="relative w-full max-w-sm bg-[#141419] border border-[#C5A880]/50 shadow-2xl rounded-t-xl sm:rounded-md p-6 text-white animate-luxury-modal"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#C5A880]" />
                <h3 className="font-serif text-base text-white">Install on iPhone / iPad</h3>
              </div>
              <button
                onClick={() => setShowIosGuide(false)}
                aria-label="Close guide"
                className="text-[#8C867D] hover:text-white p-1"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>

            <div className="py-4 space-y-4 text-xs font-sans text-[#D3CBBF]">
              <div className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-[#C5A880]/20 text-[#C5A880] border border-[#C5A880]/40 flex items-center justify-center font-mono font-bold text-[10px] shrink-0 mt-0.5">
                  1
                </span>
                <p>
                  Tap the <strong className="text-white">Share button</strong> (
                  <svg className="w-3.5 h-3.5 inline mx-0.5 text-[#C5A880]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8" />
                    <polyline points="16 6 12 2 8 6" />
                    <line x1="12" y1="2" x2="12" y2="15" />
                  </svg>
                  ) in Safari at the bottom of your screen.
                </p>
              </div>

              <div className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-[#C5A880]/20 text-[#C5A880] border border-[#C5A880]/40 flex items-center justify-center font-mono font-bold text-[10px] shrink-0 mt-0.5">
                  2
                </span>
                <p>
                  Scroll down the share sheet and tap <strong className="text-white">Add to Home Screen</strong> (
                  <svg className="w-3.5 h-3.5 inline mx-0.5 text-[#C5A880]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
                    <line x1="12" y1="8" x2="12" y2="16" />
                    <line x1="8" y1="12" x2="16" y2="12" />
                  </svg>
                  ).
                </p>
              </div>

              <div className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-[#C5A880]/20 text-[#C5A880] border border-[#C5A880]/40 flex items-center justify-center font-mono font-bold text-[10px] shrink-0 mt-0.5">
                  3
                </span>
                <p>
                  Tap <strong className="text-white">Add</strong> in the top right corner. Faizan Gems is now installed on your home screen!
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowIosGuide(false)}
              className="w-full py-2.5 bg-[#1C1C26] hover:bg-[#252532] text-[#E0CFA9] border border-[#C5A880]/30 text-xs uppercase tracking-wider font-sans font-medium transition-colors"
            >
              Got It
            </button>
          </div>
        </div>
      )}
    </>
  );
}

export default PwaInstallPrompt;
