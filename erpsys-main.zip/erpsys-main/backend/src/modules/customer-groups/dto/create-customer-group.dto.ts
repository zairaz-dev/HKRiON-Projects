export class CreateCustomerGroupDto {
  name: string;
  percentageDiscount?: number;
  sellingPriceGroupId?: string;
  isActive?: boolean;
  businessId: string;
  branchIds?: string[];
  createdById?: string;
}
