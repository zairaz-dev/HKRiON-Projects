"use client";

import React, { useState, useEffect, useRef, MouseEvent, TouchEvent } from "react";
import Image from "next/image";
import { Rotate360Icon } from "@/components/ui/LuxuryIcons";

interface RotationViewerProps {
  frames: string[];
  gemstoneName: string;
}

export function RotationViewer({ frames, gemstoneName }: RotationViewerProps) {
  const [currentFrame, setCurrentFrame] = useState(0);
  const [isAutoSpinning, setIsAutoSpinning] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const startXRef = useRef(0);
  const startFrameRef = useRef(0);

  const totalFrames = frames.length;

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isAutoSpinning && totalFrames > 1) {
      interval = setInterval(() => {
        setCurrentFrame((prev) => (prev + 1) % totalFrames);
      }, 350);
    }
    return () => clearInterval(interval);
  }, [isAutoSpinning, totalFrames]);

  const handleMouseDown = (e: MouseEvent<HTMLDivElement>) => {
    setIsDragging(true);
    setIsAutoSpinning(false);
    startXRef.current = e.clientX;
    startFrameRef.current = currentFrame;
  };

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const deltaX = e.clientX - startXRef.current;
    const frameShift = Math.floor(deltaX / 30);
    let nextFrame = (startFrameRef.current - frameShift) % totalFrames;
    if (nextFrame < 0) nextFrame += totalFrames;
    setCurrentFrame(nextFrame);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleTouchStart = (e: TouchEvent<HTMLDivElement>) => {
    setIsDragging(true);
    setIsAutoSpinning(false);
    startXRef.current = e.touches[0].clientX;
    startFrameRef.current = currentFrame;
  };

  const handleTouchMove = (e: TouchEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const deltaX = e.touches[0].clientX - startXRef.current;
    const frameShift = Math.floor(deltaX / 25);
    let nextFrame = (startFrameRef.current - frameShift) % totalFrames;
    if (nextFrame < 0) nextFrame += totalFrames;
    setCurrentFrame(nextFrame);
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  const calculatedAngle = Math.round((currentFrame / totalFrames) * 360);

  return (
    <div className="relative select-none">
      {/* Top Header */}
      <div className="mb-2 flex items-center justify-between text-xs font-sans text-[#8C867D]">
        <span className="flex items-center gap-1.5 uppercase tracking-wider">
          <Rotate360Icon className="w-4 h-4 text-[#C5A880]" />
          Turntable Inspection ({calculatedAngle}°)
        </span>
        <button
          onClick={() => setIsAutoSpinning(!isAutoSpinning)}
          className="text-[#9A7B4F] hover:underline uppercase tracking-wider text-[11px]"
        >
          {isAutoSpinning ? "Stop Auto-Spin" : "Auto-Spin 360°"}
        </button>
      </div>

      {/* Main Interactive Stage */}
      <div
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        className="relative aspect-[4/3] w-full overflow-hidden bg-[#F7F5F1] border border-[#E8E4DC] cursor-grab active:cursor-grabbing flex items-center justify-center"
      >
        <Image
          src={frames[currentFrame]}
          alt={`${gemstoneName} Angle ${currentFrame + 1}`}
          fill
          priority
          className="object-contain p-6 pointer-events-none"
        />

        {/* Drag Indicator Overlay */}
        <div className="absolute bottom-3 inset-x-0 flex justify-center pointer-events-none">
          <div className="bg-white/90 backdrop-blur-sm border border-[#E8E4DC] px-3 py-1 text-[11px] font-sans text-[#6B655C] uppercase tracking-wider flex items-center gap-2 shadow-sm">
            <Rotate360Icon className="w-3.5 h-3.5 text-[#C5A880]" />
            <span>Click & Drag to Rotate</span>
          </div>
        </div>
      </div>

      {/* Angle Slider Bar */}
      <div className="mt-3 flex items-center gap-3">
        <span className="text-[10px] text-[#9C9488] font-mono">0°</span>
        <input
          type="range"
          min="0"
          max={totalFrames - 1}
          value={currentFrame}
          onChange={(e) => {
            setIsAutoSpinning(false);
            setCurrentFrame(parseInt(e.target.value, 10));
          }}
          className="w-full accent-[#C5A880] h-1 bg-[#E8E4DC] rounded-lg cursor-pointer"
        />
        <span className="text-[10px] text-[#9C9488] font-mono">360°</span>
      </div>
    </div>
  );
}
