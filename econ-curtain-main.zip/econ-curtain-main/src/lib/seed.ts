import { prisma } from "./prisma";
import bcrypt from "bcryptjs";
import { products } from "../data/products";

export async function seedDatabase() {
  console.log("Seeding database...");

  // 1. Seed Default Admin User
  const adminEmail = "admin@shadeitblinds.com";
  const existingAdmin = await prisma.user.findUnique({
    where: { email: adminEmail },
  });

  if (!existingAdmin) {
    const passwordHash = await bcrypt.hash("123456", 10);
    await prisma.user.create({
      data: {
        name: "Admin User",
        email: adminEmail,
        passwordHash: passwordHash,
        role: "ADMIN",
      },
    });
    console.log("Default Admin User created: admin@shadeitblinds.com / 123456");
  } else {
    console.log("Admin User already exists.");
  }

  // 2. Seed 13 Products
  for (const product of products) {
    await prisma.product.upsert({
      where: { id: product.id },
      update: {
        name: product.name,
        category: product.category,
        description: product.description,
        imageUrl: product.image,
        features: JSON.stringify(product.features),
        isActive: true,
      },
      create: {
        id: product.id,
        name: product.name,
        category: product.category,
        description: product.description,
        imageUrl: product.image,
        features: JSON.stringify(product.features),
        isActive: true,
      },
    });
  }

  console.log(`Seeded ${products.length} products successfully.`);
}

// Run if called directly
if (require.main === module) {
  seedDatabase()
    .then(() => {
      console.log("Database seed completed successfully.");
      process.exit(0);
    })
    .catch((error) => {
      console.error("Database seed failed:", error);
      process.exit(1);
    });
}
