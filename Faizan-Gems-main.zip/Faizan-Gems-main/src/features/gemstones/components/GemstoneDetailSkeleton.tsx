"use client";

import React from "react";

export function GemstoneDetailSkeleton() {
  return (
    <div className="bg-[#FAF8F5] min-h-screen py-8 lg:py-14">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb Skeleton */}
        <div className="flex items-center space-x-3 mb-8">
          <div className="w-12 h-3 bg-[#E8E4DC] rounded-xs animate-pulse" />
          <span className="text-[#8C867D]">/</span>
          <div className="w-16 h-3 bg-[#E8E4DC] rounded-xs animate-pulse" />
          <span className="text-[#8C867D]">/</span>
          <div className="w-24 h-3 bg-[#E2DDD3] rounded-xs animate-pulse" />
        </div>

        {/* Product Master Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          {/* Left Column: Media Studio Placeholder (7 Cols) */}
          <div className="lg:col-span-7 space-y-6">
            {/* Media Tabs Skeleton */}
            <div className="flex space-x-6 border-b border-[#E8E4DC] pb-2">
              <div className="w-32 h-4 bg-[#E2DDD3] rounded-xs animate-pulse" />
              <div className="w-24 h-4 bg-[#EFECE5] rounded-xs animate-pulse" />
              <div className="w-24 h-4 bg-[#EFECE5] rounded-xs animate-pulse" />
            </div>

            {/* Main Stage Image Frame with Shimmer */}
            <div className="bg-white border border-[#E8E4DC] p-4 sm:p-6 shadow-xs">
              <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#F2EFE9] border border-[#E8E4DC] animate-shimmer rounded-xs" />
              
              {/* Thumbnails Row */}
              <div className="grid grid-cols-4 sm:grid-cols-5 gap-3 mt-4">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="aspect-square bg-[#EFECE5] border border-[#E8E4DC] animate-pulse rounded-xs" />
                ))}
              </div>
            </div>

            {/* Trust Strip Skeleton */}
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-[#E8E4DC]">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="space-y-2">
                  <div className="w-8 h-8 bg-[#EFECE5] rounded-full animate-pulse" />
                  <div className="w-20 h-3 bg-[#E2DDD3] rounded-xs" />
                  <div className="w-28 h-2.5 bg-[#EFECE5] rounded-xs" />
                </div>
              ))}
            </div>
          </div>

          {/* Right Column: Specimen Details & Acquisition (5 Cols) */}
          <div className="lg:col-span-5 space-y-6">
            {/* Eyebrow & Badges */}
            <div className="space-y-2.5">
              <div className="w-40 h-5 bg-[#EFECE5] rounded-xs animate-pulse" />
              <div className="w-4/5 h-8 sm:h-10 bg-[#E2DDD3] rounded-xs animate-pulse" />
              <div className="w-3/5 h-4 bg-[#EFECE5] rounded-xs animate-pulse" />
            </div>

            {/* Price & Acquisition Box */}
            <div className="bg-white border border-[#E8E4DC] p-6 sm:p-8 space-y-6 shadow-xs">
              <div className="space-y-2 border-b border-[#F0ECE1] pb-5">
                <div className="w-20 h-3 bg-[#EFECE5] rounded-xs" />
                <div className="w-36 h-7 bg-[#E8DFC8] rounded-xs animate-pulse" />
              </div>

              {/* Weight / Variants Options */}
              <div className="space-y-3">
                <div className="w-28 h-3 bg-[#EFECE5] rounded-xs" />
                <div className="grid grid-cols-3 gap-2.5">
                  <div className="h-10 bg-[#F2EFE9] border border-[#E8E4DC] rounded-xs animate-pulse" />
                  <div className="h-10 bg-[#F2EFE9] border border-[#E8E4DC] rounded-xs animate-pulse" />
                  <div className="h-10 bg-[#F2EFE9] border border-[#E8E4DC] rounded-xs animate-pulse" />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3 pt-2">
                <div className="h-12 w-full bg-[#18181D]/80 rounded-xs animate-pulse" />
                <div className="h-11 w-full bg-[#F2EFE9] border border-[#E8E4DC] rounded-xs animate-pulse" />
              </div>
            </div>

            {/* Technical Specifications Matrix */}
            <div className="bg-white border border-[#E8E4DC] p-6 space-y-4 shadow-xs">
              <div className="w-36 h-4 bg-[#E2DDD3] rounded-xs animate-pulse border-b border-[#F0ECE1] pb-3" />
              <div className="space-y-3">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex justify-between items-center py-1.5 border-b border-[#FAF8F5]">
                    <div className="w-24 h-3 bg-[#EFECE5] rounded-xs" />
                    <div className="w-28 h-3 bg-[#E2DDD3] rounded-xs" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default GemstoneDetailSkeleton;
