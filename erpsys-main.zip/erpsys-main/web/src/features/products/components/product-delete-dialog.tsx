import React, { useState, useEffect } from "react";
import { AlertCircle, AlertTriangle, Loader2, PowerOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ProductItem } from "../types";
import { useDeleteProductMutation, useUpdateProductMutation } from "../hooks/use-products";

interface ProductDeleteDialogProps {
  isOpen: boolean;
  onClose: () => void;
  product: ProductItem | null;
  businessId: string;
  onSuccessMessage: (msg: string) => void;
  onErrorMessage: (msg: string) => void;
}

export function ProductDeleteDialog({
  isOpen,
  onClose,
  product,
  businessId,
  onSuccessMessage,
  onErrorMessage
}: ProductDeleteDialogProps) {
  const deleteMutation = useDeleteProductMutation();
  const updateMutation = useUpdateProductMutation();
  const [restrictionError, setRestrictionError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setRestrictionError(null);
    }
  }, [isOpen]);

  if (!isOpen || !product) return null;

  const handleDelete = async () => {
    try {
      setRestrictionError(null);
      await deleteMutation.mutateAsync({ id: product.id, businessId });
      onSuccessMessage(`Product "${product.name}" deleted successfully.`);
      onClose();
    } catch (err: any) {
      const errMsg = err.message || "Failed to delete product.";
      setRestrictionError(errMsg);
      onErrorMessage(errMsg);
    }
  };

  const handleDeactivate = async () => {
    try {
      await updateMutation.mutateAsync({
        id: product.id,
        productData: { isActive: false, businessId },
      });
      onSuccessMessage(`Product "${product.name}" has been deactivated successfully and hidden from sales.`);
      onClose();
    } catch (err: any) {
      onErrorMessage(err.message || "Failed to deactivate product.");
    }
  };

  const isPending = deleteMutation.isPending || updateMutation.isPending;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-md rounded-xl border border-border/50 bg-card p-5 shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-start space-x-3">
          <AlertCircle className="h-6 w-6 text-destructive shrink-0 mt-0.5" />
          <div className="flex-1">
            <h3 className="text-base font-bold text-foreground">Delete Product?</h3>
            <p className="text-xs text-muted-foreground mt-1.5 leading-relaxed">
              Are you sure you want to permanently delete <strong className="text-foreground">"{product.name}"</strong>?
            </p>
          </div>
        </div>

        {/* Restriction Alert Banner if Product has Transactions */}
        {restrictionError && (
          <div className="mt-4 p-3.5 rounded-lg border border-amber-500/30 bg-amber-500/10 text-amber-500 space-y-2 animate-in fade-in duration-200">
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
              <div className="text-xs space-y-1">
                <span className="font-bold block">Deletion Restricted</span>
                <p className="text-[11px] text-muted-foreground leading-relaxed">
                  {restrictionError}
                </p>
              </div>
            </div>

            {product.isActive && (
              <div className="pt-2 border-t border-amber-500/20 flex justify-end">
                <Button
                  size="sm"
                  onClick={handleDeactivate}
                  disabled={isPending}
                  className="h-8 text-xs font-semibold bg-amber-600 hover:bg-amber-700 text-white flex items-center gap-1.5 shadow-sm"
                >
                  {updateMutation.isPending ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <PowerOff className="h-3.5 w-3.5" />
                  )}
                  Deactivate Product Instead
                </Button>
              </div>
            )}
          </div>
        )}

        <div className="flex items-center justify-end space-x-3 mt-5 pt-3 border-t border-border/40">
          <Button
            variant="outline"
            onClick={onClose}
            disabled={isPending}
            className="h-8.5 text-xs px-3.5"
          >
            Cancel
          </Button>

          {!restrictionError && (
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={isPending}
              className="h-8.5 text-xs px-3.5 flex items-center gap-1.5"
            >
              {deleteMutation.isPending && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
              Delete Product
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
