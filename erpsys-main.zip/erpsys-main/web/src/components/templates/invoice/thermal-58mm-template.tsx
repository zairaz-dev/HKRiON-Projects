import React from "react";
import { InvoiceTemplateProps } from "./types";

export function generateThermal58mmHtml(props: InvoiceTemplateProps): string {
  const { sale, layout, businessName, currencySymbol = "₹" } = props;
  const cur = currencySymbol;

  const headerText = layout?.headerText || "TAX INVOICE";
  const showCustomerDetails = layout?.showCustomerDetails ?? true;
  const footerText = layout?.footerText || "Thank you!";
  const termsConditions = layout?.termsConditions || "";

  return `
    <!DOCTYPE html>
    <html>
      <head>
        <title>${headerText} - ${sale.invoiceNumber}</title>
        <style>
          @page {
            margin: 0;
            size: 58mm auto;
          }
          body {
            margin: 0;
            padding: 2mm;
            font-family: 'Courier New', Courier, monospace;
            font-size: 9px;
            color: #000;
            width: 50mm;
          }
          .text-center { text-align: center; }
          .text-right { text-align: right; }
          .font-bold { font-weight: bold; }
          .mb-2 { margin-bottom: 6px; }
          .border-b { border-bottom: 1px dashed #000; }
          table { width: 100%; border-collapse: collapse; margin-top: 4px; font-size: 8px; }
          th, td { padding: 2px 0; vertical-align: top; }
          hr { border: none; border-top: 1px dashed #000; margin: 4px 0; }
          .total-section { text-align: right; margin-top: 4px; line-height: 1.3; font-size: 9px; }
          .box-section { border: 1px dashed #000; padding: 4px; margin-top: 4px; font-size: 8px; white-space: pre-line; }
        </style>
      </head>
      <body onload="window.print(); window.close();">
        <div class="text-center mb-2">
          <h2 style="margin: 0; font-size: 11px; text-transform: uppercase;">${businessName}</h2>
          <div style="font-size: 9px; font-weight: bold;">${headerText}</div>
          <div>${sale.branch?.name || ""}</div>
          ${sale.branch?.phone ? `<div>Tel: ${sale.branch.phone}</div>` : ""}
        </div>
        
        <div class="border-b pb-1" style="font-size: 8px;">
          <div><b>Inv #:</b> ${sale.invoiceNumber}</div>
          <div><b>Date:</b> ${new Date(sale.saleDate).toLocaleDateString()}</div>
          ${showCustomerDetails && sale.customer?.name ? `<div><b>Cust:</b> ${sale.customer.name}</div>` : ""}
        </div>

        <table>
          <thead>
            <tr class="border-b">
              <th align="left">Item</th>
              <th align="right" style="width: 25px;">Qty</th>
              <th align="right" style="width: 45px;">Amt</th>
            </tr>
          </thead>
          <tbody>
            ${sale.saleLines?.map((line: any) => {
              const imeiText = line.productImeis && line.productImeis.length > 0
                ? line.productImeis.map((i: any) => i.imeiNumber).join(", ")
                : (line.imeiNumber || "");
              return `
              <tr>
                <td>
                  <div>${line.variant?.product?.name || line.variant?.name}</div>
                  ${imeiText ? `<div style="font-size: 7px; color: #666; font-family: monospace;">SN: ${imeiText}</div>` : ""}
                </td>
                <td align="right">${line.quantity}</td>
                <td align="right">${cur}${line.subtotal.toFixed(0)}</td>
              </tr>
            `;}).join("")}
          </tbody>
        </table>

        <hr/>

        <div class="total-section">
          ${sale.discountAmount > 0 ? `<div>Disc: -${cur}${sale.discountAmount.toFixed(0)}</div>` : ""}
          <div class="font-bold">Total: ${cur}${sale.grandTotal.toFixed(0)}</div>
          <div style="color: green;">Paid: ${cur}${sale.amountPaid.toFixed(0)}</div>
          ${sale.grandTotal - sale.amountPaid > 0 ? `<div style="color: red; font-weight: bold;">Due: ${cur}${(sale.grandTotal - sale.amountPaid).toFixed(0)}</div>` : ""}
        </div>

        ${termsConditions ? `
          <div class="border-b" style="font-size: 7px; padding: 4px 0; color: #555;">
            ${termsConditions}
          </div>
        ` : ""}

        <div class="text-center" style="margin-top: 10px; font-size: 8px; color: #777;">
          <div>${footerText}</div>
        </div>
      </body>
    </html>
  `;
}

export function Thermal58mmTemplate(props: InvoiceTemplateProps) {
  const { sale, layout, businessName, currencySymbol = "₹" } = props;
  const cur = currencySymbol;

  const headerText = layout?.headerText || "INVOICE";
  const showCustomerDetails = layout?.showCustomerDetails ?? true;
  const footerText = layout?.footerText || "Thank you!";
  const termsConditions = layout?.termsConditions || "";

  return (
    <div className="w-[58mm] border border-border bg-card text-card-foreground p-2 font-mono text-[10px] shadow-inner rounded max-h-[75vh] overflow-y-auto">
      <div className="text-center space-y-0.5 mb-2">
        <h2 className="text-xs font-bold uppercase text-foreground">{businessName}</h2>
        <p className="text-[9px] font-bold text-muted-foreground">{headerText}</p>
        <p className="text-[8px] text-muted-foreground">{sale.branch?.name}</p>
        {sale.branch?.phone && <p className="text-[8px] text-muted-foreground">Tel: {sale.branch.phone}</p>}
      </div>

      <div className="border-b border-dashed border-border pb-1 mb-1 space-y-0.5 text-[8.5px] text-muted-foreground">
        <p><span className="font-bold text-foreground">Inv:</span> {sale.invoiceNumber}</p>
        <p><span className="font-bold text-foreground">Date:</span> {new Date(sale.saleDate).toLocaleDateString()}</p>
        {showCustomerDetails && sale.customer?.name && (
          <p><span className="font-bold text-foreground">Cust:</span> {sale.customer.name}</p>
        )}
      </div>

      <table className="w-full text-[8.5px] mb-1 text-foreground">
        <thead>
          <tr className="border-b border-dashed border-border text-muted-foreground">
            <th className="text-left py-0.5 font-semibold">Item</th>
            <th className="text-right py-0.5 font-semibold" style={{ width: "25px", textAlign: 'right' }}>Qty</th>
            <th className="text-right py-0.5 font-semibold" style={{ width: "45px", textAlign: 'right' }}>Amt</th>
          </tr>
        </thead>
        <tbody>
          {sale.saleLines?.map((line) => {
            const imeiText = line.productImeis && line.productImeis.length > 0
              ? line.productImeis.map((i: any) => i.imeiNumber).join(", ")
              : (line.imeiNumber || "");
            return (
              <tr key={line.id} className="border-b border-dotted border-border/40">
                <td className="py-0.5 max-w-[80px]">
                  <span className="block truncate">{line.variant?.product?.name || line.variant?.name}</span>
                  {imeiText && (
                    <span className="block text-[7px] text-muted-foreground font-mono leading-tight">
                      SN: {imeiText}
                    </span>
                  )}
                </td>
                <td className="text-right py-0.5" style={{ textAlign: 'right' }}>{line.quantity}</td>
                <td className="text-right py-0.5" style={{ textAlign: 'right' }}>{cur}{line.subtotal.toFixed(0)}</td>
              </tr>
            );
          })}
        </tbody>
      </table>

      <div className="border-t border-dashed border-border pt-1 space-y-0.5 text-[9px] text-right text-muted-foreground">
        {sale.discountAmount > 0 && <p>Disc: -{cur}{sale.discountAmount.toFixed(0)}</p>}
        <p className="font-bold text-[10px] text-foreground">Total: {cur}{sale.grandTotal.toFixed(0)}</p>
        <p className="text-emerald-500 font-semibold">Paid: {cur}{sale.amountPaid.toFixed(0)}</p>
        {sale.grandTotal - sale.amountPaid > 0 && (
          <p className="text-destructive font-semibold">
            Due: {cur}{(sale.grandTotal - sale.amountPaid).toFixed(0)}
          </p>
        )}
      </div>

      {termsConditions && (
        <div className="border border-dashed border-border p-1.5 mt-2 text-[7.5px] whitespace-pre-line rounded bg-muted/20">
          {termsConditions}
        </div>
      )}

      <div className="border-t border-dashed border-border pt-2 mt-2 text-center text-[8px] text-muted-foreground">
        <p>{footerText}</p>
      </div>
    </div>
  );
}
