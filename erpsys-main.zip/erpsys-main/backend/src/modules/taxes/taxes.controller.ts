import { Controller, Post, Body, Get, Patch, Delete, Param, Query, UseGuards, Req } from '@nestjs/common';
import { TaxesService } from './taxes.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('taxes')
export class TaxesController {
  constructor(private readonly taxesService: TaxesService) {}

  // ==========================================
  // Tax Rates
  // ==========================================

  @Post('rates')
  async createTaxRate(@Req() req: any, @Body() body: any) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }
    const { name, rate, businessId, createdById } = body;
    return this.taxesService.createTaxRate({
      name,
      rate: Number(rate),
      businessId,
      createdById: createdById || user.id,
    });
  }

  @Get('rates')
  async getTaxRates(@Req() req: any, @Query('businessId') businessId?: string) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.taxesService.getTaxRates(bId);
  }

  @Patch('rates/:id')
  async updateTaxRate(
    @Req() req: any,
    @Param('id') id: string,
    @Body() body: any,
  ) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }
    const { name, rate, isActive, updatedById, businessId } = body;
    return this.taxesService.updateTaxRate(id, businessId, {
      name,
      rate: rate !== undefined ? Number(rate) : undefined,
      isActive: isActive !== undefined ? Boolean(isActive) : undefined,
      updatedById: updatedById || user.id,
    });
  }

  @Delete('rates/:id')
  async deleteTaxRate(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.taxesService.deleteTaxRate(id, bId);
  }

  // ==========================================
  // Tax Groups
  // ==========================================

  @Post('groups')
  async createTaxGroup(@Req() req: any, @Body() body: any) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }
    const { name, businessId, rateIds, createdById } = body;
    return this.taxesService.createTaxGroup({
      name,
      businessId,
      rateIds,
      createdById: createdById || user.id,
    });
  }

  @Get('groups')
  async getTaxGroups(@Req() req: any, @Query('businessId') businessId?: string) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.taxesService.getTaxGroups(bId);
  }

  @Patch('groups/:id')
  async updateTaxGroup(
    @Req() req: any,
    @Param('id') id: string,
    @Body() body: any,
  ) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }
    const { name, rateIds, isActive, updatedById, businessId } = body;
    return this.taxesService.updateTaxGroup(id, businessId, {
      name,
      rateIds,
      isActive: isActive !== undefined ? Boolean(isActive) : undefined,
      updatedById: updatedById || user.id,
    });
  }

  @Delete('groups/:id')
  async deleteTaxGroup(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.taxesService.deleteTaxGroup(id, bId);
  }
}

