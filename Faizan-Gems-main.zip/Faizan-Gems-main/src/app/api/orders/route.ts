import { NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import {
  getOrders,
  createOrder,
  updateOrderStatus,
  updateOrderAddress,
  validateOrderStock,
  validateAndCalculateOrderPricing,
} from "@/lib/data/gemstones-db";
import { requireAdmin } from "@/lib/require-admin";
import { createOrderAccessToken } from "@/lib/auth";
import { getClientIp } from "@/lib/request-ip";
import { requiresPostalCode } from "@/lib/data/address-formats";

export const dynamic = "force-dynamic";
export const revalidate = 0;

// Rate limiting store for order placement to prevent Denial of Inventory / automated depletion
interface OrderRateRecord {
  count: number;
  resetAt: number;
}
const orderLimits = new Map<string, OrderRateRecord>();
const MAX_ORDERS_PER_WINDOW = 10;
const ORDER_WINDOW_MS = 15 * 60 * 1000; // 15 minutes

function pruneOrderLimits(now: number): void {
  if (orderLimits.size > 1000) {
    for (const [key, record] of orderLimits.entries()) {
      if (record.resetAt <= now) {
        orderLimits.delete(key);
      }
    }
  }
}

interface OrderRow {
  id: string;
  order_number: string;
  created_at: string | null;
  client_name: string | null;
  client_email: string | null;
  client_phone: string | null;
  client_id: string | null;
  shipping_address: string | null;
  city: string | null;
  state: string | null;
  postal_code: string | null;
  country: string | null;
  courier: string | null;
  items: string | unknown[];
  subtotal: number;
  total: number;
  currency: string | null;
  payment_method: string | null;
  bank_reference: string | null;
  payment_slip: string | null;
  status: string | null;
  tracking_number: string | null;
}

interface OrderItem {
  gemstone?: { name?: string; carat?: number };
  name?: string;
  bankReference?: string;
  paymentSlipUrl?: string;
}

// GET /api/orders — Admin only
export async function GET() {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const rows = await getOrders();
    const orders = (rows as OrderRow[]).map((o) => {
      let items = [];
      try {
        items = typeof o.items === "string" ? JSON.parse(o.items) : (o.items || []);
      } catch {
        items = [];
      }

      return {
        id: o.order_number || o.id,
        dbId: o.id,
        orderNumber: o.order_number,
        createdAt: o.created_at,
        date: o.created_at
          ? new Date(o.created_at).toLocaleDateString("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric",
              hour: "2-digit",
              minute: "2-digit",
            })
          : "Recently",
        clientName: o.client_name || "Private Patron",
        email: o.client_email || "",
        phone: o.client_phone || "",
        clientId: o.client_id || null,
        shippingAddress: o.shipping_address || "",
        city: o.city || "",
        state: o.state || "",
        postalCode: o.postal_code || "",
        country: o.country || "",
        courier: o.courier || "Armored Air Courier",
        items,
        gemstoneName:
          items[0]?.gemstone?.name || items[0]?.name || "Authentic Natural Specimen",
        carat: Number(items[0]?.gemstone?.carat || 2.5),
        subtotal: Number(o.subtotal || 0),
        total: Number(o.total || 0),
        currency: o.currency || "USD",
        paymentMethod: o.payment_method || "wire",
        bankReference: (items[0] as OrderItem)?.bankReference || o.bank_reference || null,
        paymentSlipUrl: (items[0] as OrderItem)?.paymentSlipUrl || o.payment_slip || null,
        status: o.status || "pending_verification",
        trackingNumber: o.tracking_number || null,
        destination: [o.city, o.country].filter(Boolean).join(", ") || "Vault Custody",
      };
    });

    return NextResponse.json({ orders });
  } catch {
    return NextResponse.json({ error: "Failed to fetch orders" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const ip = getClientIp(request);
    const now = Date.now();
    pruneOrderLimits(now);

    let record = orderLimits.get(ip);
    if (!record || record.resetAt <= now) {
      record = { count: 0, resetAt: now + ORDER_WINDOW_MS };
    }

    if (record.count >= MAX_ORDERS_PER_WINDOW) {
      const waitMinutes = Math.ceil((record.resetAt - now) / 60000);
      return NextResponse.json(
        {
          error: `Order placement rate limit exceeded. Please wait ${waitMinutes} minutes before attempting another order.`,
        },
        { status: 429, headers: { "Retry-After": Math.ceil((record.resetAt - now) / 1000).toString() } }
      );
    }

    const body = await request.json();

    // Increment valid submission rate count
    record.count += 1;
    orderLimits.set(ip, record);

    // 1. Validate Customer Contact Details
    const fullName = body.client?.fullName?.trim();
    const email = body.client?.email?.trim();
    const phone = body.client?.phone?.trim();
    if (!fullName || fullName.length < 2) {
      return NextResponse.json(
        { error: "Customer full name is required (minimum 2 characters)." },
        { status: 400 }
      );
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || !emailRegex.test(email)) {
      return NextResponse.json(
        { error: "A valid customer email address is required." },
        { status: 400 }
      );
    }
    if (!phone || phone.replace(/\D/g, "").length < 9) {
      return NextResponse.json(
        { error: "A valid customer phone number is required (minimum 9 digits)." },
        { status: 400 }
      );
    }

    // 2. Validate Delivery Address
    const address = body.shippingAddress?.address?.trim();
    const city = body.shippingAddress?.city?.trim();
    const state = body.shippingAddress?.state?.trim();
    const postalCode = body.shippingAddress?.postalCode?.trim() || "";
    const country = body.shippingAddress?.country?.trim() || "United States";

    if (!address || address.length < 3) {
      return NextResponse.json(
        { error: "Complete street address is required." },
        { status: 400 }
      );
    }
    if (!city || city.length < 2) {
      return NextResponse.json(
        { error: "Delivery city is required." },
        { status: 400 }
      );
    }
    if (!state) {
      return NextResponse.json(
        { error: "Delivery state, emirate, province, or district is required." },
        { status: 400 }
      );
    }
    const needsPostal = requiresPostalCode(country);
    if (needsPostal && (!postalCode || postalCode.length < 2)) {
      return NextResponse.json(
        { error: "A valid delivery postal / ZIP code is required." },
        { status: 400 }
      );
    }
    if (!country) {
      return NextResponse.json(
        { error: "Delivery country is required." },
        { status: 400 }
      );
    }

    body.shippingAddress = {
      address,
      city,
      state,
      postalCode: needsPostal ? postalCode : "",
      country,
    };

    // 3. Validate Cart Items
    if (!body.items || !Array.isArray(body.items) || body.items.length === 0) {
      return NextResponse.json(
        { error: "Your shopping bag is empty. Please add specimens before checkout." },
        { status: 400 }
      );
    }

    // 4. Validate Payment Proof for Bank Wire Transfer
    const paymentMethod = body.paymentMethod || "wire";
    const isWire = paymentMethod.toLowerCase().includes("bank transfer") || paymentMethod === "wire";
    if (isWire) {
      const bankRef = (body.bankReference || (body.items[0] as OrderItem)?.bankReference || "").trim();
      const paymentSlip = (body.paymentSlip || (body.items[0] as OrderItem)?.paymentSlipUrl || "").trim();

      if (!bankRef || bankRef.length < 3) {
        return NextResponse.json(
          { error: "Bank transfer reference number is required to verify your transaction." },
          { status: 400 }
        );
      }
      if (!paymentSlip) {
        return NextResponse.json(
          { error: "Bank transfer slip upload is required as proof of payment." },
          { status: 400 }
        );
      }
    }

    // 5. Real-Time Vault Stock Validation
    const stockCheck = await validateOrderStock(body.items);
    if (!stockCheck.valid) {
      return NextResponse.json(
        { error: stockCheck.error || "One or more items in your order are out of stock." },
        { status: 400 }
      );
    }

    // 6. Authoritative Server-Side Price Verification (Prevents Price Tampering)
    const priceCheck = await validateAndCalculateOrderPricing(
      body.items,
      body.subtotal,
      body.total
    );
    if (!priceCheck.valid) {
      return NextResponse.json(
        { error: priceCheck.error || "Order price verification failed. Please review your cart." },
        { status: 400 }
      );
    }

    // Bind authoritative server-calculated figures to order
    body.items = priceCheck.sanitizedItems;
    body.subtotal = priceCheck.calculatedSubtotal;
    body.total = priceCheck.calculatedTotal;

    const orderNumber = body.orderNumber || `ORD-MA-${Math.floor(100000 + Math.random() * 900000)}`;
    body.orderNumber = orderNumber;

    // 7. Create Order & Automatically Deduct / Reserve Stock in an Atomic Transaction
    const orderResult = await createOrder(body);
    if (!orderResult.success) {
      const isConflict =
        orderResult.error?.includes("stock") ||
        orderResult.error?.includes("reserved") ||
        orderResult.error?.includes("available");
      return NextResponse.json(
        { error: orderResult.error || "Failed to persist order in database. Please try again." },
        { status: isConflict ? 409 : 500 }
      );
    }

    try {
      revalidatePath("/gemstones");
      revalidatePath("/gemstones/[id]", "page");
      revalidatePath("/");
      revalidatePath("/admin");
    } catch {
      // ignore
    }

    const orderToken = createOrderAccessToken(orderNumber);

    const response = NextResponse.json(
      { success: true, orderNumber, orderToken },
      { status: 201 }
    );

    // Set secure HttpOnly cookie so guest buyer can seamlessly track order and print receipt
    response.cookies.set(`fg_order_${orderNumber}`, orderToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 30 * 24 * 60 * 60, // 30 days
    });

    return response;
  } catch (err: unknown) {
    console.error("Error creating order:", err);
    const message = err instanceof Error ? err.message : "Invalid order request";
    return NextResponse.json(
      { error: message },
      { status: 400 }
    );
  }
}

// PATCH /api/orders — Admin only
export async function PATCH(request: Request) {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const body = await request.json();
    const { id, status, shippingAddress, city, state, postalCode, country } = body;

    if (!id) {
      return NextResponse.json({ error: "Order ID is required" }, { status: 400 });
    }

    let statusUpdated = false;
    let addressUpdated = false;

    if (status) {
      const validStatuses = [
        "pending_verification",
        "pending_inspection",
        "accepted",
        "vault_packed",
        "in_transit",
        "delivered",
        "rejected"
      ];
      if (!validStatuses.includes(status)) {
        return NextResponse.json({ error: "Valid status is required" }, { status: 400 });
      }

      const success = await updateOrderStatus(id, status);
      if (!success) {
        return NextResponse.json({ error: "Failed to update order status in MySQL" }, { status: 500 });
      }
      statusUpdated = true;
    }

    const hasAddressUpdates =
      shippingAddress !== undefined ||
      city !== undefined ||
      state !== undefined ||
      postalCode !== undefined ||
      country !== undefined;

    if (hasAddressUpdates) {
      const success = await updateOrderAddress(id, {
        shippingAddress,
        city,
        state,
        postalCode,
        country,
      });
      if (!success) {
        return NextResponse.json({ error: "Failed to update order address in MySQL" }, { status: 500 });
      }
      addressUpdated = true;
    }

    if (!statusUpdated && !addressUpdated) {
      return NextResponse.json({ error: "Either status or address updates are required" }, { status: 400 });
    }

    try {
      revalidatePath("/gemstones");
      revalidatePath("/gemstones/[id]", "page");
      revalidatePath("/");
      revalidatePath("/admin");
    } catch {
      // Non-fatal if revalidation context is missing
    }

    return NextResponse.json({ success: true, statusUpdated, addressUpdated });
  } catch {
    return NextResponse.json({ error: "Invalid request payload" }, { status: 400 });
  }
}
