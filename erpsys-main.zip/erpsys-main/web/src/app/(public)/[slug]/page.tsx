import DynamicLegalClientPage from "./client-page";
import { notFound } from "next/navigation";

export function generateStaticParams() {
  // Return a non-colliding dummy slug so Next.js static export succeeds
  // without overwriting dedicated pages: /about, /contact, /privacy, /refund, /terms
  return [{ slug: "custom" }];
}

export default function DynamicLegalPage({
  params,
}: {
  params: { slug: string };
}) {
  const slug = params?.slug;
  if (!slug || slug === "favicon.ico" || slug.includes(".")) {
    notFound();
  }
  return <DynamicLegalClientPage initialSlug={slug} />;
}
