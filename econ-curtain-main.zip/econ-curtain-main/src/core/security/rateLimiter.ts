interface RateLimitRecord {
  count: number;
  resetAt: number;
}

const rateLimitMap = new Map<string, RateLimitRecord>();

// Cleanup stale rate limit entries periodically (every 5 minutes)
if (typeof setInterval !== "undefined") {
  setInterval(() => {
    const now = Date.now();
    for (const [key, record] of rateLimitMap.entries()) {
      if (now > record.resetAt) {
        rateLimitMap.delete(key);
      }
    }
  }, 5 * 60 * 1000).unref?.();
}

export class RateLimiter {
  /**
   * Checks if an action is within allowed rate limits.
   * @param key Unique identifier (e.g. IP + action name)
   * @param maxRequests Maximum requests permitted within the window
   * @param windowMs Window duration in milliseconds
   * @returns Object with allowed status, remaining count, and retryAfter seconds
   */
  static check(
    key: string,
    maxRequests: number = 5,
    windowMs: number = 60 * 1000
  ): { allowed: boolean; remaining: number; retryAfterSeconds: number } {
    const now = Date.now();
    const record = rateLimitMap.get(key);

    if (!record || now > record.resetAt) {
      rateLimitMap.set(key, {
        count: 1,
        resetAt: now + windowMs,
      });
      return { allowed: true, remaining: maxRequests - 1, retryAfterSeconds: 0 };
    }

    if (record.count >= maxRequests) {
      const retryAfterSeconds = Math.ceil((record.resetAt - now) / 1000);
      return { allowed: false, remaining: 0, retryAfterSeconds };
    }

    record.count += 1;
    return {
      allowed: true,
      remaining: maxRequests - record.count,
      retryAfterSeconds: 0,
    };
  }

  /**
   * Resets rate limit for a key (e.g., upon successful login)
   */
  static reset(key: string): void {
    rateLimitMap.delete(key);
  }

  /**
   * Extracts client IP safely from request headers
   */
  static getClientIp(request: Request): string {
    const xForwardedFor = request.headers.get("x-forwarded-for");
    if (xForwardedFor) {
      return xForwardedFor.split(",")[0].trim();
    }
    const realIp = request.headers.get("x-real-ip");
    if (realIp) {
      return realIp.trim();
    }
    return "127.0.0.1";
  }
}
