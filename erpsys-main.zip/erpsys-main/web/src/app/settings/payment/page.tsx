"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import {
  CreditCard,
  Plus,
  Edit2,
  Trash2,
  Loader2,
  CheckCircle,
  AlertCircle,
  Globe,
  Building2,
  Search,
  Check,
  XCircle,
  ChevronLeft
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";

import {
  PaymentMethodItem,
  PaymentMethodDialog,
  PaymentMethodDeleteDialog,
  usePaymentMethodsQuery,
  useUpdateBranchStatusMutation
} from "@/features/payment-methods";
import { useBranchesQuery } from "@/features/brands/hooks/use-brands";

function PaymentMethodManagementContent() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Notifications
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Dialog States
  const [isDialogOpen, setIsDialogOpen] = useState<boolean>(false);
  const [editingPaymentMethod, setEditingPaymentMethod] = useState<PaymentMethodItem | null>(null);
  const [paymentToDelete, setPaymentToDelete] = useState<PaymentMethodItem | null>(null);

  // Search State
  const [searchTerm, setSearchTerm] = useState<string>("");

  // URL-driven Branch Filter
  const selectedBranchFilter = searchParams.get("branchId") || "all";

  const setSelectedBranchFilter = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value === "all") {
      params.delete("branchId");
    } else {
      params.set("branchId", value);
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  // Authenticate
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  const businessId = currentUser?.businessId || "";

  // Fetch Data via React Query
  const {
    data: paymentMethods = [],
    isLoading: paymentsLoading,
    error: paymentsError
  } = usePaymentMethodsQuery(businessId);

  const {
    data: branchesList = [],
    isLoading: branchesLoading
  } = useBranchesQuery(businessId, currentUser?.id);

  const updateBranchStatusMutation = useUpdateBranchStatusMutation();

  // Handle Query Errors
  useEffect(() => {
    if (paymentsError) {
      setError(paymentsError.message || "Failed to load payment methods.");
    }
  }, [paymentsError]);

  // Auto-dismiss notifications
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  const handleOpenCreateModal = () => {
    setEditingPaymentMethod(null);
    setIsDialogOpen(true);
  };

  const handleOpenEditModal = (pm: PaymentMethodItem) => {
    setEditingPaymentMethod(pm);
    setIsDialogOpen(true);
  };

  const handleToggleBranchActive = async (pmId: string, branchId: string, currentStatus: boolean) => {
    if (!currentUser?.businessId) return;

    try {
      await updateBranchStatusMutation.mutateAsync({
        paymentMethodId: pmId,
        branchId,
        data: {
          isActive: !currentStatus,
          businessId: currentUser.businessId,
        },
      });
      setSuccessMessage("Branch status updated successfully!");
    } catch (err: any) {
      setError(err.message || "Failed to update branch status.");
    }
  };

  // Filter and Search Payment Methods
  const getFilteredList = () => {
    let list = paymentMethods;

    // Search filter
    if (searchTerm) {
      const query = searchTerm.toLowerCase();
      list = list.filter(
        (pm) =>
          pm.name.toLowerCase().includes(query) ||
          pm.code.toLowerCase().includes(query) ||
          (pm.description && pm.description.toLowerCase().includes(query))
      );
    }

    // Branch filter
    if (selectedBranchFilter !== "all") {
      list = list.filter((pm) =>
        pm.branches?.some((b) => b.branchId === selectedBranchFilter)
      );
    }

    return list;
  };

  const filteredList = getFilteredList();

  // Helpers
  const getBranchActiveStatus = (pm: PaymentMethodItem, branchId: string) => {
    const mapping = pm.branches?.find((b) => b.branchId === branchId);
    return mapping ? mapping.isActive : false;
  };

  const renderAssignedBranches = (pm: PaymentMethodItem) => {
    if (!pm.branches || pm.branches.length === 0) {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground font-medium">
          <Globe className="h-3.5 w-3.5 text-muted-foreground/60" />
          No Branches (Deactivated)
        </span>
      );
    }

    if (pm.branches.length === branchesList.length) {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs text-primary font-medium">
          <Building2 className="h-3.5 w-3.5 text-primary/60" />
          All Branches ({pm.branches.length})
        </span>
      );
    }

    return (
      <div className="flex flex-wrap gap-1 max-w-[200px]">
        {pm.branches.map((b) => (
          <span
            key={b.branchId}
            className={`inline-flex items-center text-[10px] px-1.5 py-0.5 rounded-full border ${
              b.isActive
                ? "bg-emerald-500/5 text-emerald-500 border-emerald-500/20"
                : "bg-muted text-muted-foreground border-border/40"
            }`}
          >
            {b.branch?.name || "Branch"}
          </span>
        ))}
      </div>
    );
  };

  if (isAuthenticated === null || !currentUser) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/settings" />
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Glowing Orbs */}
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-primary/5 blur-[120px] pointer-events-none z-0" />

        <Navbar title="Payment Methods Settings" className="relative z-10" />

        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 relative z-10">
          <div className="max-w-6xl mx-auto space-y-6">
            {/* Back button and Header */}
            <div className="flex flex-col gap-4">
              <button
                onClick={() => router.push("/settings")}
                className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-primary transition-colors w-fit font-medium"
              >
                <ChevronLeft className="h-4 w-4" /> Back to Settings
              </button>
              
              <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                <div>
                  <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                    <CreditCard className="h-7 w-7 text-primary" /> Payment Methods Settings
                  </h1>
                  <p className="text-sm text-muted-foreground mt-1">
                    Manage business payment methods and toggle active methods for specific branches.
                  </p>
                </div>
                <Button onClick={handleOpenCreateModal} className="w-full sm:w-auto text-xs gap-1.5 h-9">
                  <Plus className="h-4 w-4" /> Add Payment Method
                </Button>
              </div>
            </div>

            {/* Notifications */}
            {successMessage && (
              <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 p-4 rounded-sm flex items-center gap-3 text-sm animate-in fade-in duration-200">
                <CheckCircle className="h-5 w-5 flex-shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}
            {error && (
              <div className="bg-rose-500/10 border border-rose-500/30 text-rose-500 p-4 rounded-sm flex items-center gap-3 text-sm animate-in fade-in duration-200">
                <AlertCircle className="h-5 w-5 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Filter and Search controls */}
            <Card className="border border-border/40 bg-card/20 backdrop-blur-md">
              <CardContent className="p-4 flex flex-col md:flex-row gap-4 items-center">
                {/* Search */}
                <div className="relative flex-1 w-full">
                  <Input
                    placeholder="Search by code, name, description..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-9 bg-background/50"
                  />
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground/60" />
                </div>

                {/* Branch selector */}
                <div className="flex items-center gap-2 w-full md:w-auto flex-shrink-0">
                  <span className="text-xs font-semibold text-muted-foreground whitespace-nowrap">Filter by Branch:</span>
                  <select
                    value={selectedBranchFilter}
                    onChange={(e) => setSelectedBranchFilter(e.target.value)}
                    className="flex-1 md:w-48 h-9 px-3 bg-background border border-input rounded-sm text-xs focus:outline-none focus:border-primary text-foreground transition-all"
                  >
                    <option value="all">All Branches</option>
                    {branchesList.map((branch) => (
                      <option key={branch.id} value={branch.id}>
                        {branch.name}
                      </option>
                    ))}
                  </select>
                </div>
              </CardContent>
            </Card>

            {/* Data Table */}
            <div className="border border-border/40 rounded-sm bg-card/10 backdrop-blur-md overflow-x-auto shadow-md">
              {paymentsLoading ? (
                <div className="p-20 flex flex-col items-center justify-center text-muted-foreground">
                  <Loader2 className="h-8 w-8 animate-spin text-primary mb-3" />
                  <p className="text-sm">Loading payment methods...</p>
                </div>
              ) : filteredList.length > 0 ? (
                <table className="w-full text-left border-collapse min-w-[700px]">
                  <thead>
                    <tr className="border-b border-border/40 bg-background/50 text-xs font-bold text-muted-foreground uppercase tracking-wider">
                      <th className="p-4 w-[120px]">Code</th>
                      <th className="p-4">Name</th>
                      <th className="p-4">Description</th>
                      <th className="p-4 w-[110px] text-center">Type</th>
                      <th className="p-4 w-[100px] text-center">Sort Order</th>
                      {selectedBranchFilter === "all" ? (
                        <th className="p-4">Branches</th>
                      ) : (
                        <th className="p-4 w-[150px] text-center">Branch Status</th>
                      )}
                      <th className="p-4 w-[120px] text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="text-sm divide-y divide-border/30">
                    {filteredList.map((pm) => {
                      const isBranchActive =
                        selectedBranchFilter !== "all"
                          ? getBranchActiveStatus(pm, selectedBranchFilter)
                          : false;

                      return (
                        <tr
                          key={pm.id}
                          className="hover:bg-primary/5 transition-colors group border-b border-border/30"
                        >
                          <td className="p-4 font-mono text-xs text-foreground/80 font-semibold">{pm.code}</td>
                          <td className="p-4 font-semibold text-foreground">{pm.name}</td>
                          <td className="p-4 text-xs text-muted-foreground/80 max-w-[200px] truncate">
                            {pm.description || "-"}
                          </td>
                          <td className="p-4 text-center">
                            {pm.isSystem ? (
                              <span className="inline-flex text-[10px] px-1.5 py-0.5 rounded-full bg-blue-500/10 text-blue-500 font-bold border border-blue-500/20">
                                System
                              </span>
                            ) : (
                              <span className="inline-flex text-[10px] px-1.5 py-0.5 rounded-full bg-violet-500/10 text-violet-500 font-bold border border-violet-500/20">
                                Custom
                              </span>
                            )}
                          </td>
                          <td className="p-4 text-center text-muted-foreground font-mono text-xs">
                            {pm.sortOrder}
                          </td>
                          {selectedBranchFilter === "all" ? (
                            <td className="p-4">{renderAssignedBranches(pm)}</td>
                          ) : (
                            <td className="p-4 text-center">
                              <button
                                type="button"
                                onClick={() =>
                                  handleToggleBranchActive(pm.id, selectedBranchFilter, isBranchActive)
                                }
                                className={`inline-flex items-center gap-1 px-3 py-1 rounded-sm border text-xs font-semibold transition-all ${
                                  isBranchActive
                                    ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/35 hover:bg-emerald-500/20"
                                    : "bg-rose-500/10 text-rose-500 border-rose-500/35 hover:bg-rose-500/20"
                                }`}
                              >
                                {isBranchActive ? (
                                  <>
                                    <Check className="h-3.5 w-3.5" /> Enabled
                                  </>
                                ) : (
                                  <>
                                    <XCircle className="h-3.5 w-3.5" /> Disabled
                                  </>
                                )}
                              </button>
                            </td>
                          )}
                          <td className="p-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => handleOpenEditModal(pm)}
                                className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded-sm transition-colors"
                                title="Edit"
                              >
                                <Edit2 className="h-4 w-4" />
                              </button>
                              <button
                                onClick={() => setPaymentToDelete(pm)}
                                className="p-1.5 text-muted-foreground hover:text-rose-500 hover:bg-rose-500/15 rounded-sm transition-colors"
                                title="Delete/Deactivate"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              ) : (
                <div className="p-20 text-center text-sm text-muted-foreground italic bg-card/5">
                  No payment methods found. Click "Add Payment Method" to create a new one.
                </div>
              )}
            </div>
          </div>
        </main>
      </div>

      {/* Modals */}
      <PaymentMethodDialog
        isOpen={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        paymentMethod={editingPaymentMethod}
        branches={branchesList}
        currentUser={currentUser}
        onSuccess={setSuccessMessage}
        onError={setError}
      />

      <PaymentMethodDeleteDialog
        isOpen={!!paymentToDelete}
        onClose={() => setPaymentToDelete(null)}
        paymentMethod={paymentToDelete}
        currentUser={currentUser}
        onSuccess={setSuccessMessage}
        onError={setError}
      />
    </div>
  );
}

export default function PaymentMethodsPage() {
  return (
    <Suspense
      fallback={
        <div className="flex h-screen items-center justify-center bg-background">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      }
    >
      <PaymentMethodManagementContent />
    </Suspense>
  );
}
