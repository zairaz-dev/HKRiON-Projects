import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class SupplierAdvancesService {
  constructor(private readonly prisma: PrismaService) {}

  async createAdvance(data: {
    amount: number;
    advanceDate?: Date;
    supplierId: string;
    paymentMethodId: string;
    branchId: string;
    businessId: string;
    transactionNo?: string;
    notes?: string;
    createdById?: string;
  }) {
    const {
      amount,
      advanceDate,
      supplierId,
      paymentMethodId,
      branchId,
      businessId,
      transactionNo,
      notes,
      createdById,
    } = data;

    if (amount <= 0) {
      throw new BadRequestException('Advance amount must be greater than zero.');
    }

    // Verify supplier
    const supplier = await this.prisma.supplier.findFirst({
      where: { id: supplierId, businessId },
    });
    if (!supplier) {
      throw new NotFoundException('Supplier not found.');
    }

    // Verify branch
    const branch = await this.prisma.branch.findFirst({
      where: { id: branchId, businessId },
    });
    if (!branch) {
      throw new NotFoundException('Branch not found.');
    }

    // Verify payment method link
    const paymentMethodLink = await this.prisma.branchPaymentMethod.findUnique({
      where: {
        branchId_paymentMethodId: {
          branchId,
          paymentMethodId,
        },
      },
    });
    if (!paymentMethodLink) {
      throw new BadRequestException('Payment method is not active or available for this branch.');
    }

    // Generate unique advance number ADV-YYYY-XXXX using max sequence
    const year = new Date(advanceDate || new Date()).getFullYear();
    const lastAdvance = await this.prisma.supplierAdvance.findFirst({
      where: {
        businessId,
        advanceNumber: {
          startsWith: `ADV-${year}-`,
        },
      },
      orderBy: {
        advanceNumber: 'desc',
      },
    });

    let seqNum = 1;
    if (lastAdvance) {
      const parts = lastAdvance.advanceNumber.split('-');
      const lastSeq = parseInt(parts[parts.length - 1], 10);
      if (!isNaN(lastSeq)) {
        seqNum = lastSeq + 1;
      }
    }
    const advanceNumber = `ADV-${year}-${String(seqNum).padStart(4, '0')}`;

    return this.prisma.supplierAdvance.create({
      data: {
        advanceNumber,
        advanceDate: advanceDate ? new Date(advanceDate) : new Date(),
        amount,
        amountRemaining: amount,
        supplierId,
        paymentMethodId,
        branchId,
        businessId,
        transactionNo: transactionNo || null,
        notes: notes || null,
        createdById: createdById || null,
      },
      include: {
        paymentMethod: true,
        supplier: true,
        branch: true,
      },
    });
  }

  async getAdvances(
    businessId: string,
    filters: {
      supplierId?: string;
      branchId?: string;
      onlyRemaining?: boolean;
    },
  ) {
    const { supplierId, branchId, onlyRemaining } = filters;
    const whereClause: any = { businessId };

    if (supplierId) {
      whereClause.supplierId = supplierId;
    }
    if (branchId) {
      whereClause.branchId = branchId;
    }
    if (onlyRemaining) {
      whereClause.amountRemaining = { gt: 0 };
    }

    return this.prisma.supplierAdvance.findMany({
      where: whereClause,
      include: {
        paymentMethod: {
          select: { id: true, name: true, code: true },
        },
        supplier: {
          select: { id: true, name: true },
        },
        branch: {
          select: { id: true, name: true },
        },
        allocations: {
          include: {
            purchase: {
              select: { id: true, purchaseNumber: true },
            },
          },
        },
      },
      orderBy: {
        advanceDate: 'desc',
      },
    });
  }

  async allocateAdvance(data: {
    supplierAdvanceId: string;
    purchaseId: string;
    amount: number;
    businessId: string;
  }) {
    const { supplierAdvanceId, purchaseId, amount, businessId } = data;

    if (amount <= 0) {
      throw new BadRequestException('Allocation amount must be greater than zero.');
    }

    // Verify advance
    const advance = await this.prisma.supplierAdvance.findFirst({
      where: { id: supplierAdvanceId, businessId },
    });
    if (!advance) {
      throw new NotFoundException('Supplier advance record not found.');
    }

    if (amount > advance.amountRemaining + 0.01) {
      throw new BadRequestException(`Allocation amount (₹${amount}) exceeds the remaining advance balance (₹${advance.amountRemaining.toFixed(2)}).`);
    }

    // Verify purchase
    const purchase = await this.prisma.purchase.findFirst({
      where: { id: purchaseId, businessId, supplierId: advance.supplierId },
    });
    if (!purchase) {
      throw new NotFoundException('Purchase invoice not found or does not match the advance supplier.');
    }

    const currentDue = purchase.grandTotal - purchase.amountPaid;
    if (amount > currentDue + 0.01) {
      throw new BadRequestException(`Allocation amount (₹${amount}) exceeds the remaining purchase invoice due (₹${currentDue.toFixed(2)}).`);
    }

    return this.prisma.$transaction(async (tx) => {
      // 1. Create allocation record
      const allocation = await tx.supplierAdvanceAllocation.create({
        data: {
          supplierAdvanceId,
          purchaseId,
          amount,
        },
      });

      // 2. Decrement amountRemaining on the advance
      await tx.supplierAdvance.update({
        where: { id: supplierAdvanceId },
        data: {
          amountRemaining: { decrement: amount },
        },
      });

      // 3. Increment amountPaid on the purchase and update paymentStatus
      const newAmountPaid = purchase.amountPaid + amount;
      let newStatus = 'PARTIAL';
      if (newAmountPaid >= purchase.grandTotal - 0.01) {
        newStatus = 'PAID';
      }

      await tx.purchase.update({
        where: { id: purchaseId },
        data: {
          amountPaid: newAmountPaid,
          paymentStatus: newStatus as any,
        },
      });

      return allocation;
    });
  }

  async deleteAllocation(id: string, businessId: string) {
    const allocation = await this.prisma.supplierAdvanceAllocation.findFirst({
      where: {
        id,
        supplierAdvance: {
          businessId,
        },
      },
      include: {
        supplierAdvance: true,
        purchase: true,
      },
    });

    if (!allocation) {
      throw new NotFoundException('Allocation record not found.');
    }

    return this.prisma.$transaction(async (tx) => {
      // 1. Increment amountRemaining back on the advance
      await tx.supplierAdvance.update({
        where: { id: allocation.supplierAdvanceId },
        data: {
          amountRemaining: { increment: allocation.amount },
        },
      });

      // 2. Decrement amountPaid on the purchase and update status
      const purchase = allocation.purchase;
      const newAmountPaid = Math.max(0, purchase.amountPaid - allocation.amount);
      let newStatus = 'PARTIAL';
      if (newAmountPaid <= 0.01) {
        newStatus = 'DUE';
      } else if (newAmountPaid >= purchase.grandTotal - 0.01) {
        newStatus = 'PAID';
      }

      await tx.purchase.update({
        where: { id: purchase.id },
        data: {
          amountPaid: newAmountPaid,
          paymentStatus: newStatus as any,
        },
      });

      // 3. Delete allocation record
      await tx.supplierAdvanceAllocation.delete({
        where: { id },
      });

      return { success: true };
    });
  }

  async deleteAdvance(id: string, businessId: string) {
    const advance = await this.prisma.supplierAdvance.findFirst({
      where: { id, businessId },
      include: {
        allocations: true,
      },
    });

    if (!advance) {
      throw new NotFoundException('Supplier advance record not found.');
    }

    if (advance.allocations.length > 0) {
      throw new BadRequestException('Cannot delete advance payment as it has already been allocated to purchase invoices. Delete allocations first.');
    }

    await this.prisma.supplierAdvance.delete({
      where: { id },
    });

    return { success: true };
  }

  async refundAdvance(data: {
    supplierId: string;
    amount: number;
    paymentMethodId: string;
    branchId: string;
    businessId: string;
    notes?: string;
    createdById?: string;
  }) {
    const { supplierId, amount, paymentMethodId, branchId, businessId, notes, createdById } = data;

    if (!amount || amount <= 0) {
      throw new BadRequestException('Refund amount must be greater than zero.');
    }

    const supplier = await this.prisma.supplier.findFirst({
      where: { id: supplierId, businessId },
    });

    if (!supplier) {
      throw new NotFoundException('Supplier record not found.');
    }

    return this.prisma.$transaction(async (tx) => {
      // Find all active advances for this supplier with remaining credit in FIFO order
      const advances = await tx.supplierAdvance.findMany({
        where: {
          supplierId,
          businessId,
          amountRemaining: { gt: 0 },
        },
        orderBy: {
          advanceDate: 'asc',
        },
      });

      const totalAvailable = advances.reduce((sum, a) => sum + a.amountRemaining, 0);

      if (amount > totalAvailable) {
        throw new BadRequestException(
          `Refund amount of ${amount} exceeds the total available advance balance of ${totalAvailable}.`
        );
      }

      let remainingToDeduct = amount;
      const refundDate = new Date();

      for (const advance of advances) {
        if (remainingToDeduct <= 0) break;

        const deduct = Math.min(advance.amountRemaining, remainingToDeduct);
        const newRemaining = Math.max(0, advance.amountRemaining - deduct);

        const refundLog = `Refunded ${deduct} on ${refundDate.toLocaleDateString('en-IN')}${notes ? ` (${notes})` : ''}`;
        const updatedNotes = advance.notes ? `${advance.notes} | ${refundLog}` : refundLog;

        await tx.supplierAdvance.update({
          where: { id: advance.id },
          data: {
            amountRemaining: newRemaining,
            notes: updatedNotes,
          },
        });

        remainingToDeduct -= deduct;
      }

      return {
        success: true,
        refundedAmount: amount,
        remainingTotalAdvance: totalAvailable - amount,
      };
    });
  }
}
