import {
  IsString,
  IsOptional,
  IsNumber,
  IsBoolean,
  Min,
  Max,
  IsEmail,
  IsArray,
} from 'class-validator';

export class UpdateSuperSettingsDto {
  @IsOptional()
  @IsString()
  platformName?: string;

  @IsOptional()
  @IsString()
  tagline?: string;

  @IsOptional()
  @IsEmail()
  supportEmail?: string;

  @IsOptional()
  @IsString()
  supportPhone?: string;

  @IsOptional()
  @IsString()
  supportWhatsapp?: string;

  @IsOptional()
  @IsString()
  defaultCurrency?: string;

  @IsOptional()
  @IsString()
  defaultTimezone?: string;

  @IsOptional()
  @IsNumber()
  @Min(1)
  @Max(365)
  defaultTrialDays?: number;

  @IsOptional()
  @IsNumber()
  @Min(0)
  @Max(100)
  subscriptionTaxRate?: number;

  // PayHere
  @IsOptional()
  @IsString()
  payhereMerchantId?: string;

  @IsOptional()
  @IsString()
  payhereMerchantSecret?: string;

  @IsOptional()
  @IsString()
  payhereMode?: string;

  // SMTP Server
  @IsOptional()
  @IsString()
  smtpHost?: string;

  @IsOptional()
  @IsNumber()
  smtpPort?: number;

  @IsOptional()
  @IsBoolean()
  smtpSecure?: boolean;

  @IsOptional()
  @IsString()
  smtpUser?: string;

  @IsOptional()
  @IsString()
  smtpPass?: string;

  @IsOptional()
  @IsString()
  smtpFromEmail?: string;

  @IsOptional()
  @IsString()
  smtpFromName?: string;

  // Email Notifications
  @IsOptional()
  @IsBoolean()
  notifyOnNewTenant?: boolean;

  @IsOptional()
  @IsBoolean()
  notifyOnBankTransfer?: boolean;

  @IsOptional()
  @IsBoolean()
  notifyOnSubExpiry?: boolean;

  // SMS Gateway
  @IsOptional()
  @IsString()
  smsProvider?: string;

  @IsOptional()
  @IsString()
  smsApiKey?: string;

  @IsOptional()
  @IsString()
  smsSenderId?: string;

  @IsOptional()
  @IsString()
  smsApiUrl?: string;

  // Security & Maintenance
  @IsOptional()
  @IsBoolean()
  maintenanceMode?: boolean;

  @IsOptional()
  @IsString()
  maintenanceMessage?: string;

  @IsOptional()
  @IsBoolean()
  allowPublicSignups?: boolean;

  @IsOptional()
  @IsBoolean()
  enableGoogleAuth?: boolean;

  @IsOptional()
  @IsString()
  googleClientId?: string;

  @IsOptional()
  @IsString()
  googleClientSecret?: string;

  // OpenRouter AI Assistant Settings
  @IsOptional()
  @IsBoolean()
  enableAiAssistant?: boolean;

  @IsOptional()
  @IsString()
  openRouterApiKey?: string;

  @IsOptional()
  @IsString()
  openRouterModel?: string;

  @IsOptional()
  @IsNumber()
  aiMaxTokens?: number;

  @IsOptional()
  @IsNumber()
  aiTemperature?: number;

  @IsOptional()
  @IsString()
  aiSystemPrompt?: string;

  @IsOptional()
  @IsArray()
  aiAllowedRoles?: string[];
}
