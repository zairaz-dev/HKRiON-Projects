import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class TaxesService {
  constructor(private readonly prisma: PrismaService) {}

  // ==========================================
  // Tax Rate Operations
  // ==========================================

  async createTaxRate(data: {
    name: string;
    rate: number;
    businessId: string;
    createdById?: string;
  }) {
    const { name, rate, businessId, createdById } = data;

    if (rate < 0) {
      throw new BadRequestException('Tax rate cannot be negative');
    }

    const existing = await this.prisma.taxRate.findFirst({
      where: { name, businessId },
    });
    if (existing) {
      throw new BadRequestException('Tax rate with this name already exists in this business');
    }

    return this.prisma.taxRate.create({
      data: {
        name,
        rate,
        businessId,
        createdById,
      },
    });
  }

  async getTaxRates(businessId: string) {
    return this.prisma.taxRate.findMany({
      where: { businessId, isActive: true },
      orderBy: { rate: 'asc' },
    });
  }

  async getTaxRateById(id: string, businessId: string) {
    const rate = await this.prisma.taxRate.findFirst({
      where: { id, businessId },
    });
    if (!rate) {
      throw new NotFoundException('Tax rate not found');
    }
    return rate;
  }

  async updateTaxRate(
    id: string,
    businessId: string,
    data: {
      name?: string;
      rate?: number;
      isActive?: boolean;
      updatedById?: string;
    },
  ) {
    const rate = await this.getTaxRateById(id, businessId);

    if (data.rate !== undefined && data.rate < 0) {
      throw new BadRequestException('Tax rate cannot be negative');
    }

    if (data.name && data.name !== rate.name) {
      const existing = await this.prisma.taxRate.findFirst({
        where: { name: data.name, businessId, id: { not: id } },
      });
      if (existing) {
        throw new BadRequestException('Tax rate with this name already exists in this business');
      }
    }

    return this.prisma.taxRate.update({
      where: { id },
      data: {
        name: data.name,
        rate: data.rate,
        isActive: data.isActive,
        updatedById: data.updatedById,
      },
    });
  }

  async deleteTaxRate(id: string, businessId: string) {
    await this.getTaxRateById(id, businessId);
    await this.prisma.taxRate.update({
      where: { id },
      data: { isActive: false },
    });
    return { success: true, message: 'Tax rate deactivated successfully' };
  }

  // ==========================================
  // Tax Group Operations
  // ==========================================

  async createTaxGroup(data: {
    name: string;
    businessId: string;
    rateIds: string[];
    createdById?: string;
  }) {
    const { name, businessId, rateIds, createdById } = data;

    if (!rateIds || rateIds.length === 0) {
      throw new BadRequestException('Tax group must contain at least one tax rate');
    }

    const existing = await this.prisma.taxGroup.findFirst({
      where: { name, businessId },
    });
    if (existing) {
      throw new BadRequestException('Tax group with this name already exists in this business');
    }

    // Verify all rateIds exist and belong to the business
    const rates = await this.prisma.taxRate.findMany({
      where: {
        id: { in: rateIds },
        businessId,
        isActive: true,
      },
    });

    if (rates.length !== rateIds.length) {
      throw new BadRequestException('One or more selected tax rates are invalid or do not exist');
    }

    return this.prisma.$transaction(async (tx) => {
      const group = await tx.taxGroup.create({
        data: {
          name,
          businessId,
          createdById,
        },
      });

      await tx.taxGroupMember.createMany({
        data: rateIds.map((rateId) => ({
          taxGroupId: group.id,
          taxRateId: rateId,
        })),
      });

      return tx.taxGroup.findUnique({
        where: { id: group.id },
        include: {
          members: {
            include: {
              taxRate: true,
            },
          },
        },
      });
    });
  }

  async getTaxGroups(businessId: string) {
    return this.prisma.taxGroup.findMany({
      where: { businessId, isActive: true },
      include: {
        members: {
          include: {
            taxRate: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getTaxGroupById(id: string, businessId: string) {
    const group = await this.prisma.taxGroup.findFirst({
      where: { id, businessId },
      include: {
        members: {
          include: {
            taxRate: true,
          },
        },
      },
    });
    if (!group) {
      throw new NotFoundException('Tax group not found');
    }
    return group;
  }

  async updateTaxGroup(
    id: string,
    businessId: string,
    data: {
      name?: string;
      rateIds?: string[];
      isActive?: boolean;
      updatedById?: string;
    },
  ) {
    const group = await this.getTaxGroupById(id, businessId);

    if (data.name && data.name !== group.name) {
      const existing = await this.prisma.taxGroup.findFirst({
        where: { name: data.name, businessId, id: { not: id } },
      });
      if (existing) {
        throw new BadRequestException('Tax group with this name already exists in this business');
      }
    }

    if (data.rateIds) {
      if (data.rateIds.length === 0) {
        throw new BadRequestException('Tax group must contain at least one tax rate');
      }
      const rates = await this.prisma.taxRate.findMany({
        where: {
          id: { in: data.rateIds },
          businessId,
          isActive: true,
        },
      });
      if (rates.length !== data.rateIds.length) {
        throw new BadRequestException('One or more selected tax rates are invalid');
      }
    }

    return this.prisma.$transaction(async (tx) => {
      await tx.taxGroup.update({
        where: { id },
        data: {
          name: data.name,
          isActive: data.isActive,
          updatedById: data.updatedById,
        },
      });

      if (data.rateIds) {
        // Sync members
        await tx.taxGroupMember.deleteMany({
          where: { taxGroupId: id },
        });

        await tx.taxGroupMember.createMany({
          data: data.rateIds.map((rateId) => ({
            taxGroupId: id,
            taxRateId: rateId,
          })),
        });
      }

      return tx.taxGroup.findUnique({
        where: { id },
        include: {
          members: {
            include: {
              taxRate: true,
            },
          },
        },
      });
    });
  }

  async deleteTaxGroup(id: string, businessId: string) {
    await this.getTaxGroupById(id, businessId);
    await this.prisma.taxGroup.update({
      where: { id },
      data: { isActive: false },
    });
    return { success: true, message: 'Tax group deactivated successfully' };
  }
}
