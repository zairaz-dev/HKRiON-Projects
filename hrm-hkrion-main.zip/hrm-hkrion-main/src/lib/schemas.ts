import { z } from "zod";
import type { Role, TaskHealth, TaskPriority, TaskStatus } from "@prisma/client";

export const RoleEnum = ["SUPER_ADMIN", "MANAGER", "EMPLOYEE"] as const;

export const TaskStatusEnum = [
  "PENDING",
  "IN_PROGRESS",
  "SUBMITTED",
  "UNDER_REVIEW",
  "COMPLETED",
  "ON_HOLD",
  "CANCELLED",
  "OVERDUE",
  "REJECTED",
] as const;

export const TaskHealthEnum = [
  "NOT_STARTED",
  "ON_TRACK",
  "AT_RISK",
  "BLOCKED",
  "WAITING_REVIEW",
] as const;

export const TaskPriorityEnum = [
  "LOW",
  "MEDIUM",
  "HIGH",
  "URGENT",
] as const;

// Reusable schemas
const passwordSchema = z.string().min(8, "Password must be at least 8 characters long");
const phoneSchema = z.string().max(25).optional().nullable().refine(val => {
  if (!val) return true;
  return /^(?:\+94|0)[0-9]{9}$/.test(val);
}, "Must be a valid Sri Lankan phone number (e.g., 0771234567 or +94771234567)");

// Login Schema
export const LoginSchema = z.object({
  email: z.string().email("Invalid email format"),
  password: z.string().min(1, "Password is required"),
});

// Employee Schemas
export const CreateEmployeeSchema = z.object({
  firstName: z.string().min(2, "First name must be at least 2 characters"),
  lastName: z.string().min(2, "Last name must be at least 2 characters"),
  email: z.string().email("Invalid email format"),
  phone: phoneSchema,
  password: passwordSchema,
  role: z.enum(RoleEnum),
  positionId: z.coerce.number().nullable().optional().transform(v => v === 0 ? null : v),
  managerId: z.coerce.number().nullable().optional().transform(v => v === 0 ? null : v),
  profileImage: z.any().optional(),
});

export const UpdateEmployeeSchema = z.object({
  firstName: z.string().min(2, "First name must be at least 2 characters"),
  lastName: z.string().min(2, "Last name must be at least 2 characters"),
  email: z.string().email("Invalid email format"),
  phone: phoneSchema,
  password: z.union([z.string().length(0), passwordSchema]).optional(),
  role: z.enum(RoleEnum),
  positionId: z.coerce.number().nullable().optional().transform(v => v === 0 ? null : v),
  managerId: z.coerce.number().nullable().optional().transform(v => v === 0 ? null : v),
  profileImage: z.any().optional(),
});

// Settings Schemas
export const UpdateProfileSchema = z.object({
  firstName: z.string().min(2, "First name must be at least 2 characters"),
  lastName: z.string().min(2, "Last name must be at least 2 characters"),
  email: z.string().email("Invalid email format"),
  phone: phoneSchema,
  profileImage: z.any().optional(),
});

export const UpdatePasswordSchema = z.object({
  currentPassword: z.string().min(1, "Current password is required"),
  newPassword: passwordSchema,
  confirmPassword: z.string().min(1, "Confirm password is required"),
}).refine(data => data.newPassword === data.confirmPassword, {
  message: "New passwords do not match",
  path: ["confirmPassword"],
});

// Leave Request Schema
export const LeaveRequestSchema = z.object({
  startDate: z.string().min(1, "Start date is required").refine(val => !isNaN(Date.parse(val)), "Invalid start date"),
  endDate: z.string().min(1, "End date is required").refine(val => !isNaN(Date.parse(val)), "Invalid end date"),
  reason: z.string().min(5, "Reason must be at least 5 characters long"),
}).refine(data => {
  const start = new Date(data.startDate);
  const end = new Date(data.endDate);
  return end >= start;
}, {
  message: "End date must be after or equal to start date",
  path: ["endDate"],
});

// Task Schemas
export const CreateTaskSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().optional(),
  deliverables: z.string().optional(),
  instructions: z.string().optional(),
  category: z.string().optional(),
  priority: z.enum(TaskPriorityEnum).default("MEDIUM"),
  startDate: z.string().optional().nullable().transform(val => val ? val : null),
  dueDate: z.string().optional().nullable().transform(val => val ? val : null),
  deadline: z.string().optional().nullable().transform(val => val ? val : null),
  assigneeIds: z.array(z.coerce.number()).optional(),
  dependencies: z.array(z.coerce.number()).optional(),
  milestones: z.array(z.string()).optional(),
});

export const UpdateTaskStatusSchema = z.object({
  status: z.enum(TaskStatusEnum),
  progress: z.number().min(0).max(100).optional(),
  reviewNotes: z.string().optional(),
});

export const UpdateTaskHealthSchema = z.object({
  health: z.enum(TaskHealthEnum),
  progress: z.number().min(0).max(100).optional(),
});

export const PostTaskUpdateSchema = z.object({
  type: z.enum(["PROGRESS", "COMMENT", "BLOCKER"]),
  content: z.string().min(1, "Content is required"),
  progress: z.number().min(0).max(100).optional(),
  health: z.enum(TaskHealthEnum).optional(),
});

export const ReviewTaskSchema = z.object({
  action: z.enum(["APPROVE", "REJECT"]),
  reviewNotes: z.string().optional(),
});

export const SubmitTaskSchema = z.object({
  deliverables: z.string().min(1, "Deliverables are required"),
  comments: z.string().optional(),
});
