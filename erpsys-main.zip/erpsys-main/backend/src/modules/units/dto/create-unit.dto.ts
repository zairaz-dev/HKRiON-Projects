import {
  IsString,
  IsNotEmpty,
  IsOptional,
  Length,
  IsNumber,
  Min,
} from 'class-validator';

export class CreateUnitDto {
  @IsString()
  @IsNotEmpty({ message: 'Unit name is required' })
  @Length(2, 100, { message: 'Unit name must be between 2 and 100 characters' })
  name: string;

  @IsString()
  @IsNotEmpty({ message: 'Unit code is required' })
  @Length(1, 20, { message: 'Unit code must be between 1 and 20 characters' })
  code: string;

  @IsOptional()
  @IsString()
  @Length(0, 500, { message: 'Description cannot exceed 500 characters' })
  description?: string;

  @IsOptional()
  isActive?: boolean | string;

  @IsOptional()
  @IsString()
  businessId?: string;

  @IsOptional()
  branchIds?: string[] | string;

  @IsOptional()
  parentId?: string | null;

  @IsOptional()
  @IsNumber()
  @Min(0.0001, { message: 'Conversion factor must be greater than 0' })
  conversionFactor?: number | null;

  @IsOptional()
  @IsString()
  createdById?: string;
}
