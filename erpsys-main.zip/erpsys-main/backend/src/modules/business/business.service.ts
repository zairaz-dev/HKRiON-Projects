import { Injectable, BadRequestException, ForbiddenException } from '@nestjs/common';
import * as bcrypt from 'bcryptjs';
import { User } from '../../types';
import { PrismaService } from '../prisma/prisma.service';
import { countriesList } from './countries';

@Injectable()
export class BusinessService {
  constructor(private readonly prisma: PrismaService) {
    this.seedGeographicData();
  }

  public async seedGeographicData() {
    try {
      // 1. Seed Countries
      const countryCount = await this.prisma.country.count();
      if (countryCount < countriesList.length) {
        for (const c of countriesList) {
          const exists = await this.prisma.country.findUnique({
            where: { code: c.code },
          });
          if (!exists) {
            await this.prisma.country.create({
              data: {
                code: c.code,
                name: c.name,
              },
            });
          }
        }
        console.log('Countries seeding completed');
      }

      // 2. Seed Currencies
      const currencyCount = await this.prisma.currency.count();
      const uniqueCurrencies = new Map<string, { code: string; name: string; symbol: string }>();
      for (const c of countriesList) {
        if (!uniqueCurrencies.has(c.currencyCode)) {
          uniqueCurrencies.set(c.currencyCode, {
            code: c.currencyCode,
            symbol: c.currencySymbol,
            name: `${c.currencyCode} - ${c.name} Currency`,
          });
        }
      }
      if (currencyCount < uniqueCurrencies.size) {
        for (const currency of uniqueCurrencies.values()) {
          const exists = await this.prisma.currency.findUnique({
            where: { code: currency.code },
          });
          if (!exists) {
            await this.prisma.currency.create({
              data: currency,
            });
          }
        }
        console.log('Currencies seeding completed');
      }

      // 3. Seed PhoneCodes
      const phoneCodeCount = await this.prisma.phoneCode.count();
      const uniquePhoneCodes = new Map<string, { code: string; name: string }>();
      for (const c of countriesList) {
        if (!uniquePhoneCodes.has(c.phoneCode)) {
          uniquePhoneCodes.set(c.phoneCode, {
            code: c.phoneCode,
            name: `${c.name} (${c.phoneCode})`,
          });
        }
      }
      if (phoneCodeCount < uniquePhoneCodes.size) {
        for (const phoneCode of uniquePhoneCodes.values()) {
          const exists = await this.prisma.phoneCode.findUnique({
            where: { code: phoneCode.code },
          });
          if (!exists) {
            await this.prisma.phoneCode.create({
              data: phoneCode,
            });
          }
        }
        console.log('Phone codes seeding completed');
      }
    } catch (error) {
      console.error('Error seeding geographic data:', error);
    }
  }

  async registerBusiness(
    businessName: string,
    industry: string,
    phone: string,
    phoneCodeId: string,
    countryId: string,
    currencyId: string,
    ownerName: string,
    email: string,
    password: string,
  ): Promise<User> {
    const existingUser = await this.prisma.user.findUnique({
      where: { email },
    });
    if (existingUser) {
      throw new BadRequestException('User with this email already exists');
    }

    const countryRecord = await this.prisma.country.findUnique({
      where: { id: countryId },
    });
    if (!countryRecord) {
      throw new BadRequestException('Selected country does not exist');
    }

    const currencyRecord = await this.prisma.currency.findUnique({
      where: { id: currencyId },
    });
    if (!currencyRecord) {
      throw new BadRequestException('Selected currency does not exist');
    }

    const phoneCodeRecord = await this.prisma.phoneCode.findUnique({
      where: { id: phoneCodeId },
    });
    if (!phoneCodeRecord) {
      throw new BadRequestException('Selected phone code does not exist');
    }

    const adminRole = await (this.prisma).role.findFirst({
      where: { role: 'admin', businessId: null }
    });

    if (!adminRole) {
      throw new BadRequestException('System admin role not found.');
    }

    const result = await this.prisma.$transaction(async (tx) => {
      const business = await tx.business.create({
        data: {
          name: businessName,
          industry,
          phone,
          phoneCodeId,
          countryId,
          currencyId,
        },
      });

      // Automatically create a default branch with the business name
      const defaultBranch = await tx.branch.create({
        data: {
          name: `${businessName} (Main Branch)`,
          address: 'Main Office',
          phone,
          email,
          businessId: business.id,
        },
      });

      const passwordHash = await bcrypt.hash(password, 10);
      const user = await tx.user.create({
        data: {
          email,
          name: ownerName,
          roleId: adminRole.id,
          passwordHash,
          businessId: business.id,
        },
        include: {
          role: true
        }
      });

      // Update business and branch with createdById
      await tx.business.update({
        where: { id: business.id },
        data: { createdById: user.id }
      });
      await tx.branch.update({
        where: { id: defaultBranch.id },
        data: { createdById: user.id }
      });

      // Assign the business owner to the default branch
      await tx.userBranch.create({
        data: {
          userId: user.id,
          branchId: defaultBranch.id,
        },
      });

      // Automatically create default payment methods and link to default branch
      const defaultPMs = [
        { name: 'Cash', code: 'cash', sortOrder: 1 },
        { name: 'Card', code: 'card', sortOrder: 2 },
        { name: 'Bank Transfer', code: 'bank_transfer', sortOrder: 3 },
        { name: 'Cheque', code: 'cheque', sortOrder: 4 },
      ];

      for (const pm of defaultPMs) {
        const method = await tx.paymentMethod.create({
          data: {
            name: pm.name,
            code: pm.code,
            sortOrder: pm.sortOrder,
            isSystem: true,
            businessId: business.id,
            createdById: user.id,
          },
        });

        await tx.branchPaymentMethod.create({
          data: {
            branchId: defaultBranch.id,
            paymentMethodId: method.id,
            isActive: true,
          },
        });
      }

      // Automatically create a default "Walk-in Customer" linked to the default branch
      await tx.customer.create({
        data: {
          name: 'Walk-in Customer',
          phone: null,
          email: null,
          isDefault: true,
          allowCredit: false,
          creditLimit: 0,
          businessId: business.id,
          createdById: user.id,
          branches: {
            create: [
              { branchId: defaultBranch.id }
            ]
          }
        }
      });

      // Auto-assign Free Trial Subscription (14 days)
      const trialPlan = await tx.plan.findFirst({
        where: { OR: [{ slug: 'trial' }, { isActive: true }] },
        orderBy: { sortOrder: 'asc' },
      });

      if (trialPlan) {
        const trialDays = trialPlan.trialDays || 14;
        const now = new Date();
        const trialEndDate = new Date();
        trialEndDate.setDate(trialEndDate.getDate() + trialDays);

        await tx.subscription.create({
          data: {
            businessId: business.id,
            planId: trialPlan.id,
            status: 'TRIAL',
            billingInterval: 'MONTHLY',
            startDate: now,
            endDate: trialEndDate,
            trialEndsAt: trialEndDate,
            isAutoRenew: false,
          },
        });
      }

      return user;
    });

    const { passwordHash: _, ...userWithoutHash } = result;
    return {
      ...userWithoutHash,
      role: result.role.role as User['role'],
      phone: userWithoutHash.phone || undefined,
      isActive: userWithoutHash.isActive,
      avatar: userWithoutHash.avatar || undefined,
      address: userWithoutHash.address || undefined,
      lastLoginAt: userWithoutHash.lastLoginAt ? userWithoutHash.lastLoginAt.toISOString() : undefined,
      lastLoginIp: userWithoutHash.lastLoginIp || undefined,
      createdAt: userWithoutHash.createdAt.toISOString(),
    };
  }

  async registerBusinessGoogle(
    businessName: string,
    industry: string,
    phone: string,
    phoneCodeId: string,
    countryId: string,
    currencyId: string,
    token: string,
  ): Promise<User> {
    if (process.env.ENABLE_GOOGLE_LOGIN === 'false') {
      throw new ForbiddenException('Google login is currently disabled by administrator');
    }
    let email: string;
    let name: string;
    let googleId: string;

    try {
      const response = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!response.ok) {
        throw new BadRequestException('Invalid Google access token');
      }
      const payload = await response.json();
      if (!payload || !payload.email) {
        throw new BadRequestException('Invalid Google access token payload');
      }
      email = payload.email.toLowerCase();
      name = payload.name || 'Google User';
      googleId = payload.sub;
    } catch (error) {
      throw new BadRequestException(error.message || 'Failed to verify Google access token');
    }

    const existingUser = await this.prisma.user.findUnique({
      where: { email },
    });
    if (existingUser) {
      throw new BadRequestException('User with this email already exists');
    }

    const countryRecord = await this.prisma.country.findUnique({
      where: { id: countryId },
    });
    if (!countryRecord) {
      throw new BadRequestException('Selected country does not exist');
    }

    const currencyRecord = await this.prisma.currency.findUnique({
      where: { id: currencyId },
    });
    if (!currencyRecord) {
      throw new BadRequestException('Selected currency does not exist');
    }

    const phoneCodeRecord = await this.prisma.phoneCode.findUnique({
      where: { id: phoneCodeId },
    });
    if (!phoneCodeRecord) {
      throw new BadRequestException('Selected phone code does not exist');
    }

    const adminRole = await (this.prisma).role.findFirst({
      where: { role: 'admin', businessId: null }
    });

    if (!adminRole) {
      throw new BadRequestException('System admin role not found.');
    }

    const result = await this.prisma.$transaction(async (tx) => {
      const business = await tx.business.create({
        data: {
          name: businessName,
          industry,
          phone,
          phoneCodeId,
          countryId,
          currencyId,
        },
      });

      const defaultBranch = await tx.branch.create({
        data: {
          name: `${businessName} (Main Branch)`,
          address: 'Main Office',
          phone,
          email,
          businessId: business.id,
        },
      });

      const user = await tx.user.create({
        data: {
          email,
          name,
          roleId: adminRole.id,
          passwordHash: null,
          provider: 'GOOGLE',
          providerId: googleId,
          businessId: business.id,
        },
        include: {
          role: true
        }
      });

      await tx.business.update({
        where: { id: business.id },
        data: { createdById: user.id }
      });
      await tx.branch.update({
        where: { id: defaultBranch.id },
        data: { createdById: user.id }
      });

      await tx.userBranch.create({
        data: {
          userId: user.id,
          branchId: defaultBranch.id,
        },
      });

      const defaultPMs = [
        { name: 'Cash', code: 'cash', sortOrder: 1 },
        { name: 'Card', code: 'card', sortOrder: 2 },
        { name: 'Bank Transfer', code: 'bank_transfer', sortOrder: 3 },
        { name: 'Cheque', code: 'cheque', sortOrder: 4 },
      ];

      for (const pm of defaultPMs) {
        const method = await tx.paymentMethod.create({
          data: {
            name: pm.name,
            code: pm.code,
            sortOrder: pm.sortOrder,
            isSystem: true,
            businessId: business.id,
            createdById: user.id,
          },
        });

        await tx.branchPaymentMethod.create({
          data: {
            branchId: defaultBranch.id,
            paymentMethodId: method.id,
            isActive: true,
          },
        });
      }

      await tx.customer.create({
        data: {
          name: 'Walk-in Customer',
          phone: null,
          email: null,
          isDefault: true,
          allowCredit: false,
          creditLimit: 0,
          businessId: business.id,
          createdById: user.id,
          branches: {
            create: [
              { branchId: defaultBranch.id }
            ]
          }
        }
      });

      // Auto-assign Free Trial Subscription (14 days)
      const trialPlan = await tx.plan.findFirst({
        where: { OR: [{ slug: 'trial' }, { isActive: true }] },
        orderBy: { sortOrder: 'asc' },
      });

      if (trialPlan) {
        const trialDays = trialPlan.trialDays || 14;
        const now = new Date();
        const trialEndDate = new Date();
        trialEndDate.setDate(trialEndDate.getDate() + trialDays);

        await tx.subscription.create({
          data: {
            businessId: business.id,
            planId: trialPlan.id,
            status: 'TRIAL',
            billingInterval: 'MONTHLY',
            startDate: now,
            endDate: trialEndDate,
            trialEndsAt: trialEndDate,
            isAutoRenew: false,
          },
        });
      }

      return user;
    });

    const { passwordHash: _, ...userWithoutHash } = result;
    return {
      ...userWithoutHash,
      role: result.role.role as User['role'],
      phone: userWithoutHash.phone || undefined,
      isActive: userWithoutHash.isActive,
      avatar: userWithoutHash.avatar || undefined,
      address: userWithoutHash.address || undefined,
      lastLoginAt: userWithoutHash.lastLoginAt ? userWithoutHash.lastLoginAt.toISOString() : undefined,
      lastLoginIp: userWithoutHash.lastLoginIp || undefined,
      createdAt: userWithoutHash.createdAt.toISOString(),
    };
  }

  async getAllBusinesses(): Promise<any[]> {
    const businesses = await this.prisma.business.findMany({
      include: {
        users: {
          where: {
            role: {
              role: 'admin'
            }
          },
          select: {
            name: true,
            email: true
          }
        },
        country: {
          select: {
            name: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    });

    return businesses.map((b) => ({
      id: b.id,
      name: b.name,
      industry: b.industry,
      phone: b.phone,
      isActive: b.isActive ?? true,
      country: b.country.name,
      ownerName: b.users[0]?.name || 'N/A',
      ownerEmail: b.users[0]?.email || 'N/A',
      createdAt: b.createdAt.toISOString()
    }));
  }

  async toggleBusinessStatus(id: string, isActive: boolean, updatedById?: string): Promise<any> {
    const business = await this.prisma.business.findUnique({
      where: { id }
    });

    if (!business) {
      throw new BadRequestException('Business not found.');
    }

    const updated = await (this.prisma.business).update({
      where: { id },
      data: {
        isActive,
        updatedById: updatedById || null,
      }
    });

    return updated;
  }

  async getBusinessById(id: string) {
    const business = await this.prisma.business.findUnique({
      where: { id },
      include: {
        country: true,
        currency: true,
        phoneCode: true,
      },
    });

    if (!business) {
      throw new BadRequestException('Business not found');
    }

    return business;
  }

  async updateBusiness(id: string, data: {
    name?: string;
    industry?: string;
    phone?: string;
    phoneCodeId?: string;
    countryId?: string;
    currencyId?: string;
    taxNumber?: string | null;
    taxName?: string | null;
    isTaxEnabled?: boolean;
    logo?: string | null;
    registrationNumber?: string | null;
    email?: string | null;
    website?: string | null;
    alternatePhone?: string | null;
    address?: string | null;
    city?: string | null;
    state?: string | null;
    postalCode?: string | null;
    financialYearStartMonth?: number | null;
    stockAccountingMethod?: string | null;
    timezone?: string | null;
    dateFormat?: string | null;
    currencySymbolPlacement?: string | null;
    decimalPrecision?: number | null;
    updatedById?: string;
  }) {
    const business = await this.prisma.business.findUnique({
      where: { id },
    });

    if (!business) {
      throw new BadRequestException('Business not found');
    }

    if (data.countryId) {
      const country = await this.prisma.country.findUnique({ where: { id: data.countryId } });
      if (!country) throw new BadRequestException('Country not found');
    }
    if (data.currencyId) {
      const currency = await this.prisma.currency.findUnique({ where: { id: data.currencyId } });
      if (!currency) throw new BadRequestException('Currency not found');
    }
    if (data.phoneCodeId) {
      const phoneCode = await this.prisma.phoneCode.findUnique({ where: { id: data.phoneCodeId } });
      if (!phoneCode) throw new BadRequestException('Phone code not found');
    }

    return this.prisma.business.update({
      where: { id },
      data: {
        name: data.name,
        industry: data.industry,
        phone: data.phone,
        phoneCodeId: data.phoneCodeId,
        countryId: data.countryId,
        currencyId: data.currencyId,
        taxNumber: data.taxNumber,
        taxName: data.taxName,
        isTaxEnabled: data.isTaxEnabled,
        logo: data.logo,
        registrationNumber: data.registrationNumber,
        email: data.email,
        website: data.website,
        alternatePhone: data.alternatePhone,
        address: data.address,
        city: data.city,
        state: data.state,
        postalCode: data.postalCode,
        financialYearStartMonth: data.financialYearStartMonth,
        stockAccountingMethod: data.stockAccountingMethod,
        timezone: data.timezone,
        dateFormat: data.dateFormat,
        currencySymbolPlacement: data.currencySymbolPlacement,
        decimalPrecision: data.decimalPrecision,
        updatedById: data.updatedById,
      },
      include: {
        country: true,
        currency: true,
        phoneCode: true,
      },
    });
  }
}
