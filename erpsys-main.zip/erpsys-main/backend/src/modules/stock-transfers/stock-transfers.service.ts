import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { TransferStatus } from '@prisma/client';

interface StockTransferLineInput {
  variantId: string;
  quantity: number;
  unitPrice: number;
}

@Injectable()
export class StockTransfersService {
  constructor(private readonly prisma: PrismaService) {}

  async createStockTransfer(data: {
    transferDate?: Date;
    status?: TransferStatus;
    fromBranchId: string;
    toBranchId: string;
    businessId: string;
    shippingCharges?: number;
    notes?: string;
    createdById?: string;
    transferLines: StockTransferLineInput[];
  }) {
    const {
      transferDate,
      status = TransferStatus.COMPLETED,
      fromBranchId,
      toBranchId,
      businessId,
      shippingCharges = 0,
      notes,
      createdById,
      transferLines,
    } = data;

    if (!transferLines || transferLines.length === 0) {
      throw new BadRequestException('Stock transfer must contain at least one item line.');
    }

    if (fromBranchId === toBranchId) {
      throw new BadRequestException('Source and destination branches must be different.');
    }

    // Verify branches
    const [fromBranch, toBranch] = await Promise.all([
      this.prisma.branch.findFirst({ where: { id: fromBranchId, businessId } }),
      this.prisma.branch.findFirst({ where: { id: toBranchId, businessId } }),
    ]);

    if (!fromBranch) {
      throw new NotFoundException('Source branch not found.');
    }
    if (!toBranch) {
      throw new NotFoundException('Destination branch not found.');
    }

    // Generate transfer number using configured document prefix
    const docPrefix = await this.prisma.documentPrefix.findUnique({
      where: { businessId },
    });
    const prefix = docPrefix?.stockTransfer || 'ST-';

    const count = await this.prisma.stockTransfer.count({ where: { businessId } });
    const transferNumber = `${prefix}${String(count + 1).padStart(4, '0')}`;

    return this.prisma.$transaction(async (tx) => {
      let totalAmount = 0;
      const linesToCreate: {
        variantId: string;
        quantity: number;
        unitPrice: number;
        subtotal: number;
      }[] = [];

      for (const line of transferLines) {
        if (line.quantity <= 0) {
          throw new BadRequestException('Transfer quantity must be greater than zero.');
        }

        const variant = await tx.productVariant.findFirst({
          where: { id: line.variantId, product: { businessId } },
        });

        if (!variant) {
          throw new BadRequestException(`Product variant ID ${line.variantId} not found.`);
        }

        const unitPrice = line.unitPrice > 0 ? line.unitPrice : variant.purchasePrice;
        const subtotal = line.quantity * unitPrice;
        totalAmount += subtotal;

        // 1. Deduct stock from Source Branch using FIFO
        const sourceBatches = await tx.purchaseLine.findMany({
          where: {
            variantId: line.variantId,
            branchId: fromBranchId,
            quantityRemaining: { gt: 0 },
          },
          orderBy: { createdAt: 'asc' }, // FIFO
        });

        let remainingToDeduct = line.quantity;

        for (const batch of sourceBatches) {
          if (remainingToDeduct <= 0) break;

          if (batch.quantityRemaining >= remainingToDeduct) {
            await tx.purchaseLine.update({
              where: { id: batch.id },
              data: {
                quantityRemaining: { decrement: remainingToDeduct },
              },
            });
            remainingToDeduct = 0;
          } else {
            remainingToDeduct -= batch.quantityRemaining;
            await tx.purchaseLine.update({
              where: { id: batch.id },
              data: { quantityRemaining: 0 },
            });
          }
        }

        if (remainingToDeduct > 0) {
          throw new BadRequestException(
            `Insufficient stock for product "${variant.name}" in source branch. Available stock is less than required transfer quantity ${line.quantity}.`,
          );
        }

        // 2. If status is COMPLETED, add stock immediately to Destination Branch
        if (status === TransferStatus.COMPLETED) {
          const rand = Math.floor(1000 + Math.random() * 9000);
          await tx.purchaseLine.create({
            data: {
              variantId: line.variantId,
              branchId: toBranchId,
              businessId,
              batchNumber: `TR-BATCH-${rand}`,
              quantityPurchased: line.quantity,
              quantityRemaining: line.quantity,
              purchasePrice: unitPrice,
              sellingPrice: variant.sellingPrice,
            },
          });
        }

        linesToCreate.push({
          variantId: line.variantId,
          quantity: line.quantity,
          unitPrice,
          subtotal,
        });
      }

      const stockTransfer = await tx.stockTransfer.create({
        data: {
          transferNumber,
          transferDate: transferDate ? new Date(transferDate) : new Date(),
          status,
          fromBranchId,
          toBranchId,
          businessId,
          totalAmount,
          shippingCharges,
          notes: notes?.trim() || null,
          createdById: createdById || null,
        },
      });

      for (const l of linesToCreate) {
        await tx.stockTransferLine.create({
          data: {
            stockTransferId: stockTransfer.id,
            variantId: l.variantId,
            quantity: l.quantity,
            unitPrice: l.unitPrice,
            subtotal: l.subtotal,
            businessId,
          },
        });
      }

      return stockTransfer;
    });
  }

  async updateTransferStatus(
    id: string,
    businessId: string,
    newStatus: TransferStatus,
  ) {
    const transfer = await this.prisma.stockTransfer.findFirst({
      where: { id, businessId },
      include: { transferLines: true },
    });

    if (!transfer) {
      throw new NotFoundException('Stock transfer not found.');
    }

    if (transfer.status === newStatus) {
      return transfer;
    }

    if (transfer.status === TransferStatus.COMPLETED) {
      throw new BadRequestException('Completed stock transfers cannot be modified.');
    }

    return this.prisma.$transaction(async (tx) => {
      if (newStatus === TransferStatus.COMPLETED) {
        // Transfer completed: Add items to Destination Branch
        for (const line of transfer.transferLines) {
          const variant = await tx.productVariant.findUnique({
            where: { id: line.variantId },
          });

          const rand = Math.floor(1000 + Math.random() * 9000);
          await tx.purchaseLine.create({
            data: {
              variantId: line.variantId,
              branchId: transfer.toBranchId,
              businessId,
              batchNumber: `TR-BATCH-${rand}`,
              quantityPurchased: line.quantity,
              quantityRemaining: line.quantity,
              purchasePrice: line.unitPrice,
              sellingPrice: variant?.sellingPrice || line.unitPrice,
            },
          });
        }
      } else if (newStatus === TransferStatus.CANCELLED) {
        // Transfer cancelled: Restore items back to Source Branch
        for (const line of transfer.transferLines) {
          const variant = await tx.productVariant.findUnique({
            where: { id: line.variantId },
          });

          const rand = Math.floor(1000 + Math.random() * 9000);
          await tx.purchaseLine.create({
            data: {
              variantId: line.variantId,
              branchId: transfer.fromBranchId,
              businessId,
              batchNumber: `RESTORE-BATCH-${rand}`,
              quantityPurchased: line.quantity,
              quantityRemaining: line.quantity,
              purchasePrice: line.unitPrice,
              sellingPrice: variant?.sellingPrice || line.unitPrice,
            },
          });
        }
      }

      return tx.stockTransfer.update({
        where: { id },
        data: { status: newStatus },
      });
    });
  }

  async getStockTransfers(
    businessId: string,
    filters: {
      fromBranchId?: string;
      toBranchId?: string;
      status?: TransferStatus;
      search?: string;
      page?: number;
      limit?: number;
    },
  ) {
    const { fromBranchId, toBranchId, status, search, page = 1, limit = 10 } = filters;
    const skip = (page - 1) * limit;

    const whereClause: any = { businessId };

    if (fromBranchId) {
      whereClause.fromBranchId = fromBranchId;
    }

    if (toBranchId) {
      whereClause.toBranchId = toBranchId;
    }

    if (status) {
      whereClause.status = status;
    }

    if (search) {
      whereClause.transferNumber = { contains: search, mode: 'insensitive' };
    }

    const [total, data] = await Promise.all([
      this.prisma.stockTransfer.count({ where: whereClause }),
      this.prisma.stockTransfer.findMany({
        where: whereClause,
        include: {
          fromBranch: {
            select: { id: true, name: true },
          },
          toBranch: {
            select: { id: true, name: true },
          },
          createdBy: {
            select: { id: true, name: true, email: true },
          },
          transferLines: {
            include: {
              variant: {
                select: {
                  id: true,
                  name: true,
                  sku: true,
                  product: {
                    select: { id: true, name: true },
                  },
                },
              },
            },
          },
        },
        orderBy: { transferDate: 'desc' },
        skip,
        take: limit,
      }),
    ]);

    return {
      data,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getStockTransferById(id: string, businessId: string) {
    const transfer = await this.prisma.stockTransfer.findFirst({
      where: { id, businessId },
      include: {
        fromBranch: true,
        toBranch: true,
        createdBy: {
          select: { id: true, name: true, email: true },
        },
        transferLines: {
          include: {
            variant: {
              include: {
                product: true,
              },
            },
          },
        },
      },
    });

    if (!transfer) {
      throw new NotFoundException('Stock transfer not found.');
    }

    return transfer;
  }
}
