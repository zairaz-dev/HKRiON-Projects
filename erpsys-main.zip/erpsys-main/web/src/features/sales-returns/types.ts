export interface SalesReturnItem {
  id: string;
  returnNumber: string;
  returnDate: string;
  saleId: string;
  sale?: {
    id: string;
    invoiceNumber: string;
    grandTotal: number;
    saleLines?: Array<{
      id: string;
      variantId: string;
      quantity: number;
      unitPrice: number;
      subtotal: number;
      variant?: {
        id: string;
        name: string;
        sku: string;
      };
    }>;
  };
  customerId: string;
  customer?: {
    id: string;
    name: string;
    phone: string;
  };
  branchId: string;
  branch?: {
    id: string;
    name: string;
  };
  subtotal: number;
  taxTotal: number;
  grandTotal: number;
  refundAmount: number;
  creditNoteAmount: number;
  reason?: string;
  notes?: string;
  createdById?: string;
  createdBy?: {
    id: string;
    name: string;
    email: string;
  };
  returnLines: Array<{
    id: string;
    saleLineId?: string;
    variantId: string;
    quantityReturned: number;
    unitPrice: number;
    taxAmount: number;
    subtotal: number;
    variant?: {
      id: string;
      name: string;
      sku: string;
      product?: {
        id: string;
        name: string;
      };
    };
  }>;
  createdAt: string;
  updatedAt: string;
}
