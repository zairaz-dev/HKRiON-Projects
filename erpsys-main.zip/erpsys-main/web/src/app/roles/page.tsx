"use strict";
"use client";

import React, { useEffect, useState } from "react";
import {
  Shield,
  Plus,
  Edit2,
  Trash2,
  Lock,
  Loader2,
  CheckCircle,
  AlertCircle,
  XCircle,
  X,
  ChevronRight,
  ShieldCheck,
  FileText,
  HelpCircle
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { authService } from "@/services/auth-service";
import { LoadingSession } from "@/components/ui/loading-session";
import { User } from "@hkr/types";
import Link from "next/link";

interface RoleItem {
  id: string;
  role: string;
  name: string;
  description: string;
  permissions: string[];
  businessId: string | null;
  isCustom: boolean;
}

interface PermissionItem {
  id: string;
  name: string;
  description: string;
}

interface PermissionGroup {
  category: string;
  items: PermissionItem[];
}

const permissionGroups: PermissionGroup[] = [
  {
    category: "Point of Sale (POS)",
    items: [
      { id: "pos:view", name: "Access POS Terminal", description: "Allows opening the POS selling screen." },
      { id: "pos:create_transaction", name: "Create Transactions", description: "Allows processing sales and completing checkouts." },
      { id: "pos:void_transaction", name: "Void Transactions", description: "Allows voiding active or completed sales." },
      { id: "pos:refund", name: "Process Refunds", description: "Allows refunding items and returning cash/credit." },
      { id: "pos:edit_price", name: "Modify Selling Price", description: "Allows changing the unit price of items in the cart." },
      { id: "pos:apply_discount", name: "Apply Discounts", description: "Allows giving percentage or fixed bill discounts." },
      { id: "pos:credit_sale", name: "Allow Credit / Due Sale", description: "Allows completing sales with unpaid / due balances." },
      { id: "pos:hold_sale", name: "Hold / Resume Bills", description: "Allows saving in-progress sales as hold bills and resuming them." },
      { id: "pos:quick_add_product", name: "Quick Add Products in POS", description: "Allows creating new products directly from POS." },
      { id: "pos:close_register", name: "Close Register & Shift", description: "Allows closing cash registers and submitting cash reports." },
      { id: "pos:reprint_receipt", name: "Reprint Receipts", description: "Allows reprinting past receipts." }
    ]
  },
  {
    category: "Quotations (Estimates)",
    items: [
      { id: "quotations:view", name: "View Quotations", description: "Allows viewing customer quotation estimates." },
      { id: "quotations:create", name: "Create Quotations", description: "Allows creating new price quotations for customers." },
      { id: "quotations:edit", name: "Edit Quotations", description: "Allows modifying pending quotations." },
      { id: "quotations:delete", name: "Delete Quotations", description: "Allows removing price quotations." }
    ]
  },
  {
    category: "Inventory & Stock",
    items: [
      { id: "inventory:view", name: "View Inventory", description: "Allows browsing product lists and stock levels." },
      { id: "inventory:add_product", name: "Add New Products", description: "Allows creating new product listings." },
      { id: "inventory:edit_product", name: "Edit Products", description: "Allows updating product names, prices, and details." },
      { id: "inventory:delete_product", name: "Delete Products", description: "Allows removing products from the system." },
      { id: "inventory:adjust_stock", name: "Adjust Stock Levels", description: "Allows manually updating stock counts." },
      { id: "inventory:transfer_stock", name: "Transfer Stock", description: "Allows transferring items between branches." }
    ]
  },
  {
    category: "Purchases & Procurement",
    items: [
      { id: "purchases:view", name: "View Purchases", description: "Allows browsing purchase orders and supplier bills." },
      { id: "purchases:create", name: "Create Purchases", description: "Allows recording new purchases from suppliers." },
      { id: "purchases:edit", name: "Edit Purchases", description: "Allows modifying purchase orders and received items." },
      { id: "purchases:delete", name: "Delete Purchases", description: "Allows removing purchase invoices." }
    ]
  },
  {
    category: "Contacts & CRM",
    items: [
      { id: "contacts:view", name: "View Contacts", description: "Allows viewing customers and suppliers directory." },
      { id: "contacts:create", name: "Create Contacts", description: "Allows adding new customers and suppliers." },
      { id: "contacts:edit", name: "Edit Contacts", description: "Allows updating customer and supplier details." },
      { id: "contacts:delete", name: "Delete Contacts", description: "Allows deleting customer and supplier profiles." }
    ]
  },
  {
    category: "User & HR Management",
    items: [
      { id: "users:view", name: "View Team Directory", description: "Allows viewing list of employees and roles." },
      { id: "users:create", name: "Add New Users", description: "Allows registering new employee accounts." },
      { id: "users:edit", name: "Edit User Profiles", description: "Allows updating names, emails, and roles." },
      { id: "users:delete", name: "Delete Users", description: "Allows terminating employee accounts." },
      { id: "users:manage_permissions", name: "Manage Permissions", description: "Allows editing role-permission mappings." }
    ]
  },
  {
    category: "Financial Ledger & Expenses",
    items: [
      { id: "finance:view_ledger", name: "View General Ledger", description: "Allows viewing overall sales revenue and expenses." },
      { id: "finance:add_expense", name: "Record Expenses", description: "Allows logging business costs and payouts." },
      { id: "finance:view_reports", name: "Financial Analytics & Reports", description: "Allows viewing detailed profit & loss charts." }
    ]
  },
  {
    category: "System Settings",
    items: [
      { id: "settings:view", name: "View ERP Settings", description: "Allows viewing store configuration details." },
      { id: "settings:edit", name: "Modify ERP Settings", description: "Allows changing store details, currency, and tax." }
    ]
  }
];

export default function RoleManagementPage() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Roles state
  const [rolesList, setRolesList] = useState<RoleItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [actionLoading, setActionLoading] = useState<boolean>(false);

  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [modalMode, setModalMode] = useState<"create" | "edit">("create");
  const [editingRoleId, setEditingRoleId] = useState<string>("");

  // Form Fields
  const [formSlug, setFormSlug] = useState<string>("");
  const [formName, setFormName] = useState<string>("");
  const [formDescription, setFormDescription] = useState<string>("");
  const [formPermissions, setFormPermissions] = useState<string[]>([]);

  // Delete Confirmation State
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState<boolean>(false);
  const [roleToDelete, setRoleToDelete] = useState<RoleItem | null>(null);

  // Authenticate and fetch roles
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
      return;
    }

    if (user) {
      fetchRoles(user.businessId || undefined);
    }
  }, []);

  const fetchRoles = async (businessId?: string) => {
    setLoading(true);
    setError("");
    try {
      const data = await authService.getRoles(businessId);
      setRolesList(data);
    } catch (err: any) {
      setError(err.message || "Failed to load roles. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // Auto-dismiss notifications
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  const handleOpenCreateModal = () => {
    setModalMode("create");
    setEditingRoleId("");
    setFormSlug("");
    setFormName("");
    setFormDescription("");
    setFormPermissions([]);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (role: RoleItem) => {
    setModalMode("edit");
    setEditingRoleId(role.id);
    setFormSlug(role.role);
    setFormName(role.name);
    setFormDescription(role.description);
    setFormPermissions(role.permissions || []);
    setIsModalOpen(true);
  };

  const handleOpenDeleteConfirm = (role: RoleItem) => {
    setRoleToDelete(role);
    setIsDeleteConfirmOpen(true);
  };

  const handleTogglePermission = (permissionId: string) => {
    setFormPermissions((prev) =>
      prev.includes(permissionId)
        ? prev.filter((id) => id !== permissionId)
        : [...prev, permissionId]
    );
  };

  const handleSaveRole = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!formName.trim()) {
      setError("Role Name is required.");
      return;
    }

    if (modalMode === "create" && !formSlug.trim()) {
      setError("Role Identifier (Slug) is required.");
      return;
    }

    setActionLoading(true);
    try {
      if (modalMode === "create") {
        await authService.createRole({
          role: formSlug,
          name: formName,
          description: formDescription,
          permissions: formPermissions,
          businessId: currentUser?.businessId || undefined,
          createdById: currentUser?.id || undefined,
        });
        setSuccessMessage(`Role "${formName}" created successfully!`);
      } else {
        await authService.updateRole(editingRoleId, {
          name: formName,
          description: formDescription,
          permissions: formPermissions,
          businessId: currentUser?.businessId || undefined,
          updatedById: currentUser?.id || undefined,
        });
        setSuccessMessage(`Role "${formName}" updated successfully!`);
      }
      setIsModalOpen(false);
      fetchRoles(currentUser?.businessId || undefined);
    } catch (err: any) {
      setError(err.message || "Failed to save role. Please try again.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteRole = async () => {
    if (!roleToDelete) return;
    setActionLoading(true);
    setError("");
    try {
      await authService.deleteRole(roleToDelete.id, currentUser?.businessId || undefined);
      setSuccessMessage(`Role "${roleToDelete.name}" deleted successfully.`);
      setIsDeleteConfirmOpen(false);
      setRoleToDelete(null);
      fetchRoles(currentUser?.businessId || undefined);
    } catch (err: any) {
      setError(err.message || "Failed to delete role. Please try again.");
      setIsDeleteConfirmOpen(false);
    } finally {
      setActionLoading(false);
    }
  };

  if (isAuthenticated === null) {
    return <LoadingSession />;
  }

  if (isAuthenticated === false) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-4 text-center p-4">
        <XCircle className="w-12 h-12 text-red-500 animate-bounce" />
        <h2 className="text-xl font-bold text-white">Access Denied</h2>
        <p className="text-sm text-slate-400 max-w-sm">
          You must be signed in to access the Role Management page. Redirecting to login page...
        </p>
        <Link href="/login">
          <Button className="bg-emerald-600 hover:bg-emerald-500 text-white mt-2">
            Go to Login
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="h-screen bg-background text-foreground flex overflow-hidden">
      {/* Sidebar */}
      <Sidebar activePath="/users" />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Navbar */}
        <Navbar title="Role Management" />

        {/* Scrollable Main Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <Shield className="h-7 w-7 text-primary" /> Role Management
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Configure user authorization profiles, permissions, and custom access rights.
              </p>
            </div>
          </div>

          <div className="w-full space-y-6 pb-8">

            {/* Status Notifications */}
            {successMessage && (
              <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-450 p-4 rounded-sm text-xs animate-fadeIn">
                <CheckCircle className="w-4 h-4 flex-shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}

            {error && (
              <div className="flex items-center gap-2 bg-rose-500/10 border border-rose-500/20 text-rose-450 p-4 rounded-sm text-xs animate-fadeIn">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Tab Navigation */}
            <div className="flex border-b border-border gap-6">
              <Link href="/users">
                <span className="pb-3 text-xs font-semibold text-muted-foreground hover:text-foreground cursor-pointer transition-colors block">
                  Users Directory
                </span>
              </Link>
              <span className="pb-3 text-xs font-semibold text-primary border-b-2 border-primary cursor-default block">
                Role Management
              </span>
            </div>

            {/* Header Action */}
            <div className="flex items-center justify-between bg-card/40 backdrop-blur-md border border-border/50 p-4 rounded-sm">
              <div>
                <h3 className="text-xs font-bold text-foreground">System Roles Directory</h3>
                <p className="text-[10px] text-muted-foreground mt-1">Manage system roles and create new custom roles for your team.</p>
              </div>
              <Button
                onClick={handleOpenCreateModal}
                className="bg-primary hover:bg-primary/90 text-primary-foreground text-xs gap-1.5 shadow-md shadow-primary/10 h-9 rounded-sm"
              >
                <Plus className="w-4 h-4" /> Create Custom Role
              </Button>
            </div>

            {/* Roles Grid */}
            {loading ? (
              <div className="py-24 flex flex-col items-center justify-center gap-3 text-muted-foreground font-mono text-xs">
                <Loader2 className="w-6 h-6 animate-spin text-primary" />
                Fetching system roles...
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {rolesList.map((role) => (
                  <Card key={role.id} className="bg-card/40 backdrop-blur-md border-border/50 shadow-sm relative overflow-hidden group hover:border-border transition-all duration-250 flex flex-col justify-between">
                    
                    {/* Header Decoration */}
                    <div className={`absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r ${
                      role.isCustom 
                        ? "from-primary to-primary/60" 
                        : "from-muted-foreground/30 to-muted-foreground/10"
                    }`} />

                    <CardHeader className="pb-3 pt-5">
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <CardTitle className="text-sm font-bold text-foreground flex items-center gap-2">
                            {role.name}
                            <span className={`inline-flex items-center text-[8px] font-bold px-1.5 py-0.5 rounded-sm uppercase tracking-wider ${
                              role.isCustom 
                                ? "bg-primary/10 text-primary border border-primary/20" 
                                : "bg-secondary text-secondary-foreground border border-border"
                            }`}>
                              {role.isCustom ? "Custom" : "System"}
                            </span>
                          </CardTitle>
                          <span className="text-[10px] font-mono text-muted-foreground block">Identifier: {role.role}</span>
                        </div>
                        <div className={`p-2 rounded-sm ${
                          role.isCustom ? "bg-primary/10 text-primary" : "bg-secondary text-muted-foreground"
                        }`}>
                          <Shield className="w-4 h-4" />
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent className="space-y-4 flex-1 flex flex-col justify-between">
                      <p className="text-xs text-muted-foreground leading-relaxed min-h-[36px]">
                        {role.description || "No description provided."}
                      </p>

                      <div className="space-y-3 pt-2">
                        <div className="flex items-center justify-between border-t border-border pt-3">
                          <span className="text-[10px] text-muted-foreground font-mono">Permissions Granted</span>
                          <span className="text-xs font-bold text-foreground font-mono">{role.permissions?.length || 0}</span>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center justify-end gap-2 pt-1">
                          <Button
                            onClick={() => handleOpenEditModal(role)}
                            disabled={!role.isCustom}
                            variant="outline"
                            className={`bg-card/45 border-border/60 hover:bg-primary/10 hover:text-primary text-[10px] h-8 px-3 gap-1 rounded-sm flex-1 ${
                              !role.isCustom ? "opacity-20 cursor-not-allowed border-border/20" : ""
                            }`}
                            title={role.isCustom ? "Edit Role" : "System Default roles cannot be modified"}
                          >
                            <Edit2 className="w-3 h-3" /> Edit Role
                          </Button>
                          
                          <Button
                            onClick={() => handleOpenDeleteConfirm(role)}
                            disabled={!role.isCustom}
                            variant="outline"
                            className={`bg-card/45 border-border/60 hover:bg-rose-500/10 hover:text-rose-500 text-[10px] h-8 px-3 gap-1 rounded-sm flex-1 ${
                              !role.isCustom ? "opacity-20 cursor-not-allowed border-border/20" : ""
                            }`}
                            title={role.isCustom ? "Delete Custom Role" : "System Default roles cannot be deleted"}
                          >
                            <Trash2 className="w-3 h-3" /> Delete
                          </Button>
                        </div>
                      </div>
                    </CardContent>

                  </Card>
                ))}
              </div>
            )}

          </div>
        </main>
      </div>

      {/* ========================================================
          CREATE / EDIT ROLE MODAL (CUSTOM THEME DIALOG)
          ======================================================== */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto animate-fadeIn">
          <div className="w-full max-w-2xl bg-card border border-border rounded-sm my-8 shadow-2xl relative flex flex-col">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-border bg-background/40">
              <h3 className="text-sm font-bold text-foreground tracking-wider uppercase font-mono">
                {modalMode === "create" ? "Create Custom Role" : "Edit Role Settings"}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSaveRole} className="flex flex-col overflow-hidden">
              <div className="p-6 space-y-5 overflow-y-auto max-h-[60vh]">
                
                {/* Inputs Row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Role Name */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">
                      Role Name
                    </label>
                    <Input
                      type="text"
                      required
                      placeholder="e.g. Supervisor"
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                      className="bg-background/50 border-input focus:border-primary/40 text-xs text-foreground h-9 rounded-sm"
                    />
                  </div>

                  {/* Role Identifier (Slug) */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono flex items-center justify-between">
                      Role Identifier (Slug)
                      {modalMode === "edit" && <span className="text-[9px] text-muted-foreground lowercase">(Cannot be changed)</span>}
                    </label>
                    <Input
                      type="text"
                      required
                      disabled={modalMode === "edit"}
                      placeholder="e.g. supervisor"
                      value={formSlug}
                      onChange={(e) => setFormSlug(e.target.value)}
                      className="bg-background/50 border-input focus:border-primary/40 text-xs text-foreground h-9 rounded-sm disabled:opacity-50"
                    />
                  </div>
                </div>

                {/* Description */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">
                    Description
                  </label>
                  <textarea
                    placeholder="Briefly describe the purpose of this role and its access levels..."
                    value={formDescription}
                    onChange={(e) => setFormDescription(e.target.value)}
                    rows={2}
                    className="w-full p-3 bg-background/50 border border-input focus:border-primary/40 text-xs text-foreground rounded-sm outline-none resize-none"
                  />
                </div>

                {/* Permissions Selector */}
                <div className="space-y-3 border-t border-border pt-4">
                  <div>
                    <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">
                      Configure Permissions
                    </label>
                    <p className="text-[10px] text-muted-foreground mt-0.5">Select the capabilities this role will grant to users.</p>
                  </div>

                  {/* Permissions Checklist */}
                  <div className="space-y-5 mt-3">
                    {permissionGroups.map((group) => (
                      <div key={group.category} className="space-y-2 bg-muted/10 border border-border/45 p-3 rounded-sm">
                        <h4 className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider border-b border-border/40 pb-1.5">
                          {group.category}
                        </h4>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                          {group.items.map((item) => {
                            const isChecked = formPermissions.includes(item.id);
                            return (
                              <button
                                key={item.id}
                                type="button"
                                onClick={() => handleTogglePermission(item.id)}
                                className="flex items-start gap-2 text-left hover:bg-secondary/40 p-1.5 rounded-sm transition-all duration-150 group"
                              >
                                <div className={`w-4.5 h-4.5 rounded-sm border flex items-center justify-center mt-0.5 flex-shrink-0 transition-all ${
                                  isChecked
                                    ? "bg-primary border-primary text-primary-foreground"
                                    : "bg-background border-input group-hover:border-primary/60 text-transparent"
                                }`}>
                                  <ChevronRight className={`w-3 h-3 transition-transform ${isChecked ? "rotate-90 text-primary-foreground" : ""}`} />
                                </div>
                                <div className="space-y-0.5">
                                  <span className="text-[11px] font-semibold text-foreground group-hover:text-primary transition-colors">
                                    {item.name}
                                  </span>
                                  <p className="text-[9px] text-muted-foreground font-medium leading-normal">
                                    {item.description}
                                  </p>
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

              {/* Modal Footer */}
              <div className="px-6 py-4 border-t border-border bg-background/40 flex items-center justify-end gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsModalOpen(false)}
                  className="text-xs h-9 rounded-sm"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={actionLoading}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground text-xs h-9 rounded-sm px-4 shadow-md shadow-primary/10 flex items-center gap-1.5"
                >
                  {actionLoading ? (
                    <>
                      <Loader2 className="w-3 h-3 animate-spin" /> Saving...
                    </>
                  ) : (
                    "Save Role"
                  )}
                </Button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* ========================================================
          DELETE CONFIRMATION DIALOG (CUSTOM THEME DIALOG)
          ======================================================== */}
      {isDeleteConfirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-sm bg-card border border-border rounded-sm overflow-hidden shadow-2xl relative">
            
            <div className="p-6 space-y-4 text-center">
              <div className="mx-auto w-12 h-12 rounded-full bg-rose-500/10 border border-rose-500/25 flex items-center justify-center text-rose-500">
                <Trash2 className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-foreground tracking-wider uppercase font-mono">
                  Delete Custom Role?
                </h3>
                <p className="text-xs text-muted-foreground">
                  Are you sure you want to delete <strong className="text-foreground">{roleToDelete?.name}</strong>? Users assigned to this role will lose their permissions. This action cannot be undone.
                </p>
              </div>
            </div>

            <div className="px-6 py-4 border-t border-border bg-background/40 flex items-center justify-center gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsDeleteConfirmOpen(false)}
                className="text-xs h-9 rounded-sm flex-1"
              >
                Cancel
              </Button>
              <Button
                type="button"
                variant="destructive"
                onClick={handleDeleteRole}
                disabled={actionLoading}
                className="text-xs h-9 rounded-sm flex-1 shadow-md shadow-rose-500/10 flex items-center justify-center gap-1.5"
              >
                {actionLoading ? (
                  <>
                    <Loader2 className="w-3 h-3 animate-spin" /> Deleting...
                  </>
                ) : (
                  "Delete"
                )}
              </Button>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
