export interface Product {
  id: string;
  name: string;
  category: "Blinds" | "Curtains" | "Outdoor Solutions" | "Outdoor Living" | "PVC Solutions";
  description: string;
  image: string;
  features: string[];
}

export const products: Product[] = [
  {
    id: "monsoon-blinds",
    name: "Monsoon Blinds",
    category: "Blinds",
    description: "Heavy-duty outdoor weather blinds engineered to withstand torrential rain, high winds, and harsh tropical monsoons while preserving clear exterior views.",
    image: "/monsoon_blinds.jpg",
    features: ["Heavy Rain & Wind Resistant", "Clear Vision Material", "Marine-Grade Track Seal", "Corrosion Resistant Guides"]
  },
  {
    id: "zebra-blinds",
    name: "Zebra Blinds",
    category: "Blinds",
    description: "Innovative dual-layered alternating sheer and solid fabric stripes that effortlessly shift to give you precision light filtering and total privacy.",
    image: "/gallery_1.png",
    features: ["Dual-Layer Light Control", "Contemporary Striped Aesthetic", "Anti-Static & Dust Repellent", "Motorized & Cordless Options"]
  },
  {
    id: "roller-blinds",
    name: "Roller Blinds",
    category: "Blinds",
    description: "Sleek, minimalist roller blinds available in sunscreen, translucent, and 100% total blackout fabrics tailored for modern residential and office spaces.",
    image: "/icon_blinds_1786042796413.png",
    features: ["UV & Solar Glare Reduction", "100% Total Blackout Options", "Smooth Silent Operation", "Somfy Smart Hub Compatible"]
  },
  {
    id: "roman-blinds",
    name: "Roman Blinds",
    category: "Blinds",
    description: "Sophisticated tailored fabric folds that stack smoothly when raised, adding luxurious texture, depth, and timeless elegance to any room.",
    image: "/roman_blinds.jpg",
    features: ["Handcrafted Elegant Folds", "Thermal Insulation Lining", "Premium Textured Linens & Velvets", "Custom Widths & Drops"]
  },
  {
    id: "curtains",
    name: "Curtains",
    category: "Curtains",
    description: "Handcrafted custom sheer and blackout draperies with elegant wave folds, offering luxurious light diffusion and acoustic sound reduction.",
    image: "/icon_curtains_1786042819663.png",
    features: ["Custom Wave & Ripplefolds", "100% Total Acoustic & Light Block", "Flame-Retardant Fabric Options", "Motorized Drapery Tracks Available"]
  },
  {
    id: "vertical-blinds",
    name: "Vertical Blinds",
    category: "Blinds",
    description: "Versatile 180-degree rotating vertical louvers ideal for large patio doors, floor-to-ceiling windows, and commercial corporate suites.",
    image: "/vertical_blinds.jpg",
    features: ["180° Precision Tilt Control", "Perfect for Floor-to-Ceiling Windows", "Durable & Easy to Wipe Clean", "Slimline Track Systems"]
  },
  {
    id: "timber-venetian-blinds",
    name: "Timber Venetian Blinds",
    category: "Blinds",
    description: "Natural hardwood timber horizontal slats that bring rich organic warmth, premium craftsmanship, and precise angle light control.",
    image: "/timber_venetian_blinds.jpg",
    features: ["100% Authentic Natural Hardwood", "Fine Angle Slats Tilt", "Moisture & Warp-Treated Finish", "Warm Architectural Glow"]
  },
  {
    id: "awning",
    name: "Awning",
    category: "Outdoor Solutions",
    description: "Motorized and manual retractable cassette awnings providing instant sun and rain protection over outdoor patios, balconies, and storefronts.",
    image: "/icon_awnings_1786042874286.png",
    features: ["Automatic Wind Sensor Retraction", "Waterproof Marine Acrylic Fabric", "Sturdy Rust-Proof Aluminum Arms", "Integrated LED Lighting Strip"]
  },
  {
    id: "canopy",
    name: "Canopy",
    category: "Outdoor Solutions",
    description: "Architectural fixed and arched canopies offering stylish, heavy-duty weather shelter for grand villa entrances, terraces, and retail facades.",
    image: "/canopy.jpg",
    features: ["Heavy-Duty Architectural Framing", "All-Weather UV & Rain Shield", "Custom Contoured Shapes", "Commercial Grade Durability"]
  },
  {
    id: "pergola",
    name: "Pergola",
    category: "Outdoor Solutions",
    description: "Luxury motorized louvered bioclimatic pergola systems that transform your garden, terrace, or rooftop into an all-weather outdoor retreat.",
    image: "/pergola.jpg",
    features: ["Adjustable Motorized Louver Roof", "Built-In Rainwater Drainage", "Integrated Ambient LED Lighting", "Remote & Smart App Control"]
  },
  {
    id: "outdoor-teak-sunbed",
    name: "Outdoor Teak Sunbed",
    category: "Outdoor Living",
    description: "Handcrafted Grade-A natural teak sun loungers built for resort poolside and outdoor garden lounging with all-weather plush cushions.",
    image: "/outdoor_teak_sunbed.jpg",
    features: ["Grade-A Natural Teak Hardwood", "Weatherproof Quick-Dry Cushions", "Multi-Position Ergonomic Recline", "Water & Termite Resistant"]
  },
  {
    id: "outdoor-fabric",
    name: "Outdoor Fabric",
    category: "Outdoor Living",
    description: "High-performance marine-grade solution-dyed acrylic and polyester fabrics designed for outdoor furniture, upholstery, and weather shading.",
    image: "/outdoor_fabric.jpg",
    features: ["100% Solution-Dyed Acrylic", "UV Fade & Mold Resistant", "Water Repellent Finish", "10-Year Color Fastness"]
  },
  {
    id: "outdoor-uv-clear-pvc",
    name: "Outdoor UV Clear PVC",
    category: "PVC Solutions",
    description: "Heavy-duty optical-grade transparent PVC weather screens providing crystal-clear views while completely shielding against rain, wind, and dust.",
    image: "/outdoor_uv_clear_pvc.jpg",
    features: ["Optical-Grade Crystal Clear View", "100% Rain & Wind Deflector", "UV Stabilized Anti-Yellowing", "Reinforced Track & Zipper Borders"]
  }
];

export const productCategories = [
  "All",
  "Blinds",
  "Curtains",
  "Outdoor Solutions",
  "Outdoor Living",
  "PVC Solutions"
] as const;

export type ProductCategory = (typeof productCategories)[number];
