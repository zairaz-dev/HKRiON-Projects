export const projects = [
  {
    id: "proj1",
    title: "Luxury Villa Master Bedroom",
    category: "Residential",
    description: "Installation of automated blackout curtains and sheer blinds for ultimate comfort and privacy.",
    image: "/gallery_1.png",
    client: "Private Residence"
  },
  {
    id: "proj2",
    title: "Corporate Headquarters Lobby",
    category: "Commercial",
    description: "Custom oversized roller blinds to manage glare while maintaining the spectacular city view.",
    image: "/gallery_2.png",
    client: "Tech Innovations Inc."
  },
  {
    id: "proj3",
    title: "Boutique Hotel Suites",
    category: "Commercial",
    description: "Elegant venetian blinds and custom drapery fitted across 50 luxury suites.",
    image: "/gallery_3.png",
    client: "The Grand Horizon Hotel"
  },
  {
    id: "proj4",
    title: "Modern Apartment Living Space",
    category: "Residential",
    description: "Motorized zebra blinds integrated with the home's smart automation system.",
    image: "/gallery_4.png",
    client: "Private Client"
  },
  {
    id: "proj5",
    title: "Café Outdoor Seating",
    category: "Commercial",
    description: "Retractable canopy awnings and clear PVC enclosures for year-round outdoor dining.",
    image: "/icon_restaurant_1786043029527.png",
    client: "Bistro 42"
  },
  {
    id: "proj6",
    title: "Backyard Pergola Oasis",
    category: "Residential",
    description: "Custom shade sails and outdoor roller blinds for a comfortable summer entertainment area.",
    image: "/icon_home_1786042956619.png",
    client: "Private Residence"
  }
];

export const projectCategories = ["All", "Residential", "Commercial"];
