import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { SessionManager } from "@/core/auth/session";
import { AUTH_CONSTANTS } from "@/core/auth/constants";
import { SafeHttp } from "@/core/http/redirect";

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // 1. Extract Token from cookie map or raw header
  let token = request.cookies.get(AUTH_CONSTANTS.SESSION_COOKIE_NAME)?.value;
  if (!token) {
    const rawCookie = request.headers.get("cookie");
    if (rawCookie) {
      const match = rawCookie.split(";").map(c => c.trim()).find(c => c.startsWith(`${AUTH_CONSTANTS.SESSION_COOKIE_NAME}=`));
      if (match) token = match.split("=")[1];
    }
  }

  // 2. Validate Session
  const session = token ? await SessionManager.verifyToken(token) : null;
  const isAuthenticated = Boolean(session);

  // 3. Route Guard: Protected Admin Routes
  if (pathname.startsWith("/admin")) {
    if (!isAuthenticated) {
      const loginUrl = SafeHttp.getUrl("/login", request);
      loginUrl.searchParams.set("callbackUrl", pathname);
      return NextResponse.redirect(loginUrl);
    }
  }

  // 4. Route Guard: Already Authenticated on /login
  if (pathname === "/login" && isAuthenticated) {
    return NextResponse.redirect(SafeHttp.getUrl("/admin", request));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*", "/login"],
};
