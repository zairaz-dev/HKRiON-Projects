import React from "react";
import { cookies } from "next/headers";
import {
  SESSION_COOKIE_NAME,
  CUSTOMER_SESSION_COOKIE_NAME,
  verifySessionToken,
  verifyCustomerSessionToken,
} from "@/lib/auth";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { CartDrawer } from "@/features/cart/components/CartDrawer";
import { WhatsAppFloatingButton } from "@/components/ui/WhatsAppFloatingButton";
import { EcomPageLayout } from "./EcomPageLayout";

export default async function EcomLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const cookieStore = await cookies();
  const adminToken = cookieStore.get(SESSION_COOKIE_NAME)?.value;
  const customerToken = cookieStore.get(CUSTOMER_SESSION_COOKIE_NAME)?.value;

  const adminSession = adminToken ? verifySessionToken(adminToken) : null;
  const customerSession = customerToken ? verifyCustomerSessionToken(customerToken) : null;

  const initialIsLoggedIn = Boolean(adminSession || customerSession);
  const initialRole = adminSession ? ("ADMIN" as const) : customerSession ? ("CUSTOMER" as const) : null;

  return (
    <EcomPageLayout
      header={<Header initialIsLoggedIn={initialIsLoggedIn} initialRole={initialRole} />}
      footer={<Footer />}
    >
      {children}
      <CartDrawer />
      <WhatsAppFloatingButton />
    </EcomPageLayout>
  );
}
