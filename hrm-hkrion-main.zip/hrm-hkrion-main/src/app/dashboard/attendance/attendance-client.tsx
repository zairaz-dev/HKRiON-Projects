"use client";

import { useState, useEffect } from "react";
import { clockIn, clockOut } from "@/actions/attendance";
import { Clock, LogIn, LogOut, CheckCircle2, AlertTriangle, CalendarClock, Search, Filter, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import Papa from "papaparse";
import { Input } from "@/components/ui/input";
import { Modal } from "@/components/ui/modal";
import { PageHeader } from "@/components/ui/page-header";
import { Badge } from "@/components/ui/badge";
import { Select } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { toast } from "sonner";

type AttendanceRecord = {
  id: number;
  userId: number;
  date: Date;
  clockIn: Date | null;
  clockOut: Date | null;
  status: string;
  user: {
    firstName: string;
    lastName: string;
    email: string;
  };
};

type TodayAttendance = {
  id: number;
  clockIn: Date | null;
  clockOut: Date | null;
  status: string;
} | null;

type AttendanceClientProps = {
  records: AttendanceRecord[];
  todayAttendance: TodayAttendance;
  isSuperAdmin?: boolean;
};

export default function AttendanceClient({
  records,
  todayAttendance,
  isSuperAdmin = false,
}: AttendanceClientProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [mounted, setMounted] = useState(false);

  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [sortBy, setSortBy] = useState("date-desc");

  useEffect(() => {
    setMounted(true);
  }, []);

  const filteredRecords = records
    .filter((record) => {
      const matchesSearch = `${record.user.firstName} ${record.user.lastName}`.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === "ALL" || record.status === statusFilter;
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      if (sortBy === "date-desc") return new Date(b.date).getTime() - new Date(a.date).getTime();
      if (sortBy === "date-asc") return new Date(a.date).getTime() - new Date(b.date).getTime();
      if (sortBy === "clockin") {
        const timeA = a.clockIn ? new Date(a.clockIn).getTime() : 0;
        const timeB = b.clockIn ? new Date(b.clockIn).getTime() : 0;
        return timeA - timeB;
      }
      return 0;
    });

  const hasClockedIn = !!todayAttendance?.clockIn;
  const hasClockedOut = !!todayAttendance?.clockOut;

  const handleClockIn = async () => {
    setIsLoading(true);
    setError(null);
    const res = await clockIn();
    if (res.error) {
      setError(res.error);
      toast.error(res.error);
    } else {
      toast.success("Clocked in successfully!");
    }
    setIsLoading(false);
  };

  const handleClockOut = async () => {
    setIsLoading(true);
    setError(null);
    const res = await clockOut();
    if (res.error) {
      setError(res.error);
      toast.error(res.error);
    } else {
      toast.success("Clocked out successfully!");
    }
    setIsLoading(false);
  };

  const formatTime = (date: Date | null) => {
    if (!mounted || !date) return "—";
    return new Date(date).toLocaleTimeString("en-US", { hour: '2-digit', minute: '2-digit' });
  };

  const formatDate = (date: Date) => {
    if (!mounted) return "";
    return new Date(date).toLocaleDateString("en-US", { weekday: 'short', month: 'short', day: 'numeric' });
  };

  const handleExportCSV = () => {
    if (!filteredRecords.length) {
      toast.error("No records to export.");
      return;
    }

    const data = filteredRecords.map(record => ({
      Date: formatDate(record.date),
      EmployeeName: `${record.user.firstName} ${record.user.lastName}`,
      Email: record.user.email,
      ClockIn: formatTime(record.clockIn),
      ClockOut: formatTime(record.clockOut),
      Status: record.status
    }));

    const csv = Papa.unparse(data);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `Attendance_Export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success("Attendance exported successfully!");
  };

  return (
    <div className="space-y-6">
      <PageHeader 
        title="Attendance"
        description="Track clock-in, clock-out, and daily attendance records."
        actions={
          <Button onClick={handleExportCSV} variant="outline" className="hidden sm:flex">
            <Download className="mr-2 h-4 w-4" />
            Export CSV
          </Button>
        }
      />

      {error && (
        <div className="p-3 rounded-md bg-error-bg border border-error-border text-error text-sm flex items-start gap-2">
          <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {/* Clock In/Out Widget */}
      {!isSuperAdmin && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="flex flex-col items-center justify-center text-center p-6 shadow-sm border-border">
            <div className="text-sm font-medium text-text-secondary mb-1">Today's Status</div>
            <div className="text-2xl font-semibold text-text-primary mb-6">
              {!hasClockedIn ? "Not Clocked In" : hasClockedOut ? "Clocked Out" : "Clocked In"}
            </div>
            
            {!hasClockedIn ? (
              <Button
                onClick={handleClockIn}
                disabled={isLoading}
                className="w-full py-6 text-base"
              >
                {isLoading ? (
                  <div className="h-5 w-5 rounded-full border-2 border-white border-t-transparent animate-spin"></div>
                ) : (
                  <>
                    <LogIn className="mr-2 h-5 w-5" />
                    Clock In
                  </>
                )}
              </Button>
            ) : !hasClockedOut ? (
              <Button
                variant="destructive"
                onClick={handleClockOut}
                disabled={isLoading}
                className="w-full py-6 text-base"
              >
                {isLoading ? (
                  <div className="h-5 w-5 rounded-full border-2 border-white border-t-transparent animate-spin"></div>
                ) : (
                  <>
                    <LogOut className="mr-2 h-5 w-5" />
                    Clock Out
                  </>
                )}
              </Button>
            ) : (
              <div className="w-full inline-flex items-center justify-center gap-2 rounded-md bg-surface-elevated border border-border px-4 py-3 text-sm font-medium text-text-secondary cursor-not-allowed">
                <CheckCircle2 className="h-5 w-5" />
                Completed for Today
              </div>
            )}
          </Card>

          <Card className="md:col-span-2 flex flex-col justify-center p-6 shadow-sm border-border">
            <div className="grid grid-cols-2 gap-6">
              <div className="rounded-lg bg-surface-elevated p-4 border border-border flex flex-col items-start">
                <div className="flex items-center gap-2 text-xs font-medium text-text-secondary uppercase tracking-wider mb-2">
                  <Clock className="h-4 w-4" />
                  Clock In Time
                </div>
                <div className="text-2xl font-semibold text-text-primary font-mono">
                  {formatTime(todayAttendance?.clockIn || null)}
                </div>
              </div>
              <div className="rounded-lg bg-surface-elevated p-4 border border-border flex flex-col items-start">
                <div className="flex items-center gap-2 text-xs font-medium text-text-secondary uppercase tracking-wider mb-2">
                  <Clock className="h-4 w-4" />
                  Clock Out Time
                </div>
                <div className="text-2xl font-semibold text-text-primary font-mono">
                  {formatTime(todayAttendance?.clockOut || null)}
                </div>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Historical Records */}
      <div className="flex flex-col sm:flex-row gap-4 mb-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-text-secondary" />
          <Input
            type="text"
            placeholder="Search by employee name..."
            className="pl-9 bg-surface"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="w-36">
            <Select
              size="sm"
              value={statusFilter}
              onValueChange={setStatusFilter}
              options={[
                { value: "ALL", label: "All Statuses" },
                { value: "PRESENT", label: "Present" },
                { value: "LATE", label: "Late" },
                { value: "ABSENT", label: "Absent" },
              ]}
            />
          </div>
          <div className="w-44">
            <Select
              size="sm"
              value={sortBy}
              onValueChange={setSortBy}
              options={[
                { value: "date-desc", label: "Sort: Date (Newest)" },
                { value: "date-asc", label: "Sort: Date (Oldest)" },
                { value: "clockin", label: "Sort: Clock In Time" },
              ]}
            />
          </div>
        </div>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Date</TableHead>
            <TableHead>Employee</TableHead>
            <TableHead>Clock In</TableHead>
            <TableHead>Clock Out</TableHead>
            <TableHead className="text-right">Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
        {filteredRecords.length === 0 ? (
          <TableRow>
            <TableCell colSpan={5} className="h-32 text-center">
              <div className="flex flex-col items-center justify-center text-text-secondary">
                <CalendarClock className="h-10 w-10 mb-3 text-border" />
                <p className="font-medium text-text-primary">No attendance records</p>
                <p className="text-sm mt-1">Try adjusting your search or filter.</p>
              </div>
            </TableCell>
          </TableRow>
        ) : (
          filteredRecords.map((record) => (
            <TableRow key={record.id}>
                <TableCell className="font-medium text-text-primary whitespace-nowrap">
                  {formatDate(record.date)}
                </TableCell>
                <TableCell className="whitespace-nowrap">
                  <div className="font-medium text-text-primary">{record.user.firstName} {record.user.lastName}</div>
                  <div className="text-xs text-text-secondary">{record.user.email}</div>
                </TableCell>
                <TableCell className="font-mono text-text-secondary">
                  {formatTime(record.clockIn)}
                </TableCell>
                <TableCell className="font-mono text-text-secondary">
                  {formatTime(record.clockOut)}
                </TableCell>
                <TableCell className="text-right">
                  <Badge 
                    variant={
                      record.status === 'PRESENT' ? 'success' :
                      record.status === 'LATE' ? 'warning' :
                      'error'
                    }
                  >
                    {record.status}
                  </Badge>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}
