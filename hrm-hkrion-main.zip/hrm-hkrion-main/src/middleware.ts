import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { jwtVerify } from "jose";

const secretKey = process.env.SESSION_SECRET;
const encodedKey = new TextEncoder().encode(secretKey);

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const sessionCookie = request.cookies.get("session")?.value;

  let isValidSession = false;
  if (sessionCookie) {
    try {
      await jwtVerify(sessionCookie, encodedKey, {
        algorithms: ["HS256"],
      });
      isValidSession = true;
    } catch {
      isValidSession = false;
    }
  }

  const isAuthRoute = pathname.startsWith("/login");
  const isDashboardRoute = pathname.startsWith("/dashboard");

  // If user is authenticated and tries to access /login, redirect to /dashboard
  if (isAuthRoute && isValidSession) {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  // If user is not authenticated and tries to access /dashboard, redirect to /login
  if (isDashboardRoute && !isValidSession) {
    const response = NextResponse.redirect(new URL("/login", request.url));
    if (sessionCookie) {
      response.cookies.delete("session");
    }
    return response;
  }

  // If visiting root / with valid session, redirect to /dashboard
  if (pathname === "/" && isValidSession) {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    "/",
    "/login",
    "/dashboard",
    "/dashboard/:path*",
  ],
};
