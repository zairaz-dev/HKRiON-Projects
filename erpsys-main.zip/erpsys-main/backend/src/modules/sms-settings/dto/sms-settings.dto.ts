export class UpdateSmsSettingsDto {
  businessId?: string;
  enableSms?: boolean;
  gatewayUrl?: string;
  httpMethod?: string;
  apiKey?: string;
  apiSecret?: string;
  senderId?: string;
  mobileParamName?: string;
  messageParamName?: string;
  customHeaders?: string;

  sendOnSale?: boolean;
  saleTemplate?: string;
  sendOnPayment?: boolean;
  paymentTemplate?: string;
}

export class TestSmsDto {
  businessId?: string;
  mobileNumber: string;
  message?: string;
}
