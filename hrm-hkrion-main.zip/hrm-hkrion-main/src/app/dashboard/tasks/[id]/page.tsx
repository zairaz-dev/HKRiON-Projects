import { getSession } from "@/lib/session";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { Role } from "@prisma/client";
import TaskWorkspaceClient from "./task-workspace-client";

export default async function TaskWorkspacePage({ params }: { params: Promise<{ id: string }> }) {
  const session = await getSession();

  if (!session) {
    redirect("/login");
  }

  const { id } = await params;
  const taskId = parseInt(id);
  if (isNaN(taskId)) redirect("/dashboard/tasks");

  const task = await prisma.task.findUnique({
    where: { id: taskId },
    include: {
      assignees: {
        select: {
          id: true,
          firstName: true,
          lastName: true,
          email: true,
          profileImage: true,
          role: true,
          position: { select: { title: true } },
        },
      },
      assigner: {
        select: {
          id: true,
          firstName: true,
          lastName: true,
          email: true,
          profileImage: true,
          role: true,
          position: { select: { title: true } },
        },
      },
      milestones: {
        orderBy: { id: "asc" },
      },
      dependencies: {
        select: {
          id: true,
          title: true,
          category: true,
          health: true,
          progress: true,
        },
      },
      updates: {
        orderBy: { createdAt: "desc" },
        include: {
          author: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              profileImage: true,
              role: true,
              position: { select: { title: true } },
            },
          },
        },
      },
    },
  });

  if (!task) redirect("/dashboard/tasks");

  // Basic authorization: Only assignees or manager/admins can view
  const currentUserId = Number(session.userId);
  const isAssignee = task.assignees.some((a) => a.id === currentUserId);
  const isCreator = task.assignerId === currentUserId;
  const isAdminOrManager =
    session.role === Role.SUPER_ADMIN || session.role === Role.MANAGER;

  if (!isAssignee && !isCreator && !isAdminOrManager) {
    redirect("/dashboard/tasks");
  }

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-20">
      <TaskWorkspaceClient
        task={task}
        currentUserId={currentUserId}
        currentUserRole={session.role as Role}
      />
    </div>
  );
}
