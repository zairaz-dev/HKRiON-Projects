import React from "react";
import { InvoiceTemplateProps } from "./types";

export function generateA5CompactHtml(props: InvoiceTemplateProps): string {
  const { sale, layout, businessName, currencySymbol = "₹" } = props;
  const cur = currencySymbol;

  const headerText = layout?.headerText || "TAX INVOICE";
  const showCustomerDetails = layout?.showCustomerDetails ?? true;
  const showSku = layout?.showSku ?? true;
  const footerText = layout?.footerText || "Thank you!";
  const termsConditions = layout?.termsConditions || "";

  return `
    <!DOCTYPE html>
    <html>
      <head>
        <title>${headerText} - ${sale.invoiceNumber}</title>
        <style>
          @page {
            size: A5 landscape;
            margin: 8mm;
          }
          body {
            font-family: Arial, sans-serif;
            font-size: 10px;
            color: #000;
            margin: 0;
          }
          .box { border: 1px solid #333; padding: 10px; }
          .header { display: flex; justify-content: space-between; border-bottom: 1px solid #000; padding-bottom: 6px; }
          table { width: 100%; border-collapse: collapse; margin-top: 8px; font-size: 9px; }
          th, td { border: 1px solid #444; padding: 4px; text-align: left; }
          th { background: #f0f0f0; }
          .totals { text-align: right; margin-top: 8px; font-size: 11px; font-weight: bold; }
        </style>
      </head>
      <body onload="window.print(); window.close();">
        <div class="box">
          <div class="header">
            <div>
              <h2 style="margin: 0; font-size: 14px;">${businessName}</h2>
              <div><b>${headerText}</b></div>
              <div>${sale.branch?.name || ""} ${sale.branch?.phone ? `| Tel: ${sale.branch.phone}` : ""}</div>
            </div>
            <div style="text-align: right;">
              <div><b>Inv #:</b> ${sale.invoiceNumber}</div>
              <div><b>Date:</b> ${new Date(sale.saleDate).toLocaleDateString()}</div>
              ${showCustomerDetails && sale.customer?.name ? `<div><b>Cust:</b> ${sale.customer.name}</div>` : ""}
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>Item</th>
                ${showSku ? `<th>SKU</th>` : ""}
                <th style="text-align: right;">Qty</th>
                <th style="text-align: right;">Price</th>
                <th style="text-align: right;">Total</th>
              </tr>
            </thead>
            <tbody>
              ${sale.saleLines?.map((line: any) => `
                <tr>
                  <td>${line.variant?.product?.name || line.variant?.name}</td>
                  ${showSku ? `<td>${line.variant?.sku || "-"}</td>` : ""}
                  <td align="right">${line.quantity}</td>
                  <td align="right">${cur}${line.unitPrice.toFixed(2)}</td>
                  <td align="right">${cur}${line.subtotal.toFixed(2)}</td>
                </tr>
              `).join("")}
            </tbody>
          </table>

          <div class="totals">
            Grand Total: ${cur}${sale.grandTotal.toFixed(2)}
          </div>

          ${termsConditions ? `<div style="font-size: 8px; margin-top: 8px;"><b>Terms:</b> ${termsConditions}</div>` : ""}
          <div style="text-align: center; margin-top: 10px; font-size: 8px; color: #555;">${footerText}</div>
        </div>
      </body>
    </html>
  `;
}

export function A5CompactTemplate(props: InvoiceTemplateProps) {
  const { sale, layout, businessName, currencySymbol = "₹" } = props;
  const cur = currencySymbol;

  const headerText = layout?.headerText || "TAX INVOICE";
  const showCustomerDetails = layout?.showCustomerDetails ?? true;
  const showSku = layout?.showSku ?? true;
  const footerText = layout?.footerText || "Thank you!";
  const termsConditions = layout?.termsConditions || "";

  return (
    <div className="w-full max-w-[140mm] mx-auto border border-border bg-card text-card-foreground p-4 font-sans text-xs shadow-md rounded max-h-[75vh] overflow-y-auto overflow-x-auto">
      <div className="flex justify-between items-start border-b border-border pb-3 mb-3">
        <div>
          <h2 className="text-base font-bold text-foreground">{businessName}</h2>
          <p className="text-xs font-bold text-primary">{headerText}</p>
          <p className="text-[10px] text-muted-foreground">{sale.branch?.name}</p>
        </div>
        <div className="text-right text-[11px] space-y-0.5">
          <p className="font-bold text-foreground">Inv #: {sale.invoiceNumber}</p>
          <p className="text-muted-foreground">Date: {new Date(sale.saleDate).toLocaleDateString()}</p>
          {showCustomerDetails && sale.customer?.name && (
            <p className="text-muted-foreground">Cust: {sale.customer.name}</p>
          )}
        </div>
      </div>

      <table className="w-full text-[10px] border border-border mb-3 border-collapse">
        <thead>
          <tr className="bg-muted/40 border-b border-border">
            <th className="p-1.5 text-left">Item</th>
            {showSku && <th className="p-1.5 text-left">SKU</th>}
            <th className="p-1.5 text-right" style={{ textAlign: 'right' }}>Qty</th>
            <th className="p-1.5 text-right" style={{ textAlign: 'right' }}>Price</th>
            <th className="p-1.5 text-right" style={{ textAlign: 'right' }}>Total</th>
          </tr>
        </thead>
        <tbody>
          {sale.saleLines?.map((line) => (
            <tr key={line.id} className="border-b border-border/40">
              <td className="p-1.5">{line.variant?.product?.name || line.variant?.name}</td>
              {showSku && <td className="p-1.5 text-muted-foreground">{line.variant?.sku || "-"}</td>}
              <td className="p-1.5 text-right" style={{ textAlign: 'right' }}>{line.quantity}</td>
              <td className="p-1.5 text-right" style={{ textAlign: 'right' }}>{cur}{line.unitPrice.toFixed(2)}</td>
              <td className="p-1.5 text-right font-semibold" style={{ textAlign: 'right' }}>{cur}{line.subtotal.toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="text-right font-bold text-xs text-foreground mb-3">
        Grand Total: {cur}{sale.grandTotal.toFixed(2)}
      </div>

      {termsConditions && (
        <p className="text-[9px] text-muted-foreground border-t border-border pt-1">
          <span className="font-bold">Terms:</span> {termsConditions}
        </p>
      )}

      <p className="text-center text-[9px] text-muted-foreground mt-3">{footerText}</p>
    </div>
  );
}
