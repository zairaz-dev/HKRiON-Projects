"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useCart } from "@/features/cart/context/CartContext";
import { useCurrency } from "@/features/currency/context/CurrencyContext";
import { useWishlist } from "@/features/wishlist/context/WishlistContext";
import { useAuth } from "@/features/auth/context/AuthContext";
import {
  CertificateShieldIcon,
  ArmoredTruckIcon,
  SecurityLockIcon,
  CloseIcon,
  HeartIcon,
  BagIcon,
  CheckIcon,
  AwardIcon
} from "@/components/ui/LuxuryIcons";
import { LuxuryPrice } from "@/components/ui/LuxuryPrice";
import { getPromoDiscount, isValidPromoCode } from "@/lib/constants/promo";

export default function CartPage() {
  const { items, removeFromCart, updateQuantity, subtotal } = useCart();
  const { formatPrice } = useCurrency();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const { isAuthenticated, isLoading: authLoading } = useAuth();

  const [promoCode, setPromoCode] = useState("");
  const [promoApplied, setPromoApplied] = useState(false);

  const promoDiscount = promoApplied ? getPromoDiscount(promoCode) : null;
  const discountAmount = promoDiscount ? Math.round(subtotal * promoDiscount.rate) : 0;
  const finalTotal = subtotal - discountAmount;

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (isValidPromoCode(promoCode)) {
      setPromoApplied(true);
    }
  };

  return (
    <div className="bg-[#FAF8F5] min-h-screen py-12 lg:py-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="border-b border-[#E8E4DC] pb-6 mb-8">
          <span className="text-[11px] font-sans tracking-wide-luxury uppercase text-[#9A7B4F] block mb-1">
            Private Client Acquisitions
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl text-[#18181D]">
            Acquisition Bag
          </h1>
          <p className="text-xs text-[#8C867D] font-sans mt-1">
            {items.length} {items.length === 1 ? "Specimen" : "Specimens"} reserved in active session
          </p>
        </div>

        {items.length === 0 ? (
          <div className="bg-white border border-[#E8E4DC] p-16 text-center shadow-sm">
            <div className="w-16 h-16 rounded-full bg-[#FAF8F5] border border-[#E8E4DC] mx-auto flex items-center justify-center text-[#8C867D] mb-4">
              <BagIcon className="w-8 h-8" />
            </div>
            <h2 className="font-serif text-2xl text-[#18181D]">Your Acquisition Bag is Empty</h2>
            <p className="mt-2 text-xs sm:text-sm text-[#6B655C] font-sans max-w-sm mx-auto leading-relaxed">
              Explore our curated vault of unheated Ceylon sapphires, Mogok rubies, and Colombian emeralds.
            </p>
            <Link
              href="/shop"
              className="inline-block mt-8 px-8 py-3.5 bg-[#18181D] hover:bg-[#2A2A32] text-white text-xs uppercase tracking-luxury font-sans transition-colors"
            >
              Explore Certified Gemstones &rarr;
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            {/* Items Column (8 Cols) */}
            <div className="lg:col-span-8 space-y-6">
              {items.map((item) => {
                const itemKey = `${item.gemstone.id}-${item.selectedVariant?.id || "default"}`;
                const itemWeight = item.selectedWeight ?? item.gemstone.carat;
                const itemBasePrice = item.selectedPrice ?? item.gemstone.price;
                const quantity = item.quantity ?? 1;
                const maxStock = item.selectedVariant?.stock ?? (item.gemstone.inStock ? 99 : 0);

                const unitPrice = itemBasePrice;
                const itemTotal = unitPrice * quantity;
                const isSaved = isInWishlist(item.gemstone.id);

                return (
                  <div
                    key={itemKey}
                    className="bg-white border border-[#E8E4DC] p-6 shadow-sm flex flex-col sm:flex-row gap-6"
                  >
                    {/* Thumbnail */}
                    <div className="relative aspect-square w-28 sm:w-36 flex-shrink-0 bg-[#F7F5F1] border border-[#E8E4DC] overflow-hidden">
                      <Image
                        src={item.gemstone.images?.[0] || (item.gemstone as any).imageUrl || "/uploads/gemstones/gem-1789652077476-hwzsqu.webp"}
                        alt={item.gemstone.name}
                        fill
                        unoptimized={Boolean((item.gemstone.images?.[0] || (item.gemstone as any).imageUrl)?.startsWith("/uploads"))}
                        className="object-cover"
                      />
                    </div>

                    {/* Details */}
                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                      <div>
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <span className="text-[10px] font-mono text-[#8C867D] uppercase tracking-wider block">
                              SKU: {item.gemstone.sku}
                            </span>
                            <Link
                              href={`/gemstones/${item.gemstone.id}`}
                              className="font-serif text-xl text-[#18181D] hover:text-[#9A7B4F] transition-colors line-clamp-1"
                            >
                              {item.gemstone.name}
                            </Link>
                          </div>

                          <div className="text-right">
                            <LuxuryPrice amount={itemTotal} size="xl" />
                            {quantity > 1 && (
                              <span className="block text-[11px] text-[#8C867D] font-mono">
                                ({formatPrice(unitPrice)} each)
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Specs strip */}
                        <div className="mt-2 flex flex-wrap items-center gap-2 text-xs font-sans text-[#6B655C]">
                          <span className="font-medium text-[#18181D] bg-[#F5F2EB] px-2 py-0.5 rounded">
                            {itemWeight.toFixed(2)} ct
                          </span>
                          <span>•</span>
                          <span>{item.gemstone.cut}</span>
                          {item.selectedSize && (
                            <>
                              <span>•</span>
                              <span className="text-[#8C867D]">{item.selectedSize}</span>
                            </>
                          )}
                          <span>•</span>
                          <span>{item.gemstone.origin}</span>
                        </div>

                      </div>

                      {/* Quantity & Actions */}
                      <div className="mt-4 pt-3 border-t border-[#F2EFE9] flex flex-wrap items-center justify-between gap-3 text-xs font-sans">
                        <div className="flex items-center gap-3">
                          <span className="text-[10px] uppercase tracking-wider text-[#8C867D]">Quantity:</span>
                          <div className="inline-flex items-center border border-[#E8E4DC] bg-[#FAF8F5] rounded-sm">
                            <button
                              type="button"
                              onClick={() =>
                                updateQuantity(
                                  item.gemstone.id,
                                  quantity - 1,
                                  item.selectedVariant?.id
                                )
                              }
                              className="px-2.5 py-1 text-xs text-[#18181D] hover:bg-[#E8E4DC] transition-colors"
                            >
                              -
                            </button>
                            <span className="px-3 py-1 text-xs font-mono font-medium text-[#18181D]">
                              {quantity}
                            </span>
                            <button
                              type="button"
                              disabled={quantity >= maxStock}
                              onClick={() =>
                                updateQuantity(
                                  item.gemstone.id,
                                  quantity + 1,
                                  item.selectedVariant?.id
                                )
                              }
                              className="px-2.5 py-1 text-xs text-[#18181D] hover:bg-[#E8E4DC] disabled:opacity-40 disabled:hover:bg-transparent transition-colors"
                            >
                              +
                            </button>
                          </div>
                        </div>

                        <div className="flex items-center gap-4">
                          <button
                            onClick={() => {
                              toggleWishlist(item.gemstone.id);
                              removeFromCart(item.gemstone.id, item.selectedVariant?.id);
                            }}
                            className="text-[#8C867D] hover:text-[#18181D] flex items-center gap-1 uppercase tracking-wider text-[11px]"
                          >
                            <HeartIcon className="w-3.5 h-3.5" filled={isSaved} />
                            <span>Save to Vault</span>
                          </button>

                          <button
                            onClick={() => removeFromCart(item.gemstone.id, item.selectedVariant?.id)}
                            className="text-[#8C867D] hover:text-red-700 uppercase tracking-wider text-[11px]"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}

            </div>

            {/* Summary Column (4 Cols) */}
            <div className="lg:col-span-4 space-y-6">
              <div className="bg-white border border-[#E8E4DC] p-6 shadow-sm space-y-6">
                <h3 className="font-serif text-lg text-[#18181D] border-b border-[#F2EFE9] pb-3">
                  Investment Summary
                </h3>

                <div className="space-y-3 text-xs font-sans">
                  <div className="flex items-center justify-between text-[#554F47]">
                    <span>Vault Subtotal</span>
                    <LuxuryPrice amount={subtotal} size="sm" weight="semibold" />
                  </div>

                  <div className="flex items-center justify-between text-[#554F47]">
                    <span>Armored Courier & Transit Insurance</span>
                    <span className="text-emerald-800 uppercase tracking-wider text-[11px] font-medium">Complimentary</span>
                  </div>

                  {promoApplied && (
                    <div className="flex items-center justify-between text-emerald-800">
                      <span>Private Collector Privilege (5%)</span>
                      <span className="flex items-baseline text-emerald-800 font-semibold">
                        -<LuxuryPrice amount={discountAmount} size="xs" color="inherit" weight="semibold" />
                      </span>
                    </div>
                  )}

                  <div className="pt-4 border-t border-[#E8E4DC] flex items-baseline justify-between">
                    <div>
                      <span className="font-serif text-base text-[#18181D] block">Total Acquisition</span>
                      <span className="text-[10px] text-[#8C867D]">All Duties & Freight Covered</span>
                    </div>
                    <LuxuryPrice amount={finalTotal} size="xl" weight="bold" />
                  </div>
                </div>

                {/* Promo Code input */}
                <form onSubmit={handleApplyPromo} className="pt-2 border-t border-[#F2EFE9]">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      placeholder="Private Privilege Code (try VAULT)"
                      className="flex-1 px-3 py-2 bg-[#FAF8F5] border border-[#E8E4DC] text-xs uppercase font-mono focus:outline-none focus:border-[#C5A880]"
                    />
                    <button
                      type="submit"
                      className="px-3 py-2 bg-[#18181D] text-white text-xs uppercase font-sans hover:bg-[#2A2A32]"
                    >
                      Apply
                    </button>
                  </div>
                  {promoApplied && (
                    <span className="text-[11px] text-emerald-800 font-sans mt-1.5 flex items-center gap-1">
                      <CheckIcon className="w-3.5 h-3.5" />
                      {promoDiscount?.label || "Private Client Privilege Applied"}
                    </span>
                  )}
                </form>

                {/* Checkout CTA */}
                <div className="space-y-2 pt-2">
                  <Link
                    href={!authLoading && !isAuthenticated ? "/login?from=/checkout" : "/checkout"}
                    className="block w-full py-4 bg-[#18181D] hover:bg-[#2A2A32] text-white text-center text-xs uppercase tracking-luxury font-sans font-medium transition-all shadow-lg active:scale-[0.99]"
                  >
                    {!authLoading && !isAuthenticated ? "Sign In to Checkout" : "Proceed to Secure Checkout"} &rarr;
                  </Link>
                  {!authLoading && !isAuthenticated && (
                    <p className="text-[11px] text-[#8C867D] text-center font-sans">
                      Private client sign-in required for insured checkout
                    </p>
                  )}
                  <Link
                    href="/shop"
                    className="block w-full py-2 text-center text-xs text-[#8C867D] hover:text-[#18181D] font-sans uppercase tracking-wider"
                  >
                    Continue Exploring Vault
                  </Link>
                </div>
              </div>

              {/* Reassurance list */}
              <div className="p-5 bg-white border border-[#E8E4DC] space-y-3 text-xs font-sans text-[#554F47]">
                <div className="flex items-center gap-2.5">
                  <ArmoredTruckIcon className="w-4 h-4 text-[#C5A880] flex-shrink-0" />
                  <span>Door-to-door armored air courier via Ferrari Logistics</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <SecurityLockIcon className="w-4 h-4 text-[#C5A880] flex-shrink-0" />
                  <span>30-Day risk-free inspection guarantee with 100% refund</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <CertificateShieldIcon className="w-4 h-4 text-[#C5A880] flex-shrink-0" />
                  <span>Original physical lab certificates enclosed in leather folio</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
