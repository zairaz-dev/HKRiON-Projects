"use client";

import React, { useState, useRef, useEffect, useId, useMemo } from "react";

export interface LuxurySelectOption {
  value: string;
  label: string;
  sublabel?: string;
  badge?: string;
  disabled?: boolean;
  canEdit?: boolean;
  canDelete?: boolean;
}

export interface LuxurySelectProps {
  value: string;
  onChange: (value: string) => void;
  options: (LuxurySelectOption | string)[];
  placeholder?: string;
  searchable?: boolean;
  searchPlaceholder?: string;
  disabled?: boolean;
  variant?: "light" | "dark";
  size?: "sm" | "md" | "lg";
  className?: string;
  triggerClassName?: string;
  menuClassName?: string;
  label?: string;
  id?: string;
  name?: string;
  onEditOption?: (oldValue: string, newValue: string) => boolean | Promise<boolean>;
  onDeleteOption?: (value: string) => boolean | Promise<boolean>;
}

export function LuxurySelect({
  value,
  onChange,
  options,
  placeholder = "Select...",
  searchable = false,
  searchPlaceholder = "Search...",
  disabled = false,
  variant = "light",
  size = "md",
  className = "",
  triggerClassName = "",
  menuClassName = "",
  label,
  id,
  name,
  onEditOption,
  onDeleteOption,
}: LuxurySelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState(-1);
  const [editingValue, setEditingValue] = useState<string | null>(null);
  const [editInputText, setEditInputText] = useState("");
  const [deletingValue, setDeletingValue] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const containerRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const listboxRef = useRef<HTMLUListElement>(null);
  const generatedId = useId();
  const selectId = id || generatedId;

  // Normalize options to objects with stable array reference
  const normalizedOptions: LuxurySelectOption[] = useMemo(
    () =>
      options.map((opt) =>
        typeof opt === "string" ? { value: opt, label: opt } : opt
      ),
    [options]
  );

  const selectedOption = normalizedOptions.find((opt) => opt.value === value);

  // Filtered options based on search query
  const filteredOptions: LuxurySelectOption[] = useMemo(() => {
    if (!searchable || !searchQuery.trim()) return normalizedOptions;
    const q = searchQuery.trim().toLowerCase();
    return normalizedOptions.filter((opt) => {
      const labelMatch = opt.label.toLowerCase().includes(q);
      const valueMatch = opt.value.toLowerCase().includes(q);
      const sublabelMatch = opt.sublabel ? opt.sublabel.toLowerCase().includes(q) : false;
      const badgeMatch = opt.badge ? opt.badge.toLowerCase().includes(q) : false;
      return labelMatch || valueMatch || sublabelMatch || badgeMatch;
    });
  }, [searchable, searchQuery, normalizedOptions]);

  // Close when clicking outside
  useEffect(() => {
    if (!isOpen) return;

    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        setEditingValue(null);
        setDeletingValue(null);
        setSearchQuery("");
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [isOpen]);

  // Reset inline states when closed
  useEffect(() => {
    if (!isOpen) {
      setEditingValue(null);
      setDeletingValue(null);
      setSearchQuery("");
    }
  }, [isOpen]);

  // Sync highlighted index and scroll into view ONLY once when opening
  useEffect(() => {
    if (isOpen) {
      setSearchQuery("");
      const idx = filteredOptions.findIndex((opt) => opt.value === value);
      const target = idx >= 0 ? idx : 0;
      setHighlightedIndex(target);

      requestAnimationFrame(() => {
        if (searchable && searchInputRef.current) {
          searchInputRef.current.focus();
        } else {
          const activeEl = listboxRef.current?.children[target] as HTMLElement;
          activeEl?.scrollIntoView({ block: "nearest" });
        }
      });
    } else {
      setSearchQuery("");
    }
  }, [isOpen, searchable]);

  const handleSelect = (val: string) => {
    onChange(val);
    setIsOpen(false);
    setSearchQuery("");
    triggerRef.current?.focus();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (disabled) return;

    if (!isOpen) {
      if (e.key === "Enter" || e.key === " " || e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        setIsOpen(true);
      }
      return;
    }

    switch (e.key) {
      case "Escape":
      case "Tab":
        setIsOpen(false);
        break;
      case "ArrowDown":
        e.preventDefault();
        setHighlightedIndex((prev) => {
          const next = prev < filteredOptions.length - 1 ? prev + 1 : 0;
          const el = listboxRef.current?.children[next] as HTMLElement;
          el?.scrollIntoView({ block: "nearest" });
          return next;
        });
        break;
      case "ArrowUp":
        e.preventDefault();
        setHighlightedIndex((prev) => {
          const next = prev > 0 ? prev - 1 : filteredOptions.length - 1;
          const el = listboxRef.current?.children[next] as HTMLElement;
          el?.scrollIntoView({ block: "nearest" });
          return next;
        });
        break;
      case "Enter":
      case " ":
        e.preventDefault();
        if (highlightedIndex >= 0 && filteredOptions[highlightedIndex]) {
          const opt = filteredOptions[highlightedIndex];
          if (!opt.disabled) {
            handleSelect(opt.value);
          }
        }
        break;
      default:
        break;
    }
  };

  // Size configurations
  const sizeStyles = {
    sm: "px-2.5 py-1.5 text-xs gap-2",
    md: "px-3 py-2 text-xs gap-2",
    lg: "px-3.5 py-2.5 text-sm gap-2.5",
  }[size];

  // Variant color styling
  const isDark = variant === "dark";

  const triggerBase = isDark
    ? "bg-[#1A1A22] text-white border-[#2A2A36] hover:border-[#C5A880] focus:border-[#C5A880]"
    : "bg-[#FAF8F5] text-[#18181D] border-[#E8E4DC] hover:border-[#C5A880] focus:border-[#C5A880]";

  const menuBase = isDark
    ? "bg-[#15151C] border-[#2A2A38] text-white shadow-2xl"
    : "bg-white border-[#E8E4DC] text-[#18181D] shadow-xl";

  return (
    <div
      ref={containerRef}
      className={`relative inline-block w-full text-left font-sans select-none ${className}`}
    >
      {label && (
        <label
          htmlFor={selectId}
          className={`block uppercase text-[10px] tracking-wider mb-1 ${
            isDark ? "text-[#A29F96] font-mono" : "text-[#554F47]"
          }`}
        >
          {label}
        </label>
      )}

      {/* Hidden input for standard form serialization if name provided */}
      {name && <input type="hidden" name={name} value={value} />}

      {/* Custom Select Trigger */}
      <button
        ref={triggerRef}
        id={selectId}
        type="button"
        role="combobox"
        aria-expanded={isOpen}
        aria-haspopup="listbox"
        aria-controls={`${selectId}-listbox`}
        disabled={disabled}
        onClick={() => !disabled && setIsOpen(!isOpen)}
        onKeyDown={handleKeyDown}
        className={`w-full flex items-center justify-between border rounded-none transition-all duration-150 outline-none btn-luxury-press ${sizeStyles} ${triggerBase} ${
          disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer"
        } ${isOpen ? "border-[#C5A880] ring-1 ring-[#C5A880]/30" : ""} ${triggerClassName}`}
      >
        <div className="flex items-center justify-between gap-2 min-w-0 flex-1 mr-1.5">
          <span className="truncate block text-left">
            {selectedOption ? selectedOption.label : <span className="opacity-60">{placeholder}</span>}
          </span>
          {selectedOption?.badge !== undefined && (
            <span
              className={`text-[9px] font-mono tabular-nums uppercase px-1.5 py-0.5 rounded-sm shrink-0 ${
                isDark
                  ? "bg-[#252534] text-[#C5A880] border border-[#343448]"
                  : "bg-[#EFECE5] text-[#8C6D3B] border border-[#DFD9CE]"
              }`}
            >
              {selectedOption.badge}
            </span>
          )}
        </div>

        <span
          className={`shrink-0 transition-transform duration-200 ${
            isOpen ? "rotate-180 text-[#C5A880]" : isDark ? "text-[#8C867D]" : "text-[#6E6B65]"
          }`}
          aria-hidden="true"
        >
          <svg className="w-3.5 h-3.5" viewBox="0 0 16 16" fill="none" stroke="currentColor">
            <path d="M4 6l4 4 4-4" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </span>
      </button>

      {/* Custom Dropdown Floating Panel */}
      {isOpen && (
        <div
          className={`absolute left-0 right-0 mt-1 z-50 max-h-80 overflow-y-auto no-scrollbar border rounded-none overscroll-contain animate-luxury-popover ${menuBase} ${menuClassName}`}
          style={{ minWidth: "100%" }}
        >
          {searchable && (
            <div
              className={`sticky top-0 z-20 p-2 border-b ${
                isDark ? "bg-[#14141E] border-[#2A2A38]" : "bg-[#FAF8F5] border-[#E8E4DC]"
              }`}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative flex items-center">
                <svg
                  className="w-3.5 h-3.5 absolute left-2.5 text-[#8C867D] pointer-events-none"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <circle cx="11" cy="11" r="8" />
                  <line x1="21" y1="21" x2="16.65" y2="16.65" />
                </svg>
                <input
                  ref={searchInputRef}
                  type="text"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setHighlightedIndex(0);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "ArrowDown") {
                      e.preventDefault();
                      setHighlightedIndex((prev) => {
                        const next = Math.min(prev + 1, filteredOptions.length - 1);
                        const el = listboxRef.current?.children[next] as HTMLElement;
                        el?.scrollIntoView({ block: "nearest" });
                        return next;
                      });
                    } else if (e.key === "ArrowUp") {
                      e.preventDefault();
                      setHighlightedIndex((prev) => {
                        const next = Math.max(prev - 1, 0);
                        const el = listboxRef.current?.children[next] as HTMLElement;
                        el?.scrollIntoView({ block: "nearest" });
                        return next;
                      });
                    } else if (e.key === "Enter") {
                      e.preventDefault();
                      if (filteredOptions.length > 0) {
                        const target = filteredOptions[highlightedIndex >= 0 ? highlightedIndex : 0];
                        if (target && !target.disabled && !target.value.startsWith("__")) {
                          handleSelect(target.value);
                        }
                      }
                    } else if (e.key === "Escape") {
                      e.preventDefault();
                      setIsOpen(false);
                      triggerRef.current?.focus();
                    }
                  }}
                  placeholder={searchPlaceholder}
                  className={`w-full pl-8 pr-7 py-1.5 text-xs border rounded-none focus:outline-none transition-colors ${
                    isDark
                      ? "bg-[#1C1C26] border-[#2A2A38] text-white placeholder-[#8C867D] focus:border-[#C5A880]"
                      : "bg-white border-[#E8E4DC] text-[#18181D] placeholder-[#8C867D] focus:border-[#C5A880]"
                  }`}
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery("");
                      searchInputRef.current?.focus();
                    }}
                    className="absolute right-2.5 text-xs text-[#8C867D] hover:text-[#18181D] p-1 cursor-pointer"
                    title="Clear search"
                  >
                    ✕
                  </button>
                )}
              </div>
            </div>
          )}

          <ul
            ref={listboxRef}
            id={`${selectId}-listbox`}
            role="listbox"
            tabIndex={-1}
            className="py-1 focus:outline-none divide-y divide-transparent"
          >
            {filteredOptions.length === 0 ? (
              <li className="px-4 py-6 text-center text-xs text-[#8C867D]">
                No options matching &quot;{searchQuery}&quot;
              </li>
            ) : (
              filteredOptions.map((opt, index) => {
              const isSelected = opt.value === value;
              const isHighlighted = index === highlightedIndex;

              const optionBg = isDark
                ? isSelected
                  ? "bg-[#222230] text-[#C5A880] font-medium"
                  : isHighlighted
                  ? "bg-[#1C1C26] text-white"
                  : "text-[#DCD8D0] hover:bg-[#1C1C26] hover:text-white"
                : isSelected
                ? "bg-[#F5F2EB] text-[#9A7B4F] font-medium"
                : isHighlighted
                ? "bg-[#FAF8F5] text-[#18181D]"
                : "text-[#3A3732] hover:bg-[#FAF8F5] hover:text-[#18181D]";

              const isSpecialAction = opt.value.startsWith("__");
              const isEditingThis = editingValue === opt.value;
              const isDeletingThis = deletingValue === opt.value;

              if (isEditingThis) {
                return (
                  <li
                    key={`${opt.value}_${index}`}
                    className={`px-3 py-1.5 transition-colors ${
                      isDark ? "bg-[#1C1C26] text-white" : "bg-[#F5F2EB] text-[#18181D]"
                    }`}
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div className="flex items-center gap-1.5 w-full">
                      <input
                        type="text"
                        autoFocus
                        value={editInputText}
                        onChange={(e) => setEditInputText(e.target.value)}
                        onKeyDown={async (e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            e.stopPropagation();
                            if (editInputText.trim() && onEditOption) {
                              const ok = await onEditOption(opt.value, editInputText.trim());
                              if (ok) setEditingValue(null);
                            }
                          } else if (e.key === "Escape") {
                            e.preventDefault();
                            e.stopPropagation();
                            setEditingValue(null);
                          }
                        }}
                        className={`flex-1 min-w-0 px-2 py-1 text-xs border rounded-sm focus:outline-none ${
                          isDark
                            ? "bg-[#121218] border-[#C5A880] text-white"
                            : "bg-white border-[#C5A880] text-[#18181D]"
                        }`}
                      />
                      <button
                        type="button"
                        title="Save"
                        onClick={async (e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          if (editInputText.trim() && onEditOption) {
                            const ok = await onEditOption(opt.value, editInputText.trim());
                            if (ok) setEditingValue(null);
                          }
                        }}
                        className="px-2 py-1 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-[10px] font-semibold uppercase tracking-wider rounded-sm transition-colors shrink-0"
                      >
                        Save
                      </button>
                      <button
                        type="button"
                        title="Cancel"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setEditingValue(null);
                        }}
                        className="px-1.5 py-1 text-[#8C867D] hover:text-white text-xs rounded-sm transition-colors shrink-0"
                      >
                        ✕
                      </button>
                    </div>
                  </li>
                );
              }

              if (isDeletingThis) {
                return (
                  <li
                    key={`${opt.value}_${index}`}
                    className={`px-3 py-1.5 transition-colors ${
                      isDark ? "bg-[#251417] border-l-2 border-red-500" : "bg-[#FDF0ED] border-l-2 border-red-500"
                    }`}
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div className="flex items-center justify-between gap-2 w-full">
                      <span className="text-[11px] text-red-300 font-medium truncate">
                        Delete &quot;{opt.label}&quot;?
                      </span>
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={async (e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            if (onDeleteOption) {
                              const ok = await onDeleteOption(opt.value);
                              if (ok) setDeletingValue(null);
                            }
                          }}
                          className="px-2 py-0.5 bg-red-600 hover:bg-red-500 text-white text-[10px] font-semibold uppercase tracking-wider rounded-sm transition-colors"
                        >
                          Delete
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            setDeletingValue(null);
                          }}
                          className="px-1.5 py-0.5 text-[#8C867D] hover:text-white text-xs rounded-sm transition-colors"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  </li>
                );
              }

              return (
                <li
                  key={`${opt.value}_${index}`}
                  role="option"
                  aria-selected={isSelected}
                  aria-disabled={opt.disabled}
                  onClick={() => !opt.disabled && handleSelect(opt.value)}
                  onMouseEnter={() => setHighlightedIndex(index)}
                  className={`px-3 py-2 cursor-pointer transition-colors flex items-center justify-between gap-2 text-xs group ${optionBg} ${
                    opt.disabled ? "opacity-40 cursor-not-allowed" : ""
                  }`}
                >
                  <div className="flex flex-col min-w-0 pr-2">
                    <span className="truncate block">{opt.label}</span>
                    {opt.sublabel && (
                      <span className={`text-[10px] ${isDark ? "text-[#8C867D]" : "text-[#7D776E]"}`}>
                        {opt.sublabel}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {opt.badge && (
                      <span
                        className={`text-[9px] font-mono tabular-nums uppercase px-1.5 py-0.5 rounded-sm ${
                          isDark
                            ? "bg-[#252534] text-[#C5A880] border border-[#343448]"
                            : "bg-[#EFECE5] text-[#8C6D3B] border border-[#DFD9CE]"
                        }`}
                      >
                        {opt.badge}
                      </span>
                    )}

                    {/* Edit & Delete Action Icons (Right side of option) */}
                    {!isSpecialAction && (onEditOption || onDeleteOption) && (
                      <div className="flex items-center gap-0.5 opacity-70 group-hover:opacity-100 transition-opacity">
                        {onEditOption && (opt.canEdit ?? true) && (
                          <button
                            type="button"
                            title={`Edit "${opt.label}"`}
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              setDeletingValue(null);
                              setEditingValue(opt.value);
                              setEditInputText(opt.label);
                            }}
                            className="p-1 text-[#8C867D] hover:text-[#C5A880] hover:bg-[#C5A880]/20 rounded transition-colors"
                          >
                            <svg
                              className="w-3.5 h-3.5"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" />
                              <path d="m15 5 4 4" />
                            </svg>
                          </button>
                        )}

                        {onDeleteOption && (opt.canDelete ?? true) && (
                          <button
                            type="button"
                            title={`Delete "${opt.label}"`}
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              setEditingValue(null);
                              setDeletingValue(opt.value);
                            }}
                            className="p-1 text-[#8C867D] hover:text-red-400 hover:bg-red-500/20 rounded transition-colors"
                          >
                            <svg
                              className="w-3.5 h-3.5"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <path d="M3 6h18" />
                              <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                              <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                            </svg>
                          </button>
                        )}
                      </div>
                    )}

                    {isSelected && (
                      <span
                        className={`text-xs ml-0.5 ${isDark ? "text-[#C5A880]" : "text-[#9A7B4F]"}`}
                        aria-hidden="true"
                      >
                        ✓
                      </span>
                    )}
                  </div>
                </li>
              );
            })
          )}
        </ul>
        </div>
      )}
    </div>
  );
}

export default LuxurySelect;
