"use client";

import React, { useState, useRef, useEffect, MouseEvent, TouchEvent, useCallback } from "react";
import { createPortal } from "react-dom";
import { CloseIcon, LoupeIcon } from "./LuxuryIcons";

export interface CropCoordinates {
  x: number;
  y: number;
  width: number;
  height: number;
  isPercentage: boolean;
}

interface ImageCropModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageFile: File | null;
  imageUrl?: string | null;
  onCropComplete: (cropData: CropCoordinates) => Promise<void> | void;
  isSaving?: boolean;
}

type AspectRatioPreset = "4:3" | "1:1" | "free";

export function ImageCropModal({
  isOpen,
  onClose,
  imageFile,
  imageUrl,
  onCropComplete,
  isSaving = false,
}: ImageCropModalProps) {
  const [objectUrl, setObjectUrl] = useState<string | null>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);
  const [naturalDimensions, setNaturalDimensions] = useState<{ width: number; height: number }>({
    width: 0,
    height: 0,
  });

  const [aspectPreset, setAspectPreset] = useState<AspectRatioPreset>("4:3");
  const [zoom, setZoom] = useState<number>(1);

  // Crop box in percentage of rendered image [0 to 100]
  const [crop, setCrop] = useState<{ x: number; y: number; width: number; height: number }>({
    x: 10,
    y: 10,
    width: 80,
    height: 60,
  });

  const imageRef = useRef<HTMLImageElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [isResizing, setIsResizing] = useState<string | null>(null);
  const dragStartRef = useRef<{ mouseX: number; mouseY: number; startCrop: typeof crop }>({
    mouseX: 0,
    mouseY: 0,
    startCrop: { x: 0, y: 0, width: 0, height: 0 },
  });

  // Prepare object URL from File or remote URL
  useEffect(() => {
    if (imageFile) {
      const url = URL.createObjectURL(imageFile);
      setObjectUrl(url);
      return () => URL.revokeObjectURL(url);
    } else if (imageUrl) {
      setObjectUrl(imageUrl);
    } else {
      setObjectUrl(null);
    }
  }, [imageFile, imageUrl]);

  // Adjust crop box when aspect ratio changes or on load
  const resetCropToAspect = useCallback(
    (preset: AspectRatioPreset, nw = naturalDimensions.width, nh = naturalDimensions.height) => {
      if (nw === 0 || nh === 0) return;

      let targetRatio = 4 / 3;
      if (preset === "1:1") targetRatio = 1;
      else if (preset === "free") targetRatio = nw / nh;

      const imgRatio = nw / nh;
      let newW = 80;
      let newH = 80;

      if (targetRatio > imgRatio) {
        // Target is wider than image
        newW = 90;
        newH = Math.min(90, (newW * imgRatio) / targetRatio);
      } else {
        // Target is taller than image
        newH = 80;
        newW = Math.min(90, (newH * targetRatio) / imgRatio);
      }

      const newX = (100 - newW) / 2;
      const newY = (100 - newH) / 2;

      setCrop({
        x: Math.max(0, newX),
        y: Math.max(0, newY),
        width: Math.min(100, newW),
        height: Math.min(100, newH),
      });
    },
    [naturalDimensions]
  );

  const handleImageLoad = (e: React.SyntheticEvent<HTMLImageElement>) => {
    const img = e.currentTarget;
    setNaturalDimensions({ width: img.naturalWidth, height: img.naturalHeight });
    resetCropToAspect(aspectPreset, img.naturalWidth, img.naturalHeight);
  };

  const handlePresetChange = (preset: AspectRatioPreset) => {
    setAspectPreset(preset);
    resetCropToAspect(preset);
  };

  // Start Dragging
  const handleStartDrag = (e: MouseEvent | TouchEvent) => {
    const clientX = "touches" in e ? e.touches[0].clientX : e.clientX;
    const clientY = "touches" in e ? e.touches[0].clientY : e.clientY;
    setIsDragging(true);
    dragStartRef.current = {
      mouseX: clientX,
      mouseY: clientY,
      startCrop: { ...crop },
    };
  };

  // Start Resizing Handle
  const handleStartResize = (handle: string, e: MouseEvent | TouchEvent) => {
    e.stopPropagation();
    const clientX = "touches" in e ? e.touches[0].clientX : e.clientX;
    const clientY = "touches" in e ? e.touches[0].clientY : e.clientY;
    setIsResizing(handle);
    dragStartRef.current = {
      mouseX: clientX,
      mouseY: clientY,
      startCrop: { ...crop },
    };
  };

  // Global Pointer Move
  useEffect(() => {
    const handlePointerMove = (e: globalThis.MouseEvent | globalThis.TouchEvent) => {
      if (!isDragging && !isResizing) return;
      if (!imageRef.current) return;

      const clientX = "touches" in e ? e.touches[0].clientX : e.clientX;
      const clientY = "touches" in e ? e.touches[0].clientY : e.clientY;

      const rect = imageRef.current.getBoundingClientRect();
      const deltaXPercent = ((clientX - dragStartRef.current.mouseX) / rect.width) * 100;
      const deltaYPercent = ((clientY - dragStartRef.current.mouseY) / rect.height) * 100;

      const { startCrop } = dragStartRef.current;

      if (isDragging) {
        let newX = startCrop.x + deltaXPercent;
        let newY = startCrop.y + deltaYPercent;

        newX = Math.max(0, Math.min(100 - startCrop.width, newX));
        newY = Math.max(0, Math.min(100 - startCrop.height, newY));

        setCrop((prev) => ({ ...prev, x: newX, y: newY }));
      } else if (isResizing) {
        let newWidth = startCrop.width;
        let newHeight = startCrop.height;
        let newX = startCrop.x;
        let newY = startCrop.y;

        const ratio =
          aspectPreset === "4:3" ? 4 / 3 : aspectPreset === "1:1" ? 1 : null;
        const imgAspect = naturalDimensions.width / naturalDimensions.height;

        if (isResizing.includes("e")) {
          newWidth = Math.max(15, Math.min(100 - startCrop.x, startCrop.width + deltaXPercent));
          if (ratio) {
            newHeight = Math.min(100 - startCrop.y, (newWidth * imgAspect) / ratio);
          }
        }
        if (isResizing.includes("s")) {
          newHeight = Math.max(15, Math.min(100 - startCrop.y, startCrop.height + deltaYPercent));
          if (ratio) {
            newWidth = Math.min(100 - startCrop.x, (newHeight * ratio) / imgAspect);
          }
        }
        if (isResizing.includes("w")) {
          const proposedW = startCrop.width - deltaXPercent;
          if (proposedW >= 15 && startCrop.x + deltaXPercent >= 0) {
            newWidth = proposedW;
            newX = startCrop.x + deltaXPercent;
            if (ratio) {
              newHeight = Math.min(100 - startCrop.y, (newWidth * imgAspect) / ratio);
            }
          }
        }
        if (isResizing.includes("n")) {
          const proposedH = startCrop.height - deltaYPercent;
          if (proposedH >= 15 && startCrop.y + deltaYPercent >= 0) {
            newHeight = proposedH;
            newY = startCrop.y + deltaYPercent;
            if (ratio) {
              newWidth = Math.min(100 - startCrop.x, (newHeight * ratio) / imgAspect);
            }
          }
        }

        setCrop({
          x: Math.max(0, Math.min(100 - newWidth, newX)),
          y: Math.max(0, Math.min(100 - newHeight, newY)),
          width: Math.min(100, newWidth),
          height: Math.min(100, newHeight),
        });
      }
    };

    const handlePointerUp = () => {
      setIsDragging(false);
      setIsResizing(null);
    };

    window.addEventListener("mousemove", handlePointerMove);
    window.addEventListener("mouseup", handlePointerUp);
    window.addEventListener("touchmove", handlePointerMove);
    window.addEventListener("touchend", handlePointerUp);

    return () => {
      window.removeEventListener("mousemove", handlePointerMove);
      window.removeEventListener("mouseup", handlePointerUp);
      window.removeEventListener("touchmove", handlePointerMove);
      window.removeEventListener("touchend", handlePointerUp);
    };
  }, [isDragging, isResizing, aspectPreset, naturalDimensions]);

  const handleConfirmCrop = async () => {
    if (naturalDimensions.width === 0 || naturalDimensions.height === 0) return;

    // Convert percentage crop box to true source image pixel coordinates
    const pixelX = Math.round((crop.x / 100) * naturalDimensions.width);
    const pixelY = Math.round((crop.y / 100) * naturalDimensions.height);
    const pixelWidth = Math.round((crop.width / 100) * naturalDimensions.width);
    const pixelHeight = Math.round((crop.height / 100) * naturalDimensions.height);

    await onCropComplete({
      x: pixelX,
      y: pixelY,
      width: pixelWidth,
      height: pixelHeight,
      isPercentage: false,
    });
  };

  if (!isOpen || !objectUrl || !mounted) return null;

  // Real-time calculated cropped dimensions
  const estWidth = Math.round((crop.width / 100) * naturalDimensions.width);
  const estHeight = Math.round((crop.height / 100) * naturalDimensions.height);

  return createPortal(
    <div
      className="fixed inset-0 z-[100000] flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-luxury-backdrop"
    >
      <div
        className="relative w-full max-w-4xl bg-[#141419] border border-[#2E2E3C] shadow-2xl rounded-sm overflow-hidden flex flex-col max-h-[95vh] animate-luxury-modal my-auto"
      >
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-[#242430] flex items-center justify-between bg-[#1A1A22]">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-full bg-[#C5A880]/15 border border-[#C5A880]/40 flex items-center justify-center text-[#C5A880]">
              <LoupeIcon className="w-3.5 h-3.5" />
            </div>
            <div>
              <h3 className="font-serif text-base text-white font-medium">
                Gemological Specimen Cropping Studio
              </h3>
              <p className="text-[11px] font-sans text-[#8C867D]">
                Crop and frame specimen photography to fill the catalog container with 100% optical precision.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isSaving}
            className="p-1.5 text-[#8C867D] hover:text-white hover:bg-white/10 rounded-sm transition-colors disabled:opacity-50"
          >
            <CloseIcon className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar & Aspect Ratio Presets */}
        <div className="px-6 py-3 border-b border-[#242430] bg-[#17171F] flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-mono tracking-wider text-[#A29F96]">
              Aspect Ratio:
            </span>
            <div className="flex bg-[#121217] border border-[#2A2A36] p-0.5 rounded-sm">
              <button
                type="button"
                onClick={() => handlePresetChange("4:3")}
                className={`px-3 py-1 text-[11px] uppercase tracking-wider font-sans rounded-sm transition-colors ${
                  aspectPreset === "4:3"
                    ? "bg-[#C5A880] text-[#0D0D11] font-semibold"
                    : "text-[#8C867D] hover:text-white"
                }`}
              >
                4:3 Catalog Stage (Recommended)
              </button>
              <button
                type="button"
                onClick={() => handlePresetChange("1:1")}
                className={`px-3 py-1 text-[11px] uppercase tracking-wider font-sans rounded-sm transition-colors ${
                  aspectPreset === "1:1"
                    ? "bg-[#C5A880] text-[#0D0D11] font-semibold"
                    : "text-[#8C867D] hover:text-white"
                }`}
              >
                1:1 Square
              </button>
              <button
                type="button"
                onClick={() => handlePresetChange("free")}
                className={`px-3 py-1 text-[11px] uppercase tracking-wider font-sans rounded-sm transition-colors ${
                  aspectPreset === "free"
                    ? "bg-[#C5A880] text-[#0D0D11] font-semibold"
                    : "text-[#8C867D] hover:text-white"
                }`}
              >
                Freeform
              </button>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-mono tracking-wider text-[#A29F96]">
                Zoom:
              </span>
              <input
                type="range"
                min={1}
                max={3}
                step={0.05}
                value={zoom}
                onChange={(e) => setZoom(parseFloat(e.target.value))}
                className="w-24 accent-[#C5A880] cursor-pointer"
              />
              <span className="text-[11px] font-mono text-[#E0CFA9] min-w-9">
                {zoom.toFixed(1)}x
              </span>
            </div>

            <button
              type="button"
              onClick={() => {
                setZoom(1);
                resetCropToAspect(aspectPreset);
              }}
              className="px-2.5 py-1 text-[10px] uppercase font-mono text-[#8C867D] hover:text-white border border-[#2A2A36] rounded-sm hover:border-[#C5A880] transition-colors"
            >
              Reset Fit
            </button>
          </div>
        </div>

        {/* Interactive Cropping Viewport */}
        <div
          ref={stageRef}
          className="relative flex-1 min-h-[380px] max-h-[58vh] bg-[#0A0A0D] overflow-hidden flex items-center justify-center p-4 select-none"
        >
          <div
            className="relative inline-block overflow-hidden transition-transform duration-100"
            style={{ transform: `scale(${zoom})` }}
          >
            {/* Base Image */}
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              ref={imageRef}
              src={objectUrl}
              alt="Crop Preview Specimen"
              onLoad={handleImageLoad}
              className="max-h-[50vh] max-w-full object-contain pointer-events-none block"
            />

            {/* Dark Mask Over Unselected Area */}
            <div
              className="absolute inset-0 pointer-events-none"
              style={{
                background: `linear-gradient(to right, rgba(0,0,0,0.65) ${crop.x}%, transparent ${crop.x}%, transparent ${
                  crop.x + crop.width
                }%, rgba(0,0,0,0.65) ${crop.x + crop.width}%)`,
              }}
            />

            {/* Interactive Resizable Crop Window */}
            <div
              onMouseDown={handleStartDrag}
              onTouchStart={handleStartDrag}
              style={{
                left: `${crop.x}%`,
                top: `${crop.y}%`,
                width: `${crop.width}%`,
                height: `${crop.height}%`,
              }}
              className="absolute cursor-move border-2 border-[#C5A880] shadow-[0_0_0_9999px_rgba(0,0,0,0.65)] z-20 group"
            >
              {/* Center Alignment Facet Reticle (Rule of Thirds Grid) */}
              <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 pointer-events-none opacity-40">
                <div className="border-r border-b border-[#C5A880]/50" />
                <div className="border-r border-b border-[#C5A880]/50" />
                <div className="border-b border-[#C5A880]/50" />
                <div className="border-r border-b border-[#C5A880]/50" />
                <div className="border-r border-b border-[#C5A880]/50 flex items-center justify-center">
                  <div className="w-3 h-3 rounded-full border border-[#C5A880]/80" />
                </div>
                <div className="border-b border-[#C5A880]/50" />
                <div className="border-r border-[#C5A880]/50" />
                <div className="border-r border-[#C5A880]/50" />
                <div />
              </div>

              {/* Real-time Dimensions Badge */}
              <div className="absolute top-2 left-2 pointer-events-none bg-black/85 backdrop-blur-sm px-2 py-0.5 border border-[#C5A880]/40 rounded-sm text-[9px] font-mono text-[#E0CFA9]">
                {estWidth} × {estHeight} px
              </div>

              {/* Resize Corner Handles */}
              <div
                onMouseDown={(e) => handleStartResize("nw", e)}
                onTouchStart={(e) => handleStartResize("nw", e)}
                className="absolute -top-1.5 -left-1.5 w-3.5 h-3.5 bg-[#C5A880] border border-black cursor-nwse-resize z-30"
              />
              <div
                onMouseDown={(e) => handleStartResize("ne", e)}
                onTouchStart={(e) => handleStartResize("ne", e)}
                className="absolute -top-1.5 -right-1.5 w-3.5 h-3.5 bg-[#C5A880] border border-black cursor-nesw-resize z-30"
              />
              <div
                onMouseDown={(e) => handleStartResize("sw", e)}
                onTouchStart={(e) => handleStartResize("sw", e)}
                className="absolute -bottom-1.5 -left-1.5 w-3.5 h-3.5 bg-[#C5A880] border border-black cursor-nesw-resize z-30"
              />
              <div
                onMouseDown={(e) => handleStartResize("se", e)}
                onTouchStart={(e) => handleStartResize("se", e)}
                className="absolute -bottom-1.5 -right-1.5 w-3.5 h-3.5 bg-[#C5A880] border border-black cursor-nwse-resize z-30"
              />
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 border-t border-[#242430] bg-[#17171F] flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-[11px] text-[#A29F96] font-sans">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>Sharp High-Fidelity WebP Optimization (92% Gemological Quality)</span>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              type="button"
              onClick={onClose}
              disabled={isSaving}
              className="flex-1 sm:flex-none px-4 py-2 border border-[#2A2A36] text-[#A29F96] hover:text-white hover:border-[#3E3E4E] text-xs uppercase font-sans tracking-wider rounded-sm transition-colors disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleConfirmCrop}
              disabled={isSaving || naturalDimensions.width === 0}
              className="flex-1 sm:flex-none px-6 py-2 bg-[#C5A880] hover:bg-[#D4BC96] text-[#0D0D11] text-xs font-medium uppercase font-sans tracking-wider rounded-sm transition-colors flex items-center justify-center gap-2 shadow-md disabled:opacity-50"
            >
              {isSaving ? (
                <>
                  <span className="inline-block animate-spin text-sm">↻</span>
                  <span>Cropping with Sharp...</span>
                </>
              ) : (
                <span>Crop & Save Specimen Image</span>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}
