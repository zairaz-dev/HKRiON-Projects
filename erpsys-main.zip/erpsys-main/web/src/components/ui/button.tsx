import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"

/**
 * ==========================================================================
 * Button Component Variants Configuration (using class-variance-authority)
 * ==========================================================================
 * 
 * This defines the Tailwind CSS classes applied to the Button component based
 * on its props: `variant` and `size`.
 * 
 * Note: We use `rounded-sm` as the default border radius to bind buttons to 
 * the custom `--radius-sm` (4px) CSS variable defined in `globals.css`.
 */
const buttonVariants = cva(
  "inline-flex items-center justify-center whitespace-nowrap rounded-sm text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      /**
       * Visual styles of the button
       */
      variant: {
        default:
          "bg-primary text-primary-foreground shadow hover:bg-primary/90",
        destructive:
          "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
        outline:
          "border border-input bg-transparent shadow-sm hover:bg-accent hover:text-accent-foreground",
        secondary:
          "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
      },
      /**
       * Sizes of the button
       */
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 rounded-sm px-3 text-xs",
        lg: "h-10 rounded-sm px-8",
        icon: "h-9 w-9",
      },
    },
    /**
     * Default properties when no props are provided
     */
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

/**
 * ==========================================================================
 * ButtonProps Interface
 * ==========================================================================
 * 
 * Extends standard HTML button attributes and merges them with the CVA variants.
 * Includes support for the Radix UI `Slot` component via the `asChild` prop.
 */
export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  /**
   * If true, the button will render as its child component (e.g. Next.js Link),
   * inheriting all the button styling and behaviors.
   */
  asChild?: boolean
}

/**
 * ==========================================================================
 * Reusable Button Component
 * ==========================================================================
 * 
 * A highly customizable, accessible button component built with Radix UI Slot
 * and Tailwind CSS. Supports various visual variants and sizing options.
 * 
 * @see {@link buttonVariants} for all available styling variants.
 */
const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    // If asChild is true, render the Radix Slot, otherwise render a standard HTML button
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }
