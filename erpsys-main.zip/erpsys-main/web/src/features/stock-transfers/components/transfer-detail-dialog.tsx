import React from "react";
import {
  X,
  Printer,
  ArrowRightLeft,
  Building2,
  Calendar,
  User as UserIcon,
  FileText,
  DollarSign,
  Truck,
  CheckCircle,
  Clock,
  Loader2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useUpdateTransferStatusMutation } from "../hooks/use-stock-transfers";
import { useCurrency } from "@/hooks/use-currency";

interface TransferDetailDialogProps {
  isOpen: boolean;
  onClose: () => void;
  transfer: any;
  businessId: string;
  onSuccess: (msg: string) => void;
  onError: (msg: string) => void;
}

export function TransferDetailDialog({
  isOpen,
  onClose,
  transfer,
  businessId,
  onSuccess,
  onError,
}: TransferDetailDialogProps) {
  const { symbol } = useCurrency(businessId || transfer?.businessId);
  const updateStatusMutation = useUpdateTransferStatusMutation();

  if (!isOpen || !transfer) return null;

  const handleCompleteTransfer = async () => {
    try {
      await updateStatusMutation.mutateAsync({
        id: transfer.id,
        businessId,
        status: "COMPLETED",
      });
      onSuccess(`Stock Transfer ${transfer.transferNumber} marked as COMPLETED! Stock received at destination.`);
      onClose();
    } catch (err: any) {
      onError(err.message || "Failed to update transfer status.");
    }
  };

  const handlePrint = () => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) return;

    const dateStr = new Date(transfer.transferDate).toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "long",
      year: "numeric",
    });

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Stock Transfer Voucher - ${transfer.transferNumber}</title>
          <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 30px; color: #111; }
            .header { display: flex; justify-content: space-between; align-items: flex-start; border-b: 2px solid #333; pb: 15px; margin-bottom: 20px; }
            .title { font-size: 24px; font-weight: bold; color: #111; margin: 0; }
            .sub-title { font-size: 12px; color: #666; margin-top: 4px; }
            .grid { display: flex; justify-content: space-between; margin-bottom: 20px; font-size: 13px; }
            .box { background: #f9fafb; padding: 12px; border-radius: 6px; border: 1px solid #e5e7eb; width: 48%; }
            table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 12px; }
            th { background: #f3f4f6; text-align: left; padding: 8px; border-bottom: 2px solid #d1d5db; font-weight: 600; }
            td { padding: 8px; border-bottom: 1px solid #e5e7eb; }
            .text-right { text-align: right; }
            .text-center { text-align: center; }
            .total-row { font-weight: bold; font-size: 14px; background: #f3f4f6; }
            .footer { margin-top: 50px; display: flex; justify-content: space-between; font-size: 12px; color: #555; }
            .signature { border-top: 1px dashed #999; width: 180px; text-align: center; padding-top: 5px; }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <h1 class="title">STOCK TRANSFER WAYBILL</h1>
              <p class="sub-title">Inter-Branch Delivery Voucher</p>
            </div>
            <div style="text-align: right;">
              <p style="font-weight: bold; margin:0;">Transfer #: ${transfer.transferNumber}</p>
              <p style="margin:4px 0 0 0; font-size:12px; color:#555;">Date: ${dateStr}</p>
              <p style="margin:2px 0 0 0; font-size:12px; color:#555;">Status: ${transfer.status}</p>
            </div>
          </div>

          <div class="grid">
            <div class="box">
              <strong style="display:block; margin-bottom:4px; text-transform:uppercase; font-size:11px; color:#666;">Source (From Branch)</strong>
              <p style="margin:0; font-weight:bold; font-size:14px; color:#be123c;">${transfer.fromBranch?.name || "N/A"}</p>
            </div>

            <div class="box">
              <strong style="display:block; margin-bottom:4px; text-transform:uppercase; font-size:11px; color:#666;">Destination (To Branch)</strong>
              <p style="margin:0; font-weight:bold; font-size:14px; color:#047857;">${transfer.toBranch?.name || "N/A"}</p>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Item / Description</th>
                <th class="text-center">Transferred Qty</th>
                <th class="text-right">Unit Cost</th>
                <th class="text-right">Total Subtotal</th>
              </tr>
            </thead>
            <tbody>
              ${transfer.transferLines?.map((line: any, idx: number) => `
                <tr>
                  <td>${idx + 1}</td>
                  <td>
                    <strong>${line.variant?.product?.name || line.variant?.name || "Item"}</strong>
                    <br/><span style="font-size:10px; color:#666;">SKU: ${line.variant?.sku || "N/A"}</span>
                  </td>
                  <td class="text-center">${line.quantity}</td>
                  <td class="text-right">${symbol}${line.unitPrice.toFixed(2)}</td>
                  <td class="text-right">${symbol}${line.subtotal.toFixed(2)}</td>
                </tr>
              `).join("")}
              ${transfer.shippingCharges > 0 ? `
                <tr>
                  <td colspan="4" class="text-right">Shipping / Freight Charges:</td>
                  <td class="text-right">${symbol}${transfer.shippingCharges.toFixed(2)}</td>
                </tr>
              ` : ""}
              <tr class="total-row">
                <td colspan="4" class="text-right" style="padding: 10px;">Total Transfer Value:</td>
                <td class="text-right" style="padding: 10px;">${symbol}${(transfer.totalAmount + (transfer.shippingCharges || 0)).toFixed(2)}</td>
              </tr>
            </tbody>
          </table>

          ${transfer.notes ? `
            <div style="margin-top: 15px; font-size: 12px; background: #f9fafb; padding: 10px; border-radius: 4px;">
              <strong>Transfer Remarks:</strong> ${transfer.notes}
            </div>
          ` : ""}

          <div class="footer">
            <div class="signature">Dispatched By</div>
            <div class="signature">Received By</div>
          </div>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 250);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-card border border-border rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border bg-muted/30">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-primary/10 text-primary">
              <ArrowRightLeft className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-foreground">
                Stock Transfer #{transfer.transferNumber}
              </h2>
              <span className="text-xs text-muted-foreground font-mono">
                Status: {transfer.status}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrint}
              className="gap-1.5 text-xs h-8"
            >
              <Printer className="h-3.5 w-3.5" /> Print Transfer Note
            </Button>

            <button
              onClick={onClose}
              className="text-muted-foreground hover:text-foreground p-1 rounded-md transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-5">
          
          {/* Status & Summary Header Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-muted/40 p-3 rounded-lg border border-border/50">
              <span className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                <Calendar className="h-3 w-3 text-primary" /> Transfer Date
              </span>
              <p className="text-xs font-semibold mt-1 text-foreground">
                {new Date(transfer.createdAt).toLocaleDateString("en-US", {
                  year: "numeric",
                  month: "short",
                  day: "numeric",
                })}
              </p>
            </div>

            <div className="bg-muted/40 p-3 rounded-lg border border-border/50">
              <span className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                <Truck className="h-3 w-3 text-primary" /> Freight Charges
              </span>
              <p className="text-sm font-semibold mt-1 font-mono">
                {symbol}{transfer.shippingCharges?.toFixed(2) || "0.00"}
              </p>
            </div>

            <div className="bg-muted/40 p-3 rounded-lg border border-border/50">
              <span className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                <DollarSign className="h-3 w-3 text-primary" /> Total Transfer Value
              </span>
              <p className="text-lg font-extrabold text-primary mt-0.5 font-mono">
                {symbol}{(transfer.totalAmount + (transfer.shippingCharges || 0))?.toFixed(2)}
              </p>
            </div>
          </div>

          {/* Source & Destination Branches */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-muted/20 p-3.5 rounded-lg border border-border/40 text-xs">
            <div className="space-y-1 border-r sm:border-r border-border/40 pr-2">
              <span className="text-[10px] font-bold text-rose-500 uppercase flex items-center gap-1">
                <Building2 className="h-3 w-3" /> From Branch (Source)
              </span>
              <p className="font-bold text-foreground text-sm">{transfer.fromBranch?.name}</p>
            </div>

            <div className="space-y-1">
              <span className="text-[10px] font-bold text-emerald-500 uppercase flex items-center gap-1">
                <Building2 className="h-3 w-3" /> To Branch (Destination)
              </span>
              <p className="font-bold text-foreground text-sm">{transfer.toBranch?.name}</p>
            </div>
          </div>

          {/* Table of Line items */}
          <div className="space-y-2">
            <span className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider block">
              Transferred Product Breakdown
            </span>
            <div className="border border-border/60 rounded-lg overflow-hidden">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="bg-muted/40 border-b border-border/60">
                    <th className="p-3 font-semibold text-muted-foreground">Product</th>
                    <th className="p-3 font-semibold text-muted-foreground text-center">Transferred Qty</th>
                    <th className="p-3 font-semibold text-muted-foreground text-right">Unit Cost ({symbol})</th>
                    <th className="p-3 font-semibold text-muted-foreground text-right pr-4">Subtotal ({symbol})</th>
                  </tr>
                </thead>
                <tbody>
                  {transfer.transferLines?.map((line: any) => (
                    <tr key={line.id} className="border-b border-border/40 hover:bg-muted/15 transition-colors">
                      <td className="p-3">
                        <span className="font-semibold text-foreground block">
                          {line.variant?.product?.name || line.variant?.name || "Product Item"}
                        </span>
                        <span className="text-[10px] font-mono text-muted-foreground block">
                          SKU: {line.variant?.sku}
                        </span>
                      </td>
                      <td className="p-3 text-center font-bold">
                        {line.quantity}
                      </td>
                      <td className="p-3 text-right font-mono">
                        {symbol}{line.unitPrice.toFixed(2)}
                      </td>
                      <td className="p-3 text-right font-semibold font-mono pr-4 text-foreground">
                        {symbol}{line.subtotal.toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Notes */}
          {transfer.notes && (
            <div className="space-y-1 bg-muted/30 p-3 rounded-lg border border-border/40">
              <span className="text-[10px] font-bold text-muted-foreground uppercase">
                Transport Notes / Vehicle Details
              </span>
              <p className="text-xs text-foreground italic">{transfer.notes}</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-border pt-3 shrink-0 flex items-center justify-between">
          <div>
            {transfer.status === "PENDING" && (
              <Button
                variant="default"
                size="sm"
                onClick={handleCompleteTransfer}
                disabled={updateStatusMutation.isPending}
                className="h-8 text-xs gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                {updateStatusMutation.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle className="h-3.5 w-3.5" />}
                Mark Received (Complete Transfer)
              </Button>
            )}
          </div>

          <Button variant="outline" size="sm" onClick={onClose} className="h-8 text-xs">
            Close
          </Button>
        </div>
      </div>
    </div>
  );
}
