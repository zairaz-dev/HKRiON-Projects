"use client";

import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from "react";
import {
  DEFAULT_CMS_BLOCKS,
  type CMSFaqItem,
  type CMSState,
  type CMSData,
} from "./constants";

export { DEFAULT_CMS_BLOCKS, type CMSFaqItem, type CMSState, type CMSData };

export interface CMSContextValue extends CMSState {
  getBlock: (sectionOrKey: string, keyOrFallback?: string, fallback?: string) => string;
  refresh: () => Promise<CMSState>;
  saveBlock: (section: string, key: string, value: string) => Promise<boolean>;
  saveBlocks: (items: { section: string; key: string; value: string }[]) => Promise<boolean>;
  createFaq: (faq: { question: string; answer: string; category?: string; orderIndex?: number }) => Promise<boolean>;
  updateFaq: (faq: { id: string; question: string; answer: string; category?: string; orderIndex?: number }) => Promise<boolean>;
  deleteFaq: (id: string) => Promise<boolean>;
}

const CMSContext = createContext<CMSContextValue | null>(null);

let globalActivePromise: Promise<CMSState> | null = null;
export async function fetchCMSGlobal(): Promise<CMSState> {
  if (globalActivePromise) return globalActivePromise;

  globalActivePromise = (async () => {
    try {
      const res = await fetch("/api/cms", { cache: "no-store" });
      if (!res.ok) {
        return {
          blocks: DEFAULT_CMS_BLOCKS,
          faqs: [],
          isLoading: false,
          error: "Failed to fetch CMS content",
        };
      }
      const json = await res.json();
      if (json.success) {
        return {
          blocks: { ...DEFAULT_CMS_BLOCKS, ...json.blocks },
          faqs: json.faqs || [],
          isLoading: false,
          error: null,
        };
      }
      return {
        blocks: DEFAULT_CMS_BLOCKS,
        faqs: [],
        isLoading: false,
        error: json.warning || "Failed to parse CMS response",
      };
    } catch (err) {
      console.warn("fetchCMSGlobal error:", (err as Error).message);
      return {
        blocks: DEFAULT_CMS_BLOCKS,
        faqs: [],
        isLoading: false,
        error: (err as Error).message,
      };
    } finally {
      globalActivePromise = null;
    }
  })();

  return globalActivePromise;
}

export function CMSProvider({
  children,
  initialData,
}: {
  children: React.ReactNode;
  initialData?: CMSData;
}) {
  const [data, setData] = useState<CMSState>(() => {
    if (initialData) {
      return {
        blocks: { ...DEFAULT_CMS_BLOCKS, ...initialData.blocks },
        faqs: initialData.faqs || [],
        isLoading: false,
        error: null,
      };
    }
    return {
      blocks: DEFAULT_CMS_BLOCKS,
      faqs: [],
      isLoading: true,
      error: null,
    };
  });

  const refresh = useCallback(async (): Promise<CMSState> => {
    const fresh = await fetchCMSGlobal();
    if (!fresh.error) {
      setData(fresh);
    }
    return fresh;
  }, []);

  useEffect(() => {
    if (!initialData) {
      refresh();
    }

    const handleSync = () => {
      refresh();
    };

    window.addEventListener("cms-updated", handleSync);
    return () => {
      window.removeEventListener("cms-updated", handleSync);
    };
  }, [initialData, refresh]);

  const getBlock = useCallback(
    (sectionOrKey: string, keyOrFallback?: string, fallback?: string): string => {
      if (fallback !== undefined) {
        const fullKey = `${sectionOrKey}.${keyOrFallback}`;
        return data.blocks[fullKey] ?? fallback ?? DEFAULT_CMS_BLOCKS[fullKey] ?? "";
      }
      return data.blocks[sectionOrKey] ?? keyOrFallback ?? DEFAULT_CMS_BLOCKS[sectionOrKey] ?? "";
    },
    [data.blocks]
  );

  const saveBlock = useCallback(
    async (section: string, key: string, value: string): Promise<boolean> => {
      try {
        const res = await fetch("/api/cms", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ type: "block", section, key, value }),
        });
        if (res.ok) {
          setData((prev) => ({
            ...prev,
            blocks: {
              ...prev.blocks,
              [`${section}.${key}`]: value,
              [key]: value,
            },
          }));
          if (typeof window !== "undefined") {
            window.dispatchEvent(new CustomEvent("cms-updated"));
          }
          return true;
        }
      } catch (err) {
        console.error("saveBlock error:", err);
      }
      return false;
    },
    []
  );

  const saveBlocks = useCallback(
    async (items: { section: string; key: string; value: string }[]): Promise<boolean> => {
      try {
        const res = await fetch("/api/cms", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ type: "blocks", items }),
        });
        if (res.ok) {
          setData((prev) => {
            const updated = { ...prev.blocks };
            for (const item of items) {
              updated[`${item.section}.${item.key}`] = item.value;
              updated[item.key] = item.value;
            }
            return { ...prev, blocks: updated };
          });
          if (typeof window !== "undefined") {
            window.dispatchEvent(new CustomEvent("cms-updated"));
          }
          return true;
        }
      } catch (err) {
        console.error("saveBlocks error:", err);
      }
      return false;
    },
    []
  );

  const createFaq = useCallback(
    async (faq: { question: string; answer: string; category?: string; orderIndex?: number }): Promise<boolean> => {
      try {
        const res = await fetch("/api/cms", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ type: "faq", ...faq }),
        });
        const json = await res.json();
        if (res.ok && json.faq) {
          setData((prev) => ({ ...prev, faqs: [...prev.faqs, json.faq] }));
          if (typeof window !== "undefined") {
            window.dispatchEvent(new CustomEvent("cms-updated"));
          }
          return true;
        }
      } catch (err) {
        console.error("createFaq error:", err);
      }
      return false;
    },
    []
  );

  const updateFaq = useCallback(
    async (faq: { id: string; question: string; answer: string; category?: string; orderIndex?: number }): Promise<boolean> => {
      try {
        const res = await fetch("/api/cms", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ type: "faq", ...faq }),
        });
        if (res.ok) {
          setData((prev) => ({
            ...prev,
            faqs: prev.faqs.map((f) => (f.id === faq.id ? { ...f, ...faq, order_index: faq.orderIndex ?? f.order_index } : f)),
          }));
          if (typeof window !== "undefined") {
            window.dispatchEvent(new CustomEvent("cms-updated"));
          }
          return true;
        }
      } catch (err) {
        console.error("updateFaq error:", err);
      }
      return false;
    },
    []
  );

  const deleteFaq = useCallback(
    async (id: string): Promise<boolean> => {
      try {
        const res = await fetch(`/api/cms?type=faq&id=${id}`, { method: "DELETE" });
        if (res.ok) {
          setData((prev) => ({
            ...prev,
            faqs: prev.faqs.filter((f) => f.id !== id),
          }));
          if (typeof window !== "undefined") {
            window.dispatchEvent(new CustomEvent("cms-updated"));
          }
          return true;
        }
      } catch (err) {
        console.error("deleteFaq error:", err);
      }
      return false;
    },
    []
  );

  const contextValue = useMemo<CMSContextValue>(
    () => ({
      ...data,
      getBlock,
      refresh,
      saveBlock,
      saveBlocks,
      createFaq,
      updateFaq,
      deleteFaq,
    }),
    [data, getBlock, refresh, saveBlock, saveBlocks, createFaq, updateFaq, deleteFaq]
  );

  return <CMSContext.Provider value={contextValue}>{children}</CMSContext.Provider>;
}

export function useCMS(): CMSContextValue {
  const context = useContext(CMSContext);
  if (context) {
    return context;
  }

  // Fallback defaults for isolated testing outside CMSProvider
  return {
    blocks: DEFAULT_CMS_BLOCKS,
    faqs: [],
    isLoading: false,
    error: null,
    getBlock: (sectionOrKey: string, keyOrFallback?: string, fallback?: string): string => {
      if (fallback !== undefined) {
        const fullKey = `${sectionOrKey}.${keyOrFallback}`;
        return fallback ?? DEFAULT_CMS_BLOCKS[fullKey] ?? "";
      }
      return keyOrFallback ?? DEFAULT_CMS_BLOCKS[sectionOrKey] ?? "";
    },
    refresh: async () => ({
      blocks: DEFAULT_CMS_BLOCKS,
      faqs: [],
      isLoading: false,
      error: null,
    }),
    saveBlock: async () => false,
    saveBlocks: async () => false,
    createFaq: async () => false,
    updateFaq: async () => false,
    deleteFaq: async () => false,
  };
}
