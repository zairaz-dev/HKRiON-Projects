"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import {
  PieChart,
  Layers,
  ShoppingBag,
  Users,
  Building2,
  Calendar,
  Loader2,
  AlertCircle,
  BarChart3
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { Select } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";
import { useBranchesQuery } from "@/features/suppliers/hooks/use-suppliers";
import {
  ProfitLossView,
  StockValuationView,
  SalesPurchasesView,
  ContactBalancesView
} from "@/features/reports";

type ReportTab = "profit-loss" | "stock-valuation" | "sales-purchases" | "contact-balances";

function ReportsPageContent() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Active Tab
  const activeTab = (searchParams.get("tab") as ReportTab) || "profit-loss";

  // Shared Filters
  const selectedBranchFilter = searchParams.get("branchId") || "all";
  const startDate = searchParams.get("startDate") || "";
  const endDate = searchParams.get("endDate") || "";
  const searchQuery = searchParams.get("search") || "";

  const handleTabChange = (tab: ReportTab) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("tab", tab);
    router.push(`${pathname}?${params.toString()}`);
  };

  const setBranchFilter = (val: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (val === "all") params.delete("branchId");
    else params.set("branchId", val);
    router.push(`${pathname}?${params.toString()}`);
  };

  const setDateFilter = (start: string, end: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (start) params.set("startDate", start);
    else params.delete("startDate");

    if (end) params.set("endDate", end);
    else params.delete("endDate");

    router.push(`${pathname}?${params.toString()}`);
  };

  const setSearchQuery = (val: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (val) params.set("search", val);
    else params.delete("search");
    router.push(`${pathname}?${params.toString()}`);
  };

  // Quick Date Range helper
  const handleQuickDatePreset = (preset: "today" | "this_month" | "this_year" | "all") => {
    const today = new Date();
    if (preset === "today") {
      const dateStr = today.toISOString().split("T")[0];
      setDateFilter(dateStr, dateStr);
    } else if (preset === "this_month") {
      const firstDay = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split("T")[0];
      const lastDay = today.toISOString().split("T")[0];
      setDateFilter(firstDay, lastDay);
    } else if (preset === "this_year") {
      const firstDay = new Date(today.getFullYear(), 0, 1).toISOString().split("T")[0];
      const lastDay = today.toISOString().split("T")[0];
      setDateFilter(firstDay, lastDay);
    } else {
      setDateFilter("", "");
    }
  };

  // Auth check
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  const businessId = currentUser?.businessId || "";
  const { data: branchesList = [] } = useBranchesQuery(businessId, currentUser?.id);

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3 p-6 max-w-sm border border-border/40 rounded-xl bg-card/60 backdrop-blur-sm">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <h2 className="text-lg font-bold">Unauthorized Access</h2>
          <p className="text-sm text-muted-foreground">
            You need to be logged in to view reports. Redirecting to login...
          </p>
          <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/reports" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Reports & Financial Analytics" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          
          {/* Header & Global Filters */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-border pb-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <BarChart3 className="h-7 w-7 text-primary" /> Financial & Business Reports
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Real-time profit & loss, stock valuation, sales/purchases analytics, and contact balances.
              </p>
            </div>

            {/* Global Filters Control Bar */}
            <div className="flex flex-wrap items-center gap-2.5 bg-card p-2 rounded-sm border border-border/60 shadow-sm text-xs">
              
              {/* Branch Filter */}
              <div className="flex items-center gap-1.5 min-w-[150px]">
                <Building2 className="h-3.5 w-3.5 text-primary shrink-0" />
                <Select
                  value={selectedBranchFilter}
                  onValueChange={setBranchFilter}
                  className="h-8 text-xs"
                >
                  <option value="all">All Branches</option>
                  {branchesList.map((b: any) => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </Select>
              </div>

              {/* Date Filters (applicable to P&L, Sales/Purchases) */}
              {(activeTab === "profit-loss" || activeTab === "sales-purchases") && (
                <>
                  <div className="h-4 w-px bg-border hidden sm:block" />
                  <div className="flex items-center gap-1.5">
                    <Calendar className="h-3.5 w-3.5 text-primary shrink-0" />
                    <Input
                      type="date"
                      value={startDate}
                      onChange={(e) => setDateFilter(e.target.value, endDate)}
                      className="h-8 text-[11px] w-28"
                    />
                    <span className="text-muted-foreground text-[10px]">to</span>
                    <Input
                      type="date"
                      value={endDate}
                      onChange={(e) => setDateFilter(startDate, e.target.value)}
                      className="h-8 text-[11px] w-28"
                    />
                  </div>

                  {/* Presets */}
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleQuickDatePreset("today")}
                      className="px-2 py-1 rounded-sm bg-secondary hover:bg-accent text-[10px] font-bold text-foreground"
                    >
                      Today
                    </button>
                    <button
                      onClick={() => handleQuickDatePreset("this_month")}
                      className="px-2 py-1 rounded-sm bg-secondary hover:bg-accent text-[10px] font-bold text-foreground"
                    >
                      This Month
                    </button>
                    <button
                      onClick={() => handleQuickDatePreset("all")}
                      className="px-2 py-1 rounded-sm bg-secondary hover:bg-accent text-[10px] font-bold text-muted-foreground"
                    >
                      Clear
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Report Navigation Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            <button
              onClick={() => handleTabChange("profit-loss")}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-sm font-bold text-xs transition-all border shrink-0 ${activeTab === "profit-loss" ? "bg-primary text-primary-foreground border-primary shadow-md shadow-primary/10" : "bg-card border-border/60 text-muted-foreground hover:text-foreground hover:bg-muted/40"}`}
            >
              <PieChart className="h-4 w-4" /> Profit & Loss Statement
            </button>

            <button
              onClick={() => handleTabChange("stock-valuation")}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-sm font-bold text-xs transition-all border shrink-0 ${activeTab === "stock-valuation" ? "bg-primary text-primary-foreground border-primary shadow-md shadow-primary/10" : "bg-card border-border/60 text-muted-foreground hover:text-foreground hover:bg-muted/40"}`}
            >
              <Layers className="h-4 w-4" /> Stock Valuation & Inventory
            </button>

            <button
              onClick={() => handleTabChange("sales-purchases")}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-sm font-bold text-xs transition-all border shrink-0 ${activeTab === "sales-purchases" ? "bg-primary text-primary-foreground border-primary shadow-md shadow-primary/10" : "bg-card border-border/60 text-muted-foreground hover:text-foreground hover:bg-muted/40"}`}
            >
              <ShoppingBag className="h-4 w-4" /> Sales vs Purchases
            </button>

            <button
              onClick={() => handleTabChange("contact-balances")}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-sm font-bold text-xs transition-all border shrink-0 ${activeTab === "contact-balances" ? "bg-primary text-primary-foreground border-primary shadow-md shadow-primary/10" : "bg-card border-border/60 text-muted-foreground hover:text-foreground hover:bg-muted/40"}`}
            >
              <Users className="h-4 w-4" /> Contact Balances (Ledgers)
            </button>
          </div>

          {/* Active Report View Body */}
          <div className="bg-card border border-border/60 rounded-sm p-6 shadow-xl min-h-[500px]">
            {activeTab === "profit-loss" && (
              <ProfitLossView
                businessId={businessId}
                startDate={startDate}
                endDate={endDate}
                branchId={selectedBranchFilter}
              />
            )}

            {activeTab === "stock-valuation" && (
              <StockValuationView
                businessId={businessId}
                branchId={selectedBranchFilter}
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
              />
            )}

            {activeTab === "sales-purchases" && (
              <SalesPurchasesView
                businessId={businessId}
                startDate={startDate}
                endDate={endDate}
                branchId={selectedBranchFilter}
              />
            )}

            {activeTab === "contact-balances" && (
              <ContactBalancesView
                businessId={businessId}
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
              />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

export default function ReportsPage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen w-screen items-center justify-center bg-[#121216]">
        <div className="flex flex-col items-center gap-2">
          <div className="w-8 h-8 border-4 border-zinc-700 border-t-emerald-500 rounded-full animate-spin" />
          <p className="text-sm text-zinc-400">Loading Reports...</p>
        </div>
      </div>
    }>
      <ReportsPageContent />
    </Suspense>
  );
}
