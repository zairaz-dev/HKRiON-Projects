/**
 * Utility for extracting and sanitizing the client's IP address.
 * Prioritizes trusted edge headers (Cloudflare, standard reverse proxies)
 * and strips ports or formatting irregularities.
 */

export function getClientIp(request: Request): string {
  // 1. Cloudflare True Client IP / Connecting IP
  const cfConnectingIp = request.headers.get("cf-connecting-ip");
  if (cfConnectingIp && cfConnectingIp.trim()) {
    return sanitizeIp(cfConnectingIp);
  }

  const trueClientIp = request.headers.get("true-client-ip");
  if (trueClientIp && trueClientIp.trim()) {
    return sanitizeIp(trueClientIp);
  }

  // 2. Standard reverse proxy real IP
  const xRealIp = request.headers.get("x-real-ip");
  if (xRealIp && xRealIp.trim()) {
    return sanitizeIp(xRealIp);
  }

  // 3. X-Forwarded-For (take the first / client IP in the chain)
  const xForwardedFor = request.headers.get("x-forwarded-for");
  if (xForwardedFor && xForwardedFor.trim()) {
    const parts = xForwardedFor.split(",").map((s) => s.trim()).filter(Boolean);
    if (parts.length > 0) {
      return sanitizeIp(parts[0]);
    }
  }

  return "127.0.0.1";
}

function sanitizeIp(rawIp: string): string {
  let cleaned = rawIp.trim();

  // Strip IPv4-mapped IPv6 prefix if present (e.g. ::ffff:192.168.1.1)
  if (cleaned.startsWith("::ffff:")) {
    cleaned = cleaned.substring(7);
  }

  // Strip port from IPv4 address (e.g. 192.168.1.1:443 -> 192.168.1.1)
  // Only strip if it matches standard IPv4:port
  if (/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d+$/.test(cleaned)) {
    cleaned = cleaned.split(":")[0];
  }

  // Strip brackets from bracketed IPv6 (e.g. [::1] -> ::1)
  if (cleaned.startsWith("[") && cleaned.includes("]")) {
    cleaned = cleaned.slice(1, cleaned.indexOf("]"));
  }

  // Basic sanity check on length to prevent memory abuse in Map keys
  if (cleaned.length > 64 || /[^a-zA-Z0-9.:_%-]/.test(cleaned)) {
    return "127.0.0.1";
  }

  return cleaned || "127.0.0.1";
}
