import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { verifyToken } from '@/lib/auth';

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const token = request.cookies.get('hkrion_auth_token')?.value;

  const authUser = token ? await verifyToken(token) : null;

  // Protect /dashboard routes
  if (pathname.startsWith('/dashboard')) {
    if (!authUser) {
      const loginUrl = new URL('/login', request.url);
      loginUrl.searchParams.set('callbackUrl', pathname);
      return NextResponse.redirect(loginUrl);
    }

    if (pathname.startsWith('/dashboard/admin') && authUser.role !== 'ADMIN') {
      return NextResponse.redirect(new URL(
        authUser.role === 'EMPLOYEE' ? '/dashboard/employee' : '/dashboard/customer',
        request.url
      ));
    }

    if (pathname.startsWith('/dashboard/employee') && authUser.role !== 'EMPLOYEE' && authUser.role !== 'ADMIN') {
      return NextResponse.redirect(new URL('/dashboard/customer', request.url));
    }
  }

  // Redirect authenticated user away from /login
  if (pathname === '/login' && authUser) {
    const redirectPath =
      authUser.role === 'ADMIN'
        ? '/dashboard/admin'
        : authUser.role === 'EMPLOYEE'
        ? '/dashboard/employee'
        : '/dashboard/customer';
    return NextResponse.redirect(new URL(redirectPath, request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/dashboard/:path*', '/login'],
};
