import * as React from "react"
import { cn } from "@/lib/utils"

/**
 * ==========================================================================
 * Card Component
 * ==========================================================================
 * 
 * The main container card with a subtle border, background, and shadow.
 * Frequently used with the `.glass` class for semi-transparent dark UI designs.
 */
const Card = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn(
      "rounded-sm border border-border/60 bg-card text-card-foreground shadow-[0_8px_30px_rgba(0,0,0,0.04)] dark:shadow-none transition-all duration-300",
      className
    )}
    {...props}
  />
))
Card.displayName = "Card"

/**
 * ==========================================================================
 * CardHeader Component
 * ==========================================================================
 * 
 * The top section of a card, typically housing CardTitle and CardDescription.
 * Provides standard layout flexbox styling and padding.
 */
const CardHeader = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn("flex flex-col space-y-1.5 p-6", className)}
    {...props}
  />
))
CardHeader.displayName = "CardHeader"

/**
 * ==========================================================================
 * CardTitle Component
 * ==========================================================================
 * 
 * The main heading of a card. Renders as an `<h3>` tag with semibold styling.
 */
const CardTitle = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLHeadingElement>
>(({ className, ...props }, ref) => (
  <h3
    ref={ref}
    className={cn("font-semibold leading-none tracking-tight", className)}
    {...props}
  />
))
CardTitle.displayName = "CardTitle"

/**
 * ==========================================================================
 * CardDescription Component
 * ==========================================================================
 * 
 * Subtext or description located under CardTitle, styled with muted text colors.
 */
const CardDescription = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => (
  <p
    ref={ref}
    className={cn("text-sm text-muted-foreground", className)}
    {...props}
  />
))
CardDescription.displayName = "CardDescription"

/**
 * ==========================================================================
 * CardContent Component
 * ==========================================================================
 * 
 * The primary body/content wrapper of a card.
 */
const CardContent = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("p-6 pt-0", className)}
    {...props}
  />
))
CardContent.displayName = "CardContent"

/**
 * ==========================================================================
 * CardFooter Component
 * ==========================================================================
 * 
 * The bottom section of a card, often housing action buttons (e.g. Cancel/Confirm).
 */
const CardFooter = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn("flex items-center p-6 pt-0", className)}
    {...props}
  />
))
CardFooter.displayName = "CardFooter"

export { Card, CardHeader, CardFooter, CardTitle, CardDescription, CardContent }
