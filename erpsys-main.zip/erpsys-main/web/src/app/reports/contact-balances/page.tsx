"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import { Users, Loader2, AlertCircle } from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";
import { ContactBalancesView } from "@/features/reports";

function ContactBalancesPageContent() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  const searchQuery = searchParams.get("search") || "";

  const setSearchQuery = (val: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (val) params.set("search", val);
    else params.delete("search");
    router.push(`${pathname}?${params.toString()}`);
  };

  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  const businessId = currentUser?.businessId || "";

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3 p-6 max-w-sm border border-border/40 rounded-xl bg-card/60 backdrop-blur-sm">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <h2 className="text-lg font-bold">Unauthorized Access</h2>
          <p className="text-sm text-muted-foreground">Redirecting to login...</p>
          <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/reports/contact-balances" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Contact Balances Report" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-border pb-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <Users className="h-7 w-7 text-primary" /> Contact Balances (Receivables & Payables)
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Customer unpaid invoice dues (Receivables) and supplier unpaid purchase dues (Payables).
              </p>
            </div>
          </div>

          <div className="bg-card border border-border/60 rounded-sm p-6 shadow-xl">
            <ContactBalancesView
              businessId={businessId}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
            />
          </div>
        </main>
      </div>
    </div>
  );
}

export default function ContactBalancesPage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen w-screen items-center justify-center bg-[#121216]">
        <div className="w-8 h-8 border-4 border-zinc-700 border-t-emerald-500 rounded-full animate-spin" />
      </div>
    }>
      <ContactBalancesPageContent />
    </Suspense>
  );
}
