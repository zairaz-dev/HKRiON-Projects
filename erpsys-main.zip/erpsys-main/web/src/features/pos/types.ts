export interface CartItem {
  variantId: string;
  variantName: string;
  sku: string;
  barcode?: string | null;
  productName: string;
  quantity: number;
  unitPrice: number;
  discountAmount: number;
  taxAmount: number;
  subtotal: number;
  stockAvailable?: number;
  imageUrl?: string | null;
  isImei?: boolean;
  imeiNumber?: string;
  imeis?: string[];
}

export interface SalePaymentInput {
  amount: number;
  paymentMethodId: string;
  transactionNo?: string;
  notes?: string;
}

export interface SaleCheckoutInput {
  invoiceNumber?: string;
  customerId: string;
  branchId: string;
  businessId: string;
  discountType?: 'FIXED' | 'PERCENTAGE';
  discountAmount?: number;
  taxAmount?: number;
  grandTotal: number;
  notes?: string;
  status: 'HOLD' | 'DRAFT' | 'FINAL';
  saleLines: {
    variantId: string;
    quantity: number;
    unitPrice: number;
    discountAmount?: number;
    taxAmount?: number;
    imeiNumber?: string;
    imeis?: string[];
  }[];
  payments: SalePaymentInput[];
  useAdvance: boolean;
}

export interface SaleItem {
  id: string;
  invoiceNumber: string;
  saleDate: string;
  status: 'HOLD' | 'DRAFT' | 'FINAL';
  paymentStatus: 'DUE' | 'PARTIAL' | 'PAID';
  amountPaid: number;
  grandTotal: number;
  customer: {
    id: string;
    name: string;
    phone?: string | null;
  };
  branch: {
    id: string;
    name: string;
  };
  createdBy?: {
    id: string;
    name: string;
    email?: string;
  } | null;
  saleLines?: any[];
}

export interface CustomerAdvanceItem {
  id: string;
  advanceNumber: string;
  advanceDate: string;
  amount: number;
  amountRemaining: number;
  paymentMethod: {
    id: string;
    name: string;
  };
}
