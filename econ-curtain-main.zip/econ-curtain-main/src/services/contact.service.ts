import { db } from "@/core/db/client";

export interface ContactPageContentData {
  id: string;
  // Header Section
  headerTitlePrefix: string;
  headerTitleHighlight: string;
  headerSubtitle: string;

  // Contact Details
  sectionTitle: string;
  sectionDescription: string;

  // Contact Channels
  phone: string;
  phoneSubtitle: string;

  email: string;
  emailSubtitle: string;

  addressLine1: string;
  addressLine2: string;

  workingHoursLine1: string;
  workingHoursLine2: string;

  whatsapp: string;

  // Form Section
  formTitle: string;
  formSubtitle: string;
  formButtonText: string;

  updatedAt?: Date;
}

export const defaultContactPageContent: ContactPageContentData = {
  id: "contact_default",
  headerTitlePrefix: "Get in",
  headerTitleHighlight: "Touch",
  headerSubtitle: "Have a question or need a quote? We're here to help. Reach out to our team of experts today.",

  sectionTitle: "Contact Details",
  sectionDescription: "Ready to transform your home or workspace with bespoke blinds and shade systems? Contact us directly or fill out the form.",

  phone: "+94 75 807 9921",
  phoneSubtitle: "Mon-Sat from 9am to 8pm",

  email: "info@shadeitblinds.com",
  emailSubtitle: "Online support 24/7",

  addressLine1: "No.188/29A, Brandiyawatha",
  addressLine2: "Wellampitiya, Colombo, Sri Lanka",

  workingHoursLine1: "Monday – Saturday: 9:00 AM – 8:00 PM",
  workingHoursLine2: "Sunday: By Appointment",

  whatsapp: "+94 75 807 9921",

  formTitle: "Send an Inquiry",
  formSubtitle: "Fill out the form below and we'll get back to you within 24 hours.",
  formButtonText: "Send Inquiry",
};

export class ContactService {
  /**
   * Retrieves the contact page content from SQLite or creates default if not exists
   */
  static async getContent(): Promise<ContactPageContentData> {
    try {
      const content = await db.contactPageContent.findUnique({
        where: { id: "contact_default" },
      });

      if (!content) {
        return await db.contactPageContent.create({
          data: {
            ...defaultContactPageContent,
          },
        });
      }

      return content;
    } catch (e) {
      console.error("Failed to load contact page content from DB, returning defaults:", e);
      return defaultContactPageContent;
    }
  }

  /**
   * Updates contact page content
   */
  static async updateContent(data: Partial<ContactPageContentData>): Promise<ContactPageContentData> {
    try {
      const updated = await db.contactPageContent.upsert({
        where: { id: "contact_default" },
        update: {
          ...data,
          updatedAt: new Date(),
        },
        create: {
          ...defaultContactPageContent,
          ...data,
        },
      });

      return updated;
    } catch (e) {
      console.error("Failed to update contact page content:", e);
      throw e;
    }
  }
}
