import mysql from "mysql2/promise";

// Global connection pool singleton for Next.js App Router & hot reloading
const globalForMySQL = globalThis as unknown as {
  mysqlPool: mysql.Pool | undefined;
};

function createPool(): mysql.Pool {
  const connectionUri = process.env.DATABASE_URL || "mysql://root:@localhost:3306/gem_ecommerce";

  try {
    const url = new URL(connectionUri);
    return mysql.createPool({
      host: url.hostname || "127.0.0.1",
      port: url.port ? parseInt(url.port, 10) : 3306,
      user: url.username || "root",
      password: url.password || "",
      database: url.pathname ? url.pathname.replace(/^\//, "") : "gem_ecommerce",
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      enableKeepAlive: true,
      keepAliveInitialDelay: 10000,
    });
  } catch {
    // Fallback if URL parsing fails
    return mysql.createPool({
      uri: connectionUri,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
    });
  }
}

export const pool = globalForMySQL.mysqlPool ?? createPool();

if (process.env.NODE_ENV !== "production") {
  globalForMySQL.mysqlPool = pool;
}

/**
 * Execute a parameterized query against MySQL
 */
export async function query<T = unknown>(
  sql: string,
  params: (string | number | boolean | null | undefined)[] = []
): Promise<T[]> {
  const [rows] = await pool.query(sql, params);
  return rows as T[];
}

export default pool;
