import { ProductService } from "@/services/product.service";
import { CategoryService } from "@/services/category.service";
import { ContactService } from "@/services/contact.service";
import { Sparkles, PhoneCall } from "lucide-react";
import Link from "next/link";
import ProductCard from "@/components/products/ProductCard";

export const dynamic = "force-dynamic";

interface ProductsPageProps {
  searchParams?: Promise<{ cat?: string }>;
}

export default async function ProductsPage({ searchParams }: ProductsPageProps) {
  const params = await searchParams;
  const catQuery = params?.cat;

  // Query live database products, categories, and contact info directly from SQLite
  const [rawProducts, rawCategories, contact] = await Promise.all([
    ProductService.getAll(),
    CategoryService.getAll(),
    ContactService.getContent(),
  ]);

  // Dynamic live categories from DB
  const dbCategoryNames = rawCategories.map((c) => c.name);
  const distinctProductCategories = Array.from(new Set(rawProducts.map((p) => p.category)));
  const allCategoryNames = Array.from(new Set([...dbCategoryNames, ...distinctProductCategories]));
  const categoryTabs = ["All", ...allCategoryNames];

  const activeCategory =
    catQuery && (catQuery === "All" || allCategoryNames.includes(catQuery))
      ? catQuery
      : "All";

  const products = rawProducts.map((p) => {
    let parsedFeatures: string[] = [];
    try {
      parsedFeatures = JSON.parse(p.features || "[]");
    } catch {
      parsedFeatures = [];
    }
    return {
      id: p.id,
      name: p.name,
      category: p.category,
      description: p.description,
      image: p.imageUrl,
      images: p.images,
      features: parsedFeatures,
      isActive: p.isActive,
    };
  });

  const filteredProducts =
    activeCategory === "All"
      ? products
      : products.filter((product) => product.category === activeCategory);

  const getCategoryCount = (category: string) => {
    if (category === "All") return products.length;
    return products.filter((p) => p.category === category).length;
  };

  return (
    <div className="flex flex-col w-full overflow-x-hidden bg-slate-950 text-slate-100 min-h-screen">
      {/* Hero Header */}
      <section className="relative py-16 sm:py-24 px-4 sm:px-6 lg:px-8 bg-slate-950 overflow-hidden border-b border-slate-800">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,var(--tw-gradient-stops))] from-amber-500/10 via-slate-950/40 to-slate-950 pointer-events-none" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-125 h-65 bg-amber-400/10 blur-[100px] pointer-events-none rounded-full" />
        
        <div className="relative max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-400 text-xs font-bold uppercase tracking-widest mb-4">
            <Sparkles size={14} /> Comprehensive Catalog
          </div>
          <h1 className="text-3xl sm:text-5xl md:text-6xl font-extrabold text-white mb-6 tracking-tight">
            Our <span className="text-transparent bg-clip-text bg-linear-to-r from-yellow-400 via-amber-300 to-yellow-500">Products</span>
          </h1>
          <p className="text-slate-300 max-w-2xl mx-auto text-base sm:text-lg font-light leading-relaxed">
            Explore our architectural window coverings, motorized shading systems, luxury teak loungers, and tropical weatherproof PVC solutions.
          </p>
        </div>
      </section>

      {/* Filter Categories Bar - 100% Dynamic from SQLite Database */}
      <section className="py-6 bg-slate-900/90 backdrop-blur-xl border-b border-slate-800/80 sticky top-17 sm:top-18 z-30 shadow-2xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3">
            {categoryTabs.map((category) => {
              const isActive = activeCategory === category;
              const count = getCategoryCount(category);
              const href = category === "All" ? "/products" : `/products?cat=${encodeURIComponent(category)}`;
              return (
                <Link
                  key={category}
                  href={href}
                  scroll={false}
                  className={`px-4 sm:px-5 py-2 sm:py-2.5 rounded-full text-xs sm:text-sm font-semibold transition-all duration-200 flex items-center gap-2 select-none touch-manipulation cursor-pointer ${
                    isActive
                      ? "bg-linear-to-r from-primary via-amber-500 to-yellow-500 text-slate-950 shadow-lg shadow-amber-500/20 scale-105 font-bold"
                      : "bg-slate-800/80 text-slate-300 hover:bg-slate-700/80 hover:text-white border border-slate-700/60"
                  }`}
                >
                  <span>{category}</span>
                  <span
                    className={`text-[11px] px-2 py-0.5 rounded-full ${
                      isActive
                        ? "bg-slate-950/20 text-slate-950 font-black"
                        : "bg-slate-700 text-slate-300"
                    }`}
                  >
                    {count}
                  </span>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Product Grid Section */}
      <section className="py-16 md:py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-8">
            {filteredProducts.map((product, index) => (
              <ProductCard key={product.id} product={product} priority={index < 4} whatsappNumber={contact.whatsapp} />
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-20 text-slate-400 bg-slate-900/60 rounded-3xl border border-slate-800 p-8 max-w-md mx-auto">
              <p className="text-lg font-medium text-white mb-2">No products found</p>
              <p className="text-sm text-slate-400 mb-6">There are no products listed under this category.</p>
              <Link
                href="/products"
                className="inline-block px-6 py-2.5 bg-primary text-slate-950 rounded-full font-bold text-sm"
              >
                View All Products
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* Consultation Banner */}
      <section className="py-20 bg-linear-to-r from-slate-900 via-slate-950 to-slate-900 border-t border-slate-800 px-4 text-center">
        <div className="max-w-4xl mx-auto space-y-6">
          <span className="text-amber-400 text-xs font-black uppercase tracking-widest block">
            Custom Sizing & Professional Installation
          </span>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-white">
            Need Custom Dimensions or On-Site Measurements?
          </h2>
          <p className="text-slate-300 text-sm sm:text-base max-w-xl mx-auto font-light leading-relaxed">
            Our expert technicians provide free doorstep laser measurements and bespoke design recommendations tailored to your exact window or patio space.
          </p>
          <div className="pt-4 flex justify-center">
            <Link
              href="/contact"
              className="px-8 py-3.5 bg-linear-to-r from-primary via-amber-500 to-yellow-500 text-slate-950 font-bold rounded-full text-sm sm:text-base hover:brightness-110 transition-all shadow-xl flex items-center gap-2 active:scale-95"
            >
              <PhoneCall size={18} />
              <span>Request Free Site Measurement</span>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
