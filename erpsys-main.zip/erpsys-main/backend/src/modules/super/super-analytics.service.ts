import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

export interface SystemAnalyticsOverview {
  // Tenant metrics
  totalBusinesses: number;
  activeBusinesses: number;
  suspendedBusinesses: number;
  trialBusinesses: number;
  newBusinessesThisMonth: number;

  // User & Branch counts
  totalUsers: number;
  totalBranches: number;

  // Subscriptions & Revenue
  totalSubscriptions: number;
  activeSubscriptions: number;
  mrrLkr: number;
  arrLkr: number;
  plansDistribution: Array<{
    planId: string;
    planName: string;
    count: number;
    revenueMonthly: number;
  }>;

  // ERP Operations Volume
  totalGlobalSalesCount: number;
  totalGlobalSalesAmount: number;
  totalProductsCount: number;
  totalImeisCount: number;
  salesThisMonthCount: number;
  salesThisMonthAmount: number;

  // Recent Businesses
  recentSignups: Array<{
    id: string;
    name: string;
    industry: string;
    phone: string;
    isActive: boolean;
    createdAt: Date;
    planName: string;
    userCount: number;
    branchCount: number;
  }>;

  // System Health
  systemHealth: {
    databaseStatus: 'HEALTHY' | 'DEGRADED';
    uptimeSeconds: number;
    memoryUsageMb: number;
    serverTime: Date;
    activeSessionsEstimate: number;
  };
}

@Injectable()
export class SuperAnalyticsService {
  constructor(private readonly prisma: PrismaService) {}

  async getOverview(): Promise<SystemAnalyticsOverview> {
    const now = new Date();
    const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    // Parallel aggregate queries for max speed
    const [
      totalBusinesses,
      activeBusinesses,
      suspendedBusinesses,
      newBusinessesThisMonth,
      totalUsers,
      totalBranches,
      allSubscriptions,
      allPlans,
      salesStats,
      salesThisMonth,
      totalProductsCount,
      totalImeisCount,
      recentBusinessesRaw,
    ] = await Promise.all([
      this.prisma.business.count(),
      this.prisma.business.count({ where: { isActive: true } }),
      this.prisma.business.count({ where: { isActive: false } }),
      this.prisma.business.count({
        where: { createdAt: { gte: firstDayOfMonth } },
      }),
      this.prisma.user.count(),
      this.prisma.branch.count(),
      this.prisma.subscription.findMany({
        include: { plan: true },
      }),
      this.prisma.plan.findMany(),
      this.prisma.sale.aggregate({
        _count: { id: true },
        _sum: { grandTotal: true },
      }),
      this.prisma.sale.aggregate({
        where: { createdAt: { gte: firstDayOfMonth } },
        _count: { id: true },
        _sum: { grandTotal: true },
      }),
      this.prisma.product.count(),
      this.prisma.productImei.count(),
      this.prisma.business.findMany({
        take: 6,
        orderBy: { createdAt: 'desc' },
        include: {
          subscription: { include: { plan: true } },
          users: { select: { id: true } },
          branches: { select: { id: true } },
        },
      }),
    ]);

    // Compute Subscription & MRR Metrics
    let mrrLkr = 0;
    let activeSubscriptions = 0;
    let trialBusinesses = 0;

    const planCountMap = new Map<string, { name: string; count: number; mrr: number }>();
    allPlans.forEach((p) => {
      planCountMap.set(p.id, { name: p.name, count: 0, mrr: 0 });
    });

    for (const sub of allSubscriptions) {
      if (sub.status === 'ACTIVE' || sub.status === 'TRIAL') {
        if (sub.status === 'TRIAL') trialBusinesses++;
        if (sub.status === 'ACTIVE') activeSubscriptions++;

        const monthlyPrice = sub.billingInterval === 'YEARLY'
          ? (sub.plan?.priceYearly ? sub.plan.priceYearly / 12 : sub.plan?.priceMonthly || 0)
          : (sub.plan?.priceMonthly || 0);

        mrrLkr += monthlyPrice;

        const currentEntry = planCountMap.get(sub.planId);
        if (currentEntry) {
          currentEntry.count += 1;
          currentEntry.mrr += monthlyPrice;
        }
      }
    }

    const plansDistribution = Array.from(planCountMap.entries()).map(([planId, data]) => ({
      planId,
      planName: data.name,
      count: data.count,
      revenueMonthly: data.mrr,
    }));

    const arrLkr = mrrLkr * 12;

    const recentSignups = recentBusinessesRaw.map((b) => ({
      id: b.id,
      name: b.name,
      industry: b.industry || 'General Retail',
      phone: b.phone || 'N/A',
      isActive: b.isActive,
      createdAt: b.createdAt,
      planName: b.subscription?.plan?.name || 'Trial Tier',
      userCount: b.users?.length || 0,
      branchCount: b.branches?.length || 0,
    }));

    const memUsage = process.memoryUsage();
    const memoryMb = Math.round(memUsage.heapUsed / 1024 / 1024);

    return {
      totalBusinesses,
      activeBusinesses,
      suspendedBusinesses,
      trialBusinesses,
      newBusinessesThisMonth,
      totalUsers,
      totalBranches,
      totalSubscriptions: allSubscriptions.length,
      activeSubscriptions,
      mrrLkr,
      arrLkr,
      plansDistribution,
      totalGlobalSalesCount: salesStats._count.id || 0,
      totalGlobalSalesAmount: Number(salesStats._sum.grandTotal || 0),
      totalProductsCount,
      totalImeisCount,
      salesThisMonthCount: salesThisMonth._count.id || 0,
      salesThisMonthAmount: Number(salesThisMonth._sum.grandTotal || 0),
      recentSignups,
      systemHealth: {
        databaseStatus: 'HEALTHY',
        uptimeSeconds: Math.round(process.uptime()),
        memoryUsageMb: memoryMb,
        serverTime: new Date(),
        activeSessionsEstimate: Math.max(totalUsers > 0 ? Math.round(totalUsers * 0.4) : 1, 1),
      },
    };
  }

  async getTrends() {
    const now = new Date();
    const months = [];

    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const nextMonth = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);
      const monthLabel = d.toLocaleString('en-US', { month: 'short' });

      const [businessesCreated, salesVolume] = await Promise.all([
        this.prisma.business.count({
          where: { createdAt: { gte: d, lt: nextMonth } },
        }),
        this.prisma.sale.aggregate({
          where: { createdAt: { gte: d, lt: nextMonth } },
          _sum: { grandTotal: true },
          _count: { id: true },
        }),
      ]);

      months.push({
        month: monthLabel,
        year: d.getFullYear(),
        newTenants: businessesCreated,
        salesCount: salesVolume._count.id || 0,
        salesAmount: Number(salesVolume._sum.grandTotal || 0),
      });
    }

    return months;
  }
}
