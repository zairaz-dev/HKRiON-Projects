import { NextResponse } from 'next/server';
import { getSavedLeads, saveLeads, updateLeadStatus, deleteLead, clearAllLeads } from '@/lib/leadsStore';

export async function GET() {
  try {
    const leads = getSavedLeads();
    return NextResponse.json({ success: true, count: leads.length, leads });
  } catch (err) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

export async function POST(req) {
  try {
    const body = await req.json();
    const { action, leadId, status, notes, leads } = body;

    if (action === 'update_status' && leadId) {
      const updated = updateLeadStatus(leadId, status, notes);
      return NextResponse.json({ success: true, lead: updated });
    }

    if (action === 'delete' && leadId) {
      deleteLead(leadId);
      return NextResponse.json({ success: true, message: 'Lead deleted' });
    }

    if (action === 'clear_all') {
      clearAllLeads();
      return NextResponse.json({ success: true, message: 'All leads cleared' });
    }

    if (Array.isArray(leads)) {
      const result = saveLeads(leads);
      return NextResponse.json(result);
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
  } catch (err) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
