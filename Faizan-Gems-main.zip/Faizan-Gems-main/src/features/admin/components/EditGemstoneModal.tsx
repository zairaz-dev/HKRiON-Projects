"use client";

import React, { useState, useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import Image from "next/image";
import {
  Gemstone,
  GemstoneType,
  GemstoneCut,
  GemstoneVariant,
  TreatmentType,
  CertificationLab,
  extractCountryFromOrigin,
  getSpeciesForType,
} from "@/types/gemstone";
import { CloseIcon } from "@/components/ui/LuxuryIcons";
import { LuxurySelect } from "@/components/ui/LuxurySelect";
import { ImageCropModal, CropCoordinates } from "@/components/ui/ImageCropModal";
import { LuxuryPrice } from "@/components/ui/LuxuryPrice";
import { useToast } from "@/components/ui/LuxuryToast";
import { useGemstoneAttributes, AttributeCategory } from "../hooks/useGemstoneAttributes";
import { compressAndLimitVideo } from "@/lib/video-compressor";

interface EditGemstoneModalProps {
  isOpen: boolean;
  onClose: () => void;
  gemstone: Gemstone | null;
  onSave: (id: string, updated: Partial<Gemstone>) => Promise<void> | void;
  formatPrice: (price: number) => string;
}

export function EditGemstoneModal({
  isOpen,
  onClose,
  gemstone,
  onSave,
  formatPrice,
}: EditGemstoneModalProps) {
  const { toast } = useToast();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  // Form State
  const [name, setName] = useState("");
  const [type, setType] = useState<GemstoneType>("Sapphire");
  const [variety, setVariety] = useState("Natural Corundum");
  const [cut, setCut] = useState<GemstoneCut>("Baguette");
  const [cutDetail, setCutDetail] = useState("");
  const [color, setColor] = useState("Red");
  const [colorGrade, setColorGrade] = useState("Vivid Saturation");
  const [clarity, setClarity] = useState("Eye Clean");
  const [treatment, setTreatment] = useState("Unheated");
  const [origin, setOrigin] = useState("Ratnapura, Sri Lanka");
  const [originCountry, setOriginCountry] = useState("Sri Lanka");
  const [species, setSpecies] = useState("Natural Corundum");
  const [description, setDescription] = useState("");
  const [inStock, setInStock] = useState(true);
  const [featured, setFeatured] = useState(false);

  const {
    types: availableTypes,
    cuts: availableCuts,
    clarities: availableClarities,
    treatments: availableTreatments,
    addCustomOption,
    editCustomOption,
    deleteCustomOption,
  } = useGemstoneAttributes(gemstone ? [gemstone] : undefined);

  const [addingField, setAddingField] = useState<AttributeCategory | null>(null);
  const [customAttributeInput, setCustomAttributeInput] = useState("");

  const handleSaveCustomAttribute = (category: AttributeCategory) => {
    if (!customAttributeInput.trim()) return;
    const added = addCustomOption(category, customAttributeInput);
    if (added) {
      if (category === "type") {
        setType(added as GemstoneType);
      } else if (category === "cut") {
        setCut(added as GemstoneCut);
        setCutDetail(`${added} Precision Cut`);
      } else if (category === "clarity") {
        setClarity(added);
      } else if (category === "treatment") {
        setTreatment(added as TreatmentType);
      }
      toast.success("Option Added", `"${added}" added to ${category} and selected.`);
    }
    setAddingField(null);
    setCustomAttributeInput("");
  };

  // Specimen Carat Weight, Price, Stock & Dimensions State
  const [caratWeight, setCaratWeight] = useState<number>(0.55);
  const [price, setPrice] = useState<number>(45000);
  const [stockQty, setStockQty] = useState<number>(5);
  const [sizeDimensions, setSizeDimensions] = useState<string>("");

  // Multi-Image Gallery State (No Enter URL)
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [photoUploadError, setPhotoUploadError] = useState<string | null>(null);

  // Crop States
  const [cropFile, setCropFile] = useState<File | null>(null);
  const [cropUrl, setCropUrl] = useState<string | null>(null);
  const [cropTargetIndex, setCropTargetIndex] = useState<number | null>(null);
  const [isCropModalOpen, setIsCropModalOpen] = useState(false);
  const [isCroppingAndSaving, setIsCroppingAndSaving] = useState(false);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const photoFileInputRef = useRef<HTMLInputElement>(null);

  // Video Showcase State (Strict 8s time limit & auto-compression)
  const [uploadedVideo, setUploadedVideo] = useState<string | null>(null);
  const [isProcessingVideo, setIsProcessingVideo] = useState(false);
  const [videoProcessingStatus, setVideoProcessingStatus] = useState<string>("");
  const [videoError, setVideoError] = useState<string | null>(null);
  const videoFileInputRef = useRef<HTMLInputElement>(null);

  // Populate form when gemstone changes
  useEffect(() => {
    if (gemstone) {
      setName(gemstone.name || "");
      setType(gemstone.type || "Sapphire");
      setVariety(gemstone.variety || "Natural Corundum");
      setCut(gemstone.cut || "Baguette");
      setCutDetail(gemstone.cutDetail || `${gemstone.cut} Precision Cut`);
      setColor(gemstone.color || "");
      setColorGrade(gemstone.colorGrade || "");
      setClarity(gemstone.clarity || "Eye Clean");
      setTreatment(
        gemstone.treatment?.includes("Unheated")
          ? "Unheated"
          : (gemstone.treatment as string) || (gemstone.isUnheated ? "Unheated" : "Traditional Minor Heat")
      );
      setOrigin(gemstone.origin || "");
      setOriginCountry(gemstone.originCountry || extractCountryFromOrigin(gemstone.origin));
      setSpecies(gemstone.species || getSpeciesForType(gemstone.type));
      setDescription(gemstone.description || "");
      const initialWeight = gemstone.variants?.[0]?.weight ?? gemstone.carat ?? 0.55;
      const initialPrice = gemstone.variants?.[0]?.price ?? gemstone.price ?? 45000;
      const initialStock = gemstone.variants?.[0]?.stock ?? (gemstone.inStock ? 5 : 0);
      const isInitiallyInStock = Boolean(gemstone.inStock) || initialStock > 0;
      setInStock(isInitiallyInStock);
      setFeatured(Boolean(gemstone.featured));
      setUploadedImages(gemstone.images || []);
      setUploadedVideo(gemstone.video || null);
      setIsProcessingVideo(false);
      setVideoProcessingStatus("");
      setVideoError(null);
      const hasDims = Boolean(
        gemstone.dimensions &&
        (Number(gemstone.dimensions.length || 0) > 0 ||
         Number(gemstone.dimensions.width || 0) > 0 ||
         Number(gemstone.dimensions.depth || 0) > 0)
      );
      const initialSize =
        gemstone.variants?.[0]?.size ||
        (hasDims
          ? `${gemstone.dimensions!.length} x ${gemstone.dimensions!.width} x ${gemstone.dimensions!.depth}mm`
          : "");
      setCaratWeight(initialWeight);
      setPrice(initialPrice);
      setStockQty(initialStock);
      setSizeDimensions(initialSize);
      setErrorMsg(null);
    }
  }, [gemstone]);

  if (!isOpen || !gemstone || !mounted) return null;

  // Upload Multi-Files directly
  const handleMultiFileUpload = async (files: FileList | File[]) => {
    setIsUploadingPhoto(true);
    setPhotoUploadError(null);

    try {
      const newUrls: string[] = [];
      for (const file of Array.from(files)) {
        const formData = new FormData();
        formData.append("file", file);
        formData.append("category", "gemstones");

        const res = await fetch("/api/admin/upload", {
          method: "POST",
          body: formData,
        });

        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || "Upload failed");
        }
        newUrls.push(data.url);
      }

      setUploadedImages((prev) => [...prev, ...newUrls]);
      toast.success("Photos Uploaded", `${newUrls.length} gemstone photo(s) added.`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Failed to upload photo";
      setPhotoUploadError(msg);
      toast.error("Upload Error", msg);
    } finally {
      setIsUploadingPhoto(false);
    }
  };

  // Open Crop Studio for image index
  const handleOpenCropForIndex = (index: number) => {
    setCropTargetIndex(index);
    setCropFile(null);
    setCropUrl(uploadedImages[index]);
    setIsCropModalOpen(true);
  };

  // Process Crop and Save with Sharp
  const handleCropAndSave = async (cropData: CropCoordinates) => {
    setIsCroppingAndSaving(true);
    setPhotoUploadError(null);

    try {
      const formData = new FormData();
      if (cropFile) {
        formData.append("file", cropFile);
      } else if (cropUrl) {
        formData.append("imageUrl", cropUrl);
      }
      formData.append("category", "gemstones");
      formData.append("crop", JSON.stringify(cropData));

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        body: formData,
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Cropping and upload failed");
      }

      if (cropTargetIndex !== null) {
        setUploadedImages((prev) =>
          prev.map((img, idx) => (idx === cropTargetIndex ? data.url : img))
        );
      } else {
        setUploadedImages((prev) => [...prev, data.url]);
      }

      setIsCropModalOpen(false);
      setCropTargetIndex(null);
      toast.success("Photo Cropped", "Gemstone image updated successfully.");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Failed to crop and save photo";
      setPhotoUploadError(msg);
      toast.error("Photo Error", msg);
    } finally {
      setIsCroppingAndSaving(false);
    }
  };

  const handleRemoveImage = (indexToRemove: number) => {
    if (uploadedImages.length <= 1) {
      toast.warning("Photo Required", "Please keep at least one gemstone photo.");
      return;
    }
    setUploadedImages((prev) => prev.filter((_, idx) => idx !== indexToRemove));
  };

  const handleVideoUpload = async (file: File) => {
    setIsProcessingVideo(true);
    setVideoError(null);
    setVideoProcessingStatus("Analyzing video duration & quality...");

    try {
      const result = await compressAndLimitVideo(file, 8.0, (_pct, msg) => {
        setVideoProcessingStatus(msg);
      });

      setVideoProcessingStatus("Uploading compressed showcase video...");

      const formData = new FormData();
      formData.append("file", result.file);
      formData.append("category", "gemstones");

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        body: formData,
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to upload video");
      }

      setUploadedVideo(data.url);
      const originalMB = (result.originalSize / (1024 * 1024)).toFixed(1);
      const compressedMB = (result.compressedSize / (1024 * 1024)).toFixed(1);

      const isOriginal = result.compressedSize === result.originalSize;
      toast.success(
        "Showcase Video Ready",
        isOriginal
          ? `MP4 video validated & uploaded (${originalMB}MB, ${result.duration.toFixed(1)}s).`
          : result.wasTrimmed
          ? `Trimmed to 8s limit & compressed (${originalMB}MB → ${compressedMB}MB).`
          : `Compressed (${originalMB}MB → ${compressedMB}MB, ${result.duration.toFixed(1)}s).`
      );
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Video processing failed";
      setVideoError(msg);
      toast.error("Video Error", msg);
    } finally {
      setIsProcessingVideo(false);
      setVideoProcessingStatus("");
    }
  };

  const handleRemoveVideo = () => {
    setUploadedVideo("");
    setVideoError(null);
    setVideoProcessingStatus("");
  };

  // Submit Edit Form
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMsg(null);

    try {
      const trimmedSize = sizeDimensions.trim();
      const parseDimensions = (sizeStr?: string) => {
        if (!sizeStr) return undefined;
        const cleaned = sizeStr.replace(/mm/gi, "").trim();
        const parts = cleaned.split(/[\sx*×-]+/).map((n) => parseFloat(n)).filter((n) => !isNaN(n));
        if (parts.length >= 2 && parts[0] > 0 && parts[1] > 0) {
          return {
            length: parts[0],
            width: parts[1],
            depth: parts[2] || 0,
          };
        }
        return undefined;
      };

      const primaryVariant: GemstoneVariant = {
        id: gemstone.variants?.[0]?.id || `var-${gemstone.id}`,
        weight: Number(caratWeight),
        price: Number(price),
        stock: Number(stockQty),
        size: trimmedSize || undefined,
      };

      const finalCountry = originCountry?.trim() || extractCountryFromOrigin(origin);
      const finalSpecies = species?.trim() || getSpeciesForType(type);

      const updatedData: Partial<Gemstone> = {
        name,
        type,
        variety,
        species: finalSpecies,
        carat: Number(caratWeight),
        price: Number(price),
        cut,
        cutDetail: cutDetail || `${cut} Precision Cut`,
        color,
        colorGrade,
        clarity,
        origin,
        originCountry: finalCountry,
        treatment: treatment as any,
        isUnheated: treatment === "Unheated" || treatment.includes("Unheated"),
        description,
        inStock: Number(stockQty) > 0,
        featured,
        dimensions: parseDimensions(trimmedSize),
        variants:
          gemstone.variants && gemstone.variants.length > 1
            ? gemstone.variants.map((v, idx) => (idx === 0 ? primaryVariant : v))
            : [primaryVariant],
        images: uploadedImages.length > 0 ? uploadedImages : gemstone.images,
        angles360:
          gemstone.angles360 && gemstone.angles360.length > 0
            ? gemstone.angles360
            : uploadedImages.length > 0
            ? uploadedImages
            : gemstone.images,
        video: uploadedVideo !== null ? (uploadedVideo || "") : (gemstone.video || ""),
      };

      await onSave(gemstone.id, updatedData);
      onClose();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Failed to update gemstone";
      setErrorMsg(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  return createPortal(
    <>
      <div
        className="fixed inset-0 z-[99999] flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-luxury-backdrop"
      >
        <div
          className="relative w-full max-w-3xl bg-[#141419] border border-[#C5A880]/60 shadow-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto text-white animate-luxury-modal my-auto"
        >
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 text-[#8C867D] hover:text-white transition-colors"
          >
            <CloseIcon className="w-5 h-5" />
          </button>

          {/* Header */}
          <div className="mb-6 border-b border-[#24242C] pb-4">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] text-[#C5A880] font-mono uppercase tracking-widest bg-[#C5A880]/10 px-2 py-0.5 rounded border border-[#C5A880]/30">
                EDIT GEMSTONE
              </span>
              <span className="text-xs text-[#A1A1AA] font-mono tabular-nums">
                SKU: <span className="text-[#C5A880] font-semibold">{gemstone.sku}</span>
              </span>
            </div>
            <h2 className="font-sans text-xl sm:text-2xl font-semibold tracking-tight text-white">
              Edit Gemstone: {gemstone.name}
            </h2>
            <p className="text-xs text-[#A1A1AA] mt-1 font-sans">
              Update gemstone prices, stock, weights, details, and photos.
            </p>
          </div>

          {errorMsg && (
            <div className="p-3 mb-4 bg-red-950/40 border border-red-500/50 text-red-300 text-xs rounded">
              {errorMsg}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5 text-xs font-sans">
            {/* Commercial Name & Gem Type */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                  Gemstone Name *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Natural Unheated Ruby"
                  className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                />
              </div>

              <div>
                <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                  Gemstone Type *
                </label>

                {addingField === "type" && (
                  <div className="mb-2 p-2.5 bg-[#121218] border border-[#C5A880] rounded-sm space-y-2 animate-fadeIn">
                    <div className="flex items-center justify-between">
                      <span className="text-[9px] font-mono text-[#C5A880] uppercase tracking-wider">
                        Add New Gemstone Type
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setAddingField(null);
                          setCustomAttributeInput("");
                        }}
                        className="text-[#8C867D] hover:text-white text-xs px-1"
                      >
                        ✕
                      </button>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        autoFocus
                        value={customAttributeInput}
                        onChange={(e) => setCustomAttributeInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            handleSaveCustomAttribute("type");
                          } else if (e.key === "Escape") {
                            setAddingField(null);
                            setCustomAttributeInput("");
                          }
                        }}
                        placeholder="e.g. Morganite, Tsavorite, Paraiba..."
                        className="flex-1 p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs focus:outline-none focus:border-[#C5A880]"
                      />
                      <button
                        type="button"
                        onClick={() => handleSaveCustomAttribute("type")}
                        className="px-3 py-2 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors shrink-0"
                      >
                        Add & Select
                      </button>
                    </div>
                  </div>
                )}

                <LuxurySelect
                  variant="dark"
                  value={type}
                  onChange={(val) => {
                    if (val === "__ADD_NEW_TYPE__") {
                      setAddingField("type");
                      setCustomAttributeInput("");
                    } else {
                      setType(val as GemstoneType);
                    }
                  }}
                  onEditOption={(oldVal, newVal) => {
                    const success = editCustomOption("type", oldVal, newVal);
                    if (success) {
                      toast.success("Type Renamed", `"${oldVal}" renamed to "${newVal.trim()}".`);
                      if (type === oldVal) {
                        setType(newVal.trim() as GemstoneType);
                      }
                      return true;
                    } else {
                      toast.error("Duplicate Type", `"${newVal.trim()}" already exists.`);
                      return false;
                    }
                  }}
                  onDeleteOption={(val) => {
                    if (availableTypes.length <= 1) {
                      toast.error("Cannot Delete", "At least one gemstone type must remain.");
                      return false;
                    }
                    const success = deleteCustomOption("type", val);
                    if (success) {
                      toast.success("Type Removed", `"${val}" deleted.`);
                      if (type === val) {
                        const nextType = (availableTypes.find((t) => t !== val) || "Sapphire") as GemstoneType;
                        setType(nextType);
                      }
                      return true;
                    } else {
                      toast.error("Delete Failed", `Could not remove "${val}".`);
                      return false;
                    }
                  }}
                  options={[
                    ...availableTypes,
                    {
                      value: "__ADD_NEW_TYPE__",
                      label: "+ Add New Gemstone Type...",
                      badge: "Add",
                    },
                  ]}
                />
              </div>
            </div>

            {/* Shape & Cut + Colour */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                  Cut & Shape *
                </label>

                {addingField === "cut" && (
                  <div className="mb-2 p-2.5 bg-[#121218] border border-[#C5A880] rounded-sm space-y-2 animate-fadeIn">
                    <div className="flex items-center justify-between">
                      <span className="text-[9px] font-mono text-[#C5A880] uppercase tracking-wider">
                        Add New Cut & Shape
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setAddingField(null);
                          setCustomAttributeInput("");
                        }}
                        className="text-[#8C867D] hover:text-white text-xs px-1"
                      >
                        ✕
                      </button>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        autoFocus
                        value={customAttributeInput}
                        onChange={(e) => setCustomAttributeInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            handleSaveCustomAttribute("cut");
                          } else if (e.key === "Escape") {
                            setAddingField(null);
                            setCustomAttributeInput("");
                          }
                        }}
                        placeholder="e.g. Trilliant, Asscher, Modified Cushion..."
                        className="flex-1 p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs focus:outline-none focus:border-[#C5A880]"
                      />
                      <button
                        type="button"
                        onClick={() => handleSaveCustomAttribute("cut")}
                        className="px-3 py-2 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors shrink-0"
                      >
                        Add & Select
                      </button>
                    </div>
                  </div>
                )}

                <LuxurySelect
                  variant="dark"
                  value={cut}
                  onChange={(val) => {
                    if (val === "__ADD_NEW_CUT__") {
                      setAddingField("cut");
                      setCustomAttributeInput("");
                    } else {
                      setCut(val as GemstoneCut);
                      setCutDetail(`${val} Precision Cut`);
                    }
                  }}
                  options={[
                    ...availableCuts,
                    {
                      value: "__ADD_NEW_CUT__",
                      label: "+ Add New Cut & Shape...",
                      badge: "Add New",
                    },
                  ]}
                />
              </div>

              <div>
                <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                  Color *
                </label>
                <input
                  type="text"
                  required
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  placeholder="e.g. Red, Royal Blue"
                  className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                />
              </div>
            </div>

            {/* Clarity, Treatment & Origin */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                  Clarity *
                </label>

                {addingField === "clarity" && (
                  <div className="mb-2 p-2.5 bg-[#121218] border border-[#C5A880] rounded-sm space-y-2 animate-fadeIn">
                    <div className="flex items-center justify-between">
                      <span className="text-[9px] font-mono text-[#C5A880] uppercase tracking-wider">
                        Add New Clarity Grade
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setAddingField(null);
                          setCustomAttributeInput("");
                        }}
                        className="text-[#8C867D] hover:text-white text-xs px-1"
                      >
                        ✕
                      </button>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        autoFocus
                        value={customAttributeInput}
                        onChange={(e) => setCustomAttributeInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            handleSaveCustomAttribute("clarity");
                          } else if (e.key === "Escape") {
                            setAddingField(null);
                            setCustomAttributeInput("");
                          }
                        }}
                        placeholder="e.g. VS2, SI1, Slightly Included..."
                        className="flex-1 p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs focus:outline-none focus:border-[#C5A880]"
                      />
                      <button
                        type="button"
                        onClick={() => handleSaveCustomAttribute("clarity")}
                        className="px-3 py-2 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors shrink-0"
                      >
                        Add & Select
                      </button>
                    </div>
                  </div>
                )}

                <LuxurySelect
                  variant="dark"
                  value={clarity}
                  onChange={(val) => {
                    if (val === "__ADD_NEW_CLARITY__") {
                      setAddingField("clarity");
                      setCustomAttributeInput("");
                    } else {
                      setClarity(val);
                    }
                  }}
                  options={[
                    ...availableClarities,
                    {
                      value: "__ADD_NEW_CLARITY__",
                      label: "+ Add New Clarity...",
                      badge: "Add New",
                    },
                  ]}
                />
              </div>

              <div>
                <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                  Treatment *
                </label>

                {addingField === "treatment" && (
                  <div className="mb-2 p-2.5 bg-[#121218] border border-[#C5A880] rounded-sm space-y-2 animate-fadeIn">
                    <div className="flex items-center justify-between">
                      <span className="text-[9px] font-mono text-[#C5A880] uppercase tracking-wider">
                        Add New Treatment Type
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setAddingField(null);
                          setCustomAttributeInput("");
                        }}
                        className="text-[#8C867D] hover:text-white text-xs px-1"
                      >
                        ✕
                      </button>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        autoFocus
                        value={customAttributeInput}
                        onChange={(e) => setCustomAttributeInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            handleSaveCustomAttribute("treatment");
                          } else if (e.key === "Escape") {
                            setAddingField(null);
                            setCustomAttributeInput("");
                          }
                        }}
                        placeholder="e.g. Low Temperature Heat, Beryllium, None..."
                        className="flex-1 p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs focus:outline-none focus:border-[#C5A880]"
                      />
                      <button
                        type="button"
                        onClick={() => handleSaveCustomAttribute("treatment")}
                        className="px-3 py-2 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors shrink-0"
                      >
                        Add & Select
                      </button>
                    </div>
                  </div>
                )}

                <LuxurySelect
                  variant="dark"
                  value={treatment}
                  onChange={(val) => {
                    if (val === "__ADD_NEW_TREATMENT__") {
                      setAddingField("treatment");
                      setCustomAttributeInput("");
                    } else {
                      setTreatment(val);
                    }
                  }}
                  options={[
                    ...availableTreatments,
                    {
                      value: "__ADD_NEW_TREATMENT__",
                      label: "+ Add New Treatment...",
                      badge: "Add New",
                    },
                  ]}
                />
              </div>

              <div>
                <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                  Origin (Country / City) *
                </label>
                <input
                  type="text"
                  required
                  value={origin}
                  onChange={(e) => {
                    const val = e.target.value;
                    setOrigin(val);
                    setOriginCountry(extractCountryFromOrigin(val));
                  }}
                  placeholder="e.g. Ratnapura, Sri Lanka or Muzo, Colombia"
                  className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                />
              </div>
            </div>

            {/* CARAT WEIGHT, PRICE, STOCK & SIZE (NO MULTIPLE ADD OPTION) */}
            <div className="border border-[#C5A880]/30 bg-[#171720] p-4 rounded-sm space-y-3">
              <div className="pb-2 border-b border-[#2A2A36]">
                <label className="text-[#C5A880] uppercase text-[11px] font-semibold block">
                  Weight, Price &amp; Stock
                </label>
                <span className="text-[10px] text-[#8C867D]">
                  Enter the gemstone carat weight, price, available stock quantity, and size.
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 p-3 bg-[#121217] border border-[#2A2A36] rounded items-end">
                <div>
                  <label className="block text-[10px] text-[#8C867D] mb-1">
                    Weight (ct) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={caratWeight}
                    onChange={(e) => setCaratWeight(parseFloat(e.target.value) || 0)}
                    placeholder="e.g. 0.55"
                    className="w-full p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-[#8C867D] mb-1">
                    Price (USD $) *
                  </label>
                  <input
                    type="number"
                    required
                    value={price}
                    onChange={(e) => setPrice(parseInt(e.target.value, 10) || 0)}
                    placeholder="e.g. 45000"
                    className="w-full p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs font-mono tabular-nums text-right focus:outline-none focus:border-[#C5A880]"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-[#8C867D] mb-1">
                    Stock Qty *
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={stockQty}
                    onChange={(e) => {
                      const val = parseInt(e.target.value, 10) || 0;
                      setStockQty(val);
                      if (val > 0) setInStock(true);
                      else if (val === 0) setInStock(false);
                    }}
                    placeholder="e.g. 5"
                    className="w-full p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-[#8C867D] mb-1">
                    Size / Dimensions <span className="text-[#6B655C]">(Optional)</span>
                  </label>
                  <input
                    type="text"
                    value={sizeDimensions}
                    onChange={(e) => setSizeDimensions(e.target.value)}
                    placeholder="e.g. 6.6 x 3.4 x 2.1mm (Optional)"
                    className="w-full p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs placeholder:text-[#555]"
                  />
                </div>
              </div>
            </div>

            {/* MULTIPLE SPECIMEN PHOTOGRAPHY (NO ENTER URL) */}
            <div className="space-y-3 border border-[#2A2A36] p-4 bg-[#181820] rounded-sm">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-[#C5A880] uppercase text-[11px] font-semibold block">
                    Gemstone Photos
                  </label>
                  <span className="text-[10px] text-[#8C867D]">
                    Upload photos from your device. The first photo will be the main cover image.
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => photoFileInputRef.current?.click()}
                  className="px-3 py-1 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-[10px] uppercase font-mono font-semibold rounded transition-colors"
                >
                  + Upload Images
                </button>
              </div>

              <input
                ref={photoFileInputRef}
                type="file"
                multiple
                accept="image/jpeg,image/png,image/webp,image/avif"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files.length > 0) {
                    handleMultiFileUpload(e.target.files);
                    e.target.value = "";
                  }
                }}
              />

              {/* Uploaded Photos Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                {uploadedImages.map((imgUrl, idx) => (
                  <div
                    key={idx}
                    className="relative aspect-square bg-[#121217] border border-[#2A2A36] rounded-sm overflow-hidden group"
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={imgUrl}
                      alt={`Specimen ${idx + 1}`}
                      className="w-full h-full object-cover"
                    />

                    {/* Primary Badge */}
                    {idx === 0 && (
                      <span className="absolute top-1.5 left-1.5 bg-[#C5A880] text-[#0D0D11] font-mono text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">
                        Primary
                      </span>
                    )}

                    {/* Action buttons on hover */}
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1.5 p-2">
                      <button
                        type="button"
                        onClick={() => handleOpenCropForIndex(idx)}
                        className="px-2 py-1 bg-[#C5A880] text-[#0D0D11] text-[10px] font-mono rounded font-semibold uppercase hover:bg-white"
                      >
                        Crop
                      </button>
                      <button
                        type="button"
                        onClick={() => handleRemoveImage(idx)}
                        className="px-2 py-1 bg-red-600/80 hover:bg-red-600 text-white text-[10px] font-mono rounded font-semibold uppercase"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                ))}

                {/* Drop/Click to Add Box */}
                <div
                  onClick={() => photoFileInputRef.current?.click()}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                      handleMultiFileUpload(e.dataTransfer.files);
                    }
                  }}
                  className="border-2 border-dashed border-[#343444] hover:border-[#C5A880] bg-[#141419] rounded-sm flex flex-col items-center justify-center p-4 text-center cursor-pointer transition-colors aspect-square"
                >
                  {isUploadingPhoto ? (
                    <div className="space-y-1">
                      <span className="inline-block animate-spin text-base text-[#C5A880]">↻</span>
                      <p className="text-[10px] text-[#C5A880]">Uploading...</p>
                    </div>
                  ) : (
                    <div className="space-y-1 text-xs">
                      <span className="text-xl text-[#C5A880]">+</span>
                      <p className="text-[10px] text-[#8C867D]">Add More Photos</p>
                    </div>
                  )}
                </div>
              </div>

              {photoUploadError && (
                <p className="text-red-400 text-[11px] mt-1">{photoUploadError}</p>
              )}
            </div>

            {/* GEMSTONE SHOWCASE VIDEO (MAX 8s • AUTO-COMPRESSED) */}
            <div className="space-y-3 border border-[#2A2A36] p-4 bg-[#181820] rounded-sm">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-[#C5A880] uppercase text-[11px] font-semibold flex items-center gap-2">
                    <span>Showcase Video (MP4)</span>
                    <span className="text-[9px] px-1.5 py-0.5 bg-[#C5A880]/15 text-[#C5A880] border border-[#C5A880]/30 rounded font-mono">
                      8s Limit • MP4 Supported • Quality Compressed
                    </span>
                  </label>
                  <span className="text-[10px] text-[#8C867D]">
                    Upload an MP4 (or MOV/WEBM) video up to 8 seconds to showcase gemstone luster, optical fire, and brilliance.
                  </span>
                </div>

                {uploadedVideo && (
                  <button
                    type="button"
                    onClick={handleRemoveVideo}
                    className="px-2.5 py-1 bg-red-600/80 hover:bg-red-600 text-white text-[10px] uppercase font-mono rounded transition-colors"
                  >
                    Remove Video
                  </button>
                )}
              </div>

              <input
                ref={videoFileInputRef}
                type="file"
                accept="video/mp4,.mp4,.m4v,video/webm,video/quicktime,.mov,video/*"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleVideoUpload(e.target.files[0]);
                    e.target.value = "";
                  }
                }}
              />

              {!uploadedVideo ? (
                <div
                  onClick={() => !isProcessingVideo && videoFileInputRef.current?.click()}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    if (!isProcessingVideo && e.dataTransfer.files && e.dataTransfer.files[0]) {
                      handleVideoUpload(e.dataTransfer.files[0]);
                    }
                  }}
                  className={`border-2 border-dashed ${
                    isProcessingVideo ? "border-[#C5A880] bg-[#1a1a24]" : "border-[#343444] hover:border-[#C5A880] bg-[#141419]"
                  } rounded-sm p-5 text-center cursor-pointer transition-all`}
                >
                  {isProcessingVideo ? (
                    <div className="space-y-2 py-2">
                      <span className="inline-block animate-spin text-2xl text-[#C5A880]">↻</span>
                      <p className="text-xs text-[#C5A880] font-mono font-medium">
                        {videoProcessingStatus || "Processing showcase video..."}
                      </p>
                      <p className="text-[10px] text-[#8C867D]">
                        Enforcing 8s limit &amp; compressing video quality for instant web streaming
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="w-10 h-10 mx-auto rounded-full bg-[#1C1C24] border border-[#2A2A36] flex items-center justify-center text-[#C5A880] text-lg">
                        ▶
                      </div>
                      <div>
                        <p className="text-xs text-white font-medium">
                          Click or drag MP4 video here to upload
                        </p>
                        <p className="text-[10px] text-[#8C867D] mt-0.5">
                          MP4 fully supported (also WEBM, MOV) • Auto-trimmed to 8s max &amp; compressed
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="relative rounded-sm overflow-hidden bg-black border border-[#2A2A36] p-3 flex flex-col sm:flex-row items-center gap-4">
                  <div className="relative w-full sm:w-48 aspect-video bg-black rounded overflow-hidden flex-shrink-0 border border-white/10">
                    <video
                      key={uploadedVideo}
                      src={uploadedVideo}
                      preload="auto"
                      autoPlay
                      loop
                      muted
                      playsInline
                      controls
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div className="flex-1 space-y-1 text-left">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-400" />
                      <span className="text-xs font-semibold text-white">8s Showcase Video Attached</span>
                    </div>
                    <p className="text-[11px] text-[#8C867D]">
                      Video will appear next to the gallery view on the product detail page and quick view.
                    </p>
                    <div className="pt-2 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => videoFileInputRef.current?.click()}
                        className="px-2.5 py-1 bg-[#2A2A36] hover:bg-[#343444] text-white text-[10px] font-mono rounded transition-colors"
                      >
                        Replace Video
                      </button>
                      <button
                        type="button"
                        onClick={handleRemoveVideo}
                        className="px-2.5 py-1 bg-red-600/20 text-red-400 hover:bg-red-600/30 text-[10px] font-mono rounded transition-colors"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {videoError && (
                <p className="text-red-400 text-[11px] mt-1">{videoError}</p>
              )}
            </div>

            {/* Stock & Featured Toggles */}
            <div className="grid grid-cols-2 gap-4 p-3 bg-[#181820] border border-[#2A2A36] rounded-sm">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={inStock}
                  onChange={(e) => {
                    const checked = e.target.checked;
                    setInStock(checked);
                    if (checked && stockQty <= 0) {
                      setStockQty(1);
                    } else if (!checked) {
                      setStockQty(0);
                    }
                  }}
                  className="w-4 h-4 accent-[#C5A880] rounded"
                />
                <span className="text-white text-xs">Available in Vault (In Stock)</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={featured}
                  onChange={(e) => setFeatured(e.target.checked)}
                  className="w-4 h-4 accent-[#C5A880] rounded"
                />
                <span className="text-[#C5A880] text-xs">Featured on Homepage Showcase</span>
              </label>
            </div>

            {/* Description */}
            <div>
              <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                Description
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
              />
            </div>

            {/* Modal Actions */}
            <div className="pt-4 flex gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-3 border border-[#2A2A36] text-xs text-[#8C867D] hover:text-white uppercase tracking-wider"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting || isUploadingPhoto || isCroppingAndSaving}
                className="flex-1 py-3 bg-[#C5A880] hover:bg-[#E0CFA9] disabled:bg-[#44382B] text-[#0D0D11] text-xs uppercase font-semibold tracking-wider transition-colors btn-luxury-press"
              >
                {isSubmitting
                  ? "Saving Changes..."
                  : "Save Changes"}
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Interactive Sharp Crop Modal for Editing */}
      <ImageCropModal
        isOpen={isCropModalOpen}
        onClose={() => setIsCropModalOpen(false)}
        imageFile={cropFile}
        imageUrl={cropUrl}
        onCropComplete={handleCropAndSave}
        isSaving={isCroppingAndSaving}
      />
    </>,
    document.body
  );
}
