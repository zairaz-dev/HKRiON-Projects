import { NextResponse } from 'next/server';
import { addMessageToConversation, getConversation } from '@/lib/chatStore';
import { transcribeAudio, synthesizeSpeech } from '@/lib/voiceService';

const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY || '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';
const EVOLUTION_API_URL = process.env.EVOLUTION_API_URL || 'http://localhost:8080';
const EVOLUTION_API_KEY = process.env.EVOLUTION_API_KEY || '429683C4C977415CAAFCCE10F7D57E11';

// In-Memory log of recent AI auto-replies
export const aiLogBuffer = [];

export async function POST(req) {
  try {
    const body = await req.json();

    // Check if event is message upsert
    const data = body.data;
    if (!data) {
      return NextResponse.json({ status: 'ignored', reason: 'no data' });
    }

    const remoteJid = data.key?.remoteJid || data.from || data.remoteJid;
    if (!remoteJid || remoteJid.includes('@g.us')) {
      // Ignore group messages by default (only reply to direct messages)
      return NextResponse.json({ status: 'ignored', reason: 'group message' });
    }

    // Safely extract instance name
    let instanceName = 'saas_instance';
    if (typeof body.instance === 'string') {
      instanceName = body.instance;
    } else if (body.instance?.name) {
      instanceName = body.instance.name;
    } else if (body.instance?.instanceName) {
      instanceName = body.instance.instanceName;
    }

    // Check message type
    const isAudio = !!(
      data.message?.audioMessage ||
      data.messageType === 'audioMessage' ||
      data.messageType === 'voiceMessage'
    );

    // Extract incoming text
    let incomingText = 
      data.message?.conversation || 
      data.message?.extendedTextMessage?.text || 
      data.body || '';

    // If neither text nor audio, ignore
    if (!incomingText && !isAudio) {
      return NextResponse.json({ status: 'ignored', reason: 'unsupported message type' });
    }

    // Clean sender phone number
    const senderNumber = remoteJid.replace(/@s\.whatsapp\.net/, '').replace(/[^0-9]/g, '');
    const pushName = data.pushName || null;

    // Capture messages sent by ourselves directly on WhatsApp mobile phone
    const isFromMe = data.key?.fromMe || data.fromMe;
    if (isFromMe) {
      if (incomingText) {
        addMessageToConversation({
          senderNumber,
          senderName: pushName,
          text: incomingText,
          fromMe: true,
          isAi: false,
          status: 'sent',
        });
      }
      return NextResponse.json({ status: 'saved_outgoing_from_phone', sender: senderNumber });
    }

    const conv = getConversation(senderNumber);
    if (conv && conv.aiEnabled === false) {
      console.log(`[AI Auto-Reply] Skipped for ${senderNumber} (AI paused for this chat)`);
      if (incomingText) {
        addMessageToConversation({
          senderNumber,
          senderName: pushName,
          text: incomingText,
          fromMe: false,
          isAi: false,
          status: 'received',
        });
      }
      return NextResponse.json({ status: 'saved_human_mode', sender: senderNumber });
    }

    console.log(`[AI Auto-Reply] Queued for ${senderNumber} (Instance: ${instanceName}, isAudio: ${isAudio})`);

    // Process AI generation and message sending asynchronously in background so Webhook returns 200 OK immediately
    processAutoReplyAsync({
      senderNumber,
      pushName,
      initialText: incomingText,
      isAudio,
      messageData: data,
      instanceName,
    }).catch((err) => {
      console.error('[AI Auto-Reply Background Error]:', err);
    });

    // Return immediate HTTP 200 to Evolution API so it never times out
    return NextResponse.json({
      status: 'queued',
      sender: senderNumber,
      isAudio,
    });
  } catch (err) {
    console.error('[AI Auto-Reply Exception]:', err);
    return NextResponse.json({ status: 'error', message: err.message }, { status: 500 });
  }
}

async function processAutoReplyAsync({
  senderNumber,
  pushName,
  initialText,
  isAudio,
  messageData,
  instanceName,
}) {
  // Read dynamic AI config if available
  let openRouterKey = OPENROUTER_API_KEY;
  let selectedModel = 'meta-llama/llama-3.3-70b-instruct';
  let systemPrompt = 'You are an intelligent WhatsApp AI Assistant. Respond in a friendly, helpful, and concise manner. Keep replies short (1-3 sentences max).';
  let voiceEnabled = true;
  let voiceReplyMode = 'match_incoming'; // 'match_incoming' | 'always_voice' | 'always_text'
  let sttProvider = 'openrouter_gemini';
  let ttsProvider = 'free_google';
  let ttsVoice = 'nova';
  let geminiApiKey = '';
  let groqApiKey = process.env.GROQ_API_KEY || '';
  let openAiApiKey = process.env.OPENAI_API_KEY || '';

  try {
    const fs = await import('fs');
    const path = await import('path');
    const configFile = path.join(process.cwd(), 'data', 'ai_config.json');
    if (fs.existsSync(configFile)) {
      const savedConfig = JSON.parse(fs.readFileSync(configFile, 'utf-8'));
      if (savedConfig.apiKey) openRouterKey = savedConfig.apiKey;
      if (savedConfig.model) selectedModel = savedConfig.model;
      if (savedConfig.systemPrompt) systemPrompt = savedConfig.systemPrompt;
      if (savedConfig.voiceEnabled !== undefined) voiceEnabled = savedConfig.voiceEnabled;
      if (savedConfig.voiceReplyMode) voiceReplyMode = savedConfig.voiceReplyMode;
      if (savedConfig.sttProvider) sttProvider = savedConfig.sttProvider;
      if (savedConfig.ttsProvider) ttsProvider = savedConfig.ttsProvider;
      if (savedConfig.ttsVoice) ttsVoice = savedConfig.ttsVoice;
      if (savedConfig.geminiApiKey) geminiApiKey = savedConfig.geminiApiKey;
      if (savedConfig.groqApiKey) groqApiKey = savedConfig.groqApiKey;
      if (savedConfig.openAiApiKey) openAiApiKey = savedConfig.openAiApiKey;
    }
  } catch (err) {
    console.error('[AI Auto-Reply] Failed to load ai_config.json:', err.message);
  }

  let incomingText = initialText;

  // 1. If Audio message, transcribe it using Speech-to-Text (STT)
  if (isAudio) {
    try {
      console.log(`[AI Voice-STT] Processing incoming audio from ${senderNumber}...`);
      let audioBase64 = messageData.base64 || messageData.message?.base64 || messageData.message?.audioMessage?.base64;
      let mimeType = messageData.message?.audioMessage?.mimetype || 'audio/ogg; codecs=opus';

      if (!audioBase64) {
        // Fetch media base64 from Evolution API
        const mediaRes = await fetch(`${EVOLUTION_API_URL}/chat/getBase64FromMediaMessage/${instanceName}`, {
          method: 'POST',
          headers: {
            'apikey': EVOLUTION_API_KEY,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: messageData,
            convertToMp4: false,
          }),
        });

        if (mediaRes.ok) {
          const mediaJson = await mediaRes.json();
          audioBase64 = mediaJson.base64;
          if (mediaJson.mimetype) mimeType = mediaJson.mimetype;
        }
      }

      if (audioBase64) {
        // Determine STT key & provider
        let chosenKey = '';
        let chosenProvider = sttProvider;

        if (sttProvider === 'groq' && groqApiKey) {
          chosenKey = groqApiKey;
        } else if (sttProvider === 'gemini_studio' && geminiApiKey) {
          chosenKey = geminiApiKey;
          chosenProvider = 'gemini';
        } else if (sttProvider === 'openai' && openAiApiKey) {
          chosenKey = openAiApiKey;
        } else {
          // Default: OpenRouter Gemini multimodal (Free with existing OpenRouter key)
          chosenProvider = 'openrouter_gemini';
          chosenKey = openRouterKey;
        }

        const transcribed = await transcribeAudio({
          audioBase64,
          mimeType,
          apiKey: chosenKey,
          provider: chosenProvider,
          openRouterKey: openRouterKey,
        });

        if (transcribed && transcribed.trim()) {
          incomingText = transcribed.trim();
          console.log(`[AI Voice-STT] Transcribed Audio Successfully: "${incomingText}"`);
        }
      }
    } catch (sttErr) {
      console.error('[AI Voice-STT] Transcription error:', sttErr.message);
      if (!incomingText) incomingText = 'Voice Message (Audio)';
    }
  }

  if (!incomingText || !incomingText.trim()) {
    console.warn(`[AI Auto-Reply] Empty message content for ${senderNumber}`);
    return;
  }

  // Save incoming message to ChatStore
  addMessageToConversation({
    senderNumber,
    senderName: pushName,
    text: isAudio ? `🎤 ${incomingText}` : incomingText,
    fromMe: false,
    isAi: false,
    status: 'received',
  });

  // 2. Generate AI Reply using OpenRouter LLM
  let replyText = null;
  const modelsToTry = [selectedModel, 'google/gemini-flash-1.5', 'openai/gpt-4o-mini'];
  
  for (const modelCandidate of modelsToTry) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 12000); // 12s timeout per model

      const aiRes = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${openRouterKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: modelCandidate,
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: incomingText }
          ],
          max_tokens: 300,
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (aiRes.ok) {
        const aiData = await aiRes.json();
        replyText = aiData.choices?.[0]?.message?.content?.trim();
        if (replyText) {
          console.log(`[AI Auto-Reply] Reply generated using model: ${modelCandidate}`);
          break;
        }
      }
    } catch (err) {
      console.warn(`[AI Auto-Reply] Model ${modelCandidate} failed/timed out:`, err.message);
    }
  }

  if (!replyText) {
    console.error(`[AI Auto-Reply] All AI models failed for ${senderNumber}`);
    return;
  }

  console.log(`[AI Auto-Reply] Generated Reply for ${senderNumber}: "${replyText}"`);

  // 3. Determine if we should reply with Voice Note (TTS)
  const shouldReplyVoice = 
    voiceEnabled && 
    (voiceReplyMode === 'always_voice' || (voiceReplyMode === 'match_incoming' && isAudio));

  let voiceSentSuccess = false;

  if (shouldReplyVoice) {
    try {
      console.log(`[AI Voice-TTS] Generating speech audio using provider: ${ttsProvider}...`);
      const voiceAudioData = await synthesizeSpeech({
        text: replyText,
        apiKey: ttsProvider === 'openai' ? openAiApiKey : '',
        voice: ttsVoice,
        provider: ttsProvider,
      });

      const cleanAudioData = typeof voiceAudioData === 'string'
        ? voiceAudioData.replace(/^data:audio\/[a-zA-Z0-9\-_]+;base64,/, '')
        : voiceAudioData;

      // Send Voice Note via Evolution API
      const voiceRes = await fetch(`${EVOLUTION_API_URL}/message/sendWhatsAppAudio/${instanceName}`, {
        method: 'POST',
        headers: {
          'apikey': EVOLUTION_API_KEY,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          number: senderNumber,
          audio: cleanAudioData,
          encoding: true,
          ptt: true, // Send as native WhatsApp Voice Note
        }),
      });

      if (voiceRes.ok) {
        voiceSentSuccess = true;
        console.log(`[AI Voice-TTS] Successfully sent WhatsApp Voice Note to ${senderNumber}`);
      } else {
        const voiceErr = await voiceRes.text();
        console.warn('[AI Voice-TTS] Failed to send WhatsApp audio, falling back to text:', voiceErr);
      }
    } catch (ttsErr) {
      console.error('[AI Voice-TTS] Speech synthesis error:', ttsErr.message);
    }
  }

  // 4. If voice was not requested or failed, send Text Reply via Evolution API
  let isSuccess = voiceSentSuccess;
  if (!voiceSentSuccess) {
    let attempts = 0;
    const maxAttempts = 3;

    while (attempts < maxAttempts && !isSuccess) {
      attempts++;
      try {
        const sendRes = await fetch(`${EVOLUTION_API_URL}/message/sendText/${instanceName}`, {
          method: 'POST',
          headers: {
            'apikey': EVOLUTION_API_KEY,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            number: senderNumber,
            text: replyText,
          }),
        });

        if (sendRes.ok) {
          isSuccess = true;
          console.log(`[AI Auto-Reply] Successfully sent WhatsApp message to ${senderNumber} (Attempt ${attempts})`);
        } else {
          const errBody = await sendRes.text();
          console.warn(`[AI Auto-Reply] Evolution API Send Attempt ${attempts} failed (${sendRes.status}):`, errBody);
          if (attempts < maxAttempts) {
            await new Promise((r) => setTimeout(r, 1500));
          }
        }
      } catch (err) {
        console.warn(`[AI Auto-Reply] Send Exception (Attempt ${attempts}):`, err.message);
        if (attempts < maxAttempts) {
          await new Promise((r) => setTimeout(r, 1500));
        }
      }
    }
  }

  // Save AI response to chat store
  if (replyText) {
    addMessageToConversation({
      senderNumber,
      text: voiceSentSuccess ? `🎙️ [Voice Note] ${replyText}` : replyText,
      fromMe: true,
      isAi: true,
      status: isSuccess ? 'sent' : 'failed',
    });
  }

  const logEntry = {
    timestamp: new Date().toLocaleTimeString(),
    sender: senderNumber,
    incomingText: isAudio ? `🎤 ${incomingText}` : incomingText,
    replyText: voiceSentSuccess ? `🎙️ (Voice Note) ${replyText}` : replyText,
    type: voiceSentSuccess ? 'Voice Note' : 'Text',
    status: isSuccess ? 'Sent' : 'Failed',
  };
  aiLogBuffer.unshift(logEntry);
  if (aiLogBuffer.length > 50) aiLogBuffer.pop();
}

export async function GET() {
  return NextResponse.json({
    status: 'active',
    logs: aiLogBuffer,
  });
}
