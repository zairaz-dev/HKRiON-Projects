/**
 * Promotional codes and discounts configuration.
 */

export interface PromoDiscount {
  rate: number;       // e.g. 0.05 for 5%
  label: string;      // e.g. "5% Private Client Privilege"
  description: string;
}

export const PROMO_CODES: Record<string, PromoDiscount> = {
  FAIZAN5: {
    rate: 0.05,
    label: "5% Faizan Gems Privilege",
    description: "5% discount on curated natural gemstones",
  },
  VAULT: {
    rate: 0.05,
    label: "5% Vault Acquisition Privilege",
    description: "5% discount for collector vault acquisitions",
  },
  MAISON5: {
    rate: 0.05,
    label: "5% Heritage Client Privilege",
    description: "5% legacy discount",
  },
};

/**
 * Checks if a given string is an active promo code.
 */
export function getPromoDiscount(code: string): PromoDiscount | null {
  if (!code) return null;
  const normalized = code.trim().toUpperCase();
  return PROMO_CODES[normalized] || null;
}

export function isValidPromoCode(code: string): boolean {
  return getPromoDiscount(code) !== null;
}
