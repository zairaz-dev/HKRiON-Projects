"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Role, TaskHealth, TaskPriority, TaskStatus } from "@prisma/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Modal } from "@/components/ui/modal";
import { 
  DropdownMenu, 
  DropdownMenuTrigger, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator 
} from "@/components/ui/dropdown-menu";
import { Tooltip } from "@/components/ui/tooltip";
import { 
  Loader2, 
  PlayCircle, 
  AlertTriangle, 
  AlertCircle, 
  CheckCircle2,
  Calendar, 
  Clock, 
  Send, 
  MessageSquare, 
  AlignLeft, 
  ArrowLeft, 
  MoreHorizontal, 
  FileText, 
  Check,
  Plus,
  Trash2,
  Share2,
  ShieldAlert,
  ChevronRight,
  Flame,
  Flag,
  User,
  Users,
  Copy,
  CheckCheck,
  ShieldCheck,
  Sparkles,
  Info,
  ListTodo,
  ArrowUpRight,
  RotateCcw
} from "lucide-react";
import Link from "next/link";
import { toast } from "sonner";
import { formatDistanceToNow, format, isPast, isToday, differenceInDays } from "date-fns";
import { postTaskUpdate, toggleMilestone, updateTaskHealth, addMilestone } from "@/actions/taskUpdates";
import { deleteTask, startTask, submitTaskForReview, reviewTask, updateTaskStatus } from "@/actions/tasks";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

export interface UserMeta {
  id: number;
  firstName: string;
  lastName: string;
  email?: string | null;
  role: Role;
  profileImage?: string | null;
  position?: { title: string } | null;
}

export interface MilestoneMeta {
  id: number;
  title: string;
  completed: boolean;
  dueDate?: Date | null;
}

export interface DependencyMeta {
  id: number;
  title: string;
  category?: string | null;
  health: TaskHealth;
  progress?: number | null;
}

export interface UpdateMeta {
  id: number;
  authorId: number;
  type: "PROGRESS" | "COMMENT" | "BLOCKER" | "SYSTEM";
  content: string;
  progressSnapshot?: number | null;
  healthSnapshot?: TaskHealth | null;
  createdAt: Date | string;
  author: UserMeta;
}

export interface TaskData {
  id: number;
  title: string;
  description?: string | null;
  deliverables?: string | null;
  instructions?: string | null;
  category?: string | null;
  status: TaskStatus;
  health: TaskHealth;
  priority: TaskPriority;
  progress: number;
  startDate?: Date | string | null;
  dueDate?: Date | string | null;
  deadline?: Date | string | null;
  reviewNotes?: string | null;
  submittedAt?: Date | string | null;
  reviewedAt?: Date | string | null;
  completedAt?: Date | string | null;
  assignerId: number;
  assigner: UserMeta;
  assignees: UserMeta[];
  milestones: MilestoneMeta[];
  dependencies: DependencyMeta[];
  updates: UpdateMeta[];
  createdAt: Date | string;
  updatedAt: Date | string;
}

interface TaskWorkspaceProps {
  task: TaskData;
  currentUserId: number;
  currentUserRole: Role;
}

const statusConfig: Record<TaskStatus, { label: string; badgeVariant: "default" | "secondary" | "success" | "warning" | "error"; color: string; bg: string; border: string }> = {
  PENDING: { label: "Pending", badgeVariant: "warning", color: "text-amber-600 dark:text-amber-400", bg: "bg-amber-500/10", border: "border-amber-500/20" },
  IN_PROGRESS: { label: "In Progress", badgeVariant: "default", color: "text-blue-600 dark:text-blue-400", bg: "bg-blue-500/10", border: "border-blue-500/20" },
  SUBMITTED: { label: "Submitted", badgeVariant: "secondary", color: "text-purple-600 dark:text-purple-400", bg: "bg-purple-500/10", border: "border-purple-500/20" },
  UNDER_REVIEW: { label: "Under Review", badgeVariant: "secondary", color: "text-indigo-600 dark:text-indigo-400", bg: "bg-indigo-500/10", border: "border-indigo-500/20" },
  COMPLETED: { label: "Completed", badgeVariant: "success", color: "text-emerald-600 dark:text-emerald-400", bg: "bg-emerald-500/10", border: "border-emerald-500/20" },
  ON_HOLD: { label: "On Hold", badgeVariant: "secondary", color: "text-slate-500", bg: "bg-slate-500/10", border: "border-slate-500/20" },
  CANCELLED: { label: "Cancelled", badgeVariant: "secondary", color: "text-slate-400", bg: "bg-slate-400/10", border: "border-slate-400/20" },
  OVERDUE: { label: "Overdue", badgeVariant: "error", color: "text-rose-600 dark:text-rose-400", bg: "bg-rose-500/10", border: "border-rose-500/20" },
  REJECTED: { label: "Revisions Needed", badgeVariant: "error", color: "text-rose-600 dark:text-rose-400", bg: "bg-rose-500/10", border: "border-rose-500/20" },
};

const healthConfig: Record<TaskHealth, { icon: React.ReactNode; color: string; bg: string; border: string; label: string }> = {
  NOT_STARTED: { icon: <Loader2 className="h-3.5 w-3.5" />, color: "text-slate-500", bg: "bg-slate-500/10", border: "border-slate-500/20", label: "Not Started" },
  ON_TRACK: { icon: <PlayCircle className="h-3.5 w-3.5 text-emerald-500" />, color: "text-emerald-600 dark:text-emerald-400", bg: "bg-emerald-500/10", border: "border-emerald-500/20", label: "On Track" },
  AT_RISK: { icon: <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />, color: "text-amber-600 dark:text-amber-400", bg: "bg-amber-500/10", border: "border-amber-500/20", label: "At Risk" },
  BLOCKED: { icon: <AlertCircle className="h-3.5 w-3.5 text-rose-500" />, color: "text-rose-600 dark:text-rose-400", bg: "bg-rose-500/10", border: "border-rose-500/20", label: "Blocked" },
  WAITING_REVIEW: { icon: <CheckCircle2 className="h-3.5 w-3.5 text-blue-500" />, color: "text-blue-600 dark:text-blue-400", bg: "bg-blue-500/10", border: "border-blue-500/20", label: "Needs Review" },
};

const priorityConfig: Record<TaskPriority, { icon: any; label: string; color: string; bg: string; border: string; dotColor: string }> = {
  LOW: { icon: Flag, label: "Low Priority", color: "text-emerald-600 dark:text-emerald-400", bg: "bg-emerald-500/10", border: "border-emerald-500/20", dotColor: "bg-emerald-500" },
  MEDIUM: { icon: Clock, label: "Medium Priority", color: "text-primary dark:text-primary-hover", bg: "bg-primary-soft", border: "border-primary/30", dotColor: "bg-primary" },
  HIGH: { icon: AlertTriangle, label: "High Priority", color: "text-amber-600 dark:text-amber-400", bg: "bg-amber-500/10", border: "border-amber-500/20", dotColor: "bg-amber-500" },
  URGENT: { icon: Flame, label: "Urgent Priority", color: "text-rose-600 dark:text-rose-400", bg: "bg-rose-500/10", border: "border-rose-500/20", dotColor: "bg-rose-500" },
};

const updateTypeConfig = {
  PROGRESS: { icon: <PlayCircle className="h-4 w-4 text-emerald-500" />, label: "Progress Report", badgeColor: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20" },
  COMMENT: { icon: <MessageSquare className="h-4 w-4 text-primary" />, label: "Comment", badgeColor: "bg-primary-soft text-primary border-primary/20" },
  BLOCKER: { icon: <AlertCircle className="h-4 w-4 text-rose-500" />, label: "Blocker Reported", badgeColor: "bg-rose-500/10 text-rose-600 border-rose-500/20" },
  SYSTEM: { icon: <Loader2 className="h-4 w-4 text-slate-500" />, label: "System Activity", badgeColor: "bg-surface-secondary text-text-muted border-border" },
};

export default function TaskWorkspaceClient({ task, currentUserId, currentUserRole }: TaskWorkspaceProps) {
  const router = useRouter();
  
  // Workspace Tab State
  const [mainTab, setMainTab] = useState<"overview" | "milestones" | "activity">("overview");

  // Lifecycle Action States
  const [isStarting, setIsStarting] = useState(false);
  
  // Submit for Review Modal
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);
  const [submissionNotes, setSubmissionNotes] = useState("");
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);

  // Review (Approve/Reject) Modal
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [reviewNotesInput, setReviewNotesInput] = useState("");
  const [isReviewing, setIsReviewing] = useState(false);

  // Activity Composer State
  const [isUpdating, setIsUpdating] = useState(false);
  const [updateType, setUpdateType] = useState<"PROGRESS" | "COMMENT" | "BLOCKER">("PROGRESS");
  const [content, setContent] = useState("");
  const [completedWork, setCompletedWork] = useState("");
  const [pendingWork, setPendingWork] = useState("");
  const [progress, setProgress] = useState(task.progress);

  // New milestone inline input
  const [newMilestoneText, setNewMilestoneText] = useState("");
  const [isAddingMilestone, setIsAddingMilestone] = useState(false);
  
  // Delete modal
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const currentStatus = statusConfig[task.status] || statusConfig.PENDING;
  const currentHealth = healthConfig[task.health] || healthConfig.NOT_STARTED;
  const currentPriority = priorityConfig[task.priority] || priorityConfig.MEDIUM;

  const isAssignee = task.assignees.some((a) => a.id === currentUserId);
  const isAssigner = task.assignerId === currentUserId;
  const isManagerOrAdmin = currentUserRole === Role.MANAGER || currentUserRole === Role.SUPER_ADMIN;
  const canEdit = isAssignee || isManagerOrAdmin || isAssigner;
  const canDelete = isManagerOrAdmin || isAssigner;

  const completedMilestonesCount = task.milestones.filter((m) => m.completed).length;
  const totalMilestonesCount = task.milestones.length;
  const milestoneCompletionPct = totalMilestonesCount > 0 
    ? Math.round((completedMilestonesCount / totalMilestonesCount) * 100) 
    : 0;

  const isOverdue = task.dueDate && isPast(new Date(task.dueDate)) && !isToday(new Date(task.dueDate)) && task.status !== TaskStatus.COMPLETED && task.status !== TaskStatus.CANCELLED;
  const isDueToday = task.dueDate && isToday(new Date(task.dueDate));

  const getInitials = (first: string, last: string) => {
    return `${first?.charAt(0) || ""}${last?.charAt(0) || ""}`.toUpperCase();
  };

  const copyTaskLink = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success("Task workspace link copied to clipboard!");
  };

  // 1. Action: Start Task (Pending -> In Progress)
  const handleStartTask = async () => {
    setIsStarting(true);
    const res = await startTask(task.id);
    if (res.error) toast.error(res.error);
    else {
      toast.success("Task started! Status changed to IN PROGRESS.");
      router.refresh();
    }
    setIsStarting(false);
  };

  // 2. Action: Submit for Review (In Progress -> Under Review)
  const handleSubmitForReview = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmittingReview(true);
    const res = await submitTaskForReview(task.id, submissionNotes);
    if (res.error) {
      toast.error(res.error);
    } else {
      toast.success("Task deliverables submitted for manager review!");
      setIsSubmitModalOpen(false);
      setSubmissionNotes("");
      router.refresh();
    }
    setIsSubmittingReview(false);
  };

  // 3. Action: Manager Review (Approve or Reject)
  const handleReviewDecision = async (action: "APPROVE" | "REJECT") => {
    setIsReviewing(true);
    const formData = new FormData();
    formData.append("action", action);
    formData.append("reviewNotes", reviewNotesInput);

    const res = await reviewTask(task.id, formData);
    if (res.error) {
      toast.error(res.error);
    } else {
      if (action === "APPROVE") toast.success("Task approved and marked as COMPLETED! 🎉");
      else toast.success("Revision requested. Task returned to assignee.");
      setIsReviewModalOpen(false);
      setReviewNotesInput("");
      router.refresh();
    }
    setIsReviewing(false);
  };

  // 4. Action: Update Health
  const handleHealthChange = async (newHealth: TaskHealth) => {
    if (!canEdit) return;
    const formData = new FormData();
    formData.append("health", newHealth);
    formData.append("progress", progress.toString());
    const res = await updateTaskHealth(task.id, formData);
    if (res.error) toast.error(res.error);
    else {
      toast.success(`Task status updated to ${newHealth.replace("_", " ")}`);
      router.refresh();
    }
  };

  // 5. Action: Post Update Note
  const handlePostUpdate = async (e: React.FormEvent) => {
    e.preventDefault();

    let finalContent = content;
    if (updateType === "PROGRESS") {
      if (!completedWork.trim() && !pendingWork.trim()) {
        toast.error("Please provide details for completed work or pending next steps.");
        return;
      }
      finalContent = `**Completed Deliverables:**\n${completedWork.trim() || "None reported."}\n\n**Next Steps:**\n${pendingWork.trim() || "None reported."}`;
    } else {
      if (!content.trim()) {
        toast.error("Please enter your message or blocker description.");
        return;
      }
    }

    setIsUpdating(true);
    const formData = new FormData();
    formData.append("type", updateType);
    formData.append("content", finalContent);
    formData.append("progress", progress.toString());

    if (updateType === "BLOCKER") {
      formData.append("health", "BLOCKED");
    } else if (updateType === "PROGRESS" && progress === 100) {
      formData.append("health", "WAITING_REVIEW");
    } else if (updateType === "PROGRESS" && task.health === "NOT_STARTED") {
      formData.append("health", "ON_TRACK");
    }

    const result = await postTaskUpdate(task.id, formData);
    if (result.error) {
      toast.error(result.error);
    } else {
      toast.success("Workspace update posted successfully!");
      setContent("");
      setCompletedWork("");
      setPendingWork("");
      router.refresh();
    }
    setIsUpdating(false);
  };

  // 6. Action: Toggle Milestone
  const handleMilestoneToggle = async (id: number, completed: boolean) => {
    if (!canEdit) return;
    const result = await toggleMilestone(id, completed, task.id);
    if (result.error) toast.error(result.error);
    else router.refresh();
  };

  // 7. Action: Add Milestone
  const handleAddMilestone = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMilestoneText.trim()) return;
    setIsAddingMilestone(true);
    const res = await addMilestone(task.id, newMilestoneText.trim());
    if (res.error) toast.error(res.error);
    else {
      toast.success("Checkpoint milestone added!");
      setNewMilestoneText("");
      router.refresh();
    }
    setIsAddingMilestone(false);
  };

  // 8. Action: Delete Task
  const handleDeleteTask = async () => {
    setIsDeleting(true);
    const res = await deleteTask(task.id);
    if (res.error) {
      toast.error(res.error);
      setIsDeleting(false);
    } else {
      toast.success("Task deleted successfully");
      router.push("/dashboard/tasks");
    }
  };

  const PriorityIcon = currentPriority.icon;

  return (
    <div className="space-y-6">
      
      {/* 1. TOP BREADCRUMB & HEADER BAR */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-border pb-4">
        


        {/* Top Actions */}
        <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
          
          {/* Status Badge */}
          <span className={cn(
            "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold uppercase tracking-wider border shadow-2xs",
            currentStatus.bg, currentStatus.color, currentStatus.border
          )}>
            <span className="h-1.5 w-1.5 rounded-full bg-current" />
            <span>{currentStatus.label}</span>
          </span>

          {/* Quick Health Selector (if allowed) */}
          {canEdit && (
            <DropdownMenu>
              <DropdownMenuTrigger className={cn(
                "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold uppercase tracking-wider border transition-all cursor-pointer shadow-2xs",
                currentHealth.bg, currentHealth.color, currentHealth.border
              )}>
                {currentHealth.icon}
                <span>{currentHealth.label}</span>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" width={200}>
                <DropdownMenuLabel>Update Health Status</DropdownMenuLabel>
                <DropdownMenuItem 
                  icon={<PlayCircle className="h-3.5 w-3.5 text-emerald-500" />}
                  onClick={() => handleHealthChange("ON_TRACK")}
                >
                  On Track
                </DropdownMenuItem>
                <DropdownMenuItem 
                  icon={<AlertTriangle className="h-3.5 w-3.5 text-amber-500" />}
                  onClick={() => handleHealthChange("AT_RISK")}
                >
                  At Risk
                </DropdownMenuItem>
                <DropdownMenuItem 
                  icon={<AlertCircle className="h-3.5 w-3.5 text-rose-500" />}
                  onClick={() => handleHealthChange("BLOCKED")}
                >
                  Blocked
                </DropdownMenuItem>
                <DropdownMenuItem 
                  icon={<CheckCircle2 className="h-3.5 w-3.5 text-blue-500" />}
                  onClick={() => handleHealthChange("WAITING_REVIEW")}
                >
                  Needs Review
                </DropdownMenuItem>
                <DropdownMenuItem 
                  icon={<Loader2 className="h-3.5 w-3.5 text-slate-500" />}
                  onClick={() => handleHealthChange("NOT_STARTED")}
                >
                  Not Started
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}

          {/* Share Link Button */}
          <Button 
            type="button" 
            variant="outline" 
            size="sm" 
            onClick={copyTaskLink}
            className="h-8 px-2.5 text-xs gap-1.5 shadow-2xs cursor-pointer"
          >
            <Share2 className="h-3.5 w-3.5 text-text-secondary" />
            <span className="hidden sm:inline">Share</span>
          </Button>

          {/* More Actions Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger className="p-1.5 h-8 w-8 rounded-xl border border-border bg-surface hover:bg-surface-secondary text-text-secondary hover:text-text-primary transition-colors inline-flex items-center justify-center shadow-2xs cursor-pointer">
              <MoreHorizontal className="h-4 w-4" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" width={180}>
              <DropdownMenuItem icon={<Copy className="h-3.5 w-3.5" />} onClick={copyTaskLink}>
                Copy Task Link
              </DropdownMenuItem>
              {canDelete && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    variant="destructive"
                    icon={<Trash2 className="h-3.5 w-3.5" />}
                    onClick={() => setIsDeleteModalOpen(true)}
                  >
                    Delete Task
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* 2. TASK LIFECYCLE PROGRESS PIPELINE BANNER */}
      <div className="p-3 sm:p-4 rounded-2xl border border-border bg-surface shadow-2xs overflow-hidden">
        <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1 sm:pb-0">
          
          {/* Step 1: Pending */}
          <div className={cn(
            "flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition-all",
            task.status === TaskStatus.PENDING 
              ? "bg-amber-500/10 text-amber-600 border border-amber-500/30" 
              : "text-text-muted"
          )}>
            <span className={cn(
              "w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold",
              task.status === TaskStatus.PENDING ? "bg-amber-500 text-white" : "bg-surface-secondary text-text-disabled"
            )}>1</span>
            <span>Assigned</span>
          </div>

          <ChevronRight className="h-3.5 w-3.5 text-text-disabled shrink-0" />

          {/* Step 2: In Progress */}
          <div className={cn(
            "flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition-all",
            task.status === TaskStatus.IN_PROGRESS || task.status === TaskStatus.REJECTED
              ? "bg-blue-500/10 text-blue-600 border border-blue-500/30" 
              : "text-text-muted"
          )}>
            <span className={cn(
              "w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold",
              task.status === TaskStatus.IN_PROGRESS ? "bg-blue-500 text-white" : "bg-surface-secondary text-text-disabled"
            )}>2</span>
            <span>In Progress</span>
          </div>

          <ChevronRight className="h-3.5 w-3.5 text-text-disabled shrink-0" />

          {/* Step 3: Under Review */}
          <div className={cn(
            "flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition-all",
            task.status === TaskStatus.UNDER_REVIEW || task.status === TaskStatus.SUBMITTED
              ? "bg-purple-500/10 text-purple-600 border border-purple-500/30" 
              : "text-text-muted"
          )}>
            <span className={cn(
              "w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold",
              task.status === TaskStatus.UNDER_REVIEW || task.status === TaskStatus.SUBMITTED ? "bg-purple-500 text-white" : "bg-surface-secondary text-text-disabled"
            )}>3</span>
            <span>Submitted & Review</span>
          </div>

          <ChevronRight className="h-3.5 w-3.5 text-text-disabled shrink-0" />

          {/* Step 4: Completed */}
          <div className={cn(
            "flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition-all",
            task.status === TaskStatus.COMPLETED 
              ? "bg-emerald-500/10 text-emerald-600 border border-emerald-500/30" 
              : "text-text-muted"
          )}>
            <span className={cn(
              "w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold",
              task.status === TaskStatus.COMPLETED ? "bg-emerald-500 text-white" : "bg-surface-secondary text-text-disabled"
            )}>
              <Check className="h-3 w-3" />
            </span>
            <span>Completed</span>
          </div>

        </div>
      </div>

      {/* 3. REVISION FEEDBACK BANNER (IF REJECTED) */}
      {task.status === TaskStatus.REJECTED && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-700 dark:text-rose-300 space-y-2 animate-in fade-in">
          <div className="flex items-center gap-2 font-bold text-xs sm:text-sm">
            <AlertTriangle className="h-4 w-4 text-rose-500" />
            <span>Revisions Requested by Manager</span>
          </div>
          <p className="text-xs sm:text-sm leading-relaxed pl-6">
            {task.reviewNotes || "Please review the deliverables and incorporate requested changes before resubmitting."}
          </p>
        </div>
      )}

      {/* 4. MANAGER REVIEW ACTION CALLOUT (IF UNDER REVIEW & MANAGER) */}
      {(task.status === TaskStatus.UNDER_REVIEW || task.status === TaskStatus.SUBMITTED) && isManagerOrAdmin && (
        <div className="p-5 rounded-2xl bg-gradient-to-r from-purple-500/10 via-primary-soft/30 to-purple-500/10 border border-purple-500/30 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-purple-500/20 text-purple-600 font-bold">
                <CheckCheck className="h-4 w-4" />
              </span>
              <h3 className="text-sm font-bold text-text-primary">Deliverables Ready for Your Review</h3>
            </div>
            <p className="text-xs text-text-secondary pl-8">
              The assigned engineer has completed this task and submitted it for formal sign-off.
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0 pl-8 sm:pl-0">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => {
                setIsReviewModalOpen(true);
                setReviewNotesInput("");
              }}
              className="border-rose-500/30 text-rose-600 hover:bg-rose-500/10 text-xs font-semibold cursor-pointer"
            >
              <AlertTriangle className="h-3.5 w-3.5" />
              <span>Request Revisions</span>
            </Button>
            <Button
              type="button"
              size="sm"
              onClick={() => handleReviewDecision("APPROVE")}
              disabled={isReviewing}
              className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer shadow-sm"
            >
              {isReviewing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
              <span>Approve & Mark Complete</span>
            </Button>
          </div>
        </div>
      )}

      {/* 5. HERO OVERVIEW CARD */}
      <Card className="border-border bg-surface shadow-xs overflow-hidden">
        <CardContent className="p-5 sm:p-7 space-y-6">
          
          {/* Top Badges Strip */}
          <div className="flex flex-wrap items-center gap-2">
            {task.category && (
              <Badge variant="default" className="text-xs font-semibold">
                {task.category}
              </Badge>
            )}

            <span className={cn(
              "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg text-xs font-semibold border",
              currentPriority.bg, currentPriority.color, currentPriority.border
            )}>
              <PriorityIcon className="h-3 w-3" />
              {currentPriority.label}
            </span>

            <span className="text-xs font-mono font-medium text-text-muted px-2 py-0.5 rounded-md bg-surface-secondary border border-border">
              Task #{task.id}
            </span>

            {isOverdue && (
              <Badge variant="error" className="text-xs font-bold animate-pulse">
                Overdue
              </Badge>
            )}

            {isDueToday && !isOverdue && (
              <Badge variant="warning" className="text-xs font-bold">
                Due Today
              </Badge>
            )}
          </div>

          {/* Title and Big Progress Indicator */}
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
            <div className="space-y-2 flex-1">
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-text-primary leading-snug">
                {task.title}
              </h1>
              <p className="text-xs text-text-muted flex items-center gap-2">
                <span suppressHydrationWarning>Created {formatDistanceToNow(new Date(task.createdAt), { addSuffix: true })}</span>
                <span>•</span>
                <span suppressHydrationWarning>Last active {formatDistanceToNow(new Date(task.updatedAt), { addSuffix: true })}</span>
              </p>
            </div>

            {/* Big Progress Meter & Action Button */}
            <div className="shrink-0 flex items-center md:flex-col md:items-end gap-3 md:gap-2 bg-surface-secondary/40 md:bg-transparent p-3 md:p-0 rounded-xl border md:border-0 border-border">
              <div className="flex items-baseline gap-1.5">
                <span className="text-3xl sm:text-4xl font-extrabold text-text-primary font-mono tracking-tight">
                  {task.progress}%
                </span>
                <span className="text-xs font-bold text-text-muted uppercase">Done</span>
              </div>
              
              {/* Contextual Action Button (Start Task / Submit Work) */}
              {task.status === TaskStatus.PENDING && (isAssignee || isManagerOrAdmin) && (
                <Button
                  type="button"
                  size="sm"
                  onClick={handleStartTask}
                  disabled={isStarting}
                  className="bg-primary text-white hover:bg-primary-hover text-xs font-semibold gap-1.5 cursor-pointer shadow-sm"
                >
                  {isStarting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <PlayCircle className="h-3.5 w-3.5" />}
                  <span>Start Task</span>
                </Button>
              )}

              {(task.status === TaskStatus.IN_PROGRESS || task.status === TaskStatus.REJECTED) && (isAssignee || isManagerOrAdmin) && (
                <Button
                  type="button"
                  size="sm"
                  onClick={() => setIsSubmitModalOpen(true)}
                  className="bg-purple-600 text-white hover:bg-purple-700 text-xs font-semibold gap-1.5 cursor-pointer shadow-sm"
                >
                  <Send className="h-3.5 w-3.5" />
                  <span>Submit for Review</span>
                </Button>
              )}
            </div>
          </div>

          {/* Full-width Animated Progress Bar */}
          <div className="space-y-1.5 pt-1">
            <div className="h-2.5 w-full bg-surface-secondary rounded-full overflow-hidden shadow-inner border border-border/40">
              <div 
                className={cn(
                  "h-full rounded-full transition-all duration-700 ease-out",
                  task.status === TaskStatus.COMPLETED ? "bg-emerald-500" :
                  task.health === "BLOCKED" || isOverdue ? "bg-rose-500" :
                  task.health === "AT_RISK" ? "bg-amber-500" :
                  "bg-primary"
                )} 
                style={{ width: `${task.progress}%` }} 
              />
            </div>
          </div>

          {/* Symmetrical 4-Stat Metric Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-2 border-t border-border">
            
            {/* 1. Creator / Lead */}
            <div className="p-3 rounded-xl bg-surface-secondary/40 border border-border/70 flex items-center gap-2.5">
              <div className="h-8 w-8 rounded-full bg-primary-soft text-primary font-bold text-xs flex items-center justify-center shrink-0 border border-primary/20">
                {task.assigner.profileImage ? (
                  <img src={task.assigner.profileImage} alt={task.assigner.firstName} className="w-full h-full rounded-full object-cover" />
                ) : (
                  getInitials(task.assigner.firstName, task.assigner.lastName)
                )}
              </div>
              <div className="min-w-0">
                <p className="text-[10px] uppercase font-bold tracking-wider text-text-muted">Task Lead</p>
                <p className="text-xs font-semibold text-text-primary truncate">
                  {task.assigner.firstName} {task.assigner.lastName}
                </p>
              </div>
            </div>

            {/* 2. Assignees Stack */}
            <div className="p-3 rounded-xl bg-surface-secondary/40 border border-border/70 flex items-center gap-2.5">
              <div className="flex -space-x-1.5 shrink-0">
                {task.assignees.slice(0, 3).map((a) => (
                  <Tooltip key={a.id} content={`${a.firstName} ${a.lastName} (${a.role})`}>
                    <div className="h-8 w-8 rounded-full bg-primary-soft border-2 border-surface text-primary font-bold text-[10px] flex items-center justify-center shadow-2xs">
                      {a.profileImage ? (
                        <img src={a.profileImage} alt={a.firstName} className="w-full h-full rounded-full object-cover" />
                      ) : (
                        getInitials(a.firstName, a.lastName)
                      )}
                    </div>
                  </Tooltip>
                ))}
                {task.assignees.length === 0 && (
                  <div className="h-8 w-8 rounded-full bg-surface-secondary border border-border flex items-center justify-center text-text-muted">
                    <User className="h-3.5 w-3.5" />
                  </div>
                )}
              </div>
              <div className="min-w-0">
                <p className="text-[10px] uppercase font-bold tracking-wider text-text-muted">Assigned</p>
                <p className="text-xs font-semibold text-text-primary truncate">
                  {task.assignees.length === 0 
                    ? "Unassigned" 
                    : task.assignees.length === 1 
                    ? `${task.assignees[0].firstName} ${task.assignees[0].lastName}`
                    : `${task.assignees.length} Members`}
                </p>
              </div>
            </div>

            {/* 3. Start Date & Target Due Date */}
            <div className="p-3 rounded-xl bg-surface-secondary/40 border border-border/70 flex items-center gap-2.5">
              <div className="h-8 w-8 rounded-full bg-primary-soft text-primary flex items-center justify-center shrink-0">
                <Calendar className="h-4 w-4" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] uppercase font-bold tracking-wider text-text-muted">Timeline</p>
                <p className="text-xs font-semibold text-text-primary truncate">
                  {task.startDate ? format(new Date(task.startDate), "MMM d") : "Started"} → {task.dueDate ? format(new Date(task.dueDate), "MMM d, yyyy") : "No due date"}
                </p>
              </div>
            </div>

            {/* 4. Hard Cutoff Deadline */}
            <div className="p-3 rounded-xl bg-surface-secondary/40 border border-border/70 flex items-center gap-2.5">
              <div className={cn(
                "h-8 w-8 rounded-full flex items-center justify-center shrink-0",
                isOverdue ? "bg-rose-500/20 text-rose-600" : "bg-warning-bg text-warning"
              )}>
                <Clock className="h-4 w-4" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] uppercase font-bold tracking-wider text-text-muted">Deadline Status</p>
                <p className="text-xs font-semibold text-text-primary truncate">
                  {task.deadline 
                    ? format(new Date(task.deadline), "MMM d \u00B7 h:mm a") 
                    : task.dueDate 
                    ? isOverdue ? "Overdue Target" : "On Schedule" 
                    : "Flexible"}
                </p>
              </div>
            </div>

          </div>

        </CardContent>
      </Card>

      {/* 6. MAIN WORKSPACE TABS */}
      <div className="flex items-center gap-2 border-b border-border pb-px overflow-x-auto">
        <button
          type="button"
          onClick={() => setMainTab("overview")}
          className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            mainTab === "overview"
              ? "border-primary text-primary font-semibold bg-primary-soft/30 rounded-t-lg"
              : "border-transparent text-text-secondary hover:text-text-primary hover:border-border"
          }`}
        >
          <FileText className="h-4 w-4" />
          <span>Overview & Scope</span>
        </button>

        <button
          type="button"
          onClick={() => setMainTab("milestones")}
          className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            mainTab === "milestones"
              ? "border-primary text-primary font-semibold bg-primary-soft/30 rounded-t-lg"
              : "border-transparent text-text-secondary hover:text-text-primary hover:border-border"
          }`}
        >
          <ListTodo className="h-4 w-4" />
          <span>Checkpoints ({completedMilestonesCount}/{totalMilestonesCount})</span>
        </button>

        <button
          type="button"
          onClick={() => setMainTab("activity")}
          className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            mainTab === "activity"
              ? "border-primary text-primary font-semibold bg-primary-soft/30 rounded-t-lg"
              : "border-transparent text-text-secondary hover:text-text-primary hover:border-border"
          }`}
        >
          <MessageSquare className="h-4 w-4" />
          <span>Activity & Thread ({task.updates.length})</span>
        </button>
      </div>

      {/* 7. WORKSPACE 2-COLUMN CONTENT */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column (8 cols): Active Tab Views */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* TAB 1: OVERVIEW & SCOPE */}
          {mainTab === "overview" && (
            <div className="space-y-6">
              
              {/* Deliverables Card */}
              <Card className="bg-surface border-border shadow-xs overflow-hidden">
                <CardHeader className="p-5 sm:p-6 border-b border-border">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 rounded-lg bg-primary-soft text-primary">
                        <CheckCheck className="h-4.5 w-4.5" />
                      </div>
                      <div>
                        <CardTitle className="text-base font-semibold">Deliverables & Expected Output</CardTitle>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-[10px] font-mono">
                      Definition of Done
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-5 sm:p-6">
                  {task.deliverables ? (
                    <div className="p-4 rounded-xl bg-surface-secondary/40 border border-border text-xs sm:text-sm text-text-primary leading-relaxed whitespace-pre-wrap font-sans">
                      {task.deliverables}
                    </div>
                  ) : (
                    <div className="p-6 text-center text-xs text-text-muted bg-surface-secondary/20 rounded-xl border border-dashed border-border">
                      No explicit deliverables defined. Standard project review criteria applies.
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Description Card */}
              <Card className="bg-surface border-border shadow-xs overflow-hidden">
                <CardHeader className="p-5 sm:p-6 border-b border-border">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 rounded-lg bg-teal-500/10 text-teal-600 dark:text-teal-400">
                        <AlignLeft className="h-4.5 w-4.5" />
                      </div>
                      <div>
                        <CardTitle className="text-base font-semibold">Background Context & Scope</CardTitle>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-[10px] font-mono">
                      Context
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-5 sm:p-6">
                  {task.description ? (
                    <div className="p-4 rounded-xl bg-surface-secondary/40 border border-border text-xs sm:text-sm text-text-primary leading-relaxed whitespace-pre-wrap">
                      {task.description}
                    </div>
                  ) : (
                    <div className="p-6 text-center text-xs text-text-muted bg-surface-secondary/20 rounded-xl border border-dashed border-border">
                      No background description was provided for this task.
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Guidelines / Instructions Card */}
              {task.instructions && (
                <Card className="bg-surface border-border shadow-xs overflow-hidden">
                  <CardHeader className="p-5 sm:p-6 border-b border-border">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 rounded-lg bg-violet-500/10 text-violet-600 dark:text-violet-400">
                          <Info className="h-4.5 w-4.5" />
                        </div>
                        <div>
                          <CardTitle className="text-base font-semibold">Manager Guidelines & Acceptance Notes</CardTitle>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-[10px] font-mono">
                        Guidelines
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="p-5 sm:p-6">
                    <div className="p-4 rounded-xl bg-surface-secondary/40 border border-border text-xs sm:text-sm text-text-primary leading-relaxed whitespace-pre-wrap">
                      {task.instructions}
                    </div>
                  </CardContent>
                </Card>
              )}

            </div>
          )}

          {/* TAB 2: MILESTONES & CHECKPOINTS */}
          {mainTab === "milestones" && (
            <Card className="bg-surface border-border shadow-xs overflow-hidden">
              <CardHeader className="p-5 sm:p-6 border-b border-border">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-primary-soft text-primary">
                      <ListTodo className="h-4.5 w-4.5" />
                    </div>
                    <div>
                      <CardTitle className="text-base font-semibold">Milestones & Action Steps</CardTitle>
                    </div>
                  </div>
                  {totalMilestonesCount > 0 && (
                    <Badge variant={completedMilestonesCount === totalMilestonesCount ? "success" : "secondary"} className="text-xs">
                      {milestoneCompletionPct}% Complete
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="p-5 sm:p-6 space-y-4">
                
                {/* List of Milestones */}
                {task.milestones.length === 0 ? (
                  <div className="p-8 text-center text-xs text-text-muted bg-surface-secondary/20 rounded-2xl border border-dashed border-border space-y-1">
                    <p className="font-medium text-text-secondary">No milestones yet</p>
                    <p className="text-[11px]">Add sequential checkpoints below to track step-by-step progress.</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {task.milestones.map((m, index) => (
                      <div
                        key={m.id}
                        onClick={() => handleMilestoneToggle(m.id, !m.completed)}
                        className={cn(
                          "flex items-center justify-between gap-3 p-3.5 rounded-xl border transition-all duration-150 select-none",
                          canEdit ? "cursor-pointer" : "cursor-default",
                          m.completed 
                            ? "bg-surface-secondary/40 border-border/60 opacity-80" 
                            : "bg-surface border-border hover:border-primary/40 hover:bg-surface-secondary/30 shadow-2xs"
                        )}
                      >
                        <div className="flex items-center gap-3 min-w-0 flex-1">
                          <div className={cn(
                            "w-5 h-5 rounded-md border flex items-center justify-center transition-all shrink-0",
                            m.completed 
                              ? "bg-primary border-primary text-white" 
                              : "border-border-strong bg-surface text-transparent"
                          )}>
                            <Check className="h-3 w-3" />
                          </div>

                          <span className={cn(
                            "text-xs sm:text-sm font-medium transition-all truncate",
                            m.completed 
                              ? "text-text-muted line-through decoration-text-muted/60" 
                              : "text-text-primary"
                          )}>
                            {m.title}
                          </span>
                        </div>

                        <span className="text-[10px] font-mono font-bold text-text-disabled shrink-0">
                          Step #{index + 1}
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Inline Add Milestone Form */}
                {canEdit && (
                  <form onSubmit={handleAddMilestone} className="flex gap-2 pt-2">
                    <Input
                      value={newMilestoneText}
                      onChange={(e) => setNewMilestoneText(e.target.value)}
                      placeholder="Add a new action checkpoint step..."
                      className="text-xs sm:text-sm h-10 bg-surface-secondary/40 focus:bg-surface"
                    />
                    <Button 
                      type="submit" 
                      variant="secondary" 
                      disabled={isAddingMilestone || !newMilestoneText.trim()} 
                      className="h-10 px-4 gap-1.5 shrink-0 cursor-pointer font-semibold"
                    >
                      {isAddingMilestone ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                      <span>Add Checkpoint</span>
                    </Button>
                  </form>
                )}

              </CardContent>
            </Card>
          )}

          {/* TAB 3: ACTIVITY & TEAM THREAD */}
          {mainTab === "activity" && (
            <Card className="bg-surface border-border shadow-xs overflow-hidden">
              <CardHeader className="p-5 sm:p-6 border-b border-border">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-primary-soft text-primary">
                      <MessageSquare className="h-4.5 w-4.5" />
                    </div>
                    <div>
                      <CardTitle className="text-base font-semibold">Activity & Team Thread</CardTitle>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-[10px] font-mono">
                    {task.updates.length} updates
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-5 sm:p-6 space-y-6">
                
                {/* Composer Box */}
                {canEdit && (
                  <div className="rounded-2xl border border-border bg-surface shadow-xs overflow-hidden focus-within:ring-2 focus-within:ring-primary/20 focus-within:border-primary transition-all">
                    
                    {/* Mode Tabs */}
                    <div className="flex border-b border-border bg-surface-secondary/40 text-xs">
                      <button
                        type="button"
                        onClick={() => setUpdateType("PROGRESS")}
                        className={cn(
                          "flex-1 py-2.5 font-bold uppercase tracking-wider text-[11px] transition-colors flex items-center justify-center gap-1.5 cursor-pointer",
                          updateType === "PROGRESS" 
                            ? "text-primary border-b-2 border-primary bg-surface" 
                            : "text-text-secondary hover:text-text-primary"
                        )}
                      >
                        <PlayCircle className="h-3.5 w-3.5 text-emerald-500" />
                        Progress Report
                      </button>
                      <button
                        type="button"
                        onClick={() => setUpdateType("COMMENT")}
                        className={cn(
                          "flex-1 py-2.5 font-bold uppercase tracking-wider text-[11px] transition-colors flex items-center justify-center gap-1.5 cursor-pointer",
                          updateType === "COMMENT" 
                            ? "text-primary border-b-2 border-primary bg-surface" 
                            : "text-text-secondary hover:text-text-primary"
                        )}
                      >
                        <MessageSquare className="h-3.5 w-3.5 text-primary" />
                        Comment
                      </button>
                      <button
                        type="button"
                        onClick={() => setUpdateType("BLOCKER")}
                        className={cn(
                          "flex-1 py-2.5 font-bold uppercase tracking-wider text-[11px] transition-colors flex items-center justify-center gap-1.5 cursor-pointer",
                          updateType === "BLOCKER" 
                            ? "text-rose-600 border-b-2 border-rose-500 bg-surface" 
                            : "text-text-secondary hover:text-text-primary"
                        )}
                      >
                        <AlertCircle className="h-3.5 w-3.5 text-rose-500" />
                        Report Blocker
                      </button>
                    </div>

                    {/* Composer Form */}
                    <form onSubmit={handlePostUpdate} className="p-4 space-y-3">
                      <AnimatePresence mode="wait">
                        {updateType === "PROGRESS" ? (
                          <motion.div
                            key="progress"
                            initial={{ opacity: 0, y: 4 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -4 }}
                            className="space-y-3"
                          >
                            <div>
                              <label className="text-[10px] font-bold uppercase tracking-widest text-text-secondary block mb-1">
                                Completed Work / Deliverables Finished
                              </label>
                              <textarea
                                value={completedWork}
                                onChange={(e) => setCompletedWork(e.target.value)}
                                placeholder="What components, milestones, or deliverables did you finish?"
                                className="w-full text-xs sm:text-sm bg-surface-secondary/40 focus:bg-surface rounded-xl border border-border p-3 text-text-primary placeholder:text-text-muted focus:outline-none focus:border-primary resize-y"
                                rows={2}
                              />
                            </div>

                            <div>
                              <label className="text-[10px] font-bold uppercase tracking-widest text-text-secondary block mb-1">
                                Pending / Immediate Next Steps
                              </label>
                              <textarea
                                value={pendingWork}
                                onChange={(e) => setPendingWork(e.target.value)}
                                placeholder="What are the immediate next items to tackle?"
                                className="w-full text-xs sm:text-sm bg-surface-secondary/40 focus:bg-surface rounded-xl border border-border p-3 text-text-primary placeholder:text-text-muted focus:outline-none focus:border-primary resize-y"
                                rows={2}
                              />
                            </div>

                            {/* Quick Progress Buttons & Slider */}
                            <div className="space-y-1.5 pt-1">
                              <div className="flex items-center justify-between text-xs">
                                <span className="font-semibold text-text-secondary">Overall Progress: {progress}%</span>
                                <div className="flex items-center gap-1">
                                  {[25, 50, 75, 100].map((val) => (
                                    <button
                                      key={val}
                                      type="button"
                                      onClick={() => setProgress(val)}
                                      className={cn(
                                        "px-2.5 py-0.5 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer",
                                        progress === val 
                                          ? "bg-primary text-white border-primary" 
                                          : "bg-surface-secondary text-text-secondary border-border hover:border-primary/40"
                                      )}
                                    >
                                      {val}%
                                    </button>
                                  ))}
                                </div>
                              </div>
                              <input
                                type="range"
                                min="0"
                                max="100"
                                value={progress}
                                onChange={(e) => setProgress(Number(e.target.value))}
                                className="w-full accent-primary h-2 bg-surface-secondary rounded-lg cursor-pointer"
                              />
                            </div>
                          </motion.div>
                        ) : (
                          <motion.div
                            key="comment"
                            initial={{ opacity: 0, y: 4 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -4 }}
                          >
                            <textarea
                              value={content}
                              onChange={(e) => setContent(e.target.value)}
                              placeholder={
                                updateType === "BLOCKER" 
                                  ? "Describe the issue blocking this task and what team assistance is required..." 
                                  : "Type your update or comment here..."
                              }
                              className="w-full text-xs sm:text-sm bg-surface-secondary/40 focus:bg-surface rounded-xl border border-border p-3 text-text-primary placeholder:text-text-muted focus:outline-none focus:border-primary resize-y"
                              rows={3}
                              required
                            />
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* Submit Footer */}
                      <div className="flex items-center justify-between pt-2 border-t border-border mt-2">
                        <span className="text-[11px] text-text-muted hidden sm:inline">
                          Posted to HKRiON project log
                        </span>
                        <Button
                          type="submit"
                          disabled={isUpdating}
                          size="sm"
                          className="gap-1.5 font-semibold text-xs ml-auto shadow-sm cursor-pointer"
                        >
                          {isUpdating ? (
                            <>
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                              <span>Posting...</span>
                            </>
                          ) : (
                            <>
                              <Send className="h-3.5 w-3.5" />
                              <span>Post Update</span>
                            </>
                          )}
                        </Button>
                      </div>
                    </form>
                  </div>
                )}

                {/* Timeline Activity Stream */}
                <div className="space-y-4 pt-1">
                  {task.updates.length === 0 ? (
                    <div className="p-8 text-center text-xs text-text-muted bg-surface-secondary/20 rounded-2xl border border-dashed border-border space-y-1">
                      <p className="font-medium text-text-secondary">No activity logged yet</p>
                      <p className="text-[11px]">Be the first to post a status report or discussion note.</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {task.updates.map((up) => {
                        const conf = updateTypeConfig[up.type] || updateTypeConfig.COMMENT;
                        return (
                          <div
                            key={up.id}
                            className="p-4 rounded-2xl border border-border bg-surface-secondary/30 hover:bg-surface-secondary/50 transition-colors space-y-2.5"
                          >
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-2.5 min-w-0">
                                <div className="h-8 w-8 rounded-full bg-primary-soft text-primary font-bold text-xs flex items-center justify-center shrink-0 border border-primary/20">
                                  {up.author.profileImage ? (
                                    <img src={up.author.profileImage} alt={up.author.firstName} className="w-full h-full rounded-full object-cover" />
                                  ) : (
                                    getInitials(up.author.firstName, up.author.lastName)
                                  )}
                                </div>
                                <div className="min-w-0">
                                  <div className="flex items-center gap-1.5">
                                    <span className="text-xs font-bold text-text-primary truncate">
                                      {up.author.firstName} {up.author.lastName}
                                    </span>
                                    <Badge variant="secondary" className="text-[9px] uppercase px-1.5 py-0">
                                      {up.author.role}
                                    </Badge>
                                  </div>
                                </div>
                              </div>

                              <div className="flex items-center gap-2 shrink-0">
                                <span className={cn("text-[10px] font-bold uppercase px-2 py-0.5 rounded-full border", conf.badgeColor)}>
                                  {conf.label}
                                </span>
                                <span suppressHydrationWarning className="text-[10px] text-text-muted font-mono">
                                  {formatDistanceToNow(new Date(up.createdAt), { addSuffix: true })}
                                </span>
                              </div>
                            </div>

                            <div className="text-xs sm:text-sm text-text-primary whitespace-pre-wrap leading-relaxed pl-10">
                              {up.content}
                            </div>

                            {up.progressSnapshot !== null && up.progressSnapshot !== undefined && (
                              <div className="pl-10 pt-1">
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-600 border border-emerald-500/20">
                                  <Check className="h-3 w-3" /> Progress Snapshot: {up.progressSnapshot}%
                                </span>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

              </CardContent>
            </Card>
          )}

        </div>

        {/* Right Sidebar (4 cols): Team & Ownership, Dependencies */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Card 1: Team & Ownership */}
          <Card className="bg-surface border-border shadow-xs overflow-hidden">
            <CardHeader className="p-5 sm:p-6 border-b border-border">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-primary-soft text-primary">
                    <Users className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <CardTitle className="text-base font-semibold">Team & Ownership</CardTitle>
                  </div>
                </div>
                <Badge variant="outline" className="text-[10px] font-mono">
                  {task.assignees.length + 1} Members
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="p-5 sm:p-6 space-y-4">
              
              {/* Creator / Lead */}
              <div>
                <p className="text-[10px] font-bold uppercase tracking-wider text-text-muted mb-2">
                  Task Lead (Assigned By)
                </p>
                <div className="flex items-center gap-3 p-2.5 rounded-xl border border-border bg-surface-secondary/30">
                  <div className="h-9 w-9 rounded-full bg-primary text-white font-bold text-xs flex items-center justify-center shrink-0">
                    {task.assigner.profileImage ? (
                      <img src={task.assigner.profileImage} alt={task.assigner.firstName} className="w-full h-full rounded-full object-cover" />
                    ) : (
                      getInitials(task.assigner.firstName, task.assigner.lastName)
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-bold text-text-primary truncate">
                      {task.assigner.firstName} {task.assigner.lastName}
                    </p>
                    <p className="text-[11px] text-text-muted truncate">
                      {task.assigner.position?.title || task.assigner.email}
                    </p>
                  </div>
                </div>
              </div>

              {/* Assignees */}
              <div>
                <p className="text-[10px] font-bold uppercase tracking-wider text-text-muted mb-2">
                  Assigned Team ({task.assignees.length})
                </p>
                {task.assignees.length === 0 ? (
                  <p className="text-xs text-text-muted italic p-2">No team members assigned.</p>
                ) : (
                  <div className="space-y-1.5">
                    {task.assignees.map((a) => (
                      <div
                        key={a.id}
                        className="flex items-center justify-between p-2.5 rounded-xl border border-border bg-surface-secondary/20"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="h-7 w-7 rounded-full bg-primary-soft text-primary font-bold text-[10px] flex items-center justify-center shrink-0 border border-primary/20">
                            {a.profileImage ? (
                              <img src={a.profileImage} alt={a.firstName} className="w-full h-full rounded-full object-cover" />
                            ) : (
                              getInitials(a.firstName, a.lastName)
                            )}
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-semibold text-text-primary truncate">
                              {a.firstName} {a.lastName}
                            </p>
                            <p className="text-[10px] text-text-muted truncate">
                              {a.position?.title || a.email}
                            </p>
                          </div>
                        </div>

                        <Badge variant="secondary" className="text-[9px] uppercase px-1.5 py-0">
                          {a.role}
                        </Badge>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </CardContent>
          </Card>

          {/* Card 2: Dependencies & Blockers */}
          <Card className="bg-surface border-border shadow-xs overflow-hidden">
            <CardHeader className="p-5 sm:p-6 border-b border-border">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-rose-500/10 text-rose-600 dark:text-rose-400">
                    <ShieldAlert className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <CardTitle className="text-base font-semibold">Dependencies</CardTitle>
                  </div>
                </div>
                {task.dependencies.length > 0 && (
                  <Badge variant="error" className="text-[10px] font-mono">
                    {task.dependencies.length} Linked
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="p-5 sm:p-6 space-y-2.5">
              {task.dependencies.length === 0 ? (
                <div className="p-4 text-center text-xs text-text-muted bg-surface-secondary/20 rounded-xl border border-dashed border-border">
                  No blockers or prerequisites linked.
                </div>
              ) : (
                task.dependencies.map((dep) => {
                  const depHealth = healthConfig[dep.health] || healthConfig.NOT_STARTED;
                  return (
                    <Link
                      key={dep.id}
                      href={`/dashboard/tasks/${dep.id}`}
                      className="block p-3 rounded-xl border border-border bg-surface-secondary/30 hover:border-primary/40 hover:bg-surface-secondary/50 transition-colors"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <span className="text-xs font-semibold text-text-primary hover:text-primary transition-colors line-clamp-1">
                          {dep.title}
                        </span>
                        <span className={cn("text-[9px] font-bold uppercase px-1.5 py-0.2 rounded shrink-0", depHealth.bg, depHealth.color)}>
                          {depHealth.label}
                        </span>
                      </div>
                      {dep.progress !== null && dep.progress !== undefined && (
                        <div className="mt-2 flex items-center gap-2">
                          <div className="h-1 flex-1 bg-surface-secondary rounded-full overflow-hidden">
                            <div className="h-full bg-primary" style={{ width: `${dep.progress}%` }} />
                          </div>
                          <span className="text-[10px] font-mono text-text-muted">{dep.progress}%</span>
                        </div>
                      )}
                    </Link>
                  );
                })
              )}
            </CardContent>
          </Card>

        </div>

      </div>

      {/* MODAL 1: SUBMIT FOR REVIEW */}
      <Modal
        isOpen={isSubmitModalOpen}
        onClose={() => setIsSubmitModalOpen(false)}
        title="Submit Deliverables for Manager Review"
      >
        <form onSubmit={handleSubmitForReview} className="space-y-4">
          <p className="text-xs text-text-secondary leading-relaxed">
            Ready for your manager to review your completed work? Submitting will mark this task as <strong className="text-text-primary">Under Review</strong> and notify your lead.
          </p>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-text-primary block">
              Deliverables Summary & Handover Notes
            </label>
            <textarea
              value={submissionNotes}
              onChange={(e) => setSubmissionNotes(e.target.value)}
              placeholder="Detail your completed deliverables, links to PRs or repos, or special instructions..."
              className="w-full text-xs sm:text-sm bg-surface-secondary/40 focus:bg-surface rounded-xl border border-border p-3 text-text-primary placeholder:text-text-muted focus:outline-none focus:border-primary resize-y"
              rows={3}
            />
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setIsSubmitModalOpen(false)}
              disabled={isSubmittingReview}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              size="sm"
              disabled={isSubmittingReview}
              className="gap-1.5 bg-purple-600 hover:bg-purple-700 text-white font-semibold cursor-pointer"
            >
              {isSubmittingReview ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
              <span>Submit for Review</span>
            </Button>
          </div>
        </form>
      </Modal>

      {/* MODAL 2: MANAGER REVIEW & REVISION REQUEST */}
      <Modal
        isOpen={isReviewModalOpen}
        onClose={() => setIsReviewModalOpen(false)}
        title="Request Revisions from Assignee"
      >
        <div className="space-y-4">
          <p className="text-xs text-text-secondary leading-relaxed">
            Explain what changes or additions are required before this task can be approved.
          </p>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-text-primary block">
              Required Changes / Revision Feedback
            </label>
            <textarea
              value={reviewNotesInput}
              onChange={(e) => setReviewNotesInput(e.target.value)}
              placeholder="e.g. Please add unit tests for the auth helper and resolve merge conflicts..."
              className="w-full text-xs sm:text-sm bg-surface-secondary/40 focus:bg-surface rounded-xl border border-border p-3 text-text-primary placeholder:text-text-muted focus:outline-none focus:border-primary resize-y"
              rows={3}
              required
            />
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setIsReviewModalOpen(false)}
              disabled={isReviewing}
            >
              Cancel
            </Button>
            <Button
              type="button"
              size="sm"
              onClick={() => handleReviewDecision("REJECT")}
              disabled={isReviewing || !reviewNotesInput.trim()}
              className="gap-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold cursor-pointer"
            >
              {isReviewing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <AlertTriangle className="h-3.5 w-3.5" />}
              <span>Send Revision Request</span>
            </Button>
          </div>
        </div>
      </Modal>

      {/* MODAL 3: DELETE CONFIRMATION */}
      <Modal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        title="Delete Task Workspace"
      >
        <div className="space-y-4">
          <p className="text-sm text-text-secondary leading-relaxed">
            Are you sure you want to delete <strong className="text-text-primary font-semibold">"{task.title}"</strong>? All checkpoints, deliverables, and team comments will be permanently erased.
          </p>

          <div className="flex items-center justify-end gap-3 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsDeleteModalOpen(false)}
              disabled={isDeleting}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={handleDeleteTask}
              disabled={isDeleting}
              className="gap-1.5"
            >
              {isDeleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
              <span>Delete Permanently</span>
            </Button>
          </div>
        </div>
      </Modal>

    </div>
  );
}
