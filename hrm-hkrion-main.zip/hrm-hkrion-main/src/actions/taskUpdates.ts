"use server";

import { prisma } from "@/lib/db";
import { getSession } from "@/lib/session";
import { revalidatePath } from "next/cache";
import { PostTaskUpdateSchema, UpdateTaskHealthSchema } from "@/lib/schemas";
import { Role, TaskHealth } from "@prisma/client";

export async function updateTaskHealth(taskId: number, formData: FormData) {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    const data = Object.fromEntries(formData.entries());
    const parsed = UpdateTaskHealthSchema.safeParse({
      ...data,
      progress: data.progress ? Number(data.progress) : undefined
    });

    if (!parsed.success) {
      const err = parsed.error as any;
      return { error: err.issues[0].message };
    }

    const task = await prisma.task.update({
      where: { id: taskId },
      data: {
        health: parsed.data.health,
        progress: parsed.data.progress,
      },
      include: { assigner: true }
    });

    // Notify assigner if progress or health changed significantly
    if (session.userId !== task.assignerId) {
      await prisma.notification.create({
        data: {
          userId: task.assignerId,
          title: "Task Health Updated",
          message: `Task "${task.title}" is now ${task.health.replace("_", " ")}.`,
          link: `/dashboard/tasks/${task.id}`,
        }
      });
    }

    revalidatePath(`/dashboard/tasks/${taskId}`);
    return { success: true };
  } catch (error) {
    console.error("Failed to update task health:", error);
    return { error: "Failed to update task health" };
  }
}

export async function postTaskUpdate(taskId: number, formData: FormData) {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    const data = Object.fromEntries(formData.entries());
    const parsed = PostTaskUpdateSchema.safeParse({
      ...data,
      progress: data.progress ? Number(data.progress) : undefined
    });

    if (!parsed.success) {
      const err = parsed.error as any;
      return { error: err.issues[0].message };
    }

    const task = await prisma.task.findUnique({
      where: { id: taskId },
      include: { assignees: true }
    });

    if (!task) return { error: "Task not found" };

    const update = await prisma.taskUpdate.create({
      data: {
        taskId,
        authorId: session.userId,
        type: parsed.data.type,
        content: parsed.data.content,
        progressSnapshot: parsed.data.progress ?? task.progress,
        healthSnapshot: parsed.data.health ?? task.health,
      }
    });

    // Optionally update task health and progress if provided
    if (parsed.data.progress !== undefined || parsed.data.health !== undefined) {
      await prisma.task.update({
        where: { id: taskId },
        data: {
          progress: parsed.data.progress,
          health: parsed.data.health,
        }
      });
    }

    // Determine who to notify
    const notifyIds = new Set(task.assignees.map(a => a.id));
    notifyIds.add(task.assignerId);
    notifyIds.delete(session.userId); // Don't notify the person who posted

    if (notifyIds.size > 0) {
      const author = await prisma.user.findUnique({
        where: { id: session.userId },
        select: { firstName: true, lastName: true },
      });
      const authorName = author ? `${author.firstName} ${author.lastName}` : "A team member";

      await prisma.notification.createMany({
        data: Array.from(notifyIds).map(userId => ({
          userId,
          title: "New Task Update",
          message: `${authorName} posted an update on "${task.title}"`,
          link: `/dashboard/tasks/${task.id}`,
        }))
      });
    }

    revalidatePath(`/dashboard/tasks/${taskId}`);
    return { success: true };
  } catch (error) {
    console.error("Failed to post task update:", error);
    return { error: "Failed to post task update" };
  }
}

export async function toggleMilestone(milestoneId: number, completed: boolean, taskId: number) {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    await prisma.$transaction(async (tx) => {
      const updatedMilestone = await tx.taskMilestone.update({
        where: { id: milestoneId },
        data: { completed },
      });

      // Recalculate task progress based on milestone completion
      const allMilestones = await tx.taskMilestone.findMany({
        where: { taskId },
      });

      const totalCount = allMilestones.length;
      const completedCount = allMilestones.filter(m => m.completed).length;
      const newProgress = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

      await tx.task.update({
        where: { id: taskId },
        data: {
          progress: newProgress,
        },
      });

      // Log system update
      await tx.taskUpdate.create({
        data: {
          taskId,
          authorId: session.userId,
          type: "SYSTEM",
          content: `Marked checkpoint "${updatedMilestone.title}" as ${completed ? 'completed' : 'incomplete'}. Progress: ${newProgress}%`,
          progressSnapshot: newProgress,
        },
      });
    });

    revalidatePath(`/dashboard/tasks/${taskId}`);
    revalidatePath("/dashboard/tasks");
    return { success: true };
  } catch (error) {
    console.error("Failed to toggle milestone:", error);
    return { error: "Failed to toggle milestone" };
  }
}

export async function addMilestone(taskId: number, title: string) {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    if (!title || !title.trim()) return { error: "Milestone title cannot be empty" };

    let milestoneId: number | undefined;

    await prisma.$transaction(async (tx) => {
      const milestone = await tx.taskMilestone.create({
        data: {
          taskId,
          title: title.trim(),
          completed: false,
        },
      });

      milestoneId = milestone.id;

      await tx.taskUpdate.create({
        data: {
          taskId,
          authorId: session.userId,
          type: "SYSTEM",
          content: `Added checkpoint milestone: "${title.trim()}"`,
        },
      });
    });

    revalidatePath(`/dashboard/tasks/${taskId}`);
    revalidatePath("/dashboard/tasks");
    return { success: true, milestoneId };
  } catch (error) {
    console.error("Failed to add milestone:", error);
    return { error: "Failed to add milestone" };
  }
}

