import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

export interface ProductSearchResult {
  id: string;
  name: string;
  type: string;
  imageUrl?: string | null;
  categoryName?: string | null;
  sku?: string | null;
  sellingPrice?: number | null;
  stock: number;
}

export interface SaleSearchResult {
  id: string;
  invoiceNumber: string;
  customerName: string;
  grandTotal: number;
  amountPaid: number;
  paymentStatus: string;
  saleDate: Date;
  branchName?: string | null;
}

export interface PurchaseSearchResult {
  id: string;
  purchaseNumber: string;
  supplierName: string;
  grandTotal: number;
  status: string;
  purchaseDate: Date;
}

export interface ContactSearchResult {
  id: string;
  name: string;
  phone?: string | null;
  email?: string | null;
  type: 'CUSTOMER' | 'SUPPLIER';
}

export interface GlobalSearchResponse {
  query: string;
  products: ProductSearchResult[];
  sales: SaleSearchResult[];
  purchases: PurchaseSearchResult[];
  contacts: ContactSearchResult[];
}

@Injectable()
export class SearchService {
  constructor(private readonly prisma: PrismaService) {}

  async searchGlobal(
    query: string,
    businessId: string,
    branchId?: string,
    limit = 5,
    canViewPurchases = true,
  ): Promise<GlobalSearchResponse> {
    const q = (query || '').trim();
    if (!q || !businessId) {
      return {
        query: q,
        products: [],
        sales: [],
        purchases: [],
        contacts: [],
      };
    }

    const effectiveLimit = Math.min(Math.max(1, Number(limit) || 5), 10);

    // Parallel queries across 5 entities using Promise.allSettled
    const [
      productsRes,
      salesRes,
      purchasesRes,
      customersRes,
      suppliersRes,
    ] = await Promise.allSettled([
      // 1. Products & Variants (Name, SKU, Barcode)
      this.prisma.product.findMany({
        where: {
          businessId,
          isActive: true,
          OR: [
            { name: { contains: q, mode: 'insensitive' } },
            { description: { contains: q, mode: 'insensitive' } },
            { variants: { some: { sku: { contains: q, mode: 'insensitive' } } } },
            { variants: { some: { barcode: { contains: q, mode: 'insensitive' } } } },
          ],
        },
        include: {
          category: { select: { name: true } },
          variants: {
            select: {
              id: true,
              sku: true,
              sellingPrice: true,
              purchaseLines: {
                where: branchId && branchId !== 'all' ? { branchId } : undefined,
                select: { quantityRemaining: true },
              },
            },
            take: 3,
          },
        },
        take: effectiveLimit,
        orderBy: { name: 'asc' },
      }),

      // 2. Sales / Invoices
      this.prisma.sale.findMany({
        where: {
          businessId,
          ...(branchId && branchId !== 'all' ? { branchId } : {}),
          OR: [
            { invoiceNumber: { contains: q, mode: 'insensitive' } },
            { customer: { name: { contains: q, mode: 'insensitive' } } },
          ],
        },
        select: {
          id: true,
          invoiceNumber: true,
          grandTotal: true,
          amountPaid: true,
          paymentStatus: true,
          saleDate: true,
          customer: { select: { name: true } },
          branch: { select: { name: true } },
        },
        take: effectiveLimit,
        orderBy: { saleDate: 'desc' },
      }),

      // 3. Purchases
      canViewPurchases
        ? this.prisma.purchase.findMany({
            where: {
              businessId,
              ...(branchId && branchId !== 'all' ? { branchId } : {}),
              OR: [
                { purchaseNumber: { contains: q, mode: 'insensitive' } },
                { supplier: { name: { contains: q, mode: 'insensitive' } } },
              ],
            },
            select: {
              id: true,
              purchaseNumber: true,
              grandTotal: true,
              status: true,
              purchaseDate: true,
              supplier: { select: { name: true } },
            },
            take: effectiveLimit,
            orderBy: { purchaseDate: 'desc' },
          })
        : Promise.resolve([]),

      // 4. Customers
      this.prisma.customer.findMany({
        where: {
          businessId,
          OR: [
            { name: { contains: q, mode: 'insensitive' } },
            { phone: { contains: q, mode: 'insensitive' } },
            { email: { contains: q, mode: 'insensitive' } },
          ],
        },
        select: {
          id: true,
          name: true,
          phone: true,
          email: true,
        },
        take: effectiveLimit,
        orderBy: { name: 'asc' },
      }),

      // 5. Suppliers
      this.prisma.supplier.findMany({
        where: {
          businessId,
          OR: [
            { name: { contains: q, mode: 'insensitive' } },
            { phone: { contains: q, mode: 'insensitive' } },
            { email: { contains: q, mode: 'insensitive' } },
          ],
        },
        select: {
          id: true,
          name: true,
          phone: true,
          email: true,
        },
        take: effectiveLimit,
        orderBy: { name: 'asc' },
      }),
    ]);

    // Format products
    const products: ProductSearchResult[] = productsRes.status === 'fulfilled'
      ? productsRes.value.map((p) => {
          const firstVariant = p.variants[0];
          const totalStock = p.variants.reduce((acc, v) => {
            const vStock = (v.purchaseLines || []).reduce((s, pl) => s + (pl.quantityRemaining || 0), 0);
            return acc + vStock;
          }, 0);

          return {
            id: p.id,
            name: p.name,
            type: p.type,
            imageUrl: p.imageUrl,
            categoryName: p.category?.name || null,
            sku: firstVariant?.sku || null,
            sellingPrice: firstVariant?.sellingPrice ? Number(firstVariant.sellingPrice) : null,
            stock: totalStock,
          };
        })
      : [];

    // Format sales
    const sales: SaleSearchResult[] = salesRes.status === 'fulfilled'
      ? salesRes.value.map((s) => ({
          id: s.id,
          invoiceNumber: s.invoiceNumber,
          customerName: s.customer?.name || 'Walk-in Customer',
          grandTotal: Number(s.grandTotal || 0),
          amountPaid: Number(s.amountPaid || 0),
          paymentStatus: s.paymentStatus,
          saleDate: s.saleDate,
          branchName: s.branch?.name || null,
        }))
      : [];

    // Format purchases
    const purchases: PurchaseSearchResult[] = purchasesRes.status === 'fulfilled'
      ? purchasesRes.value.map((pu) => ({
          id: pu.id,
          purchaseNumber: pu.purchaseNumber,
          supplierName: pu.supplier?.name || 'Unknown Supplier',
          grandTotal: Number(pu.grandTotal || 0),
          status: pu.status,
          purchaseDate: pu.purchaseDate,
        }))
      : [];

    // Format contacts (customers & suppliers merged with type badge)
    const contacts: ContactSearchResult[] = [];
    if (customersRes.status === 'fulfilled') {
      customersRes.value.forEach((c) => {
        contacts.push({
          id: c.id,
          name: c.name,
          phone: c.phone,
          email: c.email,
          type: 'CUSTOMER',
        });
      });
    }
    if (suppliersRes.status === 'fulfilled') {
      suppliersRes.value.forEach((s) => {
        contacts.push({
          id: s.id,
          name: s.name,
          phone: s.phone,
          email: s.email,
          type: 'SUPPLIER',
        });
      });
    }

    return {
      query: q,
      products,
      sales,
      purchases,
      contacts,
    };
  }
}
