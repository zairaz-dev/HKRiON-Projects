import { Controller, Get, Body, Post, Put, Delete, Param, Query, UseGuards, Req } from '@nestjs/common';
import { ExpensesService } from './expenses.service';
import { CreateExpenseDto } from './dto/create-expense.dto';
import { UpdateExpenseDto } from './dto/update-expense.dto';
import { ApiBody, ApiResponse } from '@nestjs/swagger';
import { CreateExpenseBodySchema, UpdateExpenseBodySchema, ExpensePaymentBodySchema, ExpenseResponseSchema } from '../../docs/expenses.docs';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('expenses')
export class ExpensesController {
  constructor(private readonly expensesService: ExpensesService) {}

  @Permissions(Permission.PURCHASE_CREATE)
  @Post()
  @ApiBody({ schema: CreateExpenseBodySchema })
  @ApiResponse({ status: 201, description: 'Expense created successfully', schema: ExpenseResponseSchema })
  create(@Req() req: any, @Body() createDto: CreateExpenseDto) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      createDto.businessId = user.businessId;
    }
    if (!createDto.createdById) {
      createDto.createdById = user.id;
    }
    return this.expensesService.create(createDto);
  }

  @Permissions(Permission.PURCHASE_VIEW)
  @Get()
  findAll(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
    @Query('categoryId') categoryId?: string,
    @Query('search') search?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.expensesService.findAll(bId, {
      branchId,
      categoryId,
      search,
      page: page ? parseInt(page, 10) : undefined,
      limit: limit ? parseInt(limit, 10) : undefined,
    });
  }

  @Permissions(Permission.PURCHASE_VIEW)
  @Get(':id')
  findOne(@Req() req: any, @Param('id') id: string, @Query('businessId') businessId?: string) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.expensesService.findOne(id, bId);
  }

  @Permissions(Permission.PURCHASE_CREATE)
  @Put(':id')
  @ApiBody({ schema: UpdateExpenseBodySchema })
  @ApiResponse({ status: 200, description: 'Expense updated successfully', schema: ExpenseResponseSchema })
  update(@Req() req: any, @Param('id') id: string, @Body() updateDto: UpdateExpenseDto) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      updateDto.businessId = user.businessId;
    }
    if (!updateDto.updatedById) {
      updateDto.updatedById = user.id;
    }
    return this.expensesService.update(id, updateDto);
  }

  @Permissions(Permission.PURCHASE_CREATE)
  @Delete(':id')
  remove(@Req() req: any, @Param('id') id: string, @Query('businessId') businessId?: string) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.expensesService.remove(id, bId);
  }

  @Permissions(Permission.PURCHASE_CREATE)
  @Post(':id/payments')
  @ApiBody({ schema: ExpensePaymentBodySchema })
  @ApiResponse({ status: 201, description: 'Expense payment added successfully' })
  addPayment(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId: string,
    @Body() paymentDto: { amount: number; paymentMethodId: string; notes?: string; paymentDate?: string },
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.expensesService.addPayment(id, bId, paymentDto);
  }

  @Permissions(Permission.PURCHASE_CREATE)
  @Delete('payments/:paymentId')
  deletePayment(
    @Req() req: any,
    @Param('paymentId') paymentId: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.expensesService.deletePayment(paymentId, bId);
  }
}

