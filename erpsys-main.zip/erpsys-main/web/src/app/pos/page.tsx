"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { 
  ArrowLeft, 
  Loader2, 
  ChevronsLeft,
  Clock,
  LayoutGrid,
  XCircle,
  FolderOpen,
  Calculator,
  Barcode,
  RotateCcw,
  Sun,
  Moon,
  Maximize2,
  PauseCircle,
  Monitor,
  CreditCard,
  FileText,
  CheckCircle2 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";

import {
  POSCart,
  POSProductGrid,
  POSPaymentDialog,
  ReceiptPreview,
  POSOrdersDialog,
  POSOrdersTab,
  POSCalculatorDialog,
  useCheckoutMutation,
  useCustomerAdvancesQuery,
  useSaleByIdQuery,
  useSalesQuery,
  useDeleteSaleMutation,
  useUpdateSaleMutation,
  usePosSettingsQuery,
} from "@/features/pos";

import { useProductsQuery, useBranchesQuery } from "@/features/products";
import { useCustomersQuery } from "@/features/customers/hooks/use-customers";
import { usePaymentMethodsQuery } from "@/features/payment-methods/hooks/use-payment-methods";
import {
  useQuotationsQuery,
  useCreateQuotationMutation,
  useDeleteQuotationMutation,
  useQuotationDetailQuery,
  QuotationPreviewDialog,
} from "@/features/quotations";
import { ExpenseDialog } from "@/features/expenses";
import { useCurrency } from "@/hooks/use-currency";

function POSPageContent() {
  const router = useRouter();
  
  // Auth state
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [selectedBranchId, setSelectedBranchId] = useState<string>(() => {
    if (typeof window !== "undefined") {
      return authService.getSelectedBranchId() || "";
    }
    return "";
  });

  // Theme management state & effect
  const [theme, setTheme] = useState("dark");

  useEffect(() => {
    const savedTheme = localStorage.getItem("theme") || "dark";
    setTheme(savedTheme);
    if (savedTheme === "light") {
      document.documentElement.classList.add("light");
    } else {
      document.documentElement.classList.remove("light");
    }
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === "dark" ? "light" : "dark";
    setTheme(newTheme);
    localStorage.setItem("theme", newTheme);
    if (newTheme === "light") {
      document.documentElement.className = "light";
    } else {
      document.documentElement.className = "";
    }
  };

  // Cart & Discount states
  const [cartItems, setCartItems] = useState<any[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState("");
  const [discountType, setDiscountType] = useState<"FIXED" | "PERCENTAGE">("FIXED");
  const [discountAmount, setDiscountAmount] = useState(0);
  const [useAdvance, setUseAdvance] = useState(false);
  const [activeDraftId, setActiveDraftId] = useState<string | null>(null);
  const [activeQuotationId, setActiveQuotationId] = useState<string | null>(null);
  const [activeEditSaleId, setActiveEditSaleId] = useState<string | null>(null);
  const [editingInvoiceNumber, setEditingInvoiceNumber] = useState<string | null>(null);

  // Dialog states
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [paymentMethodForDialog, setPaymentMethodForDialog] = useState<string | null>(null);
  const [isReceiptOpen, setIsReceiptOpen] = useState(false);
  const [completedSale, setCompletedSale] = useState<any>(null);
  const [isExpenseOpen, setIsExpenseOpen] = useState(false);
  const [isOrdersDialogOpen, setIsOrdersDialogOpen] = useState(false);
  const [ordersDialogTab, setOrdersDialogTab] = useState<POSOrdersTab>("HOLD");
  const [previewQuotation, setPreviewQuotation] = useState<any>(null);
  const [isCalculatorOpen, setIsCalculatorOpen] = useState(false);

  const openOrdersDialog = (tab: POSOrdersTab) => {
    setOrdersDialogTab(tab);
    setIsOrdersDialogOpen(true);
  };

  // Auth check
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      router.push("/login");
    }
  }, [router]);

  const businessId = currentUser?.businessId || "";
  const { format } = useCurrency(businessId);

  // Fetch POS Settings for dynamic customization and keyboard shortcuts
  const { data: posSettings } = usePosSettingsQuery(businessId, selectedBranchId);

  const searchShortcut = posSettings?.searchShortcut || "F1";
  const checkoutShortcut = posSettings?.checkoutShortcut || "F2";
  const cashShortcut = posSettings?.cashShortcut || "F4";
  const cardShortcut = posSettings?.cardShortcut || "F8";
  const holdShortcut = posSettings?.holdShortcut || "F6";
  const cancelShortcut = posSettings?.cancelShortcut || "Escape";

  // Fetch payment methods
  const { data: paymentMethods = [] } = usePaymentMethodsQuery(
    businessId,
    selectedBranchId || undefined,
    true
  );

  const cashPaymentMethod = React.useMemo(() => {
    return (
      paymentMethods.find((pm: any) => pm.name.toLowerCase().includes("cash")) ||
      paymentMethods[0]
    );
  }, [paymentMethods]);

  const cardPaymentMethod = React.useMemo(() => {
    return paymentMethods.find(
      (pm: any) =>
        pm.name.toLowerCase().includes("card") ||
        pm.name.toLowerCase().includes("credit") ||
        pm.name.toLowerCase().includes("debit") ||
        pm.name.toLowerCase().includes("pos")
    );
  }, [paymentMethods]);

  // Fetch branches
  const { data: branches = [] } = useBranchesQuery(businessId, currentUser?.id);

  // Set default branch or restore saved branch
  useEffect(() => {
    if (branches.length > 0) {
      const savedBranchId = authService.getSelectedBranchId();
      const isValidSaved = savedBranchId && branches.some((b: any) => b.id === savedBranchId);

      if (isValidSaved) {
        if (selectedBranchId !== savedBranchId) {
          setSelectedBranchId(savedBranchId);
        }
      } else if (!selectedBranchId) {
        const defaultBranch = branches[0].id;
        setSelectedBranchId(defaultBranch);
        authService.setSelectedBranchId(defaultBranch);
      }
    }
  }, [branches, selectedBranchId]);

  // Listen for external branch change events
  useEffect(() => {
    const handleBranchChange = (e: any) => {
      const newBranchId = e.detail;
      if (newBranchId && newBranchId !== selectedBranchId) {
        setSelectedBranchId(newBranchId);
      }
    };
    window.addEventListener("hkr_branch_changed", handleBranchChange);
    return () => window.removeEventListener("hkr_branch_changed", handleBranchChange);
  }, [selectedBranchId]);

  // Fetch products for selected branch
  const { data: productsList = [], isLoading: productsLoading } = useProductsQuery(
    businessId,
    selectedBranchId || undefined
  );

  // Compute live branch stock for a variant
  const getVariantStock = React.useCallback((variantId: string) => {
    if (!productsList || productsList.length === 0) return 999;
    for (const prod of productsList) {
      const v = (prod as any).variants?.find((item: any) => item.id === variantId);
      if (v) {
        if (!prod.enableStock) return 9999;
        if (v.purchaseLines) {
          return v.purchaseLines
            .filter((line: any) => !selectedBranchId || line.branchId === selectedBranchId)
            .reduce((sum: number, line: any) => sum + (line.quantityRemaining || 0), 0);
        }
      }
    }
    return 999;
  }, [productsList, selectedBranchId]);

  // Fetch customers for default selection
  const { data: customersList = [] } = useCustomersQuery(businessId, selectedBranchId || undefined);

  // Set default customer to Walk-in Customer from the database
  useEffect(() => {
    if (customersList.length > 0 && !selectedCustomerId) {
      const walkIn = customersList.find((c: any) => c.name.toLowerCase() === "walk-in customer");
      if (walkIn) {
        setSelectedCustomerId(walkIn.id);
      }
    }
  }, [customersList, selectedCustomerId]);

  // Fetch customer advance if customer selected
  const { data: customerAdvances = [] } = useCustomerAdvancesQuery(
    selectedCustomerId,
    businessId
  );

  const searchParams = useSearchParams();
  const holdId = searchParams.get("holdId") || searchParams.get("draftId");
  const quotationId = searchParams.get("quotationId");
  const editSaleId = searchParams.get("editSaleId");

  // Fetch hold sales for current branch to show badge count
  const { data: holdSalesResponse } = useSalesQuery(
    businessId,
    {
      branchId: selectedBranchId || undefined,
      status: "HOLD",
      limit: 100,
    },
    { enabled: !!businessId && !!selectedBranchId }
  );
  const holdBillsCount = holdSalesResponse?.data?.length || 0;

  // Fetch quotations for current branch to show badge count
  const { data: quotationsResponse } = useQuotationsQuery(
    {
      branchId: selectedBranchId || undefined,
      status: "PENDING",
      limit: 100,
    },
    { enabled: !!selectedBranchId }
  );
  const quotationsCount = quotationsResponse?.data?.length || 0;

  // Fetch hold details if holdId query param is present
  const { data: holdData } = useSaleByIdQuery(
    holdId || "",
    businessId
  );

  // Fetch quotation details if quotationId query param is present
  const { data: quotationData } = useQuotationDetailQuery(quotationId || "");

  // Fetch sale details if editSaleId query param is present
  const { data: editSaleData } = useSaleByIdQuery(editSaleId || "", businessId);

  // Load hold items into cart
  useEffect(() => {
    if (holdData && holdId && activeDraftId !== holdId) {
      setActiveDraftId(holdId);
      setSelectedCustomerId(holdData.customerId);
      setSelectedBranchId(holdData.branchId);
      setDiscountType(holdData.discountType || "FIXED");
      setDiscountAmount(holdData.discountAmount || 0);

      const items = (holdData.saleLines || []).map((line: any) => ({
        variantId: line.variantId,
        variantName: line.variant?.name || "Product",
        sku: line.variant?.sku || "",
        barcode: line.variant?.barcode || "",
        productName: line.variant?.product?.name || line.variant?.name || "Product",
        quantity: line.quantity,
        unitPrice: line.unitPrice,
        discountAmount: line.discountAmount || 0,
        taxAmount: line.taxAmount || 0,
        subtotal: line.subtotal,
        stockAvailable: getVariantStock(line.variantId),
        imageUrl: line.variant?.product?.imageUrl || null,
      }));
      setCartItems(items);
    }
  }, [holdData, holdId, activeDraftId, getVariantStock]);

  // Load quotation items into cart
  useEffect(() => {
    if (quotationData && quotationId && activeQuotationId !== quotationId) {
      setActiveQuotationId(quotationId);
      setSelectedCustomerId(quotationData.customerId);
      setSelectedBranchId(quotationData.branchId);
      setDiscountAmount(quotationData.discountAmount || 0);

      const items = (quotationData.quotationLines || []).map((line: any) => ({
        variantId: line.variantId,
        variantName: line.variant?.name || "Product",
        sku: line.variant?.sku || "",
        barcode: "",
        productName: line.variant?.product?.name || line.variant?.name || "Product",
        quantity: line.quantity,
        unitPrice: line.unitPrice,
        discountAmount: line.discountAmount || 0,
        taxAmount: line.taxAmount || 0,
        subtotal: line.subtotal,
        stockAvailable: getVariantStock(line.variantId),
        imageUrl: null,
      }));
      setCartItems(items);
    }
  }, [quotationData, quotationId, activeQuotationId, getVariantStock]);

  // Load sale items for editing into cart
  useEffect(() => {
    if (editSaleData && editSaleId && activeEditSaleId !== editSaleId) {
      setActiveEditSaleId(editSaleId);
      setEditingInvoiceNumber(editSaleData.invoiceNumber);
      setSelectedCustomerId(editSaleData.customerId);
      setSelectedBranchId(editSaleData.branchId);
      setDiscountType(editSaleData.discountType || "FIXED");
      setDiscountAmount(editSaleData.discountAmount || 0);

      const items = (editSaleData.saleLines || []).map((line: any) => ({
        variantId: line.variantId,
        variantName: line.variant?.name || "Product",
        sku: line.variant?.sku || "",
        barcode: line.variant?.barcode || "",
        productName: line.variant?.product?.name || line.variant?.name || "Product",
        quantity: line.quantity,
        unitPrice: line.unitPrice,
        discountAmount: line.discountAmount || 0,
        taxAmount: line.taxAmount || 0,
        subtotal: line.subtotal,
        stockAvailable: getVariantStock(line.variantId),
        imageUrl: line.variant?.product?.imageUrl || null,
        isImei: !!(line.variant?.product?.isImei || line.variant?.product?.enableImei || line.imeiNumber),
        imeiNumber: line.imeiNumber || (line.productImeis && line.productImeis[0]?.imeiNumber),
      }));
      setCartItems(items);
    }
  }, [editSaleData, editSaleId, activeEditSaleId, getVariantStock]);

  const handleCancelEdit = () => {
    setActiveEditSaleId(null);
    setEditingInvoiceNumber(null);
    handleClearCart();
    router.replace("/pos");
  };

  const customerAdvanceBalance = React.useMemo(() => {
    if (!customerAdvances || !Array.isArray(customerAdvances)) return 0;
    return customerAdvances.reduce((sum: number, adv: any) => sum + adv.amountRemaining, 0);
  }, [customerAdvances]);

  // Mutations
  const checkoutMutation = useCheckoutMutation();
  const updateSaleMutation = useUpdateSaleMutation();
  const deleteSaleMutation = useDeleteSaleMutation();
  const createQuotationMutation = useCreateQuotationMutation();
  const deleteQuotationMutation = useDeleteQuotationMutation();

  // Add to cart handler
  const handleAddToCart = (variant: any, imeiNumber?: string) => {
    setCartItems((prev) => {
      // If adding serialized product with an IMEI
      if (variant.isImei && imeiNumber) {
        if (prev.some((item) => item.imeiNumber === imeiNumber)) {
          alert(`IMEI ${imeiNumber} is already in the cart.`);
          return prev;
        }
        return [
          ...prev,
          {
            variantId: variant.id,
            variantName: variant.name,
            sku: variant.sku,
            barcode: variant.barcode,
            productName: variant.productName,
            quantity: 1,
            unitPrice: variant.sellingPrice,
            discountAmount: 0,
            taxAmount: 0,
            subtotal: variant.sellingPrice,
            stockAvailable: variant.stock,
            imageUrl: variant.imageUrl,
            isImei: true,
            imeiNumber,
          },
        ];
      }

      // Non-IMEI item
      const existing = prev.find((item) => item.variantId === variant.id && !item.imeiNumber);
      if (existing) {
        if (variant.enableStock && existing.quantity >= variant.stock) {
          alert(`Cannot add more. Only ${variant.stock} items left in stock.`);
          return prev;
        }
        return prev.map((item) =>
          item.variantId === variant.id && !item.imeiNumber
            ? {
                ...item,
                quantity: item.quantity + 1,
                subtotal: (item.quantity + 1) * item.unitPrice,
              }
            : item
        );
      }
      return [
        ...prev,
        {
          variantId: variant.id,
          variantName: variant.name,
          sku: variant.sku,
          barcode: variant.barcode,
          productName: variant.productName,
          quantity: 1,
          unitPrice: variant.sellingPrice,
          discountAmount: 0,
          taxAmount: 0,
          subtotal: variant.sellingPrice,
          stockAvailable: variant.stock,
          imageUrl: variant.imageUrl,
          isImei: !!variant.isImei,
        },
      ];
    });
  };

  // Update quantity handler
  const handleUpdateQty = (variantId: string, quantity: number, imeiNumber?: string) => {
    if (quantity <= 0) {
      handleRemoveItem(variantId, imeiNumber);
      return;
    }

    setCartItems((prev) =>
      prev.map((item) => {
        const isMatch = imeiNumber
          ? item.variantId === variantId && item.imeiNumber === imeiNumber
          : item.variantId === variantId && !item.imeiNumber;

        if (isMatch) {
          if (item.isImei || item.imeiNumber) {
            return item; // IMEI item quantity is strictly 1 per IMEI
          }
          if (item.stockAvailable !== undefined && quantity > item.stockAvailable) {
            alert(`Cannot update quantity. Only ${item.stockAvailable} items left in stock.`);
            return item;
          }
          return {
            ...item,
            quantity,
            subtotal: quantity * item.unitPrice,
          };
        }
        return item;
      })
    );
  };

  // Remove item handler
  const handleRemoveItem = (variantId: string, imeiNumber?: string) => {
    setCartItems((prev) =>
      prev.filter((item) => {
        if (imeiNumber) {
          return !(item.variantId === variantId && item.imeiNumber === imeiNumber);
        }
        return item.variantId !== variantId;
      })
    );
  };

  // Clear cart
  const handleClearCart = () => {
    setCartItems([]);
    const defaultCustomer = customersList.find(
      (c: any) => c.isDefault || c.name?.toLowerCase() === "walk-in customer"
    );
    setSelectedCustomerId(defaultCustomer?.id || "");
    setDiscountAmount(0);
    setUseAdvance(false);
    setActiveDraftId(null);
    setActiveQuotationId(null);
  };

  // Auto-select Default Customer (from posSettings or Walk-in) when customers list loads
  useEffect(() => {
    if (customersList.length > 0 && !selectedCustomerId) {
      if (posSettings?.defaultCustomerId) {
        const found = customersList.find((c: any) => c.id === posSettings.defaultCustomerId);
        if (found) {
          setSelectedCustomerId(found.id);
          return;
        }
      }
      const defaultCustomer = customersList.find(
        (c: any) => c.isDefault || c.name?.toLowerCase() === "walk-in customer"
      );
      if (defaultCustomer) {
        setSelectedCustomerId(defaultCustomer.id);
      }
    }
  }, [customersList, selectedCustomerId, posSettings]);

  // Calculations
  const subtotal = cartItems.reduce((sum, item) => sum + item.subtotal, 0);
  const discountVal = React.useMemo(() => {
    if (discountType === "PERCENTAGE") {
      return (subtotal * discountAmount) / 100;
    }
    return discountAmount;
  }, [subtotal, discountType, discountAmount]);
  const grandTotal = Math.max(0, subtotal - discountVal);

  // Submit checkout or update
  const handleCheckoutSubmit = (payments: any[]) => {
    if (!selectedBranchId) return;

    if (activeEditSaleId) {
      const updatePayload = {
        customerId: selectedCustomerId || "walk-in",
        discountType,
        discountAmount,
        taxAmount: 0,
        grandTotal,
        saleLines: cartItems.map((item) => ({
          variantId: item.variantId,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          discountAmount: item.discountAmount || 0,
          taxAmount: item.taxAmount || 0,
          imeiNumber: item.imeiNumber,
          imeis: item.imeiNumber ? [item.imeiNumber] : (item.imeis || undefined),
        })),
        payments: payments.map((p: any) => ({
          amount: p.amount,
          paymentMethodId: p.paymentMethodId,
          transactionNo: p.transactionNo,
          notes: p.notes,
        })),
      };

      updateSaleMutation.mutate(
        { id: activeEditSaleId, payload: updatePayload, businessId },
        {
          onSuccess: (data) => {
            alert(`Invoice ${editingInvoiceNumber} updated successfully!`);
            setActiveEditSaleId(null);
            setEditingInvoiceNumber(null);
            setCompletedSale(data);
            setIsPaymentOpen(false);
            setIsReceiptOpen(true);
            handleClearCart();
            router.replace("/pos");
          },
          onError: (err: any) => {
            alert(err.message || "Failed to update sale.");
          },
        }
      );
      return;
    }

    const payload = {
      customerId: selectedCustomerId || "walk-in",
      branchId: selectedBranchId,
      businessId,
      discountType,
      discountAmount,
      grandTotal,
      status: "FINAL" as const,
      saleLines: cartItems.map((item) => ({
        variantId: item.variantId,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        discountAmount: item.discountAmount,
        taxAmount: item.taxAmount,
        imeiNumber: item.imeiNumber,
        imeis: item.imeiNumber ? [item.imeiNumber] : (item.imeis || undefined),
      })),
      payments,
      useAdvance,
      createdById: currentUser?.id,
    };

    checkoutMutation.mutate(payload, {
      onSuccess: (data) => {
        if (activeDraftId) {
          deleteSaleMutation.mutate({ id: activeDraftId, businessId });
          setActiveDraftId(null);
          router.replace("/pos");
        }
        if (activeQuotationId) {
          deleteQuotationMutation.mutate(activeQuotationId);
          setActiveQuotationId(null);
          router.replace("/pos");
        }
        setCompletedSale(data);
        setIsPaymentOpen(false);
        setIsReceiptOpen(true);
        handleClearCart();
      },
      onError: (err: any) => {
        alert(err.message || "Failed to checkout. Please try again.");
      },
    });
  };

  const handleOpenPayment = (methodId?: string | null) => {
    if (cartItems.length === 0) return;
    setPaymentMethodForDialog(methodId || posSettings?.defaultPaymentMethodId || null);

    if (activeEditSaleId && editSaleData) {
      const alreadyPaid = editSaleData.amountPaid || 0;
      if (grandTotal <= alreadyPaid) {
        if (
          confirm(
            `Invoice ${editingInvoiceNumber} total is ${format(grandTotal)} (already paid: ${format(alreadyPaid)}). Save changes now?`
          )
        ) {
          handleCheckoutSubmit([]);
          return;
        }
      }
    }
    setIsPaymentOpen(true);
  };

  // Hold invoice
  const handleHoldDraft = () => {
    if (!selectedBranchId) return;

    if (cartItems.length === 0) {
      alert("Cart is empty! Add products before placing on hold.");
      return;
    }

    const payload = {
      customerId: selectedCustomerId || "walk-in",
      branchId: selectedBranchId,
      businessId,
      discountType,
      discountAmount,
      grandTotal,
      status: "HOLD" as const,
      saleLines: cartItems.map((item) => ({
        variantId: item.variantId,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        imeiNumber: item.imeiNumber,
        imeis: item.imeiNumber ? [item.imeiNumber] : (item.imeis || undefined),
      })),
      payments: [],
      useAdvance: false,
      createdById: currentUser?.id,
    };

    checkoutMutation.mutate(payload, {
      onSuccess: () => {
        if (activeDraftId) {
          deleteSaleMutation.mutate({ id: activeDraftId, businessId });
          setActiveDraftId(null);
          router.replace("/pos");
        }
        if (activeQuotationId) {
          deleteQuotationMutation.mutate(activeQuotationId);
          setActiveQuotationId(null);
          router.replace("/pos");
        }
        alert("Bill placed on Hold successfully!");
        handleClearCart();
      },
      onError: (err: any) => {
        alert(err.message || "Failed to place bill on hold.");
      },
    });
  };

  // Resume held bill into active cart
  const handleResumeHoldBill = (sale: any) => {
    setActiveDraftId(sale.id);
    setSelectedCustomerId(sale.customerId);
    setSelectedBranchId(sale.branchId);
    setDiscountType(sale.discountType || "FIXED");
    setDiscountAmount(sale.discountAmount || 0);

    const items = (sale.saleLines || []).map((line: any) => ({
      variantId: line.variantId,
      variantName: line.variant?.name || "Product",
      sku: line.variant?.sku || "",
      barcode: line.variant?.barcode || "",
      productName: line.variant?.product?.name || line.variant?.name || "Product",
      quantity: line.quantity,
      unitPrice: line.unitPrice,
      discountAmount: line.discountAmount || 0,
      taxAmount: line.taxAmount || 0,
      subtotal: line.subtotal || line.quantity * line.unitPrice,
      stockAvailable: getVariantStock(line.variantId),
      imageUrl: line.variant?.product?.imageUrl || null,
    }));

    setCartItems(items);
    setIsOrdersDialogOpen(false);
  };

  // Delete held bill
  const handleDeleteHoldBill = (saleId: string) => {
    if (!confirm("Are you sure you want to delete this hold bill?")) return;
    deleteSaleMutation.mutate({ id: saleId, businessId });
  };

  // Save Cart as Price Quotation (like Hold, but does not affect inventory)
  const handleCreateQuotation = async () => {
    if (!selectedBranchId) return;

    if (cartItems.length === 0) {
      alert("Cart is empty! Add products before creating a quotation.");
      return;
    }

    const payload = {
      customerId: selectedCustomerId || "walk-in",
      branchId: selectedBranchId,
      discountType,
      discountAmount: discountVal,
      taxAmount: 0,
      grandTotal,
      quotationLines: cartItems.map((item) => ({
        variantId: item.variantId,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        discountAmount: item.discountAmount || 0,
        taxAmount: item.taxAmount || 0,
        subtotal: item.subtotal,
      })),
    };

    try {
      const created = await createQuotationMutation.mutateAsync(payload);
      alert(`Quotation ${created.quotationNumber} created successfully!`);
      setPreviewQuotation(created);
      handleClearCart();
    } catch (err: any) {
      alert(err.message || "Failed to create quotation.");
    }
  };

  // Resume quotation into active cart
  const handleResumeQuotation = (q: any) => {
    setActiveQuotationId(q.id);
    setSelectedCustomerId(q.customerId);
    setSelectedBranchId(q.branchId);
    setDiscountAmount(q.discountAmount || 0);

    const items = (q.quotationLines || []).map((line: any) => ({
      variantId: line.variantId,
      variantName: line.variant?.name || "Product",
      sku: line.variant?.sku || "",
      barcode: "",
      productName: line.variant?.product?.name || line.variant?.name || "Product",
      quantity: line.quantity,
      unitPrice: line.unitPrice,
      discountAmount: line.discountAmount || 0,
      taxAmount: line.taxAmount || 0,
      subtotal: line.subtotal,
      stockAvailable: getVariantStock(line.variantId),
      imageUrl: null,
    }));

    setCartItems(items);
    setIsOrdersDialogOpen(false);
  };

  // Delete quotation
  const handleDeleteQuotation = (id: string, number: string) => {
    if (!confirm(`Are you sure you want to delete quotation ${number}?`)) return;
    deleteQuotationMutation.mutate(id);
  };

  // Keyboard shortcut listener dynamically bound to POS settings
  useEffect(() => {
    const isMatch = (e: KeyboardEvent, shortcut: string) => {
      if (!shortcut) return false;
      return e.key.trim().toLowerCase() === shortcut.trim().toLowerCase();
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      // 1. Search shortcut
      if (isMatch(e, searchShortcut)) {
        e.preventDefault();
        const searchInput = document.querySelector('input[placeholder*="Search by name"]') as HTMLInputElement;
        if (searchInput) searchInput.focus();
        return;
      }

      // 2. Checkout shortcut
      if (isMatch(e, checkoutShortcut)) {
        if (cartItems.length > 0 && !isPaymentOpen) {
          e.preventDefault();
          handleOpenPayment(posSettings?.defaultPaymentMethodId || null);
        }
        return;
      }

      // 3. Direct Cash Pay shortcut
      if (isMatch(e, cashShortcut)) {
        if (cartItems.length > 0 && !isPaymentOpen) {
          e.preventDefault();
          handleOpenPayment(cashPaymentMethod?.id || null);
        }
        return;
      }

      // 4. Direct Card Pay shortcut
      if (isMatch(e, cardShortcut)) {
        if (cartItems.length > 0 && !isPaymentOpen) {
          e.preventDefault();
          handleOpenPayment(cardPaymentMethod?.id || null);
        }
        return;
      }

      // 5. Hold shortcut
      if (isMatch(e, holdShortcut)) {
        if (cartItems.length > 0 && !isPaymentOpen) {
          e.preventDefault();
          handleHoldDraft();
        }
        return;
      }

      // 6. Cancel / Escape shortcut
      if (isMatch(e, cancelShortcut)) {
        if (isPaymentOpen) {
          setIsPaymentOpen(false);
          return;
        }
        if (isOrdersDialogOpen) {
          setIsOrdersDialogOpen(false);
          return;
        }
        if (isCalculatorOpen) {
          setIsCalculatorOpen(false);
          return;
        }
        if (isReceiptOpen) {
          setIsReceiptOpen(false);
          return;
        }
        if (isExpenseOpen) {
          setIsExpenseOpen(false);
          return;
        }
        if (previewQuotation) {
          setPreviewQuotation(null);
          return;
        }
        if (cartItems.length > 0) {
          if (confirm("Are you sure you want to clear the active cart?")) {
            handleClearCart();
          }
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [
    cartItems,
    isPaymentOpen,
    isOrdersDialogOpen,
    isCalculatorOpen,
    isReceiptOpen,
    isExpenseOpen,
    previewQuotation,
    searchShortcut,
    checkoutShortcut,
    cashShortcut,
    cardShortcut,
    holdShortcut,
    cancelShortcut,
    cashPaymentMethod,
    cardPaymentMethod,
    posSettings,
  ]);

  const topBarButtons = [
    {
      icon: (
        <div className="relative flex items-center justify-center">
          <Clock className="h-[18px] w-[18px] text-primary" strokeWidth={1.75} />
          {holdBillsCount > 0 && (
            <span className="absolute -top-1.5 -right-2 bg-amber-500 text-black text-[9px] font-black rounded-full h-4 min-w-4 px-1 flex items-center justify-center border-2 border-background">
              {holdBillsCount}
            </span>
          )}
        </div>
      ),
      tooltip: `Hold Bills (${holdBillsCount})`,
      onClick: () => openOrdersDialog("HOLD"),
    },
    {
      icon: (
        <div className="relative flex items-center justify-center">
          <FileText className="h-[18px] w-[18px] text-primary" strokeWidth={1.75} />
          {quotationsCount > 0 && (
            <span className="absolute -top-1.5 -right-2 bg-emerald-500 text-black text-[9px] font-black rounded-full h-4 min-w-4 px-1 flex items-center justify-center border-2 border-background">
              {quotationsCount}
            </span>
          )}
        </div>
      ),
      tooltip: `Quotations (${quotationsCount})`,
      onClick: () => openOrdersDialog("QUOTATION"),
    },
    {
      icon: (
        <div className="relative flex items-center justify-center">
          <CheckCircle2 className="h-[18px] w-[18px] text-primary" strokeWidth={1.75} />
        </div>
      ),
      tooltip: "Recent Transactions",
      onClick: () => openOrdersDialog("FINAL"),
    },
    { icon: <LayoutGrid className="h-[18px] w-[18px] text-primary" strokeWidth={1.75} />, tooltip: "Switch to Apps", onClick: () => router.push("/dashboard") },
    { icon: <XCircle className="h-[18px] w-[18px] text-primary" strokeWidth={1.75} />, tooltip: "Close POS Terminal", onClick: () => router.push("/dashboard") },
    { 
      icon: <FolderOpen className="h-[18px] w-[18px] text-primary" strokeWidth={1.75} />, 
      tooltip: "Open Cash Drawer", 
      onClick: () => {
        if ((window as any).electronAPI?.openCashDrawer) {
          (window as any).electronAPI.openCashDrawer();
        } else {
          alert("Cash drawer signal sent.");
        }
      } 
    },
    { 
      icon: <Calculator className="h-[18px] w-[18px] text-primary" strokeWidth={1.75} />, 
      tooltip: "Open Calculator", 
      onClick: () => setIsCalculatorOpen(true) 
    },
    { 
      icon: <Barcode className="h-[18px] w-[18px] text-primary" strokeWidth={1.75} />, 
      tooltip: `Focus Barcode Search (${searchShortcut})`, 
      onClick: () => {
        const searchInput = document.querySelector('input[placeholder*="Search by name"]') as HTMLInputElement;
        if (searchInput) searchInput.focus();
      } 
    },
    { icon: <RotateCcw className="h-[18px] w-[18px] text-primary" strokeWidth={1.75} />, tooltip: `Reset Cart (${cancelShortcut})`, onClick: handleClearCart },
    { 
      icon: theme === "dark" ? (
        <Sun className="h-[18px] w-[18px] text-primary" strokeWidth={1.75} />
      ) : (
        <Moon className="h-[18px] w-[18px] text-primary" strokeWidth={1.75} />
      ), 
      tooltip: theme === "dark" ? "Switch to Light Mode" : "Switch to Dark Mode", 
      onClick: toggleTheme 
    },
    { icon: <Maximize2 className="h-[18px] w-[18px] text-primary" strokeWidth={1.75} />, tooltip: "Toggle Fullscreen", onClick: () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().catch(() => {});
        } else {
          document.exitFullscreen().catch(() => {});
        }
      } 
    },
    { icon: <PauseCircle className="h-[18px] w-[18px] text-primary" strokeWidth={1.75} />, tooltip: `Hold Current Bill (${holdShortcut})`, onClick: handleHoldDraft },
    { icon: <Monitor className="h-[18px] w-[18px] text-primary" strokeWidth={1.75} />, tooltip: "Display Settings", onClick: () => alert("Display configured") },
  ];

  if (isAuthenticated === null || !currentUser) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-background text-foreground">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-sm font-semibold">Checking authentication...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-background text-foreground overflow-hidden">
      
      {/* Top Header Bar */}
      <header className="h-14 px-6 border-b border-border flex items-center justify-between shrink-0 bg-background/50 backdrop-blur-sm z-10">
        <div className="flex items-center gap-4">
          <h1 className="text-sm font-bold uppercase tracking-wider text-foreground">
            POS Billing Terminal
          </h1>
        </div>

        {/* Top Bar Quick Action Buttons Tray */}
        <div className="hidden xl:flex items-center gap-1.5">
          {/* Home Button with Text */}
          <button
            onClick={() => router.push("/dashboard")}
            className="h-9 px-3 flex items-center gap-1.5 rounded bg-background/50 border border-border hover:bg-muted hover:border-primary/60 transition-all active:scale-95 shadow-sm text-xs font-bold text-primary"
            title="Back to Dashboard"
          >
            <ChevronsLeft className="h-[16px] w-[16px]" strokeWidth={2} />
            <span>Home</span>
          </button>

          {topBarButtons.map((btn, idx) => (
            <button
              key={idx}
              onClick={btn.onClick}
              title={btn.tooltip}
              className="h-9 w-9 flex items-center justify-center rounded bg-background/50 border border-border hover:bg-muted hover:border-primary/60 transition-all active:scale-95 shadow-sm"
            >
              {btn.icon}
            </button>
          ))}

          {/* Add Expense Button with Text */}
          <button
            onClick={() => setIsExpenseOpen(true)}
            className="h-9 px-3 flex items-center gap-1.5 rounded bg-background/50 border border-border hover:bg-muted hover:border-primary/60 transition-all active:scale-95 shadow-sm text-xs font-bold text-primary"
            title="Add Expense"
          >
            <CreditCard className="h-[16px] w-[16px]" strokeWidth={2} />
            <span>Add Expense</span>
          </button>
        </div>

        {/* Branch Selector & Cashier */}
        <div className="flex items-center gap-4">
          {branches.length > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                Branch:
              </span>
              <Select
                value={selectedBranchId}
                onValueChange={(val) => {
                  setSelectedBranchId(val);
                  authService.setSelectedBranchId(val);
                }}
                className="h-9 text-xs font-semibold bg-background/60 border border-input rounded-sm min-w-[150px]"
              >
                {branches.map((b: any) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </Select>
            </div>
          )}

          <div className="h-5 w-[1px] bg-border" />
          <div className="text-right">
            <span className="text-[10px] font-semibold text-muted-foreground block leading-tight">
              Cashier
            </span>
            <span className="text-xs font-bold text-foreground block">
              {currentUser.name}
            </span>
          </div>
        </div>
      </header>

      {/* Main Billing Grid */}
      <main className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-12 gap-3 p-3">
        
        {/* Left Column: Cart list and Summary */}
        <section className="lg:col-span-5 min-h-0 flex flex-col">
          <POSCart
            cartItems={cartItems}
            onUpdateQty={handleUpdateQty}
            onRemoveItem={handleRemoveItem}
            onClearCart={handleClearCart}
            selectedCustomerId={selectedCustomerId}
            onCustomerChange={setSelectedCustomerId}
            discountType={discountType}
            onDiscountTypeChange={setDiscountType}
            discountAmount={discountAmount}
            onDiscountAmountChange={setDiscountAmount}
            businessId={businessId}
            branchId={selectedBranchId}
            onOpenPayment={handleOpenPayment}
            onHold={handleHoldDraft}
            onQuotation={handleCreateQuotation}
            isPending={checkoutMutation.isPending || updateSaleMutation.isPending || createQuotationMutation.isPending}
            branches={branches}
            currentUser={currentUser}
            editingInvoiceNumber={editingInvoiceNumber}
            onCancelEdit={handleCancelEdit}
            checkoutShortcut={checkoutShortcut}
            holdShortcut={holdShortcut}
          />
        </section>

        {/* Right Column: Product Selector Grid */}
        <section className="lg:col-span-7 min-h-0 flex flex-col bg-background/20 border border-border p-4 rounded-sm">
          <POSProductGrid
            products={productsList}
            isLoading={productsLoading}
            branchId={selectedBranchId}
            onAddToCart={handleAddToCart}
            businessId={businessId}
            userId={currentUser.id}
          />
        </section>
      </main>

      {/* Checkout and Receipt Dialogs */}
      {(() => {
        const selectedCustomer = customersList.find((c: any) => c.id === selectedCustomerId);
        const isWalkIn = !selectedCustomer || selectedCustomer.isDefault || selectedCustomer.name?.toLowerCase() === "walk-in customer";
        const allowCredit = isWalkIn ? false : (selectedCustomer.allowCredit ?? true);

        const opening = selectedCustomer?.openingBalance || 0;
        const unpaidSales = selectedCustomer?.sales?.filter((s: any) => s.status === "FINAL" || !s.status) || [];
        const totalSales = unpaidSales.reduce((sum: number, s: any) => sum + (s.grandTotal || 0), 0);
        const totalPaid = unpaidSales.reduce((sum: number, s: any) => sum + (s.amountPaid || 0), 0);
        const currentDue = Math.max(0, (totalSales + opening) - totalPaid);

        return (
          <POSPaymentDialog
            isOpen={isPaymentOpen}
            onClose={() => {
              setIsPaymentOpen(false);
              setPaymentMethodForDialog(null);
            }}
            grandTotal={grandTotal}
            businessId={businessId}
            branchId={selectedBranchId}
            customerAdvanceBalance={customerAdvanceBalance}
            useAdvance={useAdvance}
            onUseAdvanceChange={setUseAdvance}
            onCheckout={handleCheckoutSubmit}
            isPending={checkoutMutation.isPending}
            allowCredit={allowCredit}
            customerName={selectedCustomer?.name || "Walk-in Customer"}
            creditLimit={selectedCustomer?.creditLimit}
            currentOutstandingDue={currentDue}
            defaultPaymentMethodId={posSettings?.defaultPaymentMethodId}
            initialPaymentMethodId={paymentMethodForDialog}
          />
        );
      })()}

      <ReceiptPreview
        isOpen={isReceiptOpen}
        onClose={() => setIsReceiptOpen(false)}
        sale={completedSale}
        businessName={currentUser.business?.name || "HKR ERP Store"}
      />

      <ExpenseDialog
        isOpen={isExpenseOpen}
        onClose={() => setIsExpenseOpen(false)}
        currentUser={currentUser}
        onSuccess={(msg) => alert(msg)}
        onError={(msg) => alert(msg)}
      />

      <POSOrdersDialog
        isOpen={isOrdersDialogOpen}
        onClose={() => setIsOrdersDialogOpen(false)}
        initialTab={ordersDialogTab}
        businessId={businessId}
        branchId={selectedBranchId}
        onResumeHoldBill={handleResumeHoldBill}
        onDeleteHoldBill={handleDeleteHoldBill}
        isDeletingHold={deleteSaleMutation.isPending}
        onResumeQuotation={handleResumeQuotation}
        onPreviewQuotation={(q) => setPreviewQuotation(q)}
        onDeleteQuotation={handleDeleteQuotation}
        isDeletingQuotation={deleteQuotationMutation.isPending}
        onViewReceipt={(sale) => {
          setCompletedSale(sale);
          setIsReceiptOpen(true);
        }}
        onEditSale={(sale) => {
          setActiveEditSaleId(sale.id);
          setEditingInvoiceNumber(sale.invoiceNumber);
          setSelectedCustomerId(sale.customerId);
          setSelectedBranchId(sale.branchId);
          setDiscountType(sale.discountType || "FIXED");
          setDiscountAmount(sale.discountAmount || 0);

          const items = (sale.saleLines || []).map((line: any) => ({
            variantId: line.variantId,
            variantName: line.variant?.name || "Product",
            sku: line.variant?.sku || "",
            barcode: line.variant?.barcode || "",
            productName: line.variant?.product?.name || line.variant?.name || "Product",
            quantity: line.quantity,
            unitPrice: line.unitPrice,
            discountAmount: line.discountAmount || 0,
            taxAmount: line.taxAmount || 0,
            subtotal: line.subtotal || line.quantity * line.unitPrice,
            stockAvailable: getVariantStock(line.variantId),
            imageUrl: line.variant?.product?.imageUrl || null,
            isImei: !!(line.variant?.product?.isImei || line.variant?.product?.enableImei || line.imeiNumber),
            imeiNumber: line.imeiNumber || (line.productImeis && line.productImeis[0]?.imeiNumber),
          }));
          setCartItems(items);
        }}
        onDeleteFinalSale={(saleId, invoiceNumber) => {
          if (
            confirm(
              `Are you sure you want to delete invoice "${invoiceNumber}"?\n\nThis will restore all items back into inventory stock and permanently remove the invoice record.`
            )
          ) {
            deleteSaleMutation.mutate(
              { id: saleId, businessId },
              {
                onSuccess: (res: any) => {
                  alert(res?.message || `Invoice ${invoiceNumber} deleted and stock restored.`);
                },
                onError: (err: any) => {
                  alert(err.message || "Failed to delete sale invoice.");
                },
              }
            );
          }
        }}
      />

      <QuotationPreviewDialog
        isOpen={!!previewQuotation}
        onClose={() => setPreviewQuotation(null)}
        quotation={previewQuotation}
        onConvert={(q) => handleResumeQuotation(q)}
      />

      <POSCalculatorDialog
        isOpen={isCalculatorOpen}
        onClose={() => setIsCalculatorOpen(false)}
      />
    </div>
  );
}

export default function POSPage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen w-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
          <p className="text-sm text-muted-foreground">Loading Terminal...</p>
        </div>
      </div>
    }>
      <POSPageContent />
    </Suspense>
  );
}
