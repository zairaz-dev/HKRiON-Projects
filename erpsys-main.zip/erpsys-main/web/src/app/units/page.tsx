"use strict";
"use client";

import React, { useEffect, useState } from "react";
import {
  Scale,
  Plus,
  Edit2,
  Trash2,
  Loader2,
  CheckCircle,
  AlertCircle,
  X,
  Building2,
  Globe,
  GitCommit,
  Layers
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { DataTable, ColumnDef, ActionsDropdown } from "@/components/ui/table";
import { ActionItem } from "@/components/ui/actions-dropdown";
import { authService } from "@/services/auth-service";
import { branchService } from "@/services/branch-service";
import { unitService } from "@/services/unit-service";
import { User } from "@hkr/types";

interface BranchItem {
  id: string;
  name: string;
}

interface UnitBranchItem {
  branchId: string;
  branch: BranchItem;
}

interface UnitItem {
  id: string;
  name: string;
  code: string;
  description: string | null;
  isActive: boolean;
  businessId: string;
  parentId: string | null;
  conversionFactor: number | null;
  createdAt: string;
  updatedAt: string;
  parent?: UnitItem | null;
  subUnits?: UnitItem[];
  branches?: UnitBranchItem[];
}

export default function UnitsPage() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Core Data State
  const [unitsList, setUnitsList] = useState<UnitItem[]>([]);
  const [branchesList, setBranchesList] = useState<BranchItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [actionLoading, setActionLoading] = useState<boolean>(false);

  // Filter State
  const [selectedBranchFilter, setSelectedBranchFilter] = useState<string>("all");
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<string>("all");

  // Notifications
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [modalMode, setModalMode] = useState<"create" | "edit">("create");
  const [editingUnitId, setEditingUnitId] = useState<string>("");

  // Form State
  const [formName, setFormName] = useState<string>("");
  const [formCode, setFormCode] = useState<string>("");
  const [formDescription, setFormDescription] = useState<string>("");
  const [formBranchIds, setFormBranchIds] = useState<string[]>([]);
  const [formParentId, setFormParentId] = useState<string>("none");
  const [formConversionFactor, setFormConversionFactor] = useState<string>("");
  const [formIsActive, setFormIsActive] = useState<boolean>(true);

  // Delete Confirmation State
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState<boolean>(false);
  const [unitToDelete, setUnitToDelete] = useState<UnitItem | null>(null);

  // Auth & Initial Fetch
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
      return;
    }

    if (user) {
      fetchData(user);
    }
  }, []);

  const fetchData = async (userObj: User) => {
    setLoading(true);
    setError("");
    try {
      const businessId = userObj.businessId;
      if (!businessId) return;

      const [unitsData, branchesData] = await Promise.all([
        unitService.getUnits(businessId),
        branchService.getBranches(businessId, userObj.id)
      ]);

      setUnitsList(unitsData);
      setBranchesList(branchesData);
    } catch (err: any) {
      setError(err.message || "Failed to load units.");
    } finally {
      setLoading(false);
    }
  };

  // Auto-dismiss Notifications
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  const handleOpenCreateModal = () => {
    setError("");
    setModalMode("create");
    setEditingUnitId("");
    setFormName("");
    setFormCode("");
    setFormDescription("");
    setFormBranchIds([]);
    setFormParentId("none");
    setFormConversionFactor("");
    setFormIsActive(true);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (unit: UnitItem) => {
    setError("");
    setModalMode("edit");
    setEditingUnitId(unit.id);
    setFormName(unit.name);
    setFormCode(unit.code);
    setFormDescription(unit.description || "");
    
    const assignedBranchIds = unit.branches?.map((ub) => ub.branch.id) || [];
    setFormBranchIds(assignedBranchIds);

    setFormParentId(unit.parentId || "none");
    setFormConversionFactor(unit.conversionFactor ? String(unit.conversionFactor) : "");
    setFormIsActive(unit.isActive);
    setIsModalOpen(true);
  };

  const handleToggleBranchForm = (branchId: string) => {
    setFormBranchIds((prev) =>
      prev.includes(branchId)
        ? prev.filter((id) => id !== branchId)
        : [...prev, branchId]
    );
  };

  const handleOpenDeleteConfirm = (unit: UnitItem) => {
    setError("");
    setUnitToDelete(unit);
    setIsDeleteConfirmOpen(true);
  };

  const handleUnitSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = formName.trim();
    const trimmedCode = formCode.trim().toUpperCase();

    if (!trimmedName || !trimmedCode) {
      setError("Unit Name and Code are required.");
      return;
    }
    if (trimmedName.length < 2 || trimmedName.length > 100) {
      setError("Unit Name must be between 2 and 100 characters.");
      return;
    }
    if (trimmedCode.length < 1 || trimmedCode.length > 20) {
      setError("Unit Code must be between 1 and 20 characters.");
      return;
    }
    if (formDescription && formDescription.trim().length > 500) {
      setError("Description cannot exceed 500 characters.");
      return;
    }
    if (!currentUser?.businessId) return;

    setActionLoading(true);
    setError("");

    const isSubUnit = formParentId !== "none";
    const factor = isSubUnit ? parseFloat(formConversionFactor) : null;

    if (isSubUnit && (!factor || factor <= 0)) {
      setError("Please enter a valid conversion factor greater than 0.");
      setActionLoading(false);
      return;
    }

    const payload = {
      name: trimmedName,
      code: trimmedCode,
      description: formDescription.trim() || undefined,
      businessId: currentUser.businessId,
      branchIds: formBranchIds,
      parentId: isSubUnit ? formParentId : null,
      conversionFactor: factor,
      isActive: formIsActive,
      createdById: modalMode === "create" ? currentUser.id : undefined,
      updatedById: modalMode === "edit" ? currentUser.id : undefined,
    };

    try {
      if (modalMode === "create") {
        await unitService.createUnit(payload);
        setSuccessMessage("Unit created successfully!");
      } else {
        await unitService.updateUnit(editingUnitId, payload);
        setSuccessMessage("Unit updated successfully!");
      }
      setIsModalOpen(false);
      fetchData(currentUser);
    } catch (err: any) {
      setError(err.message || "Failed to save unit.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteUnit = async () => {
    if (!unitToDelete || !currentUser?.businessId) return;
    setActionLoading(true);
    setError("");
    try {
      await unitService.deleteUnit(unitToDelete.id, currentUser.businessId);
      setSuccessMessage("Unit deleted successfully!");
      setIsDeleteConfirmOpen(false);
      fetchData(currentUser);
    } catch (err: any) {
      setError(err.message || "Failed to delete unit.");
    } finally {
      setActionLoading(false);
    }
  };

  // Filter Logic
  const availableParentUnits = unitsList.filter(
    (u) => u.id !== editingUnitId && !u.parentId
  );

  const getFilteredUnits = () => {
    let list = unitsList;

    // 1. Branch Filter
    if (selectedBranchFilter !== "all") {
      if (selectedBranchFilter === "global") {
        list = list.filter((u) => !u.branches || u.branches.length === 0);
      } else {
        list = list.filter((u) =>
          u.branches?.some((ub) => ub.branch.id === selectedBranchFilter)
        );
      }
    }

    // 2. Type Filter (Base / Sub)
    if (selectedTypeFilter !== "all") {
      if (selectedTypeFilter === "base") {
        list = list.filter((u) => u.parentId === null);
      } else if (selectedTypeFilter === "sub") {
        list = list.filter((u) => u.parentId !== null);
      }
    }

    return list;
  };

  const filteredList = getFilteredUnits();

  // Columns Definition
  const columns: ColumnDef<UnitItem>[] = [
    {
      header: "Unit Name",
      searchable: true,
      render: (unit) => (
        <div>
          <span className="font-semibold text-foreground block">{unit.name}</span>
          {unit.description && (
            <span className="text-xs text-muted-foreground block truncate max-w-[250px]">
              {unit.description}
            </span>
          )}
        </div>
      ),
    },
    {
      header: "Unit Code",
      searchable: true,
      render: (unit) => (
        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-primary/10 text-primary uppercase border border-primary/20">
          {unit.code}
        </span>
      ),
    },
    {
      header: "Type & Relationship",
      render: (unit) => {
        if (!unit.parentId) {
          return (
            <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-600 dark:text-emerald-400">
              <Layers className="h-3 w-3" /> Base Unit
            </span>
          );
        }
        const parentUnit = unitsList.find((u) => u.id === unit.parentId);
        return (
          <div className="text-xs">
            <span className="inline-flex items-center gap-1 font-medium text-amber-600 dark:text-amber-400 mb-0.5">
              <GitCommit className="h-3 w-3" /> Sub-unit
            </span>
            {parentUnit && (
              <span className="text-[10px] text-muted-foreground block">
                1 {parentUnit.code} = {unit.conversionFactor} {unit.code}
              </span>
            )}
          </div>
        );
      },
    },
    {
      header: "Branch Scope",
      render: (unit) => {
        if (!unit.branches || unit.branches.length === 0) {
          return (
            <span className="inline-flex items-center gap-1 text-xs text-muted-foreground font-medium">
              <Globe className="h-3.5 w-3.5 text-muted-foreground/60" />
              Global
            </span>
          );
        }
        if (unit.branches.length === 1) {
          return (
            <span className="inline-flex items-center gap-1 text-xs text-foreground/80 font-medium">
              <Building2 className="h-3.5 w-3.5 text-muted-foreground/60" />
              {unit.branches[0].branch.name}
            </span>
          );
        }
        return (
          <span className="inline-flex items-center gap-1 text-xs text-primary font-medium">
            <Building2 className="h-3.5 w-3.5 text-primary/60" />
            {unit.branches.length} Branches
          </span>
        );
      },
    },
    {
      header: "Status",
      render: (unit) => (
        <span
          className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${
            unit.isActive
              ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
              : "bg-destructive/10 text-destructive border-destructive/20"
          }`}
        >
          {unit.isActive ? "Active" : "Inactive"}
        </span>
      ),
    },
    {
      header: "Actions",
      render: (unit) => {
        const actions: ActionItem[] = [
          {
            label: "Edit",
            onClick: () => handleOpenEditModal(unit),
            icon: <Edit2 className="h-3.5 w-3.5" />,
          },
          {
            label: "Delete",
            onClick: () => handleOpenDeleteConfirm(unit),
            icon: <Trash2 className="h-3.5 w-3.5" />,
            variant: "destructive",
          },
        ];
        return <ActionsDropdown actions={actions} />;
      },
    },
  ];

  const customFilters = (
    <>
      {/* Branch Filter */}
      <div className="flex items-center gap-2">
        <span className="text-xs font-semibold text-muted-foreground whitespace-nowrap">
          Branch:
        </span>
        <select
          value={selectedBranchFilter}
          onChange={(e) => setSelectedBranchFilter(e.target.value)}
          className="h-9 rounded-md border border-input bg-background px-3 py-1 text-xs shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
        >
          <option value="all">All Branches</option>
          <option value="global">Global (No Branch)</option>
          {branchesList.map((b) => (
            <option key={b.id} value={b.id}>
              {b.name}
            </option>
          ))}
        </select>
      </div>

      {/* Type Filter */}
      <div className="flex items-center gap-2">
        <span className="text-xs font-semibold text-muted-foreground whitespace-nowrap">
          Type:
        </span>
        <select
          value={selectedTypeFilter}
          onChange={(e) => setSelectedTypeFilter(e.target.value)}
          className="h-9 rounded-md border border-input bg-background px-3 py-1 text-xs shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
        >
          <option value="all">All Types</option>
          <option value="base">Base Units Only</option>
          <option value="sub">Sub-units Only</option>
        </select>
      </div>
    </>
  );

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3 p-6 max-w-sm border border-border/40 rounded-xl bg-card/60 backdrop-blur-sm">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <h2 className="text-lg font-bold">Unauthorized Access</h2>
          <p className="text-sm text-muted-foreground">
            You need to be logged in to view this page. Redirecting to login...
          </p>
          <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/units" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Product Units" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <Scale className="h-7 w-7 text-primary" /> Product Units
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Manage your product units of measure (UoM), define sub-units, and map branch scopes.
              </p>
            </div>
          </div>

          {/* Banner Notifications */}
          {successMessage && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 animate-in fade-in slide-in-from-top-4 duration-300">
              <CheckCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive animate-in fade-in slide-in-from-top-4 duration-300">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          {loading ? (
            <div className="flex h-64 items-center justify-center">
              <div className="text-center space-y-2">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
                <span className="text-sm text-muted-foreground block">Loading units...</span>
              </div>
            </div>
          ) : (
            <DataTable
              data={filteredList}
              columns={columns}
              searchKeys={["name", "code"]}
              actionButton={{
                label: "Add Unit",
                onClick: handleOpenCreateModal,
                icon: <Plus className="h-4 w-4" />
              }}
              customFilters={customFilters}
              reportTitle="Product Units Report"
            />
          )}
        </main>
      </div>

      {/* Create / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-xl border border-border/50 bg-card p-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-border/50 pb-3 mb-4">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <Scale className="h-5 w-5 text-primary" />
                {modalMode === "create" ? "Create New Unit" : "Edit Product Unit"}
              </h3>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsModalOpen(false)}
                className="h-8 w-8 rounded-full"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            <form onSubmit={handleUnitSubmit} className="space-y-4">
              {error && (
                <div className="p-3 rounded-md bg-destructive/15 border border-destructive/30 text-destructive text-xs flex items-center gap-2 animate-in fade-in duration-200">
                  <AlertCircle className="h-4 w-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}
              <div className="grid grid-cols-2 gap-4">
                {/* Name */}
                <div className="space-y-1.5 col-span-2 sm:col-span-1">
                  <label className="text-xs font-bold text-muted-foreground uppercase">
                    Unit Name <span className="text-destructive">*</span>
                  </label>
                  <Input
                    placeholder="e.g., Kilogram, Box"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    required
                    disabled={actionLoading}
                  />
                </div>

                {/* Code */}
                <div className="space-y-1.5 col-span-2 sm:col-span-1">
                  <label className="text-xs font-bold text-muted-foreground uppercase">
                    Unit Code <span className="text-destructive">*</span>
                  </label>
                  <Input
                    placeholder="e.g., KG, BOX"
                    value={formCode}
                    onChange={(e) => setFormCode(e.target.value)}
                    required
                    disabled={actionLoading}
                    className="uppercase"
                  />
                </div>
              </div>

              {/* Description */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-muted-foreground uppercase">
                  Description
                </label>
                <Input
                  placeholder="Optional unit description"
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  disabled={actionLoading}
                />
              </div>

              {/* Parent Unit & Conversion Factor */}
              <div className="grid grid-cols-2 gap-4 p-3 rounded-lg bg-secondary/30 border border-border/30">
                <div className="space-y-1.5 col-span-2 sm:col-span-1">
                  <label className="text-xs font-bold text-muted-foreground uppercase">
                    Parent Unit
                  </label>
                  <select
                    value={formParentId}
                    onChange={(e) => setFormParentId(e.target.value)}
                    className="h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-xs shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                    disabled={actionLoading}
                  >
                    <option value="none">None (Base Unit)</option>
                    {availableParentUnits.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name} ({u.code})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5 col-span-2 sm:col-span-1">
                  <label className="text-xs font-bold text-muted-foreground uppercase">
                    Conversion Factor
                  </label>
                  <Input
                    type="number"
                    step="any"
                    placeholder="e.g., 12 (1 Parent = X of this)"
                    value={formConversionFactor}
                    onChange={(e) => setFormConversionFactor(e.target.value)}
                    disabled={actionLoading || formParentId === "none"}
                    required={formParentId !== "none"}
                  />
                  {formParentId !== "none" && formConversionFactor && (
                    <span className="text-[10px] text-muted-foreground block mt-0.5">
                      1 {availableParentUnits.find(u => u.id === formParentId)?.code || "Parent"} = {formConversionFactor} {formCode || "PCS"}
                    </span>
                  )}
                </div>
              </div>

              {/* Branch Scope */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-muted-foreground uppercase block">
                  Branch Mapping (Optional - Leave empty for Global)
                </label>
                <div className="grid grid-cols-2 gap-2 max-h-24 overflow-y-auto border border-border/40 rounded-md p-2 bg-background/50">
                  {branchesList.map((branch) => {
                    const isChecked = formBranchIds.includes(branch.id);
                    return (
                      <div
                        key={branch.id}
                        onClick={() => handleToggleBranchForm(branch.id)}
                        className={`flex items-center space-x-2 p-1.5 rounded-md cursor-pointer border text-xs font-medium transition-all ${
                          isChecked
                            ? "bg-primary/10 border-primary/30 text-primary"
                            : "bg-transparent border-transparent hover:bg-secondary/40 text-muted-foreground"
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}} // Handled by onClick on div
                          className="rounded text-primary focus:ring-0 cursor-pointer"
                        />
                        <span className="truncate">{branch.name}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Status */}
              <div className="flex items-center space-x-2 py-1">
                <input
                  type="checkbox"
                  id="isActive"
                  checked={formIsActive}
                  onChange={(e) => setFormIsActive(e.target.checked)}
                  disabled={actionLoading}
                  className="rounded text-primary focus:ring-0 cursor-pointer h-4 w-4"
                />
                <label htmlFor="isActive" className="text-xs font-semibold cursor-pointer select-none">
                  Active (Allow using this unit in products)
                </label>
              </div>

              {/* Form Buttons */}
              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-border/50">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsModalOpen(false)}
                  disabled={actionLoading}
                  className="h-9 px-4 text-xs"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={actionLoading}
                  className="h-9 px-4 text-xs flex items-center gap-1.5"
                >
                  {actionLoading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                  {modalMode === "create" ? "Create Unit" : "Save Changes"}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      {isDeleteConfirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="w-full max-w-sm rounded-xl border border-border/50 bg-card p-5 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-start space-x-3">
              <AlertCircle className="h-6 w-6 text-destructive shrink-0 mt-0.5" />
              <div>
                <h3 className="text-base font-bold">Delete Product Unit?</h3>
                {error && (
                  <div className="p-2.5 my-2 rounded-md bg-destructive/15 border border-destructive/30 text-destructive text-xs animate-in fade-in duration-200">
                    {error}
                  </div>
                )}
                <p className="text-xs text-muted-foreground mt-1.5">
                  Are you sure you want to delete the unit <strong className="text-foreground">"{unitToDelete?.name}"</strong>? This action is permanent and cannot be undone.
                </p>
              </div>
            </div>
            <div className="flex items-center justify-end space-x-3 mt-5 pt-3 border-t border-border/40">
              <Button
                variant="outline"
                onClick={() => setIsDeleteConfirmOpen(false)}
                disabled={actionLoading}
                className="h-8.5 text-xs px-3.5"
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={handleDeleteUnit}
                disabled={actionLoading}
                className="h-8.5 text-xs px-3.5 flex items-center gap-1.5"
              >
                {actionLoading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                Delete Unit
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
