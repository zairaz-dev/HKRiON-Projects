import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { X, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { User } from "@hkr/types";
import { paymentMethodFormSchema, PaymentMethodFormData } from "../schema";
import { PaymentMethodItem } from "../types";
import { useCreatePaymentMethodMutation, useUpdatePaymentMethodMutation } from "../hooks/use-payment-methods";

// Simple BranchItem definition matching existing features
interface BranchItem {
  id: string;
  name: string;
}

interface PaymentMethodDialogProps {
  isOpen: boolean;
  onClose: () => void;
  paymentMethod?: PaymentMethodItem | null;
  branches: BranchItem[];
  currentUser: User;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

export function PaymentMethodDialog({
  isOpen,
  onClose,
  paymentMethod,
  branches,
  currentUser,
  onSuccess,
  onError,
}: PaymentMethodDialogProps) {
  const isEditMode = !!paymentMethod;
  const createMutation = useCreatePaymentMethodMutation();
  const updateMutation = useUpdatePaymentMethodMutation();

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<PaymentMethodFormData>({
    resolver: zodResolver(paymentMethodFormSchema),
    defaultValues: {
      name: "",
      code: "",
      description: "",
      sortOrder: 0,
      branchIds: [],
    },
  });

  const watchBranchIds = watch("branchIds") || [];

  // Populate form if in edit mode
  useEffect(() => {
    if (paymentMethod) {
      const assignedBranchIds = paymentMethod.branches?.map((b) => b.branchId) || [];
      reset({
        name: paymentMethod.name,
        code: paymentMethod.code,
        description: paymentMethod.description || "",
        sortOrder: paymentMethod.sortOrder || 0,
        branchIds: assignedBranchIds,
      });
    } else {
      reset({
        name: "",
        code: "",
        description: "",
        sortOrder: 0,
        branchIds: [],
      });
    }
  }, [paymentMethod, reset, isOpen]);

  const handleToggleBranch = (branchId: string) => {
    if (watchBranchIds.includes(branchId)) {
      setValue(
        "branchIds",
        watchBranchIds.filter((id) => id !== branchId),
        { shouldValidate: true }
      );
    } else {
      setValue("branchIds", [...watchBranchIds, branchId], {
        shouldValidate: true,
      });
    }
  };

  const onSubmit = async (data: PaymentMethodFormData) => {
    if (!currentUser.businessId) return;

    const payload: any = {
      name: data.name.trim(),
      description: data.description?.trim() || undefined,
      sortOrder: Number(data.sortOrder),
      businessId: currentUser.businessId,
      branchIds: data.branchIds,
    };

    if (isEditMode) {
      payload.updatedById = currentUser.id;
    } else {
      payload.code = data.code.trim().toLowerCase();
      payload.createdById = currentUser.id;
    }

    try {
      if (isEditMode && paymentMethod) {
        await updateMutation.mutateAsync({ id: paymentMethod.id, data: payload });
        onSuccess("Payment method updated successfully!");
      } else {
        await createMutation.mutateAsync(payload);
        onSuccess("Payment method created successfully!");
      }
      onClose();
    } catch (err: any) {
      onError(err.message || "Failed to save payment method.");
    }
  };

  const isLoading = createMutation.isPending || updateMutation.isPending;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-card border border-border rounded-sm shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between border-b border-border p-5 bg-background/40">
          <h2 className="text-lg font-bold text-foreground">
            {isEditMode ? "Edit Payment Method" : "Add Payment Method"}
          </h2>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-5 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Code - Disabled in edit mode */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">Payment Method Code *</label>
            <Input
              {...register("code")}
              placeholder="e.g. upi, phonepe, credit_card (Immutable)"
              disabled={isEditMode}
              className={isEditMode ? "bg-muted text-muted-foreground cursor-not-allowed opacity-70" : ""}
            />
            {!isEditMode && errors.code && (
              <span className="text-xs text-rose-500">{errors.code.message}</span>
            )}
            <p className="text-[10px] text-muted-foreground">
              Unique slug identifier. Lowercase, alphanumeric & underscores only. Cannot be changed later.
            </p>
          </div>

          {/* Name */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">Payment Method Name *</label>
            <Input
              {...register("name")}
              placeholder="e.g. Credit Card, UPI / GPay"
            />
            {errors.name && (
              <span className="text-xs text-rose-500">{errors.name.message}</span>
            )}
          </div>

          {/* Description */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">Description</label>
            <textarea
              {...register("description")}
              placeholder="Provide a brief description..."
              className="w-full h-20 px-3 py-2 bg-background border border-input text-foreground rounded-sm text-sm focus:outline-none focus:border-primary placeholder:text-muted-foreground/60 transition-all focus:ring-1 focus:ring-primary"
            />
            {errors.description && (
              <span className="text-xs text-rose-500">{errors.description.message}</span>
            )}
          </div>

          {/* Sort Order */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">Sort Order</label>
            <Input
              type="number"
              {...register("sortOrder", { valueAsNumber: true })}
              placeholder="0"
            />
            {errors.sortOrder && (
              <span className="text-xs text-rose-500">{errors.sortOrder.message}</span>
            )}
          </div>

          {/* Branch Assignment */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">Assign to Branches</label>
            <div className="border border-border/60 p-3 rounded-sm bg-background/30 max-h-32 overflow-y-auto space-y-2">
              {branches.map((branch) => {
                const isChecked = watchBranchIds.includes(branch.id);
                return (
                  <label key={branch.id} className="flex items-center gap-2.5 text-sm text-foreground cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => handleToggleBranch(branch.id)}
                      className="rounded border-input text-primary focus:ring-primary h-4 w-4 bg-background"
                    />
                    {branch.name}
                  </label>
                );
              })}
              {branches.length === 0 && (
                <p className="text-xs text-muted-foreground">No branches found.</p>
              )}
            </div>
            <p className="text-[10px] text-muted-foreground">
              Select which branches can accept payments using this method.
            </p>
          </div>

          <div className="flex gap-3 pt-3 border-t border-border/40">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1 text-xs"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isLoading}
              className="flex-1 text-xs gap-1.5"
            >
              {isLoading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
              {isEditMode ? "Save Changes" : "Create Payment"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
