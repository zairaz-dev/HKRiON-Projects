"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import {
  ShieldCheck,
  Plus,
  Edit2,
  Trash2,
  Loader2,
  CheckCircle,
  AlertCircle,
  Building2,
  Globe
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { DataTable, ColumnDef, ActionsDropdown } from "@/components/ui/table";
import { ActionItem } from "@/components/ui/actions-dropdown";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";

import {
  WarrantyItem,
  WarrantyDialog,
  WarrantyDeleteDialog,
  useWarrantiesQuery,
  useBranchesQuery
} from "@/features/warranties";

function WarrantiesPageContent() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Notifications
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Dialog States
  const [isDialogOpen, setIsDialogOpen] = useState<boolean>(false);
  const [editingWarranty, setEditingWarranty] = useState<WarrantyItem | null>(null);
  const [warrantyToDelete, setWarrantyToDelete] = useState<WarrantyItem | null>(null);

  // URL-driven Branch Filter
  const selectedBranchFilter = searchParams.get("branchId") || "all";

  const setSelectedBranchFilter = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value === "all") {
      params.delete("branchId");
    } else {
      params.set("branchId", value);
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  // Authenticate
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  // Fetch Data via React Query
  const businessId = currentUser?.businessId || "";
  const { data: warrantiesList = [], isLoading: warrantiesLoading, error: warrantiesError } = useWarrantiesQuery(businessId);
  const { data: branchesList = [], isLoading: branchesLoading } = useBranchesQuery(businessId, currentUser?.id);

  // Handle Query Errors
  useEffect(() => {
    if (warrantiesError) {
      setError(warrantiesError.message || "Failed to load warranties.");
    }
  }, [warrantiesError]);

  // Auto-dismiss notifications
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  const handleOpenCreateModal = () => {
    setEditingWarranty(null);
    setIsDialogOpen(true);
  };

  const handleOpenEditModal = (warranty: WarrantyItem) => {
    setEditingWarranty(warranty);
    setIsDialogOpen(true);
  };

  // Filter Logic
  const getFilteredWarranties = () => {
    let list = warrantiesList;

    if (selectedBranchFilter !== "all") {
      if (selectedBranchFilter === "global") {
        list = list.filter((w) => !w.branches || w.branches.length === 0);
      } else {
        list = list.filter((w) =>
          w.branches?.some((ub) => ub.branch.id === selectedBranchFilter)
        );
      }
    }

    return list;
  };

  const filteredList = getFilteredWarranties();

  // Columns Definition
  const columns: ColumnDef<WarrantyItem>[] = [
    {
      header: "Warranty Name",
      searchable: true,
      render: (warranty) => (
        <div>
          <span className="font-semibold text-foreground block">{warranty.name}</span>
          {warranty.description && (
            <span className="text-xs text-muted-foreground block truncate max-w-[250px]">
              {warranty.description}
            </span>
          )}
        </div>
      ),
    },
    {
      header: "Duration",
      render: (warranty) => (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-primary/10 text-primary border border-primary/20">
          {warranty.duration} {warranty.durationType}
        </span>
      ),
    },
    {
      header: "Branch Scope",
      render: (warranty) => {
        if (!warranty.branches || warranty.branches.length === 0) {
          return (
            <span className="inline-flex items-center gap-1 text-xs text-muted-foreground font-medium">
              <Globe className="h-3.5 w-3.5 text-muted-foreground/60" />
              Global
            </span>
          );
        }
        if (warranty.branches.length === 1) {
          return (
            <span className="inline-flex items-center gap-1 text-xs text-foreground/80 font-medium">
              <Building2 className="h-3.5 w-3.5 text-muted-foreground/60" />
              {warranty.branches[0].branch.name}
            </span>
          );
        }
        return (
          <span className="inline-flex items-center gap-1 text-xs text-primary font-medium">
            <Building2 className="h-3.5 w-3.5 text-primary/60" />
            {warranty.branches.length} Branches
          </span>
        );
      },
    },
    {
      header: "Status",
      render: (warranty) => (
        <span
          className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${
            warranty.isActive
              ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
              : "bg-destructive/10 text-destructive border-destructive/20"
          }`}
        >
          {warranty.isActive ? "Active" : "Inactive"}
        </span>
      ),
    },
    {
      header: "Actions",
      render: (warranty) => {
        const actions: ActionItem[] = [
          {
            label: "Edit",
            onClick: () => handleOpenEditModal(warranty),
            icon: <Edit2 className="h-3.5 w-3.5" />,
          },
          {
            label: "Delete",
            onClick: () => setWarrantyToDelete(warranty),
            icon: <Trash2 className="h-3.5 w-3.5" />,
            variant: "destructive",
          },
        ];
        return <ActionsDropdown actions={actions} />;
      },
    },
  ];

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3 p-6 max-w-sm border border-border/40 rounded-xl bg-card/60 backdrop-blur-sm">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <h2 className="text-lg font-bold">Unauthorized Access</h2>
          <p className="text-sm text-muted-foreground">
            You need to be logged in to view this page. Redirecting to login...
          </p>
          <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
        </div>
      </div>
    );
  }

  const isLoading = warrantiesLoading || branchesLoading;

  const customFilters = (
    <div className="flex items-center gap-2">
      <span className="text-xs font-semibold text-muted-foreground whitespace-nowrap">
        Branch:
      </span>
      <select
        value={selectedBranchFilter}
        onChange={(e) => setSelectedBranchFilter(e.target.value)}
        className="h-9 rounded-md border border-input bg-background px-3 py-1 text-xs shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
      >
        <option value="all">All Branches</option>
        <option value="global">Global (No Branch)</option>
        {branchesList.map((b) => (
          <option key={b.id} value={b.id}>
            {b.name}
          </option>
        ))}
      </select>
    </div>
  );

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/warranties" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Product Warranties" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <ShieldCheck className="h-7 w-7 text-primary" /> Product Warranties
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Manage your product warranties, define durations, and map branch scopes.
              </p>
            </div>
          </div>

          {/* Banner Notifications */}
          {successMessage && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 animate-in fade-in slide-in-from-top-4 duration-300">
              <CheckCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive animate-in fade-in slide-in-from-top-4 duration-300">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          {isLoading ? (
            <div className="flex h-64 items-center justify-center">
              <div className="text-center space-y-2">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
                <span className="text-sm text-muted-foreground block">Loading warranties...</span>
              </div>
            </div>
          ) : (
            <DataTable
              data={filteredList}
              columns={columns}
              searchKeys={["name"]}
              actionButton={{
                label: "Add Warranty",
                onClick: handleOpenCreateModal,
                icon: <Plus className="h-4 w-4" />
              }}
              customFilters={customFilters}
              reportTitle="Product Warranties Report"
            />
          )}
        </main>
      </div>

      {/* Create / Edit Modal Dialog */}
      {currentUser && (
        <WarrantyDialog
          isOpen={isDialogOpen}
          onClose={() => {
            setIsDialogOpen(false);
            setEditingWarranty(null);
          }}
          warranty={editingWarranty}
          branches={branchesList}
          currentUser={currentUser}
          onSuccess={setSuccessMessage}
          onError={setError}
        />
      )}

      {/* Delete Confirmation Dialog */}
      {currentUser && warrantyToDelete && (
        <WarrantyDeleteDialog
          isOpen={!!warrantyToDelete}
          onClose={() => setWarrantyToDelete(null)}
          warranty={warrantyToDelete}
          currentUser={currentUser}
          onSuccess={setSuccessMessage}
          onError={setError}
        />
      )}
    </div>
  );
}

export default function WarrantiesPage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen w-screen items-center justify-center bg-[#121216]">
        <div className="flex flex-col items-center gap-2">
          <div className="w-8 h-8 border-4 border-zinc-700 border-t-emerald-500 rounded-full animate-spin" />
          <p className="text-sm text-zinc-400">Loading...</p>
        </div>
      </div>
    }>
      <WarrantiesPageContent />
    </Suspense>
  );
}
