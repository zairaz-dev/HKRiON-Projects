import React from "react";
import { InvoiceTemplateProps } from "./types";

export function generateA4StandardHtml(props: InvoiceTemplateProps): string {
  const { sale, layout, businessName, currencySymbol = "₹" } = props;
  const cur = currencySymbol;

  const headerText = layout?.headerText || "TAX INVOICE";
  const subHeading = layout?.subHeading || "ORIGINAL FOR RECIPIENT";
  const showLogo = layout?.showLogo ?? true;
  const showCustomerDetails = layout?.showCustomerDetails ?? true;
  const showSku = layout?.showSku ?? true;
  const showDiscount = layout?.showDiscount ?? true;
  const showTax = layout?.showTax ?? true;
  const footerText = layout?.footerText || "Thank you for doing business with us!";
  const termsConditions = layout?.termsConditions || "1. Goods once sold will not be taken back.\n2. Warranty as per manufacturer policy.";
  const bankDetails = layout?.bankDetails || "";

  return `
    <!DOCTYPE html>
    <html>
      <head>
        <title>${headerText} - ${sale.invoiceNumber}</title>
        <style>
          @page {
            size: A4 portrait;
            margin: 12mm;
          }
          body {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 11px;
            color: #111;
            margin: 0;
            padding: 0;
          }
          .invoice-box {
            border: 1px solid #111;
            padding: 16px;
            max-width: 100%;
          }
          .header-table {
            width: 100%;
            border-bottom: 2px solid #111;
            padding-bottom: 12px;
            margin-bottom: 12px;
          }
          .title {
            font-size: 20px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
          }
          .subtitle {
            font-size: 10px;
            color: #555;
            text-transform: uppercase;
          }
          .info-table {
            width: 100%;
            margin-bottom: 16px;
            border-collapse: collapse;
          }
          .info-table td {
            width: 50%;
            vertical-align: top;
            padding: 4px;
          }
          .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 12px;
            margin-bottom: 16px;
          }
          .items-table th, .items-table td {
            border: 1px solid #333;
            padding: 6px 8px;
            text-align: left;
          }
          .items-table th {
            background-color: #f2f2f2;
            font-weight: bold;
            text-transform: uppercase;
            font-size: 10px;
          }
          .text-right {
            text-align: right !important;
          }
          .totals-table {
            width: 40%;
            margin-left: auto;
            border-collapse: collapse;
          }
          .totals-table td {
            padding: 4px 8px;
            text-align: right;
          }
          .totals-table tr.grand-total {
            font-weight: bold;
            font-size: 13px;
            border-top: 2px solid #111;
            border-bottom: 2px solid #111;
          }
          .footer-section {
            margin-top: 24px;
            display: flex;
            justify-content: space-between;
          }
          .terms-box {
            width: 55%;
            border: 1px solid #ccc;
            padding: 8px;
            font-size: 9px;
            white-space: pre-line;
            border-radius: 4px;
          }
          .signature-box {
            width: 38%;
            text-align: center;
            margin-left: auto;
            margin-top: 20px;
          }
          .sig-line {
            border-top: 1px solid #111;
            margin-top: 40px;
            padding-top: 4px;
            font-weight: bold;
            font-size: 10px;
          }
        </style>
      </head>
      <body onload="window.print(); window.close();">
        <div class="invoice-box">
          <table class="header-table">
            <tr>
              <td>
                <div class="title">${headerText}</div>
                <div class="subtitle">${subHeading}</div>
                <div style="font-size: 16px; font-weight: bold; margin-top: 6px;">${businessName}</div>
                <div>${sale.branch?.name || ""}</div>
                ${sale.branch?.address ? `<div>${sale.branch.address}</div>` : ""}
                ${sale.branch?.phone ? `<div>Phone: ${sale.branch.phone}</div>` : ""}
              </td>
              <td class="text-right" style="vertical-align: top;">
                <div style="font-size: 12px; font-weight: bold;">Invoice #: ${sale.invoiceNumber}</div>
                <div>Date: ${new Date(sale.saleDate).toLocaleDateString()}</div>
              </td>
            </tr>
          </table>

          <table class="info-table">
            <tr>
              <td style="border-right: 1px solid #eee;">
                <strong>BILLED TO:</strong><br/>
                ${showCustomerDetails ? `
                  <span style="font-size: 13px; font-weight: bold;">${sale.customer?.name || "Walk-in Customer"}</span><br/>
                  ${sale.customer?.address ? `${sale.customer.address}<br/>` : ""}
                  ${sale.customer?.phone ? `Phone: ${sale.customer.phone}<br/>` : ""}
                  ${sale.customer?.taxNumber ? `GSTIN/VAT: ${sale.customer.taxNumber}<br/>` : ""}
                ` : `<span>Walk-in Customer</span>`}
              </td>
              <td style="padding-left: 12px;">
                <strong>PAYMENT DETAILS:</strong><br/>
                Status: <span style="font-weight: bold;">${sale.amountPaid >= sale.grandTotal ? 'PAID' : 'DUE'}</span><br/>
                Amount Paid: ${cur}${sale.amountPaid.toFixed(2)}<br/>
                Balance Due: ${cur}${Math.max(0, sale.grandTotal - sale.amountPaid).toFixed(2)}
              </td>
            </tr>
          </table>

          <table class="items-table">
            <thead>
              <tr>
                <th style="width: 30px;">#</th>
                <th>Item Description</th>
                ${showSku ? `<th style="width: 90px;">SKU</th>` : ""}
                <th class="text-right" style="width: 60px;">Qty</th>
                <th class="text-right" style="width: 80px;">Unit Price</th>
                ${showDiscount ? `<th class="text-right" style="width: 70px;">Discount</th>` : ""}
                ${showTax ? `<th class="text-right" style="width: 70px;">Tax</th>` : ""}
                <th class="text-right" style="width: 90px;">Total</th>
              </tr>
            </thead>
            <tbody>
              ${sale.saleLines?.map((line, idx) => {
                const imeiStr = line.imeiNumber || line.productImeis?.map(i => i.imeiNumber).join(", ");
                return `
                <tr>
                  <td>${idx + 1}</td>
                  <td>
                    <strong>${line.variant?.product?.name || line.variant?.name}</strong>
                    ${imeiStr ? `<div style="font-size: 10px; color: #555; font-family: monospace;">IMEI/SN: ${imeiStr}</div>` : ""}
                  </td>
                  ${showSku ? `<td>${line.variant?.sku || "-"}</td>` : ""}
                  <td class="text-right">${line.quantity}</td>
                  <td class="text-right">${cur}${line.unitPrice.toFixed(2)}</td>
                  ${showDiscount ? `<td class="text-right">${cur}${(line.discountAmount || 0).toFixed(2)}</td>` : ""}
                  ${showTax ? `<td class="text-right">${cur}${(line.taxAmount || 0).toFixed(2)}</td>` : ""}
                  <td class="text-right">${cur}${line.subtotal.toFixed(2)}</td>
                </tr>
              `}).join("")}
            </tbody>
          </table>

          <table class="totals-table">
            ${showDiscount && sale.discountAmount > 0 ? `<tr><td>Discount:</td><td>-${cur}${sale.discountAmount.toFixed(2)}</td></tr>` : ""}
            ${showTax && sale.taxAmount > 0 ? `<tr><td>Tax Amount:</td><td>+${cur}${sale.taxAmount.toFixed(2)}</td></tr>` : ""}
            <tr class="grand-total">
              <td>Grand Total:</td>
              <td>${cur}${sale.grandTotal.toFixed(2)}</td>
            </tr>
          </table>

          <div style="margin-top: 20px;" class="footer-section">
            <div class="terms-box">
              ${bankDetails ? `<strong>BANK DETAILS:</strong>\n${bankDetails}\n\n` : ""}
              ${termsConditions ? `<strong>TERMS & CONDITIONS:</strong>\n${termsConditions}` : ""}
            </div>

            <div class="signature-box">
              <div class="sig-line">For ${businessName}<br/><span style="font-size: 8px; font-weight: normal;">(Authorized Signatory)</span></div>
            </div>
          </div>

          <div style="text-center; margin-top: 24px; text-align: center; font-size: 9px; color: #777;">
            ${footerText}
          </div>
        </div>
      </body>
    </html>
  `;
}

export function A4StandardTemplate(props: InvoiceTemplateProps) {
  const { sale, layout, businessName, currencySymbol = "₹" } = props;
  const cur = currencySymbol;

  const headerText = layout?.headerText || "TAX INVOICE";
  const subHeading = layout?.subHeading || "ORIGINAL FOR RECIPIENT";
  const showCustomerDetails = layout?.showCustomerDetails ?? true;
  const showSku = layout?.showSku ?? true;
  const showDiscount = layout?.showDiscount ?? true;
  const showTax = layout?.showTax ?? true;
  const footerText = layout?.footerText || "Thank you for doing business with us!";
  const termsConditions = layout?.termsConditions || "1. Goods once sold will not be taken back.\n2. Warranty as per manufacturer policy.";
  const bankDetails = layout?.bankDetails || "";

  return (
    <div className="w-full max-w-[190mm] mx-auto border border-border bg-card text-card-foreground p-6 font-sans text-xs shadow-md rounded max-h-[75vh] overflow-y-auto overflow-x-auto">
      {/* Header */}
      <div className="flex justify-between items-start border-b-2 border-foreground pb-4 mb-4">
        <div>
          <h1 className="text-xl font-extrabold uppercase tracking-wider text-foreground">{headerText}</h1>
          <p className="text-[10px] font-semibold text-muted-foreground uppercase">{subHeading}</p>
          <h2 className="text-base font-bold text-primary mt-2">{businessName}</h2>
          <p className="text-xs text-muted-foreground">{sale.branch?.name}</p>
          {sale.branch?.address && <p className="text-xs text-muted-foreground">{sale.branch.address}</p>}
          {sale.branch?.phone && <p className="text-xs text-muted-foreground">Phone: {sale.branch.phone}</p>}
        </div>
        <div className="text-right space-y-1">
          <p className="text-sm font-bold text-foreground">Invoice #: {sale.invoiceNumber}</p>
          <p className="text-xs text-muted-foreground">Date: {new Date(sale.saleDate).toLocaleDateString()}</p>
        </div>
      </div>

      {/* Customer & Payment info */}
      <div className="grid grid-cols-2 gap-4 pb-4 mb-4 border-b border-border/60">
        <div>
          <span className="text-[10px] font-bold text-muted-foreground uppercase block mb-1">Billed To:</span>
          {showCustomerDetails ? (
            <div>
              <p className="font-bold text-sm text-foreground">{sale.customer?.name || "Walk-in Customer"}</p>
              {sale.customer?.address && <p className="text-xs text-muted-foreground">{sale.customer.address}</p>}
              {sale.customer?.phone && <p className="text-xs text-muted-foreground">Phone: {sale.customer.phone}</p>}
              {sale.customer?.taxNumber && <p className="text-xs text-muted-foreground">GSTIN: {sale.customer.taxNumber}</p>}
            </div>
          ) : (
            <p className="font-semibold text-foreground">Walk-in Customer</p>
          )}
        </div>
        <div>
          <span className="text-[10px] font-bold text-muted-foreground uppercase block mb-1">Payment Status:</span>
          <p className="font-bold text-sm text-foreground">
            {sale.amountPaid >= sale.grandTotal ? (
              <span className="text-emerald-500">PAID</span>
            ) : (
              <span className="text-destructive">PARTIAL / DUE</span>
            )}
          </p>
          <p className="text-xs text-muted-foreground">Amount Paid: {cur}{sale.amountPaid.toFixed(2)}</p>
          <p className="text-xs text-muted-foreground">
            Balance Due: {cur}{Math.max(0, sale.grandTotal - sale.amountPaid).toFixed(2)}
          </p>
        </div>
      </div>

      {/* Items Table */}
      <table className="w-full text-xs border border-border mb-4 border-collapse">
        <thead>
          <tr className="bg-muted/40 border-b border-border text-foreground font-bold">
            <th className="p-2 text-left w-8">#</th>
            <th className="p-2 text-left">Item Description</th>
            {showSku && <th className="p-2 text-left w-24">SKU</th>}
            <th className="p-2 text-right w-16" style={{ textAlign: 'right' }}>Qty</th>
            <th className="p-2 text-right w-20" style={{ textAlign: 'right' }}>Unit Price</th>
            {showDiscount && <th className="p-2 text-right w-20" style={{ textAlign: 'right' }}>Discount</th>}
            {showTax && <th className="p-2 text-right w-20" style={{ textAlign: 'right' }}>Tax</th>}
            <th className="p-2 text-right w-24" style={{ textAlign: 'right' }}>Total</th>
          </tr>
        </thead>
        <tbody>
          {sale.saleLines?.map((line, idx) => {
            const imeiStr = line.imeiNumber || line.productImeis?.map(i => i.imeiNumber).join(", ");
            return (
              <tr key={line.id} className="border-b border-border/40">
                <td className="p-2">{idx + 1}</td>
                <td className="p-2">
                  <div className="font-medium">{line.variant?.product?.name || line.variant?.name}</div>
                  {imeiStr && (
                    <div className="text-[10px] text-muted-foreground font-mono mt-0.5">
                      IMEI/SN: {imeiStr}
                    </div>
                  )}
                </td>
                {showSku && <td className="p-2 text-muted-foreground">{line.variant?.sku || "-"}</td>}
                <td className="p-2 text-right" style={{ textAlign: 'right' }}>{line.quantity}</td>
                <td className="p-2 text-right" style={{ textAlign: 'right' }}>{cur}{line.unitPrice.toFixed(2)}</td>
                {showDiscount && <td className="p-2 text-right" style={{ textAlign: 'right' }}>{cur}{(line.discountAmount || 0).toFixed(2)}</td>}
                {showTax && <td className="p-2 text-right" style={{ textAlign: 'right' }}>{cur}{(line.taxAmount || 0).toFixed(2)}</td>}
                <td className="p-2 text-right font-semibold" style={{ textAlign: 'right' }}>{cur}{line.subtotal.toFixed(2)}</td>
              </tr>
            );
          })}
        </tbody>
      </table>

      {/* Totals */}
      <div className="flex justify-end mb-6">
        <div className="w-64 space-y-1 text-right">
          {showDiscount && sale.discountAmount > 0 && (
            <p className="text-xs text-muted-foreground">Discount: -{cur}{sale.discountAmount.toFixed(2)}</p>
          )}
          {showTax && sale.taxAmount > 0 && (
            <p className="text-xs text-muted-foreground">Tax Amount: +{cur}{sale.taxAmount.toFixed(2)}</p>
          )}
          <div className="border-t-2 border-b-2 border-foreground py-1.5 flex justify-between font-bold text-sm">
            <span>Grand Total:</span>
            <span>{cur}{sale.grandTotal.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* Footer & Signature */}
      <div className="grid grid-cols-2 gap-4 items-end pt-4 border-t border-border/60">
        <div className="text-[10px] space-y-2 bg-muted/20 p-3 rounded border border-border/40">
          {bankDetails && (
            <div>
              <span className="font-bold text-foreground block">Bank Details:</span>
              <p className="whitespace-pre-line text-muted-foreground">{bankDetails}</p>
            </div>
          )}
          {termsConditions && (
            <div>
              <span className="font-bold text-foreground block">Terms & Conditions:</span>
              <p className="whitespace-pre-line text-muted-foreground">{termsConditions}</p>
            </div>
          )}
        </div>

        <div className="text-center ml-auto w-48 space-y-8 pt-4">
          <div className="border-t border-foreground pt-1 text-xs font-bold">
            For {businessName}
            <p className="text-[9px] font-normal text-muted-foreground">(Authorized Signatory)</p>
          </div>
        </div>
      </div>

      <p className="text-center text-[10px] text-muted-foreground mt-6">{footerText}</p>
    </div>
  );
}
