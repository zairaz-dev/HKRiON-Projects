import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class PaymentMethodsService {
  constructor(private readonly prisma: PrismaService) {}

  async createPaymentMethod(data: {
    name: string;
    code: string;
    description?: string;
    sortOrder?: number;
    businessId: string;
    createdById?: string;
    branchIds?: string[];
  }) {
    const { name, code, description, sortOrder, businessId, createdById, branchIds } = data;

    // Code validation
    if (!/^[a-z0-9_]+$/.test(code)) {
      throw new BadRequestException('Code must be lowercase and alphanumeric (underscores allowed)');
    }

    // Check unique constraints
    const existingCode = await this.prisma.paymentMethod.findFirst({
      where: { code, businessId },
    });
    if (existingCode) {
      throw new BadRequestException('Payment method with this code already exists in this business');
    }

    const existingName = await this.prisma.paymentMethod.findFirst({
      where: { name, businessId },
    });
    if (existingName) {
      throw new BadRequestException('Payment method with this name already exists in this business');
    }

    return this.prisma.$transaction(async (tx) => {
      const paymentMethod = await tx.paymentMethod.create({
        data: {
          name,
          code,
          description,
          sortOrder: sortOrder || 0,
          isSystem: false,
          businessId,
          createdById,
        },
      });

      if (branchIds && branchIds.length > 0) {
        await tx.branchPaymentMethod.createMany({
          data: branchIds.map((branchId) => ({
            branchId,
            paymentMethodId: paymentMethod.id,
            isActive: true,
          })),
        });
      }

      return tx.paymentMethod.findUnique({
        where: { id: paymentMethod.id },
        include: {
          branches: true,
        },
      });
    });
  }

  async getPaymentMethods(businessId: string, branchId?: string, onlyActive?: boolean) {
    const whereClause: any = {
      businessId,
      isActive: true, // Business level soft delete check
    };

    if (branchId) {
      whereClause.branches = {
        some: {
          branchId,
          ...(onlyActive ? { isActive: true } : {}),
        },
      };
    }

    return this.prisma.paymentMethod.findMany({
      where: whereClause,
      include: {
        branches: {
          include: {
            branch: true,
          },
        },
      },
      orderBy: {
        sortOrder: 'asc',
      },
    });
  }

  async getPaymentMethodById(id: string, businessId: string) {
    const method = await this.prisma.paymentMethod.findFirst({
      where: { id, businessId },
      include: {
        branches: {
          include: {
            branch: true,
          },
        },
      },
    });

    if (!method) {
      throw new NotFoundException('Payment method not found');
    }

    return method;
  }

  async updatePaymentMethod(
    id: string,
    businessId: string,
    data: {
      name?: string;
      description?: string;
      isActive?: boolean;
      sortOrder?: number;
      branchIds?: string[];
      updatedById?: string;
    },
  ) {
    const method = await this.getPaymentMethodById(id, businessId);

    // Block immutable code change if code was passed (should not be in DTO, but check to be safe)
    if ((data as any).code && (data as any).code !== method.code) {
      throw new BadRequestException('Code is immutable and cannot be changed');
    }

    if (data.name && data.name !== method.name) {
      const existingName = await this.prisma.paymentMethod.findFirst({
        where: {
          name: data.name,
          businessId,
          id: { not: id },
        },
      });
      if (existingName) {
        throw new BadRequestException('Payment method with this name already exists in this business');
      }
    }

    return this.prisma.$transaction(async (tx) => {
      const updated = await tx.paymentMethod.update({
        where: { id },
        data: {
          name: data.name,
          description: data.description,
          isActive: data.isActive,
          sortOrder: data.sortOrder,
          updatedById: data.updatedById,
        },
      });

      if (data.branchIds) {
        // Sync branch associations
        await tx.branchPaymentMethod.deleteMany({
          where: {
            paymentMethodId: id,
            branchId: { notIn: data.branchIds },
          },
        });

        for (const branchId of data.branchIds) {
          await tx.branchPaymentMethod.upsert({
            where: {
              branchId_paymentMethodId: {
                branchId,
                paymentMethodId: id,
              },
            },
            update: {}, // keep existing isActive status
            create: {
              branchId,
              paymentMethodId: id,
              isActive: true,
            },
          });
        }
      }

      return tx.paymentMethod.findUnique({
        where: { id },
        include: {
          branches: {
            include: {
              branch: true,
            },
          },
        },
      });
    });
  }

  async deletePaymentMethod(id: string, businessId: string) {
    const method = await this.getPaymentMethodById(id, businessId);

    // If it's a system payment method, we soft delete it by setting isActive: false
    if (method.isSystem) {
      await this.prisma.paymentMethod.update({
        where: { id },
        data: { isActive: false },
      });
      return { success: true, message: 'System payment method deactivated successfully' };
    }

    // Custom payment method: soft delete as well (per "Use soft delete via isActive; never hard delete system payment methods")
    await this.prisma.paymentMethod.update({
      where: { id },
      data: { isActive: false },
    });
    return { success: true, message: 'Payment method deleted successfully' };
  }

  async updateBranchStatus(
    paymentMethodId: string,
    branchId: string,
    businessId: string,
    isActive: boolean,
  ) {
    // Validate ownership
    await this.getPaymentMethodById(paymentMethodId, businessId);

    return this.prisma.branchPaymentMethod.upsert({
      where: {
        branchId_paymentMethodId: {
          branchId,
          paymentMethodId,
        },
      },
      update: { isActive },
      create: {
        branchId,
        paymentMethodId,
        isActive,
      },
    });
  }
}
