"use client";

import { useState } from "react";
import Image from "next/image";
import {
  FolderKanban,
  Plus,
  Edit3,
  ExternalLink,
  Search,
  Save,
  X,
  Sparkles,
} from "lucide-react";
import Link from "next/link";
import ImageUploadInput from "@/components/admin/ImageUploadInput";

interface ProjectItem {
  id: string;
  title: string;
  category: "Residential" | "Commercial" | "Hospitality";
  description: string;
  imageUrl: string;
  location: string;
  status: "Published" | "Draft";
}

export default function AdminProjectsPage() {
  const [projects, setProjects] = useState<ProjectItem[]>([
    {
      id: "p1",
      title: "Luxury Residential Villa",
      category: "Residential",
      description: "Motorized zebra blinds and automated sheer drapery across master suites.",
      imageUrl: "/gallery_1.png",
      location: "Colombo 07",
      status: "Published",
    },
    {
      id: "p2",
      title: "Corporate HQ Glass Facade",
      category: "Commercial",
      description: "Solar screen roller blinds with heat deflection and glare control.",
      imageUrl: "/gallery_2.png",
      location: "World Trade Center",
      status: "Published",
    },
    {
      id: "p3",
      title: "Boutique Beach Resort Pergola",
      category: "Hospitality",
      description: "Architectural motorized louvre pergola and waterproof canopy awnings.",
      imageUrl: "/gallery_3.png",
      location: "Bentota Coast",
      status: "Published",
    },
    {
      id: "p4",
      title: "Modern Penthouse Verandah",
      category: "Residential",
      description: "Heavy-duty monsoon PVC clear screens engineered for high winds.",
      imageUrl: "/gallery_4.png",
      location: "Havelock City",
      status: "Published",
    },
  ]);

  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("ALL");

  const filteredProjects = projects.filter((p) => {
    const matchesCat = activeCategory === "ALL" || p.category === activeCategory;
    const matchesSearch =
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6 w-full pb-16">
      {/* Header */}
      <div className="bg-white dark:bg-black p-6 sm:p-7 rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 px-2.5 py-0.5 rounded-none">
              PORTFOLIO & SHOWCASE
            </span>
            <span className="text-xs text-neutral-400 dark:text-neutral-500">• Featured Project Cards</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white tracking-tight">
            Featured Projects
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Visual cards showcase for high-end residential villas, corporate offices, and resort installations.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/projects"
            target="_blank"
            className="inline-flex items-center gap-2 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-900 dark:hover:bg-neutral-850 text-neutral-800 dark:text-neutral-200 font-bold px-4 py-2 rounded-none text-xs border border-[#E5E5E0] dark:border-neutral-800 transition-all active:scale-95"
          >
            <span>Live Portfolio</span>
            <ExternalLink size={12} className="text-neutral-500 dark:text-neutral-400" />
          </Link>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-white dark:bg-black p-4 rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 scrollbar-none">
          {["ALL", "Residential", "Commercial", "Hospitality"].map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-none text-xs font-bold transition-all whitespace-nowrap cursor-pointer border ${
                activeCategory === cat
                  ? "bg-amber-500 text-slate-950 border-amber-600 shadow-xs"
                  : "bg-neutral-50 dark:bg-neutral-950 hover:bg-neutral-100 dark:hover:bg-neutral-900 text-neutral-600 dark:text-neutral-300 border-[#E5E5E0] dark:border-neutral-800"
              }`}
            >
              {cat === "ALL" ? `All Projects (${projects.length})` : cat}
            </button>
          ))}
        </div>

        <div className="relative w-full md:w-64">
          <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-500 pointer-events-none" />
          <input
            type="text"
            placeholder="Search project..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 dark:placeholder:text-neutral-500 outline-hidden font-medium"
          />
        </div>
      </div>

      {/* Visual Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
        {filteredProjects.map((project) => (
          <div
            key={project.id}
            className="bg-white dark:bg-black rounded-none border border-[#E5E5E0] dark:border-neutral-800 overflow-hidden shadow-2xs hover:shadow-md hover:border-amber-400/50 dark:hover:border-amber-400/50 transition-all flex flex-col group"
          >
            <div className="relative h-48 w-full bg-neutral-100 dark:bg-neutral-950 overflow-hidden">
              <Image
                src={project.imageUrl}
                alt={project.title}
                fill
                sizes="300px"
                className="object-cover group-hover:scale-105 transition-transform duration-500"
                unoptimized
              />
              <div className="absolute inset-0 bg-linear-to-t from-black/70 via-black/20 to-transparent" />

              <span className="absolute top-3 left-3 bg-neutral-900/80 backdrop-blur-xs text-amber-400 border border-amber-400/30 text-[10px] font-bold px-2.5 py-0.5 rounded-none shadow-xs">
                {project.category}
              </span>

              <div className="absolute bottom-3 left-3 right-3">
                <h3 className="text-sm font-black text-white truncate drop-shadow-xs">
                  {project.title}
                </h3>
                <p className="text-[10px] text-amber-300 font-medium">{project.location}</p>
              </div>
            </div>

            <div className="p-4 flex flex-col grow justify-between space-y-3">
              <p className="text-xs text-neutral-500 dark:text-neutral-400 line-clamp-2 leading-relaxed">
                {project.description}
              </p>

              <button
                type="button"
                onClick={() => setSelectedProject(project)}
                className="w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded-none bg-neutral-50 dark:bg-neutral-900 hover:bg-amber-500 dark:hover:bg-amber-500 hover:text-slate-950 dark:hover:text-slate-950 text-neutral-700 dark:text-neutral-200 text-xs font-bold border border-[#E5E5E0] dark:border-neutral-800 hover:border-amber-600 transition-all cursor-pointer"
              >
                <Edit3 size={12} />
                <span>Edit Project</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Edit Project Drawer / Modal */}
      {selectedProject && (
        <div className="fixed inset-0 z-50 bg-neutral-950/80 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-black w-full max-w-lg rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-6 py-4 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between bg-neutral-50 dark:bg-neutral-950">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
                  EDIT PROJECT
                </span>
                <h3 className="text-base font-bold text-neutral-900 dark:text-white mt-0.5">
                  {selectedProject.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedProject(null)}
                className="p-1.5 rounded-none text-neutral-400 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-900 cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs overflow-y-auto">
              <div>
                <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">Project Title</label>
                <input
                  type="text"
                  defaultValue={selectedProject.title}
                  className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">Category</label>
                  <select
                    defaultValue={selectedProject.category}
                    className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                  >
                    <option value="Residential">Residential</option>
                    <option value="Commercial">Commercial</option>
                    <option value="Hospitality">Hospitality</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">Location</label>
                  <input
                    type="text"
                    defaultValue={selectedProject.location}
                    className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">Description</label>
                <textarea
                  rows={3}
                  defaultValue={selectedProject.description}
                  className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                />
              </div>

              <div>
                <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">Upload Image</label>
                <ImageUploadInput
                  name="imageUrl"
                  defaultValue={selectedProject.imageUrl}
                  placeholder="/gallery_1.png"
                />
              </div>

              <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedProject(null)}
                  className="px-4 py-2 rounded-none bg-neutral-100 dark:bg-neutral-900 hover:bg-neutral-200 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedProject(null)}
                  className="inline-flex items-center gap-1.5 px-5 py-2 rounded-none bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-extrabold shadow-xs cursor-pointer"
                >
                  <Save size={13} />
                  <span>Save Changes</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
