"use client";

import React, {
  createContext,
  useContext,
  useState,
  useCallback,
  useEffect,
  useRef,
} from "react";

export type ToastVariant = "gold" | "success" | "error" | "warning" | "info";

export interface ToastAction {
  label: string;
  onClick: () => void;
}

export interface ToastItem {
  id: string;
  title?: string;
  message: string;
  variant: ToastVariant;
  duration: number; // in ms; 0 means manual dismiss only
  action?: ToastAction;
  createdAt: number;
  count?: number;
}

export interface ConfirmOptions {
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: "danger" | "gold" | "info";
  badgeText?: string;
}

interface ToastContextValue {
  toast: {
    show: (
      message: string,
      options?: {
        title?: string;
        variant?: ToastVariant;
        duration?: number;
        action?: ToastAction;
      }
    ) => string;
    gold: (titleOrMessage: string, messageOrDuration?: string | number) => string;
    success: (titleOrMessage: string, messageOrDuration?: string | number) => string;
    error: (titleOrMessage: string, messageOrDuration?: string | number) => string;
    warning: (titleOrMessage: string, messageOrDuration?: string | number) => string;
    info: (titleOrMessage: string, messageOrDuration?: string | number) => string;
    dismiss: (id?: string) => void;
  };
  confirm: (options: ConfirmOptions) => Promise<boolean>;
}

const ToastContext = createContext<ToastContextValue | null>(null);

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error("useToast must be used within a ToastProvider");
  }
  return context;
}

// Global dispatcher support so non-React contexts can also dispatch notifications
let globalShowToast: ((msg: string, opt?: any) => string) | null = null;
export const luxuryToast = {
  show: (msg: string, opt?: any) => globalShowToast?.(msg, opt),
  success: (title: string, msg?: string) =>
    globalShowToast?.(msg || title, { title: msg ? title : undefined, variant: "success" }),
  error: (title: string, msg?: string) =>
    globalShowToast?.(msg || title, { title: msg ? title : undefined, variant: "error" }),
  gold: (title: string, msg?: string) =>
    globalShowToast?.(msg || title, { title: msg ? title : undefined, variant: "gold" }),
  warning: (title: string, msg?: string) =>
    globalShowToast?.(msg || title, { title: msg ? title : undefined, variant: "warning" }),
  info: (title: string, msg?: string) =>
    globalShowToast?.(msg || title, { title: msg ? title : undefined, variant: "info" }),
};

/* =========================================================================
   PROVIDER
   ========================================================================= */
export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [activeToast, setActiveToast] = useState<ToastItem | null>(null);
  const [confirmState, setConfirmState] = useState<{
    options: ConfirmOptions;
    resolve: (value: boolean) => void;
  } | null>(null);

  const dismiss = useCallback((id?: string) => {
    setActiveToast((prev) => {
      if (!prev) return null;
      if (id && prev.id !== id) return prev;
      return null;
    });
  }, []);

  const show = useCallback(
    (
      message: string,
      options?: {
        title?: string;
        variant?: ToastVariant;
        duration?: number;
        action?: ToastAction;
      }
    ) => {
      const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
      const variant = options?.variant || "gold";
      const duration = options?.duration ?? 4200;

      setActiveToast((prev) => {
        // If the same toast is triggered again (e.g. repeated button clicks)
        if (prev && prev.message === message && prev.title === options?.title) {
          return {
            ...prev,
            id, // fresh id triggers animation pulse & resets countdown
            duration,
            action: options?.action,
            count: (prev.count || 1) + 1,
            createdAt: Date.now(),
          };
        }
        // If a new or different notification arrives, display directly in the same spot
        return {
          id,
          message,
          title: options?.title,
          variant,
          duration,
          action: options?.action,
          createdAt: Date.now(),
          count: 1,
        };
      });

      return id;
    },
    []
  );

  useEffect(() => {
    globalShowToast = show;
    return () => {
      globalShowToast = null;
    };
  }, [show]);

  const helper = useCallback(
    (variant: ToastVariant) => {
      return (titleOrMessage: string, messageOrDuration?: string | number) => {
        if (typeof messageOrDuration === "string") {
          return show(messageOrDuration, { title: titleOrMessage, variant });
        }
        return show(titleOrMessage, {
          variant,
          duration: typeof messageOrDuration === "number" ? messageOrDuration : 4200,
        });
      };
    },
    [show]
  );

  const confirm = useCallback((options: ConfirmOptions): Promise<boolean> => {
    return new Promise((resolve) => {
      setConfirmState({ options, resolve });
    });
  }, []);

  const handleConfirmClose = (result: boolean) => {
    if (confirmState) {
      confirmState.resolve(result);
      setConfirmState(null);
    }
  };

  const contextValue: ToastContextValue = {
    toast: {
      show,
      gold: helper("gold"),
      success: helper("success"),
      error: helper("error"),
      warning: helper("warning"),
      info: helper("info"),
      dismiss,
    },
    confirm,
  };

  return (
    <ToastContext.Provider value={contextValue}>
      {children}

      {/* Floating Toast Notification - Dedicated Single Anchor (Over & Over in Same Spot) */}
      <div
        className="fixed top-20 right-4 left-4 sm:left-auto sm:right-6 z-[100050] pointer-events-none sm:max-w-md w-auto flex justify-end"
        aria-live="polite"
        aria-atomic="true"
      >
        {activeToast && (
          <ToastCard
            key={activeToast.id}
            toast={activeToast}
            onDismiss={() => dismiss(activeToast.id)}
          />
        )}
      </div>

      {/* Toast Confirmation Dialog Modal */}
      {confirmState && (
        <ConfirmModal
          options={confirmState.options}
          onConfirm={() => handleConfirmClose(true)}
          onCancel={() => handleConfirmClose(false)}
        />
      )}
    </ToastContext.Provider>
  );
}

/* =========================================================================
   TOAST ITEM CARD
   ========================================================================= */
function ToastCard({
  toast,
  onDismiss,
}: {
  toast: ToastItem;
  onDismiss: () => void;
}) {
  const [isExiting, setIsExiting] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [remainingTime, setRemainingTime] = useState(toast.duration);
  const startTimeRef = useRef(Date.now());
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const triggerDismiss = useCallback(() => {
    setIsExiting(true);
    setTimeout(() => {
      onDismiss();
    }, 220);
  }, [onDismiss]);

  // Countdown auto-dismiss
  useEffect(() => {
    if (toast.duration <= 0) return;

    if (isPaused) {
      if (timerRef.current) clearTimeout(timerRef.current);
      return;
    }

    startTimeRef.current = Date.now();
    timerRef.current = setTimeout(() => {
      triggerDismiss();
    }, remainingTime);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [toast.id, toast.duration, remainingTime, isPaused, triggerDismiss]);

  // Reset when toast is refreshed/updated in place (e.g. repeated click)
  useEffect(() => {
    setRemainingTime(toast.duration);
    setIsExiting(false);
    startTimeRef.current = Date.now();
  }, [toast.id, toast.duration, toast.count]);

  const handleMouseEnter = () => {
    if (toast.duration <= 0) return;
    setIsPaused(true);
    const elapsed = Date.now() - startTimeRef.current;
    setRemainingTime((prev) => Math.max(0, prev - elapsed));
  };

  const handleMouseLeave = () => {
    if (toast.duration <= 0) return;
    setIsPaused(false);
  };

  // Luxury theme variant styling
  const variantStyles = {
    gold: {
      border: "border-[#C5A880]/50",
      bg: "bg-[#141419]/95",
      glow: "shadow-[0_16px_40px_-6px_rgba(197,168,128,0.25)]",
      topHighlight: "bg-gradient-to-r from-transparent via-[#C5A880] to-transparent",
      iconBg: "bg-[#201D17] border-[#C5A880]/40 text-[#C5A880]",
      titleColor: "text-[#FAF8F5]",
      barColor: "bg-[#C5A880]",
      badge: "bg-[#C5A880]/20 text-[#E0CFA9] border-[#C5A880]/40",
    },
    success: {
      border: "border-emerald-500/40",
      bg: "bg-[#101713]/95",
      glow: "shadow-[0_16px_40px_-6px_rgba(16,185,129,0.25)]",
      topHighlight: "bg-gradient-to-r from-transparent via-emerald-400 to-transparent",
      iconBg: "bg-emerald-950/70 border-emerald-500/40 text-emerald-400",
      titleColor: "text-[#FAF8F5]",
      barColor: "bg-emerald-400",
      badge: "bg-emerald-500/20 text-emerald-300 border-emerald-500/40",
    },
    error: {
      border: "border-rose-500/45",
      bg: "bg-[#1B1114]/95",
      glow: "shadow-[0_16px_40px_-6px_rgba(244,63,94,0.28)]",
      topHighlight: "bg-gradient-to-r from-transparent via-rose-500 to-transparent",
      iconBg: "bg-rose-950/70 border-rose-500/40 text-rose-400",
      titleColor: "text-[#FAF8F5]",
      barColor: "bg-rose-500",
      badge: "bg-rose-500/20 text-rose-300 border-rose-500/40",
    },
    warning: {
      border: "border-amber-500/40",
      bg: "bg-[#1B170E]/95",
      glow: "shadow-[0_16px_40px_-6px_rgba(245,158,11,0.25)]",
      topHighlight: "bg-gradient-to-r from-transparent via-amber-400 to-transparent",
      iconBg: "bg-amber-950/70 border-amber-500/40 text-amber-400",
      titleColor: "text-[#FAF8F5]",
      barColor: "bg-amber-400",
      badge: "bg-amber-500/20 text-amber-300 border-amber-500/40",
    },
    info: {
      border: "border-sky-500/40",
      bg: "bg-[#0E1520]/95",
      glow: "shadow-[0_16px_40px_-6px_rgba(56,189,248,0.25)]",
      topHighlight: "bg-gradient-to-r from-transparent via-sky-400 to-transparent",
      iconBg: "bg-sky-950/70 border-sky-500/40 text-sky-400",
      titleColor: "text-[#FAF8F5]",
      barColor: "bg-sky-400",
      badge: "bg-sky-500/20 text-sky-300 border-sky-500/40",
    },
  }[toast.variant];

  return (
    <div
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      className={`pointer-events-auto relative overflow-hidden rounded-md border backdrop-blur-xl transition-all duration-200 w-full sm:w-[380px] max-w-full ${
        isExiting
          ? "opacity-0 translate-x-4 scale-95 pointer-events-none"
          : toast.count && toast.count > 1
          ? "opacity-100 translate-x-0 scale-100 animate-luxury-toast-pulse"
          : "opacity-100 translate-x-0 scale-100 animate-luxury-toast-in"
      } ${variantStyles.bg} ${variantStyles.border} ${variantStyles.glow}`}
      role="status"
    >
      {/* Luxury Specular Top Highlight */}
      <div className={`absolute top-0 left-0 right-0 h-[1.5px] ${variantStyles.topHighlight}`} />

      <div className="p-4 flex items-start gap-3.5">
        {/* Jewel Icon Halo */}
        <div
          className={`w-8 h-8 rounded-full border flex items-center justify-center shrink-0 shadow-inner ${variantStyles.iconBg}`}
        >
          {toast.variant === "gold" && <FacetedDiamondIcon className="w-4 h-4" />}
          {toast.variant === "success" && <EmeraldCheckIcon className="w-4 h-4" />}
          {toast.variant === "error" && <RubyShieldAlertIcon className="w-4 h-4" />}
          {toast.variant === "warning" && <AmberAlertTriangleIcon className="w-4 h-4" />}
          {toast.variant === "info" && <SapphireInfoIcon className="w-4 h-4" />}
        </div>

        {/* Content Column */}
        <div className="flex-1 min-w-0 pr-1">
          <div className="flex items-center gap-2">
            {toast.title && (
              <h4
                className={`font-serif text-xs sm:text-sm font-semibold tracking-wide leading-snug truncate ${variantStyles.titleColor}`}
              >
                {toast.title}
              </h4>
            )}
            {/* Repeated Action Counter Pill */}
            {toast.count && toast.count > 1 && (
              <span
                className={`inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-mono font-medium tracking-tight border shrink-0 ${variantStyles.badge}`}
              >
                &times;{toast.count}
              </span>
            )}
          </div>
          <p className="text-xs text-[#BAB5AE] font-sans leading-relaxed mt-0.5 break-words">
            {toast.message}
          </p>

          {/* Action Button if specified */}
          {toast.action && (
            <button
              onClick={() => {
                toast.action?.onClick();
                triggerDismiss();
              }}
              className="mt-2.5 inline-flex items-center text-[11px] font-mono uppercase tracking-wider text-[#C5A880] hover:text-[#E0CFA9] underline underline-offset-4 transition-colors"
            >
              {toast.action.label} &rarr;
            </button>
          )}
        </div>

        {/* Manual Dismiss Button */}
        <button
          onClick={triggerDismiss}
          aria-label="Dismiss Notification"
          className="shrink-0 p-1 text-[#8C867D] hover:text-white rounded hover:bg-white/10 transition-colors -mr-1 -mt-1"
        >
          <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        </button>
      </div>

      {/* Auto-dismiss Animated Progress Line */}
      {toast.duration > 0 && (
        <div className="h-[2px] w-full bg-white/5 overflow-hidden">
          <div
            className={`h-full ${variantStyles.barColor} transition-all ease-linear`}
            style={{
              width: isPaused ? `${(remainingTime / toast.duration) * 100}%` : "0%",
              transitionDuration: isPaused ? "0ms" : `${remainingTime}ms`,
            }}
          />
        </div>
      )}
    </div>
  );
}

/* =========================================================================
   CONFIRMATION MODAL (TOAST CONFIRMATION MESSAGE)
   ========================================================================= */
function ConfirmModal({
  options,
  onConfirm,
  onCancel,
}: {
  options: ConfirmOptions;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  const confirmButtonRef = useRef<HTMLButtonElement | null>(null);

  // Focus trap & Escape key handler
  useEffect(() => {
    confirmButtonRef.current?.focus();

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        onCancel();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onCancel]);

  const variant = options.variant || "gold";

  const modalTheme = {
    danger: {
      accentLine: "bg-gradient-to-r from-red-600 via-rose-500 to-red-600",
      badgeColor: "text-red-400 bg-red-950/40 border-red-500/30",
      iconBg: "bg-rose-950/80 border-rose-500/50 text-rose-400",
      confirmBtn:
        "bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white shadow-lg shadow-red-950/60 focus:ring-rose-500",
      icon: <RubyShieldAlertIcon className="w-6 h-6" />,
      defaultBadge: "Irreversible Action",
    },
    gold: {
      accentLine: "bg-gradient-to-r from-[#856738] via-[#C5A880] to-[#E0CFA9]",
      badgeColor: "text-[#C5A880] bg-[#C5A880]/15 border-[#C5A880]/30",
      iconBg: "bg-[#1E1C16] border-[#C5A880]/50 text-[#C5A880]",
      confirmBtn:
        "bg-gradient-to-r from-[#C5A880] to-[#E0CFA9] hover:from-[#D4AF37] hover:to-[#F3E5AB] text-[#0D0D11] font-semibold shadow-lg shadow-[#C5A880]/20 focus:ring-[#C5A880]",
      icon: <FacetedDiamondIcon className="w-6 h-6" />,
      defaultBadge: "Vault Confirmation",
    },
    info: {
      accentLine: "bg-gradient-to-r from-sky-600 via-sky-400 to-sky-600",
      badgeColor: "text-sky-400 bg-sky-950/40 border-sky-500/30",
      iconBg: "bg-sky-950/80 border-sky-500/50 text-sky-400",
      confirmBtn:
        "bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-500 hover:to-blue-600 text-white shadow-lg shadow-sky-950/60 focus:ring-sky-500",
      icon: <SapphireInfoIcon className="w-6 h-6" />,
      defaultBadge: "Vault Notice",
    },
  }[variant];

  return (
    <div
      className="fixed inset-0 z-[100060] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-luxury-backdrop"
      role="dialog"
      aria-modal="true"
      aria-labelledby="confirm-dialog-title"
    >
      {/* Backdrop click dismiss */}
      <div className="absolute inset-0" onClick={onCancel} />

      {/* Luxury Modal Card */}
      <div className="relative w-full max-w-md bg-[#141419] border border-[#2E2E3C] shadow-2xl rounded-sm overflow-hidden z-10 animate-luxury-modal">
        {/* Top Accent Strip */}
        <div className={`h-1 w-full ${modalTheme.accentLine}`} />

        <div className="p-6 sm:p-7">
          {/* Header Row: Badge & Close */}
          <div className="flex items-center justify-between gap-4 mb-4">
            <span
              className={`text-[10px] font-mono uppercase tracking-widest px-2.5 py-1 rounded-full border inline-flex items-center gap-1.5 ${modalTheme.badgeColor}`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-current" />
              {options.badgeText || modalTheme.defaultBadge}
            </span>

            <button
              onClick={onCancel}
              className="p-1 text-[#8C867D] hover:text-white rounded transition-colors"
              aria-label="Cancel"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          </div>

          {/* Main Visual & Body */}
          <div className="flex items-start gap-4">
            <div
              className={`w-12 h-12 rounded-full border flex items-center justify-center shrink-0 shadow-inner ${modalTheme.iconBg}`}
            >
              {modalTheme.icon}
            </div>

            <div className="flex-1">
              <h3
                id="confirm-dialog-title"
                className="font-serif text-lg sm:text-xl font-medium text-white tracking-wide leading-snug"
              >
                {options.title}
              </h3>
              <p className="mt-2 text-xs sm:text-sm text-[#9E9BA3] font-sans leading-relaxed">
                {options.message}
              </p>
            </div>
          </div>

          {/* Action Button Footer */}
          <div className="mt-6 pt-5 border-t border-[#24242C] flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2.5 bg-[#1C1C24] hover:bg-[#252530] text-[#9E9BA3] hover:text-white border border-[#2E2E3C] text-xs font-sans uppercase tracking-wider rounded-sm transition-colors"
            >
              {options.cancelLabel || "Cancel"}
            </button>
            <button
              ref={confirmButtonRef}
              type="button"
              onClick={onConfirm}
              className={`px-5 py-2.5 text-xs font-sans uppercase tracking-wider rounded-sm transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-[#141419] ${modalTheme.confirmBtn}`}
            >
              {options.confirmLabel || "Confirm"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* =========================================================================
   JEWEL SVG ICONOGRAPHY
   ========================================================================= */
function FacetedDiamondIcon({ className = "w-4 h-4" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M6 3h12l4 6-10 12L2 9l4-6z" />
      <path d="M2 9h20" />
      <path d="M10 3l-2 6 4 12 4-12-2-6" />
    </svg>
  );
}

function EmeraldCheckIcon({ className = "w-4 h-4" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M20 6L9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function RubyShieldAlertIcon({ className = "w-4 h-4" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
      <line x1="12" y1="8" x2="12" y2="12" strokeLinecap="round" />
      <circle cx="12" cy="16" r="0.75" fill="currentColor" />
    </svg>
  );
}

function AmberAlertTriangleIcon({ className = "w-4 h-4" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
      <line x1="12" y1="9" x2="12" y2="13" strokeLinecap="round" />
      <circle cx="12" cy="17" r="0.75" fill="currentColor" />
    </svg>
  );
}

function SapphireInfoIcon({ className = "w-4 h-4" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="12" cy="12" r="9" />
      <line x1="12" y1="16" x2="12" y2="12" strokeLinecap="round" />
      <circle cx="12" cy="8" r="0.75" fill="currentColor" />
    </svg>
  );
}
