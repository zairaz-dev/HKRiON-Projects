export const CreateBrandBodySchema = {
  type: 'object',
  properties: {
    name: { type: 'string', minLength: 2, maxLength: 100, example: 'HKRION Brand' },
    description: { type: 'string', maxLength: 500, example: 'High quality consumer goods' },
    businessId: { type: 'string', example: 'business-uuid-123' },
    branchIds: { type: 'array', items: { type: 'string' }, example: ['branch-uuid-1'] },
    isActive: { type: 'boolean', example: true },
    logoUrl: { type: 'string', example: '/uploads/brands/logo.png' },
    createdById: { type: 'string', example: 'user-uuid-123' }
  },
  required: ['name', 'businessId']
};

export const UpdateBrandBodySchema = {
  type: 'object',
  properties: {
    name: { type: 'string', minLength: 2, maxLength: 100, example: 'HKRION Brand Updated' },
    description: { type: 'string', maxLength: 500, example: 'Updated description' },
    businessId: { type: 'string', example: 'business-uuid-123' },
    branchIds: { type: 'array', items: { type: 'string' }, example: ['branch-uuid-1'] },
    isActive: { type: 'boolean', example: true },
    logoUrl: { type: 'string', example: '/uploads/brands/logo-updated.png' },
    updatedById: { type: 'string', example: 'user-uuid-123' }
  },
  required: ['businessId']
};

export const BrandResponseSchema = {
  type: 'object',
  properties: {
    id: { type: 'string', example: 'brand-uuid-123' },
    name: { type: 'string', example: 'HKRION Brand' },
    description: { type: 'string', example: 'High quality consumer goods' },
    logoUrl: { type: 'string', example: '/uploads/brands/logo.png' },
    isActive: { type: 'boolean', example: true },
    businessId: { type: 'string', example: 'business-uuid-123' }
  }
};
