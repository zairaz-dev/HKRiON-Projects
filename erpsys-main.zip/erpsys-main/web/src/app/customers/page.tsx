"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import {
  Users,
  Plus,
  Edit2,
  Trash2,
  Loader2,
  CheckCircle,
  AlertCircle,
  Building2,
  Globe,
  Eye,
  Coins,
  History,
} from "lucide-react";
import { CustomerPaymentDialog, CustomerPaymentsListDialog } from "@/features/customer-payments";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { DataTable, ColumnDef, ActionsDropdown } from "@/components/ui/table";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";
import { useCurrency } from "@/hooks/use-currency";
import { getFullAssetUrl } from "@/lib/utils";

import { Select } from "@/components/ui/select";

import {
  CustomerItem,
  CustomerDialog,
  CustomerDeleteDialog,
  useCustomersQuery,
  useBranchesQuery
} from "@/features/customers";

function CustomersPageContent() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Notifications
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Dialog States
  const [isDialogOpen, setIsDialogOpen] = useState<boolean>(false);
  const [editingCustomer, setEditingCustomer] = useState<CustomerItem | null>(null);
  const [customerToDelete, setCustomerToDelete] = useState<CustomerItem | null>(null);
  const [paymentCustomer, setPaymentCustomer] = useState<any | null>(null);
  const [historyCustomer, setHistoryCustomer] = useState<any | null>(null);

  // URL-driven Branch Filter
  const selectedBranchFilter = searchParams.get("branchId") || "all";

  const setSelectedBranchFilter = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value === "all") {
      params.delete("branchId");
    } else {
      params.set("branchId", value);
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  // Authenticate
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  // Fetch Data via React Query
  const businessId = currentUser?.businessId || "";
  const { symbol, format } = useCurrency(businessId);
  const { data: customers = [], isLoading: customersLoading, error: customersError } = useCustomersQuery(businessId);
  const { data: branchesList = [], isLoading: branchesLoading } = useBranchesQuery(businessId, currentUser?.id);

  // Handle Query Errors
  useEffect(() => {
    if (customersError) {
      setError(customersError.message || "Failed to load customers.");
    }
  }, [customersError]);

  // Auto-dismiss notifications
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  const handleOpenCreateModal = () => {
    setEditingCustomer(null);
    setIsDialogOpen(true);
  };

  const handleOpenEditModal = (customer: CustomerItem) => {
    if (customer.isDefault || customer.name.toLowerCase() === "walk-in customer") {
      setError("The default Walk-in Customer cannot be edited.");
      return;
    }
    setEditingCustomer(customer);
    setIsDialogOpen(true);
  };

  // Filter Logic
  const getFilteredCustomers = () => {
    let list = customers;

    if (selectedBranchFilter !== "all") {
      if (selectedBranchFilter === "global") {
        list = list.filter((c) => !c.branches || c.branches.length === 0);
      } else {
        list = list.filter((c) =>
          c.branches?.some((cb) => cb.branch.id === selectedBranchFilter)
        );
      }
    }

    return list;
  };

  const filteredList = getFilteredCustomers();

  // Columns Definition
  const columns: ColumnDef<CustomerItem>[] = [
    {
      header: "Customer Name",
      searchable: true,
      render: (customer) => (
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full border border-border/80 bg-secondary/40 overflow-hidden flex items-center justify-center shrink-0 shadow-sm">
            {customer.image ? (
              <img
                src={getFullAssetUrl(customer.image) || customer.image}
                alt={customer.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="text-xs font-bold font-mono text-primary uppercase">
                {customer.name.substring(0, 2)}
              </div>
            )}
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-foreground leading-tight">{customer.name}</span>
              {(customer.isDefault || customer.name.toLowerCase() === "walk-in customer") && (
                <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-primary/10 text-primary border border-primary/25 uppercase tracking-wide">
                  Default
                </span>
              )}
            </div>
            {customer.email && (
              <span className="text-[11px] text-muted-foreground font-mono">{customer.email}</span>
            )}
          </div>
        </div>
      ),
    },
    {
      header: "Business Name",
      render: (customer) => (
        <span className="text-xs font-medium text-foreground/80">
          {customer.businessName || <span className="text-muted-foreground italic">None</span>}
        </span>
      ),
    },
    {
      header: "Phone Number",
      render: (customer) => (
        <span className="text-xs font-mono">
          {customer.phone || <span className="text-muted-foreground italic">None</span>}
        </span>
      ),
    },
    {
      header: "Customer Group",
      render: (customer) => (
        <span className="text-xs font-medium text-foreground/80">
          {customer.customerGroup ? customer.customerGroup.name : <span className="text-muted-foreground italic">None</span>}
        </span>
      ),
    },
    {
      header: "Credit Limit",
      render: (customer) => (
        <span className="font-mono text-xs">
          {customer.creditLimit !== null ? customer.creditLimit : <span className="text-muted-foreground italic">Unlimited</span>}
        </span>
      ),
    },
    {
      header: "Outstanding Due",
      render: (customer) => {
        const opening = customer.openingBalance || 0;
        const totalSales = customer.sales?.reduce((sum, s) => sum + s.grandTotal, 0) || 0;
        const totalPaid = customer.sales?.reduce((sum, s) => sum + s.amountPaid, 0) || 0;
        const due = Math.max(0, (totalSales + opening) - totalPaid);
        return (
          <span className={`font-bold text-xs ${due > 0 ? "text-rose-500 font-extrabold" : "text-muted-foreground"}`}>
            {format(due)}
          </span>
        );
      },
    },
    {
      header: "Remaining Advance",
      render: (customer) => {
        const remaining = customer.advances?.reduce((sum, a) => sum + a.amountRemaining, 0) || 0;
        return (
          <span className={`font-bold text-xs ${remaining > 0 ? "text-emerald-500 font-extrabold" : "text-muted-foreground"}`}>
            {format(remaining)}
          </span>
        );
      },
    },
    {
      header: "Branch Scope",
      render: (customer) => {
        if (!customer.branches || customer.branches.length === 0) {
          return (
            <span className="inline-flex items-center gap-1 text-xs text-muted-foreground font-medium">
              <Globe className="h-3.5 w-3.5 text-muted-foreground/60" />
              Global
            </span>
          );
        }
        if (customer.branches.length === 1) {
          return (
            <span className="inline-flex items-center gap-1 text-xs text-foreground/80 font-medium">
              <Building2 className="h-3.5 w-3.5 text-muted-foreground/60" />
              {customer.branches[0].branch.name}
            </span>
          );
        }
        return (
          <span className="inline-flex items-center gap-1 text-xs text-primary font-medium">
            <Building2 className="h-3.5 w-3.5 text-primary/60" />
            {customer.branches.length} Branches
          </span>
        );
      },
    },
    {
      header: "Status",
      render: (customer) => (
        <span
          className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${
            customer.isActive
              ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
              : "bg-destructive/10 text-destructive border-destructive/20"
          }`}
        >
          {customer.isActive ? "Active" : "Inactive"}
        </span>
      ),
    },
    {
      header: "Actions",
      render: (customer) => {
        const isDefaultCustomer = customer.isDefault || customer.name.toLowerCase() === "walk-in customer";
        return (
          <ActionsDropdown
            actions={[
              {
                label: "View Profile",
                onClick: () => router.push(`/customers/view?id=${customer.id}`),
                icon: <Eye className="h-3.5 w-3.5" />,
              },
              {
                label: "Record Payment",
                onClick: () => setPaymentCustomer(customer),
                icon: <Coins className="h-3.5 w-3.5" />,
              },
              {
                label: "Payments History",
                onClick: () => setHistoryCustomer(customer),
                icon: <History className="h-3.5 w-3.5" />,
              },
              ...(!isDefaultCustomer
                ? [
                    {
                      label: "Edit",
                      onClick: () => handleOpenEditModal(customer),
                      icon: <Edit2 className="h-3.5 w-3.5" />,
                    },
                    {
                      label: "Delete",
                      onClick: () => setCustomerToDelete(customer),
                      icon: <Trash2 className="h-3.5 w-3.5" />,
                      variant: "destructive" as const,
                    },
                  ]
                : []),
            ]}
          />
        );
      },
    },
  ];

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3 p-6 max-w-sm border border-border/40 rounded-xl bg-card/60 backdrop-blur-sm">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <h2 className="text-lg font-bold">Unauthorized Access</h2>
          <p className="text-sm text-muted-foreground">
            You need to be logged in to view this page. Redirecting to login...
          </p>
          <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
        </div>
      </div>
    );
  }

  const isLoading = customersLoading || branchesLoading;

  const customFilters = (
    <div className="space-y-1.5 min-w-[200px]">
      <label className="text-[10px] font-bold text-muted-foreground uppercase">
        Branch Filter
      </label>
      <Select
        value={selectedBranchFilter}
        onValueChange={setSelectedBranchFilter}
        className="h-9 text-xs"
      >
        <option value="all">All Branches</option>
        <option value="global">Global (No Branch)</option>
        {branchesList.map((b) => (
          <option key={b.id} value={b.id}>
            {b.name}
          </option>
        ))}
      </Select>
    </div>
  );

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/customers" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Customers" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <Users className="h-7 w-7 text-primary" /> Customers
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Manage your customer database, billing/shipping details, credit limits, and branch mappings.
              </p>
            </div>
          </div>

          {/* Banner Notifications */}
          {successMessage && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 animate-in fade-in slide-in-from-top-4 duration-300">
              <CheckCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive animate-in fade-in slide-in-from-top-4 duration-300">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          {/* Main Table Card */}
          {isLoading ? (
            <div className="flex h-64 items-center justify-center">
              <div className="text-center space-y-2">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
                <span className="text-sm text-muted-foreground block">Loading customers...</span>
              </div>
            </div>
          ) : (
            <DataTable
              data={filteredList}
              columns={columns}
              searchKeys={["name"]}
              actionButton={{
                label: "Add Customer",
                onClick: handleOpenCreateModal,
                icon: <Plus className="h-4 w-4" />
              }}
              customFilters={customFilters}
              reportTitle="Customers Report"
            />
          )}
        </main>
      </div>

      {/* Create / Edit Modal Dialog */}
      {currentUser && (
        <CustomerDialog
          isOpen={isDialogOpen}
          onClose={() => {
            setIsDialogOpen(false);
            setEditingCustomer(null);
          }}
          customer={editingCustomer}
          branches={branchesList}
          currentUser={currentUser}
          onSuccess={setSuccessMessage}
          onError={setError}
        />
      )}

      {/* Delete Confirmation Dialog */}
      {currentUser && customerToDelete && (
        <CustomerDeleteDialog
          isOpen={!!customerToDelete}
          onClose={() => setCustomerToDelete(null)}
          customer={customerToDelete}
          currentUser={currentUser}
          onSuccess={setSuccessMessage}
          onError={setError}
        />
      )}

      {/* Customer Record Payment Dialog */}
      {currentUser && paymentCustomer && (
        <CustomerPaymentDialog
          isOpen={!!paymentCustomer}
          onClose={() => setPaymentCustomer(null)}
          sale={null}
          customer={paymentCustomer}
          currentUser={currentUser}
          onSuccess={setSuccessMessage}
          onError={setError}
        />
      )}

      {/* Customer Payments List Dialog */}
      {currentUser && historyCustomer && (
        <CustomerPaymentsListDialog
          isOpen={!!historyCustomer}
          onClose={() => setHistoryCustomer(null)}
          sale={null}
          customer={historyCustomer}
          currentUser={currentUser}
          onSuccess={setSuccessMessage}
          onError={setError}
        />
      )}
    </div>
  );
}

export default function CustomersPage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen w-screen items-center justify-center bg-[#121216]">
        <div className="flex flex-col items-center gap-2">
          <div className="w-8 h-8 border-4 border-zinc-700 border-t-emerald-500 rounded-full animate-spin" />
          <p className="text-sm text-zinc-400">Loading...</p>
        </div>
      </div>
    }>
      <CustomersPageContent />
    </Suspense>
  );
}
