export class UpdateSupplierDto {
  name?: string;
  image?: string;
  businessName?: string;
  email?: string;
  phone?: string;
  taxNumber?: string;
  openingBalance?: number;
  address?: string;
  businessId?: string;
  branchIds?: string[];
  isActive?: boolean;
  updatedById?: string;
}
