import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { X, Loader2, Coins } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { User } from "@hkr/types";
import { PurchaseItem } from "@/features/purchases/types";
import { useSupplierAdvancesQuery, useAllocateSupplierAdvanceMutation } from "../hooks/use-supplier-advances";
import { useCurrency } from "@/hooks/use-currency";

interface SupplierAdvanceAllocationDialogProps {
  isOpen: boolean;
  onClose: () => void;
  purchase: PurchaseItem;
  currentUser: User;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

export function SupplierAdvanceAllocationDialog({
  isOpen,
  onClose,
  purchase,
  currentUser,
  onSuccess,
  onError,
}: SupplierAdvanceAllocationDialogProps) {
  const { symbol } = useCurrency(currentUser?.businessId);
  const allocateMutation = useAllocateSupplierAdvanceMutation();
  const [selectedAdvanceId, setSelectedAdvanceId] = useState<string>("");

  const businessId = currentUser?.businessId || "";

  // Query unused advances for this supplier
  const { data: advances = [], isLoading: advancesLoading } = useSupplierAdvancesQuery(
    businessId,
    { supplierId: purchase.supplierId, onlyRemaining: true }
  );

  const remainingDue = Math.max(0, purchase.grandTotal - purchase.amountPaid);

  const selectedAdvance = React.useMemo(() => {
    return advances.find((adv) => adv.id === selectedAdvanceId);
  }, [advances, selectedAdvanceId]);

  const maxAllocatable = React.useMemo(() => {
    if (!selectedAdvance) return 0;
    return Math.min(selectedAdvance.amountRemaining, remainingDue);
  }, [selectedAdvance, remainingDue]);

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { errors },
  } = useForm({
    defaultValues: {
      amount: 0,
    },
  });

  // Prefill first advance select
  useEffect(() => {
    if (advances.length > 0 && !selectedAdvanceId) {
      setSelectedAdvanceId(advances[0].id);
    }
  }, [advances, selectedAdvanceId]);

  // Set default values when select changes or dialog opens
  useEffect(() => {
    if (isOpen) {
      reset({
        amount: Number(maxAllocatable.toFixed(2)),
      });
    }
  }, [isOpen, maxAllocatable, reset]);

  // Set values when selected advance changes
  useEffect(() => {
    if (selectedAdvance) {
      setValue("amount", Number(maxAllocatable.toFixed(2)));
    }
  }, [selectedAdvance, maxAllocatable, setValue]);

  if (!isOpen) return null;

  const onSubmit = async (data: any) => {
    if (!businessId) return;
    if (!selectedAdvanceId) {
      onError("Please select an advance record to draw from.");
      return;
    }

    const payload = {
      supplierAdvanceId: selectedAdvanceId,
      purchaseId: purchase.id,
      amount: Number(data.amount),
      businessId,
    };

    try {
      await allocateMutation.mutateAsync(payload);
      onSuccess("Advance balance applied successfully to the invoice!");
      onClose();
    } catch (err: any) {
      onError(err.message || "Failed to allocate advance balance.");
    }
  };

  const isLoading = allocateMutation.isPending || advancesLoading;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-card border border-border rounded-sm shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between border-b border-border p-5 bg-background/40">
          <h2 className="text-lg font-bold text-foreground flex items-center gap-2">
            <Coins className="h-5 w-5 text-primary" /> Apply Unused Advance
          </h2>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-5 space-y-4">
          
          {/* Purchase Details */}
          <div className="p-3 bg-secondary/50 rounded-sm border border-border/40 text-xs space-y-1">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Invoice / Bill:</span>
              <span className="font-mono font-bold">{purchase.purchaseNumber}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Outstanding Due:</span>
              <span className="font-bold text-rose-500">{symbol}{remainingDue.toFixed(2)}</span>
            </div>
          </div>

          {/* Select Unused Advance */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide">Available Advances</label>
            <select
              value={selectedAdvanceId}
              onChange={(e) => setSelectedAdvanceId(e.target.value)}
              className="w-full bg-background border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
            >
              {advances.map((adv: any) => (
                <option key={adv.id} value={adv.id}>
                  {adv.advanceNumber} (Unused: {symbol}{adv.amountRemaining.toFixed(2)})
                </option>
              ))}
            </select>
            {advances.length === 0 && !advancesLoading && (
              <p className="text-[10px] text-amber-500 font-semibold mt-1">
                No unused advance payments found for this supplier. Record an advance first!
              </p>
            )}
          </div>

          {/* Amount to apply */}
          {selectedAdvance && (
            <div className="space-y-1.5 animate-in fade-in duration-200">
              <div className="flex justify-between items-center">
                <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide">Amount to Apply ({symbol})</label>
                <span className="text-[10px] text-muted-foreground">Max limit: {symbol}{maxAllocatable.toFixed(2)}</span>
              </div>
              <Input
                type="number"
                step="0.01"
                placeholder="0.00"
                {...register("amount", { required: true, min: 0.01, max: maxAllocatable })}
                className="w-full"
              />
              {errors.amount && (
                <p className="text-[10px] text-destructive font-semibold">Please enter a valid amount within the limits.</p>
              )}
            </div>
          )}

          {/* Footer Action buttons */}
          <div className="flex justify-end gap-2 border-t border-border pt-4 mt-2">
            <Button
              type="button"
              variant="ghost"
              onClick={onClose}
              className="text-xs font-bold"
              disabled={allocateMutation.isPending}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="text-xs font-bold px-4"
              disabled={isLoading || advances.length === 0}
            >
              {allocateMutation.isPending ? (
                <>
                  <Loader2 className="h-3 w-3 animate-spin mr-1.5" /> Applying...
                </>
              ) : (
                "Apply Advance"
              )}
            </Button>
          </div>

        </form>
      </div>
    </div>
  );
}
