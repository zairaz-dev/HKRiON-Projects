import {
  IsString,
  IsNotEmpty,
  IsOptional,
  Length,
  Matches,
  IsArray,
} from 'class-validator';

export class CreateCategoryDto {
  @IsString()
  @IsNotEmpty({ message: 'Category name is required' })
  @Length(2, 100, { message: 'Category name must be between 2 and 100 characters' })
  name: string;

  @IsOptional()
  @IsString()
  @Length(0, 500, { message: 'Description cannot exceed 500 characters' })
  description?: string;

  @IsOptional()
  @IsString()
  imageUrl?: string;

  @IsOptional()
  @IsString()
  @Matches(/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/, {
    message: 'Color must be a valid hex code (e.g. #3B82F6)',
  })
  color?: string;

  @IsOptional()
  isActive?: boolean | string;

  @IsString()
  @IsNotEmpty({ message: 'Business ID is required' })
  businessId: string;

  @IsOptional()
  branchIds?: string[] | string;

  @IsOptional()
  parentId?: string | null;

  @IsOptional()
  @IsString()
  createdById?: string;
}
