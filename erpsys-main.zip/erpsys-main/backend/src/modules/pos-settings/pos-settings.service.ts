import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { UpdatePosSettingsDto } from './dto/pos-settings.dto';
import { randomUUID } from 'crypto';

@Injectable()
export class PosSettingsService {
  constructor(private readonly prisma: PrismaService) {}

  async getSettings(businessId: string, branchId?: string | null) {
    const targetBranchId = branchId && branchId !== 'all' ? branchId : null;

    if ((this.prisma as any).posSettings) {
      if (targetBranchId) {
        const branchSettings = await (this.prisma as any).posSettings.findFirst({
          where: {
            businessId,
            branchId: targetBranchId,
          },
        });

        if (branchSettings) {
          return branchSettings;
        }
      }

      let defaultSettings = await (this.prisma as any).posSettings.findFirst({
        where: {
          businessId,
          branchId: null,
        },
      });

      if (!defaultSettings) {
        defaultSettings = await (this.prisma as any).posSettings.create({
          data: {
            businessId,
            branchId: null,
            enableExpressCheckout: true,
            autoPrintInvoice: false,
            showProductSuggestions: true,
            allowOverSelling: true,
            enableDiscount: true,
            enableHoldOrders: true,
            enableSoundEffects: true,
            searchShortcut: 'F1',
            checkoutShortcut: 'F2',
            cashShortcut: 'F4',
            cardShortcut: 'F8',
            holdShortcut: 'F6',
            cancelShortcut: 'Escape',
          },
        });
      }

      return defaultSettings;
    }

    // Direct database raw query fallback
    if (targetBranchId) {
      const branchRows: any[] = await this.prisma.$queryRawUnsafe(
        `SELECT * FROM "PosSettings" WHERE "businessId" = $1 AND "branchId" = $2 LIMIT 1`,
        businessId,
        targetBranchId,
      );
      if (branchRows && branchRows.length > 0) {
        return branchRows[0];
      }
    }

    const defaultRows: any[] = await this.prisma.$queryRawUnsafe(
      `SELECT * FROM "PosSettings" WHERE "businessId" = $1 AND "branchId" IS NULL LIMIT 1`,
      businessId,
    );

    if (defaultRows && defaultRows.length > 0) {
      return defaultRows[0];
    }

    const newId = randomUUID();
    await this.prisma.$executeRawUnsafe(
      `INSERT INTO "PosSettings" 
       ("id", "businessId", "branchId", "enableExpressCheckout", "autoPrintInvoice", "showProductSuggestions", "allowOverSelling", "enableDiscount", "enableHoldOrders", "enableSoundEffects", "searchShortcut", "checkoutShortcut", "cashShortcut", "cardShortcut", "holdShortcut", "cancelShortcut", "createdAt", "updatedAt") 
       VALUES ($1, $2, NULL, true, false, true, true, true, true, true, 'F1', 'F2', 'F4', 'F8', 'F6', 'Escape', NOW(), NOW())`,
      newId,
      businessId,
    );

    const created: any[] = await this.prisma.$queryRawUnsafe(
      `SELECT * FROM "PosSettings" WHERE "businessId" = $1 AND "branchId" IS NULL LIMIT 1`,
      businessId,
    );
    return created[0];
  }

  async updateSettings(businessId: string, dto: UpdatePosSettingsDto) {
    const targetBranchId = dto.branchId && dto.branchId !== 'all' ? dto.branchId : null;

    const dataPayload: any = {};
    if (dto.defaultCustomerId !== undefined) dataPayload.defaultCustomerId = dto.defaultCustomerId;
    if (dto.defaultPaymentMethodId !== undefined) dataPayload.defaultPaymentMethodId = dto.defaultPaymentMethodId;
    if (dto.enableExpressCheckout !== undefined) dataPayload.enableExpressCheckout = dto.enableExpressCheckout;
    if (dto.autoPrintInvoice !== undefined) dataPayload.autoPrintInvoice = dto.autoPrintInvoice;
    if (dto.showProductSuggestions !== undefined) dataPayload.showProductSuggestions = dto.showProductSuggestions;
    if (dto.allowOverSelling !== undefined) dataPayload.allowOverSelling = dto.allowOverSelling;
    if (dto.enableDiscount !== undefined) dataPayload.enableDiscount = dto.enableDiscount;
    if (dto.enableHoldOrders !== undefined) dataPayload.enableHoldOrders = dto.enableHoldOrders;
    if (dto.enableSoundEffects !== undefined) dataPayload.enableSoundEffects = dto.enableSoundEffects;

    if (dto.searchShortcut !== undefined) dataPayload.searchShortcut = dto.searchShortcut;
    if (dto.checkoutShortcut !== undefined) dataPayload.checkoutShortcut = dto.checkoutShortcut;
    if (dto.cashShortcut !== undefined) dataPayload.cashShortcut = dto.cashShortcut;
    if (dto.cardShortcut !== undefined) dataPayload.cardShortcut = dto.cardShortcut;
    if (dto.holdShortcut !== undefined) dataPayload.holdShortcut = dto.holdShortcut;
    if (dto.cancelShortcut !== undefined) dataPayload.cancelShortcut = dto.cancelShortcut;

    if ((this.prisma as any).posSettings) {
      const existing = await (this.prisma as any).posSettings.findFirst({
        where: {
          businessId,
          branchId: targetBranchId,
        },
      });

      if (existing) {
        return (this.prisma as any).posSettings.update({
          where: { id: existing.id },
          data: dataPayload,
        });
      } else {
        return (this.prisma as any).posSettings.create({
          data: {
            businessId,
            branchId: targetBranchId,
            ...dataPayload,
          },
        });
      }
    }

    // Direct database raw query fallback
    let existingRows: any[];
    if (targetBranchId) {
      existingRows = await this.prisma.$queryRawUnsafe(
        `SELECT "id" FROM "PosSettings" WHERE "businessId" = $1 AND "branchId" = $2 LIMIT 1`,
        businessId,
        targetBranchId,
      );
    } else {
      existingRows = await this.prisma.$queryRawUnsafe(
        `SELECT "id" FROM "PosSettings" WHERE "businessId" = $1 AND "branchId" IS NULL LIMIT 1`,
        businessId,
      );
    }

    if (existingRows && existingRows.length > 0) {
      const keys = Object.keys(dataPayload);
      if (keys.length > 0) {
        const setClauses = keys.map((k, i) => `"${k}" = $${i + 2}`).join(', ');
        const values = keys.map((k) => dataPayload[k]);
        await this.prisma.$executeRawUnsafe(
          `UPDATE "PosSettings" SET ${setClauses}, "updatedAt" = NOW() WHERE "id" = $1`,
          existingRows[0].id,
          ...values,
        );
      }
    } else {
      const newId = randomUUID();
      const keys = Object.keys(dataPayload);
      const cols = ['"id"', '"businessId"', '"branchId"', ...keys.map((k) => `"${k}"`), '"createdAt"', '"updatedAt"'].join(', ');
      const placeholders = ['$1', '$2', '$3', ...keys.map((_, i) => `$${i + 4}`), 'NOW()', 'NOW()'].join(', ');
      const values = keys.map((k) => dataPayload[k]);
      await this.prisma.$executeRawUnsafe(
        `INSERT INTO "PosSettings" (${cols}) VALUES (${placeholders})`,
        newId,
        businessId,
        targetBranchId,
        ...values,
      );
    }

    let updatedRows: any[];
    if (targetBranchId) {
      updatedRows = await this.prisma.$queryRawUnsafe(
        `SELECT * FROM "PosSettings" WHERE "businessId" = $1 AND "branchId" = $2 LIMIT 1`,
        businessId,
        targetBranchId,
      );
    } else {
      updatedRows = await this.prisma.$queryRawUnsafe(
        `SELECT * FROM "PosSettings" WHERE "businessId" = $1 AND "branchId" IS NULL LIMIT 1`,
        businessId,
      );
    }
    return updatedRows[0];
  }
}
