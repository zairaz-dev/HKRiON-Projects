import { useQuery } from '@tanstack/react-query';
import { dashboardService } from '@/services/dashboard-service';
import { queryKeys } from '@/lib/query-keys';

export function useDashboardSummaryQuery(
  businessId: string,
  branchId?: string,
  dateRange?: string,
  startDate?: string,
  endDate?: string
) {
  return useQuery({
    queryKey: queryKeys.dashboard.summary(businessId, branchId, dateRange, startDate, endDate),
    queryFn: () => dashboardService.getDashboardSummary(businessId, branchId, dateRange, startDate, endDate),
    enabled: !!businessId,
  });
}
