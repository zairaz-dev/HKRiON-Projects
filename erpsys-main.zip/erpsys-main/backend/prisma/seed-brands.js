const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  console.log('Finding HKR System Business and Main Branch...');
  const business = await prisma.business.findFirst({
    where: { name: 'HKR System Business' }
  });

  if (!business) {
    console.error('HKR System Business not found! Please run the app dev server or seed first.');
    return;
  }

  const branch = await prisma.branch.findFirst({
    where: { businessId: business.id }
  });

  if (!branch) {
    console.error('Main Branch not found for this business!');
    return;
  }

  const user = await prisma.user.findFirst({
    where: { email: 'superadmin@hkr.com' }
  });

  if (!user) {
    console.error('Super admin user not found!');
    return;
  }

  console.log('Generating 1000000 dummy brands...');
  const brandsData = [];
  for (let i = 1; i <= 1000000; i++) {
    const num = String(i).padStart(4, '0');
    brandsData.push({
      name: `Branddd ${num}`,
      description: `Dummy Brand Description for Brand ${num}`,
      businessId: business.id,
      createdById: user.id,
      isActive: true,
    });
  }

  console.log('Inserting brands into DB...');
  await prisma.brand.createMany({
    data: brandsData,
    skipDuplicates: true,
  });

  console.log('Fetching inserted brand IDs...');
  const insertedBrands = await prisma.brand.findMany({
    where: {
      businessId: business.id,
      name: { startsWith: 'Brand ' }
    },
    select: { id: true }
  });

  console.log(`Found ${insertedBrands.length} brands. Linking them to branch: ${branch.name}...`);
  const brandBranchesData = insertedBrands.map((b) => ({
    brandId: b.id,
    branchId: branch.id,
  }));

  await prisma.brandBranch.createMany({
    data: brandBranchesData,
    skipDuplicates: true,
  });

  console.log('1000 brands successfully created and linked to the main branch!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
