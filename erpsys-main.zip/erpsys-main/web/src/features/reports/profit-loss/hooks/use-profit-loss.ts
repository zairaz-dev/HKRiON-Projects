import { useQuery } from "@tanstack/react-query";
import { reportService } from "@/services/report-service";
import { queryKeys } from "@/lib/query-keys";

export function useProfitLossQuery(
  businessId: string,
  filters: {
    startDate?: string;
    endDate?: string;
    branchId?: string;
  },
) {
  return useQuery({
    queryKey: queryKeys.reports.profitLoss(
      businessId,
      filters.startDate,
      filters.endDate,
      filters.branchId,
    ),
    queryFn: () => reportService.getProfitAndLoss(businessId, filters),
    enabled: !!businessId,
  });
}
