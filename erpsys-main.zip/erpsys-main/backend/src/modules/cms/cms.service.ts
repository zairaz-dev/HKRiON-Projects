import { Injectable, OnModuleInit, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { UpdateCmsHeroDto } from './dto/update-hero.dto';
import { CreateCmsFeatureDto, UpdateCmsFeatureDto } from './dto/create-feature.dto';
import { CreateCmsFaqDto, UpdateCmsFaqDto } from './dto/create-faq.dto';
import { CreateCmsTestimonialDto, UpdateCmsTestimonialDto } from './dto/create-testimonial.dto';
import { CreateCmsPageDto, UpdateCmsPageDto } from './dto/create-page.dto';
import { CreateCmsPostDto, UpdateCmsPostDto } from './dto/create-post.dto';
import { CreateCmsSpotlightDto, UpdateCmsSpotlightDto } from './dto/create-spotlight.dto';

@Injectable()
export class CmsService implements OnModuleInit {
  constructor(private readonly prisma: PrismaService) {}

  async onModuleInit() {
    await this.seedDefaultsIfEmpty();
  }

  /**
   * Seed rich marketing content defaults if CMS tables are empty
   */
  async seedDefaultsIfEmpty() {
    // 1. Hero
    const heroCount = await this.prisma.cmsHero.count();
    if (heroCount === 0) {
      await this.prisma.cmsHero.create({
        data: {
          announcementText: 'Special Launch Offer: Get 20% OFF on all Yearly Subscription Plans! 🚀',
          announcementLink: '#pricing',
          announcementActive: true,
          badgeText: 'NEXT-GEN CLOUD ERP FOR MODERN RETAIL & ENTERPRISE',
          heroTitle: 'The Complete Intelligent ERP Platform Built For Growth',
          heroSubtitle: 'Streamline multi-branch point of sale, inventory tracking with IMEI verification, customer accounting, and automated Sri Lankan tax invoicing in one ultra-fast system.',
          primaryCtaText: 'Start 14-Day Free Trial',
          primaryCtaLink: '/register',
          secondaryCtaText: 'Explore Features',
          secondaryCtaLink: '#features',
          statsJson: JSON.stringify([
            { value: '99.9%', label: 'System Uptime' },
            { value: '1,500+', label: 'Active Stores' },
            { value: '10M+', label: 'Invoices Processed' },
            { value: '4.9/5', label: 'User Satisfaction' },
          ]),
        },
      });
    }

    // 2. Features
    const featureCount = await this.prisma.cmsFeature.count();
    if (featureCount === 0) {
      const defaultFeatures = [
        {
          title: 'Lightning-Fast POS Billing',
          description: 'High-speed touch and barcode scanner Point of Sale with instant thermal receipt printing, draft sales, and split payments.',
          iconName: 'ShoppingBag',
          badge: 'HOT',
          category: 'Retail & POS',
          sortOrder: 1,
        },
        {
          title: 'IMEI & Serial Number Tracker',
          description: 'Full warranty tracking, purchase-to-sale lifecycle history, and replacement tracking for electronics & mobile stores.',
          iconName: 'Smartphone',
          badge: 'UNIQUE',
          category: 'Inventory',
          sortOrder: 2,
        },
        {
          title: 'Multi-Branch & Warehouse Sync',
          description: 'Manage multiple retail locations, inter-branch stock transfers, and permission-based user access seamlessly.',
          iconName: 'Building2',
          badge: 'ENTERPRISE',
          category: 'Multi-Branch',
          sortOrder: 3,
        },
        {
          title: 'Automated Accounting & Ledgers',
          description: 'Real-time Profit & Loss, expense tracking, customer credit ledgers, supplier payments, and balance sheets.',
          iconName: 'Layers',
          category: 'Finance',
          sortOrder: 4,
        },
        {
          title: 'Sri Lanka Tax & PayHere Gateway',
          description: 'Official 18% VAT/GST tax invoicing with PayHere integration for Visa/Master, FriMi, Genie, eZ Cash, and Bank Transfers.',
          iconName: 'CreditCard',
          badge: 'LOCALIZED',
          category: 'Payments',
          sortOrder: 5,
        },
        {
          title: 'Live Analytics & Reports',
          description: 'Dynamic visual dashboards, fast-moving items analysis, stock valuation, and Excel/PDF export capabilities.',
          iconName: 'BarChart3',
          category: 'Analytics',
          sortOrder: 6,
        },
      ];

      for (const feat of defaultFeatures) {
        await this.prisma.cmsFeature.create({ data: feat });
      }
    }

    // 3. FAQs
    const faqCount = await this.prisma.cmsFaq.count();
    if (faqCount === 0) {
      const defaultFaqs = [
        {
          question: 'Can I test HKRION ERP before paying?',
          answer: 'Yes! Every new business account starts with a 14-day full feature Free Trial without requiring any credit card details.',
          category: 'Billing',
          sortOrder: 1,
        },
        {
          question: 'What payment options are supported for subscriptions?',
          answer: 'We support instant online checkout via PayHere.lk (Credit/Debit Cards, FriMi, Genie, eZ Cash, mCash, Internet Banking) and Direct Bank Transfer with slip upload verification.',
          category: 'Billing',
          sortOrder: 2,
        },
        {
          question: 'Does HKRION ERP support barcode scanners and thermal printers?',
          answer: 'Absolutely! Our Point of Sale works seamlessly with standard USB and Bluetooth barcode scanners, 80mm/58mm thermal ESC/POS printers, and cash drawers.',
          category: 'Hardware',
          sortOrder: 3,
        },
        {
          question: 'Can I manage multiple stores with different pricing groups?',
          answer: 'Yes, HKRION ERP allows you to configure multiple branches with independent stock quantities, selling price groups, and inter-branch transfer tracking.',
          category: 'Features',
          sortOrder: 4,
        },
        {
          question: 'Is my business data secure and backed up?',
          answer: 'Yes, your data is stored in encrypted cloud servers with daily automated backups and 256-bit SSL encryption.',
          category: 'Security',
          sortOrder: 5,
        },
      ];

      for (const faq of defaultFaqs) {
        await this.prisma.cmsFaq.create({ data: faq });
      }
    }

    // 4. Testimonials
    const testimonialCount = await this.prisma.cmsTestimonial.count();
    if (testimonialCount === 0) {
      const defaultTestimonials = [
        {
          clientName: 'Mohamed Rizwan',
          clientRole: 'Managing Director',
          businessName: 'Apex Mobile & Electronics, Colombo',
          avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
          rating: 5,
          content: 'The IMEI tracking and fast barcode POS transformed our 3 mobile outlets. Stock transfer between branches takes just seconds now!',
          sortOrder: 1,
        },
        {
          clientName: 'Priyanka Senanayake',
          clientRole: 'Store Owner',
          businessName: 'Lanka Super Mart, Kandy',
          avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
          rating: 5,
          content: 'PayHere integration and offline bank transfer made upgrading our plan effortless. Best cloud ERP in Sri Lanka!',
          sortOrder: 2,
        },
        {
          clientName: 'K. Thirunavukkarasu',
          clientRole: 'General Manager',
          businessName: 'Royal Auto Spares, Jaffna',
          avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
          rating: 5,
          content: 'Accounting and Profit & Loss reports are extremely accurate. Outstanding customer support and reliability.',
          sortOrder: 3,
        },
      ];

      for (const item of defaultTestimonials) {
        await this.prisma.cmsTestimonial.create({ data: item });
      }
    }

    // 5. Legal Pages (Upsert rich enterprise policies)
    const richPrivacyContent = `# Privacy Policy & Data Protection Standards

**Effective Date:** August 31, 2026  
**Operating Entity:** HKRION SYSTEMS (PVT) LTD ("HKRION", "We", "Our", "Us")  
**Product Scope:** HKRION ERP Multi-Tenant SaaS Platform  
**Compliance Scope:** Sri Lanka Personal Data Protection Act (PDPA) & Global Data Privacy Benchmarks  

---

## 1. Introduction & Organizational Commitment
At **HKRION SYSTEMS (PVT) LTD**, we recognize the paramount importance of privacy, trust, and confidentiality for businesses running critical daily operations on our cloud platform. This Privacy Policy details the exact types of data we collect, our strict multi-tenant data isolation protocols, enterprise security encryption benchmarks, and your unwavering rights as a business owner (Tenant).

By accessing or using **HKRION ERP**, you agree to the data collection and governance practices outlined in this document.

---

## 2. Information We Collect
We collect only the essential information necessary to provide ultra-fast, secure, and uninterrupted ERP services across Point of Sale, Inventory, and Accounting:

### A. Account & Business Administrator Profile
- **Tenant Administrator:** Full legal name, business email address, direct contact number, and encrypted password credentials (hashed with bcrypt).
- **Business Profile:** Registered trade name, business registration number (BR No), physical store/warehouse addresses, tax identification numbers (VAT/GST), and official store logos.

### B. Operational Business & Transactional Data
- **Point of Sale & Invoicing:** Transaction amounts, receipt numbers, product descriptions, tax line items, discount records, and cashier user IDs.
- **Inventory & Serial Tracking:** SKU quantities, product categories, unit purchase costs, selling prices, barcode mappings, and IMEI / Serial numbers with warranty timestamps.
- **Contacts & Ledgers:** Customer directory (names, phone numbers, credit limits, outstanding balances) and supplier profiles (payment histories, purchase orders).

### C. Subscription, Billing & Proof of Payment
- **Subscription Records:** Active plan tier, billing frequency (Monthly / Yearly), quota consumption metrics, and invoice receipts.
- **Payment Verification:** Bank deposit proof slips uploaded by tenants and PayHere.lk gateway transaction references.  
*(Note: We NEVER process, access, or store raw credit/debit card numbers or CVV codes on our servers. All online card transactions are processed securely by PCI-DSS compliant PayHere.lk).*

### D. System Security & Audit Logs
- System access timestamps, browser user-agent headers, and IP addresses to maintain security audit trails and prevent unauthorized account access.

---

## 3. Strict Multi-Tenant Data Isolation & Security Architecture
HKRION ERP is built with enterprise-grade multi-tenant architecture designed to guarantee absolute data segregation:

- 🛡️ **Row-Level Tenant Isolation:** Every database entity is strictly partitioned and mapped to a unique \`businessId\` (Tenant ID). Cross-tenant queries are strictly rejected by the server runtime.
- 🔐 **End-to-End Encryption:** All network traffic between your devices and our cloud servers is encrypted using **TLS 1.3 / SSL 256-bit certificates**.
- 🔑 **Cryptographic Password Protection:** Passwords are never stored in plaintext. We utilize one-way salted hashing algorithms.
- 💾 **Redundant Automated Backups:** Your operational database is automatically backed up to encrypted, geographically redundant storage to protect against disaster recovery scenarios.

---

## 4. How We Use & Process Your Information
Your information is strictly utilized to deliver and improve our platform functionality:
- To execute lightning-fast Point of Sale checkouts, calculate automated taxes, and print receipt vouchers.
- To dispatch essential transactional notifications, including SMS verification codes, invoice payment receipts, and subscription expiry alerts.
- To provide dedicated technical support and troubleshoot operational inquiries upon tenant request.
- To detect, prevent, and mitigate fraud, security incidents, and unauthorized logins.

---

## 5. Absolute "No-Sale" Guarantee & Third-Party Service Providers
**We maintain a strict, non-negotiable policy: We NEVER sell, rent, monetize, or trade your business data or customer records to advertisers, data brokers, or third parties.**

We share minimal necessary data only with verified infrastructure providers:
- **PayHere.lk:** Licensed by the Central Bank of Sri Lanka for processing online subscription payments.
- **Telecom & SMS Gateways (Dialog, Mobitel, Twilio):** For delivering one-time passcodes (OTP) and automated customer receipts.

---

## 6. Data Ownership & Tenant Rights (Right to Export & Delete)
- **100% Data Ownership:** You remain the sole and exclusive owner of all business records, customer contact lists, and inventory databases entered into HKRION ERP.
- **Data Portability:** You can export your full product catalog, stock valuations, customer balances, and financial reports to Excel (XLSX) or PDF format at any time.
- **Right to be Forgotten (Account Deletion):** Upon subscription termination, you may request permanent and complete purging of your tenant database from our active servers.

---

## 7. Cookies & Session Storage
We do not use tracking or advertising cookies. We utilize secure browser Local Storage solely for maintaining your encrypted JWT authentication session token (\`hkr_token\`).

---

## 8. Privacy Inquiries & Compliance Contact
If you have any questions, compliance verification requests, or data privacy inquiries, please contact our Data Protection and Compliance Team:

- 📧 **Direct Privacy Email:** privacy@hkrion.com
- 🛠️ **Customer Care Hotline:** +94 77 123 4567
- 🏢 **Company:** HKRION SYSTEMS (PVT) LTD
- 📍 **Headquarters:** Colombo, Sri Lanka`;

    const richRefundContent = `# Subscription Refund & Cancellation Policy

**Effective Date:** August 31, 2026  
**Operating Entity:** HKRION SYSTEMS (PVT) LTD ("HKRION", "We", "Our", "Us")  
**Product Scope:** HKRION ERP Multi-Tenant SaaS Platform  
**Payment Gateways Covered:** PayHere.lk (Online Gateway) & Direct SaaS Bank Transfer  

---

## 1. 14-Day Risk-Free Free Trial
To ensure complete transparency and satisfaction, **HKRION ERP** offers a **14-day full feature Free Trial** on all newly registered business accounts.
- **No Credit Card Required:** Tenants can explore all POS, IMEI tracking, inventory, multi-branch, and accounting modules without entering payment details.
- **Evaluation Period:** We strongly encourage business owners to test barcode scanners, receipt printers, and multi-branch syncing during this trial period before making any subscription commitment.

---

## 2. Subscription Cancellation & Auto-Renewal Policy
- **Cancel Anytime:** Tenants may cancel their recurring subscription renewal at any time directly through the **Tenant Subscription Portal (\`/settings/subscription\`)**.
- **Active Service Guarantee:** Upon cancellation, your ERP workspace remains **100% active and fully operational** until the conclusion of your current prepaid billing cycle (Monthly or Yearly).
- **No Early Cancellation Penalty:** There are no cancellation fees, penalty charges, or lock-in contracts.

---

## 3. Refund Eligibility & Qualification Criteria
Refunds are evaluated objectively on a case-by-case basis. You are eligible for a **100% full refund** under the following qualifying circumstances:

### A. Accidental Duplicate / Multiple Billing
If a technical timeout or network glitch results in duplicate charges for the same subscription period via PayHere.lk or bank transfer, the duplicate amount will be refunded immediately.

### B. Severe Technical Service Outage (>24h SLA Breach)
If our cloud servers experience an unannounced service disruption exceeding **24 consecutive hours** that prevents your business from executing core POS or inventory operations, you are eligible for a full refund for that billing month.

### C. Incorrect Subscription Tier Charges
If you are billed for an incorrect plan tier or tax rate due to an automated billing discrepancy, we will refund the difference or the full transaction upon request.

### D. Dispute Submission Window
Refund requests must be submitted within **7 calendar days** from the transaction date.

---

## 4. Non-Refundable Scenarios
Refunds cannot be granted in the following scenarios:
- **Change of Mind Beyond 7 Days:** Requests submitted after 7 days of active platform utilization.
- **Account Suspension for Abuse:** If an account is suspended or terminated due to fraudulent activity or violation of our Terms of Service.
- **Third-Party Hardware Incompatibilities:** Unwillingness to use supported POS thermal ESC/POS printers or barcode scanners that meet industry standards.

---

## 5. Refund Processing Timelines & Disbursement Channels
Approved refund claims will be disbursed strictly to the original source of payment:

- 💳 **PayHere.lk Online Payments (Visa, Mastercard, FriMi, Genie, eZ Cash):**  
  Refunds are processed through the PayHere Merchant Gateway and credited back to your original bank card or digital wallet within **5 to 7 business days** (subject to your issuing bank's settlement cycle).

- 🏦 **Direct Bank Transfer Deposits:**  
  Refunds are transferred via direct SLIPS/CEFT deposit to the tenant's verified company bank account within **3 to 5 business days** following validation of the original deposit slip.

---

## 6. Plan Upgrades & Prorated Billing Adjustments
- **Upgrades:** When upgrading to a higher plan mid-cycle, your remaining prepaid days on the lower tier are automatically converted into a monetary credit and deducted from the upgrade fee.
- **Downgrades:** Plan downgrades take effect automatically at the start of your subsequent billing period without forfeiting your active higher-tier quotas prematurely.

---

## 7. How to Submit a Refund Request
To initiate a refund request, please email our Billing & Finance Support Team with the following details:

- 📧 **Billing Support Email:** billing@hkrion.com
- 🏢 **Registered Business Name:** (e.g. Apex Mobile, Colombo)
- 🧾 **Invoice / Receipt Number:** (e.g. INV-2026-0089)
- 💳 **Payment Reference:** PayHere Order ID or Bank Deposit Slip copy
- 📝 **Reason for Refund Request:** Brief description of the issue encountered

---

## 8. Billing Inquiries & Dispute Resolution Contact
For any questions regarding billing statements, invoice copies, or payment confirmations, contact our dedicated billing support desk:

- 📧 **Email:** billing@hkrion.com
- 🛠️ **Customer Care Hotline:** +94 77 123 4567
- 🏢 **Operating Entity:** HKRION SYSTEMS (PVT) LTD
- 📍 **Headquarters:** Colombo, Sri Lanka`;

    const richTermsContent = `# HKRION Cloud ERP - Terms of Service & End User License Agreement (EULA)

**Effective Date:** August 31, 2026  
**Operating Entity:** HKRION SYSTEMS (PVT) LTD (Colombo, Sri Lanka)  
**Applicability:** Cloud SaaS Platform, Multi-Branch POS, and Web Management Suite

---

## 1. Acceptance of Terms & Cloud Licensing
By registering an account, purchasing a subscription, or accessing the **HKRION ERP** platform (accessible via web and desktop applications), you ("Tenant", "Customer", or "User") agree to be legally bound by these Terms of Service. If you are entering into this agreement on behalf of a company, retail business, or enterprise entity, you represent that you have the legal authority to bind such entity to these terms.

---

## 2. Multi-Tenant Accounts, Branches & Role Quotas
- **Account Security:** The tenant administrator is responsible for maintaining the confidentiality of login credentials for all branch cashiers, inventory managers, and accountants created under their account.
- **Resource Quotas:** Each subscription tier (Starter, Professional, Enterprise) includes specific resource limits regarding the maximum number of active branches, registered cashier users, product catalog SKUs, and monthly invoices.
- **Usage Limits:** If your operational volume exceeds the designated plan tier limits, the system may prompt you to upgrade your subscription to ensure uninterrupted service.

---

## 3. Subscription Billing, PayHere Gateway & Renewals
- **Billing Frequency:** Subscriptions are billed in advance on either a Monthly or Yearly recurring cycle.
- **Payment Methods:** We accept major credit/debit cards (Visa, Mastercard), FriMi, Genie, eZ Cash via **PayHere.lk** (Licensed by the Central Bank of Sri Lanka), and manual Direct Bank Transfer.
- **Trial Period:** New businesses enjoy a **14-Day Full-Featured Free Trial** with no credit card required at signup.
- **Failed Payments & Grace Period:** In the event of a failed subscription renewal, a 3-day grace period is provided during which the system remains operational to prevent checkout interruption at your retail counters.

---

## 4. 100% Customer Data Ownership & Tenant Isolation
- **Exclusive Ownership:** You retain full, exclusive, and unencumbered ownership of all data, transactions, customer directories, inventory SKUs, and accounting ledgers entered into HKRION ERP.
- **Row-Level Partitioning:** Every tenant's records are cryptographically separated by a unique \`businessId\`. Cross-tenant data access is strictly prohibited and blocked by runtime architecture.
- **Data Portability:** You retain the right to export your complete transactional records, inventory valuations, and financial ledgers to Excel (XLSX) or PDF format at any time.

---

## 5. 99.9% Service Level Agreement (SLA) & Uptime Guarantee
- **Uptime Commitment:** HKRION ERP guarantees a 99.9% application uptime for all core Point of Sale (POS) billing and database synchronization services.
- **Scheduled Maintenance:** Routine server optimizations and software feature updates are scheduled during off-peak retail hours (1:00 AM - 4:00 AM IST) and announced at least 48 hours in advance via the Top Announcement Banner.
- **Emergency Support:** Active paid subscribers have access to 24/7 emergency incident support for business-critical billing outages.

---

## 6. Prohibited Activities & Acceptable Use Policy
You agree not to use the HKRION ERP platform for any unlawful purpose, including but not limited to:
- Attempting to reverse engineer, decompile, or disassemble the platform API, database schemas, or source code.
- Utilizing automated scraping tools, bots, or brute-force mechanisms against authentication endpoints.
- Storing or distributing fraudulent, counterfeit, or illicit inventory items prohibited by Sri Lankan or international law.
- Intentionally overloading, disrupting, or compromising the integrity of our cloud server infrastructure.

---

## 7. Intellectual Property Rights
- The HKRION ERP software, user interface design, logo marks, algorithm architecture, and proprietary documentation are the exclusive intellectual property of **HKRION SYSTEMS (PVT) LTD**.
- This agreement grants you a non-exclusive, non-transferable, revocable cloud software license to use the service for your internal business management during active subscription periods.

---

## 8. Account Termination & Data Retention Grace Period
- **Cancellation:** You may cancel your subscription at any time via the Super Admin / Subscription Manager portal without penalty.
- **30-Day Export Grace Period:** Following subscription cancellation, your account transitions to read-only status for 30 calendar days, allowing you ample time to export all financial archives and customer databases.
- **Permanent Purge:** After 30 days of inactivity following confirmed termination, tenant database partitions are permanently purged in accordance with our Privacy Policy.

---

## 9. Limitation of Liability & Warranty Disclaimers
- HKRION ERP is provided on an "as is" and "as available" basis. While we employ automated multi-region backups, enterprise encryption, and resilient failover architecture, HKRION SYSTEMS (PVT) LTD shall not be liable for indirect, incidental, or consequential damages resulting from third-party internet service provider outages, power cuts, or hardware failures at local store counters.
- Our total aggregate liability under any circumstances is strictly capped at the total subscription fees paid by the tenant in the twelve (12) months preceding the claim.

---

## 10. Governing Law, Legal Jurisdiction & Contact Details
These Terms of Service are governed by and construed in accordance with the laws of the **Democratic Socialist Republic of Sri Lanka**. Any disputes arising under this agreement shall be subject to the exclusive jurisdiction of the commercial courts of Colombo, Sri Lanka.

### 🏢 Official Contact Channels:
- **Operating Entity:** HKRION SYSTEMS (PVT) LTD
- **Headquarters:** Level 14, World Trade Center, Echelon Square, Colombo 00100, Sri Lanka
- **Legal Inquiries:** legal@hkrion.com
- **Billing & Subscriptions:** billing@hkrion.com
- **Direct Hotline:** +94 11 234 5678 / +94 77 123 4567`;

    const defaultPages = [
      {
        slug: 'privacy',
        title: 'Privacy Policy & Data Protection',
        metaDescription: 'Official Privacy Policy, Data Protection standards, and Tenant Isolation Architecture for HKRION ERP.',
        content: richPrivacyContent,
        isPublished: true,
      },
      {
        slug: 'terms',
        title: 'Terms of Service & Cloud SLA',
        metaDescription: 'Official Terms of Service, End User License Agreement (EULA), and 99.9% Uptime SLA for HKRION Cloud ERP.',
        content: richTermsContent,
        isPublished: true,
      },
      {
        slug: 'refund',
        title: 'Subscription Refund & Cancellation Policy',
        metaDescription: 'Official Refund & Cancellation Policy, 14-Day Free Trial, and PayHere dispute resolution guidelines for HKRION ERP.',
        content: richRefundContent,
        isPublished: true,
      },
      {
        slug: 'about',
        title: 'About HKRION ERP',
        metaDescription: 'HKRION ERP is a premium monorepo-based Enterprise Resource Planning suite designed to streamline retail, inventory, finances, and operations.',
        content: JSON.stringify({
          badge: 'About Our Platform',
          headline: 'Empowering Businesses with Next-Gen ERP Technology',
          subtitle: 'HKRION ERP is a premium monorepo-based Enterprise Resource Planning suite designed to streamline retail, inventory, finances, and operations.',
          mission: "We believe that enterprise management software shouldn't be slow, bloated, or complicated. Our mission is to provide businesses of all sizes with a lightning-fast, modular, and exceptionally beautiful ERP platform.",
          architectureStory: 'By utilizing a modern monorepo architecture with NestJS and Next.js, HKRION delivers a seamless native-like performance both on the web and as a desktop shell.',
          stats: [
            { label: 'Active Businesses', value: '2,500+' },
            { label: 'Daily Transactions', value: '$1.2M+' },
            { label: 'Server Uptime', value: '99.99%' },
            { label: 'Support Resolution', value: '< 2 Hrs' },
          ],
          values: [
            { title: 'High Performance', description: 'Optimized for speed and efficiency with a native-feeling desktop and web experience.', icon: 'Zap' },
            { title: 'Ironclad Security', description: 'Your business data is fully encrypted and protected with enterprise-grade security protocols.', icon: 'Shield' },
            { title: 'Modular Design', description: 'Scale your business seamlessly by mounting only the modules you need, when you need them.', icon: 'Cpu' },
            { title: 'Global Scalability', description: 'Multi-currency, multi-country, and multi-warehouse support built directly into the core.', icon: 'Globe' },
          ],
        }),
        isPublished: true,
      },
      {
        slug: 'contact',
        title: 'Contact Support & Sales',
        metaDescription: 'Get in touch with HKRION ERP support team in Colombo, Sri Lanka. We are here to help.',
        content: JSON.stringify({
          badge: 'Get In Touch',
          headline: 'Contact Our Support Team',
          subtitle: "Have questions about HKRION ERP? We're here to help. Send us a message or contact our direct hotline.",
          email: 'support@hkrion.com',
          phone: '+94 11 234 5678',
          whatsapp: '+94 77 123 4567',
          address: 'Level 14, World Trade Center, Echelon Square, Colombo 00100, Sri Lanka',
          workingHours: 'Monday - Friday: 8:30 AM - 6:30 PM (IST)\n24/7 Emergency Cloud Hotline for Active Subscribers',
          whatsappLink: 'https://wa.me/94771234567',
        }),
        isPublished: true,
      },
    ];

    for (const page of defaultPages) {
      await this.prisma.cmsPage.upsert({
        where: { slug: page.slug },
        update: {
          title: page.title,
          metaDescription: page.metaDescription,
          content: page.content,
          isPublished: true,
        },
        create: page,
      });
    }

    // 6. Interactive Product Spotlights
    const spotlightCount = await this.prisma.cmsSpotlight.count();
    if (spotlightCount === 0) {
      const defaultSpotlights = [
        {
          tabKey: 'pos',
          tabLabel: 'Point of Sale (POS)',
          title: 'Lightning-Fast Touch & Barcode POS Billing',
          subtitle: 'Serve retail customers in under 3 seconds. Connect thermal printers, barcode scanners, and accept all Sri Lankan payment gateways seamlessly.',
          badge: 'RETAIL & STORE CHECKOUT',
          iconName: 'ShoppingBag',
          imageUrl: '/images/pos-terminal.jpg',
          bulletPointsJson: JSON.stringify([
            { icon: 'ShoppingBag', title: 'Hardware Ready Out-of-the-Box', description: 'Connect USB/Bluetooth barcode scanners, cash drawers, and 80mm/58mm thermal printers instantly.' },
            { icon: 'CreditCard', title: 'Sri Lankan Payment Gateways', description: 'Accept PayHere.lk QR codes, Visa, Mastercard, Genie, FriMi, eZ Cash, and Split Cash payments.' },
            { icon: 'Sparkles', title: 'Offline Resilient & Draft Sales', description: 'Never stop ringing sales during network drops with local queue sync.' },
          ]),
          ctaText: 'Start 14-Day Free Trial',
          ctaLink: '/register',
          sortOrder: 1,
        },
        {
          tabKey: 'imei',
          tabLabel: 'IMEI & Serial Tracker',
          title: 'Serial & IMEI Lifecycle Warranty Tracking',
          subtitle: 'Total visibility from manufacturer purchase to customer sale. Track individual serial numbers with automated warranty lifecycle logs.',
          badge: 'INVENTORY & ELECTRONICS',
          iconName: 'Smartphone',
          imageUrl: '/images/inventory-warehouse.jpg',
          bulletPointsJson: JSON.stringify([
            { icon: 'Smartphone', title: 'Individual IMEI Verification', description: 'Prevent shrinkage and manage warranty claims with one-click serial lookups.' },
            { icon: 'Building2', title: 'Multi-Branch Real-Time Sync', description: 'Transfer stock between stores with dispatch manifests, receiving approvals, and automated ledger entries.' },
            { icon: 'ShieldCheck', title: 'Automated Warranty Replacement', description: 'Log supplier claims and track replacement serials effortlessly.' },
          ]),
          ctaText: 'Start Free IMEI Trial',
          ctaLink: '/register',
          sortOrder: 2,
        },
        {
          tabKey: 'branch',
          tabLabel: 'Multi-Branch Sync',
          title: 'Centralized Multi-Location Store Management',
          subtitle: 'Unify multiple store locations, warehouses, and franchises under one intelligent cloud dashboard.',
          badge: 'ENTERPRISE DISTRIBUTION',
          iconName: 'Building2',
          imageUrl: '/images/hero-dashboard.jpg',
          bulletPointsJson: JSON.stringify([
            { icon: 'Building2', title: 'Inter-Branch Stock Transfers', description: 'Instant transfer orders with dispatch manifests and receiving verification.' },
            { icon: 'Layers', title: 'Custom Selling Price Groups', description: 'Set location-based pricing and discounts tailored to each regional branch.' },
            { icon: 'BarChart3', title: 'Consolidated Executive Reports', description: 'Compare branch profitability, stock turnover, and cashier sales in real-time.' },
          ]),
          ctaText: 'Explore Multi-Branch',
          ctaLink: '/register',
          sortOrder: 3,
        },
        {
          tabKey: 'finance',
          tabLabel: 'Finance & Ledgers',
          title: 'Automated Double-Entry Accounting & 18% VAT',
          subtitle: 'Say goodbye to manual spreadsheets. Full Sri Lankan tax-compliant invoicing, profit & loss, and customer credit management.',
          badge: 'AUTOMATED ACCOUNTING',
          iconName: 'Layers',
          imageUrl: '/images/hero-dashboard.jpg',
          bulletPointsJson: JSON.stringify([
            { icon: 'Layers', title: 'Customer & Supplier Ledgers', description: 'Automated credit balance tracking, payment reminders, and receipts.' },
            { icon: 'CreditCard', title: 'Sri Lanka 18% VAT / GST Invoicing', description: 'Generate official IRD-compliant tax invoices with automatic tax rate splits.' },
            { icon: 'BarChart3', title: 'Real-time P&L Statements', description: 'Instant gross profit, expense breakdown, and balance sheets at your fingertips.' },
          ]),
          ctaText: 'Start Accounting Trial',
          ctaLink: '/register',
          sortOrder: 4,
        },
      ];

      for (const spotlight of defaultSpotlights) {
        await this.prisma.cmsSpotlight.upsert({
          where: { tabKey: spotlight.tabKey },
          update: spotlight,
          create: spotlight,
        });
      }
    }
  }

  // --- Public Content Consolidation ---
  async getPublicLandingContent() {
    const [hero, features, spotlights, faqs, testimonials] = await Promise.all([
      this.getHero(),
      this.prisma.cmsFeature.findMany({
        where: { isActive: true },
        orderBy: { sortOrder: 'asc' },
      }),
      this.prisma.cmsSpotlight.findMany({
        where: { isActive: true },
        orderBy: { sortOrder: 'asc' },
      }),
      this.prisma.cmsFaq.findMany({
        where: { isActive: true },
        orderBy: { sortOrder: 'asc' },
      }),
      this.prisma.cmsTestimonial.findMany({
        where: { isActive: true },
        orderBy: { sortOrder: 'asc' },
      }),
    ]);

    return {
      hero,
      features,
      spotlights,
      faqs,
      testimonials,
    };
  }

  // --- Hero Section ---
  async getHero() {
    let hero = await this.prisma.cmsHero.findFirst();
    if (!hero) {
      hero = await this.prisma.cmsHero.create({
        data: {
          heroTitle: 'The Complete Intelligent ERP Platform Built For Growth',
        },
      });
    }
    return hero;
  }

  async updateHero(dto: UpdateCmsHeroDto) {
    const hero = await this.getHero();
    return this.prisma.cmsHero.update({
      where: { id: hero.id },
      data: dto,
    });
  }

  // --- Features ---
  async getFeatures(includeInactive = false) {
    return this.prisma.cmsFeature.findMany({
      where: includeInactive ? {} : { isActive: true },
      orderBy: { sortOrder: 'asc' },
    });
  }

  async createFeature(dto: CreateCmsFeatureDto) {
    return this.prisma.cmsFeature.create({ data: dto });
  }

  async updateFeature(id: string, dto: UpdateCmsFeatureDto) {
    return this.prisma.cmsFeature.update({
      where: { id },
      data: dto,
    });
  }

  async deleteFeature(id: string) {
    return this.prisma.cmsFeature.delete({ where: { id } });
  }

  // --- FAQs ---
  async getFaqs(includeInactive = false) {
    return this.prisma.cmsFaq.findMany({
      where: includeInactive ? {} : { isActive: true },
      orderBy: { sortOrder: 'asc' },
    });
  }

  async createFaq(dto: CreateCmsFaqDto) {
    return this.prisma.cmsFaq.create({ data: dto });
  }

  async updateFaq(id: string, dto: UpdateCmsFaqDto) {
    return this.prisma.cmsFaq.update({
      where: { id },
      data: dto,
    });
  }

  async deleteFaq(id: string) {
    return this.prisma.cmsFaq.delete({ where: { id } });
  }

  // --- Testimonials ---
  async getTestimonials(includeInactive = false) {
    return this.prisma.cmsTestimonial.findMany({
      where: includeInactive ? {} : { isActive: true },
      orderBy: { sortOrder: 'asc' },
    });
  }

  async createTestimonial(dto: CreateCmsTestimonialDto) {
    return this.prisma.cmsTestimonial.create({ data: dto });
  }

  async updateTestimonial(id: string, dto: UpdateCmsTestimonialDto) {
    return this.prisma.cmsTestimonial.update({
      where: { id },
      data: dto,
    });
  }

  async deleteTestimonial(id: string) {
    return this.prisma.cmsTestimonial.delete({ where: { id } });
  }

  // --- Dynamic Pages ---
  async getPages() {
    return this.prisma.cmsPage.findMany({
      orderBy: { updatedAt: 'desc' },
    });
  }

  async getPageBySlug(slug: string) {
    const page = await this.prisma.cmsPage.findUnique({
      where: { slug },
    });
    if (!page) throw new NotFoundException(`Page with slug '${slug}' not found`);
    return page;
  }

  async createPage(dto: CreateCmsPageDto) {
    return this.prisma.cmsPage.create({ data: dto });
  }

  async updatePage(id: string, dto: UpdateCmsPageDto) {
    return this.prisma.cmsPage.update({
      where: { id },
      data: dto,
    });
  }

  async deletePage(id: string) {
    return this.prisma.cmsPage.delete({ where: { id } });
  }

  // --- Blog & Changelog Posts ---
  async getPosts(includeDrafts = false) {
    return this.prisma.cmsPost.findMany({
      where: includeDrafts ? {} : { isPublished: true },
      orderBy: { publishedAt: 'desc' },
    });
  }

  async getPostBySlug(slug: string) {
    const post = await this.prisma.cmsPost.findUnique({
      where: { slug },
    });
    if (!post) throw new NotFoundException(`Post with slug '${slug}' not found`);
    return post;
  }

  async createPost(dto: CreateCmsPostDto) {
    return this.prisma.cmsPost.create({ data: dto });
  }

  async updatePost(id: string, dto: UpdateCmsPostDto) {
    return this.prisma.cmsPost.update({
      where: { id },
      data: dto,
    });
  }

  async deletePost(id: string) {
    return this.prisma.cmsPost.delete({ where: { id } });
  }

  // --- Interactive Product Spotlights ---
  async getSpotlights(includeInactive = false) {
    return this.prisma.cmsSpotlight.findMany({
      where: includeInactive ? {} : { isActive: true },
      orderBy: { sortOrder: 'asc' },
    });
  }

  async getSpotlightById(id: string) {
    const item = await this.prisma.cmsSpotlight.findUnique({ where: { id } });
    if (!item) throw new NotFoundException(`Spotlight with ID '${id}' not found`);
    return item;
  }

  async createSpotlight(dto: CreateCmsSpotlightDto) {
    return this.prisma.cmsSpotlight.create({ data: dto });
  }

  async updateSpotlight(id: string, dto: UpdateCmsSpotlightDto) {
    return this.prisma.cmsSpotlight.update({
      where: { id },
      data: dto,
    });
  }

  async deleteSpotlight(id: string) {
    return this.prisma.cmsSpotlight.delete({ where: { id } });
  }
}
