import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class SupplierPaymentsService {
  constructor(private readonly prisma: PrismaService) {}

  async createPayment(data: {
    amount: number;
    paymentDate?: Date;
    purchaseId?: string;
    supplierId: string;
    paymentMethodId: string;
    branchId: string;
    businessId: string;
    transactionNo?: string;
    notes?: string;
    createdById?: string;
  }) {
    const {
      amount,
      paymentDate,
      purchaseId,
      supplierId,
      paymentMethodId,
      branchId,
      businessId,
      transactionNo,
      notes,
      createdById,
    } = data;

    if (amount <= 0) {
      throw new BadRequestException('Payment amount must be greater than zero.');
    }

    // Verify supplier exists
    const supplier = await this.prisma.supplier.findFirst({
      where: { id: supplierId, businessId },
    });
    if (!supplier) {
      throw new NotFoundException('Supplier not found.');
    }

    // Verify branch exists
    const branch = await this.prisma.branch.findFirst({
      where: { id: branchId, businessId },
    });
    if (!branch) {
      throw new NotFoundException('Branch not found.');
    }

    // Verify payment method exists and is linked to the branch
    const paymentMethodLink = await this.prisma.branchPaymentMethod.findUnique({
      where: {
        branchId_paymentMethodId: {
          branchId,
          paymentMethodId,
        },
      },
    });
    if (!paymentMethodLink) {
      throw new BadRequestException('Payment method is not active or available for this branch.');
    }

    // If purchase ID is provided, verify purchase exists
    let purchase = null;
    if (purchaseId) {
      purchase = await this.prisma.purchase.findFirst({
        where: { id: purchaseId, businessId, supplierId },
      });
      if (!purchase) {
        throw new NotFoundException('Purchase invoice not found or does not belong to this supplier.');
      }
      
      const currentDue = purchase.grandTotal - purchase.amountPaid;
      if (amount > currentDue + 0.01) {
        throw new BadRequestException(`Payment amount (₹${amount}) exceeds the remaining due (₹${currentDue.toFixed(2)}).`);
      }
    }

    return this.prisma.$transaction(async (tx) => {
      // CASE 1: Single specific Purchase Payment
      if (purchaseId && purchase) {
        const paymentNumber = await this.generatePaymentNumber(tx, businessId, paymentDate);
        const payment = await tx.purchasePayment.create({
          data: {
            paymentNumber,
            paymentDate: paymentDate ? new Date(paymentDate) : new Date(),
            amount,
            purchaseId,
            supplierId,
            paymentMethodId,
            branchId,
            businessId,
            transactionNo: transactionNo || null,
            notes: notes || null,
            createdById: createdById || null,
          },
          include: {
            paymentMethod: true,
            supplier: true,
            branch: true,
          },
        });

        const newAmountPaid = purchase.amountPaid + amount;
        let newStatus = 'PARTIAL';
        if (newAmountPaid >= purchase.grandTotal - 0.01) {
          newStatus = 'PAID';
        }

        await tx.purchase.update({
          where: { id: purchaseId },
          data: {
            amountPaid: newAmountPaid,
            paymentStatus: newStatus as any,
          },
        });

        return payment;
      }

      // CASE 2: Direct / On-Account Payment (FIFO Allocation across unpaid purchases)
      let remainingAmount = amount;
      let primaryPaymentRecord: any = null;

      // 1. Find all unpaid / partial purchases for this supplier in FIFO order
      const unpaidPurchases = await tx.purchase.findMany({
        where: {
          supplierId,
          businessId,
          paymentStatus: { in: ['DUE', 'PARTIAL'] as any },
        },
        orderBy: {
          purchaseDate: 'asc',
        },
      });

      for (const p of unpaidPurchases) {
        if (remainingAmount <= 0) break;

        const currentDue = Math.max(0, p.grandTotal - p.amountPaid);
        if (currentDue <= 0.01) continue;

        const allocAmount = Math.min(currentDue, remainingAmount);
        const pNum = await this.generatePaymentNumber(tx, businessId, paymentDate);

        const allocPayment = await tx.purchasePayment.create({
          data: {
            paymentNumber: pNum,
            paymentDate: paymentDate ? new Date(paymentDate) : new Date(),
            amount: allocAmount,
            purchaseId: p.id,
            supplierId,
            paymentMethodId,
            branchId,
            businessId,
            transactionNo: transactionNo || null,
            notes: notes ? `${notes} (FIFO allocation for Bill #${p.purchaseNumber})` : `FIFO allocation for Bill #${p.purchaseNumber}`,
            createdById: createdById || null,
          },
          include: {
            paymentMethod: true,
            supplier: true,
            branch: true,
          },
        });

        if (!primaryPaymentRecord) primaryPaymentRecord = allocPayment;

        const newPaid = p.amountPaid + allocAmount;
        let newStatus = 'PARTIAL';
        if (newPaid >= p.grandTotal - 0.01) {
          newStatus = 'PAID';
        }

        await tx.purchase.update({
          where: { id: p.id },
          data: {
            amountPaid: newPaid,
            paymentStatus: newStatus as any,
          },
        });

        remainingAmount -= allocAmount;
      }

      // 2. If still remaining and supplier has openingBalance, settle openingBalance
      const currentSupplier = await tx.supplier.findUnique({ where: { id: supplierId } });
      if (remainingAmount > 0 && currentSupplier && (currentSupplier.openingBalance || 0) > 0) {
        const openingDeduct = Math.min(currentSupplier.openingBalance, remainingAmount);
        const pNum = await this.generatePaymentNumber(tx, businessId, paymentDate);

        const openingPayment = await tx.purchasePayment.create({
          data: {
            paymentNumber: pNum,
            paymentDate: paymentDate ? new Date(paymentDate) : new Date(),
            amount: openingDeduct,
            purchaseId: null,
            supplierId,
            paymentMethodId,
            branchId,
            businessId,
            transactionNo: transactionNo || null,
            notes: notes ? `${notes} - Settlement of Opening Balance` : `Settlement of Opening Balance`,
            createdById: createdById || null,
          },
          include: {
            paymentMethod: true,
            supplier: true,
            branch: true,
          },
        });

        if (!primaryPaymentRecord) primaryPaymentRecord = openingPayment;

        await tx.supplier.update({
          where: { id: supplierId },
          data: {
            openingBalance: { decrement: openingDeduct },
          },
        });

        remainingAmount -= openingDeduct;
      }

      // 3. If excess remaining, create a SupplierAdvance!
      if (remainingAmount > 0) {
        const year = new Date(paymentDate || new Date()).getFullYear();
        const lastAdvance = await tx.supplierAdvance.findFirst({
          where: {
            businessId,
            advanceNumber: { startsWith: `ADV-${year}-` },
          },
          orderBy: { advanceNumber: 'desc' },
        });

        let advSeq = 1;
        if (lastAdvance) {
          const parts = lastAdvance.advanceNumber.split('-');
          const lastNum = parseInt(parts[parts.length - 1], 10);
          if (!isNaN(lastNum)) advSeq = lastNum + 1;
        }
        const advanceNumber = `ADV-${year}-${String(advSeq).padStart(4, '0')}`;

        await tx.supplierAdvance.create({
          data: {
            advanceNumber,
            advanceDate: paymentDate ? new Date(paymentDate) : new Date(),
            amount: remainingAmount,
            amountRemaining: remainingAmount,
            supplierId,
            paymentMethodId,
            branchId,
            businessId,
            transactionNo: transactionNo || null,
            notes: notes ? `${notes} (Excess advance credit)` : `Excess advance credit`,
            createdById: createdById || null,
          },
        });
      }

      // If no purchases existed and openingBalance was 0, create direct record
      if (!primaryPaymentRecord) {
        const pNum = await this.generatePaymentNumber(tx, businessId, paymentDate);
        primaryPaymentRecord = await tx.purchasePayment.create({
          data: {
            paymentNumber: pNum,
            paymentDate: paymentDate ? new Date(paymentDate) : new Date(),
            amount,
            purchaseId: null,
            supplierId,
            paymentMethodId,
            branchId,
            businessId,
            transactionNo: transactionNo || null,
            notes: notes || 'Direct Supplier Payment (Recorded as Advance Credit)',
            createdById: createdById || null,
          },
          include: {
            paymentMethod: true,
            supplier: true,
            branch: true,
          },
        });
      }

      return primaryPaymentRecord;
    });
  }

  private async generatePaymentNumber(tx: any, businessId: string, paymentDate?: Date): Promise<string> {
    const year = new Date(paymentDate || new Date()).getFullYear();
    const lastPayment = await tx.purchasePayment.findFirst({
      where: {
        businessId,
        paymentNumber: {
          startsWith: `PAY-PR-${year}-`,
        },
      },
      orderBy: {
        paymentNumber: 'desc',
      },
    });

    let seqNum = 1;
    if (lastPayment) {
      const parts = lastPayment.paymentNumber.split('-');
      const lastSeq = parseInt(parts[parts.length - 1], 10);
      if (!isNaN(lastSeq)) {
        seqNum = lastSeq + 1;
      }
    }
    return `PAY-PR-${year}-${String(seqNum).padStart(4, '0')}`;
  }

  async getPayments(
    businessId: string,
    filters: {
      branchId?: string;
      supplierId?: string;
      purchaseId?: string;
    },
  ) {
    const { branchId, supplierId, purchaseId } = filters;
    const whereClause: any = { businessId };

    if (branchId) {
      whereClause.branchId = branchId;
    }
    if (supplierId) {
      whereClause.supplierId = supplierId;
    }
    if (purchaseId) {
      whereClause.purchaseId = purchaseId;
    }

    return this.prisma.purchasePayment.findMany({
      where: whereClause,
      include: {
        paymentMethod: {
          select: {
            id: true,
            name: true,
            code: true,
          },
        },
        supplier: {
          select: {
            id: true,
            name: true,
          },
        },
        branch: {
          select: {
            id: true,
            name: true,
          },
        },
      },
      orderBy: {
        paymentDate: 'desc',
      },
    });
  }

  async deletePayment(id: string, businessId: string) {
    const payment = await this.prisma.purchasePayment.findFirst({
      where: { id, businessId },
    });

    if (!payment) {
      throw new NotFoundException('Payment record not found.');
    }

    return this.prisma.$transaction(async (tx) => {
      // If linked to a purchase, decrement amountPaid and update status
      if (payment.purchaseId) {
        const purchase = await tx.purchase.findUnique({
          where: { id: payment.purchaseId },
        });

        if (purchase) {
          const newAmountPaid = Math.max(0, purchase.amountPaid - payment.amount);
          let newStatus = 'PARTIAL';
          if (newAmountPaid <= 0.01) {
            newStatus = 'DUE';
          } else if (newAmountPaid >= purchase.grandTotal - 0.01) {
            newStatus = 'PAID';
          }

          await tx.purchase.update({
            where: { id: payment.purchaseId },
            data: {
              amountPaid: newAmountPaid,
              paymentStatus: newStatus as any,
            },
          });
        }
      }

      // If payment was settlement of opening balance, restore supplier.openingBalance
      if (payment.notes && payment.notes.includes('Settlement of Opening Balance')) {
        await tx.supplier.update({
          where: { id: payment.supplierId },
          data: {
            openingBalance: { increment: payment.amount },
          },
        });
      }

      // Delete the payment record
      await tx.purchasePayment.delete({
        where: { id },
      });

      return { success: true };
    });
  }
}
