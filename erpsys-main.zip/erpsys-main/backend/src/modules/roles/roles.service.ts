import { Injectable, BadRequestException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class RolesService {
  public readonly defaultPermissions: Record<string, string[]> = {
    admin: [
      "pos:view", "pos:create_transaction", "pos:void_transaction", "pos:refund",
      "pos:edit_price", "pos:apply_discount", "pos:credit_sale", "pos:hold_sale", "pos:quick_add_product", "pos:close_register", "pos:reprint_receipt",
      "inventory:view", "inventory:add_product", "inventory:edit_product", "inventory:delete_product", "inventory:adjust_stock", "inventory:transfer_stock",
      "quotations:view", "quotations:create", "quotations:edit", "quotations:delete",
      "purchases:view", "purchases:create", "purchases:edit", "purchases:delete",
      "contacts:view", "contacts:create", "contacts:edit", "contacts:delete",
      "finance:view_ledger", "finance:add_expense", "finance:view_reports",
      "settings:view", "settings:edit",
      "users:view", "users:create", "users:edit", "users:delete", "users:manage_permissions"
    ],
    manager: [
      "pos:view", "pos:create_transaction", "pos:void_transaction", "pos:refund",
      "pos:edit_price", "pos:apply_discount", "pos:credit_sale", "pos:hold_sale", "pos:quick_add_product", "pos:close_register", "pos:reprint_receipt",
      "inventory:view", "inventory:add_product", "inventory:edit_product", "inventory:adjust_stock", "inventory:transfer_stock",
      "quotations:view", "quotations:create", "quotations:edit",
      "purchases:view", "purchases:create", "purchases:edit",
      "contacts:view", "contacts:create", "contacts:edit",
      "finance:view_ledger", "finance:add_expense", "finance:view_reports",
      "users:view"
    ],
    cashier: [
      "pos:view", "pos:create_transaction", "pos:hold_sale", "pos:reprint_receipt",
      "quotations:view", "quotations:create",
      "inventory:view",
      "contacts:view", "contacts:create"
    ],
    employee: [
      "pos:view",
      "inventory:view"
    ],
    "super-admin": [
      "super:manage_businesses",
      "super:view_analytics",
      "super:manage_subscriptions"
    ]
  };

  constructor(private readonly prisma: PrismaService) {
    this.seedDefaultRolePermissions();
  }

  public async seedDefaultRolePermissions() {
    const allPermissions = [
      // Point of Sale
      { id: "pos:view", name: "Access POS Terminal", description: "Allows opening the POS selling screen." },
      { id: "pos:create_transaction", name: "Create Transactions", description: "Allows processing sales and completing checkouts." },
      { id: "pos:void_transaction", name: "Void Transactions", description: "Allows voiding active or completed sales." },
      { id: "pos:refund", name: "Process Refunds", description: "Allows refunding items and returning cash/credit." },
      { id: "pos:edit_price", name: "Modify Selling Price", description: "Allows changing the unit price of items in the cart." },
      { id: "pos:apply_discount", name: "Apply Discounts", description: "Allows giving percentage or fixed bill discounts." },
      { id: "pos:credit_sale", name: "Allow Credit / Due Sale", description: "Allows completing sales with unpaid / due balances." },
      { id: "pos:hold_sale", name: "Hold / Resume Bills", description: "Allows saving sales on hold and resuming them in POS." },
      { id: "pos:quick_add_product", name: "Quick Add Products in POS", description: "Allows creating new products directly from POS." },
      { id: "pos:close_register", name: "Close Register & Shift", description: "Allows closing cash registers and submitting cash reports." },
      { id: "pos:reprint_receipt", name: "Reprint Receipts", description: "Allows reprinting past receipts." },

      // Quotations (Estimates)
      { id: "quotations:view", name: "View Quotations", description: "Allows viewing customer quotation estimates." },
      { id: "quotations:create", name: "Create Quotations", description: "Allows creating new price quotations for customers." },
      { id: "quotations:edit", name: "Edit Quotations", description: "Allows modifying pending quotations." },
      { id: "quotations:delete", name: "Delete Quotations", description: "Allows removing price quotations." },

      // Inventory & Stock
      { id: "inventory:view", name: "View Inventory", description: "Allows browsing product lists and stock levels." },
      { id: "inventory:add_product", name: "Add New Products", description: "Allows creating new product listings." },
      { id: "inventory:edit_product", name: "Edit Products", description: "Allows updating product names, prices, and details." },
      { id: "inventory:delete_product", name: "Delete Products", description: "Allows removing products from the system." },
      { id: "inventory:adjust_stock", name: "Adjust Stock Levels", description: "Allows manually updating stock counts." },
      { id: "inventory:transfer_stock", name: "Transfer Stock", description: "Allows transferring items between branches." },

      // Purchases & Procurement
      { id: "purchases:view", name: "View Purchases", description: "Allows browsing purchase orders and supplier bills." },
      { id: "purchases:create", name: "Create Purchases", description: "Allows recording new purchases from suppliers." },
      { id: "purchases:edit", name: "Edit Purchases", description: "Allows modifying purchase orders and received items." },
      { id: "purchases:delete", name: "Delete Purchases", description: "Allows removing purchase invoices." },

      // Contacts & CRM
      { id: "contacts:view", name: "View Contacts", description: "Allows viewing customers and suppliers directory." },
      { id: "contacts:create", name: "Create Contacts", description: "Allows adding new customers and suppliers." },
      { id: "contacts:edit", name: "Edit Contacts", description: "Allows updating customer and supplier details." },
      { id: "contacts:delete", name: "Delete Contacts", description: "Allows deleting customer and supplier profiles." },

      // Finance & Expenses
      { id: "finance:view_ledger", name: "View General Ledger", description: "Allows viewing overall sales revenue and expenses." },
      { id: "finance:add_expense", name: "Record Expenses", description: "Allows logging business costs and payouts." },
      { id: "finance:view_reports", name: "Financial Analytics & Reports", description: "Allows viewing detailed profit & loss charts." },

      // Settings
      { id: "settings:view", name: "View ERP Settings", description: "Allows viewing store configuration details." },
      { id: "settings:edit", name: "Modify ERP Settings", description: "Allows changing store details, currency, and tax." },

      // Users & HR
      { id: "users:view", name: "View Team Directory", description: "Allows viewing list of employees and roles." },
      { id: "users:create", name: "Add New Users", description: "Allows registering new employee accounts." },
      { id: "users:edit", name: "Edit User Profiles", description: "Allows updating names, emails, and roles." },
      { id: "users:delete", name: "Delete Users", description: "Allows terminating employee accounts." },
      { id: "users:manage_permissions", name: "Manage Permissions", description: "Allows editing role-permission mappings." },

      // Super Admin
      { id: "super:manage_businesses", name: "Manage Businesses", description: "Allows viewing and toggling business activation." },
      { id: "super:view_analytics", name: "View Global Analytics", description: "Allows viewing platform-wide sales and business metrics." },
      { id: "super:manage_subscriptions", name: "Manage Subscriptions", description: "Allows managing subscription plans and billing." }
    ];

    try {
      // 1. Seed Permissions
      for (const p of allPermissions) {
        await (this.prisma).permission.upsert({
          where: { id: p.id },
          update: { name: p.name, description: p.description },
          create: { id: p.id, name: p.name, description: p.description }
        });
      }
      console.log('Permissions seeded successfully');

      // 2. Seed Default Roles
      const defaultRoles = [
        {
          role: 'admin',
          name: 'Admin',
          description: 'Full system access and control',
          permissions: this.defaultPermissions.admin,
        },
        {
          role: 'manager',
          name: 'Manager',
          description: 'Store operations, sales, purchases and inventory management',
          permissions: this.defaultPermissions.manager,
        },
        {
          role: 'cashier',
          name: 'Cashier',
          description: 'Point of Sale operations and customer checkouts',
          permissions: this.defaultPermissions.cashier,
        },
        {
          role: 'employee',
          name: 'Employee',
          description: 'Basic employee operational access',
          permissions: this.defaultPermissions.employee,
        },
        {
          role: 'super-admin',
          name: 'Super Admin',
          description: 'Global platform administrator',
          permissions: this.defaultPermissions['super-admin'],
        }
      ];

      for (const dr of defaultRoles) {
        let roleRecord = await (this.prisma).role.findFirst({
          where: {
            role: dr.role,
            businessId: null,
          }
        });

        if (roleRecord) {
          roleRecord = await (this.prisma).role.update({
            where: { id: roleRecord.id },
            data: { name: dr.name, description: dr.description }
          });
        } else {
          roleRecord = await (this.prisma).role.create({
            data: {
              role: dr.role,
              name: dr.name,
              description: dr.description,
              businessId: null,
            }
          });
        }

        for (const permId of dr.permissions) {
          await (this.prisma).rolePermission.upsert({
            where: {
              roleId_permissionId: {
                roleId: roleRecord.id,
                permissionId: permId
              }
            },
            update: {},
            create: {
              roleId: roleRecord.id,
              permissionId: permId
            }
          });
        }
      }
      console.log('Default roles and role-permissions seeded successfully');
    } catch (error) {
      console.error('Error seeding default roles and permissions:', error);
    }
  }

  async getRoles(businessId?: string): Promise<any[]> {
    try {
      const whereClause: any = {
        OR: [
          { businessId: businessId || null },
          { businessId: null }
        ]
      };

      if (businessId) {
        whereClause.NOT = {
          role: 'super-admin',
          businessId: null
        };
      }

      const roles = await (this.prisma).role.findMany({
        where: whereClause,
        include: {
          rolePermissions: true
        },
        orderBy: { createdAt: 'asc' }
      });

      const roleMap = new Map<string, any>();
      for (const r of roles) {
        if (r.businessId === businessId || !roleMap.has(r.role)) {
          roleMap.set(r.role, {
            id: r.id,
            role: r.role,
            name: r.name,
            description: r.description || '',
            permissions: r.rolePermissions.map((rp: any) => rp.permissionId),
            businessId: r.businessId,
            isCustom: r.businessId !== null,
          });
        }
      }

      return Array.from(roleMap.values());
    } catch (error) {
      console.error('Error fetching roles:', error);
      return [];
    }
  }

  async createRole(
    data: { role: string; name: string; description?: string; permissions: string[]; createdById?: string },
    businessId?: string
  ): Promise<any> {
    const roleSlug = data.role.toLowerCase().replace(/\s+/g, '-');
    const targetBusinessId = businessId || null;

    const existing = await (this.prisma).role.findFirst({
      where: {
        role: roleSlug,
        businessId: targetBusinessId
      }
    });

    if (existing) {
      throw new BadRequestException('A role with this identifier already exists.');
    }

    const newRole = await (this.prisma).role.create({
      data: {
        role: roleSlug,
        name: data.name,
        description: data.description || '',
        businessId: targetBusinessId,
        createdById: data.createdById || null
      }
    });

    if (data.permissions && data.permissions.length > 0) {
      for (const permId of data.permissions) {
        await (this.prisma).rolePermission.create({
          data: {
            roleId: newRole.id,
            permissionId: permId
          }
        });
      }
    }

    return {
      ...newRole,
      permissions: data.permissions,
      isCustom: newRole.businessId !== null
    };
  }

  async updateRole(
    id: string,
    data: { name?: string; description?: string; permissions?: string[]; updatedById?: string },
    businessId?: string
  ): Promise<any> {
    const roleRecord = await (this.prisma).role.findUnique({
      where: { id }
    });

    if (!roleRecord) {
      throw new BadRequestException('Role not found.');
    }

    if (roleRecord.businessId === null) {
      throw new BadRequestException('System default roles cannot be modified.');
    }

    if (businessId && roleRecord.businessId !== businessId) {
      throw new ForbiddenException('Access denied: You cannot modify roles belonging to another business.');
    }

    const updated = await (this.prisma).role.update({
      where: { id },
      data: {
        name: data.name,
        description: data.description,
        updatedById: data.updatedById || null,
      }
    });

    if (data.permissions) {
      await (this.prisma).rolePermission.deleteMany({
        where: { roleId: id }
      });

      for (const permId of data.permissions) {
        await (this.prisma).rolePermission.create({
          data: {
            roleId: id,
            permissionId: permId
          }
        });
      }
    }

    return {
      ...updated,
      permissions: data.permissions || [],
      isCustom: updated.businessId !== null
    };
  }

  async deleteRole(id: string, businessId?: string): Promise<{ success: boolean }> {
    const roleRecord = await (this.prisma).role.findUnique({
      where: { id }
    });

    if (!roleRecord) {
      throw new BadRequestException('Role not found.');
    }

    if (roleRecord.businessId === null) {
      throw new BadRequestException('System default roles cannot be deleted.');
    }

    if (businessId && roleRecord.businessId !== businessId) {
      throw new ForbiddenException('Access denied: You cannot delete roles belonging to another business.');
    }

    const userCount = await this.prisma.user.count({
      where: {
        role: {
          role: roleRecord.role
        },
        businessId: businessId || null
      }
    });

    if (userCount > 0) {
      throw new BadRequestException(`Cannot delete role. There are ${userCount} user(s) currently assigned to this role.`);
    }

    await (this.prisma).role.delete({
      where: { id }
    });

    return { success: true };
  }

  async getRolePermissions(businessId?: string): Promise<Record<string, string[]>> {
    const result: Record<string, string[]> = {};

    try {
      const whereClause: any = {
        OR: [
          { businessId: businessId || null },
          { businessId: null }
        ]
      };

      if (businessId) {
        whereClause.NOT = {
          role: 'super-admin',
          businessId: null
        };
      }

      const roles = await (this.prisma).role.findMany({
        where: whereClause,
        include: {
          rolePermissions: true
        }
      });

      const roleMap = new Map<string, any>();
      for (const r of roles) {
        if (r.businessId === businessId || !roleMap.has(r.role)) {
          roleMap.set(r.role, r);
        }
      }

      for (const [roleSlug, roleRecord] of roleMap.entries()) {
        result[roleSlug] = roleRecord.rolePermissions.map((rp: any) => rp.permissionId);
      }
    } catch (error) {
      console.error('Error fetching role permissions from DB:', error);
      return this.defaultPermissions;
    }

    return result;
  }

  async saveRolePermissions(permissions: Record<string, string[]>, businessId?: string): Promise<void> {
    try {
      const targetBusinessId = businessId || null;

      for (const [roleSlug, perms] of Object.entries(permissions)) {
        let roleRecord = await (this.prisma).role.findFirst({
          where: {
            role: roleSlug,
            businessId: targetBusinessId
          }
        });

        if (!roleRecord) {
          const systemRole = await (this.prisma).role.findFirst({
            where: {
              role: roleSlug,
              businessId: null
            }
          });

          roleRecord = await (this.prisma).role.create({
            data: {
              role: roleSlug,
              name: systemRole?.name || roleSlug,
              description: systemRole?.description || '',
              businessId: targetBusinessId
            }
          });
        }

        await (this.prisma).rolePermission.deleteMany({
          where: { roleId: roleRecord.id }
        });

        for (const permId of perms) {
          await (this.prisma).rolePermission.create({
            data: {
              roleId: roleRecord.id,
              permissionId: permId
            }
          });
        }
      }
    } catch (error) {
      console.error('Error saving role permissions:', error);
      throw new Error('Failed to save permissions');
    }
  }
}
