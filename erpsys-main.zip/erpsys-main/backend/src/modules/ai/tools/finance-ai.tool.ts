import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class FinanceAiTool {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Get operational expenses, category breakdown, and net profit overview
   */
  async getFinanceContext(businessId: string, userRole = 'CASHIER') {
    const normalizedRole = userRole.toUpperCase().replace(/[-\s]/g, '_');
    if (normalizedRole === 'CASHIER') {
      return {
        accessRestricted: true,
        message: 'Operational expenditure and net profit metrics are restricted from CASHIER role.',
      };
    }

    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    const [expenses, salesAgg] = await Promise.all([
      this.prisma.expense.findMany({
        where: {
          businessId,
          expenseDate: { gte: startOfMonth },
        },
        include: {
          category: { select: { name: true } },
        },
      }),
      this.prisma.sale.aggregate({
        where: {
          businessId,
          createdAt: { gte: startOfMonth },
        },
        _sum: { grandTotal: true },
      }),
    ]);

    let totalExpensesThisMonth = 0;
    const categoryBreakdown: Record<string, number> = {};

    expenses.forEach((e: any) => {
      const amt = Number(e.amount || 0);
      totalExpensesThisMonth += amt;
      const catName = e.category?.name || 'General Expense';
      categoryBreakdown[catName] = (categoryBreakdown[catName] || 0) + amt;
    });

    const totalRevenueThisMonth = Number(salesAgg._sum.grandTotal || 0);
    const estimatedGrossProfit = totalRevenueThisMonth - totalExpensesThisMonth;

    return {
      period: `${now.toLocaleString('default', { month: 'long' })} ${now.getFullYear()}`,
      totalRevenue: totalRevenueThisMonth,
      totalExpenses: totalExpensesThisMonth,
      estimatedProfitOrMargin: estimatedGrossProfit,
      expenseCount: expenses.length,
      categoryBreakdown,
    };
  }
}
