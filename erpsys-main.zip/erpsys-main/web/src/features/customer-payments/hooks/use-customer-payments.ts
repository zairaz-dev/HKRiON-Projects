import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { customerPaymentService } from "@/services/customer-payment-service";
import { queryKeys } from "@/lib/query-keys";

export function useCustomerPaymentsQuery(
  businessId: string,
  filters: {
    branchId?: string;
    customerId?: string;
    saleId?: string;
  },
) {
  return useQuery({
    queryKey: queryKeys.customerPayments.list(
      businessId,
      filters.branchId,
      filters.customerId,
      filters.saleId,
    ),
    queryFn: () => customerPaymentService.getPayments(businessId, filters),
    enabled: !!businessId,
  });
}

export function useCreateCustomerPaymentMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: Parameters<typeof customerPaymentService.createPayment>[0]) =>
      customerPaymentService.createPayment(data),
    onSuccess: () => {
      // Invalidate query caches for payments, sales, and customers list!
      queryClient.invalidateQueries({ queryKey: queryKeys.customerPayments.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.pos.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.customers.all });
    },
  });
}

export function useDeleteCustomerPaymentMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, businessId }: { id: string; businessId: string }) =>
      customerPaymentService.deletePayment(id, businessId),
    onSuccess: () => {
      // Invalidate query caches for payments, sales, and customers list!
      queryClient.invalidateQueries({ queryKey: queryKeys.customerPayments.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.pos.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.customers.all });
    },
  });
}

export function useRefundCustomerAdvanceMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: {
      customerId: string;
      amount: number;
      paymentMethodId: string;
      branchId: string;
      businessId: string;
      notes?: string;
    }) => customerPaymentService.refundAdvance(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.customerPayments.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.pos.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.customers.all });
    },
  });
}
