# Hardcoded Pattern Reference & Code Smells

This document outlines the regex patterns and code smells targeted by the `clean-hardcoded` skill.

## 1. Contact & Identity Information
- **Phone Numbers**:
  - Pattern: `(\+94|07)[0-9\s-]{8,12}`
  - Typical hardcoded values: `+94 76 1119 823`, `+94 76 8671 219`, `076 111 9823`
  - Correct Destination: `SITE_CONFIG.phone`, `SITE_CONFIG.secondaryPhone` (fed into `useCMS`)
- **Email Addresses**:
  - Pattern: `[a-zA-Z0-9._%+-]+@(faizangems|gmail)\.[a-zA-Z]{2,}`
  - Typical hardcoded values: `faizangems2025@gmail.com`, `admin@faizangems.com`
  - Correct Destination: `SITE_CONFIG.email`, `SITE_CONFIG.adminEmail`, or `process.env.ADMIN_EMAIL`
- **Showroom Addresses**:
  - Pattern: `(283/2|N\.C\s*Road|Trincomalee|Galle Road|Kalutara)`
  - Correct Destination: `SITE_CONFIG.showroom` / `useCMS`

## 2. Banking Details
- **Account Numbers**: `100048299104`
- **SWIFT Codes**: `COMBCEKLXXX`
- **Bank Names**: `Commercial Bank of Ceylon PLC`
- Correct Destination: `SITE_CONFIG.banking.*` / `useCMS`

## 3. Storage & Cache Keys
- **Cart Key**: `maison_cart` -> `STORAGE_KEYS.cart` (with fallback to `STORAGE_KEYS.legacyCart`)
- **Wishlist Key**: `maison_vault_wishlist` -> `STORAGE_KEYS.wishlist`
- **Currency Key**: `maison_currency` -> `STORAGE_KEYS.currency`

## 4. Promo Codes & Magic Numbers
- **Promo Codes**: `FAIZAN5`, `VAULT`, `MAISON5` -> `PROMO_CODES` in `src/lib/constants/promo.ts`
- **Exchange Rates**: `CAST(total AS DECIMAL(15,2)) / 300` -> `DEFAULT_LKR_RATE` or dynamic rates
- **District Lists**: 25 district names hardcoded in UI -> `SRI_LANKA_DISTRICTS` in `src/lib/data/districts.ts`

## 5. Hostnames & Absolute URLs
- **Localhost URLs**: `http://127.0.0.1:3000` or `http://localhost:3000`
- Correct Destination: `process.env.NEXTAUTH_URL` or `process.env.NEXT_PUBLIC_APP_URL`
