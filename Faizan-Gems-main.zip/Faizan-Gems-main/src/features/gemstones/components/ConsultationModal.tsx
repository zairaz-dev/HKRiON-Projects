"use client";

import React, { useState } from "react";
import { Gemstone } from "@/types/gemstone";
import { CloseIcon, CheckIcon, AwardIcon } from "@/components/ui/LuxuryIcons";
import { LuxurySelect } from "@/components/ui/LuxurySelect";
import { SITE_CONFIG } from "@/lib/constants/site";

interface ConsultationModalProps {
  gemstone?: Gemstone;
  onClose: () => void;
}

export function ConsultationModal({ gemstone, onClose }: ConsultationModalProps) {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    location: "Virtual Private Video Consultation (High-Def Microscope)",
    preferredDate: "",
    notes: gemstone ? `Inquiring about ${gemstone.name} (${gemstone.sku})` : "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Prevent background scrolling & handle Escape key
  React.useEffect(() => {
    document.body.style.overflow = "hidden";
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [onClose]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await fetch("/api/inquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          preferredLocation: formData.location,
          preferredSalon: formData.location,
          gemstoneId: gemstone?.id,
          gemstoneName: gemstone?.name,
          message: `[Date: ${formData.preferredDate || "Flexible"}] ${formData.notes}`,
        }),
      });
    } catch {
      // Continue and show confirmation even if offline
    } finally {
      setIsSubmitting(false);
      setSubmitted(true);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/60 backdrop-blur-sm animate-luxury-backdrop"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-lg bg-white border border-[#C5A880] shadow-2xl p-6 sm:p-8 animate-luxury-modal"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          aria-label="Close consultation modal"
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-[#FAF8F5] text-[#18181D] hover:bg-[#18181D] hover:text-white flex items-center justify-center transition-colors border border-[#E8E4DC]"
        >
          <CloseIcon className="w-4 h-4" />
        </button>

        {!submitted ? (
          <div>
            <div className="text-center mb-6">
              <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-[#FAF8F5] border border-[#C5A880] text-[#C5A880] mb-2">
                <AwardIcon className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-sans tracking-wide-luxury uppercase text-[#9A7B4F] block">
                Faizan Gems Client Advisory
              </span>
              <h2 className="font-serif text-2xl text-[#18181D] mt-1 font-medium">
                Private Gemologist Consultation
              </h2>
              <p className="text-xs text-[#8C867D] font-sans mt-1">
                Schedule a confidential 1-on-1 session with our GIA Graduate Gemologists.
              </p>
            </div>

            {gemstone && (
              <div className="mb-4 p-3 bg-[#FAF8F5] border border-[#E8E4DC] flex items-center justify-between text-xs font-sans">
                <div>
                  <span className="text-[#8C867D] block text-[10px] uppercase tracking-wider">Specimen of Interest</span>
                  <span className="text-[#18181D] font-medium">{gemstone.name}</span>
                </div>
                <span className="text-[#9A7B4F] font-mono">{gemstone.sku}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 text-xs font-sans">
              <div>
                <label className="block text-[#554F47] uppercase tracking-wider text-[10px] mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Full Legal Name"
                  className="w-full px-3.5 py-2.5 border border-[#E8E4DC] focus:border-[#C5A880] focus:outline-none bg-[#FAF8F5]/50 text-[#18181D]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#554F47] uppercase tracking-wider text-[10px] mb-1">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="name@domain.com"
                    className="w-full px-3.5 py-2.5 border border-[#E8E4DC] focus:border-[#C5A880] focus:outline-none bg-[#FAF8F5]/50 text-[#18181D]"
                  />
                </div>
                <div>
                  <label className="block text-[#554F47] uppercase tracking-wider text-[10px] mb-1">
                    Phone / WhatsApp *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder={SITE_CONFIG.contact.phone}
                    className="w-full px-3.5 py-2.5 border border-[#E8E4DC] focus:border-[#C5A880] focus:outline-none bg-[#FAF8F5]/50 text-[#18181D]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[#554F47] uppercase tracking-wider text-[10px] mb-1">
                  Consultation Format
                </label>
                <LuxurySelect
                  value={formData.location}
                  onChange={(val) => setFormData({ ...formData, location: val })}
                  variant="light"
                  size="md"
                  options={[
                    {
                      value: "Virtual Private Video Consultation (High-Def Microscope)",
                      label: "Virtual Video Call (4K Live Gem Microscope)",
                    },
                    {
                      value: "Trincomalee Showroom (N.C Road)",
                      label: `Trincomalee Showroom (${SITE_CONFIG.showroom.address})`,
                    },
                    {
                      value: "Direct Phone / WhatsApp Consultation",
                      label: "Phone / WhatsApp Consultation",
                    },
                  ]}
                />
              </div>

              <div>
                <label className="block text-[#554F47] uppercase tracking-wider text-[10px] mb-1">
                  Specific Inquiries or Acquisition Notes
                </label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-3.5 py-2 border border-[#E8E4DC] focus:border-[#C5A880] focus:outline-none bg-[#FAF8F5]/50 text-[#18181D]"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 bg-[#18181D] hover:bg-[#2A2A32] disabled:opacity-60 text-white text-xs uppercase tracking-widest font-sans transition-colors shadow-md mt-2 btn-luxury-press"
              >
                {isSubmitting ? "Transmitting Private Request..." : "Request Private Appointment"}
              </button>
            </form>
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#18181D] text-[#C5A880] mb-4">
              <CheckIcon className="w-6 h-6" />
            </div>
            <h3 className="font-serif text-2xl text-[#18181D]">Appointment Requested</h3>
            <p className="mt-2 text-xs text-[#6B655C] font-sans leading-relaxed max-w-sm mx-auto">
              Thank you, {formData.name}. Our Head of Private Client Acquisitions will reach out via {formData.email} within 2 hours to confirm your private session.
            </p>
            <button
              onClick={onClose}
              className="mt-6 px-6 py-2.5 bg-[#18181D] text-white text-xs uppercase tracking-wider font-sans hover:bg-[#2A2A32]"
            >
              Return to Specimen
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
