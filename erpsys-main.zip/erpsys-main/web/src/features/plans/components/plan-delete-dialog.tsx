"use strict";
"use client";

import React, { useState } from 'react';
import { Plan } from '../../subscriptions/types';
import { Button } from '@/components/ui/button';
import { Trash2, Loader2 } from 'lucide-react';
import { subscriptionService } from '@/services/subscription-service';

interface PlanDeleteDialogProps {
  plan: Plan | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function PlanDeleteDialog({ plan, isOpen, onClose, onSuccess }: PlanDeleteDialogProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen || !plan) return null;

  const handleDelete = async () => {
    setLoading(true);
    setError('');
    try {
      await subscriptionService.deletePlan(plan.id);
      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to delete plan.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-sm bg-card border border-border rounded-xl overflow-hidden shadow-2xl p-6 space-y-4 text-center">
        <div className="mx-auto w-12 h-12 rounded-full bg-rose-500/10 border border-rose-500/25 flex items-center justify-center text-rose-500">
          <Trash2 className="w-5 h-5" />
        </div>

        <div className="space-y-1">
          <h3 className="text-sm font-bold text-foreground uppercase tracking-wider font-mono">
            Delete Plan?
          </h3>
          <p className="text-xs text-muted-foreground">
            Are you sure you want to delete <strong className="text-foreground">{plan.name}</strong>?
            This will permanently remove this tier.
          </p>
        </div>

        {error && (
          <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 p-2.5 rounded-lg text-xs">
            {error}
          </div>
        )}

        <div className="pt-2 flex items-center justify-center gap-3">
          <Button type="button" variant="outline" onClick={onClose} className="text-xs h-9 flex-1">
            Cancel
          </Button>
          <Button
            type="button"
            variant="destructive"
            onClick={handleDelete}
            disabled={loading}
            className="text-xs h-9 flex-1 flex items-center justify-center gap-1.5 shadow-md shadow-rose-500/20"
          >
            {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 'Delete'}
          </Button>
        </div>
      </div>
    </div>
  );
}
