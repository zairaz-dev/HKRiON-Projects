import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class SalesAiTool {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Get sales statistics, invoice totals and payment summaries
   */
  async getSalesContext(businessId: string, branchId?: string, userRole?: string) {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    const branchFilter = branchId && branchId !== 'all' ? { branchId } : {};

    const [todayAgg, monthAgg, recentSales] = await Promise.all([
      this.prisma.sale.aggregate({
        where: {
          businessId,
          ...branchFilter,
          createdAt: { gte: startOfToday },
        },
        _sum: { grandTotal: true, amountPaid: true },
        _count: { _all: true },
      }),
      this.prisma.sale.aggregate({
        where: {
          businessId,
          ...branchFilter,
          createdAt: { gte: startOfMonth },
        },
        _sum: { grandTotal: true, amountPaid: true },
        _count: { _all: true },
      }),
      this.prisma.sale.findMany({
        where: {
          businessId,
          ...branchFilter,
        },
        orderBy: { createdAt: 'desc' },
        take: 5,
        include: {
          customer: { select: { name: true } },
        },
      }),
    ]);

    return {
      today: {
        invoiceCount: todayAgg._count._all || 0,
        totalSales: Number(todayAgg._sum.grandTotal || 0),
        totalReceived: Number(todayAgg._sum.amountPaid || 0),
        dueAmount: Number((todayAgg._sum.grandTotal || 0) - (todayAgg._sum.amountPaid || 0)),
      },
      thisMonth: {
        invoiceCount: monthAgg._count._all || 0,
        totalSales: Number(monthAgg._sum.grandTotal || 0),
        totalReceived: Number(monthAgg._sum.amountPaid || 0),
      },
      recentInvoices: recentSales.map((s) => ({
        invoiceNo: s.invoiceNumber,
        customer: s.customer?.name || 'Walk-in Customer',
        amount: Number(s.grandTotal),
        status: s.status,
        date: s.createdAt.toISOString().split('T')[0],
      })),
    };
  }
}
