"use client";

import React from "react";
import Image from "next/image";
import Link from "next/link";
import { useCMS } from "@/features/cms/useCMS";
import { SITE_CONFIG } from "@/lib/constants/site";
import {
  CertificateShieldIcon,
  ArmoredTruckIcon,
  AwardIcon,
  GemIcon,
} from "@/components/ui/LuxuryIcons";

export default function AboutPage() {
  const { getBlock } = useCMS();

  // Core Brand Info
  const companyName = SITE_CONFIG.legalName;
  const brandSlogan = getBlock("about.brand_slogan", SITE_CONFIG.slogan);
  const brandTagline = getBlock("about.brand_tagline", SITE_CONFIG.tagline);
  const pageIntro = getBlock(
    "about.page_intro",
    "Faizan Gems (Pvt) Ltd is a Sri Lankan gemstone trading and jewellery company specializing in the buying and selling of natural gemstones, with a special focus on Sri Lankan sapphires."
  );

  // About Cards
  const tradingDesc = getBlock(
    "about.trading_desc",
    "We source and trade carefully selected natural gemstones from Sri Lanka, with a special focus on Sri Lankan sapphires."
  );
  const jewelleryDesc = getBlock(
    "about.jewellery_desc",
    "In addition to gemstone trading, we offer custom jewellery manufacturing, creating unique rings, earrings, pendants, bracelets and necklaces according to our customers’ requirements. Our jewellery combines carefully selected natural gemstones with quality craftsmanship to create beautiful and timeless pieces."
  );
  const trustDesc = getBlock(
    "about.trust_desc",
    "At Faizan Gems, we believe that trust, authenticity, quality and customer satisfaction are the foundation of a successful gemstone business. We are committed to providing genuine natural gemstones, transparent service and professional assistance to both local and international customers."
  );
  const visionShort = getBlock(
    "about.vision_short",
    "Our vision is to connect the rich Sri Lankan gemstone heritage with customers and jewellery markets around the world, while building long-term relationships based on trust, quality and excellence."
  );

  // Mission & Vision
  const missionStatement = getBlock(
    "about.mission_statement",
    "Faizan Gems (Pvt) Ltd is committed to sourcing and trading genuine natural gemstones, especially Sri Lankan sapphires, while creating high-quality custom jewellery that combines the beauty of natural gemstones with modern craftsmanship. We aim to provide our local and international customers with authenticity, transparency, competitive value, and reliable service from gemstone selection to the final jewellery piece."
  );
  const visionStatement = getBlock(
    "about.vision_statement",
    "To become a trusted and internationally recognized Sri Lankan gemstone and jewellery company, renowned for genuine natural gemstones, exceptional craftsmanship, ethical business practices, and lasting customer relationships."
  );

  // CEO Info
  const ceoName = getBlock("about.founder_name", "Riyas Abdul Aziz (JP)");
  const ceoTitle = getBlock("about.founder_title", "CEO / Founder");
  const ceoCredentials = getBlock("about.founder_credentials", "BSc in Psychology & Counselling");
  const ceoImage = getBlock("about.founder_image", "/uploads/gemstones/gem-1789653639242-gt09cd.webp");
  const ceoGreeting = getBlock("about.founder_greeting", "Assalamu Alaikum and warm greetings,");
  const ceoP1 = getBlock(
    "about.founder_p1",
    "It is my great pleasure to welcome you to Faizan Gems (Pvt) Ltd, a Sri Lankan gemstone trading and jewellery company built on trust, authenticity, quality and customer satisfaction."
  );
  const ceoP2 = getBlock(
    "about.founder_p2",
    "Sri Lanka is world-renowned for its exceptional natural gemstones, particularly its beautiful sapphires. At Faizan Gems, our aim is to share this valuable heritage with customers in Sri Lanka and around the world through carefully selected natural gemstones and professionally crafted custom jewellery."
  );
  const ceoP3 = getBlock(
    "about.founder_p3",
    "Our business is not only about buying and selling gemstones. We are committed to building long-term relationships with our customers by providing honest information, reliable service and quality products. Whether you are looking for a natural Sri Lankan sapphire, a gemstone for investment, or a unique custom-made ring, pendant, bracelet or other jewellery, our team is ready to assist you."
  );
  const ceoP4 = getBlock(
    "about.founder_p4",
    "We continuously strive to improve our standards, expand our international presence and introduce the beauty of Sri Lankan gemstones to new markets."
  );
  const ceoP5 = getBlock(
    "about.founder_p5",
    "I sincerely thank all our customers, business partners and supporters for their trust in Faizan Gems. We look forward to growing together and creating lasting value through Sri Lankan gemstones and fine craftsmanship."
  );

  // Locations
  const headOffice = {
    title: getBlock("about.headoffice_title", "Head Office – Trincomalee"),
    address: getBlock("about.headoffice_address", SITE_CONFIG.showroom.fullAddress),
    badge: getBlock("about.headoffice_badge", SITE_CONFIG.showroom.badge),
    description: getBlock(
      "about.headoffice_desc",
      "Our main showroom and gemological facility where stones are inspected, certified, and dispatched worldwide."
    ),
    phone: getBlock("about.headoffice_phone", SITE_CONFIG.showroom.phone),
  };

  const kalutaraOffice = {
    title: getBlock("about.kalutara_title", SITE_CONFIG.branches.kalutara.title),
    address: getBlock("about.kalutara_address", SITE_CONFIG.branches.kalutara.address),
    badge: getBlock("about.kalutara_badge", SITE_CONFIG.branches.kalutara.badge),
    description: getBlock(
      "about.kalutara_desc",
      "Our western province gemstone trading and client consultation centre along the historic coastal gemstone corridor."
    ),
    phone: getBlock("about.kalutara_phone", SITE_CONFIG.branches.kalutara.phone),
  };

  // Contacts
  const phonePrimary = headOffice.phone;
  const phoneSecondary = kalutaraOffice.phone;

  // Gemstone types sourced
  const gemstonesList = [
    { name: "Blue Sapphires", color: "from-blue-600/30 to-blue-900/40", border: "border-blue-500/30" },
    { name: "Yellow Sapphires", color: "from-amber-500/30 to-yellow-800/40", border: "border-yellow-500/30" },
    { name: "Padparadscha Sapphires", color: "from-rose-500/30 to-orange-800/40", border: "border-rose-400/30" },
    { name: "Burmese & Ceylon Rubies", color: "from-red-600/30 to-rose-900/40", border: "border-red-500/30" },
    { name: "Chrysoberyl & Cat’s Eye", color: "from-emerald-500/30 to-teal-800/40", border: "border-emerald-500/30" },
    { name: "Natural Emeralds", color: "from-emerald-600/30 to-green-900/40", border: "border-emerald-600/30" },
    { name: "Aquamarine", color: "from-cyan-500/30 to-blue-800/40", border: "border-cyan-400/30" },
    { name: "Fine Garnets & Rare Gems", color: "from-red-800/30 to-amber-900/40", border: "border-amber-600/30" },
  ];

  // Custom jewellery offerings
  const jewelleryItems = [
    { title: "Bespoke Rings", desc: "Engagement, eternity, and statement solitaire rings." },
    { title: "Earrings", desc: "Fine studs, drop earrings, and halo chandelier designs." },
    { title: "Pendants", desc: "Signature gemstone pendants crafted in gold and platinum." },
    { title: "Bracelets", desc: "Tennis bracelets and customized gemstone bangles." },
    { title: "Necklaces", desc: "High-jewellery suites and everyday fine necklaces." },
  ];

  return (
    <div className="bg-[#FAF8F5] text-[#18181D] selection:bg-[#C5A880] selection:text-[#0D0D11]">
      {/* ========================================================================= */}
      {/* 1. HERO SECTION (Dark Obsidian Luxury Atmosphere)                         */}
      {/* ========================================================================= */}
      <section className="relative bg-[#0D0D11] text-[#FAF8F5] pt-32 pb-20 sm:pt-36 sm:pb-28 lg:pt-40 lg:pb-32 overflow-hidden border-b border-white/10">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-[#C5A880]/10 rounded-full blur-[140px] pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 w-[400px] h-[300px] bg-[#9A7B4F]/10 rounded-full blur-[120px] pointer-events-none" />

        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-4xl mx-auto space-y-6">

            <h1 className="font-serif text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-light text-[#FAF8F5] leading-[1.08] tracking-tight">
              &ldquo;{brandSlogan}&rdquo;
            </h1>

            <p className="text-xs sm:text-sm md:text-base text-[#C5A880] font-sans uppercase tracking-widest font-medium">
              {brandTagline}
            </p>

            <p className="text-sm sm:text-base md:text-lg text-[#C7C2BA] font-sans font-light leading-relaxed max-w-2xl mx-auto pt-2">
              {pageIntro}
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              <Link
                href="/shop"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 bg-[#C5A880] text-[#0D0D11] hover:bg-[#E0CFA9] font-sans text-xs uppercase tracking-luxury font-medium transition-all duration-300 shadow-lg hover:shadow-xl hover:shadow-[#C5A880]/20 transform hover:-translate-y-0.5"
              >
                <span>Explore Gemstones</span>
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
              </Link>
              <a
                href="#about-us"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 border border-white/20 text-[#FAF8F5] hover:border-[#C5A880] hover:text-[#C5A880] font-sans text-xs uppercase tracking-luxury font-medium transition-all duration-300 hover:bg-white/5"
              >
                <span>Discover Our Story ↓</span>
              </a>
              <a
                href="#locations"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 border border-white/20 text-[#FAF8F5] hover:border-[#C5A880] hover:text-[#C5A880] font-sans text-xs uppercase tracking-luxury font-medium transition-all duration-300 hover:bg-white/5"
              >
                <span>Our Locations</span>
              </a>
            </div>
          </div>

          {/* Quick Pillars Bar */}
          <div className="mt-14 sm:mt-16 grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 border-t border-white/10 pt-8">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-[#C5A880]/15 border border-[#C5A880]/30 flex items-center justify-center shrink-0">
                <GemIcon className="w-4 h-4 text-[#C5A880]" />
              </div>
              <div>
                <p className="font-serif text-sm sm:text-base text-[#FAF8F5]">Natural Sapphires</p>
                <p className="font-sans text-[11px] text-[#A29C91]">Sri Lankan Origin</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-[#C5A880]/15 border border-[#C5A880]/30 flex items-center justify-center shrink-0">
                <AwardIcon className="w-4 h-4 text-[#C5A880]" />
              </div>
              <div>
                <p className="font-serif text-sm sm:text-base text-[#FAF8F5]">Custom Jewellery</p>
                <p className="font-sans text-[11px] text-[#A29C91]">Rings, Pendants &amp; More</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-[#C5A880]/15 border border-[#C5A880]/30 flex items-center justify-center shrink-0">
                <CertificateShieldIcon className="w-4 h-4 text-[#C5A880]" />
              </div>
              <div>
                <p className="font-serif text-sm sm:text-base text-[#FAF8F5]">Certified Natural</p>
                <p className="font-sans text-[11px] text-[#A29C91]">Independent Lab Verified</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-[#C5A880]/15 border border-[#C5A880]/30 flex items-center justify-center shrink-0">
                <ArmoredTruckIcon className="w-4 h-4 text-[#C5A880]" />
              </div>
              <div>
                <p className="font-serif text-sm sm:text-base text-[#FAF8F5]">Insured Delivery</p>
                <p className="font-sans text-[11px] text-[#A29C91]">Safe Global Shipping</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 2. ABOUT US (Core Story & Specialization)                                 */}
      {/* ========================================================================= */}
      <section id="about-us" className="py-20 lg:py-28 bg-[#FAF8F5] border-b border-[#E8E4DC]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
            <span className="text-[11px] font-sans uppercase tracking-wide-luxury text-[#9A7B4F] block font-medium">
              About Us
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-[#18181D] font-light">
              Faizan Gems (Pvt) Ltd
            </h2>
            <div className="w-12 h-0.5 bg-[#C5A880] mx-auto mt-4" />
            <p className="text-xs sm:text-sm text-[#6B655C] font-sans leading-relaxed pt-2">
              Sri Lankan gemstone trading and custom jewellery manufacturing with an uncompromising commitment to authenticity, trust, and fine craftsmanship.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Card 1: Gemstone Trading */}
            <div className="bg-white border border-[#E8E4DC] hover:border-[#C5A880] p-8 transition-all duration-300 hover:shadow-xl space-y-5">
              <div className="w-12 h-12 bg-[#FAF8F5] border border-[#C5A880]/40 flex items-center justify-center text-[#9A7B4F]">
                <GemIcon className="w-6 h-6" />
              </div>
              <h3 className="font-serif text-2xl text-[#18181D]">
                Natural Gemstone Trading
              </h3>
              <p className="text-xs sm:text-sm text-[#554F47] font-sans leading-relaxed">
                {tradingDesc}
              </p>
              <div className="pt-2 border-t border-[#E8E4DC]">
                <span className="text-[11px] font-sans uppercase tracking-wider text-[#9A7B4F] block mb-3 font-semibold">
                  Gemstones We Source &amp; Trade:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {gemstonesList.map((g, idx) => (
                    <span
                      key={idx}
                      className="text-[11px] font-sans px-2.5 py-1 bg-[#FAF8F5] border border-[#E8E4DC] text-[#18181D] rounded-none"
                    >
                      {g.name}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Card 2: Custom Jewellery Manufacturing */}
            <div className="bg-white border border-[#E8E4DC] hover:border-[#C5A880] p-8 transition-all duration-300 hover:shadow-xl space-y-5">
              <div className="w-12 h-12 bg-[#FAF8F5] border border-[#C5A880]/40 flex items-center justify-center text-[#9A7B4F]">
                <AwardIcon className="w-6 h-6" />
              </div>
              <h3 className="font-serif text-2xl text-[#18181D]">
                Custom Jewellery Manufacturing
              </h3>
              <p className="text-xs sm:text-sm text-[#554F47] font-sans leading-relaxed">
                {jewelleryDesc}
              </p>
              <div className="pt-2 border-t border-[#E8E4DC]">
                <span className="text-[11px] font-sans uppercase tracking-wider text-[#9A7B4F] block mb-3 font-semibold">
                  Bespoke Creations:
                </span>
                <ul className="space-y-2 text-xs font-sans text-[#554F47]">
                  {jewelleryItems.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-[#C5A880] font-bold">✦</span>
                      <span>
                        <strong className="text-[#18181D] font-medium">{item.title}:</strong> {item.desc}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Card 3: Trust & Foundation */}
            <div className="bg-white border border-[#E8E4DC] hover:border-[#C5A880] p-8 transition-all duration-300 hover:shadow-xl space-y-5 flex flex-col justify-between">
              <div className="space-y-5">
                <div className="w-12 h-12 bg-[#FAF8F5] border border-[#C5A880]/40 flex items-center justify-center text-[#9A7B4F]">
                  <CertificateShieldIcon className="w-6 h-6" />
                </div>
                <h3 className="font-serif text-2xl text-[#18181D]">
                  Our Pillars of Trust
                </h3>
                <p className="text-xs sm:text-sm text-[#554F47] font-sans leading-relaxed">
                  {trustDesc}
                </p>
                <div className="grid grid-cols-2 gap-2 pt-2">
                  <div className="p-2.5 bg-[#FAF8F5] border border-[#E8E4DC] text-center">
                    <span className="text-[11px] font-sans font-medium uppercase tracking-wider text-[#9A7B4F] block">Trust</span>
                    <span className="text-[10px] text-[#6B655C]">Transparent relationships</span>
                  </div>
                  <div className="p-2.5 bg-[#FAF8F5] border border-[#E8E4DC] text-center">
                    <span className="text-[11px] font-sans font-medium uppercase tracking-wider text-[#9A7B4F] block">Authenticity</span>
                    <span className="text-[10px] text-[#6B655C]">100% natural stones</span>
                  </div>
                  <div className="p-2.5 bg-[#FAF8F5] border border-[#E8E4DC] text-center">
                    <span className="text-[11px] font-sans font-medium uppercase tracking-wider text-[#9A7B4F] block">Quality</span>
                    <span className="text-[10px] text-[#6B655C]">Expert craftsmanship</span>
                  </div>
                  <div className="p-2.5 bg-[#FAF8F5] border border-[#E8E4DC] text-center">
                    <span className="text-[11px] font-sans font-medium uppercase tracking-wider text-[#9A7B4F] block">Satisfaction</span>
                    <span className="text-[10px] text-[#6B655C]">Global client support</span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-[#E8E4DC]">
                <p className="text-xs font-serif italic text-[#8C867D]">
                  &ldquo;{visionShort}&rdquo;
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 3. MISSION & VISION (Side-by-Side Luxury Section)                          */}
      {/* ========================================================================= */}
      <section className="py-20 lg:py-28 bg-[#131318] text-[#FAF8F5] relative overflow-hidden border-b border-white/10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
            <span className="text-[11px] font-sans uppercase tracking-wide-luxury text-[#E0CFA9] block font-medium">
              Purpose &amp; Direction
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-white font-light">
              Our Mission &amp; Vision
            </h2>
            <div className="w-12 h-0.5 bg-[#C5A880] mx-auto mt-4" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Mission Card */}
            <div className="bg-white/5 border border-white/10 hover:border-[#C5A880] p-8 sm:p-10 transition-all duration-300 space-y-6 relative group">
              <div className="flex items-center justify-between">
                <span className="text-xs font-sans uppercase tracking-luxury text-[#C5A880] font-semibold">
                  Our Mission
                </span>
                <span className="text-lg text-[#C5A880]">✦</span>
              </div>
              <h3 className="font-serif text-2xl sm:text-3xl text-white font-normal">
                Authenticity, Value &amp; Craftsmanship
              </h3>
              <p className="font-sans text-xs sm:text-sm text-[#C7C2BA] leading-relaxed">
                {missionStatement}
              </p>
              <div className="pt-4 border-t border-white/10 flex flex-wrap gap-2 text-[11px] font-sans text-[#E0CFA9]">
                <span className="px-2.5 py-1 bg-white/5 border border-white/10">Genuine Natural Stones</span>
                <span className="px-2.5 py-1 bg-white/5 border border-white/10">Modern Craftsmanship</span>
                <span className="px-2.5 py-1 bg-white/5 border border-white/10">Competitive Value</span>
                <span className="px-2.5 py-1 bg-white/5 border border-white/10">Reliable Service</span>
              </div>
            </div>

            {/* Vision Card */}
            <div className="bg-white/5 border border-white/10 hover:border-[#C5A880] p-8 sm:p-10 transition-all duration-300 space-y-6 relative group">
              <div className="flex items-center justify-between">
                <span className="text-xs font-sans uppercase tracking-luxury text-[#C5A880] font-semibold">
                  Our Vision
                </span>
                <span className="text-lg text-[#C5A880]">✦</span>
              </div>
              <h3 className="font-serif text-2xl sm:text-3xl text-white font-normal">
                Global Recognition &amp; Enduring Trust
              </h3>
              <p className="font-sans text-xs sm:text-sm text-[#C7C2BA] leading-relaxed">
                {visionStatement}
              </p>
              <div className="pt-4 border-t border-white/10 flex flex-wrap gap-2 text-[11px] font-sans text-[#E0CFA9]">
                <span className="px-2.5 py-1 bg-white/5 border border-white/10">Internationally Recognized</span>
                <span className="px-2.5 py-1 bg-white/5 border border-white/10">Exceptional Craftsmanship</span>
                <span className="px-2.5 py-1 bg-white/5 border border-white/10">Ethical Business</span>
                <span className="px-2.5 py-1 bg-white/5 border border-white/10">Lasting Relationships</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 4. MESSAGE FROM THE CEO (Official Executive Letter)                       */}
      {/* ========================================================================= */}
      <section className="py-20 lg:py-28 bg-[#FAF8F5] border-b border-[#E8E4DC]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white border border-[#C5A880]/50 shadow-2xl p-8 sm:p-12 lg:p-16 relative overflow-hidden">
            {/* Top Badge */}
            <div className="text-center mb-10 space-y-2">
              <span className="text-[10px] sm:text-[11px] font-sans uppercase tracking-wide-luxury text-[#9A7B4F] block font-semibold">
                Executive Leadership
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-[#18181D] font-light">
                Message from the CEO
              </h2>
              <div className="w-16 h-0.5 bg-[#C5A880] mx-auto mt-4" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-start">
              {/* Left Column: CEO Portrait & Credentials */}
              <div className="lg:col-span-4 space-y-4">
                <div className="relative aspect-[3/4] w-full bg-[#18181D] border border-[#C5A880]/40 overflow-hidden shadow-lg group">
                  <Image
                    src={ceoImage}
                    alt={`${ceoName} - ${ceoTitle}`}
                    fill
                    unoptimized={ceoImage.startsWith("/uploads")}
                    className="object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D11]/90 via-transparent to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4 text-white">
                    <p className="font-serif text-lg text-[#FAF8F5]">{ceoName}</p>
                    <p className="font-sans text-[11px] uppercase tracking-wider text-[#C5A880]">{ceoTitle}</p>
                    <p className="font-sans text-[10px] text-[#A8A196]">{ceoCredentials}</p>
                  </div>
                </div>

                <div className="p-4 bg-[#FAF8F5] border border-[#E8E4DC] text-center">
                  <span className="text-[10px] font-sans uppercase tracking-widest text-[#9A7B4F] block font-semibold">
                    Faizan Gems (Pvt) Ltd
                  </span>
                  <p className="font-serif italic text-xs text-[#18181D] mt-1">
                    &ldquo;{brandSlogan}&rdquo;
                  </p>
                </div>
              </div>

              {/* Right Column: Formal Letter */}
              <div className="lg:col-span-8 space-y-6">
                <p className="font-serif text-xl sm:text-2xl text-[#18181D] italic">
                  {ceoGreeting}
                </p>

                <div className="space-y-4 font-sans text-xs sm:text-sm md:text-[15px] text-[#423E38] leading-relaxed">
                  <p>{ceoP1}</p>
                  <p>{ceoP2}</p>
                  <p>{ceoP3}</p>
                  {ceoP4 && <p>{ceoP4}</p>}
                  {ceoP5 && <p>{ceoP5}</p>}
                </div>

                {/* Sign-off */}
                <div className="pt-6 border-t border-[#E8E4DC]">
                  <p className="font-sans text-xs text-[#8C867D] uppercase tracking-wider mb-2">
                    With sincere gratitude,
                  </p>
                  <h4 className="font-serif text-2xl text-[#18181D] font-normal">
                    {ceoName}
                  </h4>
                  <p className="font-sans text-xs text-[#9A7B4F] font-medium mt-0.5">
                    {ceoCredentials}
                  </p>
                  <p className="font-sans text-xs text-[#6B655C] mt-0.5">
                    {ceoTitle}, {companyName}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 5. OUR LOCATIONS (Trincomalee & Kalutara)                                  */}
      {/* ========================================================================= */}
      <section id="locations" className="py-20 lg:py-28 bg-[#FAF8F5] border-b border-[#E8E4DC]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
            <span className="text-[11px] font-sans uppercase tracking-wide-luxury text-[#9A7B4F] block font-medium">
              Our Presence
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-[#18181D] font-light">
              Our Locations
            </h2>
            <div className="w-12 h-0.5 bg-[#C5A880] mx-auto mt-4" />
            <p className="text-xs sm:text-sm text-[#6B655C] font-sans leading-relaxed pt-2">
              Visit our offices in Sri Lanka for private consultations, loose gemstone viewings, and custom jewellery orders.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Head Office - Trincomalee */}
            <div className="bg-white border border-[#E8E4DC] hover:border-[#C5A880] p-8 sm:p-10 transition-all duration-300 hover:shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-sans uppercase tracking-luxury text-[#9A7B4F] bg-[#FAF8F5] px-3 py-1 border border-[#E8E4DC]">
                  {headOffice.badge}
                </span>
                <span className="text-sm text-[#C5A880]">📍</span>
              </div>
              <h3 className="font-serif text-2xl sm:text-3xl text-[#18181D]">
                {headOffice.title}
              </h3>
              <p className="text-sm font-sans font-medium text-[#18181D] bg-[#FAF8F5] p-3 border-l-2 border-[#C5A880]">
                {headOffice.address}
              </p>
              <p className="text-xs sm:text-sm text-[#6B655C] font-sans leading-relaxed">
                {headOffice.description}
              </p>
              <div className="pt-4 border-t border-[#E8E4DC] flex items-center gap-4">
                <a
                  href={`tel:${phonePrimary.replace(/\s+/g, "")}`}
                  className="text-xs font-sans text-[#9A7B4F] hover:text-[#18181D] uppercase tracking-wider font-semibold"
                >
                  Call Head Office &rarr;
                </a>
              </div>
            </div>

            {/* Kalutara Office */}
            <div className="bg-white border border-[#E8E4DC] hover:border-[#C5A880] p-8 sm:p-10 transition-all duration-300 hover:shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-sans uppercase tracking-luxury text-[#9A7B4F] bg-[#FAF8F5] px-3 py-1 border border-[#E8E4DC]">
                  {kalutaraOffice.badge}
                </span>
                <span className="text-sm text-[#C5A880]">📍</span>
              </div>
              <h3 className="font-serif text-2xl sm:text-3xl text-[#18181D]">
                {kalutaraOffice.title}
              </h3>
              <p className="text-sm font-sans font-medium text-[#18181D] bg-[#FAF8F5] p-3 border-l-2 border-[#C5A880]">
                {kalutaraOffice.address}
              </p>
              <p className="text-xs sm:text-sm text-[#6B655C] font-sans leading-relaxed">
                {kalutaraOffice.description}
              </p>
              <div className="pt-4 border-t border-[#E8E4DC] flex items-center gap-4">
                <a
                  href={`tel:${phoneSecondary.replace(/\s+/g, "")}`}
                  className="text-xs font-sans text-[#9A7B4F] hover:text-[#18181D] uppercase tracking-wider font-semibold"
                >
                  Call Kalutara Office &rarr;
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
