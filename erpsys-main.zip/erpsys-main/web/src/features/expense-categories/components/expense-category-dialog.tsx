import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { X, FolderPlus, Loader2, Tag, FileText, Folder, AlignLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { User } from "@hkr/types";
import { expenseCategoryFormSchema, ExpenseCategoryFormSchema } from "../schema";
import { ExpenseCategoryItem, BranchItem } from "../types";
import {
  useCreateExpenseCategoryMutation,
  useUpdateExpenseCategoryMutation,
  useExpenseCategoriesQuery,
} from "../hooks/use-expense-categories";

interface ExpenseCategoryDialogProps {
  isOpen: boolean;
  onClose: () => void;
  category?: ExpenseCategoryItem | null;
  branches: BranchItem[];
  currentUser: User;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

export function ExpenseCategoryDialog({
  isOpen,
  onClose,
  category,
  branches,
  currentUser,
  onSuccess,
  onError,
}: ExpenseCategoryDialogProps) {
  const isEditMode = !!category;
  const createMutation = useCreateExpenseCategoryMutation();
  const updateMutation = useUpdateExpenseCategoryMutation();

  // Fetch all categories to populate the Parent Category dropdown
  const { data: allCategories = [] } = useExpenseCategoriesQuery(currentUser.businessId || "");

  // Filter out the current category and any of its children (to prevent circular references)
  // For simplicity, we just filter out the category itself in edit mode.
  const parentCategoryOptions = allCategories.filter(
    (c) => !isEditMode || c.id !== category?.id
  );

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<ExpenseCategoryFormSchema>({
    resolver: zodResolver(expenseCategoryFormSchema),
    defaultValues: {
      name: "",
      code: "",
      description: "",
      parentId: "",
      branchIds: [],
      isActive: true,
    },
  });

  const watchBranchIds = watch("branchIds") || [];
  const watchParentId = watch("parentId") || "";
  const watchIsActive = watch("isActive");

  // Populate form in edit mode
  useEffect(() => {
    if (category) {
      const assignedBranchIds = category.branches?.map((cb) => cb.branch.id) || [];
      reset({
        name: category.name,
        code: category.code || "",
        description: category.description || "",
        parentId: category.parentId || "",
        branchIds: assignedBranchIds,
        isActive: category.isActive,
      });
    } else {
      reset({
        name: "",
        code: "",
        description: "",
        parentId: "",
        branchIds: [],
        isActive: true,
      });
    }
  }, [category, reset, isOpen]);

  const handleToggleBranch = (branchId: string) => {
    if (watchBranchIds.includes(branchId)) {
      setValue(
        "branchIds",
        watchBranchIds.filter((id) => id !== branchId),
        { shouldValidate: true }
      );
    } else {
      setValue("branchIds", [...watchBranchIds, branchId], {
        shouldValidate: true,
      });
    }
  };

  const onSubmit = async (data: ExpenseCategoryFormSchema) => {
    if (!currentUser.businessId) return;

    const payload = {
      name: data.name.trim(),
      code: data.code?.trim() || "",
      description: data.description?.trim() || "",
      parentId: data.parentId || null,
      branchIds: data.branchIds,
      isActive: data.isActive,
      businessId: currentUser.businessId,
      createdById: isEditMode ? undefined : currentUser.id,
      updatedById: isEditMode ? currentUser.id : undefined,
    };

    try {
      if (isEditMode && category) {
        await updateMutation.mutateAsync({ id: category.id, data: payload });
        onSuccess("Expense category updated successfully!");
      } else {
        await createMutation.mutateAsync(payload);
        onSuccess("Expense category created successfully!");
      }
      onClose();
    } catch (err: any) {
      onError(err.message || "Failed to save expense category.");
    }
  };

  const isLoading = createMutation.isPending || updateMutation.isPending;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-lg rounded-xl border border-border/50 bg-card p-6 shadow-2xl animate-in zoom-in-95 duration-200 my-8">
        <div className="flex items-center justify-between border-b border-border/50 pb-3 mb-4">
          <h3 className="text-lg font-bold flex items-center gap-2">
            <FolderPlus className="h-5 w-5 text-primary" />
            {isEditMode ? "Edit Expense Category" : "Add Expense Category"}
          </h3>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="h-8 w-8 rounded-full"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          {/* Name */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase">
              Category Name <span className="text-destructive">*</span>
            </label>
            <Input
              placeholder="e.g., Rent, Utilities"
              icon={<Tag className="h-4 w-4" />}
              {...register("name")}
              disabled={isLoading}
            />
            {errors.name && (
              <span className="text-xs text-rose-500">{errors.name.message}</span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Code */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-muted-foreground uppercase">
                Category Code
              </label>
              <Input
                placeholder="e.g., EXP-001"
                icon={<FileText className="h-4 w-4" />}
                {...register("code")}
                disabled={isLoading}
              />
            </div>

            {/* Parent Category */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-muted-foreground uppercase">
                Parent Category (For Sub-categories)
              </label>
              <Select
                value={watchParentId}
                onValueChange={(val) => setValue("parentId", val, { shouldValidate: true })}
                icon={<Folder className="h-4 w-4" />}
                disabled={isLoading}
              >
                <option value="">None (Main Category)</option>
                {parentCategoryOptions.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </Select>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase">
              Description
            </label>
            <div className="relative w-full">
              <div className="absolute left-3 top-3 text-muted-foreground/60">
                <AlignLeft className="h-4 w-4" />
              </div>
              <textarea
                placeholder="Enter category description"
                {...register("description")}
                disabled={isLoading}
                className="flex min-h-[60px] w-full rounded-md border border-input bg-transparent pl-10 pr-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
              />
            </div>
          </div>

          {/* Status */}
          <div className="flex items-center space-x-2 pt-2">
            <Checkbox
              id="isActive"
              checked={watchIsActive}
              onCheckedChange={(checked) => setValue("isActive", checked, { shouldValidate: true })}
              disabled={isLoading}
            />
            <label htmlFor="isActive" className="text-xs font-semibold cursor-pointer select-none">
              Active (Allow expense entries)
            </label>
          </div>

          {/* Branch Scope */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase block">
              Branch Mapping (Optional - Leave empty for Global)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-24 overflow-y-auto border border-border/40 rounded-md p-2 bg-background/50">
              {branches.map((branch) => {
                const isChecked = watchBranchIds.includes(branch.id);
                return (
                  <div
                    key={branch.id}
                    onClick={() => handleToggleBranch(branch.id)}
                    className={`flex items-center space-x-2 p-1.5 rounded-md cursor-pointer border text-xs font-medium transition-all ${
                      isChecked
                        ? "bg-primary/10 border-primary/30 text-primary"
                        : "bg-transparent border-transparent hover:bg-secondary/40 text-muted-foreground"
                    }`}
                  >
                    <Checkbox
                      checked={isChecked}
                      onCheckedChange={() => handleToggleBranch(branch.id)}
                      disabled={isLoading}
                    />
                    <span className="truncate">{branch.name}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Form Buttons */}
          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-border/50">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isLoading}
              className="h-9 px-4 text-xs"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isLoading}
              className="h-9 px-4 text-xs flex items-center gap-1.5"
            >
              {isLoading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
              {isEditMode ? "Save Changes" : "Add Category"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
