import { Controller, Get, Put, Post, Body, Query, UseGuards, Req } from '@nestjs/common';
import { EmailSettingsService } from './email-settings.service';
import { UpdateEmailSettingsDto, TestEmailDto } from './dto/email-settings.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('email-settings')
export class EmailSettingsController {
  constructor(private readonly emailSettingsService: EmailSettingsService) {}

  @Permissions(Permission.SETTINGS_VIEW)
  @Get()
  async getSettings(@Req() req: any, @Query('businessId') queryBusinessId?: string) {
    const user = req.user;
    const bId = user.role === 'super-admin' && queryBusinessId ? queryBusinessId : user.businessId;
    return this.emailSettingsService.getSettings(bId);
  }

  @Permissions(Permission.SETTINGS_EDIT)
  @Put()
  async updateSettings(@Req() req: any, @Body() dto: UpdateEmailSettingsDto) {
    const user = req.user;
    const bId = user.role === 'super-admin' && dto.businessId ? dto.businessId : user.businessId;
    return this.emailSettingsService.updateSettings(bId, dto);
  }

  @Permissions(Permission.SETTINGS_EDIT)
  @Post('test')
  async sendTestEmail(@Req() req: any, @Body() dto: TestEmailDto) {
    const user = req.user;
    const bId = user.role === 'super-admin' && dto.businessId ? dto.businessId : user.businessId;
    return this.emailSettingsService.sendTestEmail(bId, dto);
  }
}
