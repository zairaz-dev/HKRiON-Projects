import { AboutService } from "@/services/about.service";
import AboutClientView from "@/components/about/AboutClientView";

export const dynamic = "force-dynamic";

export default async function AboutPage() {
  const content = await AboutService.getContent();

  return <AboutClientView content={content} />;
}
