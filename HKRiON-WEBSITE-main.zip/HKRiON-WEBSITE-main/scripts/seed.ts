import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding MySQL Database with RBAC for HKRION (Pvt) Ltd...');

  // 1. Create Permissions
  const permissionsData = [
    { name: 'inquiries:read', description: 'View all contact submissions and inquiries' },
    { name: 'inquiries:assign', description: 'Assign inquiries to employees' },
    { name: 'inquiries:update', description: 'Update status of inquiries' },
    { name: 'users:manage', description: 'Create, update, and delete users and roles' },
    { name: 'services:manage', description: 'Manage service requests and projects' },
    { name: 'settings:manage', description: 'Manage system settings' },
  ];

  const permissionsMap: Record<string, string> = {};

  for (const p of permissionsData) {
    const perm = await prisma.permission.upsert({
      where: { name: p.name },
      update: { description: p.description, updatedBy: 'system-seed' },
      create: { name: p.name, description: p.description, createdBy: 'system-seed', updatedBy: 'system-seed' },
    });
    permissionsMap[p.name] = perm.id;
  }

  console.log('Permissions seeded:', Object.keys(permissionsMap));

  // 2. Create Roles
  const adminRole = await prisma.role.upsert({
    where: { name: 'ADMIN' },
    update: { description: 'Full system administrative access', updatedBy: 'system-seed' },
    create: { name: 'ADMIN', description: 'Full system administrative access', createdBy: 'system-seed', updatedBy: 'system-seed' },
  });

  const empRole = await prisma.role.upsert({
    where: { name: 'EMPLOYEE' },
    update: { description: 'Staff member with access to assigned inquiries and projects', updatedBy: 'system-seed' },
    create: { name: 'EMPLOYEE', description: 'Staff member with access to assigned inquiries and projects', createdBy: 'system-seed', updatedBy: 'system-seed' },
  });

  const custRole = await prisma.role.upsert({
    where: { name: 'CUSTOMER' },
    update: { description: 'Client account with access to own inquiries and service requests', updatedBy: 'system-seed' },
    create: { name: 'CUSTOMER', description: 'Client account with access to own inquiries and service requests', createdBy: 'system-seed', updatedBy: 'system-seed' },
  });

  // 3. Map Role Permissions
  const adminPerms = Object.values(permissionsMap);
  const empPerms = [permissionsMap['inquiries:read'], permissionsMap['inquiries:update'], permissionsMap['services:manage']];
  const custPerms = [permissionsMap['inquiries:read']];

  // Helper to connect Role and Permission
  const attachRolePermissions = async (roleId: string, permIds: string[]) => {
    for (const permId of permIds) {
      if (permId) {
        await prisma.rolePermission.upsert({
          where: { roleId_permissionId: { roleId, permissionId: permId } },
          update: { createdBy: 'system-seed' },
          create: { roleId, permissionId: permId, createdBy: 'system-seed' },
        });
      }
    }
  };

  await attachRolePermissions(adminRole.id, adminPerms);
  await attachRolePermissions(empRole.id, empPerms);
  await attachRolePermissions(custRole.id, custPerms);

  console.log('RolePermissions mapped!');

  // 4. Create Users linked to Roles
  const adminPassword = await bcrypt.hash('admin123', 10);
  const empPassword = await bcrypt.hash('emp123', 10);
  const custPassword = await bcrypt.hash('cust123', 10);

  const admin = await prisma.user.upsert({
    where: { email: 'admin@hkrion.com' },
    update: { password: adminPassword, roleId: adminRole.id, name: 'HKRION Admin', updatedBy: 'system-seed' },
    create: {
      name: 'HKRION Admin',
      email: 'admin@hkrion.com',
      password: adminPassword,
      roleId: adminRole.id,
      createdBy: 'system-seed',
      updatedBy: 'system-seed',
    },
  });

  const employee = await prisma.user.upsert({
    where: { email: 'employee@hkrion.com' },
    update: { password: empPassword, roleId: empRole.id, name: 'HKRION Senior Engineer', updatedBy: 'system-seed' },
    create: {
      name: 'HKRION Senior Engineer',
      email: 'employee@hkrion.com',
      password: empPassword,
      roleId: empRole.id,
      createdBy: 'system-seed',
      updatedBy: 'system-seed',
    },
  });

  const customer = await prisma.user.upsert({
    where: { email: 'customer@hkrion.com' },
    update: { password: custPassword, roleId: custRole.id, name: 'John Doe (Valued Client)', updatedBy: 'system-seed' },
    create: {
      name: 'John Doe (Valued Client)',
      email: 'customer@hkrion.com',
      password: custPassword,
      roleId: custRole.id,
      createdBy: 'system-seed',
      updatedBy: 'system-seed',
    },
  });

  console.log('Users created with roleIds:', { admin: admin.email, employee: employee.email, customer: customer.email });

  // 5. Create Initial Submissions in Database
  const count = await prisma.contactSubmission.count();
  if (count === 0) {
    await prisma.contactSubmission.createMany({
      data: [
        {
          name: 'John Doe',
          email: 'customer@hkrion.com',
          phone: '+94 77 50 14 217',
          service: 'Enterprise ERP & Business Systems',
          message: 'We require a custom ERP system with inventory tracking for our enterprise business in Sri Lanka.',
          status: 'PENDING',
          customerId: customer.id,
          createdBy: customer.id,
        },
        {
          name: 'Sarah Connor',
          email: 'sarah@cyberdyne.io',
          phone: '+94 71 987 6543',
          service: 'AI & Workflow Automation',
          message: 'Looking for AI workflow automation for automated document processing and invoice extraction.',
          status: 'IN_PROGRESS',
          assignedToId: employee.id,
          createdBy: customer.id,
        },
      ],
    });
    console.log('Sample Contact Submissions created!');
  }

  // 6. Seed Job Openings for Careers Portal
  const seedJobs = [
    {
      id: 'fullstack-nextjs',
      title: 'Senior Full-Stack Next.js Developer',
      department: 'engineering',
      location: 'Remote / Colombo',
      type: 'Full-Time',
      salary: 'LKR 250,000 - 400,000 / mo',
      badge: 'Urgent Hiring',
      description: 'We are seeking an experienced Full-Stack Engineer skilled in Next.js 16, TypeScript, React 19, and Node.js REST/GraphQL APIs to build enterprise SaaS & ERP platforms.',
      requirements: JSON.stringify([
        '3+ years experience with Next.js, React, and TypeScript',
        'Strong expertise in MySQL / PostgreSQL relational databases & Prisma ORM',
        'Experience building RESTful APIs & Microservices architecture',
        'Familiarity with Tailwind CSS, Serverless deployment, and AWS/Docker'
      ]),
      responsibilities: JSON.stringify([
        'Architect and build high-speed enterprise Web & ERP applications',
        'Collaborate with UI/UX designers and backend engineers',
        'Optimize database queries and system performance for 99.9% uptime'
      ]),
      status: 'ACTIVE',
    },
    {
      id: 'mobile-dev',
      title: 'Mobile Application Developer (Flutter / React Native)',
      department: 'engineering',
      location: 'Hybrid (Colombo / Remote)',
      type: 'Full-Time',
      salary: 'LKR 200,000 - 350,000 / mo',
      badge: 'Featured',
      description: 'Join our mobile team to craft fluid, cross-platform Android & iOS applications using Flutter or React Native with offline sync capabilities.',
      requirements: JSON.stringify([
        '2+ years experience building mobile apps with Flutter or React Native',
        'Experience with state management (Bloc, Provider, Redux, Zustand)',
        'Understanding of REST APIs, WebSockets, and Push Notifications',
        'Published apps on Google Play Store or Apple App Store'
      ]),
      responsibilities: JSON.stringify([
        'Develop pixel-perfect mobile interfaces with 60 FPS animations',
        'Integrate biometric security, local SQLite caching, and push alerts',
        'Maintain continuous CI/CD build deployments'
      ]),
      status: 'ACTIVE',
    },
    {
      id: 'erp-architect',
      title: 'Enterprise ERP Solutions Engineer',
      department: 'product',
      location: 'Colombo Tech Hub',
      type: 'Full-Time',
      salary: 'LKR 300,000 - 500,000 / mo',
      badge: 'Enterprise Core',
      description: 'Lead the architecture and implementation of HKRION POS, ERP, and HRM inventory systems for enterprise retail & logistics clients.',
      requirements: JSON.stringify([
        '4+ years in software engineering & enterprise business logic',
        'Deep knowledge of MySQL database indexing, ACID transactions, & security',
        'Experience with HR payroll, attendance telemetry, & inventory workflows'
      ]),
      responsibilities: JSON.stringify([
        'Design modular ERP schemas and automated financial reporting engines',
        'Conduct client technical audits and customize ERP modules',
        'Manage database backups, migration scripts, and zero-downtime releases'
      ]),
      status: 'ACTIVE',
    },
    {
      id: 'ui-ux-designer',
      title: 'UI/UX & Product Designer',
      department: 'design',
      location: 'Hybrid / Remote',
      type: 'Full-Time',
      salary: 'LKR 180,000 - 300,000 / mo',
      badge: 'Creative Team',
      description: 'Design intuitive wireframes, glassmorphic UI design systems, and interactive prototypes in Figma for web apps, ERP dashboards, and mobile apps.',
      requirements: JSON.stringify([
        'Proficiency in Figma, design systems, wireframing, & interactive prototyping',
        'Strong eye for modern dark modes, micro-interactions, & typography',
        'Basic understanding of HTML/CSS capabilities to work with developers'
      ]),
      responsibilities: JSON.stringify([
        'Create high-fidelity visual mockups & reusable component libraries',
        'Conduct user research and simplify complex ERP workflows',
        'Export production-ready assets and design specs'
      ]),
      status: 'ACTIVE',
    },
    {
      id: 'iot-engineer',
      title: 'IoT & Hardware Automation Engineer',
      department: 'engineering',
      location: 'Hybrid / Tech Hub',
      type: 'Full-Time',
      salary: 'LKR 220,000 - 380,000 / mo',
      badge: 'Hardware & Telemetry',
      description: 'Build low-latency MQTT/WebSocket hardware telemetry bridges connecting smart sensors, micro-controllers, and cloud monitoring dashboards.',
      requirements: JSON.stringify([
        'Experience with IoT micro-controllers (ESP32, Raspberry Pi, Arduino)',
        'Knowledge of MQTT, WebSockets, Modbus, and Serial RS485 communication',
        'Proficiency in Node.js, C/C++, or Python for telemetry parsing'
      ]),
      responsibilities: JSON.stringify([
        'Integrate industrial smart sensors with cloud database vaults',
        'Develop real-time threshold alert & remote relay control scripts',
        'Perform hardware testing and gateway deployment'
      ]),
      status: 'ACTIVE',
    },
    {
      id: 'intern-engineer',
      title: 'Software Engineering Intern (Web / Mobile / IoT)',
      department: 'internship',
      location: 'Hybrid / Remote',
      type: 'Internship (6 Months)',
      salary: 'LKR 50,000 - 80,000 / mo',
      badge: 'Growth Program',
      description: 'A paid 6-month intensive internship program for passionate undergraduates or fresh graduates looking to master Next.js, Node.js, and Cloud development.',
      requirements: JSON.stringify([
        'Undergraduate or recent graduate in Computer Science, IT, or Software Engineering',
        'Good foundational knowledge of JavaScript, React, or Python',
        'Enthusiasm to learn enterprise code standards, Git workflow, & Next.js 16'
      ]),
      responsibilities: JSON.stringify([
        'Assist senior engineers in building production components',
        'Write clean, unit-tested code and documentation',
        'Participate in daily agile standups and code reviews'
      ]),
      status: 'ACTIVE',
    }
  ];

  for (const j of seedJobs) {
    await prisma.$executeRaw`
      INSERT INTO JobPosting (id, title, department, location, type, salary, badge, description, requirements, responsibilities, status, createdBy, updatedBy, createdAt, updatedAt)
      VALUES (${j.id}, ${j.title}, ${j.department}, ${j.location}, ${j.type}, ${j.salary}, ${j.badge}, ${j.description}, ${j.requirements}, ${j.responsibilities}, ${j.status}, 'system-seed', 'system-seed', NOW(), NOW())
      ON DUPLICATE KEY UPDATE title = ${j.title}, salary = ${j.salary}, updatedBy = 'system-seed', updatedAt = NOW()
    `;
  }
  console.log('Sample Job Openings seeded!');

  console.log('Database Seeding Complete with RBAC, Job Openings, createdBy and updatedBy audit fields!');
}

main()
  .catch((e) => {
    console.error('Seeding error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
