#!/usr/bin/env node

/**
 * detect-hardcoded.mjs
 * Fast audit script to detect hardcoded values across the Faizan Gems codebase.
 * Usage:
 *   node .agents/skills/clean-hardcoded/scripts/detect-hardcoded.mjs [--json] [--summary] [--category=<cat>]
 */

import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECT_ROOT = path.resolve(__dirname, "../../../../");

const IGNORE_DIRS = new Set([
  "node_modules",
  ".next",
  ".git",
  "dist",
  "build",
  "backups",
  "private_uploads",
  "public",
  ".agents",
]);

const ALLOWED_EXTENSIONS = new Set([
  ".ts",
  ".tsx",
  ".js",
  ".jsx",
  ".mjs",
  ".json",
]);

// Ignored files (e.g. documentation, constants definitions themselves, lockfiles)
const IGNORE_FILES = new Set([
  "package-lock.json",
  "pnpm-lock.yaml",
  "skills-lock.json",
  "tsconfig.tsbuildinfo",
  "site.ts",      // central constants definition
  "districts.ts", // central data definition
  "storage.ts",   // central storage keys definition
  "promo.ts",     // central promo codes definition
]);

const AUDIT_RULES = [
  {
    id: "phone-numbers",
    category: "contact",
    name: "Hardcoded Phone Number",
    regex: /(\+94\s*7[0-9]\s*[0-9]{3,4}\s*[0-9]{3,4}|07[0-9]\s*[0-9]{3}\s*[0-9]{4})/g,
    destination: "SITE_CONFIG.phone or SITE_CONFIG.secondaryPhone (src/lib/constants/site.ts)",
    // Allow matches if importing or referencing SITE_CONFIG or in definition files
    filter: (line, filePath) => !line.includes("SITE_CONFIG") && !filePath.endsWith("site.ts"),
  },
  {
    id: "company-emails",
    category: "contact",
    name: "Hardcoded Company Email",
    regex: /(faizangems2025@gmail\.com|admin@faizangems\.com)/g,
    destination: "SITE_CONFIG.email or process.env.ADMIN_EMAIL",
    filter: (line, filePath) => !line.includes("SITE_CONFIG") && !filePath.endsWith("site.ts") && !filePath.endsWith(".env.example"),
  },
  {
    id: "banking-details",
    category: "banking",
    name: "Hardcoded Bank Account / SWIFT",
    regex: /(100048299104|COMBCEKLXXX|Commercial Bank of Ceylon)/g,
    destination: "SITE_CONFIG.banking.* (src/lib/constants/site.ts)",
    filter: (line, filePath) => !line.includes("SITE_CONFIG") && !filePath.endsWith("site.ts"),
  },
  {
    id: "legacy-storage-keys",
    category: "storage",
    name: "Hardcoded Storage Key (maison_*)",
    regex: /(maison_cart|maison_vault_wishlist|maison_currency)/g,
    destination: "STORAGE_KEYS.* (src/lib/constants/storage.ts)",
    filter: (line, filePath) => !filePath.endsWith("storage.ts"),
  },
  {
    id: "promo-codes",
    category: "promo",
    name: "Hardcoded Promo Code Literal",
    regex: /"(FAIZAN5|VAULT|MAISON5)"/g,
    destination: "PROMO_CODES in src/lib/constants/promo.ts",
    filter: (line, filePath) => !filePath.endsWith("promo.ts"),
  },
  {
    id: "hardcoded-districts-array",
    category: "data",
    name: "Inline Districts Array Declaration",
    regex: /const SRI_LANKA_DISTRICTS\s*=\s*\[/g,
    destination: "SRI_LANKA_DISTRICTS in src/lib/data/districts.ts",
    filter: (line, filePath) => !filePath.endsWith("districts.ts"),
  },
  {
    id: "localhost-urls",
    category: "urls",
    name: "Hardcoded Localhost URL",
    regex: /https?:\/\/127\.0\.0\.1:\d+|https?:\/\/localhost:\d+/g,
    destination: "process.env.NEXTAUTH_URL || process.env.NEXT_PUBLIC_APP_URL",
    filter: (line) => !line.includes("process.env"),
  },
  {
    id: "magic-exchange-rate",
    category: "data",
    name: "Hardcoded Currency Exchange Rate",
    regex: /\/\s*300\b/g,
    destination: "DEFAULT_LKR_RATE in src/lib/constants/site.ts",
    filter: (line, filePath) => filePath.includes("clients-db.ts"),
  },
];

function walkDir(dirPath, fileList = []) {
  const entries = fs.readdirSync(dirPath, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);
    if (entry.isDirectory()) {
      if (!IGNORE_DIRS.has(entry.name)) {
        walkDir(fullPath, fileList);
      }
    } else if (entry.isFile()) {
      const ext = path.extname(entry.name);
      if (ALLOWED_EXTENSIONS.has(ext) && !IGNORE_FILES.has(entry.name)) {
        fileList.push(fullPath);
      }
    }
  }
  return fileList;
}

function scanFile(filePath, results) {
  let content;
  try {
    content = fs.readFileSync(filePath, "utf-8");
  } catch {
    return;
  }

  const lines = content.split("\n");
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const lineNumber = i + 1;

    for (const rule of AUDIT_RULES) {
      rule.regex.lastIndex = 0;
      let match;
      while ((match = rule.regex.exec(line)) !== null) {
        if (!rule.filter || rule.filter(line, filePath, match)) {
          results.push({
            ruleId: rule.id,
            category: rule.category,
            ruleName: rule.name,
            match: match[0],
            file: path.relative(PROJECT_ROOT, filePath),
            fullPath: filePath,
            line: lineNumber,
            snippet: line.trim(),
            destination: rule.destination,
          });
        }
      }
    }
  }
}

function main() {
  const args = process.argv.slice(2);
  const isJson = args.includes("--json");
  const isSummary = args.includes("--summary");
  const categoryArg = args.find((a) => a.startsWith("--category="));
  const categoryFilter = categoryArg ? categoryArg.split("=")[1] : null;

  const targetDirs = [path.join(PROJECT_ROOT, "src"), path.join(PROJECT_ROOT, "prisma")];
  const filesToScan = [];

  for (const dir of targetDirs) {
    if (fs.existsSync(dir)) {
      walkDir(dir, filesToScan);
    }
  }

  const results = [];
  for (const file of filesToScan) {
    scanFile(file, results);
  }

  const filtered = categoryFilter
    ? results.filter((r) => r.category.toLowerCase() === categoryFilter.toLowerCase())
    : results;

  if (isJson) {
    console.log(JSON.stringify(filtered, null, 2));
    process.exit(filtered.length > 0 ? 1 : 0);
  }

  console.log("\n==================================================");
  console.log("💎 Faizan Gems — Hardcoded Values Audit");
  console.log("==================================================");
  console.log(`Scanned ${filesToScan.length} source files.`);

  if (filtered.length === 0) {
    console.log("\n✅ Clean! No hardcoded anti-patterns found.\n");
    process.exit(0);
  }

  console.log(`Found ${filtered.length} hardcoded instances:\n`);

  // Group by category
  const groups = {};
  for (const r of filtered) {
    groups[r.category] = groups[r.category] || [];
    groups[r.category].push(r);
  }

  for (const [cat, items] of Object.entries(groups)) {
    console.log(`\n📌 Category: [${cat.toUpperCase()}] (${items.length} items)`);
    console.log("--------------------------------------------------");
    for (const item of items) {
      console.log(`  • ${item.ruleName}: "${item.match}"`);
      console.log(`    Location: ${item.file}:${item.line}`);
      console.log(`    Snippet:  ${item.snippet}`);
      console.log(`    Target:   → ${item.destination}\n`);
    }
  }

  if (isSummary) {
    console.log("\n--- Summary Count by Category ---");
    for (const [cat, items] of Object.entries(groups)) {
      console.log(`  ${cat}: ${items.length}`);
    }
    console.log("----------------------------------");
  }

  process.exit(filtered.length > 0 ? 1 : 0);
}

main();
