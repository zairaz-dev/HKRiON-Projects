import pool from "@/lib/db";
import { RowDataPacket } from "mysql2";

export interface CustomerAddress {
  id: string;
  userId: string;
  userEmail: string;
  fullName: string;
  phone: string;
  address: string;
  city: string;
  district: string;
  postalCode: string;
  country: string;
  isDefault: boolean;
  createdAt?: string;
}

/**
 * Ensure customer_addresses table exists in MySQL
 */
export async function initAddressTable(): Promise<void> {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS customer_addresses (
        id VARCHAR(64) PRIMARY KEY,
        user_id VARCHAR(64) NOT NULL,
        user_email VARCHAR(255) NOT NULL,
        full_name VARCHAR(150),
        phone VARCHAR(50),
        address VARCHAR(255) NOT NULL,
        city VARCHAR(100) NOT NULL,
        district VARCHAR(100) NOT NULL,
        postal_code VARCHAR(50) NOT NULL,
        country VARCHAR(100) NOT NULL DEFAULT 'Sri Lanka',
        is_default BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_user_email (user_email),
        INDEX idx_user_id (user_id)
      )
    `);
  } catch (error) {
    console.error("Error initializing customer_addresses table:", error);
  }
}

/**
 * Get all saved addresses for a customer by email.
 * If none found in customer_addresses, attempts to import from most recent order.
 */
export async function getCustomerAddresses(
  email: string,
  userId?: string
): Promise<CustomerAddress[]> {
  await initAddressTable();
  try {
    const [rows] = await pool.query<RowDataPacket[]>(
      `SELECT id, user_id, user_email, full_name, phone, address, city, district, postal_code, country, is_default, created_at
       FROM customer_addresses
       WHERE user_email = ?
       ORDER BY is_default DESC, created_at DESC`,
      [email]
    );

    if (rows && rows.length > 0) {
      return rows.map((r) => ({
        id: r.id,
        userId: r.user_id,
        userEmail: r.user_email,
        fullName: r.full_name || "",
        phone: r.phone || "",
        address: r.address,
        city: r.city,
        district: r.district,
        postalCode: r.postal_code,
        country: r.country || "Sri Lanka",
        isDefault: Boolean(r.is_default),
        createdAt: r.created_at ? new Date(r.created_at).toISOString() : undefined,
      }));
    }

    // Fallback: Check past orders for this customer to auto-import their last used address
    const [orderRows] = await pool.query<RowDataPacket[]>(
      `SELECT client_name, client_phone, shipping_address, city, state, postal_code, country
       FROM orders
       WHERE client_email = ? AND shipping_address IS NOT NULL AND shipping_address != ''
       ORDER BY created_at DESC
       LIMIT 1`,
      [email]
    );

    if (orderRows && orderRows.length > 0) {
      const o = orderRows[0];
      const importedId = `addr-${Date.now()}`;
      const newAddress: CustomerAddress = {
        id: importedId,
        userId: userId || email,
        userEmail: email,
        fullName: o.client_name || "",
        phone: o.client_phone || "",
        address: o.shipping_address,
        city: o.city || "",
        district: o.state || "Colombo",
        postalCode: o.postal_code || "",
        country: o.country || "Sri Lanka",
        isDefault: true,
      };

      await saveCustomerAddress(newAddress);
      return [newAddress];
    }

    return [];
  } catch (error) {
    console.error("Error fetching customer addresses:", error);
    return [];
  }
}

/**
 * Save or update a customer address
 */
export async function saveCustomerAddress(
  addr: Partial<CustomerAddress> & { userEmail: string; address: string; city: string; district: string }
): Promise<CustomerAddress | null> {
  await initAddressTable();
  try {
    // Check if the exact same street address already exists for this user
    const [existing] = await pool.query<RowDataPacket[]>(
      `SELECT id FROM customer_addresses WHERE user_email = ? AND address = ? LIMIT 1`,
      [addr.userEmail, addr.address]
    );

    if (existing && existing.length > 0) {
      const existingId = existing[0].id;
      await pool.query(
        `UPDATE customer_addresses
         SET full_name = COALESCE(?, full_name),
             phone = COALESCE(?, phone),
             city = ?,
             district = ?,
             postal_code = ?,
             country = COALESCE(?, country)
         WHERE id = ?`,
        [
          addr.fullName || null,
          addr.phone || null,
          addr.city,
          addr.district,
          addr.postalCode || "",
          addr.country || "Sri Lanka",
          existingId,
        ]
      );

      return {
        id: existingId,
        userId: addr.userId || addr.userEmail,
        userEmail: addr.userEmail,
        fullName: addr.fullName || "",
        phone: addr.phone || "",
        address: addr.address,
        city: addr.city,
        district: addr.district,
        postalCode: addr.postalCode || "",
        country: addr.country || "Sri Lanka",
        isDefault: Boolean(addr.isDefault),
      };
    }

    // Insert new address
    const newId = addr.id || `addr-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const [countRows] = await pool.query<RowDataPacket[]>(
      `SELECT COUNT(*) as cnt FROM customer_addresses WHERE user_email = ?`,
      [addr.userEmail]
    );
    const isFirst = (countRows[0]?.cnt || 0) === 0;
    const isDefault = addr.isDefault !== undefined ? addr.isDefault : isFirst;

    await pool.query(
      `INSERT INTO customer_addresses (
        id, user_id, user_email, full_name, phone, address, city, district, postal_code, country, is_default
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        newId,
        addr.userId || addr.userEmail,
        addr.userEmail,
        addr.fullName || "",
        addr.phone || "",
        addr.address,
        addr.city,
        addr.district,
        addr.postalCode || "",
        addr.country || "Sri Lanka",
        isDefault,
      ]
    );

    return {
      id: newId,
      userId: addr.userId || addr.userEmail,
      userEmail: addr.userEmail,
      fullName: addr.fullName || "",
      phone: addr.phone || "",
      address: addr.address,
      city: addr.city,
      district: addr.district,
      postalCode: addr.postalCode || "",
      country: addr.country || "Sri Lanka",
      isDefault,
    };
  } catch (error) {
    console.error("Error saving customer address:", error);
    return null;
  }
}

/**
 * Update an existing customer address by ID and user email.
 */
export async function updateCustomerAddress(
  id: string,
  email: string,
  updates: Partial<CustomerAddress>
): Promise<CustomerAddress | null> {
  await initAddressTable();
  try {
    const fields: string[] = [];
    const values: any[] = [];

    if (updates.fullName !== undefined) {
      fields.push("full_name = ?");
      values.push(updates.fullName);
    }
    if (updates.phone !== undefined) {
      fields.push("phone = ?");
      values.push(updates.phone);
    }
    if (updates.address !== undefined) {
      fields.push("address = ?");
      values.push(updates.address.trim());
    }
    if (updates.city !== undefined) {
      fields.push("city = ?");
      values.push(updates.city.trim());
    }
    if (updates.district !== undefined) {
      fields.push("district = ?");
      values.push(updates.district.trim());
    }
    if (updates.postalCode !== undefined) {
      fields.push("postal_code = ?");
      values.push(updates.postalCode.trim());
    }
    if (updates.country !== undefined) {
      fields.push("country = ?");
      values.push(updates.country.trim());
    }
    if (updates.isDefault !== undefined) {
      fields.push("is_default = ?");
      values.push(Boolean(updates.isDefault));
    }

    if (fields.length === 0) {
      return null;
    }

    values.push(id, email);
    await pool.query(
      `UPDATE customer_addresses SET ${fields.join(", ")} WHERE id = ? AND user_email = ?`,
      values
    );

    const [rows] = await pool.query<RowDataPacket[]>(
      `SELECT id, user_id, user_email, full_name, phone, address, city, district, postal_code, country, is_default, created_at
       FROM customer_addresses WHERE id = ? AND user_email = ? LIMIT 1`,
      [id, email]
    );

    if (rows && rows.length > 0) {
      const r = rows[0];
      return {
        id: r.id,
        userId: r.user_id,
        userEmail: r.user_email,
        fullName: r.full_name || "",
        phone: r.phone || "",
        address: r.address,
        city: r.city,
        district: r.district,
        postalCode: r.postal_code,
        country: r.country || "Sri Lanka",
        isDefault: Boolean(r.is_default),
        createdAt: r.created_at ? new Date(r.created_at).toISOString() : undefined,
      };
    }
    return null;
  } catch (error) {
    console.error("Error updating customer address:", error);
    return null;
  }
}

/**
 * Delete a customer address by ID and user email.
 */
export async function deleteCustomerAddress(id: string, email: string): Promise<boolean> {
  await initAddressTable();
  try {
    await pool.query(
      `DELETE FROM customer_addresses WHERE id = ? AND user_email = ?`,
      [id, email]
    );
    return true;
  } catch (error) {
    console.error("Error deleting customer address:", error);
    return false;
  }
}

