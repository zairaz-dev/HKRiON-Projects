'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import DashboardSidebar from '@/components/DashboardSidebar';
import {
  Briefcase,
  Search,
  RefreshCw,
  Download,
  Trash2,
  Mail,
  Phone,
  Calendar,
  ExternalLink,
  CheckCircle,
  Clock,
  AlertCircle,
  FileText,
  X,
  UserCheck,
  Sparkles
} from 'lucide-react';

interface JobApplicationItem {
  id: string;
  jobId: string;
  jobTitle: string;
  fullName: string;
  email: string;
  phone: string;
  experience: string;
  portfolioUrl: string | null;
  resumeUrl: string;
  coverNote: string | null;
  status: string;
  createdAt: string;
}

export default function AdminCareersPage() {
  const router = useRouter();
  const [applications, setApplications] = useState<JobApplicationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  // Selected Cover Note Modal
  const [viewingApp, setViewingApp] = useState<JobApplicationItem | null>(null);

  // Delete Confirmation Modal
  const [deletingApp, setDeletingApp] = useState<JobApplicationItem | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Toast
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  const fetchApplications = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/careers/applications');
      if (res.status === 401 || res.status === 403) {
        router.push('/login');
        return;
      }
      const data = await res.json();
      if (data.applications) {
        setApplications(data.applications);
      }
    } catch (err) {
      console.error('Error fetching applications:', err);
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    fetchApplications();
  }, [fetchApplications]);

  const handleStatusChange = async (id: string, newStatus: string) => {
    setUpdatingId(id);
    try {
      const res = await fetch('/api/admin/careers/applications', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status: newStatus }),
      });

      if (res.ok) {
        setApplications((prev) =>
          prev.map((app) => (app.id === id ? { ...app, status: newStatus } : app))
        );
        showToast(`Candidate status updated to ${newStatus}`);
      } else {
        showToast('Failed to update status', 'error');
      }
    } catch {
      showToast('Error updating status', 'error');
    } finally {
      setUpdatingId(null);
    }
  };

  const handleDeleteApplication = async () => {
    if (!deletingApp) return;
    setSubmitting(true);
    try {
      const res = await fetch(`/api/admin/careers/applications?id=${deletingApp.id}`, {
        method: 'DELETE',
      });

      if (res.ok) {
        setDeletingApp(null);
        showToast('Application deleted successfully');
        fetchApplications();
      } else {
        showToast('Failed to delete application', 'error');
      }
    } catch {
      showToast('Error deleting application', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const filteredApplications = applications.filter((app) => {
    const matchesSearch =
      app.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.jobTitle.toLowerCase().includes(searchTerm.toLowerCase());

    if (statusFilter === 'ALL') return matchesSearch;
    return matchesSearch && app.status.toUpperCase() === statusFilter.toUpperCase();
  });

  const totalCount = applications.length;
  const pendingCount = applications.filter((a) => a.status.toUpperCase() === 'PENDING').length;
  const shortlistedCount = applications.filter((a) => a.status.toUpperCase() === 'SHORTLISTED').length;
  const hiredCount = applications.filter((a) => a.status.toUpperCase() === 'HIRED').length;

  return (
    <div className="min-h-screen bg-black text-white radial-bg flex">
      {/* Sidebar */}
      <DashboardSidebar
        userRole="ADMIN"
        userName="HKRION Admin"
        userEmail="admin@hkrion.com"
        activeTab="careers"
      />

      {/* Main Area */}
      <div className="flex-1 lg:ml-64 flex flex-col min-w-0 min-h-screen">
        {/* Toast */}
        {toastMessage && (
          <div
            className={`fixed top-5 right-5 z-50 px-4 py-3 rounded-xl border flex items-center gap-3 shadow-2xl backdrop-blur-md animate-fade-in ${
              toastMessage.type === 'success'
                ? 'bg-emerald-950/90 border-emerald-500/50 text-emerald-300'
                : 'bg-red-950/90 border-red-500/50 text-red-300'
            }`}
          >
            {toastMessage.type === 'success' ? (
              <CheckCircle className="w-5 h-5 text-emerald-400" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-400" />
            )}
            <span className="text-xs font-semibold">{toastMessage.text}</span>
          </div>
        )}

        {/* Top Navbar Header */}
        <header className="border-b border-[#1ABE56]/20 bg-black/80 backdrop-blur-md sticky top-0 z-30 px-6 py-4 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold font-mono tracking-wide text-white flex items-center gap-2">
              <Briefcase className="w-6 h-6 text-[#1ABE56]" />
              Careers & <span className="text-[#1ABE56]">Job Applications Console</span>
            </h1>
            <p className="text-xs text-neutral-400">
              Review candidate resumes, portfolio links, and manage recruitment pipeline
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={fetchApplications}
              className="px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-[#1ABE56]/40 text-neutral-300 hover:text-white text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-[#1ABE56]' : ''}`} />
              Refresh
            </button>
          </div>
        </header>

        {/* Dashboard Main View */}
        <main className="p-6 sm:p-8 space-y-8 flex-1">
          {/* Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="glass-card p-5 rounded-2xl border border-[#1ABE56]/30 bg-black/80 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-[#1ABE56]/20 flex items-center justify-center shrink-0">
                <FileText className="w-6 h-6 text-[#1ABE56]" />
              </div>
              <div>
                <p className="text-xs font-mono uppercase text-neutral-400">Total Applicants</p>
                <h3 className="text-2xl font-bold text-white">{totalCount}</h3>
              </div>
            </div>

            <div className="glass-card p-5 rounded-2xl border border-yellow-500/30 bg-black/80 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-yellow-500/20 flex items-center justify-center shrink-0">
                <Clock className="w-6 h-6 text-yellow-400" />
              </div>
              <div>
                <p className="text-xs font-mono uppercase text-neutral-400">Pending Review</p>
                <h3 className="text-2xl font-bold text-white">{pendingCount}</h3>
              </div>
            </div>

            <div className="glass-card p-5 rounded-2xl border border-blue-500/30 bg-black/80 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center shrink-0">
                <Sparkles className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <p className="text-xs font-mono uppercase text-neutral-400">Shortlisted</p>
                <h3 className="text-2xl font-bold text-white">{shortlistedCount}</h3>
              </div>
            </div>

            <div className="glass-card p-5 rounded-2xl border border-emerald-500/30 bg-black/80 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center shrink-0">
                <UserCheck className="w-6 h-6 text-emerald-400" />
              </div>
              <div>
                <p className="text-xs font-mono uppercase text-neutral-400">Hired Candidates</p>
                <h3 className="text-2xl font-bold text-white">{hiredCount}</h3>
              </div>
            </div>
          </div>

          {/* Search & Filter */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
              <div className="relative w-full sm:w-80">
                <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  placeholder="Search candidate name, email, or role..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-500 focus:outline-none focus:border-[#1ABE56] text-xs transition-colors"
                />
              </div>

              {/* Status filter tabs */}
              <div className="flex items-center p-1 rounded-xl bg-neutral-900 border border-neutral-800 text-xs">
                {['ALL', 'PENDING', 'SHORTLISTED', 'HIRED', 'REJECTED'].map((st) => (
                  <button
                    key={st}
                    onClick={() => setStatusFilter(st)}
                    className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                      statusFilter === st
                        ? 'bg-[#1ABE56]/20 text-[#1ABE56] font-semibold border border-[#1ABE56]/40'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            <div className="text-xs text-neutral-400 font-mono">
              Showing {filteredApplications.length} of {applications.length} Submissions
            </div>
          </div>

          {/* Applications Table */}
          <div className="glass-card rounded-2xl border border-[#1ABE56]/20 bg-black/90 overflow-hidden shadow-2xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-900/90 text-neutral-400 uppercase font-mono border-b border-neutral-800">
                  <tr>
                    <th className="px-6 py-4">Candidate & Contact</th>
                    <th className="px-6 py-4">Target Job Opening</th>
                    <th className="px-6 py-4">Experience</th>
                    <th className="px-6 py-4">Resume & Portfolio</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800/60">
                  {filteredApplications.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-12 text-center text-neutral-500">
                        No candidate applications found matching &quot;{searchTerm}&quot;.
                      </td>
                    </tr>
                  ) : (
                    filteredApplications.map((app) => (
                      <tr key={app.id} className="hover:bg-neutral-900/40 transition-colors">
                        {/* Candidate Identity */}
                        <td className="px-6 py-4">
                          <div className="font-semibold text-white">{app.fullName}</div>
                          <div className="text-neutral-400 font-mono flex items-center gap-1">
                            <Mail className="w-3 h-3 text-neutral-500" />
                            <span>{app.email}</span>
                          </div>
                          <div className="text-neutral-500 font-mono flex items-center gap-1">
                            <Phone className="w-3 h-3 text-neutral-600" />
                            <span>{app.phone}</span>
                          </div>
                        </td>

                        {/* Job Title */}
                        <td className="px-6 py-4">
                          <span className="px-2.5 py-1 rounded-lg bg-[#1ABE56]/10 text-[#1ABE56] font-medium border border-[#1ABE56]/30">
                            {app.jobTitle}
                          </span>
                        </td>

                        {/* Experience */}
                        <td className="px-6 py-4 font-mono text-neutral-300">
                          {app.experience}
                        </td>

                        {/* Resume & Portfolio */}
                        <td className="px-6 py-4">
                          <div className="flex flex-col gap-1.5">
                            <a
                              href={app.resumeUrl}
                              download
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-2.5 py-1 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 hover:border-[#1ABE56]/40 text-neutral-300 hover:text-white font-mono text-[11px] inline-flex items-center gap-1.5 w-max transition-colors"
                            >
                              <Download className="w-3.5 h-3.5 text-[#1ABE56]" />
                              Download Resume
                            </a>

                            {app.portfolioUrl && (
                              <a
                                href={app.portfolioUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-[11px] font-mono text-blue-400 hover:underline flex items-center gap-1"
                              >
                                <ExternalLink className="w-3 h-3" />
                                Portfolio Link
                              </a>
                            )}
                          </div>
                        </td>

                        {/* Status Dropdown */}
                        <td className="px-6 py-4">
                          <select
                            value={app.status}
                            disabled={updatingId === app.id}
                            onChange={(e) => handleStatusChange(app.id, e.target.value)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-semibold border bg-black focus:outline-none transition-colors cursor-pointer ${
                              app.status === 'HIRED'
                                ? 'border-emerald-500/50 text-emerald-400 bg-emerald-500/10'
                                : app.status === 'SHORTLISTED'
                                ? 'border-blue-500/50 text-blue-400 bg-blue-500/10'
                                : app.status === 'REJECTED'
                                ? 'border-red-500/50 text-red-400 bg-red-500/10'
                                : 'border-yellow-500/50 text-yellow-400 bg-yellow-500/10'
                            }`}
                          >
                            <option value="PENDING">PENDING</option>
                            <option value="SHORTLISTED">SHORTLISTED</option>
                            <option value="HIRED">HIRED</option>
                            <option value="REJECTED">REJECTED</option>
                          </select>
                        </td>

                        {/* Actions */}
                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            {app.coverNote && (
                              <button
                                onClick={() => setViewingApp(app)}
                                className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white transition-colors cursor-pointer"
                                title="View Cover Note"
                              >
                                <FileText className="w-4 h-4 text-[#1ABE56]" />
                              </button>
                            )}

                            <button
                              onClick={() => setDeletingApp(app)}
                              className="p-2 rounded-xl bg-neutral-900 hover:bg-red-950/60 border border-neutral-800 hover:border-red-500/40 text-neutral-400 hover:text-red-400 transition-colors cursor-pointer"
                              title="Delete Application"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>

      {/* VIEW COVER NOTE MODAL */}
      {viewingApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="bg-neutral-950 border border-[#1ABE56]/40 rounded-2xl w-full max-w-lg p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-900 pb-4">
              <div>
                <h3 className="text-base font-bold text-white font-mono">
                  Candidate Note: {viewingApp.fullName}
                </h3>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Applied for {viewingApp.jobTitle}
                </p>
              </div>
              <button
                onClick={() => setViewingApp(null)}
                className="p-2 rounded-xl text-neutral-400 hover:text-white bg-neutral-900 border border-neutral-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 rounded-xl bg-neutral-900/80 border border-neutral-800 text-xs text-neutral-300 leading-relaxed font-mono whitespace-pre-wrap">
              {viewingApp.coverNote || 'No cover note provided by candidate.'}
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <a
                href={viewingApp.resumeUrl}
                download
                target="_blank"
                rel="noopener noreferrer"
                className="glow-btn px-4 py-2 rounded-xl text-xs font-semibold text-white flex items-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download Resume</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {deletingApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="bg-neutral-950 border border-red-500/40 rounded-2xl w-full max-w-md p-6 space-y-6 shadow-2xl">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-red-950/80 border border-red-500/40 flex items-center justify-center shrink-0">
                <AlertCircle className="w-6 h-6 text-red-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-mono">
                  Delete Application from &quot;{deletingApp.fullName}&quot;?
                </h3>
                <p className="text-xs text-neutral-400 mt-1">
                  This action is permanent and will remove candidate record from database.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setDeletingApp(null)}
                className="px-4 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteApplication}
                disabled={submitting}
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-semibold flex items-center gap-2 cursor-pointer disabled:opacity-60"
              >
                {submitting && <RefreshCw className="w-4 h-4 animate-spin" />}
                <span>Confirm Delete</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
