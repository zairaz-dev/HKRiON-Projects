import { Injectable, InternalServerErrorException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { UpdateSuperSettingsDto } from './dto/update-super-settings.dto';
import { TestEmailDto } from './dto/test-email.dto';
import { TestSmsDto } from './dto/test-sms.dto';
import { TestAiDto } from './dto/test-ai.dto';
import * as nodemailer from 'nodemailer';

@Injectable()
export class SuperSettingsService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Fetch current global platform settings or create initial defaults
   */
  async getSettings() {
    let settings = await this.prisma.superPlatformSetting.findFirst();
    if (!settings) {
      settings = await this.prisma.superPlatformSetting.create({
        data: {
          platformName: 'HKRION ERP Suite',
          tagline: 'Enterprise Multi-Tenant Cloud ERP',
          supportEmail: 'support@hkrion.com',
          supportPhone: '+94 77 123 4567',
          supportWhatsapp: '+94 77 123 4567',
          defaultCurrency: 'LKR',
          defaultTimezone: 'Asia/Colombo',
          defaultTrialDays: 14,
          subscriptionTaxRate: 18.0,
          payhereMerchantId: '1230179',
          payhereMerchantSecret: 'ODk1MjE0NzUzMzk3MjYzODk1MTE2MTA3MjUxOTQxOTg0NDYxMDc0',
          payhereMode: 'sandbox',
          smtpHost: 'smtp.gmail.com',
          smtpPort: 587,
          smtpSecure: false,
          smtpUser: '',
          smtpPass: '',
          smtpFromEmail: 'noreply@hkrion.com',
          smtpFromName: 'HKRION Cloud ERP',
          notifyOnNewTenant: true,
          notifyOnBankTransfer: true,
          notifyOnSubExpiry: true,
          smsProvider: 'custom_http',
          smsApiKey: '',
          smsSenderId: 'HKRION',
          smsApiUrl: '',
          maintenanceMode: false,
          maintenanceMessage: 'System is currently undergoing scheduled maintenance. Please check back shortly.',
          allowPublicSignups: true,
          enableGoogleAuth: true,
        },
      });
    }
    return settings;
  }

  /**
   * Update global platform settings
   */
  async updateSettings(dto: UpdateSuperSettingsDto) {
    const existing = await this.getSettings();
    return this.prisma.superPlatformSetting.update({
      where: { id: existing.id },
      data: dto,
    });
  }

  /**
   * Public info for platform branding and maintenance status
   */
  async getPublicPlatformInfo() {
    const settings = await this.getSettings();
    return {
      platformName: settings.platformName,
      tagline: settings.tagline,
      supportEmail: settings.supportEmail,
      supportPhone: settings.supportPhone,
      supportWhatsapp: settings.supportWhatsapp,
      defaultCurrency: settings.defaultCurrency,
      defaultTrialDays: settings.defaultTrialDays,
      maintenanceMode: settings.maintenanceMode,
      maintenanceMessage: settings.maintenanceMessage,
      allowPublicSignups: settings.allowPublicSignups,
      enableGoogleAuth: settings.enableGoogleAuth,
    };
  }

  /**
   * Send test email using saved or provided SMTP credentials
   */
  async sendTestEmail(dto: TestEmailDto) {
    const settings = await this.getSettings();

    if (!settings.smtpHost || !settings.smtpUser) {
      throw new BadRequestException('SMTP configuration is incomplete. Please configure SMTP Host and Username.');
    }

    try {
      const transporter = nodemailer.createTransport({
        host: settings.smtpHost,
        port: settings.smtpPort || 587,
        secure: settings.smtpSecure || false,
        auth: {
          user: settings.smtpUser,
          pass: settings.smtpPass || '',
        },
      });

      const info = await transporter.sendMail({
        from: `"${settings.smtpFromName || 'HKRION ERP'}" <${settings.smtpFromEmail || settings.smtpUser}>`,
        to: dto.toEmail,
        subject: dto.subject || 'HKRION ERP - SMTP Test Email',
        text: dto.message || 'Congratulations! Your HKRION ERP System SMTP configuration is working seamlessly.',
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eee; border-radius: 8px;">
            <h2 style="color: #6366f1;">HKRION ERP SMTP Test</h2>
            <p>${dto.message || 'Congratulations! Your HKRION ERP Global SMTP Server configuration is working seamlessly.'}</p>
            <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;" />
            <p style="font-size: 12px; color: #888;">Dispatched automatically by Super Admin Platform Settings.</p>
          </div>
        `,
      });

      return {
        success: true,
        messageId: info.messageId,
        message: `Test email dispatched successfully to ${dto.toEmail}`,
      };
    } catch (error: any) {
      throw new InternalServerErrorException(`SMTP Dispatch Error: ${error.message}`);
    }
  }

  /**
   * Test SMS Gateway Dispatch
   */
  async sendTestSms(dto: TestSmsDto) {
    const settings = await this.getSettings();

    // Simulated / HTTP gateway dispatch
    return {
      success: true,
      provider: settings.smsProvider || 'custom_http',
      recipient: dto.phoneNumber,
      message: dto.message || 'HKRION ERP Test SMS notification dispatched successfully.',
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Test OpenRouter AI Connection
   */
  async testAiConnection(dto?: TestAiDto) {
    const settings = await this.getSettings();
    const apiKey = (dto?.apiKey || settings.openRouterApiKey || process.env.OPENROUTER_API_KEY || '').trim();
    const model = (dto?.model || settings.openRouterModel || 'google/gemini-2.0-flash-exp:free').trim();

    if (!apiKey) {
      throw new BadRequestException('OpenRouter API Key is missing. Please provide or save a valid API Key.');
    }

    const startTime = Date.now();
    try {
      const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'HTTP-Referer': 'https://ihmtech.com',
          'X-Title': 'HKRION ERP',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model,
          messages: [
            {
              role: 'user',
              content: 'Say "HKRION ERP AI Copilot connection successful" in under 10 words.',
            },
          ],
          max_tokens: 50,
        }),
      });

      const latencyMs = Date.now() - startTime;
      const data = await response.json();

      if (!response.ok) {
        const errorMsg = data?.error?.message || response.statusText || 'OpenRouter API request failed';
        throw new BadRequestException(`OpenRouter error (${response.status}): ${errorMsg}`);
      }

      const reply = data?.choices?.[0]?.message?.content || 'Connection OK';

      return {
        success: true,
        model,
        latencyMs,
        reply: reply.trim(),
        message: `Successfully connected to OpenRouter model (${model}) in ${latencyMs}ms!`,
      };
    } catch (error: any) {
      if (error instanceof BadRequestException) {
        throw error;
      }
      throw new InternalServerErrorException(`Failed to connect to OpenRouter: ${error.message}`);
    }
  }

  /**
   * Compute live System Health & Diagnostic KPIs
   */
  async getSystemHealth() {
    let dbStatus = 'CONNECTED';
    let totalTenants = 0;
    let totalUsers = 0;

    try {
      [totalTenants, totalUsers] = await Promise.all([
        this.prisma.business.count(),
        this.prisma.user.count(),
      ]);
    } catch (e) {
      dbStatus = 'DISCONNECTED';
    }

    const uptimeSeconds = Math.floor(process.uptime());
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = uptimeSeconds % 60;
    const uptimeFormatted = `${hours}h ${minutes}m ${seconds}s`;

    const memory = process.memoryUsage();
    const rssMb = Math.round((memory.rss / (1024 * 1024)) * 100) / 100;
    const heapUsedMb = Math.round((memory.heapUsed / (1024 * 1024)) * 100) / 100;
    const heapTotalMb = Math.round((memory.heapTotal / (1024 * 1024)) * 100) / 100;

    return {
      serverStatus: 'ONLINE',
      uptimeSeconds,
      uptimeFormatted,
      databaseStatus: dbStatus,
      nodeVersion: process.version,
      platform: process.platform,
      memory: {
        rssMb,
        heapUsedMb,
        heapTotalMb,
      },
      stats: {
        totalTenants,
        totalUsers,
      },
      serverTime: new Date().toISOString(),
    };
  }
}
