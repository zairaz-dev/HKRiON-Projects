"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Gemstone } from "@/types/gemstone";
import { useCurrency } from "@/features/currency/context/CurrencyContext";
import { useWishlist } from "@/features/wishlist/context/WishlistContext";
import { HeartIcon, EyeIcon } from "@/components/ui/LuxuryIcons";
import { LuxuryPrice } from "@/components/ui/LuxuryPrice";
import { QuickViewModal } from "./QuickViewModal";

interface GemstoneCardProps {
  gemstone: Gemstone;
  priority?: boolean;
  className?: string;
}

export function GemstoneCard({ gemstone, priority = false, className = "" }: GemstoneCardProps) {
  const { toggleWishlist, isInWishlist } = useWishlist();
  const [isQuickViewOpen, setIsQuickViewOpen] = useState(false);
  const isFavorited = isInWishlist(gemstone.id);

  const isSoldOut =
    gemstone.variants && gemstone.variants.length > 0
      ? gemstone.variants.every((v) => (v.stock ?? 0) <= 0)
      : gemstone.inStock === false;

  const coverImage =
    (gemstone.images && gemstone.images.length > 0 ? gemstone.images[0] : null) ||
    (gemstone as { imageUrl?: string }).imageUrl ||
    gemstone.daylightImage ||
    "/uploads/gemstones/gem-1789652077476-hwzsqu.webp";

  return (
    <>
      <div className={`group relative flex flex-col bg-white border card-luxury-hover transition-all duration-300 ${
        isSoldOut ? "border-[#E8E4DC] opacity-90" : "border-[#E8E4DC] hover:border-[#C5A880]"
      } ${className}`}>
        {/* Image Container with Badge */}
        <div
          onClick={() => setIsQuickViewOpen(true)}
          className="relative aspect-[4/5] w-full overflow-hidden bg-[#F7F5F1] cursor-pointer"
        >
          <Image
            src={coverImage}
            alt={gemstone.name}
            fill
            priority={priority}
            sizes="(max-width: 640px) 50vw, (max-width: 1200px) 33vw, 25vw"
            unoptimized={coverImage.startsWith("/uploads")}
            className={`object-cover object-center gem-image-zoom transition-transform duration-700 ease-out ${
              isSoldOut ? "grayscale-[25%]" : ""
            }`}
          />

          {/* Sold Out Luxury Badge */}
          {isSoldOut ? (
            <div className="absolute top-1.5 sm:top-3.5 left-1.5 sm:left-3.5 z-10 pointer-events-none">
              <span className="inline-flex items-center gap-1 sm:gap-1.5 px-1.5 sm:px-2.5 py-0.5 sm:py-1 bg-[#18181D]/90 text-[#E0CFA9] text-[7.5px] sm:text-[9px] font-mono uppercase tracking-widest backdrop-blur-sm border border-[#C5A880]/40 shadow-md">
                <span className="w-1 sm:w-1.5 h-1 sm:h-1.5 rounded-full bg-red-400" />
                Sold Out
              </span>
            </div>
          ) : gemstone.video ? (
            <div className="absolute top-1.5 sm:top-3.5 left-1.5 sm:left-3.5 z-10 pointer-events-none">
              <span className="inline-flex items-center gap-1 px-1.5 sm:px-2 py-0.5 bg-black/80 text-[#C5A880] text-[7.5px] sm:text-[9px] font-mono uppercase tracking-wider backdrop-blur-sm border border-[#C5A880]/40 rounded-sm shadow-sm">
                <span className="text-[8px] sm:text-[10px]">▶</span>
                <span>Video</span>
              </span>
            </div>
          ) : null}

          {/* Top Wishlist Button */}
          <div className="absolute top-1.5 sm:top-3.5 right-1.5 sm:right-3.5 pointer-events-auto" onClick={(e) => e.stopPropagation()}>
            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                toggleWishlist(gemstone.id);
              }}
              aria-label="Add to private vault"
              className={`pointer-events-auto w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110 active:scale-95 ${
                isFavorited
                  ? "bg-[#18181D] text-[#C5A880]"
                  : "bg-white/90 text-[#18181D] hover:bg-[#18181D] hover:text-white"
              } shadow-sm backdrop-blur-sm`}
            >
              <HeartIcon className="w-3 h-3 sm:w-4 sm:h-4" filled={isFavorited} />
            </button>
          </div>

          {/* Quick View Hover Button (Desktop Only — on mobile, tapping the image directly opens QuickView) */}
          <div className="hidden sm:block absolute inset-x-4 bottom-4 translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300 ease-out pointer-events-auto">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsQuickViewOpen(true);
              }}
              className="w-full py-2.5 bg-[#18181D]/90 hover:bg-[#18181D] text-white text-xs font-sans tracking-wider uppercase backdrop-blur-sm flex items-center justify-center gap-2 transition-all shadow-lg btn-luxury-press"
            >
              <EyeIcon className="w-4 h-4 text-[#C5A880]" />
              <span>
                {isSoldOut
                  ? "Inspect Specimen (Sold Out)"
                  : gemstone.variants && gemstone.variants.length > 1
                  ? `Select Size (${gemstone.variants.length} Weights)`
                  : "Inspect Specimen"}
              </span>
            </button>
          </div>
        </div>

        {/* Content Container */}
        <div className="p-2.5 sm:p-5 flex flex-col flex-grow justify-between">
          <div onClick={() => setIsQuickViewOpen(true)} className="cursor-pointer">
            {/* Origin & Carat Line */}
            <div className="flex items-center justify-between text-[9px] sm:text-xs text-[#8C867D] uppercase tracking-wider mb-1 sm:mb-1.5 font-sans">
              <span className="truncate max-w-[55%]">{gemstone.originCountry || gemstone.origin}</span>
              <span className="font-medium text-[#18181D] shrink-0">
                {gemstone.variants && gemstone.variants.length > 1
                  ? `${gemstone.variants.length} Sizes`
                  : `${gemstone.carat.toFixed(2)} ct`}
              </span>
            </div>

            {/* Title */}
            <h3 className="font-serif text-xs sm:text-base lg:text-lg text-[#18181D] group-hover:text-[#9A7B4F] transition-colors leading-snug line-clamp-1">
              {gemstone.name}
            </h3>

            {/* Shape & Cut Description */}
            <p className="text-[10px] sm:text-xs text-[#6B655C] font-sans mt-0.5 sm:mt-1 truncate">
              {gemstone.cut} • {gemstone.color}
            </p>
          </div>

          {/* Price & Action Footer */}
          <div className="mt-2.5 sm:mt-4 pt-2 sm:pt-3.5 border-t border-[#F0ECE1] flex items-end justify-between gap-1 sm:gap-2.5">
            <div className="min-w-0 flex-1 cursor-pointer" onClick={() => setIsQuickViewOpen(true)}>
              <span className="text-[8px] sm:text-[10px] text-[#8C867D] block tracking-wider sm:tracking-widest uppercase font-sans font-medium mb-0.5">
                {isSoldOut
                  ? "Status"
                  : gemstone.variants && gemstone.variants.length > 1
                  ? "From"
                  : "Price"}
              </span>
              {isSoldOut ? (
                <span className="text-[10px] sm:text-xs font-serif font-medium text-[#8C867D] italic block truncate">
                  Sold Out
                </span>
              ) : (
                <div className="truncate">
                  <LuxuryPrice
                    amount={gemstone.variants && gemstone.variants.length > 0 ? gemstone.variants[0].price : gemstone.price}
                    size="sm"
                    weight="bold"
                  />
                </div>
              )}
            </div>

            <Link
              href={`/gemstones/${gemstone.id}`}
              className="shrink-0 inline-flex items-center gap-0.5 sm:gap-1 text-[9.5px] sm:text-[11px] font-sans font-medium uppercase tracking-wider text-[#9A7B4F] group-hover:text-[#18181D] hover:text-[#18181D] transition-colors pb-0.5 whitespace-nowrap"
            >
              <span className="hidden sm:inline">View Dossier</span>
              <span className="sm:hidden">View</span>
              <span className="text-[10px] sm:text-xs transition-transform duration-300 group-hover:translate-x-1">&rarr;</span>
            </Link>
          </div>
        </div>
      </div>

      {isQuickViewOpen && (
        <QuickViewModal gemstone={gemstone} onClose={() => setIsQuickViewOpen(false)} />
      )}
    </>
  );
}
