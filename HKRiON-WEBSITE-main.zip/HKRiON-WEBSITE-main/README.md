<div align="center">

# 🚀 HKRION (Pvt) Ltd

**Empowering Businesses with Next-Generation Digital Solutions & Enterprise Software**

[![Next.js](https://img.shields.io/badge/Next.js-16.2-black?style=for-the-badge&logo=next.js)](https://nextjs.org/)
[![React](https://img.shields.io/badge/React-19.0-61DAFB?style=for-the-badge&logo=react&logoColor=black)](https://react.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0-3178C6?style=for-the-badge&logo=typescript&logoColor=white)](https://www.typescriptlang.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-v4.0-38B2AC?style=for-the-badge&logo=tailwind-css&logoColor=white)](https://tailwindcss.com/)
[![Prisma](https://img.shields.io/badge/Prisma-5.22-2D3748?style=for-the-badge&logo=prisma&logoColor=white)](https://www.prisma.io/)

</div>

---

## 📖 Table of Contents

- [Overview](#-overview)
- [Key Features](#-key-features)
- [Tech Stack](#-tech-stack)
- [Getting Started](#-getting-started)
- [Project Structure](#-project-structure)
- [Deployment](#-deployment)
- [License & Contact](#-license--contact)

---

## 🌐 Overview

**HKRION (Pvt) Ltd** is a modern, high-performance web application built for an enterprise software development and IT solutions provider. Built with **Next.js 16 (App Router)**, **React 19**, and **Tailwind CSS v4**, the platform delivers an immersive user experience featuring custom WebGL shaders, dark glassmorphism styling, an interactive technology stack showcase, enterprise product portfolios, and seamless client consultation workflows.

---

## ✨ Key Features

- 🎨 **Modern Dark Glassmorphism UI**: High-end aesthetic with WebGL shader animations powered by OGL.
- ⚡ **Lightning Fast Performance**: Built using Next.js 16 App Router with optimized asset delivery.
- 🛍️ **Featured Products & Case Studies**: Showcases Cloud POS, Enterprise ERPs, and custom Mobile/Web applications.
- 💻 **Interactive Tech Stack Grid**: Filterable view of engineering capabilities across Frontend, Backend, Database, and Cloud.
- 📝 **Client Lead & Inquiry Workflow**: Interactive contact interface with real-time field validation.
- 📱 **Fully Responsive & Accessible**: Optimized for seamless viewing across all device screens.

---

## 🛠️ Tech Stack

### **Frontend & Core**

| Technology          | Description                                         |
| :------------------ | :-------------------------------------------------- |
| **Next.js 16**      | React Framework with App Router                     |
| **React 19**        | Core UI Component Library                           |
| **TypeScript**      | Static Type Safety                                  |
| **Tailwind CSS v4** | Modern Utility-First Styling System                 |
| **Lucide React**    | Icon Suite                                          |
| **OGL**             | Minimal WebGL Library for Background Visual Shaders |

### **Backend & Database**

| Technology     | Description                    |
| :------------- | :----------------------------- |
| **Node.js**    | JavaScript Runtime Environment |
| **Prisma ORM** | Type-safe Database Client      |

---

## 🚀 Getting Started

Follow these instructions to run the repository on your local computer.

### 1. Prerequisites

Ensure you have Node.js (v18+) and npm installed:

```bash
node -v
npm -v
```

### 2. Installation

Clone the repository and install project dependencies:

```bash
git clone https://github.com/hkrilham/HKRiON-Pvt-Ltd.git
cd "HKRION (Pvt) Ltd"
npm install

npx prisma generate
npx prisma db push

npx tsx scripts/seed.ts


```

### 3. Run Development Server

Launch the local development environment:

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your web browser to view the application.

---

## 📁 Project Structure

```text
HKRION (Pvt) Ltd/
├── src/
│   ├── app/                 # Next.js App Router pages, layout, and global CSS
│   ├── components/          # UI Components
│   │   ├── About.tsx        # Company introduction section
│   │   ├── ContactForm.tsx  # Dynamic inquiry form
│   │   ├── DarkVeil.tsx     # WebGL background visual effect
│   │   ├── Hero.tsx         # Main landing hero section
│   │   ├── Products.tsx     # Products & Featured Projects
│   │   ├── TechStack.tsx    # Technology stack grid showcase
│   │   └── ...
├── prisma/                  # Database models & Prisma configuration
├── public/                  # Static media, icons, and assets
└── package.json             # Scripts & dependency definitions
```

---

## 🛠️ Project Commands

- `npm run dev` - Starts the development server at `localhost:3000`
- `npm run build` - Creates an optimized production build
- `npm run start` - Runs the production server after building
- `npm run lint` - Executes ESLint analysis across the project codebase

---

## 🌐 Deployment

This application is ready for instant deployment on [Vercel](https://vercel.com).

1. Push your changes to GitHub (`main` branch).
2. Import the repository in your Vercel Dashboard.
3. Vercel will automatically detect Next.js and deploy the application.

---

## 📄 License & Ownership

© **HKRION (Pvt) Ltd**. All Rights Reserved.

# hkrion_web
