import { getSession } from "@/lib/session";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import EmployeeDashboard from "@/components/features/employee-dashboard";
import ManagerDashboard from "@/components/features/manager-dashboard";
import SuperAdminDashboard from "@/components/features/superadmin-dashboard";
import { PageHeader } from "@/components/ui/page-header";

export default async function DashboardPage() {
  const session = await getSession();

  if (!session) {
    redirect("/login");
  }

  const hour = new Date().getHours();
  let greeting = "Good evening";
  if (hour >= 5 && hour < 12) {
    greeting = "Good morning";
  } else if (hour >= 12 && hour < 18) {
    greeting = "Good afternoon";
  }

  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);
  
  const todayEnd = new Date();
  todayEnd.setHours(23, 59, 59, 999);

  // ==========================================
  // EMPLOYEE VIEW
  // ==========================================
  if (session.role === "EMPLOYEE") {
    const [user, todayAttendance, leavesTaken, pendingLeaves, recentActivity] = await Promise.all([
      prisma.user.findUnique({
        where: { id: session.userId },
        select: { firstName: true, lastName: true },
      }),
      prisma.attendance.findUnique({
        where: { userId_date: { userId: session.userId, date: todayStart } }
      }),
      prisma.leaveRequest.count({ where: { userId: session.userId, status: "APPROVED" } }),
      prisma.leaveRequest.count({ where: { userId: session.userId, status: "PENDING" } }),
      prisma.attendance.findMany({
        where: { userId: session.userId },
        take: 5,
        orderBy: { date: 'desc' }
      })
    ]);

    const displayName = user ? `${user.firstName} ${user.lastName}` : `User #${session.userId}`;

    return (
      <div className="max-w-7xl mx-auto space-y-6">
        <PageHeader 
          title={`${greeting}, ${displayName}`}
          description="Here is your personal overview for today."
          className="border-none pb-0 mb-2"
        />
        <EmployeeDashboard
          todayAttendance={todayAttendance}
          leavesTaken={leavesTaken}
          pendingLeaves={pendingLeaves}
          recentActivity={recentActivity}
        />
      </div>
    );
  }

  // ==========================================
  // MANAGER VIEW
  // ==========================================
  if (session.role === "MANAGER") {
    const [user, teamHeadcount, teamPresentToday, teamPendingLeaves, teamRecentActivity] = await Promise.all([
      prisma.user.findUnique({
        where: { id: session.userId },
        select: { firstName: true, lastName: true },
      }),
      prisma.user.count({ where: { managerId: session.userId } }),
      prisma.attendance.count({
        where: {
          date: { gte: todayStart, lte: todayEnd },
          clockIn: { not: null },
          user: { managerId: session.userId }
        }
      }),
      prisma.leaveRequest.count({
        where: {
          status: "PENDING",
          user: { managerId: session.userId }
        }
      }),
      prisma.attendance.findMany({
        where: { user: { managerId: session.userId } },
        take: 5,
        orderBy: [ { date: 'desc' }, { clockIn: 'desc' } ],
        include: { user: { select: { firstName: true, lastName: true, email: true } } }
      })
    ]);

    const displayName = user ? `${user.firstName} ${user.lastName}` : `User #${session.userId}`;

    return (
      <div className="max-w-7xl mx-auto space-y-6">
        <PageHeader 
          title={`${greeting}, ${displayName}`}
          description="Here is the status of your team today."
          className="border-none pb-0 mb-2"
        />
        <ManagerDashboard
          teamHeadcount={teamHeadcount}
          teamPresentToday={teamPresentToday}
          teamPendingLeaves={teamPendingLeaves}
          teamRecentActivity={teamRecentActivity}
        />
      </div>
    );
  }

  // ==========================================
  // SUPER ADMIN VIEW
  // ==========================================
  if (session.role === "SUPER_ADMIN") {
    const [user, totalEmployees, totalPositions, presentToday, recentAuditLogs] = await Promise.all([
      prisma.user.findUnique({
        where: { id: session.userId },
        select: { firstName: true, lastName: true },
      }),
      prisma.user.count(),
      prisma.position.count(),
      prisma.attendance.count({
        where: {
          date: { gte: todayStart, lte: todayEnd },
          clockIn: { not: null },
        },
      }),
      prisma.auditLog.findMany({
        take: 8,
        orderBy: { createdAt: 'desc' },
        include: {
          user: { select: { firstName: true, lastName: true, email: true } }
        }
      })
    ]);

    const displayName = user ? `${user.firstName} ${user.lastName}` : `User #${session.userId}`;

    return (
      <div className="max-w-7xl mx-auto space-y-6">
        <PageHeader 
          title={`${greeting}, ${displayName}`}
          description="Here is the global overview of the organization."
          className="border-none pb-0 mb-2"
        />
        <SuperAdminDashboard
          totalEmployees={totalEmployees}
          totalPositions={totalPositions}
          presentToday={presentToday}
          recentAuditLogs={recentAuditLogs}
        />
      </div>
    );
  }

  // Fallback
  return null;
}
