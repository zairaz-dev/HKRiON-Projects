export interface BranchItem {
  id: string;
  name: string;
}

export interface BrandBranchItem {
  branchId: string;
  branch: BranchItem;
}

export interface BrandItem {
  id: string;
  name: string;
  description: string | null;
  logoUrl: string | null;
  isActive: boolean;
  businessId: string;
  createdAt: string;
  updatedAt: string;
  branches?: BrandBranchItem[];
}
