import { NextResponse } from "next/server";
import { getClients } from "@/lib/data/clients-db";
import { requireAdmin } from "@/lib/require-admin";

export const dynamic = "force-dynamic";
export const revalidate = 0;

// GET /api/clients — Admin only
export async function GET() {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const clients = await getClients();
    return NextResponse.json({ clients });
  } catch (error) {
    console.error("Error in GET /api/clients:", error);
    return NextResponse.json(
      { error: "Failed to fetch clients" },
      { status: 500 }
    );
  }
}
