import { Controller, Get, Query, UseGuards, Req } from '@nestjs/common';
import { ContactBalancesService } from './contact-balances.service';
import { JwtAuthGuard } from '../../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { PermissionsGuard } from '../../../common/guards/permissions.guard';
import { Permissions } from '../../../common/decorators/permissions.decorator';
import { Permission } from '../../../common/enums/permission.enum';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('reports/contact-balances')
export class ContactBalancesController {
  constructor(private readonly contactBalancesService: ContactBalancesService) {}

  @Permissions(Permission.REPORT_VIEW)
  @Get()
  async getContactBalances(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('search') search?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.contactBalancesService.getContactBalances(bId, { search });
  }
}

