import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateCustomerGroupDto } from './dto/create-customer-group.dto';
import { UpdateCustomerGroupDto } from './dto/update-customer-group.dto';

@Injectable()
export class CustomerGroupsService {
  constructor(private prisma: PrismaService) {}

  async create(createDto: CreateCustomerGroupDto) {
    const { branchIds, ...data } = createDto;

    return this.prisma.customerGroup.create({
      data: {
        ...data,
        branches: branchIds && branchIds.length > 0
          ? {
              create: branchIds.map((branchId) => ({
                branchId,
              })),
            }
          : undefined,
      },
      include: {
        sellingPriceGroup: true,
        branches: {
          include: {
            branch: true,
          },
        },
      },
    });
  }

  async findAll(businessId: string, branchId?: string) {
    const whereClause: any = { businessId };

    if (branchId) {
      whereClause.branches = {
        some: { branchId },
      };
    }

    return this.prisma.customerGroup.findMany({
      where: whereClause,
      include: {
        sellingPriceGroup: true,
        branches: {
          include: {
            branch: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });
  }

  async findOne(id: string, businessId: string) {
    const customerGroup = await this.prisma.customerGroup.findFirst({
      where: { id, businessId },
      include: {
        sellingPriceGroup: true,
        branches: {
          include: {
            branch: true,
          },
        },
      },
    });

    if (!customerGroup) {
      throw new NotFoundException('Customer group not found');
    }

    return customerGroup;
  }

  async update(id: string, updateDto: UpdateCustomerGroupDto) {
    const { branchIds, businessId, ...data } = updateDto;

    // Verify it exists
    if (businessId) {
      await this.findOne(id, businessId);
    }

    // Update data and branch mappings
    return this.prisma.$transaction(async (tx) => {
      // Delete existing branch mappings if branchIds is provided
      if (branchIds !== undefined) {
        await tx.customerGroupBranch.deleteMany({
          where: { customerGroupId: id },
        });
      }

      return tx.customerGroup.update({
        where: { id },
        data: {
          ...data,
          branches: branchIds && branchIds.length > 0
            ? {
                create: branchIds.map((branchId) => ({
                  branchId,
                })),
              }
            : undefined,
        },
        include: {
          sellingPriceGroup: true,
          branches: {
            include: {
              branch: true,
            },
          },
        },
      });
    });
  }

  async remove(id: string, businessId: string) {
    await this.findOne(id, businessId);

    return this.prisma.customerGroup.delete({
      where: { id },
    });
  }
}
