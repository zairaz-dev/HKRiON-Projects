"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import {
  Package,
  Plus,
  Edit2,
  Trash2,
  Loader2,
  CheckCircle,
  AlertCircle,
  Building2,
  Globe,
  Eye,
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { DataTable, ColumnDef, ActionsDropdown } from "@/components/ui/table";
import { Select } from "@/components/ui/select";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";
import { getFullAssetUrl } from "@/lib/utils";

import {
  ProductItem,
  ProductDialog,
  ProductDeleteDialog,
  useProductsPaginatedQuery,
  useCategoriesQuery,
  useBranchesQuery,
} from "@/features/products";
import { useCurrency } from "@/hooks/use-currency";

function ProductsPageContent() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Success / Error notifications
  const [successMessage, setSuccessMessage] = useState<string>("none");
  const [error, setError] = useState<string>("");

  // Dialog / Modal States
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingProduct, setEditingProduct] = useState<ProductItem | null>(null);
  const [productToDelete, setProductToDelete] = useState<ProductItem | null>(null);

  // URL Search Params for Filters & Pagination
  const selectedBranchFilter = searchParams.get("branchId") || "all";
  const selectedCategoryFilter = searchParams.get("categoryId") || "all";
  const page = parseInt(searchParams.get("page") || "1", 10);
  const limit = parseInt(searchParams.get("limit") || "10", 10);
  const searchQuery = searchParams.get("search") || "";

  const setSelectedBranchFilter = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value === "all") {
      params.delete("branchId");
    } else {
      params.set("branchId", value);
    }
    params.set("page", "1");
    router.push(`${pathname}?${params.toString()}`);
  };

  const setSelectedCategoryFilter = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value === "all") {
      params.delete("categoryId");
    } else {
      params.set("categoryId", value);
    }
    params.set("page", "1");
    router.push(`${pathname}?${params.toString()}`);
  };

  const handlePageChange = (newPage: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", String(newPage));
    router.push(`${pathname}?${params.toString()}`);
  };

  const handleLimitChange = (newLimit: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("limit", String(newLimit));
    params.set("page", "1");
    router.push(`${pathname}?${params.toString()}`);
  };

  const handleSearchChange = (query: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (query && query.trim()) {
      params.set("search", query.trim());
    } else {
      params.delete("search");
    }
    params.set("page", "1");
    router.push(`${pathname}?${params.toString()}`);
  };

  // Auth check
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  // Notifications timeout auto dismiss
  useEffect(() => {
    if (successMessage && successMessage !== "none") {
      const timer = setTimeout(() => setSuccessMessage("none"), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  const businessId = currentUser?.businessId || "";
  const { symbol, format } = useCurrency(businessId);

  // Queries
  const { data: response, isLoading: productsLoading } = useProductsPaginatedQuery(
    businessId,
    {
      branchId: selectedBranchFilter !== "all" ? selectedBranchFilter : undefined,
      categoryId: selectedCategoryFilter !== "all" ? selectedCategoryFilter : undefined,
      search: searchQuery || undefined,
      page,
      limit,
    }
  );

  const productsList = response?.data || [];
  const meta = response?.meta || { totalItems: 0, totalPages: 1, currentPage: 1, limit };

  const { data: categoriesList = [] } = useCategoriesQuery(businessId);
  const { data: branchesList = [] } = useBranchesQuery(businessId);

  const handleOpenCreateModal = () => {
    setEditingProduct(null);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (prod: ProductItem) => {
    setEditingProduct(prod);
    setIsModalOpen(true);
  };

  const handleOpenDeleteConfirm = (prod: ProductItem) => {
    setProductToDelete(prod);
  };

  // Columns definition
  const columns: ColumnDef<ProductItem>[] = [
    {
      header: "Image",
      render: (prod) => (
        <div className="w-8 h-8 rounded-md border border-border bg-muted/60 flex items-center justify-center overflow-hidden shrink-0 shadow-xs hover:border-primary/50 transition-colors">
          {prod.imageUrl ? (
            <img 
              src={getFullAssetUrl(prod.imageUrl) || ""} 
              alt={prod.name} 
              className="w-full h-full object-cover" 
            />
          ) : (
            <Package className="w-4 h-4 text-muted-foreground/60" />
          )}
        </div>
      ),
    },
    {
      header: "Product Details",
      searchable: true,
      render: (prod) => (
        <div className="truncate max-w-[220px]">
          <span 
            onClick={() => router.push(`/products/detail?id=${prod.id}`)}
            className="font-semibold text-xs text-foreground hover:text-primary transition block truncate cursor-pointer"
          >
            {prod.name}
          </span>
          <div className="flex items-center gap-2 mt-0.5">
            <span className="text-[9px] font-medium text-muted-foreground uppercase">
              {prod.type}
            </span>
            {(prod.isImei || prod.enableImei) && (
              <span className="inline-flex items-center gap-0.5 text-[9px] font-medium text-primary uppercase">
                📱 IMEI
              </span>
            )}
          </div>
        </div>
      ),
    },
    {
      header: "SKU & Barcode",
      render: (prod) => {
        if (prod.type === "SINGLE") {
          const variant = prod.variants[0];
          return (
            <div className="text-[11px] space-y-0.5">
              <span className="font-mono font-medium text-foreground block">
                {variant?.sku || "N/A"}
              </span>
              {variant?.barcode && (
                <span className="text-muted-foreground block text-[9px]">
                  BC: {variant.barcode}
                </span>
              )}
            </div>
          );
        } else {
          return (
            <div className="text-[11px] text-muted-foreground font-semibold">
              {prod.variants.length} Variants
            </div>
          );
        }
      },
    },
    {
      header: "Cost Price",
      align: "right",
      render: (prod) => {
        if (prod.type === "SINGLE") {
          const variant = prod.variants[0];
          return (
            <span className="text-[11px] font-medium font-mono tabular-nums text-muted-foreground block">
              {format(variant?.purchasePrice || 0)}
            </span>
          );
        } else {
          const purchasePrices = prod.variants.map((v) => v.purchasePrice || 0);
          const minCost = purchasePrices.length ? Math.min(...purchasePrices) : 0;
          const maxCost = purchasePrices.length ? Math.max(...purchasePrices) : 0;
          return (
            <span className="text-[11px] font-medium font-mono tabular-nums text-muted-foreground block">
              {minCost === maxCost ? format(minCost) : `${format(minCost)} - ${format(maxCost)}`}
            </span>
          );
        }
      },
    },
    {
      header: "Selling Price",
      align: "right",
      render: (prod) => {
        if (prod.type === "SINGLE") {
          const variant = prod.variants[0];
          return (
            <span className="text-[11px] font-bold font-mono tabular-nums text-emerald-500 block">
              {format(variant?.sellingPrice || 0)}
            </span>
          );
        } else {
          const sellingPrices = prod.variants.map((v) => v.sellingPrice || 0);
          const minSell = sellingPrices.length ? Math.min(...sellingPrices) : 0;
          const maxSell = sellingPrices.length ? Math.max(...sellingPrices) : 0;
          return (
            <span className="text-[11px] font-bold font-mono tabular-nums text-emerald-500 block">
              {minSell === maxSell ? format(minSell) : `${format(minSell)} - ${format(maxSell)}`}
            </span>
          );
        }
      },
    },
    {
      header: "Current Stock",
      render: (prod) => {
        if (!prod.enableStock) {
          return <span className="text-[11px] text-muted-foreground font-semibold">Not Tracked</span>;
        }

        let totalStock = 0;
        prod.variants.forEach((v) => {
          v.purchaseLines?.forEach((pl) => {
            if (selectedBranchFilter === "all" || pl.branchId === selectedBranchFilter) {
              totalStock += pl.quantityRemaining;
            }
          });
        });

        const isLowStock = prod.alertQuantity !== null && totalStock <= prod.alertQuantity;

        return (
          <div className="flex flex-col">
            <span className={`text-[11px] font-bold ${totalStock === 0 ? "text-destructive" : isLowStock ? "text-amber-500" : "text-foreground"}`}>
              {totalStock} {prod.unit?.code || "units"}
            </span>
            {isLowStock && totalStock > 0 && (
              <span className="text-[8px] font-bold text-amber-500 uppercase tracking-wider mt-0.5">
                Low Stock
              </span>
            )}
            {totalStock === 0 && (
              <span className="text-[8px] font-bold text-destructive uppercase tracking-wider mt-0.5">
                Out of Stock
              </span>
            )}
          </div>
        );
      },
    },
    {
      header: "Category & Brand",
      render: (prod) => (
        <div className="flex flex-col gap-0.5">
          {prod.category && (
            <span className="text-[11px] font-medium text-foreground">
              {prod.category.name}
            </span>
          )}
          {prod.brand && (
            <span className="text-[10px] text-muted-foreground">
              {prod.brand.name}
            </span>
          )}
          {!prod.category && !prod.brand && (
            <span className="text-[11px] text-muted-foreground">—</span>
          )}
        </div>
      ),
    },
    {
      header: "Branches",
      render: (prod) => {
        if (!prod.branches || prod.branches.length === 0) {
          return (
            <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
              <Globe className="h-3 w-3 text-muted-foreground" /> Global
            </span>
          );
        }
        return (
          <div className="flex flex-wrap gap-1 max-w-[150px]">
            {prod.branches.map((pb) => (
              <span
                key={pb.branchId}
                className="inline-flex items-center gap-1 text-[11px] text-muted-foreground"
              >
                <Building2 className="h-3 w-3 text-muted-foreground" /> {pb.branch.name}
              </span>
            ))}
          </div>
        );
      },
    },
    {
      header: "Status",
      render: (prod) => (
        <span
          className={`text-[11px] font-semibold ${
            prod.isActive ? "text-emerald-500" : "text-destructive"
          }`}
        >
          {prod.isActive ? "Active" : "Inactive"}
        </span>
      ),
    },
    {
      header: "Actions",
      render: (prod) => (
        <ActionsDropdown
          actions={[
            {
              label: "View Details",
              onClick: () => router.push(`/products/detail?id=${prod.id}`),
              icon: <Eye className="h-3.5 w-3.5" />,
            },
            {
              label: "Edit",
              onClick: () => handleOpenEditModal(prod),
              icon: <Edit2 className="h-3.5 w-3.5" />,
            },
            {
              label: "Delete",
              onClick: () => handleOpenDeleteConfirm(prod),
              icon: <Trash2 className="h-3.5 w-3.5" />,
              variant: "destructive",
            },
          ]}
        />
      ),
    },
  ];

  // Custom filters render inside popover
  const customFilters = (
    <div className="space-y-3.5 min-w-[200px]">
      {/* Branch Filter */}
      <div className="space-y-1.5">
        <label className="text-[10px] font-bold text-muted-foreground uppercase">
          Branch Filter
        </label>
        <Select
          value={selectedBranchFilter}
          onValueChange={setSelectedBranchFilter}
          className="h-9 text-xs"
        >
          <option value="all">All Branches</option>
          <option value="global">Global (No Branch)</option>
          {branchesList.map((b: any) => (
            <option key={b.id} value={b.id}>{b.name}</option>
          ))}
        </Select>
      </div>

      {/* Category Filter */}
      <div className="space-y-1.5">
        <label className="text-[10px] font-bold text-muted-foreground uppercase">
          Category Filter
        </label>
        <Select
          value={selectedCategoryFilter}
          onValueChange={setSelectedCategoryFilter}
          className="h-9 text-xs"
        >
          <option value="all">All Categories</option>
          {categoriesList.map((c: any) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </Select>
      </div>
    </div>
  );

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3 p-6 max-w-sm border border-border/40 rounded-xl bg-card/60 backdrop-blur-sm">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <h2 className="text-lg font-bold">Unauthorized Access</h2>
          <p className="text-sm text-muted-foreground">
            You need to be logged in to view this page. Redirecting to login...
          </p>
          <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
        </div>
      </div>
    );
  }

  const isLoading = productsLoading;

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/products" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Products List" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <Package className="h-7 w-7 text-primary" /> Products List
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Manage your product catalog, configure variations, units, and custom prices.
              </p>
            </div>
          </div>

          {/* Banner Notifications */}
          {successMessage && successMessage !== "none" && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 animate-in fade-in slide-in-from-top-4 duration-300">
              <CheckCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive animate-in fade-in slide-in-from-top-4 duration-300">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          {/* Main Table Card */}
          {isLoading ? (
            <div className="flex h-64 items-center justify-center">
              <div className="text-center space-y-2">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
                <span className="text-sm text-muted-foreground block">Loading products...</span>
              </div>
            </div>
          ) : (
            <DataTable
              data={productsList}
              columns={columns}
              searchPlaceholder="Search products by name, SKU, or barcode..."
              reportTitle="Product Catalog Report"
              pageSize={meta.limit}
              customFilters={customFilters}
              actionButton={{
                label: "Add Product",
                onClick: handleOpenCreateModal,
                icon: <Plus className="h-4 w-4" />
              }}
              serverSide={true}
              totalItems={meta.totalItems}
              totalPages={meta.totalPages}
              currentPage={meta.currentPage}
              onPageChange={handlePageChange}
              searchQuery={searchQuery}
              onSearchQueryChange={handleSearchChange}
              isLoading={productsLoading}
              onPageSizeChange={handleLimitChange}
            />
          )}
        </main>
      </div>

      {/* Add / Edit Product Modal */}
      <ProductDialog
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        product={editingProduct}
        businessId={businessId}
        userId={currentUser?.id || ""}
        onSuccessMessage={(msg) => setSuccessMessage(msg)}
        onErrorMessage={(msg) => setError(msg)}
      />

      {/* Delete Confirmation Dialog */}
      <ProductDeleteDialog
        isOpen={!!productToDelete}
        onClose={() => setProductToDelete(null)}
        product={productToDelete}
        businessId={businessId}
        onSuccessMessage={(msg) => setSuccessMessage(msg)}
        onErrorMessage={(msg) => setError(msg)}
      />
    </div>
  );
}

export default function ProductsPage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen w-screen items-center justify-center bg-[#121216]">
        <div className="flex flex-col items-center gap-2">
          <div className="w-8 h-8 border-4 border-zinc-700 border-t-emerald-500 rounded-full animate-spin" />
          <p className="text-sm text-zinc-400">Loading...</p>
        </div>
      </div>
    }>
      <ProductsPageContent />
    </Suspense>
  );
}
