import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { PosService } from '../pos/pos.service';
import { CreateQuotationDto } from './dto/create-quotation.dto';
import { UpdateQuotationDto } from './dto/update-quotation.dto';

@Injectable()
export class QuotationsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly posService: PosService,
  ) {}

  private async generateQuotationNumber(businessId: string, tx: any = this.prisma): Promise<string> {
    const year = new Date().getFullYear();
    const count = await tx.quotation.count({
      where: { businessId },
    });
    const seq = String(count + 1).padStart(4, '0');
    let candidate = `QT-${year}-${seq}`;

    // Verify uniqueness
    const exists = await tx.quotation.findFirst({
      where: { quotationNumber: candidate, businessId },
    });

    if (exists) {
      candidate = `QT-${year}-${seq}-${Math.floor(100 + Math.random() * 900)}`;
    }

    return candidate;
  }

  async create(businessId: string, userId: string, dto: CreateQuotationDto) {
    return this.prisma.$transaction(async (tx) => {
      // Resolve Walk-in customer if needed
      let finalCustomerId = dto.customerId;
      if (!finalCustomerId || finalCustomerId === 'walk-in') {
        const walkIn = await tx.customer.findFirst({
          where: {
            businessId,
            OR: [
              { isDefault: true },
              { name: { equals: 'Walk-in Customer', mode: 'insensitive' } },
            ],
          },
        });
        if (walkIn) {
          finalCustomerId = walkIn.id;
        }
      }

      const quotationNumber = dto.quotationNumber?.trim() || (await this.generateQuotationNumber(businessId, tx));

      const quotation = await tx.quotation.create({
        data: {
          quotationNumber,
          date: dto.date ? new Date(dto.date) : new Date(),
          expiryDate: dto.expiryDate ? new Date(dto.expiryDate) : null,
          status: (dto.status as any) || 'PENDING',
          discountType: dto.discountType || null,
          discountAmount: dto.discountAmount || 0,
          taxAmount: dto.taxAmount || 0,
          grandTotal: dto.grandTotal,
          termsAndConditions: dto.termsAndConditions || null,
          notes: dto.notes || null,
          customerId: finalCustomerId,
          branchId: dto.branchId,
          businessId,
          createdById: userId,
          quotationLines: {
            create: dto.quotationLines.map((line) => ({
              variantId: line.variantId,
              quantity: line.quantity,
              unitPrice: line.unitPrice,
              discountAmount: line.discountAmount || 0,
              taxAmount: line.taxAmount || 0,
              subtotal: line.subtotal,
              branchId: dto.branchId,
              businessId,
            })),
          },
        },
        include: {
          customer: true,
          branch: true,
          quotationLines: {
            include: {
              variant: {
                include: {
                  product: true,
                },
              },
            },
          },
        },
      });

      return quotation;
    });
  }

  async findAll(
    businessId: string,
    query: {
      branchId?: string;
      customerId?: string;
      status?: string;
      startDate?: string;
      endDate?: string;
      search?: string;
      page?: number;
      limit?: number;
      userId?: string;
      userRole?: string;
    },
  ) {
    const {
      branchId,
      customerId,
      status,
      startDate,
      endDate,
      search,
      page = 1,
      limit = 20,
      userId,
      userRole,
    } = query;

    const skip = (Number(page) - 1) * Number(limit);
    const take = Number(limit);

    const where: any = { businessId };

    // Strict Branch Permission Enforcement:
    // If the user is not admin/super-admin, restrict to their assigned branches
    if (userRole && userRole !== 'admin' && userRole !== 'super-admin' && userId) {
      const userBranches = await this.prisma.userBranch.findMany({
        where: { userId },
        select: { branchId: true },
      });
      const allowedBranchIds = userBranches.map((ub) => ub.branchId);

      if (branchId && branchId !== 'all') {
        if (allowedBranchIds.includes(branchId)) {
          where.branchId = branchId;
        } else {
          where.branchId = { in: allowedBranchIds };
        }
      } else {
        where.branchId = { in: allowedBranchIds };
      }
    } else {
      if (branchId && branchId !== 'all') {
        where.branchId = branchId;
      }
    }

    if (customerId) {
      where.customerId = customerId;
    }

    if (status) {
      where.status = status;
    }

    if (startDate || endDate) {
      where.date = {};
      if (startDate) {
        where.date.gte = new Date(startDate);
      }
      if (endDate) {
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        where.date.lte = end;
      }
    }

    if (search) {
      where.OR = [
        { quotationNumber: { contains: search, mode: 'insensitive' } },
        { customer: { name: { contains: search, mode: 'insensitive' } } },
        { customer: { phone: { contains: search, mode: 'insensitive' } } },
      ];
    }

    const [total, items] = await Promise.all([
      this.prisma.quotation.count({ where }),
      this.prisma.quotation.findMany({
        where,
        skip,
        take,
        orderBy: { createdAt: 'desc' },
        include: {
          customer: {
            select: {
              id: true,
              name: true,
              phone: true,
              email: true,
            },
          },
          branch: {
            select: {
              id: true,
              name: true,
            },
          },
          createdBy: {
            select: {
              id: true,
              name: true,
            },
          },
          convertedSale: {
            select: {
              id: true,
              invoiceNumber: true,
            },
          },
          quotationLines: {
            include: {
              variant: {
                select: {
                  id: true,
                  sku: true,
                  name: true,
                  product: {
                    select: {
                      id: true,
                      name: true,
                    },
                  },
                },
              },
            },
          },
        },
      }),
    ]);

    return {
      data: items,
      meta: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / take) || 1,
      },
    };
  }

  async findOne(businessId: string, id: string) {
    const quotation = await this.prisma.quotation.findFirst({
      where: { id, businessId },
      include: {
        customer: true,
        branch: true,
        createdBy: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        convertedSale: {
          select: {
            id: true,
            invoiceNumber: true,
            grandTotal: true,
            saleDate: true,
            status: true,
          },
        },
        quotationLines: {
          include: {
            variant: {
              include: {
                product: true,
              },
            },
          },
        },
      },
    });

    if (!quotation) {
      throw new NotFoundException('Quotation not found.');
    }

    return quotation;
  }

  async update(businessId: string, id: string, dto: UpdateQuotationDto) {
    const existing = await this.prisma.quotation.findFirst({
      where: { id, businessId },
    });

    if (!existing) {
      throw new NotFoundException('Quotation not found.');
    }

    if (existing.status === 'CONVERTED') {
      throw new BadRequestException('Cannot edit a quotation that has already been converted to a sale.');
    }

    return this.prisma.$transaction(async (tx) => {
      // If quotationLines are provided, delete existing lines and create new ones
      if (dto.quotationLines && dto.quotationLines.length > 0) {
        await tx.quotationLine.deleteMany({
          where: { quotationId: id },
        });

        await tx.quotationLine.createMany({
          data: dto.quotationLines.map((line) => ({
            quotationId: id,
            variantId: line.variantId,
            quantity: line.quantity,
            unitPrice: line.unitPrice,
            discountAmount: line.discountAmount || 0,
            taxAmount: line.taxAmount || 0,
            subtotal: line.subtotal,
            branchId: dto.branchId || existing.branchId,
            businessId,
          })),
        });
      }

      const updated = await tx.quotation.update({
        where: { id },
        data: {
          date: dto.date ? new Date(dto.date) : undefined,
          expiryDate: dto.expiryDate ? new Date(dto.expiryDate) : undefined,
          status: dto.status as any,
          discountType: dto.discountType,
          discountAmount: dto.discountAmount,
          taxAmount: dto.taxAmount,
          grandTotal: dto.grandTotal,
          termsAndConditions: dto.termsAndConditions,
          notes: dto.notes,
          customerId: dto.customerId,
          branchId: dto.branchId,
        },
        include: {
          customer: true,
          branch: true,
          quotationLines: {
            include: {
              variant: {
                include: {
                  product: true,
                },
              },
            },
          },
        },
      });

      return updated;
    });
  }

  async delete(businessId: string, id: string) {
    const existing = await this.prisma.quotation.findFirst({
      where: { id, businessId },
    });

    if (!existing) {
      throw new NotFoundException('Quotation not found.');
    }

    await this.prisma.quotation.delete({
      where: { id },
    });

    return { success: true, message: 'Quotation deleted successfully.' };
  }

  async convertToSale(
    businessId: string,
    userId: string,
    id: string,
    body?: { payments?: any[]; useAdvance?: boolean },
  ) {
    const quotation = await this.findOne(businessId, id);

    if (quotation.status === 'CONVERTED') {
      throw new BadRequestException('This quotation has already been converted to a sale.');
    }

    // Prepare checkout DTO for PosService
    const checkoutDto: any = {
      businessId,
      customerId: quotation.customerId,
      branchId: quotation.branchId,
      createdById: userId,
      status: 'FINAL',
      discountType: quotation.discountType || undefined,
      discountAmount: quotation.discountAmount || 0,
      taxAmount: quotation.taxAmount || 0,
      notes: `Converted from Quotation: ${quotation.quotationNumber}${quotation.notes ? ` | ${quotation.notes}` : ''}`,
      saleLines: quotation.quotationLines.map((ql) => ({
        variantId: ql.variantId,
        quantity: ql.quantity,
        unitPrice: ql.unitPrice,
        discountAmount: ql.discountAmount || 0,
        taxAmount: ql.taxAmount || 0,
        subtotal: ql.subtotal,
      })),
      payments: body?.payments || [],
      useAdvance: body?.useAdvance || false,
    };

    // Execute checkout through PosService (deducts stock and records sale)
    const sale = await this.posService.checkout(checkoutDto);

    // Automatically remove quotation once converted to sale as requested
    await this.prisma.quotation.delete({
      where: { id },
    });

    return {
      message: `Quotation ${quotation.quotationNumber} successfully converted to Sale ${sale.invoiceNumber} and removed!`,
      sale,
    };
  }
}
