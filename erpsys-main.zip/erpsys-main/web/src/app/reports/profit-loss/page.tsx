"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import { PieChart, Building2, Calendar, Loader2, AlertCircle } from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { Select } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";
import { useBranchesQuery } from "@/features/suppliers/hooks/use-suppliers";
import { ProfitLossView } from "@/features/reports";

function ProfitLossPageContent() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  const selectedBranchFilter = searchParams.get("branchId") || "all";
  const startDate = searchParams.get("startDate") || "";
  const endDate = searchParams.get("endDate") || "";

  const setBranchFilter = (val: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (val === "all") params.delete("branchId");
    else params.set("branchId", val);
    router.push(`${pathname}?${params.toString()}`);
  };

  const setDateFilter = (start: string, end: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (start) params.set("startDate", start);
    else params.delete("startDate");

    if (end) params.set("endDate", end);
    else params.delete("endDate");

    router.push(`${pathname}?${params.toString()}`);
  };

  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  const businessId = currentUser?.businessId || "";
  const { data: branchesList = [] } = useBranchesQuery(businessId, currentUser?.id);

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3 p-6 max-w-sm border border-border/40 rounded-xl bg-card/60 backdrop-blur-sm">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <h2 className="text-lg font-bold">Unauthorized Access</h2>
          <p className="text-sm text-muted-foreground">Redirecting to login...</p>
          <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/reports/profit-loss" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Profit & Loss Report" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-border pb-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <PieChart className="h-7 w-7 text-primary" /> Profit & Loss Statement
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Gross sales revenue, cost of goods sold, operating expenses, and net profit.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 bg-card p-2 rounded-sm border border-border/60 shadow-sm text-xs">
              <div className="flex items-center gap-1.5 min-w-[140px]">
                <Building2 className="h-3.5 w-3.5 text-primary shrink-0" />
                <Select value={selectedBranchFilter} onValueChange={setBranchFilter} className="h-8 text-xs">
                  <option value="all">All Branches</option>
                  {branchesList.map((b: any) => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </Select>
              </div>

              <div className="h-4 w-px bg-border hidden sm:block" />

              <div className="flex items-center gap-1.5">
                <Calendar className="h-3.5 w-3.5 text-primary shrink-0" />
                <Input
                  type="date"
                  value={startDate}
                  onChange={(e) => setDateFilter(e.target.value, endDate)}
                  className="h-8 text-[11px] w-28"
                />
                <span className="text-muted-foreground text-[10px]">to</span>
                <Input
                  type="date"
                  value={endDate}
                  onChange={(e) => setDateFilter(startDate, e.target.value)}
                  className="h-8 text-[11px] w-28"
                />
              </div>
            </div>
          </div>

          <div className="bg-card border border-border/60 rounded-sm p-6 shadow-xl">
            <ProfitLossView
              businessId={businessId}
              startDate={startDate}
              endDate={endDate}
              branchId={selectedBranchFilter}
            />
          </div>
        </main>
      </div>
    </div>
  );
}

export default function ProfitLossPage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen w-screen items-center justify-center bg-[#121216]">
        <div className="w-8 h-8 border-4 border-zinc-700 border-t-emerald-500 rounded-full animate-spin" />
      </div>
    }>
      <ProfitLossPageContent />
    </Suspense>
  );
}
