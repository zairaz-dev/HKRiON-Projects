import { Controller, Post, Body, Get, Param, Query, UseGuards, Put, Req } from '@nestjs/common';
import { StockTransfersService } from './stock-transfers.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';
import { TransferStatus } from '@prisma/client';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('stock-transfers')
export class StockTransfersController {
  constructor(private readonly stockTransfersService: StockTransfersService) {}

  @Permissions(Permission.PRODUCT_CREATE)
  @Post()
  async createStockTransfer(@Req() req: any, @Body() body: any) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }

    const {
      transferDate,
      status,
      fromBranchId,
      toBranchId,
      businessId,
      shippingCharges,
      notes,
      createdById,
      transferLines,
    } = body;

    return this.stockTransfersService.createStockTransfer({
      transferDate: transferDate ? new Date(transferDate) : undefined,
      status: status as TransferStatus,
      fromBranchId,
      toBranchId,
      businessId,
      shippingCharges: shippingCharges ? Number(shippingCharges) : undefined,
      notes,
      createdById: createdById || user.id,
      transferLines,
    });
  }

  @Permissions(Permission.PRODUCT_VIEW)
  @Get()
  async getStockTransfers(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('fromBranchId') fromBranchId?: string,
    @Query('toBranchId') toBranchId?: string,
    @Query('status') status?: TransferStatus,
    @Query('search') search?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.stockTransfersService.getStockTransfers(bId, {
      fromBranchId,
      toBranchId,
      status,
      search,
      page: page ? Number(page) : undefined,
      limit: limit ? Number(limit) : undefined,
    });
  }

  @Permissions(Permission.PRODUCT_VIEW)
  @Get(':id')
  async getStockTransferById(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.stockTransfersService.getStockTransferById(id, bId);
  }

  @Permissions(Permission.PRODUCT_CREATE)
  @Put(':id/status')
  async updateTransferStatus(
    @Req() req: any,
    @Param('id') id: string,
    @Body() body: { businessId: string; status: TransferStatus },
  ) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }
    return this.stockTransfersService.updateTransferStatus(id, body.businessId, body.status);
  }
}

