import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, email, phone, service, message } = body;

    if (!name || !email || !service || !message) {
      return NextResponse.json(
        { error: 'Name, email, service, and message are required.' },
        { status: 400 }
      );
    }

    const savedSubmission = await prisma.contactSubmission.create({
      data: {
        name,
        email,
        phone: phone || null,
        service,
        message,
      },
    });

    return NextResponse.json(
      {
        success: true,
        message: 'HKRION team has received your message and will contact you shortly!',
        data: savedSubmission,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Contact Database Save Error:', error);
    return NextResponse.json(
      { error: 'Failed to save contact submission to database.' },
      { status: 500 }
    );
  }
}
