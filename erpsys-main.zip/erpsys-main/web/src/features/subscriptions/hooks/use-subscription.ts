import { useQuery, useMutation, useQueryClient, keepPreviousData } from '@tanstack/react-query';
import { subscriptionService } from '@/services/subscription-service';
import { queryKeys } from '@/lib/query-keys';
import { UpgradeSubscriptionInput, SubscriptionStatus } from '../types';

export function useCurrentSubscriptionQuery(businessId?: string) {
  return useQuery({
    queryKey: queryKeys.subscriptions.current(businessId || ''),
    queryFn: () => subscriptionService.getCurrentSubscription(businessId),
    enabled: !!businessId,
    placeholderData: keepPreviousData,
  });
}

export function usePlansQuery(includeInactive = false, businessId?: string) {
  return useQuery({
    queryKey: [...queryKeys.plans.list(includeInactive), businessId || 'global'],
    queryFn: () => subscriptionService.getPlans(includeInactive, businessId),
    placeholderData: keepPreviousData,
  });
}

export function useUpgradeSubscriptionMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: UpgradeSubscriptionInput) => subscriptionService.upgradePlan(input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.subscriptions.all });
    },
  });
}

export function useSuperSubscriptionsQuery() {
  return useQuery({
    queryKey: queryKeys.subscriptions.superAll(),
    queryFn: () => subscriptionService.getAllSubscriptions(),
    placeholderData: keepPreviousData,
  });
}

export function useUpdateSubscriptionStatusMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      data,
    }: {
      id: string;
      data: { status: SubscriptionStatus; endDate?: string; planId?: string };
    }) => subscriptionService.updateSubscriptionStatus(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.subscriptions.all });
    },
  });
}
