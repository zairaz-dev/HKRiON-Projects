'use client';

import { useState } from 'react';
import { 
  Search, 
  Map, 
  Palette, 
  Code, 
  TestTube, 
  Rocket, 
  LifeBuoy,
  CheckCircle2,
  Clock,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

const steps = [
  {
    step: '01',
    title: 'Discovery',
    duration: '1-2 Days',
    desc: 'Understanding business goals, requirements gathering, and technical feasibility audit.',
    deliverables: ['Requirements Audit', 'Feasibility Check', 'Scope Document'],
    icon: Search,
    image: 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?auto=format&fit=crop&w=800&q=80'
  },
  {
    step: '02',
    title: 'Planning',
    duration: '2-3 Days',
    desc: 'System architecture design, database schema planning, and roadmap milestone mapping.',
    deliverables: ['Database Schema', 'System Architecture', 'Milestone Roadmap'],
    icon: Map,
    image: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=800&q=80'
  },
  {
    step: '03',
    title: 'UI/UX Design',
    duration: '3-5 Days',
    desc: 'Crafting modern, intuitive wireframes, visual design mockups, and interactive prototypes.',
    deliverables: ['Figma Wireframes', 'Interactive Prototypes', 'Design System'],
    icon: Palette,
    image: 'https://images.unsplash.com/photo-1581291518633-83b4ebd1d83e?auto=format&fit=crop&w=800&q=80'
  },
  {
    step: '04',
    title: 'Development',
    duration: '1-3 Weeks',
    desc: 'Agile coding sprints, type-safe API integration, and modular component assembly.',
    deliverables: ['Type-Safe Next.js', 'Clean Rest/GraphQL API', 'Modular Components'],
    icon: Code,
    image: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=800&q=80'
  },
  {
    step: '05',
    title: 'Testing & Audit',
    duration: '3-4 Days',
    desc: 'Automated QA testing, security vulnerability audits, and load testing for performance.',
    deliverables: ['Automated QA', 'Vulnerability Hardening', 'Load Stress Test'],
    icon: TestTube,
    image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=800&q=80'
  },
  {
    step: '06',
    title: 'Deployment',
    duration: '1-2 Days',
    desc: 'Zero-downtime production deployment, cloud server configuration, and SSL security setup.',
    deliverables: ['AWS Cloud Setup', 'Zero-Downtime Launch', 'SSL & Domain DNS'],
    icon: Rocket,
    image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80'
  },
  {
    step: '07',
    title: 'Support & Growth',
    duration: '24/7 Ongoing',
    desc: '24/7 technical monitoring, regular software updates, and ongoing feature enhancement.',
    deliverables: ['24/7 Technical SLA', 'Security Patches', 'Feature Upgrades'],
    icon: LifeBuoy,
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80'
  }
];

export default function Process() {
  const [activeStep, setActiveStep] = useState(0);

  return (
    <section id="process" className="py-24 bg-black relative overflow-hidden border-y border-white/10">
      
      {/* Ambient background light */}
      <div className="absolute top-1/3 left-1/4 w-96 h-96 bg-[#1ABE56]/10 rounded-full blur-[160px] pointer-events-none" />
      <div className="absolute bottom-10 right-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <span className="text-xs font-mono font-bold uppercase tracking-widest text-[#1ABE56] bg-[#1ABE56]/10 px-4 py-1.5 rounded-full border border-[#1ABE56]/30 inline-block animate-pulse">
            CONNECTED EXECUTION PIPELINE
          </span>
          <h2 className="text-3xl sm:text-5xl font-semibold text-white tracking-tight">
            Our Proven <span className="gradient-text">7-Step Laser Methodology</span>
          </h2>
          <p className="text-neutral-400 text-base sm:text-lg leading-relaxed">
            From initial concept to deployment and 24/7 maintenance, we follow a transparent and connected agile pipeline.
          </p>
        </div>

        {/* Mobile Interactive Step Tabs */}
        <div className="mb-8 block md:hidden">
          <div 
            className="flex items-center gap-2.5 overflow-x-auto pb-3 scrollbar-none px-1"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {steps.map((item, idx) => {
              const Icon = item.icon;
              const isActive = activeStep === idx;

              return (
                <button
                  key={idx}
                  onClick={() => setActiveStep(idx)}
                  className={`px-4 py-2.5 rounded-xl font-mono text-xs font-semibold whitespace-nowrap flex items-center gap-2 transition-all shrink-0 cursor-pointer ${
                    isActive
                      ? 'bg-[#1ABE56] text-black shadow-md shadow-[#1ABE56]/40 font-bold scale-105'
                      : 'bg-neutral-900 text-neutral-300 border border-white/10 hover:border-[#1ABE56]/40'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-black' : 'text-[#1ABE56]'}`} />
                  <span>{item.step}. {item.title}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Desktop Frameless Interactive Laser Progress Track */}
        <div className="mb-14 hidden md:block px-6 relative">
          {/* Connecting Track Line Container */}
          <div className="absolute top-6 left-12 right-12 h-0.5 -translate-y-1/2 z-0">
            {/* Background Line */}
            <div className="w-full h-full bg-neutral-800/80 rounded-full" />
            
            {/* Active Glowing Laser Progress Line */}
            <div 
              className="absolute top-0 left-0 h-full bg-linear-to-r from-[#1ABE56] via-emerald-400 to-[#1ABE56] rounded-full transition-all duration-500 shadow-[0_0_12px_#1ABE56]"
              style={{ width: `${(activeStep / (steps.length - 1)) * 100}%` }}
            />
          </div>

          {/* Desktop Nodes Row */}
          <div className="relative z-10 flex items-center justify-between">
            {steps.map((item, idx) => {
              const Icon = item.icon;
              const isActive = activeStep === idx;
              const isPassed = activeStep > idx;

              return (
                <button
                  key={idx}
                  onClick={() => setActiveStep(idx)}
                  className="group flex flex-col items-center cursor-pointer focus:outline-none z-10"
                >
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center font-mono font-bold text-sm transition-all duration-300 relative ${
                      isActive
                        ? 'bg-[#1ABE56] text-black shadow-[0_0_25px_#1ABE56] scale-110 border-2 border-white'
                        : isPassed
                        ? 'bg-black text-[#1ABE56] border border-[#1ABE56]/60 shadow-[0_0_10px_#1ABE56/20]'
                        : 'bg-neutral-900 text-neutral-500 border border-neutral-800 hover:border-[#1ABE56]/40 hover:text-white'
                    }`}
                  >
                    <Icon className={`w-5 h-5 ${isActive ? 'text-black' : isPassed ? 'text-[#1ABE56]' : 'text-neutral-400'}`} />
                    
                    {isActive && (
                      <span className="absolute -top-1 -right-1 w-3 h-3 bg-[#1ABE56] rounded-full animate-ping" />
                    )}
                  </div>

                  <span
                    className={`mt-3 text-xs font-mono font-semibold transition-colors ${
                      isActive ? 'text-[#1ABE56]' : 'text-neutral-400 group-hover:text-white'
                    }`}
                  >
                    {item.step}. {item.title}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Stage Spotlight Card */}
        <div className="glass-card p-6 sm:p-8 rounded-3xl border border-[#1ABE56]/40 bg-linear-to-r from-neutral-950 via-black to-neutral-950 relative overflow-hidden shadow-2xl shadow-[#1ABE56]/10">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#1ABE56]/10 blur-3xl pointer-events-none" />
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
            {/* Left Info */}
            <div className="lg:col-span-7 space-y-4">
              <div className="flex items-center gap-3">
                <span className="text-4xl font-extrabold font-mono text-[#1ABE56]">
                  {steps[activeStep].step}
                </span>
                <span className="text-xs font-mono font-bold uppercase tracking-widest text-[#1ABE56] bg-[#1ABE56]/10 px-3 py-1 rounded-full border border-[#1ABE56]/30 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  Estimated Time: {steps[activeStep].duration}
                </span>
              </div>

              <h3 className="text-2xl sm:text-4xl font-extrabold text-white flex items-center gap-3">
                {steps[activeStep].title}
              </h3>

              <p className="text-neutral-300 text-sm sm:text-base leading-relaxed">
                {steps[activeStep].desc}
              </p>

              {/* Deliverables Chips */}
              <div className="pt-2">
                <p className="text-xs font-mono font-semibold text-neutral-400 mb-2 uppercase tracking-wider">
                  Key Deliverables & Milestones:
                </p>
                <div className="flex flex-wrap gap-2">
                  {steps[activeStep].deliverables.map((del, dIdx) => (
                    <span
                      key={dIdx}
                      className="text-xs font-mono bg-neutral-900 text-white px-3 py-1.5 rounded-lg border border-[#1ABE56]/30 flex items-center gap-1.5"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#1ABE56]" />
                      {del}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Interactive Stage Image Card & Mobile Controls */}
            <div className="lg:col-span-5 flex flex-col justify-center space-y-4">
              <div className="relative h-56 sm:h-64 rounded-2xl overflow-hidden border border-[#1ABE56]/40 shadow-xl bg-neutral-900 group">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={steps[activeStep].image}
                  alt={steps[activeStep].title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                
                {/* Dark gradient overlay */}
                <div className="absolute inset-0 bg-linear-to-t from-black via-black/20 to-transparent" />

                {/* Top Badge Overlay */}
                <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
                  <span className="text-[11px] font-mono text-neutral-200 bg-black/80 px-2.5 py-1 rounded-md border border-white/10 backdrop-blur-xs">
                    Stage {steps[activeStep].step}
                  </span>
                  <span className="text-[11px] font-mono text-[#1ABE56] bg-black/80 px-2.5 py-1 rounded-md border border-[#1ABE56]/40 flex items-center gap-1.5 backdrop-blur-xs">
                    <span className="w-2 h-2 rounded-full bg-[#1ABE56] animate-ping" />
                    Active Pipeline Node
                  </span>
                </div>

                {/* Bottom Overlay Info Label */}
                <div className="absolute bottom-3 left-3 right-3 p-3 rounded-xl bg-black/85 border border-white/10 backdrop-blur-md flex items-center justify-between">
                  <span className="text-xs font-mono text-neutral-300 font-semibold">Quality Standard</span>
                  <span className="text-xs font-mono text-[#1ABE56] font-bold">100% Tested & Hardened</span>
                </div>
              </div>

              {/* Mobile Navigation Prev/Next Buttons (Visible on Mobile) */}
              <div className="flex items-center justify-between pt-2 md:hidden">
                <button
                  onClick={() => setActiveStep(prev => Math.max(0, prev - 1))}
                  disabled={activeStep === 0}
                  className="px-4 py-2.5 rounded-xl bg-neutral-900 border border-white/10 text-xs font-mono text-white disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5 active:scale-95 transition-all"
                >
                  <ChevronLeft className="w-4 h-4 text-[#1ABE56]" />
                  <span>Prev Step</span>
                </button>

                <span className="text-xs font-mono text-[#1ABE56] font-bold">
                  Step {activeStep + 1} of {steps.length}
                </span>

                <button
                  onClick={() => setActiveStep(prev => Math.min(steps.length - 1, prev + 1))}
                  disabled={activeStep === steps.length - 1}
                  className="px-4 py-2.5 rounded-xl bg-[#1ABE56] text-black font-bold text-xs font-mono disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5 active:scale-95 transition-all shadow-md shadow-[#1ABE56]/30"
                >
                  <span>Next Step</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
}
