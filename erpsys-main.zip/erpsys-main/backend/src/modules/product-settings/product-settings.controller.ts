import { Controller, Get, Put, Body, Query, UseGuards, Req } from '@nestjs/common';
import { ProductSettingsService } from './product-settings.service';
import { UpdateProductSettingsDto } from './dto/product-settings.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('product-settings')
export class ProductSettingsController {
  constructor(private readonly productSettingsService: ProductSettingsService) {}

  @Get()
  async getSettings(@Req() req: any, @Query('businessId') queryBusinessId?: string) {
    const user = req.user;
    const bId = user.role === 'super-admin' && queryBusinessId ? queryBusinessId : user.businessId;
    return this.productSettingsService.getSettings(bId);
  }

  @Put()
  async updateSettings(@Req() req: any, @Body() dto: UpdateProductSettingsDto) {
    const user = req.user;
    const bId = user.role === 'super-admin' && dto.businessId ? dto.businessId : user.businessId;
    return this.productSettingsService.updateSettings(bId, dto);
  }
}
