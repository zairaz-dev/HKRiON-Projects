import React from "react";
import { AlertCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { User } from "@hkr/types";
import { CustomerGroupItem } from "../types";
import { useDeleteCustomerGroupMutation } from "../hooks/use-customer-groups";

interface CustomerGroupDeleteDialogProps {
  isOpen: boolean;
  onClose: () => void;
  customerGroup: CustomerGroupItem | null;
  currentUser: User;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

export function CustomerGroupDeleteDialog({
  isOpen,
  onClose,
  customerGroup,
  currentUser,
  onSuccess,
  onError,
}: CustomerGroupDeleteDialogProps) {
  const deleteMutation = useDeleteCustomerGroupMutation();

  const handleDelete = async () => {
    if (!customerGroup || !currentUser.businessId) return;

    try {
      await deleteMutation.mutateAsync({
        id: customerGroup.id,
        businessId: currentUser.businessId,
      });
      onSuccess("Customer group deleted successfully!");
      onClose();
    } catch (err: any) {
      onError(err.message || "Failed to delete customer group.");
    }
  };

  const isLoading = deleteMutation.isPending;

  if (!isOpen || !customerGroup) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-sm rounded-xl border border-border/50 bg-card p-5 shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-start space-x-3">
          <AlertCircle className="h-6 w-6 text-destructive shrink-0 mt-0.5" />
          <div>
            <h3 className="text-base font-bold">Delete Customer Group?</h3>
            <p className="text-xs text-muted-foreground mt-1.5">
              Are you sure you want to delete the customer group <strong className="text-foreground">"{customerGroup.name}"</strong>? This action is permanent.
            </p>
          </div>
        </div>
        <div className="flex items-center justify-end space-x-3 mt-5 pt-3 border-t border-border/40">
          <Button
            variant="outline"
            onClick={onClose}
            disabled={isLoading}
            className="h-8.5 text-xs px-3.5"
          >
            Cancel
          </Button>
          <Button
            variant="destructive"
            onClick={handleDelete}
            disabled={isLoading}
            className="h-8.5 text-xs px-3.5 flex items-center gap-1.5"
          >
            {isLoading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            Delete Group
          </Button>
        </div>
      </div>
    </div>
  );
}
