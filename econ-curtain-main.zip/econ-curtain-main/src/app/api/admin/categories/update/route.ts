import { NextResponse } from "next/server";
import { CategoryService } from "@/services/category.service";
import { SessionManager } from "@/core/auth/session";
import { SafeHttp } from "@/core/http/redirect";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  try {
    const session = await SessionManager.getCurrentSession();
    if (!session) {
      return SafeHttp.redirect("/login", request, 303);
    }

    const contentType = request.headers.get("content-type") || "";
    const isJson = contentType.includes("application/json");

    let id = "";
    let name = "";
    let description = "";
    let imageUrl = "";
    let order = 0;
    let isActive = true;

    if (isJson) {
      const body = await request.json();
      id = body.id || "";
      name = body.name || "";
      description = body.description || "";
      imageUrl = body.imageUrl || "";
      order = Number(body.order) || 0;
      isActive = body.isActive !== false;
    } else {
      const formData = await request.formData();
      id = (formData.get("id") as string) || "";
      name = (formData.get("name") as string) || "";
      description = (formData.get("description") as string) || "";
      imageUrl = (formData.get("imageUrl") as string) || "";
      order = Number(formData.get("order")) || 0;
      isActive = formData.get("isActive") === "on" || formData.get("isActive") === "true";
    }

    if (!id || !name.trim()) {
      if (isJson) {
        return NextResponse.json({ success: false, error: "Missing required fields" }, { status: 400 });
      }
      return SafeHttp.redirect("/admin/categories?error=Missing+required+fields", request, 303);
    }

    await CategoryService.update(id, {
      name,
      description,
      imageUrl,
      order,
      isActive,
    });

    revalidatePath("/admin/categories");
    revalidatePath("/admin/products");
    revalidatePath("/products");
    revalidatePath("/admin");
    revalidatePath("/");

    if (isJson) {
      return NextResponse.json({ success: true, message: "Category updated successfully" });
    }

    return SafeHttp.redirect(`/admin/categories?success=${encodeURIComponent(`Category "${name}" updated successfully!`)}`, request, 303);
  } catch (error: unknown) {
    console.error("Failed to update category:", error);
    return SafeHttp.redirect("/admin/categories?error=Failed+to+update+category", request, 303);
  }
}
