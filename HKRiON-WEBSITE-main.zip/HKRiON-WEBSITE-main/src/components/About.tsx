'use client';

import { CheckCircle2, Shield, Target, Lightbulb } from 'lucide-react';

const values = [
  {
    title: 'Precision Engineering',
    desc: 'Clean code standards, strict type-checking, and resilient software architectures built for enterprise longevity.'
  },
  {
    title: 'Agile Delivery',
    desc: 'Rapid iteration cycles with continuous deployment, keeping clients in total sync at every stage of development.'
  },
  {
    title: 'Enterprise Security',
    desc: 'Bank-grade encryption, secure MySQL database practices, role-based access control, and vulnerability hardening.'
  },
  {
    title: 'Scalable Performance',
    desc: 'Optimized serverless and containerized deployments designed to handle heavy user traffic without bottlenecking.'
  }
];

export default function About() {
  return (
    <section id="about" className="py-24 relative bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Narrative */}
          <div className="space-y-6">
            <h2 className="text-xs font-semibold uppercase tracking-widest text-[#1ABE56] font-mono">
              ABOUT HKRION (PVT) LTD
            </h2>
            <h3 className="text-3xl sm:text-5xl font-extrabold text-white leading-tight">
              We Craft Digital Products That <span className="gradient-text">Drive Innovation</span>
            </h3>
            <p className="text-neutral-300 text-base leading-relaxed">
              HKRION (Pvt) Ltd is a forward-thinking software development enterprise specializing in custom web applications, ERP platforms, cloud integration, and database systems. 
            </p>
            <p className="text-neutral-400 text-sm leading-relaxed">
              Our mission is to empower businesses with intelligent digital systems that streamline operations, enhance client engagement, and accelerate growth in a digital-first economy.
            </p>

            <div className="pt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {values.map((v, i) => (
                <div key={i} className="flex gap-3">
                  <CheckCircle2 className="w-5 h-5 text-[#1ABE56] shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-bold text-white">{v.title}</h4>
                    <p className="text-xs text-neutral-400 mt-1">{v.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column: Interactive Card Visual */}
          <div className="relative">
            <div className="absolute -inset-1 bg-linear-to-r from-[#1ABE56] to-emerald-700 rounded-3xl blur-xl opacity-30 animate-pulse-slow" />
            <div className="glass-card p-8 rounded-3xl border border-[#1ABE56]/40 relative z-10 space-y-6 bg-black/90">
              
              <div className="flex items-center justify-between pb-6 border-b border-white/10">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-[#1ABE56] animate-ping" />
                  <span className="text-sm font-mono font-semibold text-white">HKRION Operational Philosophy</span>
                </div>
                <span className="text-xs font-mono text-[#1ABE56] px-2.5 py-1 rounded-full bg-[#1ABE56]/20 border border-[#1ABE56]/40">Active</span>
              </div>

              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-neutral-900/90 border border-[#1ABE56]/30 flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-[#1ABE56]/20 flex items-center justify-center shrink-0">
                    <Target className="w-5 h-5 text-[#1ABE56]" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Target-Driven Architecture</h4>
                    <p className="text-xs text-neutral-400 mt-1">We align every line of code with your business goals and performance targets.</p>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-neutral-900/90 border border-[#1ABE56]/30 flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center shrink-0">
                    <Lightbulb className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Continuous Innovation</h4>
                    <p className="text-xs text-neutral-400 mt-1">Integrating modern frameworks, cloud tools, and intelligent data workflows.</p>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-neutral-900/90 border border-[#1ABE56]/30 flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center shrink-0">
                    <Shield className="w-5 h-5 text-green-400" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Production-Ready Reliability</h4>
                    <p className="text-xs text-neutral-400 mt-1">MySQL relational schemas and type-safe APIs for seamless data handling.</p>
                  </div>
                </div>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
