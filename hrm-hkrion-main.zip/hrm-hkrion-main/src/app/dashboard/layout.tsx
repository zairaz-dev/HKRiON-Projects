import { getSession } from "@/lib/session";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import Sidebar from "@/components/layout/sidebar";
import Topbar from "@/components/layout/topbar";
import InactivityTimer from "@/components/layout/inactivity-timer";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getSession();

  if (!session) {
    redirect("/login");
  }

  const [user, notifications] = await Promise.all([
    prisma.user.findUnique({
      where: { id: session.userId },
      select: { 
        firstName: true, 
        lastName: true, 
        email: true, 
        profileImage: true,
        position: { select: { title: true } }
      },
    }),
    prisma.notification.findMany({
      where: { userId: session.userId },
      orderBy: { createdAt: "desc" },
      take: 10,
    }),
  ]);

  const userName = user ? `${user.firstName} ${user.lastName}` : `User #${session.userId}`;
  const initials = user ? `${user.firstName.charAt(0)}${user.lastName.charAt(0)}` : "SA";
  const profileImage = user?.profileImage;

  return (
    <div className="flex h-screen overflow-hidden bg-background text-text-primary">
      <InactivityTimer />
      
      {/* Sidebar */}
      <Sidebar role={session.role} />

      {/* Main content area */}
      <div className="flex flex-1 flex-col overflow-hidden relative">
        {/* Topbar */}
        <Topbar 
          userName={userName} 
          initials={initials} 
          role={session.role} 
          profileImage={profileImage} 
          initialNotifications={notifications} 
          userEmail={user?.email}
        />

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 custom-scrollbar">{children}</main>
      </div>
    </div>
  );
}
