"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Settings as SettingsIcon,
  Building2,
  Percent,
  Package,
  Monitor,
  CreditCard,
  Hash,
  Mail,
  MessageSquare,
  Search,
  ChevronRight,
  ChevronLeft,
  FileText,
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface SettingItem {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
}

export default function SettingsPage() {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState("");

  const handleCardClick = (id: string) => {
    if (id === "business") {
      router.push("/settings/business");
    } else if (id === "tax") {
      router.push("/settings/tax");
    } else if (id === "invoice") {
      router.push("/settings/invoice");
    } else if (id === "product") {
      router.push("/settings/product");
    } else if (id === "pos") {
      router.push("/settings/pos");
    } else if (id === "payment") {
      router.push("/settings/payment");
    } else if (id === "prefixes") {
      router.push("/settings/prefixes");
    } else if (id === "sms") {
      router.push("/settings/sms");
    } else if (id === "email") {
      router.push("/settings/email");
    } else if (id === "subscription") {
      router.push("/settings/subscription");
    }
  };

  // Only active, fully-implemented settings
  const settingsList: SettingItem[] = [
    {
      id: "subscription",
      title: "Plan & Subscription",
      description: "Manage your active SaaS plan, resource limits, upgrade tiers, and invoice history...",
      icon: CreditCard,
    },
    {
      id: "business",
      title: "Business Settings",
      description: "Business name, logo, country, currency, contact numbers, financial year...",
      icon: Building2,
    },
    {
      id: "pos",
      title: "POS Settings",
      description: "Branch-wise POS preferences, express cash checkout, auto-print, sound effects & hotkeys...",
      icon: Monitor,
    },
    {
      id: "product",
      title: "Product Settings",
      description: "Default profit margin %, auto-SKU generation, barcode types, and expiry alerts...",
      icon: Package,
    },
    {
      id: "tax",
      title: "Tax Settings",
      description: "Tax rates, CGST/SGST/VAT configurations, and combined tax groups...",
      icon: Percent,
    },
    {
      id: "invoice",
      title: "Invoice & Layout Settings",
      description: "Invoice numbering schemes, custom receipt layouts, logo & thermal paper sizes...",
      icon: FileText,
    },
    {
      id: "payment",
      title: "Payment Methods",
      description: "Manage payment gateways and methods (Cash, Card, UPI, Bank Transfer)...",
      icon: CreditCard,
    },
    {
      id: "prefixes",
      title: "Prefix Settings",
      description: "Customize reference code prefixes for invoices, purchases, and orders...",
      icon: Hash,
    },
    {
      id: "sms",
      title: "SMS Gateway Settings",
      description: "SMS provider configuration (Twilio, BulkSMS), and automated customer notifications...",
      icon: MessageSquare,
    },
    {
      id: "email",
      title: "Email & SMTP Settings",
      description: "SMTP mail server configuration, presets (Gmail, SendGrid), and transaction email alerts...",
      icon: Mail,
    },
  ];

  // Filter settings based on search query
  const filteredSettings = settingsList.filter(
    (item) =>
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/settings" />
      <div className="flex-1 flex flex-col overflow-hidden relative">
        <Navbar title="Settings" />

        <main className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Top Navigation / Header Actions (Exact User Profile Page Style) */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border pb-4">
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => router.push("/dashboard")}
                className="h-8 px-2.5 rounded-sm border-border hover:bg-secondary/40 text-xs font-mono cursor-pointer"
              >
                <ChevronLeft className="w-3.5 h-3.5 mr-1" /> Dashboard
              </Button>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-base sm:text-lg font-bold uppercase tracking-wider font-mono text-foreground flex items-center gap-2">
                    <SettingsIcon className="h-5 w-5 text-primary" /> System Settings
                  </h1>
                  <span className="text-[10px] text-muted-foreground font-mono">
                    #{settingsList.length} MODULES
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Configure organization profile, POS terminals, tax rates, invoice schemes, and communication gateways.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 text-xs font-mono font-bold px-2.5 py-1 rounded-sm border uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border-emerald-500/30">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Live Enterprise System
              </span>
            </div>
          </div>

          {/* Full Width Search Settings Bar */}
          <div className="relative">
            <Input
              type="text"
              placeholder="Search active settings (e.g. POS, Product, Tax, SMS, Email, Invoice)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              icon={<Search className="h-4 w-4 text-muted-foreground" />}
              className="w-full h-10 bg-card/40 border-border/70 placeholder:text-muted-foreground/60 text-xs focus:ring-primary/30"
            />
          </div>

          {/* Expansive Responsive Settings Grid (Full Width) */}
          <div className="w-full pb-8">
            {filteredSettings.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {filteredSettings.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Card
                      key={item.id}
                      onClick={() => handleCardClick(item.id)}
                      className="group cursor-pointer border border-border/70 hover:border-primary/40 bg-card/60 hover:bg-card transition-all duration-200 shadow-sm flex flex-col justify-between"
                    >
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="w-9 h-9 rounded-sm bg-primary/10 border border-primary/20 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-200">
                            <Icon className="w-4 h-4" />
                          </div>
                          <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-0.5 transition-all duration-200" />
                        </div>

                        <div className="space-y-1">
                          <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-foreground group-hover:text-primary transition-colors">
                            {item.title}
                          </h3>
                          <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed">
                            {item.description}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-12 text-sm text-muted-foreground italic border border-dashed border-border/40 rounded-sm bg-card/10 font-mono">
                No matching settings found.
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
