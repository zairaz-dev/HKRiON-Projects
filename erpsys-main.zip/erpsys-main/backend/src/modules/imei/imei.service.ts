import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { BulkAddImeiDto, UpdateImeiStatusDto, QueryImeiDto } from './dto/imei.dto';
import { randomUUID } from 'crypto';

@Injectable()
export class ImeiService {
  constructor(private readonly prisma: PrismaService) {}

  async searchImei(businessId: string, query: string) {
    if (!query || query.trim() === '') {
      return [];
    }

    const trimmed = query.trim();

    if ((this.prisma as any).productImei) {
      return (this.prisma as any).productImei.findMany({
        where: {
          businessId,
          imeiNumber: { contains: trimmed, mode: 'insensitive' },
        },
        include: {
          product: { select: { id: true, name: true, type: true, imageUrl: true } },
          variant: { select: { id: true, name: true, sku: true, sellingPrice: true, purchasePrice: true } },
          branch: { select: { id: true, name: true } },
          saleLine: {
            include: {
              sale: {
                select: {
                  id: true,
                  invoiceNumber: true,
                  saleDate: true,
                  customer: { select: { id: true, name: true, phone: true } },
                },
              },
            },
          },
        },
        take: 20,
      });
    }

    // Direct database query fallback
    const rows: any[] = await this.prisma.$queryRawUnsafe(
      `SELECT 
        i.*,
        p.name as "productName",
        v.name as "variantName", v.sku as "variantSku", v."sellingPrice",
        b.name as "branchName"
       FROM "ProductImei" i
       LEFT JOIN "Product" p ON i."productId" = p.id
       LEFT JOIN "ProductVariant" v ON i."variantId" = v.id
       LEFT JOIN "Branch" b ON i."branchId" = b.id
       WHERE i."businessId" = $1 AND i."imeiNumber" ILIKE $2
       LIMIT 20`,
      businessId,
      `%${trimmed}%`,
    );

    return rows;
  }

  async getAvailableImeis(businessId: string, variantId: string, branchId?: string) {
    if ((this.prisma as any).productImei) {
      const whereClause: any = {
        businessId,
        variantId,
        status: 'IN_STOCK',
      };
      if (branchId && branchId !== 'all') {
        whereClause.branchId = branchId;
      }
      return (this.prisma as any).productImei.findMany({
        where: whereClause,
        orderBy: { createdAt: 'desc' },
      });
    }

    if (branchId && branchId !== 'all') {
      return this.prisma.$queryRawUnsafe(
        `SELECT * FROM "ProductImei" 
         WHERE "businessId" = $1 AND "variantId" = $2 AND "branchId" = $3 AND "status" = 'IN_STOCK'
         ORDER BY "createdAt" DESC`,
        businessId,
        variantId,
        branchId,
      );
    } else {
      return this.prisma.$queryRawUnsafe(
        `SELECT * FROM "ProductImei" 
         WHERE "businessId" = $1 AND "variantId" = $2 AND "status" = 'IN_STOCK'
         ORDER BY "createdAt" DESC`,
        businessId,
        variantId,
      );
    }
  }

  async getImeiList(businessId: string, queryDto: QueryImeiDto) {
    const page = Math.max(1, Number(queryDto.page) || 1);
    const limit = Math.max(1, Math.min(100, Number(queryDto.limit) || 20));
    const skip = (page - 1) * limit;

    const whereObj: any = { businessId };
    if (queryDto.branchId && queryDto.branchId !== 'all') whereObj.branchId = queryDto.branchId;
    if (queryDto.productId) whereObj.productId = queryDto.productId;
    if (queryDto.variantId) whereObj.variantId = queryDto.variantId;
    if (queryDto.status) whereObj.status = queryDto.status;
    if (queryDto.search) {
      whereObj.imeiNumber = { contains: queryDto.search, mode: 'insensitive' };
    }

    if ((this.prisma as any).productImei) {
      const [items, total] = await Promise.all([
        (this.prisma as any).productImei.findMany({
          where: whereObj,
          include: {
            product: { select: { id: true, name: true } },
            variant: { select: { id: true, name: true, sku: true, sellingPrice: true } },
            branch: { select: { id: true, name: true } },
          },
          orderBy: { createdAt: 'desc' },
          skip,
          take: limit,
        }),
        (this.prisma as any).productImei.count({ where: whereObj }),
      ]);

      return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
    }

    // Direct database raw query fallback
    const items: any[] = await this.prisma.$queryRawUnsafe(
      `SELECT 
        i.*,
        json_build_object('id', p.id, 'name', p.name) as product,
        json_build_object('id', v.id, 'name', v.name, 'sku', v.sku, 'sellingPrice', v."sellingPrice") as variant,
        json_build_object('id', b.id, 'name', b.name) as branch
       FROM "ProductImei" i
       LEFT JOIN "Product" p ON i."productId" = p.id
       LEFT JOIN "ProductVariant" v ON i."variantId" = v.id
       LEFT JOIN "Branch" b ON i."branchId" = b.id
       WHERE i."businessId" = $1
       ORDER BY i."createdAt" DESC
       LIMIT $2 OFFSET $3`,
      businessId,
      limit,
      skip,
    );

    const countRows: any[] = await this.prisma.$queryRawUnsafe(
      `SELECT COUNT(*)::int as total FROM "ProductImei" WHERE "businessId" = $1`,
      businessId,
    );
    const total = countRows[0]?.total || 0;

    return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
  }

  async bulkAddImeis(businessId: string, dto: BulkAddImeiDto) {
    if (!dto.imeis || dto.imeis.length === 0) {
      throw new BadRequestException('No IMEI numbers provided.');
    }

    const createdList: any[] = [];
    for (const item of dto.imeis) {
      if (!item.imeiNumber || item.imeiNumber.trim() === '') continue;

      const trimmedImei = item.imeiNumber.trim();

      if ((this.prisma as any).productImei) {
        const created = await (this.prisma as any).productImei.upsert({
          where: {
            imeiNumber_businessId: {
              imeiNumber: trimmedImei,
              businessId,
            },
          },
          create: {
            imeiNumber: trimmedImei,
            status: 'IN_STOCK',
            productId: dto.productId,
            variantId: dto.variantId,
            branchId: dto.branchId,
            businessId,
            purchaseLineId: dto.purchaseLineId,
            notes: dto.notes,
          },
          update: {
            branchId: dto.branchId,
            productId: dto.productId,
            variantId: dto.variantId,
            notes: dto.notes,
          },
        });
        createdList.push(created);
      } else {
        const newId = randomUUID();
        await this.prisma.$executeRawUnsafe(
          `INSERT INTO "ProductImei" 
           ("id", "imeiNumber", "status", "productId", "variantId", "branchId", "businessId", "purchaseLineId", "notes", "createdAt", "updatedAt") 
           VALUES ($1, $2, 'IN_STOCK', $3, $4, $5, $6, $7, $8, NOW(), NOW())
           ON CONFLICT ("imeiNumber", "businessId") DO UPDATE SET "branchId" = $5, "updatedAt" = NOW()`,
          newId,
          trimmedImei,
          dto.productId,
          dto.variantId,
          dto.branchId,
          businessId,
          dto.purchaseLineId,
          dto.notes,
        );
        createdList.push({ id: newId, imeiNumber: trimmedImei });
      }
    }

    return {
      success: true,
      count: createdList.length,
      items: createdList,
    };
  }

  async updateImeiStatus(id: string, businessId: string, dto: UpdateImeiStatusDto) {
    if ((this.prisma as any).productImei) {
      return (this.prisma as any).productImei.update({
        where: { id, businessId },
        data: {
          status: dto.status,
          saleLineId: dto.saleLineId,
          soldDate: dto.soldDate,
          warrantyExpires: dto.warrantyExpires,
          notes: dto.notes,
        },
      });
    }

    await this.prisma.$executeRawUnsafe(
      `UPDATE "ProductImei" SET "status" = $1, "updatedAt" = NOW() WHERE "id" = $2 AND "businessId" = $3`,
      dto.status,
      id,
      businessId,
    );

    const rows: any[] = await this.prisma.$queryRawUnsafe(
      `SELECT * FROM "ProductImei" WHERE "id" = $1 LIMIT 1`,
      id,
    );
    return rows[0];
  }
}
