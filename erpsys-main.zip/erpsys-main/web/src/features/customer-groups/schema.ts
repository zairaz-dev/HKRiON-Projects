import * as z from "zod";

export const customerGroupFormSchema = z.object({
  name: z
    .string()
    .min(1, "Group name is required")
    .max(100, "Group name must be under 100 characters"),
  percentageDiscount: z.number().min(0, "Discount must be 0 or greater"),
  sellingPriceGroupId: z.string().nullable().optional(),
  branchIds: z.array(z.string()),
  isActive: z.boolean(),
});

export type CustomerGroupFormSchema = z.infer<typeof customerGroupFormSchema>;
