import { useQuery } from "@tanstack/react-query";
import { reportService } from "@/services/report-service";
import { queryKeys } from "@/lib/query-keys";

export function useSalesPurchasesQuery(
  businessId: string,
  filters: {
    startDate?: string;
    endDate?: string;
    branchId?: string;
  },
) {
  return useQuery({
    queryKey: queryKeys.reports.salesPurchases(
      businessId,
      filters.startDate,
      filters.endDate,
      filters.branchId,
    ),
    queryFn: () => reportService.getSalesPurchaseSummary(businessId, filters),
    enabled: !!businessId,
  });
}
