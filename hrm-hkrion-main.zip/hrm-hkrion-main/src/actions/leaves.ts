"use server";

import { prisma } from "@/lib/db";
import { getSession } from "@/lib/session";
import { revalidatePath } from "next/cache";
import { Role, LeaveStatus } from "@prisma/client";
import { LeaveRequestSchema } from "@/lib/schemas";

export async function submitLeaveRequest(formData: FormData) {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    const parsed = LeaveRequestSchema.safeParse(Object.fromEntries(formData));
    if (!parsed.success) {
      return { error: parsed.error.issues[0].message };
    }
    const data = parsed.data;

    const startDate = new Date(data.startDate);
    const endDate = new Date(data.endDate);

    // Overlap prevention: Check if user already has a pending or approved request covering these dates
    const overlapping = await prisma.leaveRequest.findFirst({
      where: {
        userId: session.userId,
        status: { in: [LeaveStatus.PENDING, LeaveStatus.APPROVED] },
        startDate: { lte: endDate },
        endDate: { gte: startDate },
      },
    });

    if (overlapping) {
      return { error: "You already have a pending or approved leave request covering these dates." };
    }

    const user = await prisma.user.findUnique({
      where: { id: session.userId },
      select: { firstName: true, lastName: true, managerId: true },
    });

    await prisma.$transaction(async (tx) => {
      const leave = await tx.leaveRequest.create({
        data: {
          userId: session.userId,
          startDate,
          endDate,
          reason: data.reason,
          status: LeaveStatus.PENDING,
        },
      });

      await tx.auditLog.create({
        data: {
          userId: session.userId,
          action: "SUBMIT_LEAVE",
          details: `Submitted leave request for ${data.startDate} to ${data.endDate} (ID: ${leave.id})`,
        },
      });

      // If user has an assigned manager, notify the manager
      if (user?.managerId) {
        await tx.notification.create({
          data: {
            userId: user.managerId,
            title: "New Leave Request",
            message: `${user.firstName} ${user.lastName} submitted a leave request for ${data.startDate} to ${data.endDate}.`,
            link: "/dashboard/leaves",
          },
        });
      }
    });

    revalidatePath("/dashboard/leaves");
    return { success: true };
  } catch (error) {
    console.error("Failed to submit leave request:", error);
    return { error: "Failed to submit leave request." };
  }
}

export async function getLeaveRequests() {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    const currentUser = await prisma.user.findUnique({
      where: { id: session.userId },
      include: { subordinates: true },
    });

    if (!currentUser) return { error: "User not found" };

    let records;

    const includeUser = {
      user: {
        select: {
          firstName: true,
          lastName: true,
          email: true,
        },
      },
    };

    if (session.role === Role.SUPER_ADMIN || session.role === Role.MANAGER) {
      // Admins and Managers see all requests
      records = await prisma.leaveRequest.findMany({
        include: includeUser,
        orderBy: { createdAt: "desc" },
      });
    } else if (currentUser.subordinates.length > 0) {
      // Managers see their own and their subordinates' requests
      const subordinateIds = currentUser.subordinates.map((sub) => sub.id);
      records = await prisma.leaveRequest.findMany({
        where: {
          userId: { in: [session.userId, ...subordinateIds] },
        },
        include: includeUser,
        orderBy: { createdAt: "desc" },
      });
    } else {
      // Regular employees see only their own
      records = await prisma.leaveRequest.findMany({
        where: {
          userId: session.userId,
        },
        include: includeUser,
        orderBy: { createdAt: "desc" },
      });
    }

    return { data: records, currentUserId: session.userId, isAdmin: session.role === Role.SUPER_ADMIN || session.role === Role.MANAGER };
  } catch (error) {
    console.error("Failed to fetch leave requests:", error);
    return { error: "Failed to fetch leave requests." };
  }
}

export async function updateLeaveStatus(id: number, newStatus: LeaveStatus) {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    const leaveRequest = await prisma.leaveRequest.findUnique({
      where: { id },
      include: { user: true },
    });

    if (!leaveRequest) {
      return { error: "Leave request not found." };
    }

    const isAdmin = session.role === Role.SUPER_ADMIN || session.role === Role.MANAGER;
    const isDirectManager = leaveRequest.user.managerId === session.userId;

    if (!isAdmin && !isDirectManager) {
      return { error: "Unauthorized to update this request." };
    }

    // Only Super Admins can approve their own requests; Managers cannot approve their own
    if (leaveRequest.userId === session.userId && session.role !== Role.SUPER_ADMIN) {
      return { error: "You cannot approve your own leave request." };
    }

    await prisma.$transaction(async (tx) => {
      await tx.leaveRequest.update({
        where: { id },
        data: {
          status: newStatus,
        },
      });

      await tx.auditLog.create({
        data: {
          userId: session.userId,
          action: "UPDATE_LEAVE_STATUS",
          details: `Updated leave request ID ${id} (${leaveRequest.user.email}) to ${newStatus}`,
        },
      });

      // Send in-app notification to the employee
      const statusLabel = newStatus === LeaveStatus.APPROVED ? "approved" : "rejected";
      await tx.notification.create({
        data: {
          userId: leaveRequest.userId,
          title: `Leave Request ${newStatus === LeaveStatus.APPROVED ? "Approved" : "Rejected"}`,
          message: `Your leave request from ${leaveRequest.startDate.toISOString().split("T")[0]} to ${leaveRequest.endDate.toISOString().split("T")[0]} has been ${statusLabel}.`,
          link: "/dashboard/leaves",
        },
      });
    });

    revalidatePath("/dashboard/leaves");
    return { success: true };
  } catch (error) {
    console.error("Failed to update leave status:", error);
    return { error: "Failed to update leave status." };
  }
}
