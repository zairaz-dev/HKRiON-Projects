"use strict";
"use client";

import React, { useEffect, useState } from "react";
import {
  Coins,
  Plus,
  Edit2,
  Trash2,
  Loader2,
  CheckCircle,
  AlertCircle,
  X,
  Building2,
  Globe
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { DataTable, ColumnDef, ActionsDropdown } from "@/components/ui/table";
import { ActionItem } from "@/components/ui/actions-dropdown";
import { authService } from "@/services/auth-service";
import { branchService } from "@/services/branch-service";
import { sellingPriceGroupService } from "@/services/selling-price-group-service";
import { User } from "@hkr/types";

interface BranchItem {
  id: string;
  name: string;
}

interface SPGBranchItem {
  branchId: string;
  branch: BranchItem;
}

interface SPGItem {
  id: string;
  name: string;
  description: string | null;
  isActive: boolean;
  businessId: string;
  createdAt: string;
  updatedAt: string;
  branches?: SPGBranchItem[];
}

export default function SellingPriceGroupsPage() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Core Data State
  const [spgList, setSpgList] = useState<SPGItem[]>([]);
  const [branchesList, setBranchesList] = useState<BranchItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [actionLoading, setActionLoading] = useState<boolean>(false);

  // Filter State
  const [selectedBranchFilter, setSelectedBranchFilter] = useState<string>("all");

  // Notifications
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [modalMode, setModalMode] = useState<"create" | "edit">("create");
  const [editingSpgId, setEditingSpgId] = useState<string>("");

  // Form State
  const [formName, setFormName] = useState<string>("");
  const [formDescription, setFormDescription] = useState<string>("");
  const [formBranchIds, setFormBranchIds] = useState<string[]>([]);
  const [formIsActive, setFormIsActive] = useState<boolean>(true);

  // Delete Confirmation State
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState<boolean>(false);
  const [spgToDelete, setSpgToDelete] = useState<SPGItem | null>(null);

  // Auth & Initial Fetch
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
      return;
    }

    if (user) {
      fetchData(user);
    }
  }, []);

  const fetchData = async (userObj: User) => {
    setLoading(true);
    setError("");
    try {
      const businessId = userObj.businessId;
      if (!businessId) return;

      const [spgData, branchesData] = await Promise.all([
        sellingPriceGroupService.getSellingPriceGroups(businessId),
        branchService.getBranches(businessId, userObj.id)
      ]);

      setSpgList(spgData);
      setBranchesList(branchesData);
    } catch (err: any) {
      setError(err.message || "Failed to load selling price groups.");
    } finally {
      setLoading(false);
    }
  };

  // Auto-dismiss Notifications
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  const handleOpenCreateModal = () => {
    setError("");
    setModalMode("create");
    setEditingSpgId("");
    setFormName("");
    setFormDescription("");
    setFormBranchIds([]);
    setFormIsActive(true);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (spg: SPGItem) => {
    setError("");
    setModalMode("edit");
    setEditingSpgId(spg.id);
    setFormName(spg.name);
    setFormDescription(spg.description || "");
    
    const assignedBranchIds = spg.branches?.map((ub) => ub.branch.id) || [];
    setFormBranchIds(assignedBranchIds);
    setFormIsActive(spg.isActive);
    setIsModalOpen(true);
  };

  const handleToggleBranchForm = (branchId: string) => {
    setFormBranchIds((prev) =>
      prev.includes(branchId)
        ? prev.filter((id) => id !== branchId)
        : [...prev, branchId]
    );
  };

  const handleOpenDeleteConfirm = (spg: SPGItem) => {
    setError("");
    setSpgToDelete(spg);
    setIsDeleteConfirmOpen(true);
  };

  const handleSpgSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = formName.trim();
    if (!trimmedName) {
      setError("Group Name is required.");
      return;
    }
    if (trimmedName.length < 2 || trimmedName.length > 100) {
      setError("Group Name must be between 2 and 100 characters.");
      return;
    }
    if (formDescription && formDescription.trim().length > 500) {
      setError("Description cannot exceed 500 characters.");
      return;
    }
    if (!currentUser?.businessId) return;

    setActionLoading(true);
    setError("");

    const payload = {
      name: trimmedName,
      description: formDescription.trim() || undefined,
      businessId: currentUser.businessId,
      branchIds: formBranchIds,
      isActive: formIsActive,
      createdById: modalMode === "create" ? currentUser.id : undefined,
      updatedById: modalMode === "edit" ? currentUser.id : undefined,
    };

    try {
      if (modalMode === "create") {
        await sellingPriceGroupService.createSellingPriceGroup(payload);
        setSuccessMessage("Selling price group created successfully!");
      } else {
        await sellingPriceGroupService.updateSellingPriceGroup(editingSpgId, payload);
        setSuccessMessage("Selling price group updated successfully!");
      }
      setIsModalOpen(false);
      fetchData(currentUser);
    } catch (err: any) {
      setError(err.message || "Failed to save selling price group.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteSpg = async () => {
    if (!spgToDelete || !currentUser?.businessId) return;
    setActionLoading(true);
    setError("");
    try {
      await sellingPriceGroupService.deleteSellingPriceGroup(spgToDelete.id, currentUser.businessId);
      setSuccessMessage("Selling price group deleted successfully!");
      setIsDeleteConfirmOpen(false);
      fetchData(currentUser);
    } catch (err: any) {
      setError(err.message || "Failed to delete selling price group.");
    } finally {
      setActionLoading(false);
    }
  };

  // Filter Logic
  const getFilteredSpg = () => {
    let list = spgList;

    if (selectedBranchFilter !== "all") {
      if (selectedBranchFilter === "global") {
        list = list.filter((s) => !s.branches || s.branches.length === 0);
      } else {
        list = list.filter((s) =>
          s.branches?.some((ub) => ub.branch.id === selectedBranchFilter)
        );
      }
    }

    return list;
  };

  const filteredList = getFilteredSpg();

  // Columns Definition
  const columns: ColumnDef<SPGItem>[] = [
    {
      header: "Group Name",
      searchable: true,
      render: (spg) => (
        <div>
          <span className="font-semibold text-foreground block">{spg.name}</span>
          {spg.description && (
            <span className="text-xs text-muted-foreground block truncate max-w-[250px]">
              {spg.description}
            </span>
          )}
        </div>
      ),
    },
    {
      header: "Branch Scope",
      render: (spg) => {
        if (!spg.branches || spg.branches.length === 0) {
          return (
            <span className="inline-flex items-center gap-1 text-xs text-muted-foreground font-medium">
              <Globe className="h-3.5 w-3.5 text-muted-foreground/60" />
              Global
            </span>
          );
        }
        if (spg.branches.length === 1) {
          return (
            <span className="inline-flex items-center gap-1 text-xs text-foreground/80 font-medium">
              <Building2 className="h-3.5 w-3.5 text-muted-foreground/60" />
              {spg.branches[0].branch.name}
            </span>
          );
        }
        return (
          <span className="inline-flex items-center gap-1 text-xs text-primary font-medium">
            <Building2 className="h-3.5 w-3.5 text-primary/60" />
            {spg.branches.length} Branches
          </span>
        );
      },
    },
    {
      header: "Status",
      render: (spg) => (
        <span
          className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${
            spg.isActive
              ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
              : "bg-destructive/10 text-destructive border-destructive/20"
          }`}
        >
          {spg.isActive ? "Active" : "Inactive"}
        </span>
      ),
    },
    {
      header: "Actions",
      render: (spg) => {
        const actions: ActionItem[] = [
          {
            label: "Edit",
            onClick: () => handleOpenEditModal(spg),
            icon: <Edit2 className="h-3.5 w-3.5" />,
          },
          {
            label: "Delete",
            onClick: () => handleOpenDeleteConfirm(spg),
            icon: <Trash2 className="h-3.5 w-3.5" />,
            variant: "destructive",
          },
        ];
        return <ActionsDropdown actions={actions} />;
      },
    },
  ];

  const customFilters = (
    <div className="flex items-center gap-2">
      <span className="text-xs font-semibold text-muted-foreground whitespace-nowrap">
        Branch:
      </span>
      <select
        value={selectedBranchFilter}
        onChange={(e) => setSelectedBranchFilter(e.target.value)}
        className="h-9 rounded-md border border-input bg-background px-3 py-1 text-xs shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
      >
        <option value="all">All Branches</option>
        <option value="global">Global (No Branch)</option>
        {branchesList.map((b) => (
          <option key={b.id} value={b.id}>
            {b.name}
          </option>
        ))}
      </select>
    </div>
  );

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3 p-6 max-w-sm border border-border/40 rounded-xl bg-card/60 backdrop-blur-sm">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <h2 className="text-lg font-bold">Unauthorized Access</h2>
          <p className="text-sm text-muted-foreground">
            You need to be logged in to view this page. Redirecting to login...
          </p>
          <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/selling-price-groups" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Selling Price Groups" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <Coins className="h-7 w-7 text-primary" /> Selling Price Groups
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Manage different price categories (e.g., Wholesale, Retail) for products and map them to branches.
              </p>
            </div>
          </div>

          {/* Banner Notifications */}
          {successMessage && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 animate-in fade-in slide-in-from-top-4 duration-300">
              <CheckCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive animate-in fade-in slide-in-from-top-4 duration-300">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          {loading ? (
            <div className="flex h-64 items-center justify-center">
              <div className="text-center space-y-2">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
                <span className="text-sm text-muted-foreground block">Loading price groups...</span>
              </div>
            </div>
          ) : (
            <DataTable
              data={filteredList}
              columns={columns}
              searchKeys={["name"]}
              actionButton={{
                label: "Add Price Group",
                onClick: handleOpenCreateModal,
                icon: <Plus className="h-4 w-4" />
              }}
              customFilters={customFilters}
              reportTitle="Selling Price Groups Report"
            />
          )}
        </main>
      </div>

      {/* Create / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-xl border border-border/50 bg-card p-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-border/50 pb-3 mb-4">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <Coins className="h-5 w-5 text-primary" />
                {modalMode === "create" ? "Create Selling Price Group" : "Edit Price Group"}
              </h3>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsModalOpen(false)}
                className="h-8 w-8 rounded-full"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            <form onSubmit={handleSpgSubmit} className="space-y-4">
              {error && (
                <div className="p-3 rounded-md bg-destructive/15 border border-destructive/30 text-destructive text-xs flex items-center gap-2 animate-in fade-in duration-200">
                  <AlertCircle className="h-4 w-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}
              {/* Name */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-muted-foreground uppercase">
                  Group Name <span className="text-destructive">*</span>
                </label>
                <Input
                  placeholder="e.g., Wholesale, Retail, Distributor"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  required
                  disabled={actionLoading}
                />
              </div>

              {/* Description */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-muted-foreground uppercase">
                  Description
                </label>
                <Input
                  placeholder="Optional description"
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  disabled={actionLoading}
                />
              </div>

              {/* Branch Scope */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-muted-foreground uppercase block">
                  Branch Mapping (Optional - Leave empty for Global)
                </label>
                <div className="grid grid-cols-2 gap-2 max-h-24 overflow-y-auto border border-border/40 rounded-md p-2 bg-background/50">
                  {branchesList.map((branch) => {
                    const isChecked = formBranchIds.includes(branch.id);
                    return (
                      <div
                        key={branch.id}
                        onClick={() => handleToggleBranchForm(branch.id)}
                        className={`flex items-center space-x-2 p-1.5 rounded-md cursor-pointer border text-xs font-medium transition-all ${
                          isChecked
                            ? "bg-primary/10 border-primary/30 text-primary"
                            : "bg-transparent border-transparent hover:bg-secondary/40 text-muted-foreground"
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}} // Handled by onClick on div
                          className="rounded text-primary focus:ring-0 cursor-pointer"
                        />
                        <span className="truncate">{branch.name}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Status */}
              <div className="flex items-center space-x-2 py-1">
                <input
                  type="checkbox"
                  id="isActive"
                  checked={formIsActive}
                  onChange={(e) => setFormIsActive(e.target.checked)}
                  disabled={actionLoading}
                  className="rounded text-primary focus:ring-0 cursor-pointer h-4 w-4"
                />
                <label htmlFor="isActive" className="text-xs font-semibold cursor-pointer select-none">
                  Active (Allow using this price group in product prices)
                </label>
              </div>

              {/* Form Buttons */}
              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-border/50">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsModalOpen(false)}
                  disabled={actionLoading}
                  className="h-9 px-4 text-xs"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={actionLoading}
                  className="h-9 px-4 text-xs flex items-center gap-1.5"
                >
                  {actionLoading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                  {modalMode === "create" ? "Create Group" : "Save Changes"}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      {isDeleteConfirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="w-full max-w-sm rounded-xl border border-border/50 bg-card p-5 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-start space-x-3">
              <AlertCircle className="h-6 w-6 text-destructive shrink-0 mt-0.5" />
              <div>
                <h3 className="text-base font-bold">Delete Price Group?</h3>
                {error && (
                  <div className="p-2.5 my-2 rounded-md bg-destructive/15 border border-destructive/30 text-destructive text-xs animate-in fade-in duration-200">
                    {error}
                  </div>
                )}
                <p className="text-xs text-muted-foreground mt-1.5">
                  Are you sure you want to delete the selling price group <strong className="text-foreground">"{spgToDelete?.name}"</strong>? This action is permanent.
                </p>
              </div>
            </div>
            <div className="flex items-center justify-end space-x-3 mt-5 pt-3 border-t border-border/40">
              <Button
                variant="outline"
                onClick={() => setIsDeleteConfirmOpen(false)}
                disabled={actionLoading}
                className="h-8.5 text-xs px-3.5"
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={handleDeleteSpg}
                disabled={actionLoading}
                className="h-8.5 text-xs px-3.5 flex items-center gap-1.5"
              >
                {actionLoading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                Delete Group
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
