import React, { useState } from "react";
import { X, Search, ShoppingBag, Loader2, ArrowRight, Calendar, User as UserIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiFetch } from "@/lib/api";
import { useCurrency } from "@/hooks/use-currency";

interface SelectSaleDialogProps {
  isOpen: boolean;
  onClose: () => void;
  businessId: string;
  onSelectSale: (sale: any) => void;
}

export function SelectSaleDialog({
  isOpen,
  onClose,
  businessId,
  onSelectSale,
}: SelectSaleDialogProps) {
  const { symbol } = useCurrency(businessId);
  const [search, setSearch] = useState("");
  const [sales, setSales] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  if (!isOpen) return null;

  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoading(true);
    setSearched(true);
    try {
      const baseUrl = process.env.NEXT_PUBLIC_API_URL;
      const res = await apiFetch(
        `${baseUrl}/pos/sales?businessId=${businessId}&search=${encodeURIComponent(search)}&limit=10`,
      );
      if (res.ok) {
        const data = await res.json();
        setSales(data.data || []);
      } else {
        setSales([]);
      }
    } catch {
      setSales([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
      <div className="w-full max-w-2xl rounded-xl border border-border bg-card p-6 shadow-2xl animate-in zoom-in-95 duration-200 flex flex-col max-h-[85vh] overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border pb-3 mb-4 shrink-0">
          <div className="flex items-center gap-2">
            <ShoppingBag className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-bold">Select Sales Invoice to Return</h3>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="h-8 w-8 rounded-full"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="flex gap-2 mb-4 shrink-0">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Enter Invoice Ref # (e.g. POS-2026-0001) or customer name..."
              className="pl-9 h-9 text-xs"
              autoFocus
            />
          </div>
          <Button type="submit" disabled={loading} className="h-9 text-xs gap-1.5">
            {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Search className="h-3.5 w-3.5" />}
            Search
          </Button>
        </form>

        {/* Results List */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
          {!searched && sales.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground space-y-1">
              <ShoppingBag className="h-8 w-8 mx-auto text-muted-foreground/40 mb-2" />
              <p className="text-xs">Type invoice number or customer name above and click Search.</p>
            </div>
          ) : loading ? (
            <div className="p-8 text-center text-muted-foreground">
              <Loader2 className="h-6 w-6 animate-spin mx-auto mb-2 text-primary" />
              <span className="text-xs">Searching sales invoices...</span>
            </div>
          ) : sales.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">
              No matching sales invoices found.
            </div>
          ) : (
            sales.map((sale) => (
              <div
                key={sale.id}
                className="p-3.5 rounded-lg border border-border/60 bg-muted/20 hover:bg-muted/40 transition-colors flex items-center justify-between gap-4"
              >
                <div className="space-y-1 min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-foreground text-sm">
                      #{sale.invoiceNumber}
                    </span>
                    <span className={`inline-flex px-1.5 py-0.5 rounded text-[10px] font-bold ${sale.paymentStatus === "PAID" ? "bg-emerald-500/10 text-emerald-500" : "bg-amber-500/10 text-amber-500"}`}>
                      {sale.paymentStatus}
                    </span>
                  </div>

                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <UserIcon className="h-3 w-3 text-primary" />
                      {sale.customer?.name || "Walk-in Customer"}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3 w-3 text-primary" />
                      {new Date(sale.saleDate).toLocaleDateString("en-IN", {
                        day: "2-digit",
                        month: "short",
                        year: "numeric",
                      })}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <span className="font-mono font-extrabold text-foreground text-sm">
                    {symbol}{sale.grandTotal?.toFixed(2)}
                  </span>
                  <Button
                    size="sm"
                    onClick={() => onSelectSale(sale)}
                    className="h-8 text-xs gap-1"
                  >
                    Select
                    <ArrowRight className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
