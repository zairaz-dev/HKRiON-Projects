import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supplierAdvanceService } from "@/services/supplier-advance-service";
import { queryKeys } from "@/lib/query-keys";

export function useSupplierAdvancesQuery(
  businessId: string,
  filters: { supplierId?: string; branchId?: string; onlyRemaining?: boolean } = {}
) {
  return useQuery({
    queryKey: queryKeys.supplierAdvances.list(businessId, filters.supplierId, filters.branchId),
    queryFn: () => supplierAdvanceService.getAdvances(businessId, filters),
    enabled: !!businessId,
  });
}

export function useCreateSupplierAdvanceMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: Parameters<typeof supplierAdvanceService.createAdvance>[0]) =>
      supplierAdvanceService.createAdvance(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.supplierAdvances.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.suppliers.all });
    },
  });
}

export function useDeleteSupplierAdvanceMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, businessId }: { id: string; businessId: string }) =>
      supplierAdvanceService.deleteAdvance(id, businessId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.supplierAdvances.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.suppliers.all });
    },
  });
}

export function useAllocateSupplierAdvanceMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: Parameters<typeof supplierAdvanceService.allocateAdvance>[0]) =>
      supplierAdvanceService.allocateAdvance(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.supplierAdvances.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.purchases.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.suppliers.all });
    },
  });
}

export function useDeleteSupplierAdvanceAllocationMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, businessId }: { id: string; businessId: string }) =>
      supplierAdvanceService.deleteAllocation(id, businessId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.supplierAdvances.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.purchases.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.suppliers.all });
    },
  });
}

export function useRefundSupplierAdvanceMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: Parameters<typeof supplierAdvanceService.refundAdvance>[0]) =>
      supplierAdvanceService.refundAdvance(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.supplierAdvances.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.suppliers.all });
    },
  });
}

