import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import pool from "@/lib/db";
import { RowDataPacket } from "mysql2";
import {
  verifyCustomerSessionToken,
  verifySessionToken,
  CUSTOMER_SESSION_COOKIE_NAME,
  SESSION_COOKIE_NAME,
} from "@/lib/auth";

export async function GET() {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get(CUSTOMER_SESSION_COOKIE_NAME)?.value;
    const adminToken = cookieStore.get(SESSION_COOKIE_NAME)?.value;

    let session: { id?: string; name: string; email: string; phone?: string; role: "ADMIN" | "CUSTOMER" } | null = null;

    if (adminToken) {
      const adminSession = verifySessionToken(adminToken);
      if (adminSession) {
        session = {
          id: "admin-vault-officer",
          name: adminSession.name,
          email: adminSession.email,
          role: "ADMIN",
        };
      }
    }

    if (!session && token) {
      session = verifyCustomerSessionToken(token);
    }

    if (!session) {
      return NextResponse.json({ authenticated: false, user: null });
    }

    // Refresh user profile details from database
    let userDetails = {
      id: session.id || "admin-user",
      name: session.name,
      email: session.email,
      phone: session.phone || "",
      role: session.role,
      tier: session.role === "ADMIN" ? "Vault Administrator" : "Regular Customer",
      location: "Sri Lanka",
      salon: "Sri Lanka",
      totalSpent: 0,
      acquisitions: 0,
    };

    try {
      const [userRows] = await pool.query<RowDataPacket[]>(
        "SELECT id, name, email, phone, role FROM users WHERE email = ? LIMIT 1",
        [session.email]
      );
      if (userRows && userRows.length > 0) {
        userDetails.id = userRows[0].id || userDetails.id;
        userDetails.name = userRows[0].name || session.name;
        userDetails.phone = userRows[0].phone || session.phone || "";
        if (userRows[0].role === "ADMIN" || session.role === "ADMIN") {
          userDetails.role = "ADMIN";
          userDetails.tier = "Vault Administrator";
        }
      }

      const [clientRows] = await pool.query<RowDataPacket[]>(
        "SELECT tier, location, total_spent, acquisitions FROM clients WHERE email = ? LIMIT 1",
        [session.email]
      );
      if (clientRows && clientRows.length > 0) {
        const loc = clientRows[0].location || "Sri Lanka";
        userDetails.tier = clientRows[0].tier || "Regular Customer";
        userDetails.location = loc;
        userDetails.salon = loc;
        userDetails.totalSpent = Number(clientRows[0].total_spent || 0);
        userDetails.acquisitions = Number(clientRows[0].acquisitions || 0);
      }
    } catch {
      // Fallback to session values if offline
    }

    return NextResponse.json({
      authenticated: true,
      user: userDetails,
    });
  } catch (error) {
    console.error("Session verification error:", error);
    return NextResponse.json({ authenticated: false, user: null });
  }
}
