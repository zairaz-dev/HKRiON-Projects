"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Mail,
  ChevronLeft,
  Loader2,
  CheckCircle,
  Save,
  Info,
  Send,
  Server,
  Key,
  ShieldCheck,
  RotateCcw,
  Sparkles,
  ShoppingBag,
  CreditCard,
  Hash,
  AtSign,
  User,
  Zap,
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { authService } from "@/services/auth-service";
import {
  emailSettingsService,
  EmailSettingsData,
} from "@/services/email-settings-service";

export default function EmailSettingsPage() {
  const router = useRouter();

  const [currentUser, setCurrentUser] = useState<any>(null);
  const [businessId, setBusinessId] = useState<string>("");

  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [testingEmail, setTestingEmail] = useState<boolean>(false);

  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Test Email State
  const [testRecipient, setTestRecipient] = useState<string>("");
  const [testResult, setTestResult] = useState<{
    success: boolean;
    message?: string;
    details?: any;
    error?: string;
  } | null>(null);

  const defaultFormState: EmailSettingsData = {
    enableEmailNotifications: false,
    mailDriver: "smtp",
    mailHost: "",
    mailPort: 587,
    mailUsername: "",
    mailPassword: "",
    mailEncryption: "tls",
    mailFromAddress: "",
    mailFromName: "",
    sendSaleInvoiceEmail: true,
    sendPaymentReceiptEmail: true,
    sendPurchaseOrderEmail: true,
  };

  const [emailForm, setEmailForm] =
    useState<EmailSettingsData>(defaultFormState);

  useEffect(() => {
    const user = authService.getCurrentUser();
    if (!user || !user.businessId) {
      router.push("/login");
      return;
    }
    setCurrentUser(user);
    setBusinessId(user.businessId);

    loadEmailSettings(user.businessId);
  }, []);

  const loadEmailSettings = async (bId: string) => {
    setLoading(true);
    setError("");
    try {
      const data = await emailSettingsService.getSettings(bId);
      setEmailForm({
        ...defaultFormState,
        ...data,
        mailHost: data.mailHost || "",
        mailUsername: data.mailUsername || "",
        mailPassword: data.mailPassword || "",
        mailFromAddress: data.mailFromAddress || "",
        mailFromName: data.mailFromName || "",
      });
    } catch (err: any) {
      setError(err.message || "Failed to load email settings.");
    } finally {
      setLoading(false);
    }
  };

  const showSuccess = (msg: string) => {
    setSuccessMessage(msg);
    setTimeout(() => setSuccessMessage(""), 4000);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      await emailSettingsService.updateSettings({
        ...emailForm,
        businessId,
        mailPort: Number(emailForm.mailPort) || 587,
      });
      showSuccess("SMTP and email notification settings saved successfully!");
    } catch (err: any) {
      setError(err.message || "Failed to save email settings.");
    } finally {
      setSaving(false);
    }
  };

  const handleSendTestEmail = async () => {
    if (!testRecipient) {
      setError("Please enter a recipient email address to test.");
      return;
    }
    setTestingEmail(true);
    setTestResult(null);
    setError("");
    try {
      const res = await emailSettingsService.sendTestEmail({
        businessId,
        recipientEmail: testRecipient,
      });
      setTestResult(res);
      if (res.success) {
        showSuccess(res.message || "Test email verified successfully!");
      }
    } catch (err: any) {
      setTestResult({
        success: false,
        error: err.message || "Failed to send test email.",
      });
    } finally {
      setTestingEmail(false);
    }
  };

  const applyPreset = (preset: "gmail" | "sendgrid" | "mailgun" | "outlook") => {
    if (preset === "gmail") {
      setEmailForm((prev) => ({
        ...prev,
        mailHost: "smtp.gmail.com",
        mailPort: 587,
        mailEncryption: "tls",
      }));
    } else if (preset === "sendgrid") {
      setEmailForm((prev) => ({
        ...prev,
        mailHost: "smtp.sendgrid.net",
        mailPort: 587,
        mailEncryption: "tls",
        mailUsername: "apikey",
      }));
    } else if (preset === "mailgun") {
      setEmailForm((prev) => ({
        ...prev,
        mailHost: "smtp.mailgun.org",
        mailPort: 587,
        mailEncryption: "tls",
      }));
    } else if (preset === "outlook") {
      setEmailForm((prev) => ({
        ...prev,
        mailHost: "smtp.office365.com",
        mailPort: 587,
        mailEncryption: "tls",
      }));
    }
    showSuccess(`Applied ${preset.toUpperCase()} SMTP settings.`);
  };

  const handleResetDefaults = () => {
    setEmailForm(defaultFormState);
    showSuccess("Reset to default settings.");
  };

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/settings" />
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Ambient Glowing Orbs */}
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-primary/5 blur-[120px] pointer-events-none z-0" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[550px] h-[550px] rounded-full bg-primary/5 blur-[130px] pointer-events-none z-0" />

        <Navbar title="Email Settings" className="relative z-10" />

        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 relative z-10">
          <div className="max-w-4xl mx-auto space-y-6">

            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <button
                  onClick={() => router.push("/settings")}
                  className="inline-flex items-center text-xs font-semibold text-muted-foreground hover:text-primary mb-2 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4 mr-1" /> Back to Settings
                </button>
                <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                  <Mail className="h-7 w-7 text-primary" /> Email Settings
                </h1>
                <p className="text-sm text-muted-foreground mt-1">
                  Configure SMTP mail server, sender details, and automated transaction email notifications.
                </p>
              </div>

              {/* Master Email Toggle Badge */}
              <div className="flex items-center gap-3 bg-card/60 border border-border/60 p-2 px-3.5 rounded-xl backdrop-blur-md shadow-sm">
                <div className="flex flex-col">
                  <span className="text-xs font-bold text-foreground">
                    Email Service: {emailForm.enableEmailNotifications ? "Active" : "Disabled"}
                  </span>
                  <span className="text-[10px] text-muted-foreground">
                    Master sending switch
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={emailForm.enableEmailNotifications}
                  onChange={(e) =>
                    setEmailForm({
                      ...emailForm,
                      enableEmailNotifications: e.target.checked,
                    })
                  }
                  className="w-5 h-5 text-primary rounded accent-primary cursor-pointer"
                />
              </div>
            </div>

            {/* Notifications */}
            {successMessage && (
              <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 p-3 rounded-lg text-sm flex items-center gap-2 animate-in fade-in">
                <CheckCircle className="w-4 h-4 shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}

            {error && (
              <div className="bg-destructive/10 border border-destructive/30 text-destructive p-3 rounded-lg text-sm flex items-center gap-2 animate-in fade-in">
                <Info className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {loading ? (
              <div className="flex items-center justify-center py-16 text-muted-foreground">
                <Loader2 className="w-6 h-6 animate-spin mr-2 text-primary" /> Loading Email configurations...
              </div>
            ) : (
              <form onSubmit={handleSave} className="space-y-6 pb-16">

                {/* Section 1: SMTP Server Configuration */}
                <Card className="border border-border/50 bg-card/30 backdrop-blur-md">
                  <CardContent className="p-5 space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border/40 pb-3">
                      <div className="flex items-center gap-2">
                        <div className="p-1.5 rounded-lg bg-primary/10 text-primary">
                          <Server className="w-5 h-5" />
                        </div>
                        <div>
                          <h2 className="text-sm font-bold text-foreground">SMTP Mail Server Settings</h2>
                          <p className="text-xs text-muted-foreground">
                            Connect your email service via secure SMTP protocol.
                          </p>
                        </div>
                      </div>

                      {/* Quick Presets */}
                      <div className="flex items-center gap-1.5 bg-background/50 p-1 rounded-lg border border-border/40">
                        <span className="text-[10px] text-muted-foreground font-semibold px-1">Presets:</span>
                        <button
                          type="button"
                          onClick={() => applyPreset("gmail")}
                          className="px-2 py-0.5 text-[10px] font-bold rounded bg-card hover:bg-primary/10 hover:text-primary transition-colors"
                        >
                          Gmail
                        </button>
                        <button
                          type="button"
                          onClick={() => applyPreset("outlook")}
                          className="px-2 py-0.5 text-[10px] font-bold rounded bg-card hover:bg-primary/10 hover:text-primary transition-colors"
                        >
                          Outlook
                        </button>
                        <button
                          type="button"
                          onClick={() => applyPreset("sendgrid")}
                          className="px-2 py-0.5 text-[10px] font-bold rounded bg-card hover:bg-primary/10 hover:text-primary transition-colors"
                        >
                          SendGrid
                        </button>
                        <button
                          type="button"
                          onClick={() => applyPreset("mailgun")}
                          className="px-2 py-0.5 text-[10px] font-bold rounded bg-card hover:bg-primary/10 hover:text-primary transition-colors"
                        >
                          Mailgun
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
                      {/* Mail Host */}
                      <div className="space-y-1.5 md:col-span-2">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <Server className="w-3.5 h-3.5 text-primary" /> Mail Host (SMTP Server)
                        </label>
                        <Input
                          type="text"
                          value={emailForm.mailHost || ""}
                          onChange={(e) =>
                            setEmailForm({ ...emailForm, mailHost: e.target.value })
                          }
                          className="font-mono text-xs h-10"
                          placeholder="e.g. smtp.gmail.com"
                        />
                      </div>

                      {/* Mail Port */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <Hash className="w-3.5 h-3.5 text-primary" /> SMTP Port
                        </label>
                        <Input
                          type="number"
                          value={emailForm.mailPort}
                          onChange={(e) =>
                            setEmailForm({
                              ...emailForm,
                              mailPort: parseInt(e.target.value) || 587,
                            })
                          }
                          className="font-mono text-xs h-10"
                          placeholder="587"
                        />
                      </div>

                      {/* Mail Username */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <AtSign className="w-3.5 h-3.5 text-primary" /> Mail Username / Email
                        </label>
                        <Input
                          type="text"
                          value={emailForm.mailUsername || ""}
                          onChange={(e) =>
                            setEmailForm({ ...emailForm, mailUsername: e.target.value })
                          }
                          className="font-mono text-xs h-10"
                          placeholder="your-email@gmail.com"
                        />
                      </div>

                      {/* Mail Password */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <Key className="w-3.5 h-3.5 text-primary" /> Mail Password / App Secret
                        </label>
                        <Input
                          type="password"
                          value={emailForm.mailPassword || ""}
                          onChange={(e) =>
                            setEmailForm({ ...emailForm, mailPassword: e.target.value })
                          }
                          className="font-mono text-xs h-10"
                          placeholder="App password or SMTP key"
                        />
                      </div>

                      {/* Encryption */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <ShieldCheck className="w-3.5 h-3.5 text-primary" /> Encryption Type
                        </label>
                        <select
                          value={emailForm.mailEncryption}
                          onChange={(e) =>
                            setEmailForm({ ...emailForm, mailEncryption: e.target.value })
                          }
                          className="w-full h-10 px-3 rounded-md bg-background/80 border border-border/60 text-xs font-mono font-bold focus:ring-1 focus:ring-primary focus:outline-none"
                        >
                          <option value="tls">TLS (Port 587 - Recommended)</option>
                          <option value="ssl">SSL (Port 465)</option>
                          <option value="none">None (Port 25)</option>
                        </select>
                      </div>

                      {/* From Email Address */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <Mail className="w-3.5 h-3.5 text-primary" /> From Email Address
                        </label>
                        <Input
                          type="email"
                          value={emailForm.mailFromAddress || ""}
                          onChange={(e) =>
                            setEmailForm({ ...emailForm, mailFromAddress: e.target.value })
                          }
                          className="font-mono text-xs h-10"
                          placeholder="billing@company.com"
                        />
                      </div>

                      {/* From Name */}
                      <div className="space-y-1.5 md:col-span-2">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-primary" /> From Sender Name
                        </label>
                        <Input
                          type="text"
                          value={emailForm.mailFromName || ""}
                          onChange={(e) =>
                            setEmailForm({ ...emailForm, mailFromName: e.target.value })
                          }
                          className="text-xs h-10"
                          placeholder="HKRION ERP Invoicing"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Section 2: Automated Email Triggers */}
                <Card className="border border-border/50 bg-card/30 backdrop-blur-md">
                  <CardContent className="p-5 space-y-4">
                    <div className="flex items-center gap-2 border-b border-border/40 pb-3">
                      <div className="p-1.5 rounded-lg bg-primary/10 text-primary">
                        <Zap className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-sm font-bold text-foreground">Automated Transaction Notifications</h2>
                        <p className="text-xs text-muted-foreground">
                          Select which business actions automatically send email copies to customers & suppliers.
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
                      {/* Sale Invoice */}
                      <div className="p-3.5 rounded-xl border border-border/40 bg-background/50 flex flex-col justify-between space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold flex items-center gap-1.5">
                            <ShoppingBag className="w-4 h-4 text-emerald-500" /> Sales Invoice
                          </span>
                          <input
                            type="checkbox"
                            checked={emailForm.sendSaleInvoiceEmail}
                            onChange={(e) =>
                              setEmailForm({
                                ...emailForm,
                                sendSaleInvoiceEmail: e.target.checked,
                              })
                            }
                            className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                          />
                        </div>
                        <p className="text-[10px] text-muted-foreground">
                          Email invoice PDF upon sales checkout.
                        </p>
                      </div>

                      {/* Payment Receipt */}
                      <div className="p-3.5 rounded-xl border border-border/40 bg-background/50 flex flex-col justify-between space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold flex items-center gap-1.5">
                            <CreditCard className="w-4 h-4 text-indigo-400" /> Payment Receipt
                          </span>
                          <input
                            type="checkbox"
                            checked={emailForm.sendPaymentReceiptEmail}
                            onChange={(e) =>
                              setEmailForm({
                                ...emailForm,
                                sendPaymentReceiptEmail: e.target.checked,
                              })
                            }
                            className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                          />
                        </div>
                        <p className="text-[10px] text-muted-foreground">
                          Email payment receipt voucher to customer.
                        </p>
                      </div>

                      {/* Purchase Order */}
                      <div className="p-3.5 rounded-xl border border-border/40 bg-background/50 flex flex-col justify-between space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold flex items-center gap-1.5">
                            <Mail className="w-4 h-4 text-amber-500" /> Purchase Orders
                          </span>
                          <input
                            type="checkbox"
                            checked={emailForm.sendPurchaseOrderEmail}
                            onChange={(e) =>
                              setEmailForm({
                                ...emailForm,
                                sendPurchaseOrderEmail: e.target.checked,
                              })
                            }
                            className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                          />
                        </div>
                        <p className="text-[10px] text-muted-foreground">
                          Send PO copy directly to supplier's email.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Section 3: Live SMTP Tester */}
                <Card className="border border-border/50 bg-card/30 backdrop-blur-md">
                  <CardContent className="p-5 space-y-4">
                    <div className="flex items-center gap-2 border-b border-border/40 pb-3">
                      <div className="p-1.5 rounded-lg bg-primary/10 text-primary">
                        <Send className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-sm font-bold text-foreground">Live SMTP Email Tester</h2>
                        <p className="text-xs text-muted-foreground">
                          Verify your SMTP connection by dispatching a test email.
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row items-end gap-3 pt-1">
                      <div className="space-y-1.5 flex-1 w-full">
                        <label className="text-xs font-semibold">Test Recipient Email Address</label>
                        <Input
                          type="email"
                          value={testRecipient}
                          onChange={(e) => setTestRecipient(e.target.value)}
                          placeholder="recipient@example.com"
                          className="h-10 text-xs font-mono"
                        />
                      </div>
                      <Button
                        type="button"
                        onClick={handleSendTestEmail}
                        disabled={testingEmail}
                        className="h-10 gap-2 min-w-[150px]"
                      >
                        {testingEmail ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Send className="w-4 h-4" />
                        )}
                        Send Test Email
                      </Button>
                    </div>

                    {/* Result Output */}
                    {testResult && (
                      <div
                        className={`p-3 rounded-lg border text-xs font-mono mt-2 space-y-1.5 ${
                          testResult.success
                            ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-500"
                            : "bg-destructive/10 border-destructive/30 text-destructive"
                        }`}
                      >
                        <div className="font-bold flex items-center gap-1.5">
                          {testResult.success ? (
                            <CheckCircle className="w-4 h-4" />
                          ) : (
                            <Info className="w-4 h-4" />
                          )}
                          Status: {testResult.success ? "Success" : "Failed"}
                        </div>
                        {testResult.message && (
                          <div className="text-[11px] text-foreground/80">
                            {testResult.message}
                          </div>
                        )}
                        {testResult.details && (
                          <div className="text-[11px] text-foreground/80 bg-background/60 p-2 rounded">
                            <pre className="text-[10px]">
                              {JSON.stringify(testResult.details, null, 2)}
                            </pre>
                          </div>
                        )}
                        {testResult.error && (
                          <div className="text-[11px] text-destructive">
                            {testResult.error}
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Actions */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-border/60">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleResetDefaults}
                    className="text-xs text-muted-foreground hover:text-foreground gap-1.5"
                  >
                    <RotateCcw className="w-3.5 h-3.5" /> Reset Defaults
                  </Button>

                  <Button
                    type="submit"
                    disabled={saving}
                    className="gap-2 min-w-[170px] shadow-md shadow-primary/10"
                  >
                    {saving ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Save className="w-4 h-4" />
                    )}
                    Save Email Settings
                  </Button>
                </div>

              </form>
            )}

          </div>
        </main>
      </div>
    </div>
  );
}
