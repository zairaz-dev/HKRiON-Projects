'use client';

import Image from 'next/image';
import { Send, Mail, Phone, MapPin, Globe, Share2 } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black text-neutral-400 border-t border-[#1ABE56]/30 pt-16 pb-12 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Top Newsletter Section */}
        <div className="glass-card p-8 sm:p-12 rounded-3xl border border-[#1ABE56]/40 bg-neutral-950 mb-16 flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="space-y-2 text-center lg:text-left max-w-xl">
            <h3 className="text-2xl font-bold text-white">Subscribe to HKRION Tech Insights</h3>
            <p className="text-sm text-neutral-400">
              Get the latest updates on ERP innovations, IoT smart systems, and cloud architecture trends.
            </p>
          </div>
          <form onSubmit={(e) => e.preventDefault()} className="flex flex-col sm:flex-row items-center gap-3 w-full lg:w-auto">
            <input
              type="email"
              placeholder="Enter your business email"
              className="w-full sm:w-80 px-4 py-3 rounded-xl bg-neutral-900 border border-[#1ABE56]/30 text-white placeholder-neutral-500 text-sm focus:outline-none focus:border-[#1ABE56]"
            />
            <button
              type="submit"
              className="w-full sm:w-auto glow-btn px-6 py-3 rounded-xl text-sm font-semibold text-white flex items-center justify-center gap-2 shrink-0"
            >
              <span>Subscribe</span>
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>

        {/* Footer Navigation Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-white/10">
          
          {/* Col 1: Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="relative h-9 w-auto flex items-center justify-center">
                <Image 
                  src="/assets/logos/logo.png" 
                  alt="HKRION (Pvt) Ltd Logo" 
                  width={36} 
                  height={36} 
                  className="h-full w-auto object-contain"
                />
              </div>
              <span className="text-xl font-black text-white font-outfit tracking-tight">
                HKRION <span className="text-[#1ABE56] text-xs font-normal font-sans">(Pvt) Ltd</span>
              </span>
            </div>

            <p className="text-sm text-neutral-400 leading-relaxed max-w-sm">
              HKRION (Pvt) Ltd is a next-generation software enterprise delivering Enterprise ERPs, IoT Hardware Telemetry, Custom Web/Mobile Applications, and Cloud Infrastructure in Sri Lanka & Globally.
            </p>

            <div className="space-y-2 text-xs text-neutral-300 font-mono pt-2">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#1ABE56]" />
                <span>Trincomalee, Sri Lanka</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#1ABE56]" />
                <span>+94 77 50 14 217</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#1ABE56]" />
                <span>contact@hkrion.com</span>
              </div>
            </div>
          </div>

          {/* Col 2: Core Services */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider font-mono">Services</h4>
            <ul className="space-y-2 text-xs">
              <li><a href="#services" className="hover:text-[#1ABE56] transition-colors">ERP & HRM Systems</a></li>
              <li><a href="#services" className="hover:text-[#1ABE56] transition-colors">IoT Smart Automation</a></li>
              <li><a href="#services" className="hover:text-[#1ABE56] transition-colors">Custom Web Apps</a></li>
              <li><a href="#services" className="hover:text-[#1ABE56] transition-colors">Mobile Development</a></li>
              <li><a href="#services" className="hover:text-[#1ABE56] transition-colors">Digital Marketing</a></li>
              <li><a href="#services" className="hover:text-[#1ABE56] transition-colors">IT Consulting</a></li>
            </ul>
          </div>

          {/* Col 3: Products Suite */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider font-mono">HKRION Products</h4>
            <ul className="space-y-2 text-xs">
              <li><a href="#products" className="hover:text-[#1ABE56] transition-colors">IHM TECH POS</a></li>
              <li><a href="#products" className="hover:text-[#1ABE56] transition-colors">HKRION ERP</a></li>
              <li><a href="#products" className="hover:text-[#1ABE56] transition-colors">HKRION HRM</a></li>
            </ul>
          </div>

          {/* Col 4: Company & Legal */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider font-mono">Company</h4>
            <ul className="space-y-2 text-xs">
              <li><a href="/about" className="hover:text-[#1ABE56] transition-colors">About Us</a></li>
              <li><a href="/careers" className="hover:text-[#1ABE56] transition-colors flex items-center gap-1.5 text-[#1ABE56] font-semibold">Careers <span className="text-[9px] bg-[#1ABE56]/20 px-1.5 py-0.5 rounded border border-[#1ABE56]/40">Hiring</span></a></li>
              <li><a href="#casestudies" className="hover:text-[#1ABE56] transition-colors">Case Studies</a></li>
              <li><a href="#faq" className="hover:text-[#1ABE56] transition-colors">FAQ & Support</a></li>
              <li><a href="#contact" className="hover:text-[#1ABE56] transition-colors">Privacy Policy</a></li>
              <li><a href="#contact" className="hover:text-[#1ABE56] transition-colors">Terms of Service</a></li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono">
          <p>© {new Date().getFullYear()} HKRION (Pvt) Ltd. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <a href="#" aria-label="Website" className="w-8 h-8 rounded-lg bg-neutral-900 border border-white/10 flex items-center justify-center hover:border-[#1ABE56] hover:text-[#1ABE56] transition-all">
              <Globe className="w-4 h-4" />
            </a>
            <a href="#" aria-label="Share" className="w-8 h-8 rounded-lg bg-neutral-900 border border-white/10 flex items-center justify-center hover:border-[#1ABE56] hover:text-[#1ABE56] transition-all">
              <Share2 className="w-4 h-4" />
            </a>
          </div>
        </div>

      </div>
    </footer>
  );
}
