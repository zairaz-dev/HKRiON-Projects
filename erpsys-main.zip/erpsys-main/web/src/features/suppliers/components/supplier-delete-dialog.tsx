import React from "react";
import { AlertCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { User } from "@hkr/types";
import { SupplierItem } from "../types";
import { useDeleteSupplierMutation } from "../hooks/use-suppliers";

interface SupplierDeleteDialogProps {
  isOpen: boolean;
  onClose: () => void;
  supplier: SupplierItem | null;
  currentUser: User;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

export function SupplierDeleteDialog({
  isOpen,
  onClose,
  supplier,
  currentUser,
  onSuccess,
  onError,
}: SupplierDeleteDialogProps) {
  const deleteMutation = useDeleteSupplierMutation();

  const handleDelete = async () => {
    if (!supplier || !currentUser.businessId) return;

    try {
      await deleteMutation.mutateAsync({
        id: supplier.id,
        businessId: currentUser.businessId,
      });
      onSuccess("Supplier deleted successfully!");
      onClose();
    } catch (err: any) {
      onError(err.message || "Failed to delete supplier.");
    }
  };

  const isLoading = deleteMutation.isPending;

  if (!isOpen || !supplier) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-sm rounded-xl border border-border/50 bg-card p-5 shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-start space-x-3">
          <AlertCircle className="h-6 w-6 text-destructive shrink-0 mt-0.5" />
          <div>
            <h3 className="text-base font-bold">Delete Supplier?</h3>
            <p className="text-xs text-muted-foreground mt-1.5">
              Are you sure you want to delete the supplier <strong className="text-foreground">"{supplier.name}"</strong>? This action is permanent and cannot be undone.
            </p>
          </div>
        </div>
        <div className="flex items-center justify-end space-x-3 mt-5 pt-3 border-t border-border/40">
          <Button
            variant="outline"
            onClick={onClose}
            disabled={isLoading}
            className="h-8.5 text-xs px-3.5"
          >
            Cancel
          </Button>
          <Button
            variant="destructive"
            onClick={handleDelete}
            disabled={isLoading}
            className="h-8.5 text-xs px-3.5 flex items-center gap-1.5"
          >
            {isLoading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            Delete Supplier
          </Button>
        </div>
      </div>
    </div>
  );
}
