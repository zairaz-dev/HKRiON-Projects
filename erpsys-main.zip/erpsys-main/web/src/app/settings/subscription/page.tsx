"use strict";
"use client";

import React, { useEffect, useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { authService } from "@/services/auth-service";
import { LoadingSession } from "@/components/ui/loading-session";
import { User } from "@hkr/types";
import {
  useCurrentSubscriptionQuery,
  usePlansQuery,
  UsageMeter,
  PricingCards,
  BillingHistoryTable,
} from "@/features/subscriptions";
import { Card, CardContent } from "@/components/ui/card";
import {
  CreditCard,
  Sparkles,
  Calendar,
  Clock,
  ShieldCheck,
  AlertCircle,
  RefreshCw,
} from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function SubscriptionBillingPage() {
  const [mounted, setMounted] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  useEffect(() => {
    setMounted(true);
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 1500);
    }
  }, []);

  const businessId = currentUser?.businessId || "";

  const {
    data: subData,
    isLoading: isSubLoading,
    refetch: refetchSub,
  } = useCurrentSubscriptionQuery(businessId);

  const { data: plansData, isLoading: isPlansLoading } = usePlansQuery(false, businessId);

  if (!mounted || isAuthenticated === null || (isAuthenticated && !currentUser)) {
    return <LoadingSession />;
  }

  if (isAuthenticated === false) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4 text-center">
        <h2 className="text-xl font-bold text-foreground">Access Denied</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Please sign in to view subscription and billing.
        </p>
      </div>
    );
  }

  const subscription = subData?.subscription;
  const plan = subData?.plan;
  const usage = subData?.usage;
  const invoices = subData?.invoices || [];

  const isTrial = subscription?.status === "TRIAL";
  const isExpired = subscription?.status === "EXPIRED";
  const isActive = subscription?.status === "ACTIVE";

  const getStatusBadge = () => {
    if (isTrial) {
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30">
          <Clock className="w-3.5 h-3.5" /> FREE TRIAL
        </span>
      );
    }
    if (isExpired) {
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-500/10 text-rose-400 border border-rose-500/30">
          <AlertCircle className="w-3.5 h-3.5" /> EXPIRED
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
        <ShieldCheck className="w-3.5 h-3.5" /> ACTIVE
      </span>
    );
  };

  return (
    <div className="h-screen bg-background text-foreground flex overflow-hidden">
      <Sidebar activePath="/settings" />

      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Billing & Subscription" />

        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <Link
                  href="/settings"
                  className="text-xs text-muted-foreground hover:text-foreground font-mono"
                >
                  Settings
                </Link>
                <span className="text-muted-foreground">/</span>
                <span className="text-xs text-foreground font-bold font-mono">Subscription</span>
              </div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5 mt-1">
                <CreditCard className="h-7 w-7 text-primary" /> Plan & Subscription
              </h1>
              <p className="text-xs text-muted-foreground mt-1">
                Manage your organization subscription plan, resource usage quotas, and billing invoices.
              </p>
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={() => refetchSub()}
              className="text-xs h-9 gap-1.5 w-fit"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Refresh Quotas
            </Button>
          </div>

          {isSubLoading ? (
            <div className="p-12 text-center text-xs text-muted-foreground">
              Loading subscription details...
            </div>
          ) : (
            <div className="space-y-6 pb-12">
              {/* Active Plan Overview Card */}
              <Card className="bg-gradient-to-r from-primary/10 via-card/60 to-card/40 backdrop-blur-md border-primary/25 shadow-md">
                <CardContent className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                    <div className="space-y-2">
                      <div className="flex items-center gap-3">
                        <h2 className="text-2xl font-extrabold text-foreground tracking-tight">
                          {plan?.name || "Free Trial"}
                        </h2>
                        {getStatusBadge()}
                      </div>
                      <p className="text-xs text-muted-foreground max-w-xl">
                        {plan?.description ||
                          "Enjoying full-featured access to the ERP system with high-speed processing."}
                      </p>

                      <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-muted-foreground pt-1">
                        <div className="flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5 text-primary" />
                          <span>
                            Start Date:{" "}
                            <strong className="text-foreground">
                              {subscription?.startDate
                                ? new Date(subscription.startDate).toLocaleDateString()
                                : "-"}
                            </strong>
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-primary" />
                          <span>
                            {isTrial ? "Trial Ends:" : "Next Renewal:"}{" "}
                            <strong className="text-foreground">
                              {subscription?.endDate
                                ? new Date(subscription.endDate).toLocaleDateString()
                                : "-"}
                            </strong>
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                      <div className="text-right sm:border-r border-border/60 sm:pr-6">
                        <div className="text-[10px] uppercase font-mono text-muted-foreground">
                          Current Rate
                        </div>
                        <div className="text-2xl font-extrabold font-mono text-foreground">
                          {plan?.priceMonthly === 0 ? (
                            <span>Free</span>
                          ) : (
                            <>
                              Rs. {plan?.priceMonthly.toLocaleString()}
                              <span className="text-xs text-muted-foreground font-normal">/mo</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Resource Usage Meters */}
              {usage && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-foreground uppercase font-mono tracking-wider">
                      Live Resource Quotas & Limits
                    </h3>
                  </div>
                  <UsageMeter usage={usage} />
                </div>
              )}

              {/* Available Plans & Upgrades */}
              <div className="space-y-3 pt-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <h3 className="text-sm font-bold text-foreground uppercase font-mono tracking-wider flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-primary" /> Upgrade or Switch Subscription Tier
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      Scale your limits effortlessly as your retail chain and team grow.
                    </p>
                  </div>
                </div>

                {isPlansLoading ? (
                  <div className="p-8 text-center text-xs text-muted-foreground">
                    Loading pricing plans...
                  </div>
                ) : (
                  <PricingCards
                    plans={plansData || []}
                    currentPlanId={plan?.id}
                    onUpgradeSuccess={() => refetchSub()}
                  />
                )}
              </div>

              {/* Billing & Invoice History */}
              <div className="space-y-3 pt-4">
                <h3 className="text-sm font-bold text-foreground uppercase font-mono tracking-wider">
                  Payment Receipts & Invoice Records
                </h3>
                <BillingHistoryTable
                  invoices={invoices}
                  businessName={plan?.name ? `${plan.name} Subscriber` : 'Subscriber'}
                  planName={plan?.name || 'SaaS Subscription'}
                />
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
