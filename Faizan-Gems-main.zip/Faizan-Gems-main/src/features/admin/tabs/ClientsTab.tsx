"use client";

import React, { useState, useMemo, useEffect } from "react";
import { VIPClient } from "../types";
import { LuxuryPrice } from "@/components/ui/LuxuryPrice";

interface ClientsTabProps {
  clientsList: VIPClient[];
  formatPrice?: (price: number) => string;
  isLoading?: boolean;
  onRefresh?: () => void;
}

export function ClientsTab({
  clientsList,
  isLoading = false,
  onRefresh,
}: ClientsTabProps) {
  const [searchQuery, setSearchQuery] = useState("");

  // Automatically refresh client list whenever this tab is opened
  useEffect(() => {
    onRefresh?.();
  }, [onRefresh]);

  const filteredClients = useMemo(() => {
    if (!searchQuery.trim()) return clientsList;
    const q = searchQuery.toLowerCase().trim();
    return clientsList.filter(
      (client) =>
        client.name.toLowerCase().includes(q) ||
        client.email.toLowerCase().includes(q) ||
        client.phone.toLowerCase().includes(q) ||
        (client.location || client.salon || "").toLowerCase().includes(q) ||
        client.tier.toLowerCase().includes(q)
    );
  }, [clientsList, searchQuery]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#24242C] pb-6">
        <div>
          <h1 className="font-sans text-xl sm:text-2xl text-white font-semibold tracking-tight">
            Customer Directory
          </h1>
          <p className="text-xs text-[#A1A1AA] font-sans mt-1">
            View registered users, verified client accounts, and purchase history.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {isLoading && (
            <span className="text-xs text-[#C5A880] font-sans flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C5A880]" />
              Syncing...
            </span>
          )}

          <span className="text-xs font-mono font-medium tabular-nums text-[#C5A880] bg-[#C5A880]/10 border border-[#C5A880]/30 px-3 py-1.5 rounded-sm">
            {clientsList.length} Registered {clientsList.length === 1 ? "Customer" : "Customers"}
          </span>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex items-center gap-3 bg-[#141419] border border-[#24242C] p-3 rounded-sm">
        <div className="relative flex-1">
          <svg className="w-4 h-4 text-[#8C867D] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by customer name, email, phone, city..."
            className="w-full bg-[#1A1A22] border border-[#282834] focus:border-[#C5A880] text-xs text-white placeholder-[#68635B] pl-9 pr-4 py-2 rounded-sm outline-none transition-colors"
          />
        </div>
        {searchQuery && (
          <button
            onClick={() => setSearchQuery("")}
            className="text-xs text-[#8C867D] hover:text-white px-2 py-1 transition-colors"
          >
            Clear
          </button>
        )}
      </div>

      {/* Customers Table */}
      <div className="bg-[#141419] border border-[#24242C] shadow-sm rounded-sm overflow-x-auto">
        <table className="w-full min-w-[780px] text-left text-xs font-sans">
          <thead>
            <tr className="border-b border-[#24242C] text-[#8C867D] uppercase text-[10px] bg-[#121217]">
              <th className="py-3 px-4">Customer Name</th>
              <th className="py-3 px-4">Email Address</th>
              <th className="py-3 px-4">Phone Number</th>
              <th className="py-3 px-4">Total Spent</th>
              <th className="py-3 px-4">Orders Count</th>
              <th className="py-3 px-4">City / Region</th>
              <th className="py-3 px-4">Account Type</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1F1E26]">
            {isLoading && clientsList.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-12 text-center text-[#8C867D]">
                  <svg className="w-6 h-6 animate-spin text-[#C5A880] mx-auto mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                  <p className="font-sans text-xs">Loading registered customers from database...</p>
                </td>
              </tr>
            ) : filteredClients.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-12 text-center text-[#8C867D]">
                  <svg className="w-8 h-8 text-[#55524B] mx-auto mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                  <p className="font-sans font-medium text-sm text-[#D8D5D0]">
                    {searchQuery ? "No matching customers found." : "No registered customers found."}
                  </p>
                  <p className="text-[11px] text-[#6C6760] mt-1">
                    {searchQuery
                      ? "Try searching with a different name, email, or phone number."
                      : "New customer accounts and order clients will automatically appear here."}
                  </p>
                </td>
              </tr>
            ) : (
              filteredClients.map((client, idx) => {
                const isVip = client.tier.toLowerCase().includes("vip");
                return (
                  <tr key={`${client.email}-${idx}`} className="hover:bg-[#181820] transition-colors">
                    <td className="py-3.5 px-4 font-sans text-sm text-white font-medium">
                      {client.name}
                    </td>
                    <td className="py-3.5 px-4 text-[#A29F96] font-mono text-xs tabular-nums">
                      {client.email}
                    </td>
                    <td className="py-3.5 px-4 text-[#8C867D] font-mono text-xs tabular-nums">
                      {client.phone || "—"}
                    </td>
                    <td className="py-3.5 px-4">
                      <LuxuryPrice amount={client.totalSpent} size="sm" color="gold" weight="semibold" />
                    </td>
                    <td className="py-3.5 px-4 text-white font-sans">
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-mono tabular-nums bg-[#1E1E26] text-[#E0DCD5] border border-[#2C2C38]">
                        {client.acquisitions} {client.acquisitions === 1 ? "Order" : "Orders"}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-[#A29F96] font-sans">
                      {client.location || client.salon || "Sri Lanka"}
                    </td>
                    <td className="py-3.5 px-4">
                      {isVip ? (
                        <span className="px-2.5 py-1 rounded text-[11px] font-mono bg-[#1D1B17] border border-[#C5A880]/50 text-[#E0CFA9] font-semibold tracking-wider uppercase">
                          VIP Customer
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 rounded text-[11px] font-mono bg-[#181820] border border-[#2D2D38] text-[#8C867D] font-medium tracking-wider uppercase">
                          Regular Customer
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
