import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class ProductsAiTool {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Get product catalog, selling prices, inventory stock, and low stock alerts
   */
  async getProductsContext(businessId: string, limit = 10) {
    const [totalProductCount, products] = await Promise.all([
      this.prisma.product.count({ where: { businessId, isActive: true } }),
      this.prisma.product.findMany({
        where: { businessId, isActive: true },
        take: limit,
        orderBy: { createdAt: 'desc' },
        select: {
          id: true,
          name: true,
          alertQuantity: true,
          category: { select: { name: true } },
          variants: {
            select: {
              id: true,
              name: true,
              sku: true,
              sellingPrice: true,
              purchaseLines: {
                where: { quantityRemaining: { gt: 0 } },
                select: { quantityRemaining: true },
              },
            },
          },
        },
      }),
    ]);

    const productCatalog = products.map((p) => {
      const primaryVariant = p.variants[0];
      const totalStock = p.variants.reduce((sum, v) => {
        const variantStock =
          v.purchaseLines?.reduce((s, pl) => s + (Number(pl.quantityRemaining) || 0), 0) || 0;
        return sum + variantStock;
      }, 0);

      const alertThreshold = Number(p.alertQuantity ?? 5);

      return {
        productName: p.name,
        category: p.category?.name || 'General',
        sku: primaryVariant?.sku || 'N/A',
        sellingPrice: Number(primaryVariant?.sellingPrice || 0),
        availableStock: totalStock,
        alertQuantity: alertThreshold,
        isLowStock: totalStock <= alertThreshold,
      };
    });

    const lowStockItems = productCatalog.filter((item) => item.isLowStock);

    return {
      totalProductsInCatalog: totalProductCount,
      productCatalog,
      lowStockAlertCount: lowStockItems.length,
      criticalLowStockItems: lowStockItems,
    };
  }
}
