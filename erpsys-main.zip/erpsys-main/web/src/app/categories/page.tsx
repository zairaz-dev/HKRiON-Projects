"use strict";
"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import { useQueryClient } from "@tanstack/react-query";
import { LoadingSession } from "@/components/ui/loading-session";
import {
  Layers,
  Plus,
  Edit2,
  Trash2,
  Loader2,
  CheckCircle,
  AlertCircle,
  X,
  Building2,
  Folder,
  Globe,
  Upload,
  Palette,
  Check,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { DataTable, ColumnDef, ActionsDropdown } from "@/components/ui/table";
import { ActionItem } from "@/components/ui/actions-dropdown";
import { authService } from "@/services/auth-service";
import { branchService } from "@/services/branch-service";
import { categoryService } from "@/services/category-service";
import { User } from "@hkr/types";
import { getFullAssetUrl } from "@/lib/utils";
import { useBranchesQuery } from "@/features/brands/hooks/use-brands";
import { useCategoriesQuery } from "@/features/categories/hooks/use-categories";
import { queryKeys } from "@/lib/query-keys";

interface BranchItem {
  id: string;
  name: string;
}

interface CategoryBranchItem {
  branchId: string;
  branch: BranchItem;
}

interface CategoryItem {
  id: string;
  name: string;
  description: string | null;
  imageUrl: string | null;
  color?: string | null;
  isActive: boolean;
  businessId: string;
  parentId: string | null;
  createdAt: string;
  updatedAt: string;
  parent?: CategoryItem | null;
  subCategories?: CategoryItem[];
  branches?: CategoryBranchItem[];
}

const PRESET_CATEGORY_COLORS = [
  { name: "Blue", hex: "#3B82F6" },
  { name: "Emerald", hex: "#10B981" },
  { name: "Amber", hex: "#F59E0B" },
  { name: "Rose", hex: "#F43F5E" },
  { name: "Purple", hex: "#8B5CF6" },
  { name: "Cyan", hex: "#06B6D4" },
  { name: "Indigo", hex: "#6366F1" },
  { name: "Teal", hex: "#14B8A6" },
  { name: "Orange", hex: "#F97316" },
  { name: "Pink", hex: "#EC4899" },
  { name: "Violet", hex: "#7C3AED" },
  { name: "Lime", hex: "#84CC16" },
  { name: "Slate", hex: "#64748B" },
  { name: "Yellow", hex: "#EAB308" },
];

function CategoryManagementPageContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();
  const queryClient = useQueryClient();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // UI States
  const [actionLoading, setActionLoading] = useState<boolean>(false);
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Category Modal State
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [modalMode, setModalMode] = useState<"create" | "edit">("create");
  const [editingCategoryId, setEditingCategoryId] = useState<string>("");
  
  // Form States
  const [formName, setFormName] = useState<string>("");
  const [formDescription, setFormDescription] = useState<string>("");
  const [formColor, setFormColor] = useState<string>("#3B82F6");
  const [formBranchIds, setFormBranchIds] = useState<string[]>([]);
  const [formParentId, setFormParentId] = useState<string>("none");
  const [formImageUrl, setFormImageUrl] = useState<string>("");
  const [formImageFile, setFormImageFile] = useState<File | null>(null); // Actual uploaded File
  const [formIsActive, setFormIsActive] = useState<boolean>(true);
  const [imageUploadType, setImageUploadType] = useState<"url" | "file">("file");

  // Delete Confirmation State
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState<boolean>(false);
  const [categoryToDelete, setCategoryToDelete] = useState<CategoryItem | null>(null);

  // URL-driven Filter & Pagination state (Rule #3: Always store table filters in URL Search Params)
  const selectedBranchFilter = searchParams.get("branchId") || "all";
  const selectedLevelFilter = searchParams.get("level") || "all";
  const currentPage = Number(searchParams.get("page")) || 1;
  const searchQuery = searchParams.get("search") || "";
  const limit = Number(searchParams.get("limit")) || 10;

  // Authenticate
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  const businessId = currentUser?.businessId || "";

  // Fetch data via React Query
  const { data: categoriesResponse, isLoading: categoriesLoading, isFetching: categoriesFetching, error: categoriesError } = useCategoriesQuery(
    businessId,
    {
      branchId: selectedBranchFilter === "all" ? undefined : selectedBranchFilter,
      page: currentPage,
      limit,
      search: searchQuery,
      type: selectedLevelFilter === "all" ? undefined : selectedLevelFilter,
    }
  );

  const categoriesList = categoriesResponse?.data || [];
  const meta = categoriesResponse?.meta || { totalItems: 0, totalPages: 1, currentPage: 1, limit: 10 };

  // Fetch all parent categories for selector dropdown (up to 1000 items)
  const { data: parentCategoriesResponse } = useCategoriesQuery(businessId, {
    limit: 1000,
    type: "parent",
  });
  const parentCategories = parentCategoriesResponse?.data || [];

  const { data: branchesList = [], isLoading: branchesLoading } = useBranchesQuery(businessId, currentUser?.id);

  const isTableLoading = categoriesLoading || categoriesFetching || actionLoading;
  const loading = categoriesLoading || branchesLoading;

  // Handle Query Errors
  useEffect(() => {
    if (categoriesError) {
      setError(categoriesError.message || "Failed to load category data.");
    }
  }, [categoriesError]);

  // Helper to resolve full image URLs
  const getFullImageUrl = (url: string | null) => {
    return getFullAssetUrl(url);
  };

  // Auto-dismiss notifications
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  const handleOpenCreateModal = (prefilledParentId?: string) => {
    setError("");
    setModalMode("create");
    setEditingCategoryId("");
    setFormName("");
    setFormDescription("");
    setFormColor("#3B82F6");
    setFormBranchIds([]);
    setFormParentId(prefilledParentId || "none");
    setFormImageUrl("");
    setFormImageFile(null);
    setFormIsActive(true);
    setImageUploadType("file");
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (category: CategoryItem) => {
    setError("");
    setModalMode("edit");
    setEditingCategoryId(category.id);
    setFormName(category.name);
    setFormDescription(category.description || "");
    setFormColor(category.color || "#3B82F6");
    
    const assignedBranchIds = category.branches?.map((cb) => cb.branch.id) || [];
    setFormBranchIds(assignedBranchIds);

    setFormParentId(category.parentId || "none");
    setFormImageUrl(category.imageUrl || "");
    setFormImageFile(null);
    setFormIsActive(category.isActive);
    setImageUploadType(category.imageUrl?.startsWith("/uploads/") ? "file" : "url");
    setIsModalOpen(true);
  };

  const handleToggleBranchForm = (branchId: string) => {
    setFormBranchIds((prev) =>
      prev.includes(branchId)
        ? prev.filter((id) => id !== branchId)
        : [...prev, branchId]
    );
  };

  const handleOpenDeleteConfirm = (category: CategoryItem) => {
    setError("");
    setCategoryToDelete(category);
    setIsDeleteConfirmOpen(true);
  };

  // Handle local file upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        setError("Image size should be less than 2MB.");
        return;
      }
      setFormImageFile(file);
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormImageUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCategorySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = formName.trim();
    if (!trimmedName) {
      setError("Category name is required.");
      return;
    }
    if (trimmedName.length < 2 || trimmedName.length > 100) {
      setError("Category name must be between 2 and 100 characters.");
      return;
    }

    if (formDescription && formDescription.trim().length > 500) {
      setError("Description cannot exceed 500 characters.");
      return;
    }

    const hexColorRegex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
    if (formColor && !hexColorRegex.test(formColor)) {
      setError("Color must be a valid hex code (e.g. #3B82F6).");
      return;
    }

    if (!currentUser?.businessId) return;

    setActionLoading(true);
    setError("");

    const payload: any = {
      name: trimmedName,
      description: formDescription.trim() || undefined,
      color: formColor || "#3B82F6",
      imageUrl: imageUploadType === "url" ? formImageUrl.trim() : undefined,
      imageFile: imageUploadType === "file" ? formImageFile : null,
      businessId: currentUser.businessId,
      branchIds: formBranchIds,
      parentId: formParentId === "none" ? null : formParentId,
      isActive: formIsActive,
    };

    if (modalMode === "create") {
      payload.createdById = currentUser.id;
    } else {
      payload.updatedById = currentUser.id;
    }

    try {
      if (modalMode === "create") {
        await categoryService.createCategory(payload);
        setSuccessMessage("Category created successfully!");
      } else {
        await categoryService.updateCategory(editingCategoryId, payload);
        setSuccessMessage("Category updated successfully!");
      }
      setIsModalOpen(false);
      queryClient.invalidateQueries({ queryKey: queryKeys.categories.all });
    } catch (err: any) {
      setError(err.message || "Failed to save category.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteCategory = async () => {
    if (!categoryToDelete || !currentUser?.businessId) return;
    setActionLoading(true);
    setError("");
    try {
      await categoryService.deleteCategory(categoryToDelete.id, currentUser.businessId);
      setSuccessMessage("Category deleted successfully!");
      setIsDeleteConfirmOpen(false);
      queryClient.invalidateQueries({ queryKey: queryKeys.categories.all });
    } catch (err: any) {
      setError(err.message || "Failed to delete category.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleBranchFilterChange = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1");
    if (value === "all") {
      params.delete("branchId");
    } else {
      params.set("branchId", value);
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  const handleLevelFilterChange = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1");
    if (value === "all") {
      params.delete("level");
    } else {
      params.set("level", value);
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  const handlePageChange = (newPage: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", String(newPage));
    router.push(`${pathname}?${params.toString()}`);
  };

  const handleSearchChange = (newSearch: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1");
    if (newSearch) {
      params.set("search", newSearch);
    } else {
      params.delete("search");
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  const handleLimitChange = (newLimit: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("limit", String(newLimit));
    params.set("page", "1");
    router.push(`${pathname}?${params.toString()}`);
  };

  // DataTable columns definition
  const columns: ColumnDef<CategoryItem>[] = [
    {
      header: "Category Name",
      searchable: true,
      render: (category) => {
        const parentCategory = category.parent;

        return (
          <div className="flex items-center gap-3">
            {/* Image / Color Preview */}
            <div
              className="h-9 w-9 rounded-md border overflow-hidden shrink-0 flex items-center justify-center transition-all"
              style={{
                borderColor: category.color ? `${category.color}80` : undefined,
                backgroundColor: category.color ? `${category.color}15` : undefined,
              }}
            >
              {category.imageUrl ? (
                <img
                  src={getFullImageUrl(category.imageUrl) || ""}
                  alt={category.name}
                  className="h-full w-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = ""; 
                  }}
                />
              ) : (
                <Folder
                  className="h-4.5 w-4.5"
                  style={{ color: category.color || undefined }}
                />
              )}
            </div>

            <div className="truncate">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-foreground block truncate">
                  {category.name}
                </span>
                {category.color && (
                  <span
                    className="w-2.5 h-2.5 rounded-full shrink-0 shadow-xs border border-white/20"
                    style={{ backgroundColor: category.color }}
                    title={`Color: ${category.color}`}
                  />
                )}
              </div>
              {parentCategory && (
                <span className="text-[10px] text-primary font-medium block">
                  Sub of {parentCategory.name}
                </span>
              )}
              {category.description && (
                <span className="text-[10px] text-muted-foreground block truncate max-w-[200px] md:max-w-[300px]">
                  {category.description}
                </span>
              )}
            </div>
          </div>
        );
      },
    },
    {
      header: "Level",
      render: (category) => (
        category.parentId ? (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-sm text-[10px] font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20 font-mono">
            SUBCATEGORY
          </span>
        ) : (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-sm text-[10px] font-semibold bg-primary/10 text-primary border border-primary/20 font-mono">
            PARENT
          </span>
        )
      ),
    },
    {
      header: "Branch Scope",
      render: (category) => renderBranchNames(category),
    },
    {
      header: "Status",
      render: (category) => (
        <span
          className={`inline-flex items-center px-2.5 py-0.5 rounded-sm text-[10px] font-semibold border ${
            category.isActive
              ? "bg-emerald-500/10 text-emerald-450 border-emerald-500/20"
              : "bg-secondary text-secondary-foreground border border-border"
          }`}
        >
          {category.isActive ? "ACTIVE" : "INACTIVE"}
        </span>
      ),
    },
    {
      header: "Actions",
      render: (category) => {
        const actions: ActionItem[] = [];
        if (!category.parentId) {
          actions.push({
            label: "Add Subcategory",
            onClick: () => handleOpenCreateModal(category.id),
            icon: <Plus className="h-3.5 w-3.5" />,
          });
        }
        actions.push(
          {
            label: "Edit",
            onClick: () => handleOpenEditModal(category),
            icon: <Edit2 className="h-3.5 w-3.5" />,
          },
          {
            label: "Delete",
            onClick: () => handleOpenDeleteConfirm(category),
            icon: <Trash2 className="h-3.5 w-3.5" />,
            variant: "destructive",
          }
        );
        return <ActionsDropdown actions={actions} />;
      },
    },
  ];

  // Helper to render branch names
  const renderBranchNames = (category: CategoryItem) => {
    if (!category.branches || category.branches.length === 0) {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground font-medium">
          <Globe className="h-3.5 w-3.5 text-muted-foreground/60" />
          Global (All Branches)
        </span>
      );
    }

    if (category.branches.length === 1) {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs text-foreground/90 font-medium">
          <Building2 className="h-3.5 w-3.5 text-muted-foreground" />
          {category.branches[0].branch.name}
        </span>
      );
    }

    if (category.branches.length === branchesList.length) {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs text-foreground/90 font-medium">
          <Building2 className="h-3.5 w-3.5 text-muted-foreground" />
          All Branches ({category.branches.length})
        </span>
      );
    }

    const names = category.branches.map((cb) => cb.branch.name);
    if (names.length <= 2) {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs text-foreground/90 font-medium">
          <Building2 className="h-3.5 w-3.5 text-muted-foreground" />
          {names.join(", ")}
        </span>
      );
    }

    return (
      <span className="inline-flex items-center gap-1.5 text-xs text-foreground/90 font-medium" title={names.join(", ")}>
        <Building2 className="h-3.5 w-3.5 text-muted-foreground" />
        {names[0]}, {names[1]} +{names.length - 2} more
      </span>
    );
  };

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-4">
          <Loader2 className="h-10 w-10 animate-spin text-primary mx-auto" />
          <p className="text-lg font-medium">Redirecting to login...</p>
        </div>
      </div>
    );
  }

  const availableParentCategories = parentCategories.filter(
    (c) => c.id !== editingCategoryId
  );

  const customFilters = (
    <div className="flex flex-wrap items-center gap-3">
      <div className="flex items-center gap-2">
        <span className="text-xs font-semibold text-muted-foreground whitespace-nowrap">Branch:</span>
        <select
          value={selectedBranchFilter}
          onChange={(e) => handleBranchFilterChange(e.target.value)}
          className="h-9 rounded-md border border-input bg-background px-3 py-1 text-xs shadow-sm focus:outline-none focus:ring-1 focus:ring-ring"
        >
          <option value="all">All Branches</option>
          <option value="global">Global Only</option>
          {branchesList.map((b) => (
            <option key={b.id} value={b.id}>
              {b.name}
            </option>
          ))}
        </select>
      </div>

      <div className="flex items-center gap-2">
        <span className="text-xs font-semibold text-muted-foreground whitespace-nowrap">Level:</span>
        <select
          value={selectedLevelFilter}
          onChange={(e) => handleLevelFilterChange(e.target.value)}
          className="h-9 rounded-md border border-input bg-background px-3 py-1 text-xs shadow-sm focus:outline-none focus:ring-1 focus:ring-ring"
        >
          <option value="all">All Levels</option>
          <option value="parent">Parent Categories</option>
          <option value="sub">Subcategories Only</option>
        </select>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/categories" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Product Categories" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          
          {/* Notifications */}
          {successMessage && (
            <div className="flex items-center gap-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-450 p-4 rounded-sm animate-in fade-in slide-in-from-top duration-300">
              <CheckCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 bg-rose-500/10 border border-rose-500/20 text-rose-450 p-4 rounded-sm animate-in fade-in slide-in-from-top duration-300">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <Layers className="h-7 w-7 text-primary" /> Product Categories
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Organize your products into categories and subcategories, associate them with multiple branches, and upload images.
              </p>
            </div>
          </div>

          {/* Category List */}
          {loading ? (
            <div className="flex h-64 items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (categoriesList.length === 0 && !searchQuery && selectedBranchFilter === "all" && selectedLevelFilter === "all") ? (
            <Card className="p-12 text-center border-dashed border-border/50 bg-card/10">
              <CardContent className="space-y-4 pt-6">
                <div className="bg-secondary h-16 w-16 rounded-2xl flex items-center justify-center mx-auto text-muted-foreground">
                  <Layers className="h-8 w-8" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-xl font-semibold text-foreground">No Categories Yet</h3>
                  <p className="text-muted-foreground max-w-sm mx-auto">
                    Get started by creating your first product category or subcategory.
                  </p>
                </div>
                <Button onClick={() => handleOpenCreateModal()} className="bg-primary hover:bg-primary/90 text-primary-foreground">
                  Create Category
                </Button>
              </CardContent>
            </Card>
          ) : (
            <DataTable
              data={categoriesList}
              columns={columns}
              searchPlaceholder="Search categories by name or description..."
              reportTitle="Product Categories Report"
              pageSize={limit}
              customFilters={customFilters}
              actionButton={{
                label: "Add Category",
                onClick: () => handleOpenCreateModal(),
                icon: <Plus className="h-4 w-4" />
              }}
              serverSide={true}
              totalItems={meta.totalItems}
              totalPages={meta.totalPages}
              currentPage={meta.currentPage}
              onPageChange={handlePageChange}
              searchQuery={searchQuery}
              onSearchQueryChange={handleSearchChange}
              isLoading={isTableLoading}
              onPageSizeChange={handleLimitChange}
            />
          )}
        </main>
      </div>

      {/* Create/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-card border border-border rounded-sm shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-border p-5 bg-background/40">
              <h3 className="text-sm font-bold text-foreground tracking-wider uppercase font-mono">
                {modalMode === "create" ? "Add Product Category" : "Edit Category Details"}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCategorySubmit} className="p-5 space-y-4 max-h-[75vh] overflow-y-auto">
              {error && (
                <div className="p-3 rounded-sm bg-rose-500/15 border border-rose-500/30 text-rose-450 text-xs flex items-center gap-2 animate-in fade-in duration-200">
                  <AlertCircle className="h-4 w-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">Category Name *</label>
                <Input
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. Electronics, Beverages"
                  className="text-xs h-9 rounded-sm"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">Description</label>
                <textarea
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Provide a brief description of this category..."
                  className="w-full h-20 px-3 py-2 bg-background/50 border border-input text-foreground rounded-sm text-xs focus:outline-none focus:border-primary placeholder:text-muted-foreground/60 transition-all focus:ring-1 focus:ring-primary resize-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">Parent Category (Optional)</label>
                <select
                  value={formParentId}
                  onChange={(e) => setFormParentId(e.target.value)}
                  className="w-full bg-background/50 border border-input text-foreground rounded-sm text-xs p-2 focus:outline-none focus:border-primary h-9"
                >
                  <option value="none">None (Make it a Parent Category)</option>
                  {availableParentCategories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-muted-foreground">
                  Select a parent category if you want to make this a Subcategory.
                </p>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">Branch Assignment</label>
                <div className="border border-border/45 p-3 rounded-sm bg-background/30 max-h-32 overflow-y-auto space-y-2">
                  {branchesList.map((branch) => {
                    const isChecked = formBranchIds.includes(branch.id);
                    return (
                      <label key={branch.id} className="flex items-center gap-2.5 text-xs text-foreground cursor-pointer hover:text-primary transition-colors">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => handleToggleBranchForm(branch.id)}
                          className="rounded-sm border-input text-primary focus:ring-primary h-3.5 w-3.5 bg-background"
                        />
                        {branch.name}
                      </label>
                    );
                  })}
                  {branchesList.length === 0 && (
                    <p className="text-xs text-muted-foreground">No branches found.</p>
                  )}
                </div>
                <p className="text-[10px] text-muted-foreground">
                  Leave all unchecked to make this category **Global** (Available in all branches).
                </p>
              </div>

              {/* Category Image */}
              <div className="space-y-2 border border-border/45 p-3 rounded-sm bg-background/30">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">Category Image</label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setImageUploadType("file")}
                      className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-sm border transition-all ${
                        imageUploadType === "file"
                          ? "bg-primary/10 border-primary/20 text-primary"
                          : "border-border text-muted-foreground hover:bg-secondary/40"
                      }`}
                    >
                      Local File
                    </button>
                    <button
                      type="button"
                      onClick={() => setImageUploadType("url")}
                      className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-sm border transition-all ${
                        imageUploadType === "url"
                          ? "bg-primary/10 border-primary/20 text-primary"
                          : "border-border text-muted-foreground hover:bg-secondary/40"
                      }`}
                    >
                      Image URL
                    </button>
                  </div>
                </div>

                {imageUploadType === "file" ? (
                  <div className="space-y-2">
                    <div className="flex items-center justify-center w-full">
                      <label className="flex flex-col items-center justify-center w-full h-24 border-2 border-dashed border-border/80 hover:border-primary/55 rounded-sm cursor-pointer bg-background/10 hover:bg-background/25 transition-all">
                        <div className="flex flex-col items-center justify-center pt-3 pb-3">
                          <Upload className="w-5 h-5 text-muted-foreground/80 mb-1" />
                          <p className="text-xs text-muted-foreground">
                            <span className="font-semibold text-primary">Click to upload</span> or drag and drop
                          </p>
                          <p className="text-[9px] text-muted-foreground/60 font-mono">PNG, JPG, WEBP (Max. 2MB)</p>
                        </div>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={handleFileChange}
                        />
                      </label>
                    </div>
                  </div>
                ) : (
                  <Input
                    value={formImageUrl}
                    onChange={(e) => setFormImageUrl(e.target.value)}
                    placeholder="https://example.com/image.jpg"
                    type="url"
                    className="text-xs h-9 rounded-sm"
                  />
                )}

                {formImageUrl && (
                  <div className="relative w-full h-24 rounded-sm border border-border overflow-hidden bg-secondary/30 mt-2 flex items-center justify-center group">
                    <img
                      src={getFullImageUrl(formImageUrl) || ""}
                      alt="Preview"
                      className="h-full w-full object-contain"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        setFormImageUrl("");
                        setFormImageFile(null);
                      }}
                      className="absolute top-1 right-1 bg-black/70 hover:bg-black/95 text-white rounded-full p-1 transition-colors"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                )}
              </div>

              {/* Category Color Picker */}
              <div className="space-y-2 border border-border/45 p-3.5 rounded-sm bg-background/30">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono flex items-center gap-1.5">
                    <Palette className="w-3.5 h-3.5 text-primary" /> Category Color & POS Accent
                  </label>
                  {/* Live Badge Preview */}
                  <span
                    className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold border transition-colors shadow-xs"
                    style={{
                      backgroundColor: `${formColor}18`,
                      borderColor: formColor,
                      color: formColor,
                    }}
                  >
                    <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: formColor }} />
                    {formName.trim() || "Preview Tag"}
                  </span>
                </div>

                {/* Preset Colors Grid */}
                <div className="grid grid-cols-7 gap-2 pt-1">
                  {PRESET_CATEGORY_COLORS.map((c) => {
                    const isSelected = formColor.toLowerCase() === c.hex.toLowerCase();
                    return (
                      <button
                        key={c.hex}
                        type="button"
                        onClick={() => setFormColor(c.hex)}
                        className={`h-7 w-full rounded-sm border transition-transform cursor-pointer flex items-center justify-center ${
                          isSelected ? "ring-2 ring-foreground scale-105 border-white" : "border-border/60 hover:scale-105"
                        }`}
                        style={{ backgroundColor: c.hex }}
                        title={`${c.name} (${c.hex})`}
                      >
                        {isSelected && <Check className="w-3.5 h-3.5 text-white drop-shadow-md" />}
                      </button>
                    );
                  })}
                </div>

                {/* Custom Hex Picker Input */}
                <div className="flex items-center gap-2 pt-1.5">
                  <div className="relative w-8 h-8 rounded-sm overflow-hidden border border-border shrink-0 cursor-pointer">
                    <input
                      type="color"
                      value={formColor}
                      onChange={(e) => setFormColor(e.target.value)}
                      className="absolute -top-2 -left-2 w-12 h-12 cursor-pointer border-0 p-0"
                    />
                  </div>
                  <Input
                    type="text"
                    value={formColor}
                    onChange={(e) => setFormColor(e.target.value)}
                    placeholder="#3B82F6"
                    className="text-xs h-8 rounded-sm font-mono uppercase w-32"
                  />
                  <span className="text-[10px] text-muted-foreground">Custom HEX accent color</span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-border/40 mt-2">
                <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">Status</span>
                <button
                  type="button"
                  onClick={() => setFormIsActive(!formIsActive)}
                  className="text-muted-foreground hover:text-foreground focus:outline-none transition-colors"
                >
                  <span
                    className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      formIsActive ? "bg-primary" : "bg-secondary"
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                        formIsActive ? "translate-x-5" : "translate-x-0"
                      }`}
                    />
                  </span>
                </button>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-border">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsModalOpen(false)}
                  className="text-xs h-9 rounded-sm"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={actionLoading}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground text-xs h-9 rounded-sm px-4 shadow-md shadow-primary/10 flex items-center gap-1.5 min-w-[100px]"
                >
                  {actionLoading ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin mx-auto text-primary-foreground" />
                  ) : modalMode === "create" ? (
                    "Create"
                  ) : (
                    "Save Changes"
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isDeleteConfirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm bg-card border border-border rounded-sm shadow-2xl p-6 space-y-4 animate-in zoom-in-95 duration-200">
            <div className="text-center space-y-2">
              <div className="h-12 w-12 rounded-full bg-rose-500/10 border border-rose-500/25 flex items-center justify-center text-rose-500 mx-auto">
                <Trash2 className="h-5 w-5" />
              </div>
              <h3 className="text-sm font-bold text-foreground tracking-wider uppercase font-mono">Delete Category?</h3>
              {error && (
                <div className="p-2.5 rounded-sm bg-rose-500/15 border border-rose-500/30 text-rose-450 text-xs text-left animate-in fade-in duration-200">
                  {error}
                </div>
              )}
              <p className="text-xs text-muted-foreground leading-relaxed">
                Are you sure you want to delete <strong className="text-foreground">{categoryToDelete?.name}</strong>? 
                {categoryToDelete?.subCategories && categoryToDelete.subCategories.length > 0 && (
                  <span className="block mt-2 text-rose-450 font-semibold text-[10px]">
                    Warning: This will also delete all of its {categoryToDelete.subCategories.length} subcategories!
                  </span>
                )}
                This action cannot be undone.
              </p>
            </div>
            <div className="flex items-center justify-center gap-3 border-t border-border pt-4 bg-background/25">
              <Button
                variant="outline"
                onClick={() => setIsDeleteConfirmOpen(false)}
                className="w-full text-xs h-9 rounded-sm"
              >
                Cancel
              </Button>
              <Button
                onClick={handleDeleteCategory}
                disabled={actionLoading}
                variant="destructive"
                className="w-full text-xs h-9 rounded-sm flex items-center justify-center gap-1.5"
              >
                {actionLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin mx-auto" /> : "Delete"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function CategoryManagementPage() {
  return (
    <Suspense fallback={<LoadingSession />}>
      <CategoryManagementPageContent />
    </Suspense>
  );
}
