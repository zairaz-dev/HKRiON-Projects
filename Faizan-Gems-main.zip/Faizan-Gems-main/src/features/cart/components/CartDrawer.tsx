"use client";

import React, { useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { useCart } from "@/features/cart/context/CartContext";
import { useCurrency } from "@/features/currency/context/CurrencyContext";
import { useAuth } from "@/features/auth/context/AuthContext";
import {
  CloseIcon,
  BagIcon,
  ArmoredTruckIcon,
  SecurityLockIcon,
  CertificateShieldIcon
} from "@/components/ui/LuxuryIcons";
import { LuxuryPrice } from "@/components/ui/LuxuryPrice";

export function CartDrawer() {
  const {
    isCartOpen,
    closeCart,
    items,
    removeFromCart,
    updateQuantity,
    subtotal,
  } = useCart();
  const { formatPrice } = useCurrency();
  const { isAuthenticated, isLoading: authLoading } = useAuth();

  // Prevent background scrolling when cart drawer is open
  useEffect(() => {
    if (isCartOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isCartOpen]);

  // Escape key to close cart drawer
  useEffect(() => {
    if (!isCartOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeCart();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isCartOpen, closeCart]);

  if (!isCartOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Shopping Cart Drawer"
      className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm animate-luxury-backdrop"
      onClick={closeCart}
    >
      <div
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between border-l border-[#C5A880]/30 animate-luxury-drawer-right"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-[#E8E4DC] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BagIcon className="w-5 h-5 text-[#C5A880]" />
            <h2 className="font-serif text-xl text-[#18181D]">Acquisition Bag</h2>
            <span className="text-xs font-mono px-2 py-0.5 bg-[#FAF8F5] border border-[#E8E4DC] text-[#8C867D]">
              {items.length} {items.length === 1 ? "Piece" : "Pieces"}
            </span>
          </div>
          <button
            onClick={closeCart}
            aria-label="Close bag"
            className="min-w-[44px] min-h-[44px] rounded-full text-[#8C867D] hover:text-[#18181D] hover:bg-[#FAF8F5] flex items-center justify-center transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#C5A880]"
          >
            <CloseIcon className="w-4 h-4" />
          </button>
        </div>

        {/* Item list */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {items.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-12 h-12 rounded-full bg-[#FAF8F5] border border-[#E8E4DC] mx-auto flex items-center justify-center text-[#8C867D] mb-4">
                <BagIcon className="w-6 h-6" />
              </div>
              <h3 className="font-serif text-lg text-[#18181D]">Your Bag is Empty</h3>
              <p className="text-xs text-[#8C867D] font-sans mt-2 max-w-xs mx-auto">
                Explore our curated collection of unheated certified sapphires, rubies, and emeralds.
              </p>
              <Link
                href="/shop"
                onClick={closeCart}
                className="inline-block mt-6 px-6 py-2.5 bg-[#18181D] text-white text-xs uppercase tracking-widest font-sans hover:bg-[#2A2A32] transition-colors"
              >
                Explore Gemstones
              </Link>
            </div>
          ) : (
            items.map((item) => {
              const itemKey = `${item.gemstone.id}-${item.selectedVariant?.id || "default"}`;
              const itemWeight = item.selectedWeight ?? item.gemstone.carat;
              const itemBasePrice = item.selectedPrice ?? item.gemstone.price;
              const quantity = item.quantity ?? 1;
              const maxStock = item.selectedVariant?.stock ?? (item.gemstone.inStock ? 99 : 0);

              const unitPrice = itemBasePrice;
              const lineTotal = unitPrice * quantity;

              return (
                <div key={itemKey} className="border-b border-[#F2EFE9] pb-6 last:border-none">
                  <div className="flex gap-4">
                    {/* Thumbnail */}
                    <div className="relative w-20 h-20 flex-shrink-0 bg-[#F7F5F1] border border-[#E8E4DC] overflow-hidden">
                      <Image
                        src={item.gemstone.images?.[0] || (item.gemstone as any).imageUrl || "/uploads/gemstones/gem-1789652077476-hwzsqu.webp"}
                        alt={item.gemstone.name}
                        fill
                        unoptimized={Boolean((item.gemstone.images?.[0] || (item.gemstone as any).imageUrl)?.startsWith("/uploads"))}
                        className="object-cover"
                      />
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <Link
                          href={`/gemstones/${item.gemstone.id}`}
                          onClick={closeCart}
                          className="font-serif text-sm font-medium text-[#18181D] hover:text-[#9A7B4F] line-clamp-1"
                        >
                          {item.gemstone.name}
                        </Link>
                        <button
                          onClick={() => removeFromCart(item.gemstone.id, item.selectedVariant?.id)}
                          aria-label={`Remove ${item.gemstone.name} from bag`}
                          className="min-h-[36px] min-w-[36px] -mr-1 px-2 flex items-center justify-center text-[11px] text-[#8C867D] hover:text-red-700 font-sans uppercase tracking-wider transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#C5A880]"
                        >
                          Remove
                        </button>
                      </div>

                      <div className="mt-1 text-[11px] text-[#8C867D] font-sans flex items-center flex-wrap gap-2">
                        <span className="font-medium text-[#18181D] bg-[#F5F2EB] px-1.5 py-0.5 rounded">
                          {itemWeight.toFixed(2)} ct
                        </span>
                        <span>•</span>
                        <span>{item.gemstone.cut}</span>
                        {item.selectedSize && (
                          <>
                            <span>•</span>
                            <span className="text-[10px] text-[#8C867D]">{item.selectedSize}</span>
                          </>
                        )}
                        {item.gemstone.origin && (
                          <>
                            <span>•</span>
                            <span className="text-[#8C867D]">{item.gemstone.origin}</span>
                          </>
                        )}
                      </div>

                      {/* Quantity Selector & Line Total */}
                      <div className="mt-3 flex items-center justify-between pt-2 border-t border-[#F2EFE9]">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] uppercase text-[#8C867D] font-sans">Qty:</span>
                          <div className="inline-flex items-center border border-[#E8E4DC] bg-[#FAF8F5] rounded-xs overflow-hidden">
                            <button
                              type="button"
                              onClick={() =>
                                updateQuantity(
                                  item.gemstone.id,
                                  quantity - 1,
                                  item.selectedVariant?.id
                                )
                              }
                              aria-label="Decrease quantity"
                              className="w-8 h-8 flex items-center justify-center text-sm font-medium text-[#18181D] hover:bg-[#E8E4DC] active:bg-[#D3CBBF] transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#C5A880]"
                            >
                              -
                            </button>
                            <span className="min-w-[28px] text-center px-1 text-xs font-mono font-medium text-[#18181D]">
                              {quantity}
                            </span>
                            <button
                              type="button"
                              disabled={quantity >= maxStock}
                              onClick={() =>
                                updateQuantity(
                                  item.gemstone.id,
                                  quantity + 1,
                                  item.selectedVariant?.id
                                )
                              }
                              aria-label="Increase quantity"
                              className="w-8 h-8 flex items-center justify-center text-sm font-medium text-[#18181D] hover:bg-[#E8E4DC] active:bg-[#D3CBBF] disabled:opacity-30 disabled:hover:bg-transparent transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#C5A880]"
                            >
                              +
                            </button>
                          </div>
                        </div>

                        <div className="text-right">
                          <LuxuryPrice amount={lineTotal} size="md" />
                          {quantity > 1 && (
                            <span className="block text-[10px] text-[#8C867D] font-mono">
                              ({formatPrice(unitPrice)} each)
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer & CTAs */}
        {items.length > 0 && (
          <div className="p-5 sm:p-6 bg-[#FAF8F5] border-t border-[#E8E4DC] space-y-4 pb-[max(1.25rem,calc(1rem+env(safe-area-inset-bottom,0px)))]">
            {/* Subtotal */}
            <div className="flex items-baseline justify-between">
              <div>
                <span className="font-serif text-sm text-[#18181D] block">Subtotal</span>
                <span className="text-[11px] text-[#8C867D] font-sans">
                  Armored Courier & Taxes Calculated at Step 2
                </span>
              </div>
              <LuxuryPrice amount={subtotal} size="xl" />
            </div>

            {/* Assurance pill */}
            <div className="p-2.5 bg-white border border-[#E8E4DC] flex items-center justify-around text-[10px] text-[#6B655C] font-sans">
              <span className="flex items-center gap-1">
                <ArmoredTruckIcon className="w-3.5 h-3.5 text-[#C5A880]" />
                Armored Air Delivery
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <SecurityLockIcon className="w-3.5 h-3.5 text-[#C5A880]" />
                Insured Transit
              </span>
            </div>

            <div className="space-y-2">
              <Link
                href={!authLoading && !isAuthenticated ? "/login?from=/checkout" : "/checkout"}
                onClick={closeCart}
                className="block w-full py-3.5 bg-[#18181D] hover:bg-[#2A2A32] text-white text-center text-xs uppercase tracking-widest font-sans transition-all shadow-md active:scale-[0.99] btn-luxury-press"
              >
                {!authLoading && !isAuthenticated ? "Sign In to Checkout" : "Proceed to Secure Checkout"}
              </Link>
              <Link
                href="/cart"
                onClick={closeCart}
                className="block w-full py-2 text-center text-xs text-[#8C867D] hover:text-[#18181D] font-sans uppercase tracking-wider"
              >
                View Detailed Bag & Special Requests &rarr;
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
