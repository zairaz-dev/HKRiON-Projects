"use client";

import Link from "next/link";
import {
  Globe,
  ExternalLink,
  Shield,
  Menu,
  LogOut,
  Users,
  Search,
  Plus,
  Bell,
  KeyRound,
  Sun,
  Moon,
} from "lucide-react";
import { useAdminTheme } from "@/components/admin/AdminThemeContext";

interface AdminTopbarProps {
  user: {
    name: string;
    email: string;
    role: string;
  };
}

export default function AdminTopbar({ user }: AdminTopbarProps) {
  const { theme, toggleTheme, mounted } = useAdminTheme();
  const initialLetter = user.name ? user.name.charAt(0).toUpperCase() : "A";
  const isDark = theme === "dark";

  return (
    <header className="sticky top-0 z-30 w-full h-16 bg-white/95 dark:bg-black/95 backdrop-blur-md border-b border-[#E5E5E0] dark:border-neutral-800 px-4 sm:px-6 flex items-center justify-between transition-colors duration-200 shadow-2xs">
      {/* Left: Mobile Sidebar Hamburger Button & Search Bar */}
      <div className="flex items-center gap-3">
        <label
          htmlFor="admin-sidebar-toggle"
          className="lg:hidden p-2 rounded-none bg-neutral-100 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white cursor-pointer active:scale-95 flex items-center justify-center select-none border border-neutral-200 dark:border-neutral-800"
          title="Toggle Navigation Menu"
        >
          <Menu size={18} />
        </label>

        {/* Global Quick Search */}
        <div className="relative hidden md:flex items-center">
          <Search size={14} className="absolute left-3 text-neutral-400 dark:text-neutral-500 pointer-events-none" />
          <input
            type="text"
            placeholder="Search pages, leads, products..."
            className="w-64 lg:w-80 pl-9 pr-4 py-1.5 bg-neutral-50 hover:bg-neutral-100 focus:bg-white dark:bg-neutral-950 dark:hover:bg-neutral-900 dark:focus:bg-black border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 dark:focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 dark:placeholder:text-neutral-500 transition-all outline-hidden font-medium"
          />
        </div>
      </div>

      {/* Right: Theme Toggle, Quick Links & Profile Avatar */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Theme Switcher Button */}
        <button
          type="button"
          onClick={toggleTheme}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-none border text-xs font-bold transition-all cursor-pointer select-none active:scale-95 bg-neutral-50 hover:bg-neutral-100 text-neutral-700 border-[#E5E5E0] dark:bg-neutral-900 dark:hover:bg-neutral-850 dark:text-amber-400 dark:border-neutral-800 shadow-2xs"
          title={isDark ? "Switch to Light Mode" : "Switch to Dark Mode"}
          aria-label="Toggle Dark/Light Mode"
        >
          {mounted && isDark ? (
            <>
              <Sun size={14} className="text-amber-400 animate-in spin-in-180 duration-300" />
              <span className="hidden sm:inline text-xs font-semibold text-neutral-200">Light Mode</span>
            </>
          ) : (
            <>
              <Moon size={14} className="text-neutral-700 dark:text-neutral-300 animate-in spin-in-180 duration-300" />
              <span className="hidden sm:inline text-xs font-semibold text-neutral-700">Dark Mode</span>
            </>
          )}
        </button>

        {/* Quick Add Dropdown / Action */}
        <Link
          href="/admin/homepage"
          className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-none bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold transition-all shadow-xs active:scale-95"
        >
          <Plus size={13} className="stroke-[3]" />
          <span>Edit Home CMS</span>
        </Link>

        {/* View Live Website Shortcut */}
        <Link
          href="/"
          target="_blank"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-none bg-neutral-50 hover:bg-neutral-100 dark:bg-neutral-900 dark:hover:bg-neutral-850 text-neutral-700 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white border border-[#E5E5E0] dark:border-neutral-800 text-xs font-semibold transition-all active:scale-95"
        >
          <Globe size={13} className="text-amber-600 dark:text-amber-400" />
          <span className="hidden xs:inline">Live Site</span>
          <ExternalLink size={11} className="text-neutral-400 dark:text-neutral-500" />
        </Link>

        {/* Notification indicator */}
        <Link
          href="/admin/inquiries"
          className="relative p-2 rounded-none bg-neutral-50 hover:bg-neutral-100 dark:bg-neutral-900 dark:hover:bg-neutral-850 text-neutral-600 dark:text-neutral-300 border border-[#E5E5E0] dark:border-neutral-800 transition-colors"
          title="Recent Inquiries"
        >
          <Bell size={15} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-none bg-amber-500 ring-2 ring-white dark:ring-black" />
        </Link>

        {/* Profile Avatar with Zero-JS Pure CSS Dropdown */}
        <div className="relative">
          {/* Native HTML Checkbox for instant 0ms toggle */}
          <input
            type="checkbox"
            id="admin-topbar-profile-toggle"
            className="peer hidden"
            aria-hidden="true"
          />

          {/* Click-away backdrop overlay */}
          <label
            htmlFor="admin-topbar-profile-toggle"
            className="hidden peer-checked:block fixed inset-0 z-40 cursor-default select-none bg-transparent"
            aria-label="Close profile menu"
          />

          {/* Profile Avatar Clickable Trigger */}
          <label
            htmlFor="admin-topbar-profile-toggle"
            className="w-9 h-9 rounded-none bg-amber-100 hover:bg-amber-200 dark:bg-amber-500/20 dark:hover:bg-amber-500/30 text-amber-900 dark:text-amber-400 border border-amber-300 dark:border-amber-500/40 font-bold text-xs flex items-center justify-center cursor-pointer select-none relative z-10 transition-colors shadow-2xs"
            title="Open Profile Menu"
          >
            {initialLetter}
          </label>

          {/* User Profile Popup Modal */}
          <div className="hidden peer-checked:block absolute right-0 top-11 z-50 w-72 p-4 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 shadow-2xl rounded-none space-y-3 animate-in fade-in zoom-in-95 duration-150">
            {/* Profile Details Header */}
            <div className="flex items-center gap-3 pb-3 border-b border-neutral-100 dark:border-neutral-800">
              <div className="w-10 h-10 rounded-none bg-amber-100 dark:bg-amber-500/20 text-amber-900 dark:text-amber-400 font-bold text-sm flex items-center justify-center shrink-0 border border-amber-300/40">
                {initialLetter}
              </div>
              <div className="overflow-hidden min-w-0">
                <p className="text-xs font-bold text-neutral-900 dark:text-white truncate">{user.name}</p>
                <p className="text-[11px] text-neutral-500 dark:text-neutral-400 truncate">{user.email}</p>
                <div className="inline-flex items-center gap-1 text-[10px] text-amber-800 dark:text-amber-400 bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 px-1.5 py-0.5 rounded-none font-semibold mt-1">
                  <Shield size={9} />
                  <span>{user.role}</span>
                </div>
              </div>
            </div>

            {/* Navigation Links & Theme Toggle */}
            <div className="space-y-0.5">
              {/* Quick Theme Switch Row */}
              <button
                type="button"
                onClick={toggleTheme}
                className="w-full flex items-center justify-between px-3 py-2 rounded-none text-xs font-semibold text-neutral-700 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-50 dark:hover:bg-neutral-900 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  {isDark ? (
                    <Sun size={14} className="text-amber-400" />
                  ) : (
                    <Moon size={14} className="text-neutral-500" />
                  )}
                  <span>Theme: {isDark ? "Dark Mode" : "Light Mode"}</span>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-none bg-amber-400/10 text-amber-500 border border-amber-400/20">
                  Switch
                </span>
              </button>

              <Link
                href="/admin/settings?tab=security"
                className="flex items-center gap-2.5 px-3 py-2 rounded-none text-xs font-semibold text-neutral-700 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-50 dark:hover:bg-neutral-900 transition-colors"
              >
                <KeyRound size={14} className="text-amber-600 dark:text-amber-400" />
                <span>Change Password</span>
              </Link>

              <Link
                href="/admin/users"
                className="flex items-center gap-2.5 px-3 py-2 rounded-none text-xs font-semibold text-neutral-700 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-50 dark:hover:bg-neutral-900 transition-colors"
              >
                <Users size={14} className="text-neutral-500 dark:text-neutral-400" />
                <span>Admin & User Management</span>
              </Link>

              <Link
                href="/"
                target="_blank"
                className="flex items-center justify-between px-3 py-2 rounded-none text-xs font-semibold text-neutral-700 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-50 dark:hover:bg-neutral-900 transition-colors"
              >
                <div className="flex items-center gap-2.5">
                  <Globe size={14} className="text-amber-600 dark:text-amber-400" />
                  <span>Open Live Website</span>
                </div>
                <ExternalLink size={12} className="text-neutral-400 dark:text-neutral-500" />
              </Link>
            </div>

            {/* Logout Button */}
            <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800">
              <form method="POST" action="/api/auth/logout" className="w-full">
                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-none text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-500/10 text-xs font-bold transition-all cursor-pointer"
                >
                  <LogOut size={13} />
                  <span>Sign Out</span>
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}


