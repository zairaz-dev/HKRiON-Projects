import { useQuery } from "@tanstack/react-query";
import { reportService } from "@/services/report-service";
import { queryKeys } from "@/lib/query-keys";

export function useStockValuationQuery(
  businessId: string,
  filters: {
    branchId?: string;
    search?: string;
  },
) {
  return useQuery({
    queryKey: queryKeys.reports.stockValuation(
      businessId,
      filters.branchId,
      filters.search,
    ),
    queryFn: () => reportService.getStockValuation(businessId, filters),
    enabled: !!businessId,
  });
}
