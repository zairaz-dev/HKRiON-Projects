import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

const HEX_COLOR_REGEX = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;

@Injectable()
export class CategoriesService {
  constructor(private readonly prisma: PrismaService) {}

  async createCategory(data: {
    name: string;
    description?: string;
    imageUrl?: string;
    color?: string;
    isActive?: boolean;
    businessId: string;
    branchIds?: string[];
    parentId?: string | null;
    createdById?: string;
  }) {
    // 0. Field validations
    const trimmedName = data.name?.trim();
    if (!trimmedName) {
      throw new BadRequestException('Category name is required');
    }
    if (trimmedName.length < 2 || trimmedName.length > 100) {
      throw new BadRequestException('Category name must be between 2 and 100 characters');
    }

    if (!data.businessId || !data.businessId.trim()) {
      throw new BadRequestException('Business ID is required');
    }

    if (data.description && data.description.length > 500) {
      throw new BadRequestException('Description cannot exceed 500 characters');
    }

    if (data.color && !HEX_COLOR_REGEX.test(data.color)) {
      throw new BadRequestException('Invalid color format. Hex color code expected (e.g., #3B82F6)');
    }

    // 1. Verify parent category exists if parentId is provided
    if (data.parentId) {
      const parent = await this.prisma.category.findFirst({
        where: { id: data.parentId, businessId: data.businessId },
      });
      if (!parent) {
        throw new BadRequestException('Parent category not found');
      }
    }

    // 2. Verify all branches belong to the business
    if (data.branchIds && data.branchIds.length > 0) {
      const validBranches = await this.prisma.branch.findMany({
        where: {
          id: { in: data.branchIds },
          businessId: data.businessId,
        },
      });
      if (validBranches.length !== data.branchIds.length) {
        throw new BadRequestException('One or more selected branches are invalid');
      }
    }

    // 3. Check for duplicate name in the same scope (business, parent)
    const existing = await this.prisma.category.findFirst({
      where: {
        name: { equals: trimmedName, mode: 'insensitive' },
        businessId: data.businessId,
        parentId: data.parentId || null,
      },
    });

    if (existing) {
      throw new BadRequestException(
        data.parentId
          ? 'A subcategory with this name already exists under this parent'
          : 'A category with this name already exists in this business'
      );
    }

    // 4. Create Category and its CategoryBranch relations
    return this.prisma.category.create({
      data: {
        name: trimmedName,
        description: data.description ? data.description.trim() : undefined,
        imageUrl: data.imageUrl,
        color: data.color || '#3B82F6',
        ...(data.isActive !== undefined && { isActive: data.isActive }),
        businessId: data.businessId,
        parentId: data.parentId || null,
        createdById: data.createdById || null,
        branches: data.branchIds && data.branchIds.length > 0
          ? {
              create: data.branchIds.map((branchId) => ({
                branchId,
              })),
            }
          : undefined,
      },
      include: {
        parent: true,
        subCategories: true,
        branches: {
          include: {
            branch: true,
          },
        },
      },
    });
  }

  async getCategories(
    businessId: string,
    options: {
      page?: number;
      limit?: number;
      search?: string;
      branchId?: string;
      type?: string;
    } = {},
  ) {
    const page = Number(options.page) || 1;
    const limit = Number(options.limit) || 10;
    const skip = (page - 1) * limit;
    const take = limit;

    const whereClause: any = {
      businessId,
    };

    if (options.type) {
      if (options.type === 'parent') {
        whereClause.parentId = null;
      } else if (options.type === 'sub') {
        whereClause.parentId = { not: null };
      }
    }

    if (options.branchId) {
      if (options.branchId === 'global') {
        whereClause.branches = { none: {} };
      } else {
        whereClause.branches = {
          some: {
            branchId: options.branchId,
          },
        };
      }
    }

    if (options.search) {
      whereClause.OR = [
        { name: { contains: options.search, mode: 'insensitive' } },
        { description: { contains: options.search, mode: 'insensitive' } },
      ];
    }

    const [totalItems, data] = await Promise.all([
      this.prisma.category.count({ where: whereClause }),
      this.prisma.category.findMany({
        where: whereClause,
        skip,
        take,
        include: {
          parent: true,
          subCategories: true,
          branches: {
            include: {
              branch: {
                select: {
                  id: true,
                  name: true,
                },
              },
            },
          },
        },
        orderBy: {
          createdAt: 'asc',
        },
      }),
    ]);

    const totalPages = Math.ceil(totalItems / limit) || 1;

    return {
      data,
      meta: {
        totalItems,
        totalPages,
        currentPage: page,
        limit,
      },
    };
  }

  async getCategoryById(id: string, businessId: string) {
    const category = await this.prisma.category.findFirst({
      where: { id, businessId },
      include: {
        parent: true,
        subCategories: true,
        branches: {
          include: {
            branch: true,
          },
        },
      },
    });

    if (!category) {
      throw new BadRequestException('Category not found');
    }

    return category;
  }

  async updateCategory(
    id: string,
    businessId: string,
    data: {
      name?: string;
      description?: string;
      imageUrl?: string;
      color?: string;
      isActive?: boolean;
      branchIds?: string[]; // Array of branch IDs
      parentId?: string | null;
      updatedById?: string;
    },
  ) {
    const category = await this.getCategoryById(id, businessId);

    // 0. Field validations
    let trimmedName: string | undefined = undefined;
    if (data.name !== undefined) {
      trimmedName = data.name.trim();
      if (!trimmedName) {
        throw new BadRequestException('Category name cannot be empty');
      }
      if (trimmedName.length < 2 || trimmedName.length > 100) {
        throw new BadRequestException('Category name must be between 2 and 100 characters');
      }
    }

    if (data.description !== undefined && data.description !== null && data.description.length > 500) {
      throw new BadRequestException('Description cannot exceed 500 characters');
    }

    if (data.color !== undefined && data.color !== null && data.color !== '') {
      if (!HEX_COLOR_REGEX.test(data.color)) {
        throw new BadRequestException('Invalid color format. Hex color code expected (e.g., #3B82F6)');
      }
    }

    // 1. Verify parent category if parentId is changing
    if (data.parentId && data.parentId !== category.parentId) {
      if (data.parentId === id) {
        throw new BadRequestException('A category cannot be its own parent');
      }
      const parent = await this.prisma.category.findFirst({
        where: { id: data.parentId, businessId },
      });
      if (!parent) {
        throw new BadRequestException('Parent category not found');
      }

      // Circular hierarchy check: target parent cannot be a descendant of this category
      let currentParent: { id: string; parentId: string | null } | null = parent;
      while (currentParent && currentParent.parentId) {
        if (currentParent.parentId === id) {
          throw new BadRequestException('Circular hierarchy detected: cannot set a subcategory as parent');
        }
        currentParent = await this.prisma.category.findFirst({
          where: { id: currentParent.parentId, businessId },
          select: { id: true, parentId: true },
        });
      }
    }

    // 2. Verify all branches belong to the business if branchIds are changing
    if (data.branchIds && data.branchIds.length > 0) {
      const validBranches = await this.prisma.branch.findMany({
        where: {
          id: { in: data.branchIds },
          businessId,
        },
      });
      if (validBranches.length !== data.branchIds.length) {
        throw new BadRequestException('One or more selected branches are invalid');
      }
    }

    // 3. Check for duplicate name if name/parent is changing
    const nameChanged = trimmedName && trimmedName !== category.name;
    const parentChanged = data.parentId !== undefined && data.parentId !== category.parentId;

    if (nameChanged || parentChanged) {
      const checkName = trimmedName || category.name;
      const checkParent = data.parentId !== undefined ? data.parentId : category.parentId;

      const existing = await this.prisma.category.findFirst({
        where: {
          id: { not: id },
          name: { equals: checkName, mode: 'insensitive' },
          businessId,
          parentId: checkParent || null,
        },
      });

      if (existing) {
        throw new BadRequestException(
          checkParent
            ? 'A subcategory with this name already exists under the target parent'
            : 'A category with this name already exists in this business'
        );
      }
    }

    // 4. Update CategoryBranch relations if branchIds are provided
    if (data.branchIds !== undefined) {
      // Remove existing connections
      await this.prisma.categoryBranch.deleteMany({
        where: { categoryId: id },
      });

      // Add new connections
      if (data.branchIds.length > 0) {
        await this.prisma.categoryBranch.createMany({
          data: data.branchIds.map((branchId) => ({
            categoryId: id,
            branchId,
          })),
        });
      }
    }

    // Prepare update data for Category fields
    const updateData: any = {};
    if (trimmedName !== undefined) updateData.name = trimmedName;
    if (data.description !== undefined) updateData.description = data.description ? data.description.trim() : null;
    if (data.imageUrl !== undefined) updateData.imageUrl = data.imageUrl;
    if (data.color !== undefined) updateData.color = data.color;
    if (data.isActive !== undefined) updateData.isActive = data.isActive;
    if (data.parentId !== undefined) updateData.parentId = data.parentId;
    if (data.updatedById !== undefined) updateData.updatedById = data.updatedById;

    return this.prisma.category.update({
      where: { id },
      data: updateData,
      include: {
        parent: true,
        subCategories: true,
        branches: {
          include: {
            branch: true,
          },
        },
      },
    });
  }

  async deleteCategory(id: string, businessId: string) {
    await this.getCategoryById(id, businessId);

    // 1. Check if category is associated with products
    const productCount = await this.prisma.product.count({
      where: { categoryId: id },
    });
    if (productCount > 0) {
      throw new BadRequestException(
        `Cannot delete category because it is associated with ${productCount} product(s). Please reassign or remove the products first.`
      );
    }

    // 2. Check if category has subcategories
    const subCategoryCount = await this.prisma.category.count({
      where: { parentId: id, businessId },
    });
    if (subCategoryCount > 0) {
      throw new BadRequestException(
        `Cannot delete category because it has ${subCategoryCount} subcategory(ies). Please reassign or delete the subcategories first.`
      );
    }

    await this.prisma.category.delete({
      where: { id },
    });

    return { success: true };
  }
}
