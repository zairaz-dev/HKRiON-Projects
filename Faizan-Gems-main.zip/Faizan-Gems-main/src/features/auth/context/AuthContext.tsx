"use client";

import React, { createContext, useContext, useState, useEffect, useCallback } from "react";

export interface CustomerUser {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: "CUSTOMER" | "ADMIN";
  tier?: string;
  location?: string;
  salon?: string;
  totalSpent?: number;
  acquisitions?: number;
}

interface AuthContextType {
  user: CustomerUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (data: {
    name: string;
    email: string;
    password: string;
    phone?: string;
    location?: string;
    salon?: string;
  }) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  updateProfile: (data: {
    name?: string;
    phone?: string;
    location?: string;
    salon?: string;
  }) => Promise<{ success: boolean; error?: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<CustomerUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check current session on mount
  const checkSession = useCallback(async () => {
    try {
      const res = await fetch("/api/auth/me");
      if (res.ok) {
        const data = await res.json();
        if (data.authenticated && data.user) {
          setUser(data.user);
          try {
            localStorage.setItem("fg_auth_user", JSON.stringify(data.user));
          } catch {}
          return;
        }
      }
      setUser(null);
      try {
        localStorage.removeItem("fg_auth_user");
      } catch {}
    } catch {
      // Keep cached session if offline/error
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    checkSession();
  }, [checkSession]);

  const login = async (email: string, password: string) => {
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();

      if (!res.ok) {
        return { success: false, error: data.error || "Authentication failed" };
      }

      setUser(data.user);
      try {
        localStorage.setItem("fg_auth_user", JSON.stringify(data.user));
      } catch {}
      return { success: true };
    } catch {
      return { success: false, error: "Unable to connect to authentication server" };
    }
  };

  const register = async (data: {
    name: string;
    email: string;
    password: string;
    phone?: string;
    location?: string;
    salon?: string;
  }) => {
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const resData = await res.json();

      if (!res.ok) {
        return { success: false, error: resData.error || "Registration failed" };
      }

      setUser(resData.user);
      try {
        localStorage.setItem("fg_auth_user", JSON.stringify(resData.user));
      } catch {}
      return { success: true };
    } catch {
      return { success: false, error: "Unable to connect to registration server" };
    }
  };

  const logout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } finally {
      setUser(null);
      try {
        localStorage.removeItem("fg_auth_user");
      } catch {}
    }
  };

  const refreshProfile = async () => {
    await checkSession();
  };

  const updateProfile = async (data: { name?: string; phone?: string; location?: string; salon?: string }) => {
    try {
      const res = await fetch("/api/auth/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const resData = await res.json();
      if (!res.ok) {
        return { success: false, error: resData.error || "Failed to update profile" };
      }
      setUser((prev) => (prev ? { ...prev, ...data } : prev));
      return { success: true };
    } catch {
      return { success: false, error: "Network error updating profile" };
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        register,
        logout,
        refreshProfile,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
