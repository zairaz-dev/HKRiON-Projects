import { pool } from "@/lib/db";
import { DEFAULT_CMS_BLOCKS, type CMSData, type CMSFaqItem } from "@/features/cms/constants";
import type { RowDataPacket } from "mysql2";

export type { CMSData };

interface ContentBlockRow extends RowDataPacket {
  id: string;
  section: string;
  key: string;
  value: string;
  updated_at: string;
}

interface FaqItemRow extends RowDataPacket {
  id: string;
  question: string;
  answer: string;
  category: string;
  order_index: number;
  created_at: string;
  updated_at: string;
}

let serverCache: { data: CMSData; timestamp: number } | null = null;
const CACHE_TTL_MS = 30_000; // 30 seconds

/**
 * Flush server-side memory cache (called after admin mutations in /api/cms)
 */
export function invalidateServerCMSCache(): void {
  serverCache = null;
}

/**
 * Fetch all CMS blocks and FAQs directly from MySQL with fallback and in-memory caching.
 * Designed for Server Components and RootLayout SSR.
 */
export async function getCMSData(): Promise<CMSData> {
  const now = Date.now();
  if (serverCache && now - serverCache.timestamp < CACHE_TTL_MS) {
    return serverCache.data;
  }

  const fallback: CMSData = {
    blocks: { ...DEFAULT_CMS_BLOCKS },
    faqs: [],
  };

  try {
    const fetchPromise = (async (): Promise<CMSData> => {
      const [blockRows] = await pool.query<ContentBlockRow[]>(
        "SELECT id, section, `key`, `value`, updated_at FROM content_blocks ORDER BY section, `key`"
      );

      const [faqRows] = await pool.query<FaqItemRow[]>(
        "SELECT id, question, answer, category, order_index, created_at, updated_at FROM faq_items ORDER BY order_index ASC"
      );

      const blockMap: Record<string, string> = { ...DEFAULT_CMS_BLOCKS };
      for (const b of blockRows) {
        blockMap[`${b.section}.${b.key}`] = b.value;
        blockMap[b.key] = b.value;
      }

      const faqs: CMSFaqItem[] = faqRows.map((f) => ({
        id: String(f.id),
        question: f.question,
        answer: f.answer,
        category: f.category || "General",
        order_index: Number(f.order_index) || 0,
        created_at: f.created_at ? String(f.created_at) : undefined,
        updated_at: f.updated_at ? String(f.updated_at) : undefined,
      }));

      return { blocks: blockMap, faqs };
    })();

    const timeoutPromise = new Promise<CMSData>((_, reject) =>
      setTimeout(() => reject(new Error("CMS database query timeout")), 2500)
    );

    const result = await Promise.race([fetchPromise, timeoutPromise]);
    serverCache = { data: result, timestamp: Date.now() };
    return result;
  } catch (error) {
    // Graceful fallback to built-in defaults without crashing the page
    console.warn("CMS server fallback used:", (error as Error).message);
    return fallback;
  }
}

/**
 * Server-safe helper to read a CMS block with section.key or key syntax
 */
export function getBlock(
  blocks: Record<string, string>,
  sectionOrKey: string,
  keyOrFallback?: string,
  fallback?: string
): string {
  if (fallback !== undefined) {
    const fullKey = `${sectionOrKey}.${keyOrFallback}`;
    return blocks[fullKey] ?? fallback ?? DEFAULT_CMS_BLOCKS[fullKey] ?? "";
  }
  return blocks[sectionOrKey] ?? keyOrFallback ?? DEFAULT_CMS_BLOCKS[sectionOrKey] ?? "";
}
