"use strict";
"use client";

import React, { useEffect, useState } from "react";
import {
  Building2,
  CheckCircle2,
  XCircle,
  Power,
  Loader2,
  Globe,
  Activity,
  ShieldAlert,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { authService } from "@/services/auth-service";
import { LoadingSession } from "@/components/ui/loading-session";
import { DataTable, ColumnDef, ActionsDropdown } from "@/components/ui/table";

interface BusinessItem {
  id: string;
  name: string;
  industry: string;
  phone: string;
  isActive: boolean;
  country: string;
  ownerName: string;
  ownerEmail: string;
  createdAt: string;
}

export default function SuperAdminDashboard() {
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [businesses, setBusinesses] = useState<BusinessItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);
  const [error, setError] = useState<string>("");
  const [successMessage, setSuccessMessage] = useState<string>("");

  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed || (user && (user.role as string) !== "super-admin")) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
      return;
    }

    fetchBusinesses();
  }, []);

  const fetchBusinesses = async () => {
    setLoading(true);
    setError("");
    try {
      const data = await authService.getBusinesses();
      setBusinesses(data);
    } catch (err: any) {
      setError(err.message || "Failed to load businesses. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleToggleStatus = async (id: string, currentStatus: boolean) => {
    setActionLoadingId(id);
    setError("");
    try {
      const nextStatus = !currentStatus;
      await authService.toggleBusinessStatus(id, nextStatus, currentUser?.id || undefined);
      setBusinesses((prev) =>
        prev.map((b) => (b.id === id ? { ...b, isActive: nextStatus } : b))
      );
      setSuccessMessage(`Business status updated successfully!`);
      setTimeout(() => setSuccessMessage(""), 4000);
    } catch (err: any) {
      setError(err.message || "Failed to update status. Please try again.");
    } finally {
      setActionLoadingId(null);
    }
  };

  const totalBusinesses = businesses.length;
  const activeBusinesses = businesses.filter((b) => b.isActive).length;
  const inactiveBusinesses = totalBusinesses - activeBusinesses;

  // Dynamic Monthly Signups Data (last 6 months)
  const getMonthlySignups = () => {
    const months: { name: string; year: number; month: number; count: number }[] = [];
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      months.push({
        name: d.toLocaleDateString("en-US", { month: "short" }).toUpperCase(),
        year: d.getFullYear(),
        month: d.getMonth(),
        count: 0
      });
    }

    businesses.forEach((b) => {
      const date = new Date(b.createdAt);
      months.forEach((m) => {
        if (date.getMonth() === m.month && date.getFullYear() === m.year) {
          m.count += 1;
        }
      });
    });

    return months;
  };

  // Dynamic Industry distribution count
  const getIndustryStats = () => {
    const counts: Record<string, number> = {};
    businesses.forEach((b) => {
      const ind = b.industry?.trim() || "Other";
      counts[ind] = (counts[ind] || 0) + 1;
    });

    const total = businesses.length || 1;
    return Object.entries(counts)
      .map(([name, count]) => ({
        name,
        count,
        percentage: Math.round((count / total) * 100)
      }))
      .sort((a, b) => b.count - a.count);
  };

  const monthlyData = getMonthlySignups();
  const maxCount = Math.max(...monthlyData.map((d) => d.count), 5);
  const pointsD = monthlyData.map((d, i) => `${40 + i * 88} ${140 - (d.count / maxCount) * 100}`).join(" L ");

  const industryData = getIndustryStats();

  const columns: ColumnDef<BusinessItem>[] = [
    {
      header: "Business / Company",
      searchable: true,
      render: (business) => (
        <div className="flex flex-col gap-0.5">
          <span className="font-semibold text-foreground group-hover:text-primary transition-colors duration-150">
            {business.name}
          </span>
          <span className="text-[10px] text-muted-foreground">
            {business.phone} • {business.country}
          </span>
        </div>
      ),
    },
    {
      header: "Industry",
      render: (business) => (
        <span className="text-xs font-semibold text-foreground/80 capitalize">
          {business.industry}
        </span>
      ),
    },
    {
      header: "Owner Info",
      render: (business) => (
        <div className="flex flex-col gap-0.5">
          <span className="font-medium text-foreground">{business.ownerName}</span>
          <span className="text-[10px] text-muted-foreground font-mono">{business.ownerEmail}</span>
        </div>
      ),
    },
    {
      header: "Registered",
      render: (business) => (
        <span className="text-xs font-mono text-muted-foreground">
          {new Date(business.createdAt).toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric",
          })}
        </span>
      ),
    },
    {
      header: "Status",
      render: (business) => (
        <span
          className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${
            business.isActive
              ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
              : "bg-rose-500/10 text-rose-500 border-rose-500/20"
          }`}
        >
          {business.isActive ? "Active" : "Suspended"}
        </span>
      ),
    },
    {
      header: "Actions",
      render: (business) => (
        <ActionsDropdown
          actions={[
            {
              label: business.isActive ? "Deactivate" : "Activate",
              onClick: () => handleToggleStatus(business.id, business.isActive),
              icon: actionLoadingId === business.id ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Power className="h-3.5 w-3.5" />
              ),
              variant: business.isActive ? ("destructive" as const) : ("default" as const),
            },
          ]}
        />
      ),
    },
  ];

  if (isAuthenticated === null) {
    return <LoadingSession />;
  }

  if (isAuthenticated === false || (currentUser && (currentUser.role as string) !== "super-admin")) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-4 text-center p-4">
        <ShieldAlert className="w-12 h-12 text-red-500 animate-bounce" />
        <h2 className="text-xl font-bold text-white">Access Denied</h2>
        <p className="text-sm text-slate-400 max-w-sm">
          You do not have permission to view the Super Admin dashboard. Redirecting to login...
        </p>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      {/* Sidebar */}
      <Sidebar activePath="/super" />

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        {/* Glowing Background Orbs */}
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-emerald-500/5 blur-[120px] pointer-events-none z-0" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[550px] h-[550px] rounded-full bg-teal-500/5 blur-[130px] pointer-events-none z-0" />

        {/* Navbar */}
        <Navbar title="Super Admin Console" />

        {/* Scrollable Main Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 relative z-10">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <Globe className="h-7 w-7 text-primary" /> Super Admin Console
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Global platform management and business registry.
              </p>
            </div>
          </div>

          {/* Notification Messages */}
          {successMessage && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 animate-in fade-in slide-in-from-top-4 duration-300">
              <CheckCircle2 className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive animate-in fade-in slide-in-from-top-4 duration-300">
              <ShieldAlert className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          {/* Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="glass border-slate-800/80">
              <CardContent className="p-6 flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-semibold text-slate-400 font-mono uppercase tracking-wider">Total Businesses</p>
                  <h3 className="text-2xl font-bold text-white tracking-tight mt-1">{totalBusinesses}</h3>
                </div>
                <div className="p-2.5 rounded-sm bg-primary/10 text-primary">
                  <Building2 className="w-5 h-5" />
                </div>
              </CardContent>
            </Card>

            <Card className="glass border-slate-800/80">
              <CardContent className="p-6 flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-semibold text-slate-400 font-mono uppercase tracking-wider">Active Businesses</p>
                  <h3 className="text-2xl font-bold text-emerald-400 tracking-tight mt-1">{activeBusinesses}</h3>
                </div>
                <div className="p-2.5 rounded-sm bg-emerald-600/10 text-emerald-450">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
              </CardContent>
            </Card>

            <Card className="glass border-slate-800/80">
              <CardContent className="p-6 flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-semibold text-slate-400 font-mono uppercase tracking-wider">Inactive / Suspended</p>
                  <h3 className="text-2xl font-bold text-rose-450 tracking-tight mt-1">{inactiveBusinesses}</h3>
                </div>
                <div className="p-2.5 rounded-sm bg-rose-600/10 text-rose-450">
                  <XCircle className="w-5 h-5" />
                </div>
              </CardContent>
            </Card>

            <Card className="glass border-slate-800/80">
              <CardContent className="p-6 flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-semibold text-slate-400 font-mono uppercase tracking-wider">System Status</p>
                  <h3 className="text-xs font-bold text-emerald-450 tracking-tight mt-2 flex items-center gap-1.5 font-mono">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" /> ONLINE
                  </h3>
                </div>
                <div className="p-2.5 rounded-sm bg-primary/10 text-primary">
                  <Activity className="w-5 h-5" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Analytics Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* SVG Monthly Signups Chart */}
            <Card className="glass lg:col-span-2">
              <div className="p-6">
                <div className="flex items-center justify-between pb-4 border-b border-border/50">
                  <div>
                    <h3 className="text-sm font-semibold text-foreground tracking-tight">Business Registration Trend</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">Monthly registration growth (last 6 months)</p>
                  </div>
                  <span className="text-xs font-mono text-primary font-bold px-2.5 py-0.5 rounded-full bg-primary/10 border border-primary/20">
                    +{businesses.filter(b => {
                      const oneMonthAgo = new Date();
                      oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
                      return new Date(b.createdAt) > oneMonthAgo;
                    }).length} this month
                  </span>
                </div>

                <div className="pt-6">
                  {/* SVG Chart */}
                  <div className="w-full flex flex-col justify-between h-56">
                    <svg className="w-full h-44" viewBox="0 0 520 160" preserveAspectRatio="none">
                      {/* Gradients */}
                      <defs>
                        <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.25" />
                          <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0.0" />
                        </linearGradient>
                      </defs>

                      {/* Grid Lines */}
                      <line x1="40" y1="20" x2="480" y2="20" stroke="currentColor" className="text-border/30" strokeDasharray="3,3" />
                      <line x1="40" y1="60" x2="480" y2="60" stroke="currentColor" className="text-border/30" strokeDasharray="3,3" />
                      <line x1="40" y1="100" x2="480" y2="100" stroke="currentColor" className="text-border/30" strokeDasharray="3,3" />
                      <line x1="40" y1="140" x2="480" y2="140" stroke="currentColor" className="text-border" />

                      {/* Area Under Line */}
                      {pointsD && <path d={`M 40 140 L ${pointsD} L 480 140 Z`} fill="url(#areaGrad)" />}

                      {/* Top Stroke Line */}
                      {pointsD && <path d={`M ${pointsD}`} fill="none" stroke="hsl(var(--primary))" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />}

                      {/* Circle Dots and Tooltips */}
                      {monthlyData.map((d, i) => {
                        const cx = 40 + i * 88;
                        const cy = 140 - (d.count / maxCount) * 100;
                        return (
                          <g key={i} className="group/dot cursor-pointer">
                            <circle
                              cx={cx}
                              cy={cy}
                              r="4"
                              fill="currentColor"
                              className="text-background stroke-primary stroke-2 hover:r-5 transition-all duration-150"
                            />
                            {/* Hover Value Tooltip/Label */}
                            <text
                              x={cx}
                              y={cy - 10}
                              textAnchor="middle"
                              className="text-[9px] font-mono font-bold fill-primary opacity-0 group-hover/dot:opacity-100 transition-opacity duration-150 bg-background"
                            >
                              {d.count}
                            </text>
                          </g>
                        );
                      })}
                    </svg>

                    {/* X-Axis Labels */}
                    <div className="flex justify-between text-[10px] font-mono text-muted-foreground/60 px-[26px] mt-2">
                      {monthlyData.map((d, i) => (
                        <span key={i}>{d.name}</span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            {/* Industry Distribution Breakdown */}
            <Card className="glass lg:col-span-1">
              <div className="p-6 h-full flex flex-col justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-foreground tracking-tight pb-4 border-b border-border/50">Industry Distribution</h3>
                  <div className="space-y-4 pt-6 max-h-[170px] overflow-y-auto pr-1">
                    {industryData.length === 0 ? (
                      <p className="text-xs text-muted-foreground text-center py-6 italic">No industry details available</p>
                    ) : (
                      industryData.map((item, idx) => (
                        <div key={idx} className="space-y-1.5">
                          <div className="flex items-center justify-between text-xs font-semibold">
                            <span className="text-foreground/90 capitalize">{item.name}</span>
                            <span className="font-mono text-primary text-[10px]">{item.count} ({item.percentage}%)</span>
                          </div>
                          <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-primary rounded-full transition-all duration-500" 
                              style={{ width: `${item.percentage}%` }} 
                            />
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </Card>

          </div>

          {/* Main Table Card */}
          {loading ? (
            <div className="flex h-64 items-center justify-center">
              <div className="text-center space-y-2">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
                <span className="text-sm text-muted-foreground block">Loading business registry...</span>
              </div>
            </div>
          ) : (
            <DataTable
              data={businesses}
              columns={columns}
              searchKeys={["name", "ownerName", "ownerEmail", "industry"]}
              searchPlaceholder="Search businesses..."
              reportTitle="Super Admin Business Registry"
            />
          )}
        </main>
      </div>
    </div>
  );
}
