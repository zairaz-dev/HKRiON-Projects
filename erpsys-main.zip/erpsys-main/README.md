# HKRION ERP

> **Modern, Scalable, and Hybrid Enterprise Resource Planning (ERP) System**
>
> A complete enterprise resource planning software featuring a NestJS API backend, a Next.js web frontend, and hybrid mobile capabilities powered by Capacitor.js.

---

## 🛠️ Technology Stack

| Component           | Technologies Used                                                                  |
| :------------------ | :--------------------------------------------------------------------------------- |
| **Backend API**     | NestJS, TypeScript, Prisma ORM, PostgreSQL, Passport JWT, Scalar API Reference     |
| **Web Frontend**    | Next.js, React, TailwindCSS, Zustand (State Management), React Query, Lucide Icons |
| **Mobile App**      | Capacitor.js (Hybrid Android/iOS SDK integration)                                  |
| **Package Manager** | `pnpm` (Recommended) / `npm`                                                       |

---

## 📁 Project Structure

```yaml
HKRION ERP/
├── backend/          # NestJS API Backend & Prisma Database Schema
│   ├── src/          # API Source code (TypeScript)
│   ├── prisma/       # Database Schema & Migrations / Seeds
│   └── package.json  # Backend dependencies & scripts
├── web/              # Next.js Frontend & Capacitor Mobile project
│   ├── src/          # Frontend Web Pages & Components (React)
│   ├── android/      # Capacitor Android native project
│   └── package.json  # Frontend dependencies & scripts
└── README.md         # This documentation
```

---

## ⚡ Quick Start Guide

### 📌 Prerequisites

- **Node.js**: Version 18.x or above (LTS recommended)
- **PostgreSQL**: Local Database server running
- **Package Manager**: `pnpm` is highly recommended (or `npm`)

---

### 1️⃣ Backend Setup

1. **Navigate to backend**:

   ```bash
   cd backend
   ```

2. **Install dependencies**:

   ```bash
   pnpm install
   # or
   npm install --legacy-peer-deps
   ```

3. **Configure Environment Variables**:
   Create a `backend/.env` file and configure your PostgreSQL connection:

   ```env
   DB_HOST="localhost"
   DB_PORT="5432"
   DB_USER="postgres"
   DB_PASSWORD="your_password"
   DB_NAME="hkrionerp"
   DB_SCHEMA="public"
   DATABASE_URL="postgresql://${DB_USER}:${DB_PASSWORD}@${DB_HOST}:${DB_PORT}/${DB_NAME}?schema=${DB_SCHEMA}"
   ```

4. **Sync Database Schema**:

   ```bash
   # Generate Prisma client
   npx prisma generate

   # Push schema changes to your database
   npx prisma db push
   ```

5. **Start the API server**:
   ```bash
   pnpm start:dev
   # or
   npm run start:dev
   ```
   _The API will run at `http://localhost:3000`._

---

### 2️⃣ Web Frontend Setup

1. **Navigate to web**:

   ```bash
   cd ../web
   ```

2. **Install dependencies**:

   ```bash
   pnpm install
   # or
   npm install
   ```

3. **Configure Environment Variables**:
   Create a `web/.env.local` file and point it to the API URL:

   ```env
   NEXT_PUBLIC_API_URL="http://localhost:3000"
   ```

4. **Start the web application**:
   ```bash
   pnpm dev
   # or
   npm run dev
   ```
   _Open `http://localhost:3000` (or the printed port) in your browser._

---

## 📱 Mobile App Development (Capacitor Android)

This web application can be compiled into an Android App using Capacitor.

1. **Build the Next.js frontend**:

   ```bash
   # Run inside the web directory
   pnpm build
   ```

2. **Sync files with the Android project**:

   ```bash
   pnpm cap:sync
   # or
   npx cap sync
   ```

3. **Open in Android Studio**:
   ```bash
   pnpm cap:open:android
   # or
   npx cap open android
   ```
   _You can then build and run the application on your physical device or emulator using Android Studio._

---

## 🚀 Deployment Guide

### Frontend Deployment

- **Vercel / Netlify**: Connect the `web` folder to Vercel/Netlify for easy hosting.
- Make sure to update `NEXT_PUBLIC_API_URL` to your production API URL in the environment variables.

### Backend Deployment

- **VPS hosting**: Run NestJS using PM2 to keep it alive in the background.
  ```bash
  pnpm build
  pm2 start dist/main.js --name "hkr-erp-api"
  ```

---

_For detailed component-specific documentation, check `backend/README.md` or `web/README.md`._

network payload size-a optimize
