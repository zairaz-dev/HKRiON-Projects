/**
 * Client-side gemstone video compressor and 8-second time limiter.
 * Compresses video frames via HTML5 Canvas + MediaRecorder and strictly
 * caps showcase duration to 8 seconds.
 */

export interface CompressionResult {
  file: File;
  duration: number;
  originalSize: number;
  compressedSize: number;
  wasTrimmed: boolean;
  previewUrl: string;
}

export interface CompressionProgressCallback {
  (progressPercent: number, statusMessage: string): void;
}

/**
 * Inspect video duration in seconds without full decompression
 */
export async function getVideoDuration(file: File): Promise<number> {
  return new Promise((resolve, reject) => {
    const video = document.createElement("video");
    video.preload = "metadata";
    video.muted = true;
    video.playsInline = true;

    const url = URL.createObjectURL(file);
    video.src = url;

    video.onloadedmetadata = () => {
      URL.revokeObjectURL(url);
      resolve(video.duration);
    };

    video.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Unable to read video metadata. Please ensure this is a valid video file."));
    };
  });
}

/**
 * Compress gemstone showcase video and enforce 8-second maximum duration limit.
 */
export async function compressAndLimitVideo(
  file: File,
  maxDurationSeconds: number = 8.0,
  onProgress?: CompressionProgressCallback
): Promise<CompressionResult> {
  const originalSize = file.size;

  // 1. Check MediaRecorder browser support
  if (typeof window === "undefined" || typeof MediaRecorder === "undefined") {
    const dur = await getVideoDuration(file);
    if (dur > maxDurationSeconds + 0.5) {
      throw new Error(
        `Video duration is ${dur.toFixed(1)}s. Showcase videos cannot exceed ${maxDurationSeconds} seconds.`
      );
    }
    return {
      file,
      duration: dur,
      originalSize,
      compressedSize: originalSize,
      wasTrimmed: false,
      previewUrl: URL.createObjectURL(file),
    };
  }

  onProgress?.(5, "Analyzing video format & duration...");

  return new Promise((resolve, reject) => {
    const video = document.createElement("video");
    video.preload = "auto";
    video.muted = true;
    video.playsInline = true;
    video.crossOrigin = "anonymous";

    const objectUrl = URL.createObjectURL(file);
    video.src = objectUrl;

    video.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error("Failed to load video for compression."));
    };

    video.onloadedmetadata = async () => {
      const originalDuration = video.duration;
      const targetDuration = Math.min(originalDuration, maxDurationSeconds);
      const wasTrimmed = originalDuration > maxDurationSeconds + 0.1;

      const isMp4 =
        file.type === "video/mp4" ||
        file.type === "video/x-m4v" ||
        file.name.toLowerCase().endsWith(".mp4") ||
        file.name.toLowerCase().endsWith(".m4v");

      // Direct MP4 passthrough: if already MP4, <= 8.1s, and <= 25MB, preserve 100% native H.264 quality without re-compression loss
      if (isMp4 && !wasTrimmed && originalSize <= 25 * 1024 * 1024) {
        onProgress?.(100, `MP4 video validated (${originalDuration.toFixed(1)}s). Ready for upload!`);
        URL.revokeObjectURL(objectUrl);
        resolve({
          file,
          duration: originalDuration,
          originalSize,
          compressedSize: originalSize,
          wasTrimmed: false,
          previewUrl: URL.createObjectURL(file),
        });
        return;
      }

      if (wasTrimmed) {
        onProgress?.(15, `Video is ${originalDuration.toFixed(1)}s. Trimming to 8-second showcase limit...`);
      } else {
        onProgress?.(15, `Compressing ${originalDuration.toFixed(1)}s showcase video...`);
      }

      // Compute scaled dimensions (cap max resolution to 720p for fast web delivery & high clarity)
      const maxDimension = 720;
      let targetWidth = video.videoWidth || 720;
      let targetHeight = video.videoHeight || 720;

      if (targetWidth > maxDimension || targetHeight > maxDimension) {
        if (targetWidth >= targetHeight) {
          targetHeight = Math.round((targetHeight / targetWidth) * maxDimension);
          targetWidth = maxDimension;
        } else {
          targetWidth = Math.round((targetWidth / targetHeight) * maxDimension);
          targetHeight = maxDimension;
        }
      }

      // Ensure dimensions are even numbers (requirement for certain video encoders)
      targetWidth = targetWidth % 2 === 0 ? targetWidth : targetWidth - 1;
      targetHeight = targetHeight % 2 === 0 ? targetHeight : targetHeight - 1;

      const canvas = document.createElement("canvas");
      canvas.width = targetWidth;
      canvas.height = targetHeight;
      const ctx = canvas.getContext("2d", { alpha: false });

      if (!ctx) {
        URL.revokeObjectURL(objectUrl);
        reject(new Error("Could not initialize video processing canvas."));
        return;
      }

      // Determine best supported MIME type, prioritizing MP4 formats
      const candidateMimeTypes = [
        "video/mp4;codecs=avc1.42E01E,mp4a.40.2",
        "video/mp4;codecs=avc1",
        "video/mp4;codecs=h264",
        "video/mp4",
        "video/webm;codecs=vp9",
        "video/webm;codecs=vp8",
        "video/webm",
      ];

      let mimeType = "";
      let fileExt = "mp4";

      for (const candidate of candidateMimeTypes) {
        if (MediaRecorder.isTypeSupported(candidate)) {
          mimeType = candidate;
          fileExt = candidate.startsWith("video/mp4") ? "mp4" : "webm";
          break;
        }
      }

      if (!mimeType) {
        mimeType = "video/webm";
        fileExt = "webm";
      }

      // 1.8 Mbps bitrate produces crystal-clear 8-second gemstone facets at ~1-2 MB size
      const bitrate = 1_800_000;
      let stream: MediaStream;
      try {
        stream = canvas.captureStream(30);
      } catch (err) {
        URL.revokeObjectURL(objectUrl);
        reject(new Error("Browser does not support canvas video streaming: " + String(err)));
        return;
      }

      let recorder: MediaRecorder;
      try {
        recorder = new MediaRecorder(stream, {
          mimeType,
          videoBitsPerSecond: bitrate,
        });
      } catch {
        try {
          recorder = new MediaRecorder(stream);
        } catch (err2) {
          URL.revokeObjectURL(objectUrl);
          reject(new Error("MediaRecorder could not be initialized: " + String(err2)));
          return;
        }
      }

      const recordedChunks: Blob[] = [];
      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          recordedChunks.push(e.data);
        }
      };

      let animFrameId: number | null = null;
      let isCompleted = false;

      const finishRecording = () => {
        if (isCompleted) return;
        isCompleted = true;

        if (animFrameId) cancelAnimationFrame(animFrameId);
        video.pause();

        if (recorder.state !== "inactive") {
          recorder.stop();
        }
      };

      recorder.onstop = () => {
        URL.revokeObjectURL(objectUrl);

        const blob = new Blob(recordedChunks, { type: mimeType });
        const cleanBaseName = file.name.replace(/\.[^/.]+$/, "").replace(/[^a-zA-Z0-9_-]/g, "_");
        const compressedFileName = `${cleanBaseName}-8s.${fileExt}`;
        const outputMime = fileExt === "mp4" ? "video/mp4" : mimeType;
        const finalFile = new File([blob], compressedFileName, { type: outputMime });

        const previewUrl = URL.createObjectURL(blob);
        onProgress?.(100, "Compression complete!");

        resolve({
          file: finalFile,
          duration: targetDuration,
          originalSize,
          compressedSize: finalFile.size,
          wasTrimmed,
          previewUrl,
        });
      };

      // Start recording
      recorder.start(100); // 100ms timeslices
      video.currentTime = 0;

      try {
        await video.play();
      } catch (playErr) {
        finishRecording();
        URL.revokeObjectURL(objectUrl);
        reject(new Error("Could not playback video for encoding: " + String(playErr)));
        return;
      }

      // Draw frames synchronized to canvas
      const drawFrame = () => {
        if (isCompleted) return;

        ctx.drawImage(video, 0, 0, targetWidth, targetHeight);

        const current = video.currentTime;
        const pct = Math.min(95, Math.round(20 + (current / targetDuration) * 75));
        onProgress?.(
          pct,
          wasTrimmed
            ? `Encoding & trimming: ${current.toFixed(1)}s / ${targetDuration.toFixed(1)}s...`
            : `Compressing quality: ${current.toFixed(1)}s / ${targetDuration.toFixed(1)}s...`
        );

        if (current >= targetDuration || video.ended || video.paused) {
          finishRecording();
        } else {
          animFrameId = requestAnimationFrame(drawFrame);
        }
      };

      animFrameId = requestAnimationFrame(drawFrame);

      // Safety timeout: stop after (targetDuration + 1) seconds in real-time
      setTimeout(() => {
        if (!isCompleted) {
          finishRecording();
        }
      }, (targetDuration + 1.5) * 1000);
    };
  });
}
