"use client";

import React, { useState, useMemo, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { Gemstone, GemstoneVariant } from "@/types/gemstone";
import { useCurrency } from "@/features/currency/context/CurrencyContext";
import { useCart } from "@/features/cart/context/CartContext";
import { useWishlist } from "@/features/wishlist/context/WishlistContext";
import {
  CloseIcon,
  HeartIcon,
  BagIcon,
  CertificateShieldIcon,
  ArmoredTruckIcon,
  SecurityLockIcon
} from "@/components/ui/LuxuryIcons";
import { LuxuryPrice } from "@/components/ui/LuxuryPrice";

interface QuickViewModalProps {
  gemstone: Gemstone;
  onClose: () => void;
}

export function QuickViewModal({ gemstone, onClose }: QuickViewModalProps) {
  const { formatPrice } = useCurrency();
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [showVideo, setShowVideo] = useState(false);
  const [addedAnimation, setAddedAnimation] = useState(false);
  const isFavorited = isInWishlist(gemstone.id);

  useEffect(() => {
    setShowVideo(false);
    setActiveImageIndex(0);
  }, [gemstone.id]);

  // Prevent background scrolling & handle Escape key
  useEffect(() => {
    document.body.style.overflow = "hidden";
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [onClose]);

  // Available variants with backward-compatible fallback
  const availableVariants: GemstoneVariant[] = useMemo(() => {
    if (gemstone.variants && gemstone.variants.length > 0) {
      return gemstone.variants;
    }
    return [
      {
        id: `var-${gemstone.id}-default`,
        weight: gemstone.carat || 1.0,
        price: gemstone.price || 50000,
        stock: gemstone.inStock ? 5 : 0,
        size: gemstone.dimensions && (gemstone.dimensions.length > 0 || gemstone.dimensions.width > 0)
          ? `${gemstone.dimensions.length} × ${gemstone.dimensions.width}${gemstone.dimensions.depth ? ` × ${gemstone.dimensions.depth}` : ""} mm`
          : undefined,
      },
    ];
  }, [gemstone]);

  const [selectedVariantIndex, setSelectedVariantIndex] = useState(0);
  const activeVariant = availableVariants[selectedVariantIndex] || availableVariants[0];

  // Quantity selection state
  const [quantity, setQuantity] = useState(1);
  const maxStock = activeVariant?.stock ?? 0;
  const isOutOfStock = gemstone.inStock === false || maxStock <= 0;

  const handleSelectVariant = (index: number) => {
    setSelectedVariantIndex(index);
    setQuantity(1);
  };

  const handleAddToCart = () => {
    if (isOutOfStock) return;
    addToCart(gemstone, "loose", undefined, activeVariant, quantity);
    setAddedAnimation(true);
    setTimeout(() => {
      onClose();
    }, 450);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/65 backdrop-blur-sm animate-luxury-backdrop"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl bg-white border border-[#E8E4DC] shadow-2xl overflow-hidden max-h-[92vh] flex flex-col md:flex-row animate-luxury-modal"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close modal"
          className="absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-white/90 text-[#18181D] hover:bg-[#18181D] hover:text-white flex items-center justify-center transition-colors shadow-sm"
        >
          <CloseIcon className="w-4 h-4" />
        </button>

        {/* Left: Gallery */}
        <div className="w-full md:w-1/2 bg-[#F7F5F1] p-6 flex flex-col justify-between">
          {showVideo && gemstone.video ? (
            <div className="relative aspect-square w-full overflow-hidden bg-black border border-[#E8E4DC] flex items-center justify-center">
              <video
                key={gemstone.video}
                autoPlay
                loop
                muted
                playsInline
                controls
                preload="auto"
                className="w-full h-full object-contain"
              >
                <source src={gemstone.video} type={gemstone.video.endsWith(".webm") ? "video/webm" : "video/mp4"} />
                Your browser does not support the video tag.
              </video>
              <div className="absolute top-3 left-3 bg-black/80 backdrop-blur-md px-2.5 py-1 text-[10px] font-mono text-[#C5A880] border border-[#C5A880]/40 flex items-center gap-1.5 pointer-events-none">
                <span className="w-1.5 h-1.5 rounded-full bg-[#C5A880]" />
                <span>8s Video View</span>
              </div>
              <button
                onClick={() => setShowVideo(false)}
                className="absolute bottom-3 right-3 bg-white/90 hover:bg-white text-[#18181D] text-[10px] uppercase font-sans tracking-wider px-2.5 py-1 rounded shadow"
              >
                View Photos
              </button>
            </div>
          ) : (
            <div className="relative aspect-square w-full overflow-hidden bg-white border border-[#E8E4DC]">
              <Image
                src={gemstone.images[activeImageIndex] || gemstone.images[0] || "/uploads/gemstones/gem-1789652077476-hwzsqu.webp"}
                alt={gemstone.name}
                fill
                unoptimized={Boolean(
                  (gemstone.images[activeImageIndex] || gemstone.images[0])?.startsWith("/uploads")
                )}
                className="object-cover object-center"
              />
              <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-sm px-2.5 py-1 text-[11px] font-sans uppercase tracking-wider text-[#18181D] border border-[#E8E4DC]">
                {activeVariant.weight.toFixed(2)} CT • {gemstone.cut}
              </div>
              {gemstone.video && (
                <button
                  onClick={() => setShowVideo(true)}
                  className="absolute bottom-3 right-3 bg-black/80 hover:bg-black text-[#C5A880] text-[10px] font-mono uppercase tracking-wider px-2.5 py-1 rounded border border-[#C5A880]/40 backdrop-blur-sm flex items-center gap-1.5 transition-transform hover:scale-105 shadow-md"
                >
                  <span className="text-[10px]">▶</span>
                  <span>8s Video</span>
                </button>
              )}
            </div>
          )}

          {/* Thumbnails */}
          {(gemstone.images.length > 1 || Boolean(gemstone.video)) && (
            <div className="flex gap-2 mt-4 overflow-x-auto pb-1 no-scrollbar">
              {gemstone.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setShowVideo(false);
                    setActiveImageIndex(idx);
                  }}
                  className={`relative w-16 h-16 flex-shrink-0 border transition-all ${
                    !showVideo && activeImageIndex === idx
                      ? "border-[#C5A880] ring-1 ring-[#C5A880]"
                      : "border-[#E8E4DC] opacity-70 hover:opacity-100"
                  }`}
                >
                  <Image src={img} alt={`Angle ${idx + 1}`} fill unoptimized={img.startsWith("/uploads")} className="object-cover" />
                </button>
              ))}
              {gemstone.video && (
                <button
                  onClick={() => setShowVideo(true)}
                  className={`relative w-16 h-16 flex-shrink-0 border transition-all bg-black flex flex-col items-center justify-center p-1 ${
                    showVideo
                      ? "border-[#C5A880] ring-1 ring-[#C5A880]"
                      : "border-[#E8E4DC] opacity-70 hover:opacity-100"
                  }`}
                  title="Watch 8s Showcase Video"
                >
                  <div className="w-6 h-6 rounded-full bg-[#C5A880] text-black flex items-center justify-center mb-0.5">
                    <span className="text-[9px] ml-0.5 font-bold">▶</span>
                  </div>
                  <span className="text-[8px] uppercase font-mono text-[#C5A880] font-bold">
                    8s Video
                  </span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Right: Specifications & Interactive Acquisition */}
        <div className="w-full md:w-1/2 p-6 md:p-8 flex flex-col justify-between overflow-y-auto max-h-[92vh]">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 bg-[#FAF8F5] border border-[#C5A880]/30 text-[#9A7B4F] text-[11px] uppercase tracking-widest font-sans font-medium">
                Natural {gemstone.type}
              </span>
              <span className="text-[11px] uppercase tracking-wider text-[#8C867D] font-sans">
                SKU: {gemstone.sku}
              </span>
            </div>

            <h2 className="font-serif text-2xl md:text-3xl text-[#18181D] leading-tight">
              {gemstone.name}
            </h2>

            {/* Dynamic Price & Stock Availability Row */}
            <div className="mt-3.5 flex flex-wrap items-baseline justify-between gap-3 pb-3 border-b border-[#F2EFE9]">
              <div className="flex items-baseline gap-2">
                <LuxuryPrice amount={activeVariant.price} size="2xl" weight="bold" />
                <span className="text-xs text-[#8C867D] font-sans">
                  (Insured Hand-Delivery)
                </span>
              </div>

              {/* Stock Status Badge */}
              <div>
                {!isOutOfStock ? (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-sans font-medium">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                    ✓ In Stock ({activeVariant.stock} available)
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-rose-50 border border-rose-200 text-rose-700 text-xs font-sans font-medium">
                    ✕ Out of Stock
                  </span>
                )}
              </div>
            </div>

            {/* Carat Weight Options */}
            <div className="mt-4">
              <label className="block text-[11px] uppercase tracking-wider text-[#8C867D] font-sans mb-1.5">
                Select Carat Weight:
              </label>
              <div className="flex flex-wrap gap-2">
                {availableVariants.map((variant, idx) => {
                  const isSelected = selectedVariantIndex === idx;
                  const variantOutOfStock = variant.stock <= 0;
                  return (
                    <button
                      key={variant.id}
                      type="button"
                      onClick={() => handleSelectVariant(idx)}
                      className={`px-3.5 py-2 text-xs font-sans rounded-sm border transition-all flex items-center gap-1.5 ${
                        isSelected
                          ? "border-[#18181D] bg-[#18181D] text-white shadow-sm ring-1 ring-[#18181D]"
                          : variantOutOfStock
                          ? "border-[#E8E4DC] bg-[#FAF8F5] text-[#A29F96] opacity-60"
                          : "border-[#E8E4DC] bg-white text-[#18181D] hover:border-[#C5A880]"
                      }`}
                    >
                      <span className="font-medium">{variant.weight.toFixed(2)} carat</span>
                      <span className={`text-[10px] ${isSelected ? "text-[#E0CFA9]" : "text-[#8C867D]"}`}>
                        • {formatPrice(variant.price)}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Quantity Selector */}
            <div className="mt-4 flex items-center justify-between p-3 bg-[#FAF8F5] border border-[#E8E4DC] rounded-sm">
              <div>
                <span className="block text-xs font-sans font-medium text-[#18181D]">
                  Acquisition Quantity
                </span>
                <span className="text-[10px] text-[#8C867D] font-sans">
                  Maximum {maxStock} specimen(s) available in vault
                </span>
              </div>

              <div className="inline-flex items-center border border-[#E8E4DC] bg-white rounded-sm">
                <button
                  type="button"
                  disabled={quantity <= 1 || isOutOfStock}
                  onClick={() => setQuantity((prev) => Math.max(1, prev - 1))}
                  className="px-3 py-1.5 text-xs text-[#18181D] hover:bg-[#FAF8F5] disabled:opacity-30 transition-colors"
                >
                  -
                </button>
                <span className="px-3 py-1.5 text-xs font-mono font-semibold text-[#18181D]">
                  {isOutOfStock ? 0 : quantity}
                </span>
                <button
                  type="button"
                  disabled={quantity >= maxStock || isOutOfStock}
                  onClick={() => setQuantity((prev) => Math.min(maxStock, prev + 1))}
                  className="px-3 py-1.5 text-xs text-[#18181D] hover:bg-[#FAF8F5] disabled:opacity-30 transition-colors"
                >
                  +
                </button>
              </div>
            </div>

            {/* Exact 7-Point Spec List requested by user */}
            <div className="mt-5 border-t border-b border-[#F2EFE9] py-3.5 space-y-2 text-xs font-sans">
              <div className="flex items-center justify-between">
                <span className="text-[#8C867D]">Gem type:</span>
                <span className="text-[#18181D] font-medium">
                  {gemstone.variety || gemstone.name}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#8C867D]">Weight:</span>
                <span className="text-[#18181D] font-medium">
                  {activeVariant.weight.toFixed(2)} carat
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#8C867D]">Clarity:</span>
                <span className="text-[#18181D] font-medium">{gemstone.clarity}</span>
              </div>
              {(() => {
                const hasDims = Boolean(
                  gemstone.dimensions &&
                  (Number(gemstone.dimensions.length || 0) > 0 ||
                   Number(gemstone.dimensions.width || 0) > 0 ||
                   Number(gemstone.dimensions.depth || 0) > 0)
                );
                const dimsText = hasDims
                  ? `${gemstone.dimensions!.length} × ${gemstone.dimensions!.width}${gemstone.dimensions!.depth ? ` × ${gemstone.dimensions!.depth}` : ""} mm`
                  : "";
                const sizeText = activeVariant?.size?.trim() || dimsText || "";
                if (!sizeText) return null;
                return (
                  <div className="flex items-center justify-between">
                    <span className="text-[#8C867D]">Size:</span>
                    <span className="text-[#18181D] font-medium">{sizeText}</span>
                  </div>
                );
              })()}
              <div className="flex items-center justify-between">
                <span className="text-[#8C867D]">Colour:</span>
                <span className="text-[#18181D] font-medium">{gemstone.color}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#8C867D]">Shape & Cut:</span>
                <span className="text-[#18181D] font-medium">
                  {gemstone.cutDetail || gemstone.cut}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#8C867D]">Treatment:</span>
                <span className="text-[#18181D] font-medium">
                  {gemstone.treatment || (gemstone.isUnheated ? "Unheated" : "Treated")}
                </span>
              </div>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="mt-6 space-y-3">
            <div className="flex gap-3">
              <button
                onClick={handleAddToCart}
                disabled={isOutOfStock}
                className="flex-1 py-3.5 bg-[#18181D] hover:bg-[#2A2A32] disabled:bg-[#444] disabled:opacity-60 text-white text-xs uppercase tracking-widest font-sans flex items-center justify-center gap-2 transition-all shadow-md active:scale-[0.99] btn-luxury-press"
              >
                <BagIcon className="w-4 h-4 text-[#C5A880]" />
                <span>
                  {isOutOfStock
                    ? "Out of Stock"
                    : addedAnimation
                    ? "Added to Bag"
                    : `Add to Bag (${quantity} ${quantity === 1 ? "Piece" : "Pieces"})`}
                </span>
              </button>

              <button
                onClick={() => toggleWishlist(gemstone.id)}
                aria-label="Save to Vault"
                className={`w-12 h-12 border flex items-center justify-center transition-colors btn-luxury-press ${
                  isFavorited
                    ? "border-[#18181D] bg-[#18181D] text-[#C5A880]"
                    : "border-[#E8E4DC] hover:border-[#18181D] text-[#18181D]"
                }`}
              >
                <HeartIcon className="w-5 h-5" filled={isFavorited} />
              </button>
            </div>

            <Link
              href={`/gemstones/${gemstone.id}`}
              onClick={onClose}
              className="block w-full py-2.5 text-center border border-[#C5A880] text-[#9A7B4F] hover:bg-[#FAF8F5] text-xs uppercase tracking-widest font-sans transition-colors"
            >
              Open Full Gemological Dossier &rarr;
            </Link>

            {/* Micro assurance */}
            <div className="pt-2 flex items-center justify-center gap-4 text-[11px] text-[#8C867D] font-sans">
              <span className="flex items-center gap-1">
                <ArmoredTruckIcon className="w-3.5 h-3.5 text-[#C5A880]" />
                Armored Courier
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <SecurityLockIcon className="w-3.5 h-3.5 text-[#C5A880]" />
                30-Day Guarantee
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
