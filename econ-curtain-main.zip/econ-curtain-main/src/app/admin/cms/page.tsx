import Link from "next/link";
import {
  Sparkles,
  LayoutTemplate,
  MessageSquare,
  ArrowRight,
  Globe,
  ExternalLink,
  Zap,
  CheckCircle2,
  Layers,
  BookOpen,
} from "lucide-react";

export const dynamic = "force-dynamic";

export default function AdminCMSHubPage() {
  const cmsPages = [
    {
      id: "homepage",
      title: "Home Page CMS",
      slug: "/",
      editorHref: "/admin/homepage",
      icon: LayoutTemplate,
      accentColor: "amber",
      badgeColor: "bg-amber-400/10 text-amber-400 border-amber-400/30",
      btnBg: "bg-linear-to-r from-primary via-amber-500 to-yellow-500 text-slate-950",
      description:
        "Manage the cinematic hero slideshow headlines, glowing highlights, brand philosophy statement, featured project card, 3 live counters, and consultation CTA banner.",
      sections: [
        "🌟 Hero Banner & Status Badges",
        "📜 Editorial Philosophy Quote",
        "🏢 About ShadeIt Preview",
        "📊 3 Live Animated Counters",
        "📞 High-Conversion CTA Banner",
      ],
      fieldsCount: "36 Editable Fields",
    },
    {
      id: "about",
      title: "About Us Page CMS",
      slug: "/about",
      editorHref: "/admin/about",
      icon: BookOpen,
      accentColor: "purple",
      badgeColor: "bg-purple-400/10 text-purple-400 border-purple-400/30",
      btnBg: "bg-linear-to-r from-purple-500 via-indigo-500 to-amber-500 text-white",
      description:
        "Customize brand narrative, heritage story, 10+ Yrs & 500+ verified milestone counters, corporate mission & vision statements, and 5-point quality checklist.",
      sections: [
        "🧭 Hero Banner & Subtitle",
        "✨ 'More Than Blinds' Statement",
        "📖 Our Story Narrative & Image",
        "🎯 Mission & Vision Cards",
        "⭐ 5 Why ShadeIt Checkpoints",
      ],
      fieldsCount: "30 Editable Fields",
    },
    {
      id: "contact",
      title: "Contact Page CMS",
      slug: "/contact",
      editorHref: "/admin/contact",
      icon: MessageSquare,
      accentColor: "emerald",
      badgeColor: "bg-emerald-400/10 text-emerald-400 border-emerald-400/30",
      btnBg: "bg-linear-to-r from-emerald-500 via-teal-500 to-amber-500 text-slate-950 font-bold",
      description:
        "Update direct phone numbers, email support, click-to-chat WhatsApp number, showroom address lines, weekday/weekend working hours, and inquiry form card titles.",
      sections: [
        "📞 Hotline & Phone Subtitle",
        "✉️ Email Address & Support Notice",
        "💬 WhatsApp Direct Chat",
        "📍 Showroom Location & Postal",
        "⏰ Operating Working Hours",
      ],
      fieldsCount: "15 Editable Fields",
    },
  ];

  return (
    <div className="space-y-8 w-full pb-20">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-black p-6 sm:p-8 rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-none bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 text-amber-700 dark:text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
            <Sparkles size={14} /> Unified Page CMS Manager
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white tracking-tight">
            Website Content Manager
          </h1>
          <p className="text-neutral-500 dark:text-neutral-400 text-xs sm:text-sm mt-1">
            Choose a public page below to customize its headlines, descriptions, contact channels, and images in real-time.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/"
            target="_blank"
            className="inline-flex items-center gap-2 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-900 dark:hover:bg-neutral-850 text-neutral-800 dark:text-neutral-200 font-bold px-4 py-2.5 rounded-none text-xs border border-[#E5E5E0] dark:border-neutral-800 transition-all active:scale-95"
          >
            <Globe size={14} className="text-amber-500" />
            <span>Open Live Website</span>
            <ExternalLink size={13} className="text-neutral-400 dark:text-neutral-400" />
          </Link>
        </div>
      </div>

      {/* Metrics Summary Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
        <div className="p-6 rounded-none bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-none bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 flex items-center justify-center text-amber-700 dark:text-amber-400">
            <Layers size={24} />
          </div>
          <div>
            <p className="text-xs uppercase tracking-wider text-neutral-400 dark:text-neutral-500 font-bold">Managed CMS Pages</p>
            <h3 className="text-2xl font-black text-neutral-900 dark:text-white">3 Pages Active</h3>
          </div>
        </div>

        <div className="p-6 rounded-none bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-none bg-emerald-50 dark:bg-emerald-400/10 border border-emerald-200 dark:border-emerald-400/30 flex items-center justify-center text-emerald-700 dark:text-emerald-400">
            <CheckCircle2 size={24} />
          </div>
          <div>
            <p className="text-xs uppercase tracking-wider text-neutral-400 dark:text-neutral-500 font-bold">Live DB Sync</p>
            <h3 className="text-2xl font-black text-neutral-900 dark:text-white">SQLite Live</h3>
          </div>
        </div>

        <div className="p-6 rounded-none bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-none bg-purple-50 dark:bg-purple-400/10 border border-purple-200 dark:border-purple-400/30 flex items-center justify-center text-purple-700 dark:text-purple-400">
            <Zap size={24} />
          </div>
          <div>
            <p className="text-xs uppercase tracking-wider text-neutral-400 dark:text-neutral-500 font-bold">Instant Latency</p>
            <h3 className="text-2xl font-black text-neutral-900 dark:text-white">0ms Hydration-Free</h3>
          </div>
        </div>
      </div>

      {/* Main CMS Pages Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
        {cmsPages.map((page) => {
          const Icon = page.icon;
          return (
            <div
              key={page.id}
              className="bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none p-6 sm:p-7 shadow-xs hover:shadow-md flex flex-col justify-between hover:border-amber-400/50 dark:hover:border-amber-400/50 transition-all duration-300 group hover:-translate-y-1"
            >
              <div className="space-y-5">
                {/* Card Top: Icon & Live Link */}
                <div className="flex items-center justify-between">
                  <div className="w-14 h-14 rounded-none bg-neutral-100 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 flex items-center justify-center text-amber-600 dark:text-amber-400 group-hover:scale-105 transition-transform">
                    <Icon size={26} />
                  </div>

                  <Link
                    href={page.slug}
                    target="_blank"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-none bg-neutral-50 hover:bg-neutral-100 dark:bg-neutral-950 dark:hover:bg-neutral-900 text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white border border-[#E5E5E0] dark:border-neutral-800 text-xs font-semibold transition-all"
                  >
                    <span>{page.slug}</span>
                    <ExternalLink size={12} />
                  </Link>
                </div>

                {/* Title & Description */}
                <div>
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-none bg-amber-50 dark:bg-amber-400/10 text-amber-800 dark:text-amber-400 border border-amber-200 dark:border-amber-400/30">
                      {page.fieldsCount}
                    </span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-extrabold text-neutral-900 dark:text-white group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors">
                    {page.title}
                  </h2>
                  <p className="text-neutral-500 dark:text-neutral-400 text-xs sm:text-sm mt-2 leading-relaxed font-light line-clamp-3">
                    {page.description}
                  </p>
                </div>

                {/* Editable Sections List */}
                <div className="pt-2 space-y-2 border-t border-neutral-100 dark:border-neutral-800">
                  <p className="text-[11px] font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">
                    Included Sections
                  </p>
                  <div className="space-y-1.5">
                    {page.sections.map((sec, i) => (
                      <div
                        key={i}
                        className="text-xs text-neutral-700 dark:text-neutral-300 bg-neutral-50 dark:bg-neutral-950/70 border border-neutral-200/80 dark:border-neutral-800/80 px-3 py-1.5 rounded-none flex items-center gap-2"
                      >
                        <span className="w-1.5 h-1.5 rounded-none bg-amber-500 shrink-0" />
                        <span className="truncate">{sec}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-6 mt-6 border-t border-neutral-100 dark:border-neutral-800">
                <Link
                  href={page.editorHref}
                  className="w-full flex items-center justify-center gap-2 px-5 py-3 rounded-none font-bold text-xs sm:text-sm transition-all shadow-xs hover:brightness-110 active:scale-95 cursor-pointer bg-amber-500 text-slate-950"
                >
                  <span>Edit {page.title}</span>
                  <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
