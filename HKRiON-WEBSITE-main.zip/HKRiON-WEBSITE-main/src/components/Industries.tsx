'use client';

import { 
  ShoppingBag, 
  UtensilsCrossed, 
  ShoppingCart, 
  Stethoscope, 
  Factory, 
  HardHat, 
  GraduationCap, 
  Truck, 
  Hotel, 
  Landmark 
} from 'lucide-react';

const industries = [
  { name: 'Retail', icon: ShoppingBag, desc: 'POS billing, multi-store inventory & customer loyalty.' },
  { name: 'Restaurant', icon: UtensilsCrossed, desc: 'Kitchen Display Systems (KDS), table billing & order tracking.' },
  { name: 'Supermarket', icon: ShoppingCart, desc: 'High-speed barcode checkout, stock alerts & weighing scale integration.' },
  { name: 'Healthcare', icon: Stethoscope, desc: 'Patient records (EMR), appointment scheduling & pharmacy management.' },
  { name: 'Manufacturing', icon: Factory, desc: 'BOM tracking, raw material inventory & production workflow.' },
  { name: 'Construction', icon: HardHat, desc: 'Project cost tracking, site material supply & labor attendance.' },
  { name: 'Education', icon: GraduationCap, desc: 'Student admissions, fee management & online exam portals.' },
  { name: 'Logistics', icon: Truck, desc: 'Fleet tracking, shipment dispatches & warehouse telemetry.' },
  { name: 'Hotels', icon: Hotel, desc: 'Room reservation, housekeeping & guest billing integration.' },
  { name: 'Finance', icon: Landmark, desc: 'Microfinance software, loan management & automated ledger.' },
];

export default function Industries() {
  return (
    <section id="industries" className="py-24 bg-black relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <h2 className="text-xs font-semibold uppercase tracking-widest text-[#1ABE56] font-mono">
            INDUSTRIES WE SERVE
          </h2>
          <p className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            Tailored Solutions for <span className="gradient-text">Every Sector</span>
          </p>
          <p className="text-neutral-400 text-base sm:text-lg">
            We deliver industry-specific software and IoT automation engineered to meet unique operational needs.
          </p>
        </div>

        {/* Industries Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {industries.map((ind, idx) => {
            const Icon = ind.icon;
            return (
              <div
                key={idx}
                className="glass-card p-5 rounded-2xl border border-[#1ABE56]/20 bg-black/80 hover:border-[#1ABE56] hover:bg-neutral-900 transition-all duration-300 group hover:-translate-y-1 text-center flex flex-col items-center justify-center"
              >
                <div className="w-12 h-12 rounded-xl bg-[#1ABE56]/10 border border-[#1ABE56]/30 flex items-center justify-center mb-3 group-hover:scale-110 group-hover:bg-[#1ABE56] transition-all">
                  <Icon className="w-6 h-6 text-[#1ABE56] group-hover:text-black transition-colors" />
                </div>
                <h3 className="text-base font-bold text-white mb-1 group-hover:text-[#1ABE56] transition-colors">
                  {ind.name}
                </h3>
                <p className="text-[11px] text-neutral-400 leading-tight">
                  {ind.desc}
                </p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
