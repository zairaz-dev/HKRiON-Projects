import { Controller, Get, Put, Post, Body, UseGuards } from '@nestjs/common';
import { SuperSettingsService } from './super-settings.service';
import { UpdateSuperSettingsDto } from './dto/update-super-settings.dto';
import { TestEmailDto } from './dto/test-email.dto';
import { TestSmsDto } from './dto/test-sms.dto';
import { TestAiDto } from './dto/test-ai.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';
import { Public } from '../../common/decorators/public.decorator';

@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('super/settings')
export class SuperSettingsController {
  constructor(private readonly superSettingsService: SuperSettingsService) {}

  @Public()
  @Get('public-info')
  async getPublicPlatformInfo() {
    return this.superSettingsService.getPublicPlatformInfo();
  }

  @Roles(Role.SUPER_ADMIN)
  @Get()
  async getSettings() {
    return this.superSettingsService.getSettings();
  }

  @Roles(Role.SUPER_ADMIN)
  @Put()
  async updateSettings(@Body() dto: UpdateSuperSettingsDto) {
    return this.superSettingsService.updateSettings(dto);
  }

  @Roles(Role.SUPER_ADMIN)
  @Post('test-email')
  async sendTestEmail(@Body() dto: TestEmailDto) {
    return this.superSettingsService.sendTestEmail(dto);
  }

  @Roles(Role.SUPER_ADMIN)
  @Post('test-sms')
  async sendTestSms(@Body() dto: TestSmsDto) {
    return this.superSettingsService.sendTestSms(dto);
  }

  @Roles(Role.SUPER_ADMIN)
  @Post('test-ai')
  async testAiConnection(@Body() dto: TestAiDto) {
    return this.superSettingsService.testAiConnection(dto);
  }

  @Roles(Role.SUPER_ADMIN)
  @Get('health')
  async getSystemHealth() {
    return this.superSettingsService.getSystemHealth();
  }
}
