import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import AppChrome from "@/components/layout/AppChrome";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import WhatsAppButton from "@/components/ui/WhatsAppButton";
import { ContactService } from "@/services/contact.service";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
});

export const viewport: Viewport = {
  themeColor: "#020617",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export const metadata: Metadata = {
  metadataBase: new URL("https://shadeitblinds.com"),
  title: {
    default: "SHADEIT BLINDS | Luxury Blinds, Curtains & Outdoor Shade Solutions",
    template: "%s | SHADEIT BLINDS",
  },
  description:
    "Leading manufacturer & installer of Monsoon Blinds, Zebra Blinds, Roller & Roman Blinds, Luxury Curtains, Pergolas, Awnings, Canopies, and Outdoor UV Clear PVC shades.",
  keywords: [
    "Monsoon Blinds",
    "Zebra Blinds",
    "Roller Blinds",
    "Roman Blinds",
    "Curtains",
    "Vertical Blinds",
    "Timber Venetian Blinds",
    "Awning",
    "Canopy",
    "Pergola",
    "Outdoor Teak Sunbed",
    "Outdoor Fabric",
    "Outdoor UV Clear PVC",
    "Window Blinds Chennai",
    "Custom Blinds Installation",
  ],
  authors: [{ name: "SHADEIT BLINDS" }],
  creator: "SHADEIT BLINDS",
  publisher: "SHADEIT BLINDS",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  icons: {
    icon: [
      { url: "/favicon.ico" },
    ],
    shortcut: ["/favicon.ico"],
    apple: ["/favicon.ico"],
  },
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://shadeitblinds.com",
    siteName: "SHADEIT BLINDS",
    title: "SHADEIT BLINDS | Luxury Blinds & Outdoor Solutions",
    description:
      "Transform your residential and commercial spaces with high-durability monsoon blinds, automated shades, and custom pergola solutions.",
    images: [
      {
        url: "/monsoon_blinds.jpg",
        width: 1200,
        height: 630,
        alt: "SHADEIT BLINDS Luxury Window & Outdoor Solutions",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "SHADEIT BLINDS | Luxury Blinds & Outdoor Solutions",
    description:
      "Transform your spaces with high-durability monsoon blinds, automated shades, and custom outdoor solutions.",
    images: ["/monsoon_blinds.jpg"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const contact = await ContactService.getContent();
  const rawWhatsapp = contact.whatsapp.replace(/[^0-9]/g, '');

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "HomeGoodsStore",
    name: "SHADEIT BLINDS",
    image: "https://shadeitblinds.com/monsoon_blinds.jpg",
    description:
      "Premium window blinds, monsoon blinds, pergolas, awnings, and outdoor shade systems.",
    url: "https://shadeitblinds.com",
    telephone: contact.phone || `+${rawWhatsapp}`,
    priceRange: "$$",
    address: {
      "@type": "PostalAddress",
      streetAddress: "No.188/29A, Brandiyawatha, Wellampitiya",
      addressLocality: "Colombo",
      addressRegion: "Western Province",
      addressCountry: "LK",
    },
    geo: {
      "@type": "GeoCoordinates",
      latitude: 13.0827,
      longitude: 80.2707,
    },
    openingHoursSpecification: [
      {
        "@type": "OpeningHoursSpecification",
        dayOfWeek: [
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
        ],
        opens: "09:00",
        closes: "20:00",
      },
    ],
  };

  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased scroll-smooth`}
      suppressHydrationWarning
    >
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </head>
      <body 
        className="min-h-full flex flex-col bg-slate-950 text-slate-100 overflow-x-hidden selection:bg-amber-500 selection:text-slate-950"
        suppressHydrationWarning
      >
        <AppChrome
          navbar={<Navbar whatsappNumber={contact.whatsapp} />}
          footer={<Footer />}
          whatsapp={<WhatsAppButton phoneNumber={contact.whatsapp} />}
        >
          {children}
        </AppChrome>
      </body>
    </html>
  );
}
