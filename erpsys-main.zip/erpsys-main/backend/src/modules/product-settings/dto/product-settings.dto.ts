export class UpdateProductSettingsDto {
  businessId?: string;
  defaultProfitMargin?: number;
  enableAutoSku?: boolean;
  skuPrefix?: string;
  defaultBarcodeType?: string;
  enableProductExpiry?: boolean;
  expiryAlertDays?: number;
  onProductExpiry?: string;
  stopSellingBeforeExpiryDays?: number;

  enableBrands?: boolean;
  enableCategories?: boolean;
  enableSubCategories?: boolean;
  enablePriceTax?: boolean;
  enableWarranty?: boolean;

  defaultUnitId?: string | null;
  defaultTaxId?: string | null;
}
