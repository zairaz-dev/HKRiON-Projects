import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import {
  SESSION_COOKIE_NAME,
  verifySessionTokenEdge,
  CUSTOMER_SESSION_COOKIE_NAME,
  verifyCustomerSessionTokenEdge,
} from "@/lib/auth-edge";

function isProtectedAdminRoute(pathname: string): boolean {
  const lower = pathname.toLowerCase();
  if (lower.startsWith("/admin")) return true;
  if (lower === "/orders" || lower === "/orders/") return true;

  const adminPrefixes = [
    "/admindashboard",
    "/inventory",
    "/clients",
    "/inquiries",
    "/cms",
    "/vault-security",
    "/vaultsecurity",
    "/security",
  ];

  return adminPrefixes.some((prefix) => lower === prefix || lower.startsWith(prefix + "/"));
}

/**
 * Validate that a redirect destination is a safe internal path.
 * Prevents open redirect attacks (e.g. //evil.com, /\evil.com).
 */
function getSafeRedirectDest(fromParam: string | null, fallback: string): string {
  if (!fromParam) return fallback;
  // Must start with a single "/" and not be a protocol-relative URL
  if (
    fromParam.startsWith("/") &&
    !fromParam.startsWith("//") &&
    !fromParam.startsWith("/\\") &&
    !fromParam.toLowerCase().includes("javascript:")
  ) {
    return fromParam;
  }
  return fallback;
}

export async function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const adminCookie = request.cookies.get(SESSION_COOKIE_NAME)?.value;
  const customerCookie = request.cookies.get(CUSTOMER_SESSION_COOKIE_NAME)?.value;

  const isAdminApiRoute = pathname.startsWith("/api/admin") && pathname !== "/api/admin/login";
  const isAdminRoute = isProtectedAdminRoute(pathname);
  const isAccountRoute = pathname === "/account" || pathname.startsWith("/account/");
  const isLoginRoute = pathname === "/login";

  // 0. Guarding Admin API Routes
  if (isAdminApiRoute) {
    if (!adminCookie) {
      return NextResponse.json(
        { error: "Unauthorized: Administrator session required" },
        { status: 401 }
      );
    }
    const verifiedAdmin = await verifySessionTokenEdge(adminCookie);
    if (!verifiedAdmin) {
      return NextResponse.json(
        { error: "Unauthorized: Invalid or expired administrator session" },
        { status: 401 }
      );
    }
    return NextResponse.next();
  }

  // 1. Guarding Administrative Routes
  if (isAdminRoute) {
    if (!adminCookie) {
      const loginUrl = new URL("/login", request.url);
      loginUrl.searchParams.set("from", pathname + request.nextUrl.search);
      return NextResponse.redirect(loginUrl);
    }

    const verifiedAdmin = await verifySessionTokenEdge(adminCookie);
    if (!verifiedAdmin) {
      const loginUrl = new URL("/login", request.url);
      loginUrl.searchParams.set("from", pathname + request.nextUrl.search);
      loginUrl.searchParams.set("reason", "expired");
      const response = NextResponse.redirect(loginUrl);
      response.cookies.delete(SESSION_COOKIE_NAME);
      return response;
    }

    return NextResponse.next();
  }

  // 2. Guarding Customer /account Route
  if (isAccountRoute) {
    let isAuthenticated = false;

    if (customerCookie) {
      const verifiedCust = await verifyCustomerSessionTokenEdge(customerCookie);
      if (verifiedCust) isAuthenticated = true;
    }

    if (!isAuthenticated && adminCookie) {
      const verifiedAdmin = await verifySessionTokenEdge(adminCookie);
      if (verifiedAdmin) isAuthenticated = true;
    }

    if (!isAuthenticated) {
      const loginUrl = new URL("/login", request.url);
      loginUrl.searchParams.set("from", pathname + request.nextUrl.search);
      return NextResponse.redirect(loginUrl);
    }

    return NextResponse.next();
  }

  // 3. Redirect already authenticated visitors visiting /login
  if (isLoginRoute) {
    const fromParam = request.nextUrl.searchParams.get("from");

    // If Admin is logged in, redirect to admin destination
    if (adminCookie) {
      const verifiedAdmin = await verifySessionTokenEdge(adminCookie);
      if (verifiedAdmin) {
        const dest = getSafeRedirectDest(fromParam, "/admindashboard");
        return NextResponse.redirect(new URL(dest, request.url));
      }
    }

    // If Customer is logged in, redirect to customer destination
    if (customerCookie) {
      const verifiedCust = await verifyCustomerSessionTokenEdge(customerCookie);
      if (verifiedCust) {
        const dest = getSafeRedirectDest(fromParam, "/account");
        return NextResponse.redirect(new URL(dest, request.url));
      }
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    "/api/admin/:path*",
    "/admin/:path*",
    "/admin",
    "/admindashboard",
    "/admindashboard/:path*",
    "/inventory",
    "/inventory/:path*",
    "/orders",
    "/clients",
    "/clients/:path*",
    "/inquiries",
    "/inquiries/:path*",
    "/cms",
    "/cms/:path*",
    "/vault-security",
    "/vault-security/:path*",
    "/security",
    "/security/:path*",
    "/account",
    "/account/:path*",
    "/login",
  ],
};
