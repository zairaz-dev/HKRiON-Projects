import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { verifyToken } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('hkrion_auth_token')?.value;

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await verifyToken(token);
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden. Admin access required.' }, { status: 403 });
    }

    const dbRoles = await prisma.role.findMany({
      orderBy: { createdAt: 'asc' },
      include: {
        permissions: {
          include: {
            permission: true,
          },
        },
        _count: {
          select: { users: true },
        },
      },
    });

    const roles = dbRoles.map((r) => ({
      id: r.id,
      name: r.name,
      description: r.description,
      isSystem: ['ADMIN', 'EMPLOYEE', 'CUSTOMER'].includes(r.name.toUpperCase()),
      userCount: r._count.users,
      permissions: r.permissions.map((rp) => rp.permission),
      createdAt: r.createdAt.toISOString(),
    }));

    return NextResponse.json({ success: true, roles });
  } catch (err) {
    console.error('Database Error fetching roles:', err);
    return NextResponse.json({ error: 'Failed to fetch roles from database' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('hkrion_auth_token')?.value;

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await verifyToken(token);
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden. Admin access required.' }, { status: 403 });
    }

    const { name, description, permissionIds } = await request.json();

    if (!name || typeof name !== 'string') {
      return NextResponse.json({ error: 'Role name is required' }, { status: 400 });
    }

    const formattedName = name.trim().toUpperCase().replace(/\s+/g, '_');

    // Check existing role
    const existing = await prisma.role.findUnique({
      where: { name: formattedName },
    });

    if (existing) {
      return NextResponse.json({ error: `Role '${formattedName}' already exists in database.` }, { status: 400 });
    }

    const newRole = await prisma.role.create({
      data: {
        name: formattedName,
        description: description || '',
        createdBy: user.id || 'admin',
        updatedBy: user.id || 'admin',
      },
    });

    // Attach permissions
    if (Array.isArray(permissionIds) && permissionIds.length > 0) {
      await prisma.rolePermission.createMany({
        data: permissionIds.map((pId: string) => ({
          roleId: newRole.id,
          permissionId: pId,
          createdBy: user.id || 'admin',
        })),
      });
    }

    return NextResponse.json({ success: true, role: newRole });
  } catch (err) {
    console.error('Database Error creating role:', err);
    return NextResponse.json({ error: 'Failed to create role in database' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('hkrion_auth_token')?.value;

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await verifyToken(token);
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden. Admin access required.' }, { status: 403 });
    }

    const { id, name, description, permissionIds } = await request.json();

    if (!id) {
      return NextResponse.json({ error: 'Role ID is required' }, { status: 400 });
    }

    const formattedName = name ? name.trim().toUpperCase().replace(/\s+/g, '_') : undefined;

    const updatedRole = await prisma.role.update({
      where: { id },
      data: {
        ...(formattedName ? { name: formattedName } : {}),
        ...(description !== undefined ? { description } : {}),
        updatedBy: user.id || 'admin',
      },
    });

    // Update permissions if provided
    if (Array.isArray(permissionIds)) {
      await prisma.rolePermission.deleteMany({
        where: { roleId: id },
      });

      if (permissionIds.length > 0) {
        await prisma.rolePermission.createMany({
          data: permissionIds.map((pId: string) => ({
            roleId: id,
            permissionId: pId,
            createdBy: user.id || 'admin',
          })),
        });
      }
    }

    return NextResponse.json({ success: true, role: updatedRole });
  } catch (err) {
    console.error('Database Error updating role:', err);
    return NextResponse.json({ error: 'Failed to update role in database' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('hkrion_auth_token')?.value;

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await verifyToken(token);
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden. Admin access required.' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Role ID parameter is required' }, { status: 400 });
    }

    const role = await prisma.role.findUnique({
      where: { id },
      include: { _count: { select: { users: true } } },
    });

    if (!role) {
      return NextResponse.json({ error: 'Role not found in database' }, { status: 404 });
    }

    if (['ADMIN', 'EMPLOYEE', 'CUSTOMER'].includes(role.name.toUpperCase())) {
      return NextResponse.json({ error: 'Cannot delete core system role' }, { status: 400 });
    }

    if (role._count.users > 0) {
      return NextResponse.json({ error: `Cannot delete role with ${role._count.users} active assigned users` }, { status: 400 });
    }

    await prisma.role.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: 'Role deleted successfully from database' });
  } catch (err) {
    console.error('Database Error deleting role:', err);
    return NextResponse.json({ error: 'Failed to delete role from database' }, { status: 500 });
  }
}
