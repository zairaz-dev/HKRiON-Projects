export interface BranchItem {
  id: string;
  name: string;
}

export interface ExpenseCategoryItem {
  id: string;
  name: string;
}

export interface ExpensePaymentItem {
  id: string;
  amount: number;
  paymentDate: string;
  paymentMethod: {
    id: string;
    name: string;
  };
  notes: string | null;
}

export interface ExpenseItem {
  id: string;
  refNo: string | null;
  amount: number;
  expenseDate: string;
  paymentStatus: 'PAID' | 'DUE' | 'PARTIAL';
  amountPaid: number;
  notes: string | null;
  attachmentUrl: string | null;
  categoryId: string;
  category: ExpenseCategoryItem;
  branchId: string;
  branch: BranchItem;
  businessId: string;
  createdAt: string;
  updatedAt: string;
  payments?: ExpensePaymentItem[];
}
