"use strict";

import * as React from "react";
import { useState, useMemo } from "react";
import { createPortal } from "react-dom";
import { cn } from "@/lib/utils";
import { 
  Search, 
  Filter, 
  Printer, 
  FileSpreadsheet, 
  FileText, 
  FileDown, 
  ChevronLeft, 
  ChevronRight,
  MoreVertical,
  ArrowUp,
  ArrowDown,
  ChevronsUpDown
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";

// ==========================================================================
// Low-level Table Components (Theme-aware with column dividers)
// ==========================================================================

const Table = React.forwardRef<
  HTMLTableElement,
  React.HTMLAttributes<HTMLTableElement>
>(({ className, ...props }, ref) => (
  <div className="relative w-full overflow-auto rounded-sm">
    <table
      ref={ref}
      className={cn("w-full caption-bottom text-sm border-collapse", className)}
      {...props}
    />
  </div>
));
Table.displayName = "Table";

const TableHeader = React.forwardRef<
  HTMLTableSectionElement,
  React.HTMLAttributes<HTMLTableSectionElement>
>(({ className, ...props }, ref) => (
  <thead 
    ref={ref} 
    className={cn(
      "border-b border-border bg-secondary/80 dark:bg-[#15161c] backdrop-blur-md [&_tr]:border-b [&_tr]:border-border/80 [&_tr]:hover:bg-transparent", 
      className
    )} 
    {...props} 
  />
));
TableHeader.displayName = "TableHeader";

const TableBody = React.forwardRef<
  HTMLTableSectionElement,
  React.HTMLAttributes<HTMLTableSectionElement>
>(({ className, ...props }, ref) => (
  <tbody
    ref={ref}
    className={cn("divide-y divide-border", className)}
    {...props}
  />
));
TableBody.displayName = "TableBody";

const TableFooter = React.forwardRef<
  HTMLTableSectionElement,
  React.HTMLAttributes<HTMLTableSectionElement>
>(({ className, ...props }, ref) => (
  <tfoot
    ref={ref}
    className={cn(
      "border-t border-border bg-muted/50 font-medium [&>tr]:last:border-b-0",
      className
    )}
    {...props}
  />
));
TableFooter.displayName = "TableFooter";

const TableRow = React.forwardRef<
  HTMLTableRowElement,
  React.HTMLAttributes<HTMLTableRowElement>
>(({ className, ...props }, ref) => (
  <tr
    ref={ref}
    className={cn(
      "border-b border-border transition-colors hover:bg-muted/40 data-[state=selected]:bg-muted",
      className
    )}
    {...props}
  />
));
TableRow.displayName = "TableRow";

const TableHead = React.forwardRef<
  HTMLTableCellElement,
  React.ThHTMLAttributes<HTMLTableCellElement>
>(({ className, ...props }, ref) => (
  <th
    ref={ref}
    className={cn(
      "h-9 px-3 text-left align-middle font-sans text-[11px] font-semibold uppercase tracking-wider text-muted-foreground border-r border-border/30 last:border-r-0 select-none transition-colors [&:has([role=checkbox])]:pr-0",
      className
    )}
    {...props}
  />
));
TableHead.displayName = "TableHead";

const TableCell = React.forwardRef<
  HTMLTableCellElement,
  React.TdHTMLAttributes<HTMLTableCellElement>
>(({ className, ...props }, ref) => (
  <td
    ref={ref}
    className={cn(
      "py-2.5 px-3 align-middle text-[11px] text-foreground/90 border-r border-border last:border-r-0 [&:has([role=checkbox])]:pr-0",
      className
    )}
    {...props}
  />
));
TableCell.displayName = "TableCell";

const TableCaption = React.forwardRef<
  HTMLTableCaptionElement,
  React.HTMLAttributes<HTMLTableCaptionElement>
>(({ className, ...props }, ref) => (
  <caption
    ref={ref}
    className={cn("mt-4 text-xs text-muted-foreground/60", className)}
    {...props}
  />
));
TableCaption.displayName = "TableCaption";


// ==========================================================================
// Reusable High-Level DataTable Component
// ==========================================================================

export interface ColumnDef<T> {
  header: string;
  accessorKey?: keyof T;
  render?: (row: T) => React.ReactNode;
  searchable?: boolean;
  sortable?: boolean;
  sortKey?: keyof T | string;
  align?: "left" | "center" | "right";
  className?: string;
  headerClassName?: string;
}

interface DataTableProps<T> {
  data: T[];
  columns: ColumnDef<T>[];
  searchPlaceholder?: string;
  searchKeys?: (keyof T)[];
  filterKey?: keyof T;
  filterOptions?: { label: string; value: string }[];
  filterPlaceholder?: string;
  actionButton?: {
    label: string;
    onClick: () => void;
    icon?: React.ReactNode;
  };
  pageSize?: number;
  reportTitle?: string;
  customFilters?: React.ReactNode;
  extraFilters?: React.ReactNode;

  // Server-side pagination support
  serverSide?: boolean;
  totalItems?: number;
  totalPages?: number;
  currentPage?: number;
  onPageChange?: (page: number) => void;
  searchQuery?: string;
  onSearchQueryChange?: (search: string) => void;
  isLoading?: boolean;
  onPageSizeChange?: (size: number) => void;
}

export function DataTable<T extends Record<string, any>>({
  data,
  columns,
  searchPlaceholder = "Search...",
  searchKeys = [],
  filterKey,
  filterOptions = [],
  filterPlaceholder = "All",
  actionButton,
  pageSize = 10,
  reportTitle = "ERP System Report",
  customFilters,
  extraFilters,
  // Server-side props
  serverSide = false,
  totalItems,
  totalPages: propTotalPages,
  currentPage: propCurrentPage,
  onPageChange,
  searchQuery: propSearchQuery,
  onSearchQueryChange,
  isLoading = false,
  onPageSizeChange,
}: DataTableProps<T>) {
  const [localSearchQuery, setLocalSearchQuery] = useState("");
  const [filterValue, setFilterValue] = useState("all");
  const [localCurrentPage, setLocalCurrentPage] = useState(1);
  const [localPageSizeState, setLocalPageSizeState] = useState(pageSize);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [sortKey, setSortKey] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<"asc" | "desc" | null>(null);

  const handleSort = (key?: string) => {
    if (!key) return;
    if (sortKey === key) {
      if (sortDirection === "asc") {
        setSortDirection("desc");
      } else if (sortDirection === "desc") {
        setSortDirection(null);
        setSortKey(null);
      }
    } else {
      setSortKey(key);
      setSortDirection("asc");
    }
  };

  const pageSizeState = serverSide ? (pageSize ?? 10) : localPageSizeState;
  const setPageSizeState = (val: number) => {
    if (serverSide) {
      onPageSizeChange?.(val);
    } else {
      setLocalPageSizeState(val);
    }
  };

  const searchQuery = serverSide ? (propSearchQuery ?? "") : localSearchQuery;
  const setSearchQuery = (val: string) => {
    if (serverSide) {
      onSearchQueryChange?.(val);
    } else {
      setLocalSearchQuery(val);
    }
  };

  const currentPage = serverSide ? (propCurrentPage ?? 1) : localCurrentPage;
  const setCurrentPage = (val: number | ((prev: number) => number)) => {
    if (serverSide) {
      const nextPage = typeof val === "function" ? val(currentPage) : val;
      onPageChange?.(nextPage);
    } else {
      setLocalCurrentPage(val);
    }
  };

  // Reset pagination on search/filter change
  React.useEffect(() => {
    if (serverSide) return;
    setCurrentPage(1);
  }, [searchQuery, filterValue, pageSizeState, serverSide]);

  // 1. Filter and Search Data
  const filteredData = useMemo(() => {
    if (serverSide) return data;
    return data.filter((item) => {
      // Search logic
      const matchesSearch = searchQuery === "" || searchKeys.some((key) => {
        const val = item[key];
        return val ? String(val).toLowerCase().includes(searchQuery.toLowerCase()) : false;
      });

      // Filter logic
      const matchesFilter = !filterKey || filterValue === "all" || String(item[filterKey]) === filterValue;

      return matchesSearch && matchesFilter;
    });
  }, [data, searchQuery, filterValue, searchKeys, filterKey, serverSide]);

  // 1.5 Sort Data
  const sortedData = useMemo(() => {
    if (serverSide || !sortKey || !sortDirection) return filteredData;
    return [...filteredData].sort((a, b) => {
      const valA = a[sortKey];
      const valB = b[sortKey];
      if (valA == null && valB == null) return 0;
      if (valA == null) return 1;
      if (valB == null) return -1;
      if (typeof valA === "number" && typeof valB === "number") {
        return sortDirection === "asc" ? valA - valB : valB - valA;
      }
      return sortDirection === "asc"
        ? String(valA).localeCompare(String(valB), undefined, { numeric: true, sensitivity: "base" })
        : String(valB).localeCompare(String(valA), undefined, { numeric: true, sensitivity: "base" });
    });
  }, [filteredData, sortKey, sortDirection, serverSide]);

  // 2. Paginate Data
  const totalPages = serverSide ? (propTotalPages ?? 1) : (Math.ceil(sortedData.length / pageSizeState) || 1);
  const paginatedData = useMemo(() => {
    if (serverSide) return data;
    const start = (currentPage - 1) * pageSizeState;
    return sortedData.slice(start, start + pageSizeState);
  }, [sortedData, currentPage, pageSizeState, serverSide, data]);

  const totalEntries = serverSide ? (totalItems ?? data.length) : sortedData.length;

  const getPageNumbers = () => {
    const pages: (number | string)[] = [];
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
    } else {
      pages.push(1);
      const start = Math.max(2, currentPage - 1);
      const end = Math.min(totalPages - 1, currentPage + 1);

      if (start > 2) {
        pages.push("...");
      }

      for (let i = start; i <= end; i++) {
        pages.push(i);
      }

      if (end < totalPages - 1) {
        pages.push("...");
      }

      pages.push(totalPages);
    }
    return pages;
  };

  // 3. Export Functions
  const exportCSV = () => {
    const headers = columns.map(col => col.header).join(",");
    const rows = sortedData.map(row => 
      columns.map(col => {
        let val = "";
        if (col.accessorKey) {
          val = String(row[col.accessorKey] || "");
        }
        return `"${val.replace(/"/g, '""')}"`;
      }).join(",")
    );
    const csvContent = [headers, ...rows].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `${reportTitle.toLowerCase().replace(/\s+/g, "-")}-${Date.now()}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportExcel = () => {
    const tableHtml = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head><meta charset="utf-8" /></head>
      <body>
        <h2>${reportTitle}</h2>
        <p>Exported on: ${new Date().toLocaleString()}</p>
        <table border="1">
          <thead>
            <tr style="background-color: #f2f2f2; font-weight: bold;">
              ${columns.map(col => `<th>${col.header}</th>`).join("")}
            </tr>
          </thead>
          <tbody>
            ${sortedData.map(row => `
              <tr>
                ${columns.map(col => {
                  const val = col.accessorKey ? String(row[col.accessorKey] || "") : "";
                  return `<td>${val}</td>`;
                }).join("")}
              </tr>
            `).join("")}
          </tbody>
        </table>
      </body>
      </html>
    `;
    const blob = new Blob([tableHtml], { type: "application/vnd.ms-excel" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `${reportTitle.toLowerCase().replace(/\s+/g, "-")}-${Date.now()}.xls`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) return;
    
    const tableHeaders = columns.map(col => `<th>${col.header}</th>`).join("");
    const tableRows = sortedData.map(row => `
      <tr>
        ${columns.map(col => {
          const val = col.accessorKey ? String(row[col.accessorKey] || "") : "";
          return `<td>${val}</td>`;
        }).join("")}
      </tr>
    `).join("");

    printWindow.document.write(`
      <html>
        <head>
          <title>${reportTitle}</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; padding: 20px; color: #333; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 10px; text-align: left; font-size: 12px; }
            th { background-color: #f5f5f5; font-weight: bold; }
            h1 { font-size: 20px; margin-bottom: 5px; }
            p { font-size: 12px; color: #666; margin-top: 0; }
          </style>
        </head>
        <body>
          <h1>${reportTitle}</h1>
          <p>Generated on ${new Date().toLocaleString()}</p>
          <table>
            <thead><tr>${tableHeaders}</tr></thead>
            <tbody>${tableRows}</tbody>
          </table>
          <script>
            window.onload = function() {
              window.print();
              setTimeout(function() { window.close(); }, 500);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className="space-y-4 w-full">
      
      {/* 1. Header Control Bar (Search, Filter, Exports, Action Button) */}
      <div className="flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between bg-card border border-border p-3.5 rounded-sm">
        
        {/* Left Side: Search & Filter */}
        <div className="flex items-center gap-2.5 flex-1 min-w-0">
          {(searchKeys.length > 0 || serverSide) && (
            <div className="relative flex-1 max-w-xs w-full">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder={searchPlaceholder}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 text-xs h-9 rounded-sm w-full bg-background/50"
              />
            </div>
          )}
          
          {filterKey && filterOptions.length > 0 && (
            <div className="relative w-36 shrink-0">
              <Filter className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground pointer-events-none z-10" />
              <Select
                value={filterValue}
                onValueChange={setFilterValue}
                className="pl-9 text-xs h-9 w-full"
              >
                <option value="all">{filterPlaceholder}</option>
                {filterOptions.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </Select>
            </div>
          )}

          {extraFilters}

          {customFilters && (
            <div className="relative inline-block text-left shrink-0">
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => setIsFilterOpen(!isFilterOpen)}
                className={cn(
                  "h-9 w-9 rounded-sm border border-input bg-background/50 hover:bg-accent text-muted-foreground hover:text-foreground transition-all duration-200",
                  isFilterOpen && "bg-primary/10 border-primary/30 text-primary hover:bg-primary/15"
                )}
                title="Filters"
              >
                <Filter className="h-4 w-4" />
              </Button>

              {isFilterOpen && (
                <>
                  {/* Backdrop overlay for closing on click-outside */}
                  <div
                    className="fixed inset-0 z-30"
                    onClick={() => setIsFilterOpen(false)}
                  />
                  {/* Popover content card */}
                  <div className="absolute left-0 mt-2 z-40 min-w-[260px] rounded-md border border-border bg-card p-4 shadow-xl backdrop-blur-md animate-in fade-in slide-in-from-top-2 duration-150 space-y-4">
                    <div className="flex items-center justify-between border-b border-border/50 pb-2">
                      <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Filters</span>
                      <button
                        type="button"
                        onClick={() => setIsFilterOpen(false)}
                        className="text-[10px] text-muted-foreground hover:text-foreground underline font-mono"
                      >
                        Close
                      </button>
                    </div>
                    <div className="flex flex-col gap-3">
                      {customFilters}
                    </div>
                  </div>
                </>
              )}
            </div>
          )}
        </div>

        {/* Right Side: Export Buttons & Main Action Button */}
        <div className="flex flex-wrap items-center gap-2 justify-start md:justify-end">
          
          {/* Export Group */}
          <div className="flex items-center border border-border rounded-sm bg-card/35 p-0.5 h-9 gap-0.5 overflow-x-auto max-w-full">
            <button
              type="button"
              onClick={handlePrint}
              title="Print Table"
              className="h-7 px-2.5 flex items-center gap-1.5 text-sky-600 dark:text-sky-400 hover:text-sky-700 dark:hover:text-sky-300 hover:bg-sky-500/10 dark:hover:bg-sky-500/15 rounded-sm transition-all text-[11px] sm:text-xs font-medium shrink-0 group"
            >
              <Printer className="w-3.5 h-3.5 shrink-0 group-hover:scale-110 transition-transform" />
              <span>Print</span>
            </button>
            <div className="w-[1px] h-3.5 bg-border/60 shrink-0" />
            <button
              type="button"
              onClick={exportExcel}
              title="Export to Excel"
              className="h-7 px-2.5 flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300 hover:bg-emerald-500/10 dark:hover:bg-emerald-500/15 rounded-sm transition-all text-[11px] sm:text-xs font-medium shrink-0 group"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 shrink-0 group-hover:scale-110 transition-transform" />
              <span>Excel</span>
            </button>
            <div className="w-[1px] h-3.5 bg-border/60 shrink-0" />
            <button
              type="button"
              onClick={handlePrint} // Native PDF via print
              title="Save as PDF"
              className="h-7 px-2.5 flex items-center gap-1.5 text-rose-600 dark:text-rose-400 hover:text-rose-700 dark:hover:text-rose-300 hover:bg-rose-500/10 dark:hover:bg-rose-500/15 rounded-sm transition-all text-[11px] sm:text-xs font-medium shrink-0 group"
            >
              <FileText className="w-3.5 h-3.5 shrink-0 group-hover:scale-110 transition-transform" />
              <span>PDF</span>
            </button>
            <div className="w-[1px] h-3.5 bg-border/60 shrink-0" />
            <button
              type="button"
              onClick={exportCSV}
              title="Export to CSV"
              className="h-7 px-2.5 flex items-center gap-1.5 text-amber-600 dark:text-amber-400 hover:text-amber-700 dark:hover:text-amber-300 hover:bg-amber-500/10 dark:hover:bg-amber-500/15 rounded-sm transition-all text-[11px] sm:text-xs font-medium shrink-0 group"
            >
              <FileDown className="w-3.5 h-3.5 shrink-0 group-hover:scale-110 transition-transform" />
              <span>CSV</span>
            </button>
          </div>

          {/* Action Button */}
          {actionButton && (
            <Button
              onClick={actionButton.onClick}
              className="text-xs gap-1.5 h-9 rounded-sm shadow-lg shadow-primary/15 whitespace-nowrap"
            >
              {actionButton.icon}
              {actionButton.label}
            </Button>
          )}
        </div>
      </div>

      {/* 2. Table Render */}
      <div className="relative rounded-sm border border-border/80 overflow-hidden bg-card shadow-xs">
        {/* Top subtle brand accent line */}
        <div className="h-[2px] w-full bg-gradient-to-r from-transparent via-primary/50 to-transparent" />

        {/* Shimmer loading bar */}
        {isLoading && (
          <>
            <style>{`
              @keyframes loadingBar {
                0% { left: -40%; width: 40%; }
                50% { width: 60%; }
                100% { left: 100%; width: 100%; }
              }
            `}</style>
            <div className="absolute top-0 left-0 right-0 h-[3px] bg-primary/10 overflow-hidden z-20">
              <div 
                className="absolute h-full bg-primary" 
                style={{
                  animation: "loadingBar 1.2s infinite ease-in-out"
                }} 
              />
            </div>
          </>
        )}

        <div className={cn("w-full transition-all duration-200", isLoading && "opacity-60 pointer-events-none filter blur-[0.5px]")}>
          <Table className="border-none">
            <TableHeader className="bg-secondary/70 dark:bg-[#15161c] border-b border-border shadow-xs">
              <TableRow className="hover:bg-transparent border-b border-border/80">
                {columns.map((col, idx) => {
                  const sortField = (col.sortKey || col.accessorKey) as string | undefined;
                  const isSortable = col.sortable !== false && !!sortField;
                  const isSorted = isSortable && sortKey === sortField;

                  return (
                    <TableHead 
                      key={idx} 
                      onClick={() => isSortable && handleSort(sortField)}
                      className={cn(
                        "h-9 px-3 text-[11px] font-semibold tracking-wider uppercase transition-all duration-150 select-none text-muted-foreground",
                        idx === 0 && "pl-4", 
                        col.align === "right" || (!col.align && idx === columns.length - 1) ? "text-right pr-4" : col.align === "center" ? "text-center" : "text-left",
                        col.headerClassName,
                        isSortable && "cursor-pointer group hover:bg-accent hover:text-foreground",
                        isSorted && "text-primary dark:text-primary bg-primary/[0.04]"
                      )}
                    >
                      <div className={cn(
                        "flex items-center gap-2",
                        (col.align === "right" || (!col.align && idx === columns.length - 1)) ? "justify-end" : col.align === "center" ? "justify-center" : "justify-start"
                      )}>
                        <span className={cn(
                          "transition-colors",
                          isSorted ? "text-primary font-bold" : "text-muted-foreground group-hover:text-foreground font-semibold"
                        )}>
                          {col.header}
                        </span>
                        {isSortable && (
                          <span className="shrink-0 transition-opacity">
                            {isSorted ? (
                              sortDirection === "asc" ? (
                                <ArrowUp className="w-3.5 h-3.5 text-primary animate-in fade-in zoom-in-75" />
                              ) : (
                                <ArrowDown className="w-3.5 h-3.5 text-primary animate-in fade-in zoom-in-75" />
                              )
                            ) : (
                              <ChevronsUpDown className="w-3.5 h-3.5 opacity-40 group-hover:opacity-80 text-muted-foreground transition-opacity" />
                            )}
                          </span>
                        )}
                      </div>
                    </TableHead>
                  );
                })}
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedData.length === 0 ? (
                <TableRow>
                  <TableCell 
                    colSpan={columns.length} 
                    className="py-12 text-center text-muted-foreground text-xs font-mono border-none"
                  >
                    No records found matching your criteria.
                  </TableCell>
                </TableRow>
              ) : (
                paginatedData.map((row, rowIdx) => (
                  <TableRow key={row.id || rowIdx} className="group">
                    {columns.map((col, colIdx) => (
                      <TableCell 
                        key={colIdx}
                        className={cn(
                          colIdx === 0 && "pl-4",
                          (col.align === "right" || (!col.align && colIdx === columns.length - 1)) ? "text-right pr-4" : col.align === "center" ? "text-center" : "text-left",
                          col.className
                        )}
                      >
                        {col.render ? col.render(row) : (col.accessorKey ? String(row[col.accessorKey] || "") : "")}
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* 3. Footer Pagination Bar */}
      {totalEntries > 0 && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-card/20 border border-border p-3.5 rounded-sm">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-muted-foreground font-mono justify-center sm:justify-start">
            <div className="flex items-center gap-1.5">
              <span>Show</span>
              <Select
                value={String(pageSizeState)}
                onValueChange={(val) => setPageSizeState(Number(val))}
                className="h-7 text-xs w-[72px] px-2 py-0"
              >
                <option value="5">5</option>
                <option value="10">10</option>
                <option value="20">20</option>
                <option value="50">50</option>
                <option value="100">100</option>
              </Select>
              <span>entries</span>
            </div>
            <div className="hidden sm:inline-block h-4 w-px bg-border/80" />
            <div>
              Showing <span className="font-semibold text-foreground">{Math.min(totalEntries, (currentPage - 1) * pageSizeState + 1)}</span> to{" "}
              <span className="font-semibold text-foreground">{Math.min(totalEntries, currentPage * pageSizeState)}</span> of{" "}
              <span className="font-semibold text-foreground">{totalEntries}</span> entries
            </div>
          </div>
          
          <div className="flex items-center gap-1 shrink-0 justify-center">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              disabled={currentPage === 1}
              className="h-8 w-8 rounded-sm"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            
            <div className="flex items-center gap-1 mx-1">
              {getPageNumbers().map((page, index) => {
                if (page === "...") {
                  return (
                    <span
                      key={`ellipsis-${index}`}
                      className="w-8 text-center text-muted-foreground/60 text-xs select-none"
                    >
                      ...
                    </span>
                  );
                }
                return (
                  <Button
                    key={page}
                    variant={currentPage === page ? "default" : "outline"}
                    onClick={() => setCurrentPage(Number(page))}
                    className="h-8 min-w-[32px] px-2 py-0 text-xs rounded-sm"
                  >
                    {page}
                  </Button>
                );
              })}
            </div>

            <Button
              variant="outline"
              size="icon"
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              disabled={currentPage === totalPages}
              className="h-8 w-8 rounded-sm"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

import { ActionsDropdown, ActionItem } from "./actions-dropdown";
export { ActionsDropdown };
export type { ActionItem };

export {
  Table,
  TableHeader,
  TableBody,
  TableFooter,
  TableRow,
  TableHead,
  TableCell,
  TableCaption,
};
