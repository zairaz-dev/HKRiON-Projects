import React, { useEffect, useState } from "react";
import { Dialog } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Printer } from "lucide-react";
import { invoiceSettingsService, InvoiceLayout } from "@/services/invoice-settings-service";
import { InvoiceRenderer, printInvoice } from "@/components/templates/invoice";
import { useCurrency } from "@/hooks/use-currency";

interface ReceiptPreviewProps {
  isOpen: boolean;
  onClose: () => void;
  sale: any;
  businessName: string;
  layout?: InvoiceLayout | null;
}

export function ReceiptPreview({
  isOpen,
  onClose,
  sale,
  businessName,
  layout: initialLayout,
}: ReceiptPreviewProps) {
  const [activeLayout, setActiveLayout] = useState<InvoiceLayout | null>(initialLayout || null);
  const { symbol } = useCurrency(sale?.businessId);

  useEffect(() => {
    if (initialLayout) {
      setActiveLayout(initialLayout);
      return;
    }
    if (isOpen && sale?.businessId) {
      invoiceSettingsService
        .getLayouts(sale.businessId, sale.branchId)
        .then((layouts) => {
          if (layouts.length > 0) {
            const defaultOrFirst = layouts.find((l) => l.isDefault) || layouts[0];
            setActiveLayout(defaultOrFirst);
          }
        })
        .catch(() => {});
    }
  }, [isOpen, sale, initialLayout]);

  if (!sale) return null;

  const effectiveBusinessName =
    sale?.business?.name ||
    sale?.branch?.business?.name ||
    (businessName !== "HKR ERP Store" ? businessName : "") ||
    "Business Store";

  const handlePrint = () => {
    printInvoice({
      sale,
      layout: activeLayout,
      businessName: effectiveBusinessName,
      currencySymbol: symbol,
    });
  };

  const headerTitle = activeLayout?.headerText || "INVOICE";
  const paperSize = activeLayout?.paperSize || "THERMAL_80MM";
  const dialogSize = paperSize === "A4" ? "4xl" : paperSize === "A5" ? "3xl" : "md";

  return (
    <Dialog isOpen={isOpen} onClose={onClose} title={`Invoice Bill Preview (${headerTitle})`} size={dialogSize}>
      <div className="flex flex-col items-center gap-4 py-2 w-full">
        {/* Render modular template */}
        <InvoiceRenderer
          sale={sale}
          layout={activeLayout}
          businessName={effectiveBusinessName}
          currencySymbol={symbol}
        />

        {/* Action Buttons */}
        <div className="flex gap-3 w-full justify-end pt-2">
          <Button type="button" variant="outline" onClick={onClose} className="h-10 text-sm">
            Close
          </Button>
          <Button
            type="button"
            onClick={handlePrint}
            className="h-10 text-sm bg-primary text-black font-semibold hover:bg-primary/90 flex items-center gap-2"
          >
            <Printer className="h-4 w-4" />
            Print Bill
          </Button>
        </div>
      </div>
    </Dialog>
  );
}
