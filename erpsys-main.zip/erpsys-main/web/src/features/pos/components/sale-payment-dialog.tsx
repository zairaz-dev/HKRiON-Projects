import React, { useState, useEffect } from "react";
import { Dialog } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Loader2, Trash2 } from "lucide-react";
import { usePaymentMethodsQuery } from "@/features/payment-methods/hooks/use-payment-methods";
import {
  useSalePaymentsQuery,
  useAddSalePaymentMutation,
  useDeleteSalePaymentMutation,
} from "../hooks/use-pos";
import { useCurrency } from "@/hooks/use-currency";

interface SalePaymentDialogProps {
  isOpen: boolean;
  onClose: () => void;
  sale: any;
  businessId: string;
  createdById?: string;
  onSuccess: (msg: string) => void;
  onError: (msg: string) => void;
}

export function SalePaymentDialog({
  isOpen,
  onClose,
  sale,
  businessId,
  createdById,
  onSuccess,
  onError,
}: SalePaymentDialogProps) {
  const branchId = sale?.branchId || "";
  const saleId = sale?.id || "";
  const { symbol, format } = useCurrency(businessId);

  // Queries & Mutations
  const { data: paymentMethods = [] } = usePaymentMethodsQuery(businessId, branchId, true);
  const { data: payments = [], isLoading: paymentsLoading } = useSalePaymentsQuery(saleId, businessId);
  
  const addPaymentMutation = useAddSalePaymentMutation();
  const deletePaymentMutation = useDeleteSalePaymentMutation();

  // Form states
  const [amount, setAmount] = useState<number>(0);
  const [paymentMethodId, setPaymentMethodId] = useState<string>("");
  const [transactionNo, setTransactionNo] = useState<string>("");
  const [notes, setNotes] = useState<string>("");

  const remainingDue = sale ? Math.max(0, sale.grandTotal - sale.amountPaid) : 0;

  // Sync remaining due and default payment method once loaded
  useEffect(() => {
    if (remainingDue > 0) {
      setAmount(remainingDue);
    }
    if (paymentMethods.length > 0) {
      setPaymentMethodId(paymentMethods[0].id);
    }
  }, [remainingDue, paymentMethods]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (amount <= 0) {
      alert("Payment amount must be greater than zero.");
      return;
    }
    if (amount > remainingDue) {
      alert(`Amount cannot exceed the remaining due of ${format(remainingDue)}`);
      return;
    }
    if (!paymentMethodId) {
      alert("Please select a payment method.");
      return;
    }

    try {
      await addPaymentMutation.mutateAsync({
        saleId,
        payload: {
          amount,
          paymentMethodId,
          transactionNo: transactionNo || undefined,
          notes: notes || undefined,
          businessId,
          createdById,
        },
      });
      onSuccess("Payment added successfully!");
      // Reset additional fields
      setTransactionNo("");
      setNotes("");
      onClose();
    } catch (err: any) {
      onError(err.message || "Failed to add payment.");
    }
  };

  const handleDeletePayment = async (paymentId: string) => {
    if (!confirm("Are you sure you want to void this payment?")) return;
    try {
      await deletePaymentMutation.mutateAsync({ paymentId, businessId });
      onSuccess("Payment voided successfully!");
    } catch (err: any) {
      onError(err.message || "Failed to void payment.");
    }
  };

  return (
    <Dialog isOpen={isOpen} onClose={onClose} title={`Record Payment - Invoice: ${sale?.invoiceNumber}`} size="lg">
      <div className="space-y-6 py-2 text-xs">
        {/* Info Box */}
        <div className="grid grid-cols-3 gap-4 border border-border/40 rounded p-3 bg-muted/20">
          <div>
            <span className="text-muted-foreground uppercase text-[10px] font-bold">Grand Total</span>
            <span className="text-sm font-bold block text-foreground">{format(sale?.grandTotal)}</span>
          </div>
          <div>
            <span className="text-muted-foreground uppercase text-[10px] font-bold">Amount Paid</span>
            <span className="text-sm font-bold block text-emerald-500">{format(sale?.amountPaid)}</span>
          </div>
          <div>
            <span className="text-muted-foreground uppercase text-[10px] font-bold">Remaining Due</span>
            <span className="text-sm font-bold block text-rose-500">{format(remainingDue)}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* New Payment Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <h4 className="font-bold text-foreground text-xs uppercase tracking-wider">
              Add New Payment
            </h4>
            
            <div className="space-y-1">
              <label className="font-semibold text-muted-foreground">Payment Amount ({symbol})</label>
              <Input
                type="number"
                step="0.01"
                min="0.01"
                max={remainingDue}
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="h-10 text-xs text-foreground bg-background"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-muted-foreground">Payment Method</label>
              <Select
                value={paymentMethodId}
                onValueChange={setPaymentMethodId}
                className="h-10 text-xs text-foreground bg-background"
              >
                {paymentMethods.map((pm) => (
                  <option key={pm.id} value={pm.id}>
                    {pm.name}
                  </option>
                ))}
              </Select>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-muted-foreground">Transaction Reference (Optional)</label>
              <Input
                type="text"
                placeholder="UPI Ref, Card Tx ID, etc."
                value={transactionNo}
                onChange={(e) => setTransactionNo(e.target.value)}
                className="h-10 text-xs text-foreground bg-background"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-muted-foreground">Notes (Optional)</label>
              <Input
                type="text"
                placeholder="Notes about payment..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="h-10 text-xs text-foreground bg-background"
              />
            </div>

            <Button
              type="submit"
              className="w-full h-10 font-bold"
              disabled={addPaymentMutation.isPending || remainingDue <= 0}
            >
              {addPaymentMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving Payment...
                </>
              ) : (
                "Save Payment"
              )}
            </Button>
          </form>

          {/* Payment History list */}
          <div className="space-y-4 border-t lg:border-t-0 lg:border-l border-border/60 pt-4 lg:pt-0 lg:pl-6">
            <h4 className="font-bold text-foreground text-xs uppercase tracking-wider">
              Payment Transactions History
            </h4>
            
            {paymentsLoading ? (
              <div className="py-8 text-center text-muted-foreground">
                <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
                <span className="text-xs block mt-1">Loading payments...</span>
              </div>
            ) : payments.length === 0 ? (
              <p className="text-muted-foreground italic text-center py-6">
                No payments have been recorded yet for this invoice.
              </p>
            ) : (
              <div className="space-y-2 overflow-y-auto max-h-[280px] pr-1">
                {payments.map((p: any) => (
                  <div key={p.id} className="p-3 border border-border/40 rounded bg-background/50 flex justify-between items-center gap-3">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-foreground">{p.paymentMethod?.name}</span>
                        <span className="text-[9px] font-mono text-muted-foreground">({p.paymentNumber})</span>
                      </div>
                      {p.transactionNo && (
                        <p className="text-[10px] text-muted-foreground">Ref: {p.transactionNo}</p>
                      )}
                      <p className="text-[10px] text-muted-foreground">
                        {new Date(p.paymentDate).toLocaleDateString()}
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="font-bold text-emerald-500">{format(p.amount)}</span>
                      <Button
                        type="button"
                        variant="secondary"
                        size="sm"
                        className="h-7 w-7 p-0 text-rose-500 hover:text-rose-600 border border-border/40 hover:bg-rose-500/5 hover:border-rose-500/10"
                        onClick={() => handleDeletePayment(p.id)}
                        disabled={deletePaymentMutation.isPending}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end border-t border-border pt-4">
          <Button type="button" onClick={onClose} variant="outline" className="h-10 text-xs">
            Close
          </Button>
        </div>
      </div>
    </Dialog>
  );
}
