import { z } from "zod";

export const purchaseLineSchema = z.object({
  variantId: z.string().min(1, "Product variant is required"),
  quantityPurchased: z.number().positive("Quantity must be greater than 0"),
  purchasePrice: z.number().nonnegative("Purchase price cannot be negative"),
  sellingPrice: z.number().nonnegative("Selling price cannot be negative"),
  batchNumber: z.string().optional().or(z.literal("")),
  expiryDate: z.string().optional().or(z.literal("")),
  imeis: z.array(z.string()).optional(),
});

export const purchaseFormSchema = z.object({
  purchaseNumber: z.string().min(1, "Purchase number/invoice is required").max(50),
  purchaseDate: z.string().optional(),
  supplierId: z.string().min(1, "Supplier is required"),
  branchId: z.string().min(1, "Branch is required"),
  discountType: z.enum(["FIXED", "PERCENTAGE"]).optional(),
  discountAmount: z.number().nonnegative().optional(),
  shippingAmount: z.number().nonnegative().optional(),
  taxAmount: z.number().nonnegative().optional(),
  notes: z.string().max(300).optional().or(z.literal("")),
  paymentAmount: z.number().nonnegative().optional(),
  paymentMethodId: z.string().optional().or(z.literal("")),
  paymentTransactionNo: z.string().max(100).optional().or(z.literal("")),
  paymentNotes: z.string().max(200).optional().or(z.literal("")),
  purchaseLines: z.array(purchaseLineSchema).min(1, "Please add at least one item to purchase"),
});

export type PurchaseFormValues = z.infer<typeof purchaseFormSchema>;
