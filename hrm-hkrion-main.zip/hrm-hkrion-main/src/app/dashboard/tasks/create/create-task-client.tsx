"use client";

import { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import { createTask } from "@/actions/tasks";
import { Role, TaskHealth, TaskPriority } from "@prisma/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/ui/page-header";
import { 
  ArrowLeft, 
  Layers, 
  CheckSquare, 
  FileText, 
  ListPlus, 
  Calendar, 
  Clock, 
  Users, 
  Link as LinkIcon, 
  Check, 
  CheckCircle2, 
  AlertTriangle, 
  AlertCircle, 
  Flag, 
  Flame, 
  Search, 
  Plus, 
  Trash2, 
  Sparkles, 
  ShieldAlert, 
  ChevronRight, 
  Loader2,
  X,
  Info
} from "lucide-react";
import Link from "next/link";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

interface UserItem {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  role: Role;
  profileImage?: string | null;
  position?: { title: string } | null;
}

interface TaskItem {
  id: number;
  title: string;
  category?: string | null;
  health: TaskHealth;
  priority: TaskPriority;
  dueDate?: Date | null;
}

interface CreateTaskClientProps {
  users: UserItem[];
  existingTasks: TaskItem[];
}

const CATEGORY_SUGGESTIONS = [
  "Engineering",
  "Product",
  "UI/UX Design",
  "HR & Operations",
  "DevOps & Infra",
  "Security & Compliance",
  "QA & Testing",
  "Marketing",
];

const MILESTONE_TEMPLATES = [
  "1. Technical Spec & RFC Approved",
  "2. UI Components & Flow Built",
  "3. Backend APIs & Migrations Completed",
  "4. QA Testing & Bug Bash",
  "5. Production Rollout & Monitored",
];

const PRIORITY_OPTIONS = [
  {
    value: TaskPriority.LOW,
    label: "Low",
    subtext: "Backlog / Minor",
    icon: Flag,
    color: "text-emerald-600 dark:text-emerald-400",
    bg: "bg-emerald-500/10",
    border: "border-emerald-500/30",
    activeRing: "ring-emerald-500/50 bg-emerald-500/10 border-emerald-500 text-emerald-700 dark:text-emerald-300",
  },
  {
    value: TaskPriority.MEDIUM,
    label: "Medium",
    subtext: "Standard Sprint Item",
    icon: Clock,
    color: "text-primary dark:text-primary-hover",
    bg: "bg-primary-soft",
    border: "border-primary/30",
    activeRing: "ring-primary/50 bg-primary-soft border-primary text-primary",
  },
  {
    value: TaskPriority.HIGH,
    label: "High",
    subtext: "High Priority Objective",
    icon: AlertTriangle,
    color: "text-amber-600 dark:text-amber-400",
    bg: "bg-amber-500/10",
    border: "border-amber-500/30",
    activeRing: "ring-amber-500/50 bg-amber-500/10 border-amber-500 text-amber-700 dark:text-amber-300",
  },
  {
    value: TaskPriority.URGENT,
    label: "Urgent",
    subtext: "Critical Path Blocker",
    icon: Flame,
    color: "text-rose-600 dark:text-rose-400",
    bg: "bg-rose-500/10",
    border: "border-rose-500/30",
    activeRing: "ring-rose-500/50 bg-rose-500/10 border-rose-500 text-rose-700 dark:text-rose-300",
    isUrgent: true,
  },
];

const healthBadgeConfig: Record<TaskHealth, { label: string; variant: "default" | "success" | "warning" | "error" | "info" | "secondary" }> = {
  NOT_STARTED: { label: "Not Started", variant: "secondary" },
  ON_TRACK: { label: "On Track", variant: "success" },
  AT_RISK: { label: "At Risk", variant: "warning" },
  BLOCKED: { label: "Blocked", variant: "error" },
  WAITING_REVIEW: { label: "In Review", variant: "info" },
};

export default function CreateTaskClient({ users, existingTasks }: CreateTaskClientProps) {
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [deliverables, setDeliverables] = useState("");
  const [instructions, setInstructions] = useState("");
  const [priority, setPriority] = useState<TaskPriority>(TaskPriority.MEDIUM);
  const [startDate, setStartDate] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [deadline, setDeadline] = useState("");

  const [milestones, setMilestones] = useState<string[]>([]);
  const [newMilestone, setNewMilestone] = useState("");

  const [assigneeIds, setAssigneeIds] = useState<number[]>([]);
  const [userSearch, setUserSearch] = useState("");

  const [dependencies, setDependencies] = useState<number[]>([]);
  const [taskSearch, setTaskSearch] = useState("");

  // Filtered users for assignment (exclude admins)
  const filteredUsers = useMemo(() => {
    const assignableUsers = users.filter(u => u.role !== "ADMIN" && u.role !== "SUPER_ADMIN");
    if (!userSearch.trim()) return assignableUsers;
    const q = userSearch.toLowerCase();
    return assignableUsers.filter(
      (u) =>
        u.firstName.toLowerCase().includes(q) ||
        u.lastName.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q) ||
        u.role.toLowerCase().includes(q) ||
        (u.position?.title && u.position.title.toLowerCase().includes(q))
    );
  }, [users, userSearch]);

  // Filtered tasks for dependencies
  const filteredTasks = useMemo(() => {
    if (!taskSearch.trim()) return existingTasks;
    const q = taskSearch.toLowerCase();
    return existingTasks.filter(
      (t) =>
        t.title.toLowerCase().includes(q) ||
        t.id.toString().includes(q) ||
        (t.category && t.category.toLowerCase().includes(q))
    );
  }, [existingTasks, taskSearch]);

  const toggleAssignee = (id: number) => {
    setAssigneeIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const selectAllUsers = () => {
    setAssigneeIds(filteredUsers.map((u) => u.id));
  };

  const clearAllUsers = () => {
    setAssigneeIds([]);
  };

  const toggleDependency = (id: number) => {
    setDependencies((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const addMilestone = () => {
    if (newMilestone.trim()) {
      setMilestones((prev) => [...prev, newMilestone.trim()]);
      setNewMilestone("");
    }
  };

  const addPresetMilestone = (titleText: string) => {
    if (!milestones.includes(titleText)) {
      setMilestones((prev) => [...prev, titleText]);
    }
  };

  const removeMilestone = (index: number) => {
    setMilestones((prev) => prev.filter((_, i) => i !== index));
  };

  // Quick date presets
  const setQuickDate = (daysFromNow: number) => {
    const d = new Date();
    d.setDate(d.getDate() + daysFromNow);
    const dateStr = d.toISOString().split("T")[0];
    setDueDate(dateStr);
  };

  const setEndOfMonth = () => {
    const d = new Date();
    const lastDay = new Date(d.getFullYear(), d.getMonth() + 1, 0);
    const dateStr = lastDay.toISOString().split("T")[0];
    setDueDate(dateStr);
  };

  const getInitials = (first: string, last: string) => {
    return `${first?.charAt(0) || ""}${last?.charAt(0) || ""}`.toUpperCase();
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!title.trim()) {
      toast.error("Please provide a task title");
      return;
    }

    setIsSubmitting(true);

    try {
      const formData = new FormData();
      formData.append("title", title.trim());
      if (category.trim()) formData.append("category", category.trim());
      if (description.trim()) formData.append("description", description.trim());
      if (deliverables.trim()) formData.append("deliverables", deliverables.trim());
      if (instructions.trim()) formData.append("instructions", instructions.trim());
      formData.append("priority", priority);
      if (startDate) formData.append("startDate", startDate);
      if (dueDate) formData.append("dueDate", dueDate);
      if (deadline) formData.append("deadline", deadline);

      formData.append("assigneeIds", JSON.stringify(assigneeIds));
      formData.append("dependencies", JSON.stringify(dependencies));
      formData.append("milestones", JSON.stringify(milestones));

      const result = await createTask(formData);

      if (result.error) {
        toast.error(result.error);
        setIsSubmitting(false);
      } else {
        toast.success("Task workspace assigned successfully!");
        router.push(`/dashboard/tasks/${result.taskId}`);
      }
    } catch (err: any) {
      toast.error(err?.message || "An unexpected error occurred while creating task.");
      setIsSubmitting(false);
    }
  };

  return (
    <form 
      onSubmit={handleSubmit} 
      className="space-y-6"
      onKeyDown={(e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
          e.preventDefault();
          const form = e.currentTarget;
          form.requestSubmit();
        }
      }}
    >
      {/* Top Header & Breadcrumb */}
      <PageHeader
        title="Create Task Workspace"
        description="Define objectives, assign team members, configure checkpoints, and establish task dependencies."
        badge={
          <Badge variant="default" className="hidden sm:inline-flex text-[11px]">
            Manager Action
          </Badge>
        }
        actions={
          <>
            <Link href="/dashboard/tasks">
              <Button type="button" variant="outline" size="sm">
                Cancel
              </Button>
            </Link>
            <Button type="submit" disabled={isSubmitting} size="sm" className="gap-2 shadow-sm">
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Assigning...
                </>
              ) : (
                <>
                  <Check className="h-4 w-4" />
                  Create Task
                </>
              )}
            </Button>
          </>
        }
      />

      {/* Main 2-Column Responsive Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Scope, Content, Deliverables, Checkpoints (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Card 1: Task Core Details */}
          <Card className="border-border bg-surface shadow-sm">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-primary-soft text-primary">
                    <Layers className="h-4 w-4" />
                  </div>
                  <div>
                    <CardTitle className="text-base font-semibold">1. Task Overview & Scope</CardTitle>
                    <CardDescription className="text-xs">
                      Provide clear title, domain categorization, and detailed context.
                    </CardDescription>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Task Title */}
              <div className="space-y-1.5">
                <Label htmlFor="title" className="text-xs font-semibold text-text-primary flex items-center justify-between">
                  <span>Task Title <span className="text-error font-bold">*</span></span>
                  <span className="text-[11px] font-normal text-text-muted">{title.length}/100 chars</span>
                </Label>
                <Input
                  id="title"
                  name="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  maxLength={100}
                  required
                  placeholder="e.g. Implement OAuth2 Social Login & Session Refresh"
                  className="font-medium text-sm"
                />
              </div>

              {/* Category with Quick Suggestion Pills */}
              <div className="space-y-2">
                <Label htmlFor="category" className="text-xs font-semibold text-text-primary">
                  Category / Domain
                </Label>
                <Input
                  id="category"
                  name="category"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  placeholder="e.g. Engineering, Design, Security"
                />
                
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[11px] font-medium text-text-secondary mr-1 flex items-center gap-1">
                    <Sparkles className="h-3 w-3 text-primary" /> Suggestions:
                  </span>
                  {CATEGORY_SUGGESTIONS.map((sug) => {
                    const isSelected = category.toLowerCase() === sug.toLowerCase();
                    return (
                      <button
                        type="button"
                        key={sug}
                        onClick={() => setCategory(sug)}
                        className={cn(
                          "px-2.5 py-0.5 rounded-full text-xs font-medium border transition-all duration-150 cursor-pointer",
                          isSelected
                            ? "bg-primary text-white border-primary shadow-xs"
                            : "bg-surface-secondary text-text-secondary border-border hover:border-primary/40 hover:text-text-primary"
                        )}
                      >
                        {sug}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Task Description */}
              <div className="space-y-1.5">
                <Label htmlFor="description" className="text-xs font-semibold text-text-primary">
                  Detailed Description & Background
                </Label>
                <textarea
                  id="description"
                  name="description"
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="flex w-full rounded-[8px] border border-border bg-surface px-3 py-2.5 text-sm text-text-primary placeholder:text-text-muted transition-colors focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary resize-y leading-relaxed"
                  placeholder="Provide background context, technical specifications, or why this task is being prioritized..."
                />
              </div>
            </CardContent>
          </Card>

          {/* Card 2: Deliverables & Acceptance Guidelines */}
          <Card className="border-border bg-surface shadow-sm">
            <CardHeader className="pb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-info-soft text-info bg-info-bg">
                  <CheckSquare className="h-4 w-4" />
                </div>
                <div>
                  <CardTitle className="text-base font-semibold">2. Deliverables & Guidelines</CardTitle>
                  <CardDescription className="text-xs">
                    Define the Definition of Done (DoD) and manager acceptance criteria.
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Expected Deliverables */}
              <div className="space-y-1.5">
                <Label htmlFor="deliverables" className="text-xs font-semibold text-text-primary flex items-center gap-1.5">
                  <FileText className="h-3.5 w-3.5 text-text-secondary" />
                  <span>Expected Deliverables / Definition of Done</span>
                </Label>
                <textarea
                  id="deliverables"
                  name="deliverables"
                  rows={3}
                  value={deliverables}
                  onChange={(e) => setDeliverables(e.target.value)}
                  className="flex w-full rounded-[8px] border border-border bg-surface px-3 py-2 text-sm text-text-primary placeholder:text-text-muted transition-colors focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary resize-y"
                  placeholder="e.g. Pull Request merged with unit tests, Figma mockups approved by client, API documentation published."
                />
                <p className="text-[11px] text-text-muted flex items-center gap-1">
                  <Info className="h-3 w-3" /> Specify the tangible artifact or link that marks task completion.
                </p>
              </div>

              {/* Manager Instructions */}
              <div className="space-y-1.5">
                <Label htmlFor="instructions" className="text-xs font-semibold text-text-primary flex items-center gap-1.5">
                  <Info className="h-3.5 w-3.5 text-text-secondary" />
                  <span>Manager Instructions & Review Guidelines (Optional)</span>
                </Label>
                <textarea
                  id="instructions"
                  name="instructions"
                  rows={2}
                  value={instructions}
                  onChange={(e) => setInstructions(e.target.value)}
                  className="flex w-full rounded-[8px] border border-border bg-surface px-3 py-2 text-sm text-text-primary placeholder:text-text-muted transition-colors focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary resize-y"
                  placeholder="e.g. Please sync with Lead Architect before running database migrations on staging."
                />
              </div>
            </CardContent>
          </Card>

          {/* Card 3: Milestones & Checkpoints */}
          <Card className="border-border bg-surface shadow-sm">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-success-bg text-success">
                    <ListPlus className="h-4 w-4" />
                  </div>
                  <div>
                    <CardTitle className="text-base font-semibold">3. Milestones & Checkpoints</CardTitle>
                    <CardDescription className="text-xs">
                      Break this task down into sequential milestones for clear tracking.
                    </CardDescription>
                  </div>
                </div>
                {milestones.length > 0 && (
                  <Badge variant="secondary" className="text-xs font-semibold">
                    {milestones.length} {milestones.length === 1 ? "step" : "steps"}
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Input for adding new milestone */}
              <div className="space-y-2">
                <div className="flex gap-2">
                  <Input
                    value={newMilestone}
                    onChange={(e) => setNewMilestone(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        addMilestone();
                      }
                    }}
                    placeholder="Add a step (e.g. 1. Architecture RFC signed off)"
                    className="text-sm"
                  />
                  <Button
                    type="button"
                    onClick={addMilestone}
                    variant="secondary"
                    className="shrink-0 gap-1.5"
                  >
                    <Plus className="h-4 w-4" />
                    <span>Add Step</span>
                  </Button>
                </div>

                {/* Quick Milestone Templates */}
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[11px] font-medium text-text-secondary mr-1">
                    Quick Templates:
                  </span>
                  {MILESTONE_TEMPLATES.map((tpl) => (
                    <button
                      type="button"
                      key={tpl}
                      onClick={() => addPresetMilestone(tpl)}
                      className="px-2 py-0.5 rounded text-[11px] font-medium bg-surface-secondary text-text-secondary border border-border hover:border-primary/40 hover:text-primary transition-colors cursor-pointer"
                    >
                      + {tpl.replace(/^\d+\.\s*/, "")}
                    </button>
                  ))}
                </div>
              </div>

              {/* Milestones List */}
              {milestones.length === 0 ? (
                <div className="p-6 border border-dashed border-border rounded-xl text-center space-y-2 bg-surface-secondary/30">
                  <div className="w-8 h-8 rounded-full bg-surface-secondary mx-auto flex items-center justify-center text-text-muted">
                    <CheckCircle2 className="h-4 w-4" />
                  </div>
                  <p className="text-xs font-medium text-text-secondary">No milestones configured yet</p>
                  <p className="text-[11px] text-text-muted max-w-sm mx-auto">
                    Milestones help assignees break work into concrete phases and report structured progress updates.
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  <AnimatePresence initial={false}>
                    {milestones.map((m, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: -4 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, height: 0, marginBottom: 0 }}
                        transition={{ duration: 0.15 }}
                        className="flex items-center justify-between gap-3 p-2.5 rounded-lg border border-border bg-surface-secondary/60 hover:bg-surface-secondary hover:border-border-strong transition-colors"
                      >
                        <div className="flex items-center gap-2.5 min-w-0 flex-1">
                          <span className="w-5 h-5 rounded-full bg-primary/10 text-primary border border-primary/20 flex items-center justify-center text-[10px] font-bold shrink-0">
                            {index + 1}
                          </span>
                          <span className="text-xs sm:text-sm font-medium text-text-primary truncate">
                            {m}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeMilestone(index)}
                          className="p-1 rounded text-text-muted hover:text-error hover:bg-error-bg transition-colors shrink-0"
                          title="Remove milestone"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              )}
            </CardContent>
          </Card>

        </div>

        {/* Right Column: Meta Controls, Priority, Timeline, Assignees, Dependencies (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Card 4: Priority & Schedule */}
          <Card className="border-border bg-surface shadow-sm">
            <CardHeader className="pb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-warning-bg text-warning">
                  <Calendar className="h-4 w-4" />
                </div>
                <div>
                  <CardTitle className="text-base font-semibold">Priority & Timeline</CardTitle>
                  <CardDescription className="text-xs">
                    Configure urgency level and completion targets.
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-5">
              
              {/* Priority Cards */}
              <div className="space-y-2">
                <Label className="text-xs font-semibold text-text-primary">
                  Task Priority Level
                </Label>
                <div className="grid grid-cols-2 gap-2">
                  {PRIORITY_OPTIONS.map((opt) => {
                    const isSelected = priority === opt.value;
                    const Icon = opt.icon;
                    return (
                      <button
                        type="button"
                        key={opt.value}
                        onClick={() => setPriority(opt.value)}
                        className={cn(
                          "relative p-3 rounded-lg border text-left transition-all duration-150 flex flex-col justify-between gap-2 cursor-pointer",
                          isSelected
                            ? `${opt.activeRing} ring-2 border-transparent shadow-xs`
                            : "border-border bg-surface-secondary/40 hover:bg-surface-secondary hover:border-border-strong text-text-secondary"
                        )}
                      >
                        <div className="flex items-center justify-between w-full">
                          <div className={cn("p-1.5 rounded-md", opt.bg, opt.color)}>
                            <Icon className="h-3.5 w-3.5" />
                          </div>
                          {isSelected && (
                            <div className="w-4 h-4 rounded-full bg-primary text-white flex items-center justify-center text-[10px]">
                              <Check className="h-2.5 w-2.5" />
                            </div>
                          )}
                          {!isSelected && opt.isUrgent && (
                            <span className="relative flex h-2 w-2">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                              <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
                            </span>
                          )}
                        </div>
                        <div>
                          <div className="text-xs font-bold text-text-primary">{opt.label}</div>
                          <div className="text-[10px] text-text-muted line-clamp-1">{opt.subtext}</div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Start Date */}
              <div className="space-y-2 pt-2 border-t border-border">
                <Label htmlFor="startDate" className="text-xs font-semibold text-text-primary flex items-center justify-between">
                  <span>Start Date (Optional)</span>
                  {startDate && (
                    <button
                      type="button"
                      onClick={() => setStartDate("")}
                      className="text-[10px] text-text-muted hover:text-error transition-colors"
                    >
                      Clear
                    </button>
                  )}
                </Label>
                <Input
                  id="startDate"
                  name="startDate"
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="text-sm font-medium"
                />
              </div>

              {/* Target Due Date */}
              <div className="space-y-2 pt-2 border-t border-border">
                <Label htmlFor="dueDate" className="text-xs font-semibold text-text-primary flex items-center justify-between">
                  <span>Target Date (Due Date)</span>
                  {dueDate && (
                    <button
                      type="button"
                      onClick={() => setDueDate("")}
                      className="text-[10px] text-text-muted hover:text-error transition-colors"
                    >
                      Clear
                    </button>
                  )}
                </Label>
                <Input
                  id="dueDate"
                  name="dueDate"
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="text-sm font-medium"
                />

                {/* Quick Date Presets */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  <button
                    type="button"
                    onClick={() => setQuickDate(0)}
                    className="px-2 py-0.5 rounded text-[11px] font-medium bg-surface-secondary text-text-secondary border border-border hover:border-primary/40 hover:text-primary transition-colors cursor-pointer"
                  >
                    Today
                  </button>
                  <button
                    type="button"
                    onClick={() => setQuickDate(3)}
                    className="px-2 py-0.5 rounded text-[11px] font-medium bg-surface-secondary text-text-secondary border border-border hover:border-primary/40 hover:text-primary transition-colors cursor-pointer"
                  >
                    +3 Days
                  </button>
                  <button
                    type="button"
                    onClick={() => setQuickDate(7)}
                    className="px-2 py-0.5 rounded text-[11px] font-medium bg-surface-secondary text-text-secondary border border-border hover:border-primary/40 hover:text-primary transition-colors cursor-pointer"
                  >
                    Next Week
                  </button>
                  <button
                    type="button"
                    onClick={setEndOfMonth}
                    className="px-2 py-0.5 rounded text-[11px] font-medium bg-surface-secondary text-text-secondary border border-border hover:border-primary/40 hover:text-primary transition-colors cursor-pointer"
                  >
                    End of Month
                  </button>
                </div>
              </div>

              {/* Hard Deadline (Time) */}
              <div className="space-y-1.5 pt-2 border-t border-border">
                <Label htmlFor="deadline" className="text-xs font-semibold text-text-primary flex items-center justify-between">
                  <span>Hard Cutoff Deadline (Optional)</span>
                  {deadline && (
                    <button
                      type="button"
                      onClick={() => setDeadline("")}
                      className="text-[10px] text-text-muted hover:text-error transition-colors"
                    >
                      Clear
                    </button>
                  )}
                </Label>
                <Input
                  id="deadline"
                  name="deadline"
                  type="datetime-local"
                  value={deadline}
                  onChange={(e) => setDeadline(e.target.value)}
                  className="text-sm font-medium"
                />
                <p className="text-[10px] text-text-muted">
                  Use for time-critical deliverables with strict submission cutoffs.
                </p>
              </div>

            </CardContent>
          </Card>

          {/* Card 5: Team Assignees */}
          <Card className="border-border bg-surface shadow-sm">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-primary-soft text-primary">
                    <Users className="h-4 w-4" />
                  </div>
                  <div>
                    <CardTitle className="text-base font-semibold">Assign Team Members</CardTitle>
                    <CardDescription className="text-xs">
                      Assign individual contributors or leads.
                    </CardDescription>
                  </div>
                </div>
                {assigneeIds.length > 0 && (
                  <Badge variant="default" className="text-xs">
                    {assigneeIds.length} assigned
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              
              {/* Search & Actions Bar */}
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-text-muted" />
                  <Input
                    value={userSearch}
                    onChange={(e) => setUserSearch(e.target.value)}
                    placeholder="Search by name, role, or title..."
                    className="pl-8 text-xs h-8"
                  />
                  {userSearch && (
                    <button
                      type="button"
                      onClick={() => setUserSearch("")}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={selectAllUsers}
                    className="h-8 text-[11px] px-2"
                  >
                    Select All
                  </Button>
                  {assigneeIds.length > 0 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={clearAllUsers}
                      className="h-8 text-[11px] px-2 text-text-muted hover:text-error"
                    >
                      Clear
                    </Button>
                  )}
                </div>
              </div>

              {/* Scrollable Assignee List */}
              <div className="max-h-64 overflow-y-auto space-y-1.5 pr-1 custom-scrollbar border border-border rounded-lg p-1.5 bg-surface-secondary/20">
                {filteredUsers.length === 0 ? (
                  <div className="p-4 text-center text-xs text-text-muted">
                    No team members found matching &ldquo;{userSearch}&rdquo;
                  </div>
                ) : (
                  filteredUsers.map((u) => {
                    const isSelected = assigneeIds.includes(u.id);
                    return (
                      <div
                        key={u.id}
                        onClick={() => toggleAssignee(u.id)}
                        className={cn(
                          "flex items-center justify-between p-2 rounded-lg border transition-all cursor-pointer select-none",
                          isSelected
                            ? "bg-primary-soft/80 border-primary/40 shadow-xs"
                            : "bg-surface border-border hover:bg-surface-secondary hover:border-border-strong"
                        )}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          {/* Avatar */}
                          <div className={cn(
                            "w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 transition-colors",
                            isSelected
                              ? "bg-primary text-white"
                              : "bg-surface-secondary text-text-secondary border border-border"
                          )}>
                            {u.profileImage ? (
                              <img
                                src={u.profileImage}
                                alt={u.firstName}
                                className="w-full h-full rounded-full object-cover"
                              />
                            ) : (
                              getInitials(u.firstName, u.lastName)
                            )}
                          </div>

                          {/* Info */}
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5">
                              <span className="text-xs font-semibold text-text-primary truncate">
                                {u.firstName} {u.lastName}
                              </span>
                              <span className={cn(
                                "text-[9px] font-bold px-1.5 py-0.2 rounded uppercase tracking-wider",
                                u.role === Role.SUPER_ADMIN ? "bg-primary-soft text-primary" :
                                u.role === Role.MANAGER ? "bg-info-bg text-info" :
                                "bg-surface-secondary text-text-secondary"
                              )}>
                                {u.role === Role.SUPER_ADMIN ? "Admin" : u.role === Role.MANAGER ? "Manager" : "Staff"}
                              </span>
                            </div>
                            <p className="text-[11px] text-text-muted truncate">
                              {u.position?.title || u.email}
                            </p>
                          </div>
                        </div>

                        {/* Checkbox indicator */}
                        <div className={cn(
                          "w-5 h-5 rounded-md border flex items-center justify-center transition-all shrink-0 ml-2",
                          isSelected
                            ? "bg-primary border-primary text-white"
                            : "border-border-strong bg-surface text-transparent"
                        )}>
                          <Check className="h-3 w-3" />
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

            </CardContent>
          </Card>

          {/* Card 6: Task Dependencies (Blocked By) */}
          <Card className="border-border bg-surface shadow-sm">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-error-bg text-error">
                    <ShieldAlert className="h-4 w-4" />
                  </div>
                  <div>
                    <CardTitle className="text-base font-semibold">Task Dependencies</CardTitle>
                    <CardDescription className="text-xs">
                      Link prerequisite tasks that must be resolved first.
                    </CardDescription>
                  </div>
                </div>
                {dependencies.length > 0 && (
                  <Badge variant="error" className="text-xs">
                    {dependencies.length} blockers
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              
              {/* Dependency Filter */}
              {existingTasks.length > 0 && (
                <div className="relative">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-text-muted" />
                  <Input
                    value={taskSearch}
                    onChange={(e) => setTaskSearch(e.target.value)}
                    placeholder="Search existing tasks to link..."
                    className="pl-8 text-xs h-8"
                  />
                  {taskSearch && (
                    <button
                      type="button"
                      onClick={() => setTaskSearch("")}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  )}
                </div>
              )}

              {/* Task Dependency List */}
              <div className="max-h-52 overflow-y-auto space-y-1.5 pr-1 custom-scrollbar border border-border rounded-lg p-1.5 bg-surface-secondary/20">
                {existingTasks.length === 0 ? (
                  <div className="p-4 text-center text-xs text-text-muted">
                    No other existing tasks in system yet.
                  </div>
                ) : filteredTasks.length === 0 ? (
                  <div className="p-4 text-center text-xs text-text-muted">
                    No tasks match &ldquo;{taskSearch}&rdquo;
                  </div>
                ) : (
                  filteredTasks.map((t) => {
                    const isSelected = dependencies.includes(t.id);
                    const healthInfo = healthBadgeConfig[t.health] || { label: t.health, variant: "secondary" };
                    return (
                      <div
                        key={t.id}
                        onClick={() => toggleDependency(t.id)}
                        className={cn(
                          "flex items-center justify-between p-2 rounded-lg border transition-all cursor-pointer select-none",
                          isSelected
                            ? "bg-error-bg/60 border-error/40 text-error shadow-xs"
                            : "bg-surface border-border hover:bg-surface-secondary hover:border-border-strong text-text-secondary"
                        )}
                      >
                        <div className="flex items-center gap-2 min-w-0 flex-1">
                          <LinkIcon className={cn("h-3.5 w-3.5 shrink-0", isSelected ? "text-error" : "text-text-muted")} />
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5">
                              <span className="text-[11px] font-mono font-bold text-text-muted">#{t.id}</span>
                              <span className="text-xs font-semibold text-text-primary truncate">
                                {t.title}
                              </span>
                            </div>
                            {t.category && (
                              <span className="text-[10px] text-text-muted truncate block">
                                {t.category}
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0 ml-2">
                          <Badge variant={healthInfo.variant} className="text-[10px] py-0 px-1.5">
                            {healthInfo.label}
                          </Badge>
                          <div className={cn(
                            "w-4 h-4 rounded border flex items-center justify-center text-[9px]",
                            isSelected ? "bg-error border-error text-white" : "border-border-strong bg-surface text-transparent"
                          )}>
                            <Check className="h-2.5 w-2.5" />
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

            </CardContent>
          </Card>

        </div>

      </div>

      {/* Floating / Sticky Footer Action Summary Bar */}
      <div className="sticky bottom-4 z-20 rounded-xl border border-border bg-surface/95 backdrop-blur-md p-4 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
        
        {/* Left: Quick Summary Badges */}
        <div className="flex flex-wrap items-center gap-2 text-xs text-text-secondary">
          <span className="font-semibold text-text-primary hidden sm:inline">Summary:</span>
          
          {/* Priority badge */}
          <span className={cn(
            "inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold",
            priority === TaskPriority.LOW ? "bg-emerald-500/10 text-emerald-600 border border-emerald-500/20" :
            priority === TaskPriority.MEDIUM ? "bg-primary-soft text-primary border border-primary/30" :
            priority === TaskPriority.HIGH ? "bg-amber-500/10 text-amber-600 border border-amber-500/20" :
            "bg-rose-500/10 text-rose-600 border border-rose-500/20"
          )}>
            Priority: {priority}
          </span>

          {/* Assignees badge */}
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-surface-secondary border border-border">
            <Users className="h-3 w-3 text-text-muted" />
            {assigneeIds.length} {assigneeIds.length === 1 ? "Assignee" : "Assignees"}
          </span>

          {/* Milestones badge */}
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-surface-secondary border border-border">
            <ListPlus className="h-3 w-3 text-text-muted" />
            {milestones.length} {milestones.length === 1 ? "Checkpoint" : "Checkpoints"}
          </span>

          {/* Dependencies badge */}
          {dependencies.length > 0 && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-error-bg text-error border border-error-border">
              <ShieldAlert className="h-3 w-3" />
              {dependencies.length} {dependencies.length === 1 ? "Blocker" : "Blockers"}
            </span>
          )}

          {/* Due date badge */}
          {dueDate && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-surface-secondary border border-border">
              <Calendar className="h-3 w-3 text-text-muted" />
              Due: {dueDate}
            </span>
          )}
        </div>

        {/* Right: Submit & Cancel Buttons */}
        <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
          <span className="text-[11px] text-text-muted hidden md:inline">
            Press <kbd className="px-1.5 py-0.5 text-[10px] font-mono bg-surface-secondary border border-border rounded">Ctrl+Enter</kbd> to submit
          </span>
          <Link href="/dashboard/tasks">
            <Button type="button" variant="outline" size="sm">
              Cancel
            </Button>
          </Link>
          <Button
            type="submit"
            disabled={isSubmitting}
            size="default"
            className="gap-2 font-semibold shadow-sm"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Assigning Task Workspace...
              </>
            ) : (
              <>
                <Check className="h-4 w-4" />
                Assign Task Workspace
              </>
            )}
          </Button>
        </div>

      </div>

    </form>
  );
}
