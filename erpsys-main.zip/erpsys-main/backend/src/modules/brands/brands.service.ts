import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class BrandsService {
  constructor(private readonly prisma: PrismaService) {}

  async createBrand(data: {
    name: string;
    description?: string;
    logoUrl?: string;
    isActive?: boolean;
    businessId: string;
    branchIds?: string[];
    createdById?: string;
  }) {
    // 0. Field validations
    const trimmedName = data.name?.trim();
    if (!trimmedName) {
      throw new BadRequestException('Brand name is required');
    }
    if (trimmedName.length < 2 || trimmedName.length > 100) {
      throw new BadRequestException('Brand name must be between 2 and 100 characters');
    }

    if (!data.businessId || !data.businessId.trim()) {
      throw new BadRequestException('Business ID is required');
    }

    if (data.description && data.description.length > 500) {
      throw new BadRequestException('Description cannot exceed 500 characters');
    }

    // 1. Verify all branches belong to the business
    if (data.branchIds && data.branchIds.length > 0) {
      const validBranches = await this.prisma.branch.findMany({
        where: {
          id: { in: data.branchIds },
          businessId: data.businessId,
        },
      });
      if (validBranches.length !== data.branchIds.length) {
        throw new BadRequestException('One or more selected branches are invalid');
      }
    }

    // 2. Check for duplicate name in the same business
    const existing = await this.prisma.brand.findFirst({
      where: {
        name: { equals: trimmedName, mode: 'insensitive' },
        businessId: data.businessId,
      },
    });

    if (existing) {
      throw new BadRequestException('A brand with this name already exists in this business');
    }

    // 3. Create Brand and its BrandBranch relations
    return this.prisma.$transaction(async (tx) => {
      const brand = await tx.brand.create({
        data: {
          name: trimmedName,
          description: data.description ? data.description.trim() : undefined,
          logoUrl: data.logoUrl,
          ...(data.isActive !== undefined && { isActive: data.isActive }),
          businessId: data.businessId,
          createdById: data.createdById,
        },
      });

      if (data.branchIds && data.branchIds.length > 0) {
        await tx.brandBranch.createMany({
          data: data.branchIds.map((branchId) => ({
            brandId: brand.id,
            branchId,
          })),
        });
      }

      return tx.brand.findUnique({
        where: { id: brand.id },
        include: {
          branches: {
            include: {
              branch: true,
            },
          },
        },
      });
    });
  }

  async getBrands(
    businessId: string,
    options: {
      page?: number;
      limit?: number;
      search?: string;
      branchId?: string;
    } = {},
  ) {
    const page = Number(options.page) || 1;
    const limit = Number(options.limit) || 10;
    const skip = (page - 1) * limit;
    const take = limit;

    const whereClause: any = { businessId };

    if (options.branchId) {
      if (options.branchId === 'global') {
        whereClause.branches = { none: {} };
      } else {
        whereClause.branches = {
          some: {
            branchId: options.branchId,
          },
        };
      }
    }

    if (options.search) {
      whereClause.OR = [
        { name: { contains: options.search, mode: 'insensitive' } },
        { description: { contains: options.search, mode: 'insensitive' } },
      ];
    }

    const [totalItems, data] = await Promise.all([
      this.prisma.brand.count({ where: whereClause }),
      this.prisma.brand.findMany({
        where: whereClause,
        skip,
        take,
        include: {
          branches: {
            include: {
              branch: true,
            },
          },
        },
        orderBy: {
          createdAt: 'desc',
        },
      }),
    ]);

    const totalPages = Math.ceil(totalItems / limit) || 1;

    return {
      data,
      meta: {
        totalItems,
        totalPages,
        currentPage: page,
        limit,
      },
    };
  }

  async getBrandById(id: string, businessId: string) {
    const brand = await this.prisma.brand.findFirst({
      where: { id, businessId },
      include: {
        branches: {
          include: {
            branch: true,
          },
        },
      },
    });

    if (!brand) {
      throw new BadRequestException('Brand not found');
    }

    return brand;
  }

  async updateBrand(
    id: string,
    businessId: string,
    data: {
      name?: string;
      description?: string;
      logoUrl?: string;
      isActive?: boolean;
      branchIds?: string[];
      updatedById?: string;
    },
  ) {
    const brand = await this.getBrandById(id, businessId);

    // 0. Field validations
    let trimmedName: string | undefined = undefined;
    if (data.name !== undefined) {
      trimmedName = data.name.trim();
      if (!trimmedName) {
        throw new BadRequestException('Brand name cannot be empty');
      }
      if (trimmedName.length < 2 || trimmedName.length > 100) {
        throw new BadRequestException('Brand name must be between 2 and 100 characters');
      }
    }

    if (data.description !== undefined && data.description !== null && data.description.length > 500) {
      throw new BadRequestException('Description cannot exceed 500 characters');
    }

    // 1. Verify all branches belong to the business if changing branchIds
    if (data.branchIds && data.branchIds.length > 0) {
      const validBranches = await this.prisma.branch.findMany({
        where: {
          id: { in: data.branchIds },
          businessId,
        },
      });
      if (validBranches.length !== data.branchIds.length) {
        throw new BadRequestException('One or more selected branches are invalid');
      }
    }

    // 2. Check for duplicate name if name is changing
    if (trimmedName && trimmedName !== brand.name) {
      const existing = await this.prisma.brand.findFirst({
        where: {
          id: { not: id },
          name: { equals: trimmedName, mode: 'insensitive' },
          businessId,
        },
      });

      if (existing) {
        throw new BadRequestException('A brand with this name already exists in this business');
      }
    }

    return this.prisma.$transaction(async (tx) => {
      // Update Brand details
      await tx.brand.update({
        where: { id },
        data: {
          ...(trimmedName !== undefined && { name: trimmedName }),
          ...(data.description !== undefined && { description: data.description ? data.description.trim() : null }),
          ...(data.logoUrl !== undefined && { logoUrl: data.logoUrl }),
          ...(data.isActive !== undefined && { isActive: data.isActive }),
          ...(data.updatedById !== undefined && { updatedById: data.updatedById }),
        },
      });

      // Update branch associations if provided
      if (data.branchIds !== undefined) {
        // Delete existing branch associations
        await tx.brandBranch.deleteMany({
          where: { brandId: id },
        });

        // Add new branch associations
        if (data.branchIds.length > 0) {
          await tx.brandBranch.createMany({
            data: data.branchIds.map((bId) => ({
              brandId: id,
              branchId: bId,
            })),
          });
        }
      }

      return tx.brand.findUnique({
        where: { id },
        include: {
          branches: {
            include: {
              branch: true,
            },
          },
        },
      });
    });
  }

  async deleteBrand(id: string, businessId: string) {
    await this.getBrandById(id, businessId);

    // 1. Check if brand is associated with products
    const productCount = await this.prisma.product.count({
      where: { brandId: id },
    });

    if (productCount > 0) {
      throw new BadRequestException(
        `Cannot delete brand because it is associated with ${productCount} product(s). Please reassign or remove the products first.`
      );
    }

    // Delete will cascade to BrandBranch due to onDelete: Cascade
    await this.prisma.brand.delete({
      where: { id, businessId },
    });

    return { success: true };
  }
}
