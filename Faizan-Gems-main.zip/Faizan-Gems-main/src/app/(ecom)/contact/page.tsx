"use client";

import React, { useState } from "react";
import { CheckIcon, AwardIcon } from "@/components/ui/LuxuryIcons";
import { LuxurySelect } from "@/components/ui/LuxurySelect";
import { useCMS } from "@/features/cms/useCMS";
import { SITE_CONFIG } from "@/lib/constants/site";

export default function ContactPage() {
  const { getBlock } = useCMS();

  // Dynamic Contact CMS Blocks
  const pageEyebrow = getBlock("contact.page_eyebrow", "Get in Touch");
  const pageTitle = getBlock("contact.page_title", "Book a Consultation");
  const pageSubtitle = getBlock(
    "contact.page_subtitle",
    "Have a question about a gemstone? Want to visit our showroom? Or need help with a custom order? We're here to help."
  );

  const cardTitle = getBlock("contact.card_title", "Contact Information");
  const addressLabel = getBlock("contact.address_label", "Showroom Address");
  const address = getBlock("contact.address", SITE_CONFIG.showroom.address);
  const country = getBlock("contact.country", SITE_CONFIG.showroom.country);
  const hours = getBlock("contact.hours", SITE_CONFIG.contact.hours);
  const phoneLabel = getBlock("contact.phone_label", "Phone Number & WhatsApp");
  const phone = getBlock("contact.phone", SITE_CONFIG.contact.phone);
  const secondaryPhone = getBlock("contact.secondary_phone", SITE_CONFIG.contact.secondaryPhone) || getBlock("contact.landline", SITE_CONFIG.contact.landline);
  const responseTime = getBlock("contact.response_time", SITE_CONFIG.contact.responseTime);
  const emailLabel = getBlock("contact.email_label", "Email");
  const email = getBlock("contact.email", SITE_CONFIG.contact.email);

  const deliveryBadge = getBlock("contact.delivery_badge", "100% Authenticity & Lifetime Guarantee");
  const deliveryDescription = getBlock(
    "contact.delivery_description",
    "Every gemstone is guaranteed 100% natural, independently certified by premier gemological laboratories, and backed by our unconditional lifetime guarantee of authenticity."
  );

  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    consultationFormat: "Virtual Private Video Consultation (High-Def Microscope)",
    inquiryType: "Acquisition Inquiry",
    budget: "Any",
    message: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await fetch("/api/inquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          preferredLocation: formData.consultationFormat,
          preferredSalon: formData.consultationFormat,
          message: `[${formData.inquiryType} | Budget: ${formData.budget}] ${formData.message}`,
        }),
      });
    } catch {
      // Continue and show confirmation even if offline
    } finally {
      setIsSubmitting(false);
      setSubmitted(true);
    }
  };

  return (
    <div className="bg-[#FAF8F5] min-h-screen py-12 lg:py-20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          {pageEyebrow && (
            <span className="text-[11px] font-sans tracking-wide-luxury uppercase text-[#9A7B4F] block">
              {pageEyebrow}
            </span>
          )}
          {pageTitle && (
            <h1 className="font-serif text-3xl sm:text-5xl text-[#18181D]">
              {pageTitle}
            </h1>
          )}
          {pageSubtitle && (
            <p className="text-xs sm:text-sm text-[#6B655C] font-sans leading-relaxed">
              {pageSubtitle}
            </p>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Contact Form (7 Cols) */}
          <div className="lg:col-span-7 bg-white border border-[#E8E4DC] p-6 sm:p-10 shadow-sm">
            {!submitted ? (
              <form onSubmit={handleSubmit} className="space-y-5 text-xs font-sans">
                <div>
                  <label className="block text-[#554F47] uppercase tracking-wider text-[10px] mb-1">
                    Your Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Your full name"
                    className="w-full px-3.5 py-3 bg-[#FAF8F5] border border-[#E8E4DC] focus:border-[#C5A880] focus:outline-none text-[#18181D]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[#554F47] uppercase tracking-wider text-[10px] mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="your@email.com"
                      className="w-full px-3.5 py-3 bg-[#FAF8F5] border border-[#E8E4DC] focus:border-[#C5A880] focus:outline-none text-[#18181D]"
                    />
                  </div>
                  <div>
                    <label className="block text-[#554F47] uppercase tracking-wider text-[10px] mb-1">
                      Telephone / WhatsApp *
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder={phone || SITE_CONFIG.contact.phone}
                      className="w-full px-3.5 py-3 bg-[#FAF8F5] border border-[#E8E4DC] focus:border-[#C5A880] focus:outline-none text-[#18181D]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[#554F47] uppercase tracking-wider text-[10px] mb-1">
                      Consultation Format
                    </label>
                    <LuxurySelect
                      value={formData.consultationFormat}
                      onChange={(val) => setFormData({ ...formData, consultationFormat: val })}
                      variant="light"
                      size="md"
                      options={[
                        {
                          value: "Virtual Private Video Consultation (High-Def Microscope)",
                          label: "Video Call (with live gemstone view)",
                        },
                        {
                          value: "Trincomalee Flagship Showroom",
                          label: "Trincomalee Showroom (No. 283/2, N.C Road)",
                        },
                        {
                          value: "Phone / WhatsApp Consultation",
                          label: "Direct Phone / WhatsApp",
                        },
                      ]}
                    />
                  </div>

                  <div>
                    <label className="block text-[#554F47] uppercase tracking-wider text-[10px] mb-1">
                      Inquiry Focus
                    </label>
                    <LuxurySelect
                      value={formData.inquiryType}
                      onChange={(val) => setFormData({ ...formData, inquiryType: val })}
                      variant="light"
                      size="md"
                      options={[
                        { value: "Acquisition Inquiry", label: "I want to buy a specific gemstone" },
                        { value: "Custom Sourcing", label: "Help me find a gemstone" },
                        { value: "Collector Portfolio", label: "Investment or collection advice" },
                        { value: "Vault Appraisal", label: "Gemstone valuation" },
                      ]}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[#554F47] uppercase tracking-wider text-[10px] mb-1">
                    Your Message or Gemstone Reference
                  </label>
                  <textarea
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Tell us what you're looking for — gemstone type, size, origin, budget, etc."
                    className="w-full px-3.5 py-3 bg-[#FAF8F5] border border-[#E8E4DC] focus:border-[#C5A880] focus:outline-none text-[#18181D]"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-4 bg-[#18181D] hover:bg-[#2A2A32] disabled:opacity-60 text-white text-xs uppercase tracking-luxury font-sans font-medium transition-colors shadow-lg active:scale-[0.99]"
                >
                  {isSubmitting ? "Sending your message..." : "Send Message"}
                </button>
              </form>
            ) : (
              <div className="py-12 text-center space-y-4">
                <div className="w-12 h-12 rounded-full bg-[#18181D] text-[#C5A880] mx-auto flex items-center justify-center">
                  <CheckIcon className="w-6 h-6" />
                </div>
                <h3 className="font-serif text-2xl text-[#18181D]">Message Sent!</h3>
                <p className="text-xs text-[#6B655C] font-sans max-w-sm mx-auto leading-relaxed">
                  Thank you, {formData.name}. Our team will get back to you at {formData.email} within 2 business hours.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-4 text-xs uppercase tracking-wider text-[#9A7B4F] underline"
                >
                  Send Another Inquiry
                </button>
              </div>
            )}
          </div>

          {/* Showrooms & Direct Contacts (5 Cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white border border-[#E8E4DC] p-6 space-y-6 text-xs font-sans shadow-sm">
              {cardTitle && (
                <h3 className="font-serif text-lg text-[#18181D] border-b border-[#F2EFE9] pb-3 font-medium">
                  {cardTitle}
                </h3>
              )}

              <div className="space-y-4 text-[#554F47]">
                {(address || country || hours) && (
                  <div>
                    {addressLabel && (
                      <span className="text-[#8C867D] uppercase tracking-wider text-[10px] block">
                        {addressLabel}
                      </span>
                    )}
                    {address && <p className="text-[#18181D] font-medium mt-0.5">{address}</p>}
                    {country && <p className="text-[#18181D] font-medium">{country}</p>}
                    {hours && <p className="text-[10px] text-[#A29F96] mt-1">{hours}</p>}
                  </div>
                )}

                {(phone || secondaryPhone || responseTime) && (
                  <div className="pt-3 border-t border-[#F2EFE9]">
                    {phoneLabel && (
                      <span className="text-[#8C867D] uppercase tracking-wider text-[10px] block">
                        {phoneLabel}
                      </span>
                    )}
                    {phone && (
                      <p className="text-[#18181D] font-medium mt-0.5">
                        <a href={`tel:${phone.replace(/\s+/g, "")}`} className="hover:text-[#9A7B4F] transition-colors">
                          {phone}
                        </a>
                      </p>
                    )}
                    {secondaryPhone && (
                      <p className="text-[#18181D] font-medium mt-0.5">
                        <a href={`tel:${secondaryPhone.replace(/\s+/g, "")}`} className="hover:text-[#9A7B4F] transition-colors">
                          {secondaryPhone}
                        </a>
                      </p>
                    )}
                    {responseTime && <p className="text-[#8C867D] mt-1">{responseTime}</p>}
                  </div>
                )}

                {email && (
                  <div className="pt-3 border-t border-[#F2EFE9]">
                    {emailLabel && (
                      <span className="text-[#8C867D] uppercase tracking-wider text-[10px] block">
                        {emailLabel}
                      </span>
                    )}
                    <p className="text-[#9A7B4F] font-mono mt-0.5">
                      <a href={`mailto:${email}`} className="hover:underline">
                        {email}
                      </a>
                    </p>
                  </div>
                )}
              </div>
            </div>

            {(deliveryBadge || deliveryDescription) && (
              <div className="p-6 bg-[#18181D] text-white border border-[#2A2A32] space-y-3 text-xs font-sans shadow-sm">
                {deliveryBadge && (
                  <div className="flex items-center gap-2 text-[#C5A880]">
                    <AwardIcon className="w-5 h-5 flex-shrink-0" />
                    <span className="uppercase tracking-wider font-medium">{deliveryBadge}</span>
                  </div>
                )}
                {deliveryDescription && (
                  <p className="text-[#D3CBBF] leading-relaxed">
                    {deliveryDescription}
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
