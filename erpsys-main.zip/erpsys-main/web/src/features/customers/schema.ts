import * as z from "zod";

export const customerFormSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, "Customer name must be at least 2 characters")
    .max(100, "Customer name must be under 100 characters"),
  image: z.string().nullable().optional(),
  businessName: z.string().max(100, "Business name cannot exceed 100 characters").optional(),
  email: z.string().email("Invalid email address").or(z.literal("")).nullable().optional(),
  phone: z.string().min(7, "Phone number must be at least 7 digits").or(z.literal("")).nullable().optional(),
  taxNumber: z.string().max(50, "Tax number cannot exceed 50 characters").optional(),
  openingBalance: z.number().min(0, "Opening balance must be 0 or greater"),
  creditLimit: z.number().min(0, "Credit limit must be 0 or greater").nullable().optional(),
  address: z.string().max(500, "Address cannot exceed 500 characters").optional(),
  customerGroupId: z.string().nullable().optional(),
  branchIds: z.array(z.string()),
  isActive: z.boolean(),
  allowCredit: z.boolean(),
});

export type CustomerFormSchema = z.infer<typeof customerFormSchema>;
