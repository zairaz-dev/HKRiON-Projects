"use client";

import { useState } from "react";
import {
  GripVertical,
  Eye,
  EyeOff,
  Edit3,
  Sliders,
  Check,
  Save,
  Globe,
  Sparkles,
  Smartphone,
  Tablet,
  Monitor,
  ArrowUp,
  ArrowDown,
  LayoutTemplate,
  Award,
  BarChart3,
  Megaphone,
  Layers,
  SplitSquareVertical,
  FolderKanban,
  CheckCircle2,
} from "lucide-react";
import Link from "next/link";

interface SectionItem {
  id: string;
  name: string;
  category: string;
  enabled: boolean;
  iconName: string;
  description: string;
  badge?: string;
}

interface SectionBuilderProps {
  initialContent: Record<string, any>;
}

export default function SectionBuilder({ initialContent }: SectionBuilderProps) {
  const [sections, setSections] = useState<SectionItem[]>([
    {
      id: "hero",
      name: "Hero Slideshow Banner",
      category: "Header & First Impression",
      enabled: true,
      iconName: "hero",
      description: "Headline, animated typography, CTA buttons, and badge",
    },
    {
      id: "philosophy",
      name: "Editorial Philosophy & Quote",
      category: "Brand Statement",
      enabled: true,
      iconName: "philosophy",
      description: "Quote block, highlight word, and division tags",
    },
    {
      id: "about",
      name: "About SHADEIT Story",
      category: "Company Profile",
      enabled: true,
      iconName: "about",
      description: "Headline, story paragraph, custom features, and image",
    },
    {
      id: "solutions",
      name: "Solutions Showcase Grid",
      category: "Core Services",
      enabled: true,
      iconName: "solutions",
      description: "Interactive category carousel and shading products",
    },
    {
      id: "metrics",
      name: "Editorial Metrics Strip",
      category: "Social Proof",
      enabled: true,
      iconName: "metrics",
      description: "3 animated count-up numbers (Years, Projects, Satisfaction)",
    },
    {
      id: "transformation",
      name: "Before & After Transformation",
      category: "Interactive Visual",
      enabled: true,
      iconName: "transformation",
      description: "Interactive comparison slider showcasing plain vs finished",
    },
    {
      id: "projects",
      name: "Featured Projects Gallery",
      category: "Portfolio",
      enabled: true,
      iconName: "projects",
      description: "Asymmetrical villa and commercial projects grid",
    },
    {
      id: "cta",
      name: "Closing Consultation Banner",
      category: "Conversion CTA",
      enabled: true,
      iconName: "cta",
      description: "Free site measurement booking prompt and action button",
    },
  ]);

  const [activeEditingId, setActiveEditingId] = useState<string | null>("hero");
  const [previewDevice, setPreviewDevice] = useState<"desktop" | "tablet" | "mobile">("desktop");
  const [formData, setFormData] = useState<Record<string, any>>(initialContent);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [isUploading, setIsUploading] = useState(false);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, key: string) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    setIsUploading(true);
    try {
      const uploadData = new FormData();
      uploadData.append("files", files[0]);

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        body: uploadData,
      });

      const data = await res.json();
      if (data.success && data.urls.length > 0) {
        handleInputChange(key, data.urls[0]);
      } else {
        alert("Upload failed: " + data.error);
      }
    } catch (err) {
      console.error("Upload error:", err);
      alert("Failed to upload image.");
    } finally {
      setIsUploading(false);
      e.target.value = "";
    }
  };

  // Toggle Section Enabled
  const toggleSection = (id: string) => {
    setSections((prev) =>
      prev.map((s) => (s.id === id ? { ...s, enabled: !s.enabled } : s))
    );
  };

  // Move Section Up/Down
  const moveSection = (index: number, direction: "up" | "down") => {
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= sections.length) return;

    const newSections = [...sections];
    const temp = newSections[index];
    newSections[index] = newSections[targetIndex];
    newSections[targetIndex] = temp;
    setSections(newSections);
  };

  const handleInputChange = (key: string, value: any) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
  };

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "hero":
        return <LayoutTemplate size={18} className="text-amber-600" />;
      case "philosophy":
        return <Sparkles size={18} className="text-amber-600" />;
      case "about":
        return <Award size={18} className="text-blue-600" />;
      case "solutions":
        return <Layers size={18} className="text-purple-600" />;
      case "metrics":
        return <BarChart3 size={18} className="text-emerald-600" />;
      case "transformation":
        return <SplitSquareVertical size={18} className="text-amber-600" />;
      case "projects":
        return <FolderKanban size={18} className="text-blue-600" />;
      case "cta":
        return <Megaphone size={18} className="text-red-600" />;
      default:
        return <LayoutTemplate size={18} className="text-neutral-500" />;
    }
  };

  return (
    <div className="space-y-6 w-full pb-16">
      {/* Header with Publish Controls */}
      <div className="bg-white dark:bg-black p-5 sm:p-6 rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 px-2.5 py-0.5 rounded-none">
              VISUAL CMS BUILDER
            </span>
            <span className="text-xs text-neutral-400 dark:text-neutral-500">• Drag, toggle & edit live sections</span>
          </div>
          <h1 className="text-2xl font-extrabold text-neutral-900 dark:text-white mt-1.5">
            Home Page Content & Sections
          </h1>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
            Rearrange sections, toggle visibility, and update titles, descriptions, and media instantly.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => setShowPreviewModal(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-none bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-900 dark:hover:bg-neutral-850 text-neutral-800 dark:text-neutral-200 text-xs font-bold border border-[#E5E5E0] dark:border-neutral-800 transition-all cursor-pointer"
          >
            <Eye size={14} />
            <span>Live Device Preview</span>
          </button>

          <button
            type="submit"
            form="cms-form"
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-none bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-extrabold shadow-xs transition-all cursor-pointer active:scale-95"
          >
            <Save size={14} />
            <span>Publish Changes</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Left is Section Stack List, Right is Focused Section Editor */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Visual Section Reorder Stack (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-xs font-bold uppercase tracking-wider text-neutral-400 dark:text-neutral-500">
              Page Section Stack ({sections.length})
            </h2>
            <span className="text-[11px] text-neutral-400 dark:text-neutral-500 font-medium">Reorder or toggle ON/OFF</span>
          </div>

          <div className="space-y-2">
            {sections.map((section, idx) => {
              const isSelected = activeEditingId === section.id;
              return (
                <div
                  key={section.id}
                  className={`p-3.5 rounded-none border transition-all ${
                    isSelected
                      ? "bg-white dark:bg-black border-amber-500 shadow-md ring-2 ring-amber-500/20"
                      : "bg-white dark:bg-black border-[#E5E5E0] dark:border-neutral-800 hover:border-neutral-300 dark:hover:border-neutral-700 shadow-2xs"
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    {/* Left: Move buttons + Icon + Info */}
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="flex flex-col gap-0.5 text-neutral-400 dark:text-neutral-500 shrink-0">
                        <button
                          type="button"
                          disabled={idx === 0}
                          onClick={() => moveSection(idx, "up")}
                          className="hover:text-neutral-900 dark:hover:text-white disabled:opacity-20 cursor-pointer p-0.5"
                          title="Move Up"
                        >
                          <ArrowUp size={12} />
                        </button>
                        <button
                          type="button"
                          disabled={idx === sections.length - 1}
                          onClick={() => moveSection(idx, "down")}
                          className="hover:text-neutral-900 dark:hover:text-white disabled:opacity-20 cursor-pointer p-0.5"
                          title="Move Down"
                        >
                          <ArrowDown size={12} />
                        </button>
                      </div>

                      <div className="w-8 h-8 rounded-none bg-neutral-100 dark:bg-neutral-900 flex items-center justify-center shrink-0">
                        {getIcon(section.iconName)}
                      </div>

                      <div className="overflow-hidden min-w-0 cursor-pointer" onClick={() => setActiveEditingId(section.id)}>
                        <div className="flex items-center gap-2">
                          <h3 className="text-xs font-bold text-neutral-900 dark:text-white truncate">
                            {section.name}
                          </h3>
                        </div>
                        <p className="text-[10px] text-neutral-400 dark:text-neutral-500 truncate">{section.category}</p>
                      </div>
                    </div>

                    {/* Right: ON/OFF Switch + Edit Button */}
                    <div className="flex items-center gap-2 shrink-0">
                      {/* ON/OFF Switch */}
                      <button
                        type="button"
                        onClick={() => toggleSection(section.id)}
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-none text-[10px] font-bold border transition-colors cursor-pointer ${
                          section.enabled
                            ? "bg-emerald-50 dark:bg-emerald-400/10 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-400/30"
                            : "bg-neutral-100 dark:bg-neutral-900 text-neutral-400 dark:text-neutral-500 border-neutral-200 dark:border-neutral-800"
                        }`}
                      >
                        {section.enabled ? (
                          <>
                            <span className="w-1.5 h-1.5 rounded-none bg-emerald-500" />
                            <span>ON</span>
                          </>
                        ) : (
                          <>
                            <span className="w-1.5 h-1.5 rounded-none bg-neutral-400 dark:bg-neutral-500" />
                            <span>OFF</span>
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => setActiveEditingId(section.id)}
                        className={`p-1.5 rounded-none border text-xs font-semibold transition-colors cursor-pointer ${
                          isSelected
                            ? "bg-amber-500 text-slate-950 border-amber-600 font-bold"
                            : "bg-neutral-50 dark:bg-neutral-900 hover:bg-neutral-100 dark:hover:bg-neutral-850 text-neutral-700 dark:text-neutral-300 border-[#E5E5E0] dark:border-neutral-800"
                        }`}
                        title="Edit Section Content"
                      >
                        <Edit3 size={13} />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Active Section Field Editor (7 cols) */}
        <div className="lg:col-span-7 bg-white dark:bg-black rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs p-5 sm:p-7">
          <form id="cms-form" method="POST" action="/api/admin/homepage" className="space-y-6">
            {/* 1. HERO BANNER EDITOR */}
            {activeEditingId === "hero" && (
              <div className="space-y-5 animate-in fade-in duration-200">
                <div className="border-b border-neutral-100 dark:border-neutral-800 pb-4">
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
                    Section 01
                  </span>
                  <h2 className="text-lg font-bold text-neutral-900 dark:text-white mt-0.5">Hero Banner & Slideshow</h2>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                    Configure the top headline, highlighted words, badges, and CTA action buttons.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">Top Status Badge</label>
                    <input
                      type="text"
                      name="heroStatusBadge"
                      value={formData.heroStatusBadge || ""}
                      onChange={(e) => handleInputChange("heroStatusBadge", e.target.value)}
                      className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">Main Highlight Badge</label>
                    <input
                      type="text"
                      name="heroMainBadge"
                      value={formData.heroMainBadge || ""}
                      onChange={(e) => handleInputChange("heroMainBadge", e.target.value)}
                      className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">Headline Prefix</label>
                    <input
                      type="text"
                      name="heroTitlePrefix"
                      value={formData.heroTitlePrefix || ""}
                      onChange={(e) => handleInputChange("heroTitlePrefix", e.target.value)}
                      className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">Headline Highlight (Gold Gradient)</label>
                    <input
                      type="text"
                      name="heroTitleHighlight"
                      value={formData.heroTitleHighlight || ""}
                      onChange={(e) => handleInputChange("heroTitleHighlight", e.target.value)}
                      className="w-full px-3.5 py-2 bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-400/30 focus:border-amber-500 rounded-none text-xs text-amber-950 dark:text-amber-300 outline-hidden font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">Headline Suffix</label>
                    <input
                      type="text"
                      name="heroTitleSuffix"
                      value={formData.heroTitleSuffix || ""}
                      onChange={(e) => handleInputChange("heroTitleSuffix", e.target.value)}
                      className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">Hero Subtitle</label>
                    <textarea
                      name="heroSubtitle"
                      rows={3}
                      value={formData.heroSubtitle || ""}
                      onChange={(e) => handleInputChange("heroSubtitle", e.target.value)}
                      className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-neutral-100 dark:border-neutral-800">
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">Primary Button Text</label>
                    <input
                      type="text"
                      name="heroCtaPrimaryText"
                      value={formData.heroCtaPrimaryText || ""}
                      onChange={(e) => handleInputChange("heroCtaPrimaryText", e.target.value)}
                      className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">Secondary Button Text</label>
                    <input
                      type="text"
                      name="heroCtaSecondaryText"
                      value={formData.heroCtaSecondaryText || ""}
                      onChange={(e) => handleInputChange("heroCtaSecondaryText", e.target.value)}
                      className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                    />
                  </div>
                </div>

                {/* HERO BACKGROUND SLIDESHOW IMAGES (4 SLIDES) */}
                <div className="space-y-4 pt-4 border-t border-neutral-100 dark:border-neutral-800">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
                        Hero Slideshow Images (4 Slides)
                      </span>
                      <p className="text-[11px] text-neutral-400 dark:text-neutral-500 mt-0.5">
                        These images crossfade automatically in the hero background every 5 seconds.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Slide 1 */}
                    <div className="p-4 rounded-none border border-[#E5E5E0] dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-neutral-800 dark:text-neutral-200">Slide 01 (Main)</span>
                        <span className="text-[10px] bg-amber-100 dark:bg-amber-400/20 text-amber-900 dark:text-amber-300 font-bold px-2 py-0.5 rounded-none">Default</span>
                      </div>
                      <div className="relative aspect-16/9 rounded-none overflow-hidden bg-neutral-200 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800">
                        <img
                          src={formData.heroSlide1Image || "/hero_banner_1786018413238.png"}
                          alt="Slide 1"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-neutral-600 dark:text-neutral-400 mb-1">
                          {isUploading ? "Uploading..." : "Upload Image"}
                        </label>
                        <input type="hidden" name="heroSlide1Image" value={formData.heroSlide1Image || ""} />
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleImageUpload(e, "heroSlide1Image")}
                          className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100"
                          disabled={isUploading}
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-neutral-600 dark:text-neutral-400 mb-1">Slide Title</label>
                        <input
                          type="text"
                          name="heroSlide1Title"
                          value={formData.heroSlide1Title || ""}
                          onChange={(e) => handleInputChange("heroSlide1Title", e.target.value)}
                          placeholder="Luxury Residential Shading"
                          className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-neutral-600 dark:text-neutral-400 mb-1">Slide Tag</label>
                        <input
                          type="text"
                          name="heroSlide1Tag"
                          value={formData.heroSlide1Tag || ""}
                          onChange={(e) => handleInputChange("heroSlide1Tag", e.target.value)}
                          placeholder="Villas & Living Spaces"
                          className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100"
                        />
                      </div>
                    </div>

                    {/* Slide 2 */}
                    <div className="p-4 rounded-none border border-[#E5E5E0] dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-neutral-800 dark:text-neutral-200">Slide 02</span>
                      </div>
                      <div className="relative aspect-16/9 rounded-none overflow-hidden bg-neutral-200 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800">
                        <img
                          src={formData.heroSlide2Image || "/gallery_1.png"}
                          alt="Slide 2"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-neutral-600 dark:text-neutral-400 mb-1">
                          {isUploading ? "Uploading..." : "Upload Image"}
                        </label>
                        <input type="hidden" name="heroSlide2Image" value={formData.heroSlide2Image || ""} />
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleImageUpload(e, "heroSlide2Image")}
                          className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100"
                          disabled={isUploading}
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-neutral-600 dark:text-neutral-400 mb-1">Slide Title</label>
                        <input
                          type="text"
                          name="heroSlide2Title"
                          value={formData.heroSlide2Title || ""}
                          onChange={(e) => handleInputChange("heroSlide2Title", e.target.value)}
                          placeholder="Automated Zebra & Blackout Drapery"
                          className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-neutral-600 dark:text-neutral-400 mb-1">Slide Tag</label>
                        <input
                          type="text"
                          name="heroSlide2Tag"
                          value={formData.heroSlide2Tag || ""}
                          onChange={(e) => handleInputChange("heroSlide2Tag", e.target.value)}
                          placeholder="Interior Precision"
                          className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100"
                        />
                      </div>
                    </div>

                    {/* Slide 3 */}
                    <div className="p-4 rounded-none border border-[#E5E5E0] dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-neutral-800 dark:text-neutral-200">Slide 03</span>
                      </div>
                      <div className="relative aspect-16/9 rounded-none overflow-hidden bg-neutral-200 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800">
                        <img
                          src={formData.heroSlide3Image || "/gallery_2.png"}
                          alt="Slide 3"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-neutral-600 dark:text-neutral-400 mb-1">
                          {isUploading ? "Uploading..." : "Upload Image"}
                        </label>
                        <input type="hidden" name="heroSlide3Image" value={formData.heroSlide3Image || ""} />
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleImageUpload(e, "heroSlide3Image")}
                          className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100"
                          disabled={isUploading}
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-neutral-600 dark:text-neutral-400 mb-1">Slide Title</label>
                        <input
                          type="text"
                          name="heroSlide3Title"
                          value={formData.heroSlide3Title || ""}
                          onChange={(e) => handleInputChange("heroSlide3Title", e.target.value)}
                          placeholder="Anti-Glare Solar Glass Facades"
                          className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-neutral-600 dark:text-neutral-400 mb-1">Slide Tag</label>
                        <input
                          type="text"
                          name="heroSlide3Tag"
                          value={formData.heroSlide3Tag || ""}
                          onChange={(e) => handleInputChange("heroSlide3Tag", e.target.value)}
                          placeholder="Corporate Offices"
                          className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100"
                        />
                      </div>
                    </div>

                    {/* Slide 4 */}
                    <div className="p-4 rounded-none border border-[#E5E5E0] dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-neutral-800 dark:text-neutral-200">Slide 04</span>
                      </div>
                      <div className="relative aspect-16/9 rounded-none overflow-hidden bg-neutral-200 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800">
                        <img
                          src={formData.heroSlide4Image || "/gallery_3.png"}
                          alt="Slide 4"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-neutral-600 dark:text-neutral-400 mb-1">
                          {isUploading ? "Uploading..." : "Upload Image"}
                        </label>
                        <input type="hidden" name="heroSlide4Image" value={formData.heroSlide4Image || ""} />
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleImageUpload(e, "heroSlide4Image")}
                          className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100"
                          disabled={isUploading}
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-neutral-600 dark:text-neutral-400 mb-1">Slide Title</label>
                        <input
                          type="text"
                          name="heroSlide4Title"
                          value={formData.heroSlide4Title || ""}
                          onChange={(e) => handleInputChange("heroSlide4Title", e.target.value)}
                          placeholder="Motorized Retractable Awnings & Clear PVC"
                          className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-neutral-600 dark:text-neutral-400 mb-1">Slide Tag</label>
                        <input
                          type="text"
                          name="heroSlide4Tag"
                          value={formData.heroSlide4Tag || ""}
                          onChange={(e) => handleInputChange("heroSlide4Tag", e.target.value)}
                          placeholder="Outdoor Terraces"
                          className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 2. PHILOSOPHY QUOTE EDITOR */}
            {activeEditingId === "philosophy" && (
              <div className="space-y-5 animate-in fade-in duration-200">
                <div className="border-b border-neutral-100 dark:border-neutral-800 pb-4">
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
                    Section 02
                  </span>
                  <h2 className="text-lg font-bold text-neutral-900 dark:text-white mt-0.5">Editorial Philosophy & Quote</h2>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                    Update the central brand quote that anchors the SHADEIT editorial identity.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">Badge Title</label>
                  <input
                    type="text"
                    name="quoteBadge"
                    value={formData.quoteBadge || ""}
                    onChange={(e) => handleInputChange("quoteBadge", e.target.value)}
                    className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">Main Quote Statement</label>
                  <textarea
                    name="quoteText"
                    rows={3}
                    value={formData.quoteText || ""}
                    onChange={(e) => handleInputChange("quoteText", e.target.value)}
                    className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">Tags (Separated with bullet •)</label>
                  <input
                    type="text"
                    name="quoteTags"
                    value={formData.quoteTags || ""}
                    onChange={(e) => handleInputChange("quoteTags", e.target.value)}
                    className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                  />
                </div>
              </div>
            )}

            {/* 3. ABOUT SHADEIT STORY */}
            {activeEditingId === "about" && (
              <div className="space-y-5 animate-in fade-in duration-200">
                <div className="border-b border-neutral-100 dark:border-neutral-800 pb-4">
                  <span className="text-xs font-bold uppercase tracking-wider text-blue-700 dark:text-blue-400">
                    Section 03
                  </span>
                  <h2 className="text-lg font-bold text-neutral-900 dark:text-white mt-0.5">About SHADEIT Story</h2>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                    Customize the introduction story, feature points, and accompanying showcase image.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">Section Title</label>
                  <input
                    type="text"
                    name="aboutTitle"
                    value={formData.aboutTitle || ""}
                    onChange={(e) => handleInputChange("aboutTitle", e.target.value)}
                    className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">Story Description</label>
                  <textarea
                    name="aboutDescription"
                    rows={4}
                    value={formData.aboutDescription || ""}
                    onChange={(e) => handleInputChange("aboutDescription", e.target.value)}
                    className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">Feature Point 1</label>
                    <input
                      type="text"
                      name="aboutFeature1"
                      value={formData.aboutFeature1 || ""}
                      onChange={(e) => handleInputChange("aboutFeature1", e.target.value)}
                      className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">Feature Point 2</label>
                    <input
                      type="text"
                      name="aboutFeature2"
                      value={formData.aboutFeature2 || ""}
                      onChange={(e) => handleInputChange("aboutFeature2", e.target.value)}
                      className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">
                    {isUploading ? "Uploading..." : "Upload Image"}
                  </label>
                  <input type="hidden" name="aboutImageUrl" value={formData.aboutImageUrl || ""} />
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleImageUpload(e, "aboutImageUrl")}
                    className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100"
                    disabled={isUploading}
                  />
                </div>
              </div>
            )}

            {/* 4. METRICS & STATS */}
            {activeEditingId === "metrics" && (
              <div className="space-y-5 animate-in fade-in duration-200">
                <div className="border-b border-neutral-100 dark:border-neutral-800 pb-4">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
                    Section 05
                  </span>
                  <h2 className="text-lg font-bold text-neutral-900 dark:text-white mt-0.5">Editorial Metrics Strip</h2>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                    Configure the 3 prominent social proof counters shown across the middle of the homepage.
                  </p>
                </div>

                {/* Stat 1 */}
                <div className="p-4 rounded-none bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 space-y-3">
                  <div className="text-xs font-bold text-neutral-900 dark:text-white">Metric 01: Years in Industry</div>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[11px] font-medium text-neutral-500 dark:text-neutral-400 mb-1">Number</label>
                      <input
                        type="number"
                        name="stat1Value"
                        value={formData.stat1Value || 10}
                        onChange={(e) => handleInputChange("stat1Value", parseInt(e.target.value))}
                        className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none text-xs font-bold text-neutral-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-neutral-500 dark:text-neutral-400 mb-1">Suffix</label>
                      <input
                        type="text"
                        name="stat1Suffix"
                        value={formData.stat1Suffix || "+"}
                        onChange={(e) => handleInputChange("stat1Suffix", e.target.value)}
                        className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none text-xs font-bold text-neutral-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-neutral-500 dark:text-neutral-400 mb-1">Label</label>
                      <input
                        type="text"
                        name="stat1Label"
                        value={formData.stat1Label || "Years Experience"}
                        onChange={(e) => handleInputChange("stat1Label", e.target.value)}
                        className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none text-xs font-bold text-neutral-900 dark:text-white"
                      />
                    </div>
                  </div>
                </div>

                {/* Stat 2 */}
                <div className="p-4 rounded-none bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 space-y-3">
                  <div className="text-xs font-bold text-neutral-900 dark:text-white">Metric 02: Completed Projects</div>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[11px] font-medium text-neutral-500 dark:text-neutral-400 mb-1">Number</label>
                      <input
                        type="number"
                        name="stat2Value"
                        value={formData.stat2Value || 500}
                        onChange={(e) => handleInputChange("stat2Value", parseInt(e.target.value))}
                        className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none text-xs font-bold text-neutral-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-neutral-500 dark:text-neutral-400 mb-1">Suffix</label>
                      <input
                        type="text"
                        name="stat2Suffix"
                        value={formData.stat2Suffix || "+"}
                        onChange={(e) => handleInputChange("stat2Suffix", e.target.value)}
                        className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none text-xs font-bold text-neutral-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-neutral-500 dark:text-neutral-400 mb-1">Label</label>
                      <input
                        type="text"
                        name="stat2Label"
                        value={formData.stat2Label || "Projects Completed"}
                        onChange={(e) => handleInputChange("stat2Label", e.target.value)}
                        className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none text-xs font-bold text-neutral-900 dark:text-white"
                      />
                    </div>
                  </div>
                </div>

                {/* Stat 3 */}
                <div className="p-4 rounded-none bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 space-y-3">
                  <div className="text-xs font-bold text-neutral-900 dark:text-white">Metric 03: Satisfaction</div>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[11px] font-medium text-neutral-500 dark:text-neutral-400 mb-1">Number</label>
                      <input
                        type="number"
                        name="stat3Value"
                        value={formData.stat3Value || 100}
                        onChange={(e) => handleInputChange("stat3Value", parseInt(e.target.value))}
                        className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none text-xs font-bold text-neutral-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-neutral-500 dark:text-neutral-400 mb-1">Suffix</label>
                      <input
                        type="text"
                        name="stat3Suffix"
                        value={formData.stat3Suffix || "%"}
                        onChange={(e) => handleInputChange("stat3Suffix", e.target.value)}
                        className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none text-xs font-bold text-neutral-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-neutral-500 dark:text-neutral-400 mb-1">Label</label>
                      <input
                        type="text"
                        name="stat3Label"
                        value={formData.stat3Label || "Satisfaction Rate"}
                        onChange={(e) => handleInputChange("stat3Label", e.target.value)}
                        className="w-full px-3 py-1.5 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none text-xs font-bold text-neutral-900 dark:text-white"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 5. CLOSING CTA BANNER */}
            {activeEditingId === "cta" && (
              <div className="space-y-5 animate-in fade-in duration-200">
                <div className="border-b border-neutral-100 dark:border-neutral-800 pb-4">
                  <span className="text-xs font-bold uppercase tracking-wider text-red-700 dark:text-red-400">
                    Section 08
                  </span>
                  <h2 className="text-lg font-bold text-neutral-900 dark:text-white mt-0.5">Closing Consultation Banner</h2>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                    Configure the bottom call to action where visitors book site measurements.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">CTA Title</label>
                  <input
                    type="text"
                    name="ctaTitle"
                    value={formData.ctaTitle || ""}
                    onChange={(e) => handleInputChange("ctaTitle", e.target.value)}
                    className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">CTA Subtitle</label>
                  <textarea
                    name="ctaSubtitle"
                    rows={3}
                    value={formData.ctaSubtitle || ""}
                    onChange={(e) => handleInputChange("ctaSubtitle", e.target.value)}
                    className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">Button Text</label>
                    <input
                      type="text"
                      name="ctaButtonText"
                      value={formData.ctaButtonText || ""}
                      onChange={(e) => handleInputChange("ctaButtonText", e.target.value)}
                      className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">Button Link</label>
                    <input
                      type="text"
                      name="ctaButtonLink"
                      value={formData.ctaButtonLink || ""}
                      onChange={(e) => handleInputChange("ctaButtonLink", e.target.value)}
                      className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium font-mono"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Fallback for other sections (Solutions, Transformation, Projects) */}
            {["solutions", "transformation", "projects"].includes(activeEditingId || "") && (
              <div className="space-y-4 py-8 text-center">
                <div className="w-12 h-12 rounded-none bg-amber-50 dark:bg-amber-400/10 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-400/30 flex items-center justify-center mx-auto">
                  {getIcon(activeEditingId || "")}
                </div>
                <h3 className="text-base font-bold text-neutral-900 dark:text-white">
                  {sections.find((s) => s.id === activeEditingId)?.name}
                </h3>
                <p className="text-xs text-neutral-500 dark:text-neutral-400 max-w-md mx-auto">
                  This section automatically pulls products and gallery items from your database catalog.
                </p>
                <div className="pt-2">
                  <Link
                    href={activeEditingId === "projects" ? "/admin/projects" : "/admin/products"}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-none bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-900 dark:hover:bg-neutral-850 text-neutral-800 dark:text-neutral-200 text-xs font-bold transition-colors border border-[#E5E5E0] dark:border-neutral-800"
                  >
                    <span>Manage Catalog Items →</span>
                  </Link>
                </div>
              </div>
            )}

            {/* Bottom Save Bar */}
            <div className="pt-5 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
              <span className="text-xs text-neutral-400 dark:text-neutral-500">
                All changes save directly to SQLite database.
              </span>
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-none bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-xs transition-all active:scale-95 cursor-pointer"
              >
                <Save size={14} />
                <span>Save Section Changes</span>
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Live Device Preview Modal */}
      {showPreviewModal && (
        <div className="fixed inset-0 z-50 bg-neutral-950/80 backdrop-blur-xs flex flex-col items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
          <div className="w-full max-w-5xl bg-neutral-900 dark:bg-black rounded-none border border-neutral-700 dark:border-neutral-800 shadow-2xl flex flex-col overflow-hidden h-[90vh]">
            {/* Modal Header with Device Switcher */}
            <div className="h-14 px-5 bg-neutral-950 dark:bg-black border-b border-neutral-800 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-none bg-red-500" />
                <span className="w-3 h-3 rounded-none bg-yellow-500" />
                <span className="w-3 h-3 rounded-none bg-green-500" />
                <span className="text-xs font-bold text-neutral-400 ml-2">Live Site Device Preview</span>
              </div>

              {/* Viewport switcher */}
              <div className="flex items-center gap-1 bg-neutral-900 dark:bg-neutral-950 p-1 rounded-none border border-neutral-800">
                <button
                  type="button"
                  onClick={() => setPreviewDevice("desktop")}
                  className={`px-3 py-1 rounded-none text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                    previewDevice === "desktop" ? "bg-amber-500 text-slate-950" : "text-neutral-400 hover:text-white"
                  }`}
                >
                  <Monitor size={13} />
                  <span>Desktop</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewDevice("tablet")}
                  className={`px-3 py-1 rounded-none text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                    previewDevice === "tablet" ? "bg-amber-500 text-slate-950" : "text-neutral-400 hover:text-white"
                  }`}
                >
                  <Tablet size={13} />
                  <span>Tablet</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewDevice("mobile")}
                  className={`px-3 py-1 rounded-none text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                    previewDevice === "mobile" ? "bg-amber-500 text-slate-950" : "text-neutral-400 hover:text-white"
                  }`}
                >
                  <Smartphone size={13} />
                  <span>Mobile</span>
                </button>
              </div>

              <button
                type="button"
                onClick={() => setShowPreviewModal(false)}
                className="px-3 py-1.5 rounded-none bg-neutral-800 dark:bg-neutral-900 hover:bg-neutral-700 dark:hover:bg-neutral-800 text-neutral-300 text-xs font-bold cursor-pointer transition-colors border border-neutral-700 dark:border-neutral-800"
              >
                Close Preview
              </button>
            </div>

            {/* Iframe Viewport Frame */}
            <div className="grow bg-neutral-950 dark:bg-black p-4 flex items-center justify-center overflow-auto">
              <div
                className={`h-full bg-slate-950 dark:bg-black rounded-none overflow-hidden border border-neutral-800 shadow-2xl transition-all duration-300 ${
                  previewDevice === "desktop"
                    ? "w-full"
                    : previewDevice === "tablet"
                    ? "w-[768px]"
                    : "w-[375px]"
                }`}
              >
                <iframe
                  src="/"
                  title="SHADEIT Live Website Preview"
                  className="w-full h-full border-none"
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
