'use client';
import { useState, useEffect } from 'react';
import Sidebar from '@/components/Sidebar';
import TopHeader from '@/components/TopHeader';
import DashboardOverview from '@/components/DashboardOverview';
import GroupExtractor from '@/components/GroupExtractor';
import AiBotManager from '@/components/AiBotManager';
import LiveChats from '@/components/LiveChats';
import ContactsManager from '@/components/ContactsManager';
import LiveMessenger from '@/components/LiveMessenger';
import DownloadsHub from '@/components/DownloadsHub';
import LeadExtractor from '@/components/LeadExtractor';
import ConnectQrModal from '@/components/ConnectQrModal';
import ConfigModal from '@/components/ConfigModal';
import { fetchInstances } from '@/lib/evolutionApi';

export default function Home() {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedChatPhone, setSelectedChatPhone] = useState(null);
  const [isQrModalOpen, setIsQrModalOpen] = useState(false);
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState('disconnected');
  const [instanceName] = useState('saas_instance');

  const handleNavigateToChat = (phoneNumber) => {
    setSelectedChatPhone(phoneNumber);
    setActiveTab('chats');
  };

  const checkConnectionStatus = async () => {
    try {
      const data = await fetchInstances();
      if (Array.isArray(data)) {
        const found = data.find(i => i.name === instanceName || i.instanceName === instanceName);
        if (found && (found.connectionStatus === 'open' || found.state === 'open')) {
          setConnectionStatus('connected');
        } else if (found) {
          setConnectionStatus(found.connectionStatus || 'connecting');
        } else {
          setConnectionStatus('disconnected');
        }
      } else {
        setConnectionStatus('disconnected');
      }
    } catch (err) {
      setConnectionStatus('ready');
    }
  };

  useEffect(() => {
    checkConnectionStatus();
    const interval = setInterval(checkConnectionStatus, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex min-h-screen bg-[#080d11]">
      {/* Sidebar */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenQrModal={() => setIsQrModalOpen(true)}
        onOpenConfigModal={() => setIsConfigModalOpen(true)}
        connectionStatus={connectionStatus}
      />

      {/* Main Wrapper */}
      <div className="flex-1 flex flex-col min-w-0">
        <TopHeader
          onOpenQrModal={() => setIsQrModalOpen(true)}
          onOpenConfigModal={() => setIsConfigModalOpen(true)}
          connectionStatus={connectionStatus}
        />

        <main className="p-6 flex-1 max-w-7xl w-full mx-auto">
          {activeTab === 'overview' && (
            <DashboardOverview
              onNavigate={setActiveTab}
              onOpenQrModal={() => setIsQrModalOpen(true)}
            />
          )}

          {activeTab === 'chats' && (
            <LiveChats instanceName={instanceName} initialChatId={selectedChatPhone} />
          )}

          {activeTab === 'leads' && (
            <LeadExtractor onNavigateToChat={handleNavigateToChat} />
          )}

          {activeTab === 'contacts' && (
            <ContactsManager onNavigateToChat={handleNavigateToChat} />
          )}

          {activeTab === 'extractor' && (
            <GroupExtractor instanceName={instanceName} />
          )}

          {activeTab === 'aibot' && (
            <AiBotManager />
          )}

          {activeTab === 'messenger' && (
            <LiveMessenger instanceName={instanceName} />
          )}

          {activeTab === 'downloads' && (
            <DownloadsHub />
          )}
        </main>
      </div>

      {/* Modals */}
      <ConnectQrModal
        isOpen={isQrModalOpen}
        onClose={() => setIsQrModalOpen(false)}
        instanceName={instanceName}
        onConnected={() => setConnectionStatus('connected')}
      />

      <ConfigModal
        isOpen={isConfigModalOpen}
        onClose={() => setIsConfigModalOpen(false)}
        onSave={checkConnectionStatus}
      />
    </div>
  );
}
