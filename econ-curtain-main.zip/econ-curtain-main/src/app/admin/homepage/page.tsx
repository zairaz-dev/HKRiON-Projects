import { HomePageService } from "@/services/homepage.service";
import SectionBuilder from "@/components/admin/cms/SectionBuilder";

export const dynamic = "force-dynamic";

export default async function AdminHomePageCMS() {
  const content = await HomePageService.getContent();

  return (
    <div className="w-full">
      <SectionBuilder initialContent={content} />
    </div>
  );
}

