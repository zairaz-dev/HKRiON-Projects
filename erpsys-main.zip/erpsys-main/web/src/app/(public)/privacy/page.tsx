"use strict";
"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { cmsService, CmsPage } from "@/services/cms-service";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  ShieldCheck,
  Clock,
  ArrowLeft,
  Printer,
  Search,
  Lock,
  Database,
  Key,
  Download,
  Mail,
  Phone,
  Building,
  CheckCircle2,
  AlertCircle,
  Loader2,
  FileText,
} from "lucide-react";

/**
 * Lightweight formatting helper for Markdown content
 */
function MarkdownRenderer({
  content,
  searchFilter = "",
}: {
  content: string;
  searchFilter?: string;
}) {
  const lines = content.split("\n");

  const formatInline = (text: string) => {
    // Highlight search matches
    const parts = text.split(/(\*\*.*?\*\*|`.*?`)/g);
    return parts.map((part, i) => {
      if (part.startsWith("**") && part.endsWith("**")) {
        return (
          <strong key={i} className="font-bold text-foreground">
            {part.slice(2, -2)}
          </strong>
        );
      }
      if (part.startsWith("`") && part.endsWith("`")) {
        return (
          <code
            key={i}
            className="px-1.5 py-0.5 rounded bg-secondary/80 text-primary font-mono text-[11px]"
          >
            {part.slice(1, -1)}
          </code>
        );
      }
      return part;
    });
  };

  const elements: React.ReactNode[] = [];
  let inList = false;
  let listItems: React.ReactNode[] = [];

  const flushList = () => {
    if (inList && listItems.length > 0) {
      elements.push(
        <ul
          key={`list-${elements.length}`}
          className="space-y-2 my-3 pl-5 list-disc text-xs md:text-sm text-muted-foreground"
        >
          {listItems}
        </ul>
      );
      listItems = [];
      inList = false;
    }
  };

  lines.forEach((line, index) => {
    const trimmed = line.trim();

    if (searchFilter && !trimmed.toLowerCase().includes(searchFilter.toLowerCase())) {
      // Don't skip headers or dividers when searching
      if (!trimmed.startsWith("#") && trimmed !== "---") return;
    }

    if (trimmed.startsWith("### ")) {
      flushList();
      elements.push(
        <h3
          key={index}
          className="text-sm md:text-base font-bold text-primary mt-6 mb-2 font-mono flex items-center gap-1.5"
        >
          {formatInline(trimmed.replace("### ", ""))}
        </h3>
      );
    } else if (trimmed.startsWith("## ")) {
      flushList();
      const headingText = trimmed.replace("## ", "");
      const anchorId = headingText
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "");

      elements.push(
        <h2
          id={anchorId}
          key={index}
          className="text-base md:text-lg font-bold text-foreground mt-8 mb-3 border-b border-border/50 pb-2 font-mono scroll-mt-24 flex items-center gap-2"
        >
          {formatInline(headingText)}
        </h2>
      );
    } else if (trimmed.startsWith("# ")) {
      flushList();
      elements.push(
        <h1
          key={index}
          className="text-xl md:text-3xl font-extrabold text-foreground mt-4 mb-4 tracking-tight"
        >
          {formatInline(trimmed.replace("# ", ""))}
        </h1>
      );
    } else if (trimmed === "---" || trimmed === "***") {
      flushList();
      elements.push(<hr key={index} className="my-6 border-border/50" />);
    } else if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
      inList = true;
      listItems.push(
        <li key={index} className="leading-relaxed">
          {formatInline(trimmed.slice(2))}
        </li>
      );
    } else if (trimmed.length > 0) {
      flushList();
      elements.push(
        <p
          key={index}
          className="text-xs md:text-sm text-muted-foreground/90 leading-relaxed my-2.5"
        >
          {formatInline(trimmed)}
        </p>
      );
    } else {
      flushList();
    }
  });

  flushList();

  return <div className="space-y-1">{elements}</div>;
}

export default function PrivacyPolicyPage() {
  const [page, setPage] = useState<CmsPage | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  const fallbackPrivacyContent = `# Privacy Policy & Data Protection Standards

**Effective Date:** August 31, 2026  
**Operating Entity:** HKRION SYSTEMS (PVT) LTD ("HKRION", "We", "Our", "Us")  
**Product Scope:** HKRION ERP Multi-Tenant SaaS Platform  
**Compliance Scope:** Sri Lanka Personal Data Protection Act (PDPA) & Global Data Privacy Benchmarks  

---

## 1. Introduction & Organizational Commitment
At **HKRION SYSTEMS (PVT) LTD**, we recognize the paramount importance of privacy, trust, and confidentiality for businesses running critical daily operations on our cloud platform. This Privacy Policy details the exact types of data we collect, our strict multi-tenant data isolation protocols, enterprise security encryption benchmarks, and your unwavering rights as a business owner (Tenant).

By accessing or using **HKRION ERP**, you agree to the data collection and governance practices outlined in this document.

---

## 2. Information We Collect
We collect only the essential information necessary to provide ultra-fast, secure, and uninterrupted ERP services across Point of Sale, Inventory, and Accounting:

### A. Account & Business Administrator Profile
- **Tenant Administrator:** Full legal name, business email address, direct contact number, and encrypted password credentials (hashed with bcrypt).
- **Business Profile:** Registered trade name, business registration number (BR No), physical store/warehouse addresses, tax identification numbers (VAT/GST), and official store logos.

### B. Operational Business & Transactional Data
- **Point of Sale & Invoicing:** Transaction amounts, receipt numbers, product descriptions, tax line items, discount records, and cashier user IDs.
- **Inventory & Serial Tracking:** SKU quantities, product categories, unit purchase costs, selling prices, barcode mappings, and IMEI / Serial numbers with warranty timestamps.
- **Contacts & Ledgers:** Customer directory (names, phone numbers, credit limits, outstanding balances) and supplier profiles (payment histories, purchase orders).

### C. Subscription, Billing & Proof of Payment
- **Subscription Records:** Active plan tier, billing frequency (Monthly / Yearly), quota consumption metrics, and invoice receipts.
- **Payment Verification:** Bank deposit proof slips uploaded by tenants and PayHere.lk gateway transaction references.  
*(Note: We NEVER process, access, or store raw credit/debit card numbers or CVV codes on our servers. All online card transactions are processed securely by PCI-DSS compliant PayHere.lk).*

### D. System Security & Audit Logs
- System access timestamps, browser user-agent headers, and IP addresses to maintain security audit trails and prevent unauthorized account access.

---

## 3. Strict Multi-Tenant Data Isolation & Security Architecture
HKRION ERP is built with enterprise-grade multi-tenant architecture designed to guarantee absolute data segregation:

- 🛡️ **Row-Level Tenant Isolation:** Every database entity is strictly partitioned and mapped to a unique \`businessId\` (Tenant ID). Cross-tenant queries are strictly rejected by the server runtime.
- 🔐 **End-to-End Encryption:** All network traffic between your devices and our cloud servers is encrypted using **TLS 1.3 / SSL 256-bit certificates**.
- 🔑 **Cryptographic Password Protection:** Passwords are never stored in plaintext. We utilize one-way salted hashing algorithms.
- 💾 **Redundant Automated Backups:** Your operational database is automatically backed up to encrypted, geographically redundant storage to protect against disaster recovery scenarios.

---

## 4. How We Use & Process Your Information
Your information is strictly utilized to deliver and improve our platform functionality:
- To execute lightning-fast Point of Sale checkouts, calculate automated taxes, and print receipt vouchers.
- To dispatch essential transactional notifications, including SMS verification codes, invoice payment receipts, and subscription expiry alerts.
- To provide dedicated technical support and troubleshoot operational inquiries upon tenant request.
- To detect, prevent, and mitigate fraud, security incidents, and unauthorized logins.

---

## 5. Absolute "No-Sale" Guarantee & Third-Party Service Providers
**We maintain a strict, non-negotiable policy: We NEVER sell, rent, monetize, or trade your business data or customer records to advertisers, data brokers, or third parties.**

We share minimal necessary data only with verified infrastructure providers:
- **PayHere.lk:** Licensed by the Central Bank of Sri Lanka for processing online subscription payments.
- **Telecom & SMS Gateways (Dialog, Mobitel, Twilio):** For delivering one-time passcodes (OTP) and automated customer receipts.

---

## 6. Data Ownership & Tenant Rights (Right to Export & Delete)
- **100% Data Ownership:** You remain the sole and exclusive owner of all business records, customer contact lists, and inventory databases entered into HKRION ERP.
- **Data Portability:** You can export your full product catalog, stock valuations, customer balances, and financial reports to Excel (XLSX) or PDF format at any time.
- **Right to be Forgotten (Account Deletion):** Upon subscription termination, you may request permanent and complete purging of your tenant database from our active servers.

---

## 7. Cookies & Session Storage
We do not use tracking or advertising cookies. We utilize secure browser Local Storage solely for maintaining your encrypted JWT authentication session token (\`hkr_token\`).

---

## 8. Privacy Inquiries & Compliance Contact
If you have any questions, compliance verification requests, or data privacy inquiries, please contact our Data Protection and Compliance Team:

- 📧 **Direct Privacy Email:** privacy@hkrion.com
- 🛠️ **Customer Care Hotline:** +94 77 123 4567
- 🏢 **Company:** HKRION SYSTEMS (PVT) LTD
- 📍 **Headquarters:** Colombo, Sri Lanka`;

  useEffect(() => {
    loadPrivacyContent();
  }, []);

  const loadPrivacyContent = async () => {
    setIsLoading(true);
    try {
      const data = await cmsService.getPublicPage("privacy");
      if (data) setPage(data);
    } catch {
      // Use fallback
    } finally {
      setIsLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const contentToRender = page?.content || fallbackPrivacyContent;

  const quickNav = [
    { title: "1. Introduction & Scope", id: "1-introduction-organizational-commitment" },
    { title: "2. Information We Collect", id: "2-information-we-collect" },
    { title: "3. Multi-Tenant Isolation & Security", id: "3-strict-multi-tenant-data-isolation-security-architecture" },
    { title: "4. How We Use Your Data", id: "4-how-we-use-process-your-information" },
    { title: "5. No-Sale Guarantee & Third-Parties", id: "5-absolute-no-sale-guarantee-third-party-service-providers" },
    { title: "6. 100% Data Ownership & Rights", id: "6-data-ownership-tenant-rights-right-to-export-delete" },
    { title: "7. Cookies & Session Storage", id: "7-cookies-session-storage" },
    { title: "8. Compliance Contact Details", id: "8-privacy-inquiries-compliance-contact" },
  ];

  return (
    <div className="bg-transparent text-foreground flex flex-col justify-between selection:bg-emerald-500/30 selection:text-emerald-400">
      {/* Main Container */}
      <main className="max-w-7xl w-full mx-auto px-4 sm:px-6 py-4 relative z-10">
        {/* Breadcrumb / Top Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-border/60">
          <div className="flex items-center gap-2">
            <Link
              href="/"
              className="text-xs font-mono font-bold text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"
            >
              <ArrowLeft className="w-4 h-4 text-primary" /> Home
            </Link>
            <span className="text-muted-foreground/40 font-mono">/</span>
            <span className="text-xs font-mono text-primary font-bold">Privacy Policy</span>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrint}
              className="text-xs h-8 gap-1.5 font-mono border-border"
            >
              <Printer className="w-3.5 h-3.5 text-primary" /> Print / Save PDF
            </Button>
          </div>
        </div>

        {/* Hero Banner Card */}
        <div className="pt-8 pb-6">
          <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border border-primary/20 rounded-sm p-6 md:p-8 space-y-3 relative overflow-hidden">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 text-[11px] font-mono text-primary font-bold bg-primary/15 border border-primary/30 px-3 py-1 rounded-sm">
                <ShieldCheck className="w-3.5 h-3.5" /> Official Verified Legal Policy
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] font-mono text-muted-foreground bg-secondary/80 px-2.5 py-1 rounded-sm">
                <Lock className="w-3 h-3 text-primary" /> Multi-Tenant Row Isolation
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] font-mono text-primary bg-primary/10 border border-primary/20 px-2.5 py-1 rounded-sm">
                🇱🇰 Sri Lanka PDPA Compliant
              </span>
            </div>

            <h1 className="text-2xl md:text-4xl font-extrabold text-foreground tracking-tight">
              Privacy Policy & Data Protection Standards
            </h1>
            <p className="text-xs md:text-sm text-muted-foreground max-w-3xl leading-relaxed">
              We are committed to absolute confidentiality, zero data selling, and enterprise-grade multi-tenant database isolation for every retail and enterprise business running on HKRION Cloud ERP.
            </p>

            <div className="flex flex-wrap items-center gap-4 text-[11px] font-mono text-muted-foreground/80 pt-2">
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-400" /> Effective Date: August 31, 2026
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Building className="w-3.5 h-3.5 text-primary" /> Operating Entity: HKRION SYSTEMS (PVT) LTD
              </span>
            </div>
          </div>
        </div>

        {/* Layout: Sticky Quick Nav (Left) + Content (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pt-4 items-start">
          {/* Left Column: Quick-Jump Table of Contents & Keyword Search */}
          <aside className="lg:col-span-4 lg:sticky lg:top-24 space-y-4">
            {/* Search Input */}
            <Card className="bg-card/40 backdrop-blur-md border-border/60 rounded-sm">
              <CardContent className="p-4 space-y-2">
                <label className="text-[10px] font-mono font-bold uppercase text-muted-foreground">
                  Search in Policy
                </label>
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-muted-foreground" />
                  <Input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="e.g. PayHere, Tenant, Backup..."
                    className="pl-8 h-8 text-xs font-mono rounded-sm"
                  />
                </div>
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery("")}
                    className="text-[10px] text-primary hover:underline font-mono"
                  >
                    Clear Filter
                  </button>
                )}
              </CardContent>
            </Card>

            {/* Quick Jump Links */}
            <Card className="bg-card/40 backdrop-blur-md border-border/60 rounded-sm">
              <CardContent className="p-5 space-y-3">
                <div className="text-xs font-bold font-mono text-foreground uppercase tracking-wider flex items-center gap-1.5 border-b border-border/50 pb-2">
                  <FileText className="w-3.5 h-3.5 text-primary" /> Table of Contents
                </div>

                <nav className="space-y-1 text-xs font-mono">
                  {quickNav.map((item, idx) => (
                    <a
                      key={idx}
                      href={`#${item.id}`}
                      className="block py-1.5 px-2 rounded-sm hover:bg-secondary/60 text-muted-foreground hover:text-primary transition-colors text-[11px]"
                    >
                      {item.title}
                    </a>
                  ))}
                </nav>
              </CardContent>
            </Card>

            {/* Trust Badges Widget */}
            <Card className="bg-card/30 border-border/50 p-4 space-y-2.5 text-xs rounded-sm">
              <div className="text-[10px] font-mono font-bold uppercase text-muted-foreground">
                Security Commitments
              </div>
              <div className="space-y-2 text-[11px] text-muted-foreground">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0" />
                  <span>256-bit TLS 1.3 / SSL Encryption</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0" />
                  <span>100% Tenant-Isolated Databases</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0" />
                  <span>Zero Data Selling / Commercialization</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0" />
                  <span>Daily Redundant Cloud Backups</span>
                </div>
              </div>
            </Card>
          </aside>

          {/* Right Column: Policy Document Body */}
          <section className="lg:col-span-8">
            <Card className="bg-card/40 backdrop-blur-md border-border/60 shadow-xl overflow-hidden rounded-sm">
              <CardContent className="p-6 md:p-10">
                {isLoading ? (
                  <div className="p-12 text-center text-muted-foreground">
                    <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-primary" />
                    <p className="text-xs font-mono">Loading verified privacy standards...</p>
                  </div>
                ) : (
                  <div className="prose prose-invert max-w-none text-xs md:text-sm leading-relaxed text-foreground/90 font-sans">
                    <MarkdownRenderer
                      content={contentToRender}
                      searchFilter={searchQuery}
                    />
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Support / Inquiries Callout */}
            <div className="mt-6 p-6 rounded-sm bg-secondary/30 border border-border/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h4 className="text-sm font-bold text-foreground">Have Questions Regarding Your Data?</h4>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Our Data Protection Officer and compliance team is available 24/7.
                </p>
              </div>
              <a href="mailto:privacy@hkrion.com">
                <Button size="sm" className="text-xs h-8 font-bold font-mono gap-1.5 rounded-sm">
                  <Mail className="w-3.5 h-3.5" /> Contact Privacy Team
                </Button>
              </a>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
