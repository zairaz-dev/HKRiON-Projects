import { IsArray, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export interface ChatMessageItem {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export class ChatPromptDto {
  @IsArray()
  @IsNotEmpty()
  messages: ChatMessageItem[];

  @IsOptional()
  @IsString()
  branchId?: string;
}
