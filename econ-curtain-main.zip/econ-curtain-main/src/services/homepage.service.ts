import { db } from "@/core/db/client";

export interface HomePageContentData {
  id: string;
  // Hero Section
  heroStatusBadge: string;
  heroMainBadge: string;
  heroTitlePrefix: string;
  heroTitleHighlight: string;
  heroTitleSuffix: string;
  heroSubtitle: string;
  heroFeaturePills: string;
  heroCtaPrimaryText: string;
  heroCtaPrimaryLink: string;
  heroCtaSecondaryText: string;
  heroCtaSecondaryLink: string;

  // Hero Slides
  heroSlide1Image: string;
  heroSlide1Title: string;
  heroSlide1Tag: string;
  heroSlide2Image: string;
  heroSlide2Title: string;
  heroSlide2Tag: string;
  heroSlide3Image: string;
  heroSlide3Title: string;
  heroSlide3Tag: string;
  heroSlide4Image: string;
  heroSlide4Title: string;
  heroSlide4Tag: string;

  // Editorial Philosophy Section
  quoteBadge: string;
  quoteText: string;
  quoteHighlight: string;
  quoteTags: string;

  // About Section
  aboutBadge: string;
  aboutTitle: string;
  aboutDescription: string;
  aboutImageUrl: string;
  aboutProjectTitle: string;
  aboutFeature1: string;
  aboutFeature2: string;

  // Metrics & Stats
  stat1Value: number;
  stat1Suffix: string;
  stat1Label: string;
  stat1Sub: string;

  stat2Value: number;
  stat2Suffix: string;
  stat2Label: string;
  stat2Sub: string;

  stat3Value: number;
  stat3Suffix: string;
  stat3Label: string;
  stat3Sub: string;

  // Final CTA Section
  ctaBadge: string;
  ctaTitle: string;
  ctaSubtitle: string;
  ctaButtonText: string;
  ctaButtonLink: string;

  updatedAt?: Date;
}

export const defaultHomePageContent: HomePageContentData = {
  id: "home_default",
  // Hero Section
  heroStatusBadge: "Certified Technicians Active",
  heroMainBadge: "100% Custom Shading",
  heroTitlePrefix: "Transform Your Space with",
  heroTitleHighlight: "Premium Window & Shade",
  heroTitleSuffix: "Solutions",
  heroSubtitle: "Custom blinds, motorized drapery, architectural awnings, shade sails, and monsoon PVC screens tailored for luxury homes and high-end businesses.",
  heroFeaturePills: "🪟 Zebra & Roller Blinds, 🛋 Acoustic Blackout Drapery, ☀ Retractable Patio Awnings, 🏭 Crystal Clear PVC Screens",
  heroCtaPrimaryText: "Get Free Quote",
  heroCtaPrimaryLink: "/contact",
  heroCtaSecondaryText: "Explore Solutions",
  heroCtaSecondaryLink: "#solutions",

  // Hero Slides
  heroSlide1Image: "/hero_banner_1786018413238.png",
  heroSlide1Title: "Luxury Residential Shading",
  heroSlide1Tag: "Villas & Living Spaces",
  heroSlide2Image: "/gallery_1.png",
  heroSlide2Title: "Automated Zebra & Blackout Drapery",
  heroSlide2Tag: "Interior Precision",
  heroSlide3Image: "/gallery_2.png",
  heroSlide3Title: "Anti-Glare Solar Glass Facades",
  heroSlide3Tag: "Corporate Offices",
  heroSlide4Image: "/gallery_3.png",
  heroSlide4Title: "Motorized Retractable Awnings & Clear PVC",
  heroSlide4Tag: "Outdoor Terraces",

  // Editorial Philosophy Section
  quoteBadge: "Editorial Philosophy",
  quoteText: "We create shade, comfort and character for every space.",
  quoteHighlight: "character",
  quoteTags: "Residential • Commercial • Outdoor",

  // About Section
  aboutBadge: "ABOUT SHADEIT",
  aboutTitle: "Designed for the way you live and work.",
  aboutDescription: "SHADEIT BLINDS delivers customized window coverings and architectural shade structures. From custom automated interior blinds to heavy-duty canopy awnings, we elevate residential and commercial properties with unmatched precision.",
  aboutImageUrl: "/gallery_1.png",
  aboutProjectTitle: "Luxury Villa Automated Blackout & Sheer Combination",
  aboutFeature1: "Custom Tailored to Fit",
  aboutFeature2: "Professional Installation",

  // Metrics & Stats
  stat1Value: 10,
  stat1Suffix: "+",
  stat1Label: "Years Experience",
  stat1Sub: "Delivering excellence since day one",

  stat2Value: 500,
  stat2Suffix: "+",
  stat2Label: "Completed Projects",
  stat2Sub: "Homes, villas, offices & hotels",

  stat3Value: 100,
  stat3Suffix: "%",
  stat3Label: "Satisfaction Guaranteed",
  stat3Sub: "Professional Certified Fitting",

  // Final CTA Section
  ctaBadge: "Elevate Your Living & Working Spaces",
  ctaTitle: "Ready to Transform Your Space?",
  ctaSubtitle: "Book a free site measurement and personalized design consultation with our shading experts today. Let's create something beautiful together.",
  ctaButtonText: "Get Free Consultation",
  ctaButtonLink: "/contact",
};

export class HomePageService {
  /**
   * Retrieves the home page content from SQLite or creates default if not exists
   */
  static async getContent(): Promise<HomePageContentData> {
    try {
      const content = await db.homePageContent.findUnique({
        where: { id: "home_default" },
      });

      if (!content) {
        return await db.homePageContent.create({
          data: {
            ...defaultHomePageContent,
          },
        });
      }

      return content;
    } catch (e) {
      console.error("Failed to load home page content from DB, returning defaults:", e);
      return defaultHomePageContent;
    }
  }

  /**
   * Updates home page content
   */
  static async updateContent(data: Partial<HomePageContentData>): Promise<HomePageContentData> {
    try {
      const updated = await db.homePageContent.upsert({
        where: { id: "home_default" },
        update: {
          ...data,
          updatedAt: new Date(),
        },
        create: {
          ...defaultHomePageContent,
          ...data,
        },
      });

      return updated;
    } catch (e) {
      console.error("Failed to update home page content:", e);
      throw e;
    }
  }
}
