import { NextResponse } from 'next/server';
import { getChats, addMessageToConversation, markAsRead, toggleAiForChat } from '@/lib/chatStore';

const EVOLUTION_API_URL = process.env.EVOLUTION_API_URL || 'http://localhost:8080';
const EVOLUTION_API_KEY = process.env.EVOLUTION_API_KEY || '429683C4C977415CAAFCCE10F7D57E11';

// GET all chats
export async function GET() {
  try {
    const chats = getChats();
    const chatList = Object.values(chats).sort((a, b) => {
      return new Date(b.lastTimestamp || 0) - new Date(a.lastTimestamp || 0);
    });

    return NextResponse.json({
      success: true,
      chats: chatList,
    });
  } catch (err) {
    console.error('[API /api/chats GET Error]:', err);
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

// POST send new human message or mark chat as read
export async function POST(req) {
  try {
    const body = await req.json();
    const { action, recipient, text, instanceName = 'saas_instance', aiEnabled } = body;

    // Action: Mark chat as read
    if (action === 'mark_read' && recipient) {
      markAsRead(recipient);
      return NextResponse.json({ success: true, message: 'Marked as read' });
    }

    // Action: Toggle AI for specific conversation
    if (action === 'toggle_ai' && recipient) {
      const updatedAiState = toggleAiForChat(recipient, aiEnabled);
      return NextResponse.json({ success: true, aiEnabled: updatedAiState });
    }

    // Action: Send Message
    if (!recipient || !text || !text.trim()) {
      return NextResponse.json({ success: false, error: 'Recipient and text are required' }, { status: 400 });
    }

    const cleanRecipient = recipient.replace(/[^0-9]/g, '');

    // 1. Send text message via Evolution API
    const sendRes = await fetch(`${EVOLUTION_API_URL}/message/sendText/${instanceName}`, {
      method: 'POST',
      headers: {
        'apikey': EVOLUTION_API_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        number: cleanRecipient,
        text: text.trim(),
      }),
    });

    if (!sendRes.ok) {
      const errBody = await sendRes.text();
      throw new Error(`Evolution API error (${sendRes.status}): ${errBody}`);
    }

    // 2. Add sent message to chat store
    const updatedConversation = addMessageToConversation({
      senderNumber: cleanRecipient,
      text: text.trim(),
      fromMe: true,
      isAi: false,
      status: 'sent',
    });

    return NextResponse.json({
      success: true,
      conversation: updatedConversation,
    });
  } catch (err) {
    console.error('[API /api/chats POST Error]:', err);
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
