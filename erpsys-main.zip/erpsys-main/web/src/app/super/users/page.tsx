"use strict";
"use client";

import React, { useEffect, useState, Suspense } from "react";
import {
  Users,
  UserPlus,
  Edit2,
  Trash2,
  Mail,
  Key,
  X,
  Loader2,
  CheckCircle2,
  ShieldAlert,
  Building2,
  UserCheck,
  Activity
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { authService } from "@/services/auth-service";
import { LoadingSession } from "@/components/ui/loading-session";
import { DataTable, ColumnDef, ActionsDropdown } from "@/components/ui/table";
import { getFullAssetUrl } from "@/lib/utils";

interface BusinessItem {
  id: string;
  name: string;
  industry: string;
}

function SuperUserManagementContent() {
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // States
  const [users, setUsers] = useState<any[]>([]);
  const [businesses, setBusinesses] = useState<BusinessItem[]>([]);
  const [roles, setRoles] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [actionLoading, setActionLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>("");
  const [successMessage, setSuccessMessage] = useState<string>("");

  // Modals state
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [modalMode, setModalMode] = useState<"create" | "edit">("create");
  const [editingUserId, setEditingUserId] = useState<string>("");

  // Form states
  const [formName, setFormName] = useState<string>("");
  const [formEmail, setFormEmail] = useState<string>("");
  const [formPassword, setFormPassword] = useState<string>("");
  const [formRole, setFormRole] = useState<string>("");
  const [formBusinessId, setFormBusinessId] = useState<string>("global");

  // Delete state
  const [isDeleteOpen, setIsDeleteOpen] = useState<boolean>(false);
  const [userToDelete, setUserToDelete] = useState<any | null>(null);

  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed || (user && (user.role as string) !== "super-admin")) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
      return;
    }

    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    setLoading(true);
    setError("");
    try {
      const [usersData, businessesData, rolesData] = await Promise.all([
        authService.getUsers(),
        authService.getBusinesses(),
        authService.getRoles(),
      ]);
      setUsers(usersData);
      setBusinesses(businessesData);
      setRoles(rolesData);
    } catch (err: any) {
      setError(err.message || "Failed to load management details.");
    } finally {
      setLoading(false);
    }
  };

  // Auto-dismiss notifications
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 5000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  const handleOpenCreateModal = () => {
    setModalMode("create");
    setEditingUserId("");
    setFormName("");
    setFormEmail("");
    setFormPassword("");
    setFormRole(roles[0]?.role || "admin");
    setFormBusinessId("global");
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (user: any) => {
    setModalMode("edit");
    setEditingUserId(user.id);
    setFormName(user.name);
    setFormEmail(user.email);
    setFormPassword("");
    setFormRole(user.role);
    setFormBusinessId(user.businessId || "global");
    setIsModalOpen(true);
  };

  const handleOpenDeleteConfirm = (user: any) => {
    setUserToDelete(user);
    setIsDeleteOpen(true);
  };

  const handleSaveUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!formName.trim() || !formEmail.trim() || !formRole) {
      setError("Please fill in all required fields.");
      return;
    }

    if (modalMode === "create" && !formPassword) {
      setError("Password is required for new users.");
      return;
    }

    setActionLoading(true);
    try {
      const bId = formBusinessId === "global" ? undefined : formBusinessId;
      if (modalMode === "create") {
        await authService.createUser({
          name: formName,
          email: formEmail,
          role: formRole,
          password: formPassword,
          businessId: bId,
          createdById: currentUser?.id || undefined,
        });
        setSuccessMessage(`User "${formName}" created successfully!`);
      } else {
        await authService.updateUser(editingUserId, {
          name: formName,
          email: formEmail,
          role: formRole,
          password: formPassword || undefined,
          businessId: bId,
          updatedById: currentUser?.id || undefined,
        });
        setSuccessMessage(`User "${formName}" updated successfully!`);
      }

      setIsModalOpen(false);
      const updatedUsers = await authService.getUsers();
      setUsers(updatedUsers);
    } catch (err: any) {
      setError(err.message || "Failed to save user. Please try again.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteUser = async () => {
    if (!userToDelete) return;
    setActionLoading(true);
    setError("");
    try {
      await authService.deleteUser(userToDelete.id);
      setSuccessMessage(`User "${userToDelete.name}" deleted successfully.`);
      setIsDeleteOpen(false);
      setUserToDelete(null);
      const updatedUsers = await authService.getUsers();
      setUsers(updatedUsers);
    } catch (err: any) {
      setError(err.message || "Failed to delete user. Please try again.");
    } finally {
      setActionLoading(false);
    }
  };

  const columns: ColumnDef<any>[] = [
    {
      header: "User Details",
      searchable: true,
      render: (user) => (
        <div className="flex items-center gap-3">
          {user.avatar ? (
            <img
              src={getFullAssetUrl(user.avatar) || user.avatar}
              alt={user.name}
              className="w-8 h-8 rounded-sm object-cover border border-primary/20 shrink-0"
              onError={(e) => {
                (e.currentTarget as HTMLElement).style.display = "none";
              }}
            />
          ) : (
            <div className="w-8 h-8 rounded-sm bg-primary/10 border border-primary/20 flex items-center justify-center text-primary font-bold uppercase text-xs">
              {user.name.substring(0, 2)}
            </div>
          )}
          <div>
            <h4 className="font-semibold text-foreground">{user.name}</h4>
            <p className="text-[10px] text-muted-foreground font-mono mt-0.5">{user.email}</p>
          </div>
        </div>
      ),
    },
    {
      header: "Business / Company",
      render: (user) => {
        const mapped = businesses.find((b) => b.id === user.businessId);
        return (
          <div className="flex items-center gap-1.5 text-xs text-foreground/80 font-medium">
            <Building2 className="h-3.5 w-3.5 text-muted-foreground/60" />
            {mapped ? mapped.name : <span className="text-primary font-semibold">Global / System</span>}
          </div>
        );
      },
    },
    {
      header: "Role",
      render: (user) => (
        <span
          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-sm text-[10px] font-semibold font-mono border ${
            user.role === "super-admin"
              ? "bg-rose-500/10 text-rose-500 border-rose-500/20"
              : user.role === "admin"
              ? "bg-primary/10 text-primary border-primary/20"
              : "bg-secondary text-secondary-foreground border-border"
          }`}
        >
          {user.role.toUpperCase()}
        </span>
      ),
    },
    {
      header: "Status",
      render: (user) => {
        const active = user.isActive !== false;
        return (
          <span
            className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-sm text-[10px] font-semibold font-mono border ${
              active
                ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                : "bg-rose-500/10 text-rose-400 border-rose-500/20"
            }`}
          >
            <span className={`w-1.5 h-1.5 rounded-full ${active ? "bg-emerald-400 animate-pulse" : "bg-rose-400"}`} />
            {active ? "Active" : "Deactivated"}
          </span>
        );
      },
    },
    {
      header: "Created Date",
      render: (user) => (
        <span className="text-xs font-mono text-muted-foreground">
          {new Date(user.createdAt).toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric",
          })}
        </span>
      ),
    },
    {
      header: "Actions",
      render: (user) => (
        <ActionsDropdown
          actions={[
            {
              label: "Edit User",
              onClick: () => handleOpenEditModal(user),
              icon: <Edit2 className="h-3.5 w-3.5" />,
            },
            {
              label: "Delete User",
              onClick: () => handleOpenDeleteConfirm(user),
              icon: <Trash2 className="h-3.5 w-3.5" />,
              variant: "destructive" as const,
            },
          ]}
        />
      ),
    },
  ];

  if (isAuthenticated === null) {
    return <LoadingSession />;
  }

  if (isAuthenticated === false || (currentUser && (currentUser.role as string) !== "super-admin")) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-4 text-center p-4">
        <ShieldAlert className="w-12 h-12 text-red-500 animate-bounce" />
        <h2 className="text-xl font-bold text-white">Access Denied</h2>
        <p className="text-sm text-slate-400 max-w-sm">
          You do not have permission to view the User Management portal. Redirecting to login...
        </p>
      </div>
    );
  }

  // Calculate Metrics
  const totalUsers = users.length;
  const superAdminCount = users.filter((u) => u.role === "super-admin").length;
  const adminCount = users.filter((u) => u.role === "admin").length;
  const cashierCount = users.filter((u) => u.role === "cashier" || u.role === "staff").length;

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      {/* Sidebar */}
      <Sidebar activePath="/super/users" />

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        {/* Glowing Background Orbs */}
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-emerald-500/5 blur-[120px] pointer-events-none z-0" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[550px] h-[550px] rounded-full bg-teal-500/5 blur-[130px] pointer-events-none z-0" />

        {/* Navbar */}
        <Navbar title="Super Admin User Registry" />

        {/* Scrollable Main Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 relative z-10">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <Users className="h-7 w-7 text-primary" /> User Management
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Manage system administrators, cashier staffs, and business owners globally.
              </p>
            </div>
          </div>

          {/* Banner Notifications */}
          {successMessage && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 animate-in fade-in slide-in-from-top-4 duration-300">
              <CheckCircle2 className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive animate-in fade-in slide-in-from-top-4 duration-300">
              <ShieldAlert className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          {/* Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="glass border-slate-800/80">
              <CardContent className="p-6 flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-semibold text-slate-400 font-mono uppercase tracking-wider">Total System Users</p>
                  <h3 className="text-2xl font-bold text-white tracking-tight mt-1">{totalUsers}</h3>
                </div>
                <div className="p-2.5 rounded-sm bg-primary/10 text-primary">
                  <Users className="w-5 h-5" />
                </div>
              </CardContent>
            </Card>

            <Card className="glass border-slate-800/80">
              <CardContent className="p-6 flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-semibold text-slate-400 font-mono uppercase tracking-wider">Super Admins</p>
                  <h3 className="text-2xl font-bold text-rose-500 tracking-tight mt-1">{superAdminCount}</h3>
                </div>
                <div className="p-2.5 rounded-sm bg-rose-600/10 text-rose-550">
                  <UserCheck className="w-5 h-5" />
                </div>
              </CardContent>
            </Card>

            <Card className="glass border-slate-800/80">
              <CardContent className="p-6 flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-semibold text-slate-400 font-mono uppercase tracking-wider">Business Admins</p>
                  <h3 className="text-2xl font-bold text-primary tracking-tight mt-1">{adminCount}</h3>
                </div>
                <div className="p-2.5 rounded-sm bg-primary/10 text-primary">
                  <Activity className="w-5 h-5" />
                </div>
              </CardContent>
            </Card>

            <Card className="glass border-slate-800/80">
              <CardContent className="p-6 flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-semibold text-slate-400 font-mono uppercase tracking-wider">Cashiers & Staffs</p>
                  <h3 className="text-2xl font-bold text-muted-foreground tracking-tight mt-1">{cashierCount}</h3>
                </div>
                <div className="p-2.5 rounded-sm bg-secondary text-secondary-foreground">
                  <Building2 className="w-5 h-5" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Table Card */}
          {loading ? (
            <div className="flex h-64 items-center justify-center">
              <div className="text-center space-y-2">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
                <span className="text-sm text-muted-foreground block">Loading system users...</span>
              </div>
            </div>
          ) : (
            <DataTable
              data={users}
              columns={columns}
              searchKeys={["name", "email", "role"]}
              searchPlaceholder="Search users by name, email..."
              reportTitle="Super Admin User Report"
              actionButton={{
                label: "Add System User",
                onClick: handleOpenCreateModal,
                icon: <UserPlus className="h-4 w-4" />
              }}
            />
          )}
        </main>
      </div>

      {/* Create / Edit User Modal Dialog */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-background/80 backdrop-blur-sm" onClick={() => setIsModalOpen(false)} />
          <div className="bg-card border border-border w-full max-w-md rounded-xl shadow-2xl p-6 relative z-10 animate-in fade-in zoom-in-95 duration-150">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 text-muted-foreground hover:text-foreground transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-bold text-foreground mb-4">
              {modalMode === "create" ? "Add System User" : "Edit User Profile"}
            </h2>

            <form onSubmit={handleSaveUser} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground">Full Name</label>
                <Input
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. John Doe"
                  required
                  className="h-10 text-xs bg-background/50 border-border"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5 text-muted-foreground/60" /> Email Address
                </label>
                <Input
                  type="email"
                  value={formEmail}
                  onChange={(e) => setFormEmail(e.target.value)}
                  placeholder="e.g. john@example.com"
                  required
                  className="h-10 text-xs bg-background/50 border-border"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground flex items-center gap-1">
                  <Key className="w-3.5 h-3.5 text-muted-foreground/60" /> Password 
                  {modalMode === "edit" && <span className="text-[10px] text-muted-foreground/65 font-normal ml-1">(Leave blank to keep current)</span>}
                </label>
                <Input
                  type="password"
                  value={formPassword}
                  onChange={(e) => setFormPassword(e.target.value)}
                  placeholder="••••••••"
                  required={modalMode === "create"}
                  className="h-10 text-xs bg-background/50 border-border"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground">System Role</label>
                <Select
                  value={formRole}
                  onValueChange={setFormRole}
                  className="h-10 text-xs"
                >
                  {roles.map((r: any) => (
                    <option key={r.id} value={r.role}>{r.role.toUpperCase()}</option>
                  ))}
                </Select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground">Business Assignment</label>
                <Select
                  value={formBusinessId}
                  onValueChange={setFormBusinessId}
                  className="h-10 text-xs"
                >
                  <option value="global">Global / System (No Business)</option>
                  {businesses.map((b: any) => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </Select>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-border/50">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsModalOpen(false)}
                  className="h-9 px-4 text-xs font-medium rounded-sm border-border"
                  disabled={actionLoading}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="h-9 px-5 text-xs font-bold rounded-sm shadow-md"
                  disabled={actionLoading}
                >
                  {actionLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-1.5" />
                      Saving...
                    </>
                  ) : (
                    "Save Changes"
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete User Confirmation Modal */}
      {isDeleteOpen && userToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-background/80 backdrop-blur-sm" onClick={() => setIsDeleteOpen(false)} />
          <div className="bg-card border border-border w-full max-w-sm rounded-xl shadow-2xl p-6 relative z-10 animate-in fade-in zoom-in-95 duration-150">
            <h2 className="text-md font-bold text-foreground mb-2">Delete User Account?</h2>
            <p className="text-xs text-muted-foreground mb-6 leading-relaxed">
              Are you sure you want to permanently delete <strong>{userToDelete.name}</strong> ({userToDelete.email})? 
              This action cannot be undone and will revoke all access.
            </p>

            <div className="flex justify-end gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsDeleteOpen(false)}
                className="h-9 px-4 text-xs font-medium rounded-sm border-border"
                disabled={actionLoading}
              >
                Cancel
              </Button>
              <Button
                type="button"
                variant="destructive"
                onClick={handleDeleteUser}
                className="h-9 px-4 text-xs font-bold rounded-sm"
                disabled={actionLoading}
              >
                {actionLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin mr-1.5" />
                    Deleting...
                  </>
                ) : (
                  "Delete Account"
                )}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function SuperUserManagementPage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen w-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
          <p className="text-sm text-muted-foreground">Loading portal...</p>
        </div>
      </div>
    }>
      <SuperUserManagementContent />
    </Suspense>
  );
}
