import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
} from '@nestjs/common';
import { Observable } from 'rxjs';

@Injectable()
export class TenantInterceptor implements NestInterceptor {
  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const req = context.switchToHttp().getRequest();
    const user = req.user;

    if (user && user.role !== 'super-admin') {
      const tenantBusinessId = user.businessId;

      if (tenantBusinessId) {
        if (req.query) {
          req.query.businessId = tenantBusinessId;
        }

        if (req.body && typeof req.body === 'object') {
          req.body.businessId = tenantBusinessId;
          if (req.method === 'POST') {
            req.body.createdById = req.body.createdById || user.id;
          }
          if (req.method === 'PUT' || req.method === 'PATCH') {
            req.body.updatedById = req.body.updatedById || user.id;
          }
        }
      }
    }

    return next.handle();
  }
}
