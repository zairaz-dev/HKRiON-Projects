"use client";

import { useState, useMemo } from "react";
import { Role, TaskStatus, TaskPriority, TaskHealth } from "@prisma/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Modal } from "@/components/ui/modal";
import { Select } from "@/components/ui/select";
import { PageHeader } from "@/components/ui/page-header";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { 
  Plus, 
  Search, 
  Filter, 
  AlertTriangle, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  PlayCircle, 
  Loader2,
  X,
  RotateCcw,
  Flame,
  Flag,
  Calendar,
  User,
  Users,
  CheckCheck,
  ChevronRight,
  ArrowUpRight,
  LayoutGrid,
  Table as TableIcon,
  Send,
  Check,
  TrendingUp,
  BarChart3,
  SlidersHorizontal,
  FileText,
  Building,
  ArrowUpDown
} from "lucide-react";
import Link from "next/link";
import { toast } from "sonner";
import { formatDistanceToNow, format, isPast, isToday, differenceInDays, differenceInHours } from "date-fns";
import { startTask, submitTaskForReview, reviewTask } from "@/actions/tasks";
import { cn } from "@/lib/utils";

interface EmployeeMeta {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  profileImage: string | null;
  role: Role;
  position: { title: string } | null;
}

interface TaskItem {
  id: number;
  title: string;
  description: string | null;
  deliverables: string | null;
  instructions: string | null;
  category: string | null;
  status: TaskStatus;
  health: TaskHealth;
  priority: TaskPriority;
  progress: number;
  startDate: Date | string | null;
  dueDate: Date | string | null;
  deadline: Date | string | null;
  reviewNotes: string | null;
  submittedAt: Date | string | null;
  reviewedAt: Date | string | null;
  completedAt: Date | string | null;
  assignerId: number;
  assigner: {
    id: number;
    firstName: string;
    lastName: string;
    profileImage: string | null;
    position?: { title: string } | null;
  };
  assignees: {
    id: number;
    firstName: string;
    lastName: string;
    profileImage: string | null;
    role?: Role;
    position?: { title: string } | null;
  }[];
  milestones?: { id: number; completed: boolean; title: string }[];
  updates?: {
    createdAt: Date | string;
    author: { firstName: string; lastName: string; profileImage: string | null };
  }[];
  createdAt: Date | string;
}

interface TasksDashboardClientProps {
  tasks: TaskItem[];
  employees: EmployeeMeta[];
  currentUserRole: Role;
  currentUserId: number;
}

// 1. Status Configuration
const statusConfig: Record<TaskStatus, { label: string; badgeVariant: "default" | "secondary" | "success" | "warning" | "error"; color: string; bg: string; border: string }> = {
  PENDING: { label: "Pending", badgeVariant: "warning", color: "text-amber-600 dark:text-amber-400", bg: "bg-amber-500/10", border: "border-amber-500/20" },
  IN_PROGRESS: { label: "In Progress", badgeVariant: "default", color: "text-blue-600 dark:text-blue-400", bg: "bg-blue-500/10", border: "border-blue-500/20" },
  SUBMITTED: { label: "Submitted", badgeVariant: "secondary", color: "text-purple-600 dark:text-purple-400", bg: "bg-purple-500/10", border: "border-purple-500/20" },
  UNDER_REVIEW: { label: "Under Review", badgeVariant: "secondary", color: "text-info", bg: "bg-info-bg", border: "border-info-border" },
  COMPLETED: { label: "Completed", badgeVariant: "success", color: "text-emerald-600 dark:text-emerald-400", bg: "bg-emerald-500/10", border: "border-emerald-500/20" },
  ON_HOLD: { label: "On Hold", badgeVariant: "secondary", color: "text-text-muted", bg: "bg-surface-secondary", border: "border-border" },
  CANCELLED: { label: "Cancelled", badgeVariant: "secondary", color: "text-text-disabled", bg: "bg-surface-secondary", border: "border-border" },
  OVERDUE: { label: "Overdue", badgeVariant: "error", color: "text-rose-600 dark:text-rose-400", bg: "bg-rose-500/10", border: "border-rose-500/20" },
  REJECTED: { label: "Revisions Needed", badgeVariant: "error", color: "text-rose-600 dark:text-rose-400", bg: "bg-rose-500/10", border: "border-rose-500/20" },
};

// 2. Priority Configuration (🟢 Low, 🔵 Medium, 🟠 High, 🔴 Urgent)
const priorityConfig: Record<TaskPriority, { icon: React.ElementType; label: string; color: string; bg: string; border: string; dotColor: string }> = {
  LOW: { icon: Flag, label: "Low", color: "text-emerald-600 dark:text-emerald-400", bg: "bg-emerald-500/10", border: "border-emerald-500/20", dotColor: "bg-emerald-500" },
  MEDIUM: { icon: Clock, label: "Medium", color: "text-primary dark:text-primary-hover", bg: "bg-primary-soft", border: "border-primary/30", dotColor: "bg-primary" },
  HIGH: { icon: AlertTriangle, label: "High", color: "text-amber-600 dark:text-amber-400", bg: "bg-amber-500/10", border: "border-amber-500/20", dotColor: "bg-amber-500" },
  URGENT: { icon: Flame, label: "Urgent", color: "text-rose-600 dark:text-rose-400", bg: "bg-rose-500/10", border: "border-rose-500/20", dotColor: "bg-rose-500" },
};

export default function TasksDashboardClient({
  tasks,
  employees,
  currentUserRole,
  currentUserId,
}: TasksDashboardClientProps) {
  const isManagerOrAdmin = currentUserRole === Role.MANAGER || currentUserRole === Role.SUPER_ADMIN;

  // View preferences
  const [viewMode, setViewMode] = useState<"grid" | "table">("grid");
  const [showAnalytics, setShowAnalytics] = useState(false);

  // Filters & Sorting
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [priorityFilter, setPriorityFilter] = useState<string>("ALL");
  const [employeeFilter, setEmployeeFilter] = useState<string>("ALL");
  const [sortBy, setSortBy] = useState<"dueDate" | "priority" | "progress" | "recent">("dueDate");

  // Interactive Quick Action States
  const [submittingTaskId, setSubmittingTaskId] = useState<number | null>(null);
  const [submissionNotes, setSubmissionNotes] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [reviewingTaskId, setReviewingTaskId] = useState<number | null>(null);
  const [reviewNotes, setReviewNotes] = useState("");
  const [isReviewing, setIsReviewing] = useState(false);

  // Helper for overdue calculation
  const checkIsOverdue = (task: TaskItem) => {
    if (task.status === TaskStatus.COMPLETED || task.status === TaskStatus.CANCELLED) {
      return false;
    }
    const targetDate = task.dueDate ? new Date(task.dueDate) : task.deadline ? new Date(task.deadline) : null;
    return targetDate ? isPast(targetDate) && !isToday(targetDate) : false;
  };

  // Helper for deadline countdown text
  const getDeadlineText = (task: TaskItem) => {
    const targetDate = task.dueDate ? new Date(task.dueDate) : task.deadline ? new Date(task.deadline) : null;
    if (!targetDate) return { text: "No deadline set", isOverdue: false, isUrgent: false };

    if (task.status === TaskStatus.COMPLETED) {
      return { text: "Completed", isOverdue: false, isUrgent: false };
    }

    if (isPast(targetDate) && !isToday(targetDate)) {
      const days = differenceInDays(new Date(), targetDate);
      return { text: `Overdue by ${days === 0 ? "today" : `${days}d`}`, isOverdue: true, isUrgent: true };
    }

    if (isToday(targetDate)) {
      return { text: "Due today", isOverdue: false, isUrgent: true };
    }

    const daysLeft = differenceInDays(targetDate, new Date());
    if (daysLeft === 1) return { text: "Due tomorrow", isOverdue: false, isUrgent: true };
    if (daysLeft <= 3) return { text: `${daysLeft} days remaining`, isOverdue: false, isUrgent: true };
    return { text: `Due ${format(targetDate, "MMM d")}`, isOverdue: false, isUrgent: false };
  };

  // Summary Metrics
  const metrics = useMemo(() => {
    const total = tasks.length;
    const pending = tasks.filter(t => t.status === TaskStatus.PENDING).length;
    const inProgress = tasks.filter(t => t.status === TaskStatus.IN_PROGRESS).length;
    const underReview = tasks.filter(t => t.status === TaskStatus.UNDER_REVIEW || t.status === TaskStatus.SUBMITTED).length;
    const completed = tasks.filter(t => t.status === TaskStatus.COMPLETED).length;
    const overdue = tasks.filter(t => checkIsOverdue(t)).length;
    const rejected = tasks.filter(t => t.status === TaskStatus.REJECTED).length;

    const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0;

    return { total, pending, inProgress, underReview, completed, overdue, rejected, completionRate };
  }, [tasks]);

  // Filtered & Sorted Tasks
  const filteredTasks = useMemo(() => {
    return tasks
      .filter((task) => {
        // Search
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchesTitle = task.title.toLowerCase().includes(q);
          const matchesDesc = task.description?.toLowerCase().includes(q);
          const matchesCategory = task.category?.toLowerCase().includes(q);
          const matchesId = task.id.toString().includes(q);
          const matchesAssignee = task.assignees.some(a => 
            `${a.firstName} ${a.lastName}`.toLowerCase().includes(q)
          );
          if (!matchesTitle && !matchesDesc && !matchesCategory && !matchesId && !matchesAssignee) {
            return false;
          }
        }

        // Status filter
        if (statusFilter === "OVERDUE") {
          if (!checkIsOverdue(task)) return false;
        } else if (statusFilter !== "ALL") {
          if (statusFilter === "UNDER_REVIEW") {
            if (task.status !== TaskStatus.UNDER_REVIEW && task.status !== TaskStatus.SUBMITTED) return false;
          } else if (task.status !== statusFilter) {
            return false;
          }
        }

        // Priority filter
        if (priorityFilter !== "ALL" && task.priority !== priorityFilter) {
          return false;
        }

        // Employee filter
        if (employeeFilter !== "ALL") {
          const empId = Number(employeeFilter);
          if (!task.assignees.some(a => a.id === empId)) return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === "dueDate") {
          if (!a.dueDate) return 1;
          if (!b.dueDate) return -1;
          return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
        }
        if (sortBy === "priority") {
          const weight: Record<TaskPriority, number> = { URGENT: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
          return weight[b.priority] - weight[a.priority];
        }
        if (sortBy === "progress") {
          return b.progress - a.progress;
        }
        if (sortBy === "recent") {
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        }
        return 0;
      });
  }, [tasks, searchQuery, statusFilter, priorityFilter, employeeFilter, sortBy]);

  // Employee workload calculation
  const employeeWorkload = useMemo(() => {
    if (!employees || employees.length === 0) return [];
    return employees.map((emp) => {
      const assigned = tasks.filter(t => t.assignees.some(a => a.id === emp.id));
      const active = assigned.filter(t => t.status !== TaskStatus.COMPLETED && t.status !== TaskStatus.CANCELLED).length;
      const completed = assigned.filter(t => t.status === TaskStatus.COMPLETED).length;
      const overdue = assigned.filter(t => checkIsOverdue(t)).length;
      return { ...emp, active, completed, overdue, total: assigned.length };
    }).sort((a, b) => b.active - a.active);
  }, [employees, tasks]);

  // Action: Start Task
  const handleStartTask = async (taskId: number) => {
    const res = await startTask(taskId);
    if (res.error) toast.error(res.error);
    else toast.success("Task started! Status changed to In Progress.");
  };

  // Action: Submit Task for Review
  const handleSubmitForReview = async () => {
    if (!submittingTaskId) return;
    setIsSubmitting(true);
    const res = await submitTaskForReview(submittingTaskId, submissionNotes);
    if (res.error) {
      toast.error(res.error);
    } else {
      toast.success("Task submitted for manager review!");
      setSubmittingTaskId(null);
      setSubmissionNotes("");
    }
    setIsSubmitting(false);
  };

  // Action: Manager Review (Approve or Reject)
  const handleReviewAction = async (action: "APPROVE" | "REJECT") => {
    if (!reviewingTaskId) return;
    setIsReviewing(true);
    const formData = new FormData();
    formData.append("action", action);
    formData.append("reviewNotes", reviewNotes);

    const res = await reviewTask(reviewingTaskId, formData);
    if (res.error) {
      toast.error(res.error);
    } else {
      if (action === "APPROVE") toast.success("Task approved and marked as COMPLETED!");
      else toast.success("Revision requested. Task returned to assignee.");
      setReviewingTaskId(null);
      setReviewNotes("");
    }
    setIsReviewing(false);
  };

  const getInitials = (first: string, last: string) => {
    return `${first?.charAt(0) || ""}${last?.charAt(0) || ""}`.toUpperCase();
  };

  return (
    <div className="space-y-6">
      
      {/* 1. TOP HEADER & WORKSPACE ACTION BAR */}
      <PageHeader
        title={isManagerOrAdmin ? "Task Management" : "My Tasks"}
        description={isManagerOrAdmin 
          ? "Create deliverables, assign tasks to software engineers, monitor workloads, and review completed work." 
          : "Track your active software tasks, update milestone progress, and submit deliverables for approval."}
        badge={
          <Badge variant="outline" className="text-xs font-mono font-bold">
            {metrics.total} Total Tasks
          </Badge>
        }
        actions={
          <>
            {isManagerOrAdmin && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setShowAnalytics(!showAnalytics)}
                className="gap-1.5 shadow-2xs cursor-pointer"
              >
                <BarChart3 className="h-4 w-4 text-primary" />
                <span>{showAnalytics ? "Hide Analytics" : "Workload Analytics"}</span>
              </Button>
            )}

            {isManagerOrAdmin && (
              <Link href="/dashboard/tasks/create">
                <Button size="sm" className="gap-2 shadow-sm font-semibold cursor-pointer">
                  <Plus className="h-4 w-4" />
                  <span>Assign New Task</span>
                </Button>
              </Link>
            )}
          </>
        }
      />

      {/* 2. MANAGER / EMPLOYEE KPI METRICS CARDS */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        
        {/* Total Tasks */}
        <button
          type="button"
          onClick={() => setStatusFilter("ALL")}
          className={cn(
            "p-3.5 sm:p-4 rounded-2xl border text-left transition-all cursor-pointer shadow-2xs space-y-1.5",
            statusFilter === "ALL" 
              ? "bg-surface border-primary ring-2 ring-primary/20" 
              : "bg-surface border-border hover:border-primary/40 hover:bg-surface-secondary/30"
          )}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-text-muted">Total Tasks</span>
            <CheckCheck className="h-4 w-4 text-primary" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-text-primary font-mono">{metrics.total}</p>
        </button>

        {/* Pending */}
        <button
          type="button"
          onClick={() => setStatusFilter(TaskStatus.PENDING)}
          className={cn(
            "p-3.5 sm:p-4 rounded-2xl border text-left transition-all cursor-pointer shadow-2xs space-y-1.5",
            statusFilter === TaskStatus.PENDING 
              ? "bg-amber-500/10 border-amber-500 ring-2 ring-amber-500/20" 
              : "bg-surface border-border hover:border-amber-500/40 hover:bg-surface-secondary/30"
          )}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">Pending</span>
            <Clock className="h-4 w-4 text-amber-500" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-amber-600 dark:text-amber-400 font-mono">{metrics.pending}</p>
        </button>

        {/* In Progress */}
        <button
          type="button"
          onClick={() => setStatusFilter(TaskStatus.IN_PROGRESS)}
          className={cn(
            "p-3.5 sm:p-4 rounded-2xl border text-left transition-all cursor-pointer shadow-2xs space-y-1.5",
            statusFilter === TaskStatus.IN_PROGRESS 
              ? "bg-blue-500/10 border-blue-500 ring-2 ring-blue-500/20" 
              : "bg-surface border-border hover:border-blue-500/40 hover:bg-surface-secondary/30"
          )}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">In Progress</span>
            <PlayCircle className="h-4 w-4 text-blue-500" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-blue-600 dark:text-blue-400 font-mono">{metrics.inProgress}</p>
        </button>

        {/* Under Review */}
        <button
          type="button"
          onClick={() => setStatusFilter("UNDER_REVIEW")}
          className={cn(
            "p-3.5 sm:p-4 rounded-2xl border text-left transition-all cursor-pointer shadow-2xs space-y-1.5",
            statusFilter === "UNDER_REVIEW" 
              ? "bg-purple-500/10 border-purple-500 ring-2 ring-purple-500/20" 
              : "bg-surface border-border hover:border-purple-500/40 hover:bg-surface-secondary/30"
          )}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400">In Review</span>
            <AlertCircle className="h-4 w-4 text-purple-500" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-purple-600 dark:text-purple-400 font-mono">{metrics.underReview}</p>
        </button>

        {/* Completed */}
        <button
          type="button"
          onClick={() => setStatusFilter(TaskStatus.COMPLETED)}
          className={cn(
            "p-3.5 sm:p-4 rounded-2xl border text-left transition-all cursor-pointer shadow-2xs space-y-1.5",
            statusFilter === TaskStatus.COMPLETED 
              ? "bg-emerald-500/10 border-emerald-500 ring-2 ring-emerald-500/20" 
              : "bg-surface border-border hover:border-emerald-500/40 hover:bg-surface-secondary/30"
          )}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">Completed</span>
            <CheckCircle2 className="h-4 w-4 text-emerald-500" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-emerald-600 dark:text-emerald-400 font-mono">{metrics.completed}</p>
        </button>

        {/* Overdue */}
        <button
          type="button"
          onClick={() => setStatusFilter("OVERDUE")}
          className={cn(
            "p-3.5 sm:p-4 rounded-2xl border text-left transition-all cursor-pointer shadow-2xs space-y-1.5",
            statusFilter === "OVERDUE" 
              ? "bg-rose-500/10 border-rose-500 ring-2 ring-rose-500/20" 
              : "bg-surface border-border hover:border-rose-500/40 hover:bg-surface-secondary/30"
          )}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400">Overdue</span>
            <AlertTriangle className="h-4 w-4 text-rose-500 animate-pulse" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-rose-600 dark:text-rose-400 font-mono">{metrics.overdue}</p>
        </button>

      </div>

      {/* 3. MANAGER ANALYTICS & WORKLOAD PANEL */}
      {isManagerOrAdmin && showAnalytics && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start animate-in fade-in slide-in-from-top-2 duration-200">
          
          {/* Employee Workload Table (7 cols) */}
          <div className="lg:col-span-7">
            <Card className="bg-surface border-border shadow-xs overflow-hidden">
              <CardHeader className="p-5 sm:p-6 border-b border-border">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-primary-soft text-primary">
                      <Users className="h-4.5 w-4.5" />
                    </div>
                    <div>
                      <CardTitle className="text-base font-semibold">Staff Workload Distribution</CardTitle>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-[10px] font-mono">
                    {employeeWorkload.length} Team Members
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="flex flex-col">
                  {/* Custom Header */}
                  <div className="grid grid-cols-12 gap-4 items-center p-4 border-b border-border bg-surface-secondary/30 text-xs font-semibold text-text-secondary uppercase tracking-wider">
                    <div className="col-span-5">Employee</div>
                    <div className="col-span-2 text-center">Active</div>
                    <div className="col-span-2 text-center">Completed</div>
                    <div className="col-span-2 text-center">Overdue</div>
                    <div className="col-span-1 text-right"></div>
                  </div>
                  
                  {/* List Body */}
                  <div className="divide-y divide-border/50 max-h-[380px] overflow-y-auto custom-scrollbar">
                    {employeeWorkload.length === 0 ? (
                      <div className="p-8 text-center text-text-muted text-sm">
                        No workload data available.
                      </div>
                    ) : (
                      employeeWorkload.map((emp) => (
                        <div 
                          key={emp.id} 
                          className="grid grid-cols-12 gap-4 items-center p-4 hover:bg-primary-soft/20 transition-all duration-300 group"
                        >
                          {/* Employee Info */}
                          <div className="col-span-5 flex items-center gap-3">
                            <div className="h-9 w-9 rounded-full bg-gradient-to-br from-primary-100 to-primary-soft text-primary font-bold text-xs flex items-center justify-center shrink-0 border border-primary/20 shadow-sm group-hover:scale-105 transition-transform duration-300">
                              {emp.profileImage ? (
                                <img src={emp.profileImage} alt={emp.firstName} className="w-full h-full rounded-full object-cover" />
                              ) : (
                                getInitials(emp.firstName, emp.lastName)
                              )}
                            </div>
                            <div className="min-w-0">
                              <p className="font-semibold text-sm text-text-primary truncate group-hover:text-primary transition-colors">
                                {emp.firstName} {emp.lastName}
                              </p>
                              <p className="text-xs text-text-muted truncate">
                                {emp.position?.title || emp.role}
                              </p>
                            </div>
                          </div>

                          {/* Active Tasks */}
                          <div className="col-span-2 flex justify-center">
                            <div className={cn(
                              "flex h-7 min-w-[28px] items-center justify-center rounded-full px-2 text-xs font-bold font-mono",
                              emp.active > 3 
                                ? "bg-amber-500/15 text-amber-600 border border-amber-500/20" 
                                : "bg-surface-secondary text-text-secondary border border-border"
                            )}>
                              {emp.active}
                            </div>
                          </div>

                          {/* Completed Tasks */}
                          <div className="col-span-2 flex justify-center">
                            <div className="flex h-7 min-w-[28px] items-center justify-center rounded-full px-2 text-xs font-bold font-mono bg-emerald-500/10 text-emerald-600 border border-emerald-500/20">
                              {emp.completed}
                            </div>
                          </div>

                          {/* Overdue Tasks */}
                          <div className="col-span-2 flex justify-center">
                            {emp.overdue > 0 ? (
                              <div className="flex h-7 min-w-[28px] items-center justify-center rounded-full px-2 text-xs font-bold font-mono bg-rose-500/15 text-rose-600 border border-rose-500/20 shadow-[0_0_10px_rgba(244,63,94,0.2)]">
                                {emp.overdue}
                              </div>
                            ) : (
                              <span className="text-text-disabled font-mono text-sm">—</span>
                            )}
                          </div>

                          {/* Action */}
                          <div className="col-span-1 flex justify-end">
                            <button
                              type="button"
                              onClick={() => setEmployeeFilter(emp.id.toString())}
                              className="opacity-0 group-hover:opacity-100 p-2 rounded-lg text-primary hover:bg-primary/10 transition-all duration-300 tooltip-trigger relative"
                              title="Filter tasks for this employee"
                            >
                              <Filter className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Completion Rate & Priority Breakdown (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            <Card className="bg-surface border-border shadow-xs overflow-hidden">
              <CardHeader className="p-5 sm:p-6 border-b border-border">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-teal-500/10 text-teal-600 dark:text-teal-400">
                      <TrendingUp className="h-4.5 w-4.5" />
                    </div>
                    <div>
                      <CardTitle className="text-base font-semibold">Completion & Priority Stats</CardTitle>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-[10px] font-mono">
                    {metrics.completionRate}% Rate
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-5 sm:p-6 space-y-4">
                
                {/* Completion Progress Gauge */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-text-secondary">Overall Delivery Progress</span>
                    <span className="font-mono font-bold text-text-primary">{metrics.completionRate}% Done</span>
                  </div>
                  <div className="h-2.5 w-full bg-surface-secondary rounded-full overflow-hidden shadow-inner">
                    <div className="h-full bg-emerald-500 rounded-full transition-all duration-500" style={{ width: `${metrics.completionRate}%` }} />
                  </div>
                </div>

                {/* Priority Breakdown */}
                <div className="pt-2 space-y-2 border-t border-border">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-text-muted">Tasks by Priority</p>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Flame className="h-3.5 w-3.5 text-rose-500" />
                        <span className="text-xs font-semibold text-rose-600">Urgent</span>
                      </div>
                      <span className="font-mono font-bold text-xs text-rose-600">
                        {tasks.filter(t => t.priority === "URGENT").length}
                      </span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
                        <span className="text-xs font-semibold text-amber-600">High</span>
                      </div>
                      <span className="font-mono font-bold text-xs text-amber-600">
                        {tasks.filter(t => t.priority === "HIGH").length}
                      </span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-primary-soft border border-primary/20 flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Clock className="h-3.5 w-3.5 text-primary" />
                        <span className="text-xs font-semibold text-primary">Medium</span>
                      </div>
                      <span className="font-mono font-bold text-xs text-primary">
                        {tasks.filter(t => t.priority === "MEDIUM").length}
                      </span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Flag className="h-3.5 w-3.5 text-emerald-500" />
                        <span className="text-xs font-semibold text-emerald-600">Low</span>
                      </div>
                      <span className="font-mono font-bold text-xs text-emerald-600">
                        {tasks.filter(t => t.priority === "LOW").length}
                      </span>
                    </div>
                  </div>
                </div>

              </CardContent>
            </Card>
          </div>

        </div>
      )}

      {/* 4. SEARCH, FILTER PILLS & VIEW CONTROLS */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          
          {/* Search Input */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-text-muted" />
            <Input
              type="text"
              placeholder="Search by title, description, category, ID, assignee..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-10 text-xs sm:text-sm bg-surface"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          {/* Filter & View Switchers */}
          <div className="flex flex-wrap items-center gap-2 pb-1 sm:pb-0">
            
            {/* Priority Filter */}
            <div className="w-40 sm:w-44 shrink-0">
              <Select
                value={priorityFilter}
                onValueChange={setPriorityFilter}
                size="sm"
                options={[
                  { value: "ALL", label: "All Priorities" },
                  { value: "URGENT", label: "🔴 Urgent Priority" },
                  { value: "HIGH", label: "🟠 High Priority" },
                  { value: "MEDIUM", label: "🔵 Medium Priority" },
                  { value: "LOW", label: "🟢 Low Priority" },
                ]}
              />
            </div>

            {/* Employee Filter (If Manager) */}
            {isManagerOrAdmin && employees && employees.length > 0 && (
              <div className="w-40 sm:w-44 shrink-0">
                <Select
                  value={employeeFilter}
                  onValueChange={setEmployeeFilter}
                  size="sm"
                  options={[
                    { value: "ALL", label: "All Employees" },
                    ...employees.map(emp => ({
                      value: emp.id.toString(),
                      label: `${emp.firstName} ${emp.lastName}`
                    }))
                  ]}
                />
              </div>
            )}

            {/* Sort Filter */}
            <div className="w-44 sm:w-48 shrink-0">
              <Select
                value={sortBy}
                onValueChange={(val) => setSortBy(val as "dueDate" | "priority" | "progress" | "recent")}
                size="sm"
                options={[
                  { value: "dueDate", label: "Sort: Deadline (Earliest)" },
                  { value: "priority", label: "Sort: Priority (Highest)" },
                  { value: "progress", label: "Sort: Progress (% Done)" },
                  { value: "recent", label: "Sort: Recently Created" },
                ]}
              />
            </div>

            {/* Reset Filters */}
            {(statusFilter !== "ALL" || priorityFilter !== "ALL" || employeeFilter !== "ALL" || searchQuery) && (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => {
                  setStatusFilter("ALL");
                  setPriorityFilter("ALL");
                  setEmployeeFilter("ALL");
                  setSearchQuery("");
                }}
                className="h-10 px-2.5 text-xs text-error hover:bg-error-bg cursor-pointer shrink-0"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Reset</span>
              </Button>
            )}

            {/* Grid / Table Switcher */}
            <div className="flex items-center bg-surface-secondary p-0.5 rounded-xl border border-border shrink-0">
              <button
                type="button"
                onClick={() => setViewMode("grid")}
                className={cn(
                  "p-2 rounded-lg transition-colors cursor-pointer",
                  viewMode === "grid" ? "bg-surface text-primary shadow-2xs" : "text-text-muted hover:text-text-primary"
                )}
                title="Grid Cards View"
              >
                <LayoutGrid className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => setViewMode("table")}
                className={cn(
                  "p-2 rounded-lg transition-colors cursor-pointer",
                  viewMode === "table" ? "bg-surface text-primary shadow-2xs" : "text-text-muted hover:text-text-primary"
                )}
                title="Data Table View"
              >
                <TableIcon className="h-4 w-4" />
              </button>
            </div>

          </div>

        </div>

        {/* Active Filter Chips */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <span className="text-text-muted text-[11px] font-medium">Active Status Filter:</span>
          {["ALL", TaskStatus.PENDING, TaskStatus.IN_PROGRESS, "UNDER_REVIEW", TaskStatus.COMPLETED, "OVERDUE", TaskStatus.REJECTED].map((st) => {
            const label = st === "ALL" ? "All Tasks" : st === "UNDER_REVIEW" ? "Under Review" : st === "OVERDUE" ? "Overdue" : statusConfig[st as TaskStatus]?.label;
            const isSelected = statusFilter === st;
            return (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={cn(
                  "px-2.5 py-1 rounded-full text-xs font-semibold border transition-all cursor-pointer",
                  isSelected 
                    ? "bg-primary text-white border-primary shadow-2xs" 
                    : "bg-surface border-border text-text-secondary hover:text-text-primary hover:border-primary/40"
                )}
              >
                {label}
              </button>
            );
          })}
        </div>
      </div>

      {/* 5. TASK LIST (GRID VIEW OR TABLE VIEW) */}
      {filteredTasks.length === 0 ? (
        <Card className="p-12 text-center bg-surface border-border shadow-xs space-y-3">
          <div className="h-12 w-12 rounded-2xl bg-surface-secondary text-text-muted mx-auto flex items-center justify-center">
            <CheckCheck className="h-6 w-6" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-semibold text-text-primary">No tasks found</h3>
            <p className="text-xs text-text-secondary max-w-sm mx-auto">
              No tasks matched your current search filters or assigned workspace criteria.
            </p>
          </div>
          {isManagerOrAdmin && (
            <Link href="/dashboard/tasks/create">
              <Button size="sm" className="mt-2 gap-1.5 font-semibold cursor-pointer">
                <Plus className="h-4 w-4" />
                <span>Create a Task</span>
              </Button>
            </Link>
          )}
        </Card>
      ) : viewMode === "grid" ? (
        
        /* GRID VIEW */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredTasks.map((task) => {
            const isOverdue = checkIsOverdue(task);
            const deadlineInfo = getDeadlineText(task);
            const priorityConf = priorityConfig[task.priority] || priorityConfig.MEDIUM;
            const statusConf = statusConfig[task.status] || statusConfig.PENDING;
            const PriorityIcon = priorityConf.icon;

            const isAssignee = task.assignees.some(a => a.id === currentUserId);
            const isTaskPending = task.status === TaskStatus.PENDING;
            const isTaskInProgress = task.status === TaskStatus.IN_PROGRESS || task.status === TaskStatus.REJECTED;
            const isTaskUnderReview = task.status === TaskStatus.UNDER_REVIEW || task.status === TaskStatus.SUBMITTED;

            return (
              <Card 
                key={task.id} 
                className={cn(
                  "bg-surface border shadow-xs hover:shadow-md transition-all duration-200 flex flex-col justify-between overflow-hidden",
                  isOverdue ? "border-rose-500/40 hover:border-rose-500" : "border-border hover:border-primary/40"
                )}
              >
                <CardContent className="p-5 space-y-4 flex-1 flex flex-col justify-between">
                  
                  {/* Top Badges & Priority */}
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between gap-2">
                      
                      {/* Priority pill */}
                      <span className={cn(
                        "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-[11px] font-bold border",
                        priorityConf.bg, priorityConf.color, priorityConf.border
                      )}>
                        <span className={cn("h-1.5 w-1.5 rounded-full", priorityConf.dotColor)} />
                        <span>{priorityConf.label}</span>
                      </span>

                      {/* Status pill */}
                      <span className={cn(
                        "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border",
                        statusConf.bg, statusConf.color, statusConf.border
                      )}>
                        {statusConf.label}
                      </span>
                    </div>

                    {/* Task Title & Category */}
                    <div>
                      {task.category && (
                        <p className="text-[10px] font-bold uppercase tracking-wider text-text-muted mb-0.5">
                          {task.category}
                        </p>
                      )}
                      <Link 
                        href={`/dashboard/tasks/${task.id}`}
                        className="text-base font-bold text-text-primary hover:text-primary transition-colors line-clamp-2 leading-snug block"
                      >
                        {task.title}
                      </Link>
                    </div>

                    {/* Description preview */}
                    {task.description && (
                      <p className="text-xs text-text-secondary line-clamp-2 leading-relaxed">
                        {task.description}
                      </p>
                    )}
                  </div>

                  {/* Middle Progress Bar */}
                  <div className="space-y-1.5 pt-2 border-t border-border">
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <span className="text-text-secondary text-[11px]">Progress</span>
                      <span className="font-mono text-text-primary text-[11px]">{task.progress}%</span>
                    </div>
                    <div className="h-1.5 w-full bg-surface-secondary rounded-full overflow-hidden">
                      <div 
                        className={cn(
                          "h-full rounded-full transition-all duration-500",
                          task.status === TaskStatus.COMPLETED ? "bg-emerald-500" :
                          isOverdue ? "bg-rose-500" : "bg-primary"
                        )} 
                        style={{ width: `${task.progress}%` }} 
                      />
                    </div>
                  </div>

                  {/* Dates & Assignees Footer */}
                  <div className="pt-2 border-t border-border space-y-3">
                    <div className="flex items-center justify-between gap-2 text-xs">
                      
                      {/* Deadline Countdown */}
                      <div className={cn(
                        "flex items-center gap-1.5 text-[11px] font-medium",
                        deadlineInfo.isOverdue ? "text-rose-600 dark:text-rose-400 font-bold" :
                        deadlineInfo.isUrgent ? "text-amber-600 dark:text-amber-400 font-semibold" :
                        "text-text-muted"
                      )}>
                        <Clock className="h-3.5 w-3.5" />
                        <span>{deadlineInfo.text}</span>
                      </div>

                      {/* Assignees Avatars */}
                      <div className="flex -space-x-1.5 shrink-0">
                        {task.assignees.slice(0, 3).map((a) => (
                          <div 
                            key={a.id}
                            title={`${a.firstName} ${a.lastName}`}
                            className="h-6 w-6 rounded-full bg-primary-soft text-primary font-bold text-[9px] flex items-center justify-center border border-surface shadow-2xs"
                          >
                            {a.profileImage ? (
                              <img src={a.profileImage} alt={a.firstName} className="w-full h-full rounded-full object-cover" />
                            ) : (
                              getInitials(a.firstName, a.lastName)
                            )}
                          </div>
                        ))}
                        {task.assignees.length === 0 && (
                          <span className="text-[10px] text-text-disabled">Unassigned</span>
                        )}
                      </div>
                    </div>

                    {/* Contextual Action Buttons */}
                    <div className="flex items-center gap-2 pt-1">
                      
                      {/* Employee Start Task Button */}
                      {isTaskPending && (isAssignee || isManagerOrAdmin) && (
                        <Button
                          type="button"
                          size="sm"
                          onClick={() => handleStartTask(task.id)}
                          className="flex-1 text-xs gap-1.5 bg-primary text-white hover:bg-primary-hover font-semibold cursor-pointer shadow-2xs"
                        >
                          <PlayCircle className="h-3.5 w-3.5" />
                          <span>Start Task</span>
                        </Button>
                      )}

                      {/* Employee Submit for Review Button */}
                      {isTaskInProgress && (isAssignee || isManagerOrAdmin) && (
                        <Button
                          type="button"
                          size="sm"
                          onClick={() => {
                            setSubmittingTaskId(task.id);
                            setSubmissionNotes("");
                          }}
                          className="flex-1 text-xs gap-1.5 bg-purple-600 text-white hover:bg-purple-700 font-semibold cursor-pointer shadow-2xs"
                        >
                          <Send className="h-3.5 w-3.5" />
                          <span>Submit Work</span>
                        </Button>
                      )}

                      {/* Manager Review Button */}
                      {isTaskUnderReview && isManagerOrAdmin && (
                        <Button
                          type="button"
                          size="sm"
                          onClick={() => {
                            setReviewingTaskId(task.id);
                            setReviewNotes("");
                          }}
                          className="flex-1 text-xs gap-1.5 bg-emerald-600 text-white hover:bg-emerald-700 font-semibold cursor-pointer shadow-2xs"
                        >
                          <CheckCheck className="h-3.5 w-3.5" />
                          <span>Review Work</span>
                        </Button>
                      )}

                      {/* Default View Workspace */}
                      <Link 
                        href={`/dashboard/tasks/${task.id}`}
                        className={cn(
                          "px-3 py-1.5 rounded-xl border border-border bg-surface hover:bg-surface-secondary text-xs font-semibold text-text-primary transition-colors inline-flex items-center justify-center gap-1 shadow-2xs",
                          !isTaskPending && !isTaskInProgress && !isTaskUnderReview ? "w-full" : ""
                        )}
                      >
                        <span>Workspace</span>
                        <ArrowUpRight className="h-3.5 w-3.5" />
                      </Link>

                    </div>

                  </div>

                </CardContent>
              </Card>
            );
          })}
        </div>

      ) : (
        
        /* TABLE VIEW */
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Task Details</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Priority</TableHead>
              <TableHead>Assignees</TableHead>
              <TableHead>Deadline</TableHead>
              <TableHead>Progress</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
                {filteredTasks.map((task) => {
                  const isOverdue = checkIsOverdue(task);
                  const deadlineInfo = getDeadlineText(task);
                  const priorityConf = priorityConfig[task.priority] || priorityConfig.MEDIUM;
                  const statusConf = statusConfig[task.status] || statusConfig.PENDING;

                  return (
                    <TableRow key={task.id}>
                      
                      {/* Title & Category */}
                      <TableCell className="max-w-xs">
                        <div>
                          {task.category && (
                            <span className="text-[10px] font-bold text-text-muted block">
                              {task.category}
                            </span>
                          )}
                          <Link 
                            href={`/dashboard/tasks/${task.id}`}
                            className="font-bold text-text-primary hover:text-primary transition-colors truncate block"
                          >
                            {task.title}
                          </Link>
                          <span className="text-[10px] font-mono text-text-disabled">#{task.id}</span>
                        </div>
                      </TableCell>

                      {/* Status */}
                      <TableCell>
                        <span className={cn(
                          "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border",
                          statusConf.bg, statusConf.color, statusConf.border
                        )}>
                          {statusConf.label}
                        </span>
                      </TableCell>

                      {/* Priority */}
                      <TableCell>
                        <span className={cn(
                          "inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[10px] font-bold border",
                          priorityConf.bg, priorityConf.color, priorityConf.border
                        )}>
                          <span className={cn("h-1.5 w-1.5 rounded-full", priorityConf.dotColor)} />
                          <span>{priorityConf.label}</span>
                        </span>
                      </TableCell>

                      {/* Assignees */}
                      <TableCell>
                        <div className="flex -space-x-1.5 shrink-0">
                          {task.assignees.map((a) => (
                            <div 
                              key={a.id}
                              title={`${a.firstName} ${a.lastName}`}
                              className="h-6 w-6 rounded-full bg-primary-soft text-primary font-bold text-[9px] flex items-center justify-center border border-surface shadow-2xs"
                            >
                              {a.profileImage ? (
                                <img src={a.profileImage} alt={a.firstName} className="w-full h-full rounded-full object-cover" />
                              ) : (
                                getInitials(a.firstName, a.lastName)
                              )}
                            </div>
                          ))}
                          {task.assignees.length === 0 && (
                            <span className="text-[10px] text-text-disabled">None</span>
                          )}
                        </div>
                      </TableCell>

                      {/* Deadline */}
                      <TableCell>
                        <span className={cn(
                          "text-xs font-medium block",
                          deadlineInfo.isOverdue ? "text-rose-600 dark:text-rose-400 font-bold" :
                          deadlineInfo.isUrgent ? "text-amber-600 dark:text-amber-400 font-semibold" :
                          "text-text-secondary"
                        )}>
                          {deadlineInfo.text}
                        </span>
                      </TableCell>

                      {/* Progress */}
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="h-1.5 w-16 bg-surface-secondary rounded-full overflow-hidden">
                            <div className="h-full bg-primary" style={{ width: `${task.progress}%` }} />
                          </div>
                          <span className="font-mono text-xs text-text-muted">{task.progress}%</span>
                        </div>
                      </TableCell>

                      {/* Actions */}
                      <TableCell className="text-right">
                        <Link 
                          href={`/dashboard/tasks/${task.id}`}
                          className="px-2.5 py-1 rounded-lg border border-border bg-surface hover:bg-surface-secondary text-xs font-semibold text-primary transition-colors inline-flex items-center gap-1 shadow-2xs"
                        >
                          <span>Open</span>
                          <ArrowUpRight className="h-3 w-3" />
                        </Link>
                      </TableCell>

                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
      )}

      {/* 6. MODAL: SUBMIT FOR REVIEW */}
      <Modal
        isOpen={submittingTaskId !== null}
        onClose={() => setSubmittingTaskId(null)}
        title="Submit Deliverables for Manager Review"
      >
        <div className="space-y-4">
          <p className="text-xs text-text-secondary leading-relaxed">
            Ready to hand over your work? Submitting this task will notify your manager and move the status to <strong className="text-text-primary">Under Review</strong>.
          </p>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-text-primary block">
              Completion Notes & Deliverables Summary
            </label>
            <textarea
              value={submissionNotes}
              onChange={(e) => setSubmissionNotes(e.target.value)}
              placeholder="Detail the completed output, PR links, or instructions for the reviewer..."
              className="w-full text-xs sm:text-sm bg-surface-secondary/40 focus:bg-surface rounded-xl border border-border p-3 text-text-primary placeholder:text-text-muted focus:outline-none focus:border-primary resize-y"
              rows={3}
            />
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setSubmittingTaskId(null)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="button"
              size="sm"
              onClick={handleSubmitForReview}
              disabled={isSubmitting}
              className="gap-1.5 bg-purple-600 hover:bg-purple-700 text-white font-semibold cursor-pointer"
            >
              {isSubmitting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
              <span>Submit for Review</span>
            </Button>
          </div>
        </div>
      </Modal>

      {/* 7. MODAL: MANAGER REVIEW & APPROVAL */}
      <Modal
        isOpen={reviewingTaskId !== null}
        onClose={() => setReviewingTaskId(null)}
        title="Review Task Submission"
      >
        <div className="space-y-4">
          <p className="text-xs text-text-secondary leading-relaxed">
            Review the deliverables submitted by the engineering team. You can either <strong className="text-emerald-600 font-semibold">Approve & Complete</strong> the task or <strong className="text-rose-600 font-semibold">Request Revisions</strong>.
          </p>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-text-primary block">
              Reviewer Notes / Feedback (Optional for approval, required for revisions)
            </label>
            <textarea
              value={reviewNotes}
              onChange={(e) => setReviewNotes(e.target.value)}
              placeholder="Provide feedback, approval congratulations, or specific changes needed..."
              className="w-full text-xs sm:text-sm bg-surface-secondary/40 focus:bg-surface rounded-xl border border-border p-3 text-text-primary placeholder:text-text-muted focus:outline-none focus:border-primary resize-y"
              rows={3}
            />
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setReviewingTaskId(null)}
              disabled={isReviewing}
            >
              Cancel
            </Button>
            <Button
              type="button"
              size="sm"
              onClick={() => handleReviewAction("REJECT")}
              disabled={isReviewing}
              className="gap-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold cursor-pointer"
            >
              {isReviewing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <AlertTriangle className="h-3.5 w-3.5" />}
              <span>Request Revisions</span>
            </Button>
            <Button
              type="button"
              size="sm"
              onClick={() => handleReviewAction("APPROVE")}
              disabled={isReviewing}
              className="gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold cursor-pointer"
            >
              {isReviewing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
              <span>Approve & Complete</span>
            </Button>
          </div>
        </div>
      </Modal>

    </div>
  );
}
