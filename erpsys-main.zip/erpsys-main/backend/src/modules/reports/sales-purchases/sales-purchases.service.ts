import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class SalesPurchasesService {
  constructor(private readonly prisma: PrismaService) {}

  async getSalesPurchaseSummary(
    businessId: string,
    filters: {
      startDate?: Date;
      endDate?: Date;
      branchId?: string;
    },
  ) {
    const { startDate, endDate, branchId } = filters;

    const dateFilter: any = {};
    if (startDate || endDate) {
      dateFilter.createdAt = {};
      if (startDate) dateFilter.createdAt.gte = new Date(startDate);
      if (endDate) dateFilter.createdAt.lte = new Date(endDate);
    }

    const saleWhere: any = { businessId, status: 'FINAL', ...dateFilter };
    const purchaseWhere: any = { businessId, ...dateFilter };

    if (branchId && branchId !== 'all') {
      saleWhere.branchId = branchId;
      purchaseWhere.branchId = branchId;
    }

    const [
      totalSalesAgg,
      totalSalesPaidAgg,
      totalSalesDueAgg,
      totalPurchasesAgg,
      totalPurchasesPaidAgg,
      totalPurchasesDueAgg,
    ] = await Promise.all([
      this.prisma.sale.aggregate({ where: saleWhere, _sum: { grandTotal: true }, _count: { id: true } }),
      this.prisma.sale.aggregate({ where: { ...saleWhere, paymentStatus: 'PAID' }, _sum: { grandTotal: true }, _count: { id: true } }),
      this.prisma.sale.aggregate({ where: { ...saleWhere, paymentStatus: { in: ['DUE', 'PARTIAL'] } }, _sum: { grandTotal: true, amountPaid: true }, _count: { id: true } }),

      this.prisma.purchase.aggregate({ where: purchaseWhere, _sum: { grandTotal: true }, _count: { id: true } }),
      this.prisma.purchase.aggregate({ where: { ...purchaseWhere, paymentStatus: 'PAID' }, _sum: { grandTotal: true }, _count: { id: true } }),
      this.prisma.purchase.aggregate({ where: { ...purchaseWhere, paymentStatus: { in: ['DUE', 'PARTIAL'] } }, _sum: { grandTotal: true, amountPaid: true }, _count: { id: true } }),
    ]);

    const totalSales = totalSalesAgg._sum.grandTotal || 0;
    const totalSalesCount = totalSalesAgg._count.id || 0;
    const salesPaid = totalSalesPaidAgg._sum.grandTotal || 0;
    const salesDueTotal = totalSalesDueAgg._sum.grandTotal || 0;
    const salesDuePaid = totalSalesDueAgg._sum.amountPaid || 0;
    const salesDueRemaining = salesDueTotal - salesDuePaid;

    const totalPurchases = totalPurchasesAgg._sum.grandTotal || 0;
    const totalPurchasesCount = totalPurchasesAgg._count.id || 0;
    const purchasesPaid = totalPurchasesPaidAgg._sum.grandTotal || 0;
    const purchasesDueTotal = totalPurchasesDueAgg._sum.grandTotal || 0;
    const purchasesDuePaid = totalPurchasesDueAgg._sum.amountPaid || 0;
    const purchasesDueRemaining = purchasesDueTotal - purchasesDuePaid;

    return {
      sales: {
        totalAmount: totalSales,
        totalInvoices: totalSalesCount,
        fullyPaidAmount: salesPaid,
        outstandingDue: salesDueRemaining,
      },
      purchases: {
        totalAmount: totalPurchases,
        totalInvoices: totalPurchasesCount,
        fullyPaidAmount: purchasesPaid,
        outstandingDue: purchasesDueRemaining,
      },
      netSalesOverPurchases: totalSales - totalPurchases,
    };
  }
}
