import { Controller, Post, Body, Get, Delete, Param, Query, UseGuards, Req } from '@nestjs/common';
import { SupplierAdvancesService } from './supplier-advances.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('supplier-advances')
export class SupplierAdvancesController {
  constructor(private readonly supplierAdvancesService: SupplierAdvancesService) {}

  @Permissions(Permission.PURCHASE_CREATE)
  @Post()
  async createAdvance(@Req() req: any, @Body() body: any) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }

    const {
      amount,
      advanceDate,
      supplierId,
      paymentMethodId,
      branchId,
      businessId,
      transactionNo,
      notes,
      createdById,
    } = body;

    return this.supplierAdvancesService.createAdvance({
      amount: Number(amount),
      advanceDate: advanceDate ? new Date(advanceDate) : undefined,
      supplierId,
      paymentMethodId,
      branchId,
      businessId,
      transactionNo,
      notes,
      createdById: createdById || user.id,
    });
  }

  @Permissions(Permission.PURCHASE_VIEW)
  @Get()
  async getAdvances(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
    @Query('supplierId') supplierId?: string,
    @Query('onlyRemaining') onlyRemaining?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.supplierAdvancesService.getAdvances(bId, {
      branchId,
      supplierId,
      onlyRemaining: onlyRemaining === 'true',
    });
  }

  @Permissions(Permission.PURCHASE_CREATE)
  @Delete(':id')
  async deleteAdvance(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.supplierAdvancesService.deleteAdvance(id, bId);
  }

  @Permissions(Permission.PURCHASE_CREATE)
  @Post('allocate')
  async allocateAdvance(@Req() req: any, @Body() body: any) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }
    const { supplierAdvanceId, purchaseId, amount, businessId } = body;

    return this.supplierAdvancesService.allocateAdvance({
      supplierAdvanceId,
      purchaseId,
      amount: Number(amount),
      businessId,
    });
  }

  @Permissions(Permission.PURCHASE_CREATE)
  @Delete('allocate/:id')
  async deleteAllocation(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.supplierAdvancesService.deleteAllocation(id, bId);
  }

  @Permissions(Permission.PURCHASE_CREATE)
  @Post('refund')
  async refundAdvance(@Req() req: any, @Body() body: any) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }

    return this.supplierAdvancesService.refundAdvance({
      supplierId: body.supplierId,
      amount: Number(body.amount),
      paymentMethodId: body.paymentMethodId,
      branchId: body.branchId,
      businessId: body.businessId,
      notes: body.notes,
      createdById: user.id,
    });
  }
}

