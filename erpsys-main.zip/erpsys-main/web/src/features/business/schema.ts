import { z } from 'zod';

export const businessSettingsSchema = z.object({
  name: z.string().min(2, "Business name must be at least 2 characters"),
  industry: z.string().min(2, "Industry must be at least 2 characters"),
  phone: z.string().min(5, "Phone number must be at least 5 digits"),
  phoneCodeId: z.string().min(1, "Phone code is required"),
  countryId: z.string().min(1, "Country is required"),
  currencyId: z.string().min(1, "Currency is required"),

  // Branding & Legal
  logo: z.string().optional().nullable(),
  registrationNumber: z.string().optional().nullable(),

  // Tax
  taxNumber: z.string().optional().nullable(),
  taxName: z.string().optional().nullable(),
  isTaxEnabled: z.boolean().optional(),

  // Contact & Address
  email: z.string().optional().nullable(),
  website: z.string().optional().nullable(),
  alternatePhone: z.string().optional().nullable(),
  address: z.string().optional().nullable(),
  city: z.string().optional().nullable(),
  state: z.string().optional().nullable(),
  postalCode: z.string().optional().nullable(),

  // Financial & Preferences
  financialYearStartMonth: z.number().optional().nullable(),
  stockAccountingMethod: z.string().optional().nullable(),
  timezone: z.string().optional().nullable(),
  dateFormat: z.string().optional().nullable(),
  currencySymbolPlacement: z.string().optional().nullable(),
  decimalPrecision: z.number().optional().nullable(),
});

export type BusinessSettingsFormData = z.infer<typeof businessSettingsSchema>;

