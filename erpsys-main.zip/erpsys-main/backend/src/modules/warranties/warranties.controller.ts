import {
  Controller,
  Post,
  Body,
  Get,
  Put,
  Delete,
  Param,
  Query,
  UseGuards,
  Req,
} from '@nestjs/common';
import { WarrantiesService } from './warranties.service';
import { DurationType } from '@prisma/client';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';
import {
  ApiTags,
  ApiOperation,
  ApiBody,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiQuery,
} from '@nestjs/swagger';

import { CreateWarrantyDto } from './dto/create-warranty.dto';
import { UpdateWarrantyDto } from './dto/update-warranty.dto';

@ApiTags('Warranties')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('warranties')
export class WarrantiesController {
  constructor(private readonly warrantiesService: WarrantiesService) {}

  @Permissions(Permission.PRODUCT_CREATE)
  @Post()
  @ApiOperation({ summary: 'Create warranty policy' })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        name: { type: 'string', minLength: 2, maxLength: 100, example: '1 Year Full Replacement' },
        description: { type: 'string', maxLength: 500, example: 'Covers all hardware faults' },
        duration: { type: 'number', minimum: 1, maximum: 1000, example: 1 },
        durationType: { type: 'string', enum: ['DAYS', 'MONTHS', 'YEARS'], example: 'YEARS' },
        isActive: { type: 'boolean', example: true },
        businessId: { type: 'string', example: 'biz_123' },
        branchIds: { type: 'array', items: { type: 'string' }, example: ['branch_01'] },
      },
      required: ['name', 'duration', 'durationType', 'businessId'],
    },
  })
  @ApiResponse({ status: 201, description: 'Warranty created successfully' })
  async createWarranty(
    @Req() req: any,
    @Body() body: CreateWarrantyDto,
  ) {
    const user = req.user;
    if (user.role !== 'super-admin' || !body.businessId) {
      body.businessId = user.businessId;
    }
    if (!body.createdById) {
      body.createdById = user.id;
    }
    return this.warrantiesService.createWarranty(body as any);
  }

  @Permissions(Permission.PRODUCT_VIEW)
  @Get()
  @ApiOperation({ summary: 'Get list of warranties' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiQuery({ name: 'branchId', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Warranties retrieved successfully' })
  async getWarranties(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.warrantiesService.getWarranties(bId, branchId);
  }

  @Permissions(Permission.PRODUCT_VIEW)
  @Get(':id')
  @ApiOperation({ summary: 'Get warranty details by ID' })
  @ApiParam({ name: 'id', description: 'Warranty UUID' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Warranty details retrieved successfully' })
  async getWarrantyById(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.warrantiesService.getWarrantyById(id, bId);
  }

  @Permissions(Permission.PRODUCT_UPDATE)
  @Put(':id')
  @ApiOperation({ summary: 'Update warranty policy' })
  @ApiParam({ name: 'id', description: 'Warranty UUID' })
  @ApiResponse({ status: 200, description: 'Warranty updated successfully' })
  async updateWarranty(
    @Req() req: any,
    @Param('id') id: string,
    @Body() body: UpdateWarrantyDto,
  ) {
    const user = req.user;
    let bId = body.businessId;
    if (user.role !== 'super-admin' || !bId) {
      bId = user.businessId;
    }
    if (!body.updatedById) {
      body.updatedById = user.id;
    }
    const { businessId, ...data } = body;
    return this.warrantiesService.updateWarranty(id, bId, data as any);
  }

  @Permissions(Permission.PRODUCT_DELETE)
  @Delete(':id')
  @ApiOperation({ summary: 'Delete warranty' })
  @ApiParam({ name: 'id', description: 'Warranty UUID' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Warranty deleted successfully' })
  async deleteWarranty(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.warrantiesService.deleteWarranty(id, bId);
  }
}
