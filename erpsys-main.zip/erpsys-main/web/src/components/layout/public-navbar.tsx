"use strict";
"use client";

import React, { useState, useEffect } from "react";
import {
  Layers,
  Menu,
  X,
  ArrowRight,
  MessageSquare,
  Home,
  Info,
  DollarSign,
  Sun,
  Moon,
  Sparkles,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { authService } from "@/services/auth-service";
import { cmsService, PublicLandingContent } from "@/services/cms-service";

export function PublicNavbar() {
  const pathname = usePathname();
  const [isOpen, setIsOpen] = useState(false);
  const [theme, setTheme] = useState("dark");
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [cms, setCms] = useState<PublicLandingContent | null>(null);

  // Load theme, auth status, and CMS announcement on mount
  useEffect(() => {
    const savedTheme = localStorage.getItem("theme") || "dark";
    setTheme(savedTheme);
    if (savedTheme === "light") {
      document.documentElement.classList.add("light");
      document.documentElement.classList.remove("dark");
    } else {
      document.documentElement.classList.remove("light");
      document.documentElement.classList.add("dark");
    }

    setIsLoggedIn(authService.isAuthenticated());

    cmsService.getPublicContent()
      .then((data) => setCms(data))
      .catch(() => {});
  }, []);

  // Toggle between light and dark themes
  const toggleTheme = () => {
    const newTheme = theme === "dark" ? "light" : "dark";
    setTheme(newTheme);
    localStorage.setItem("theme", newTheme);
    if (newTheme === "light") {
      document.documentElement.classList.add("light");
      document.documentElement.classList.remove("dark");
    } else {
      document.documentElement.classList.remove("light");
      document.documentElement.classList.add("dark");
    }
  };

  const hero = cms?.hero;
  const showAnnouncement = hero?.announcementActive && hero?.announcementText;

  const navigation = [
    { name: "Home", href: "/", icon: Home },
    { name: "About", href: "/about", icon: Info },
    { name: "Pricing", href: "/pricing", icon: DollarSign },
    { name: "Contact Us", href: "/contact", icon: MessageSquare },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 transition-all duration-300">
      {/* 🌟 ULTRA-MODERN ANIMATED TOP ANNOUNCEMENT BAR */}
      {showAnnouncement && (
        <div className="relative overflow-hidden bg-emerald-100/90 dark:bg-emerald-900/60 text-emerald-900 dark:text-emerald-200 border-b border-emerald-300/70 dark:border-emerald-500/20 py-2 px-4 shadow-sm dark:shadow-md backdrop-blur-md transition-all">
          {/* Animated Light Beam / Shimmer Gliding Across */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <div className="w-1/2 h-full bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12 animate-banner-shimmer" />
          </div>

          <div className="max-w-7xl mx-auto flex items-center justify-center gap-2.5 text-xs font-sans relative z-10">
            {/* Live Indicator Pill Badge */}
            <span className="hidden sm:inline-flex items-center gap-1.5 bg-emerald-500/15 dark:bg-emerald-500/20 text-emerald-800 dark:text-emerald-300 text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full border border-emerald-500/30 shadow-sm backdrop-blur-sm">
              <span className="relative flex h-1.5 w-1.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-500 dark:bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-600 dark:bg-emerald-400" />
              </span>
              ANNOUNCEMENT
            </span>

            {/* Pulsing Sparkle Icon */}
            <Sparkles className="w-3.5 h-3.5 animate-pulse text-emerald-600 dark:text-emerald-400 shrink-0" />

            {/* Announcement Text */}
            <span className="font-semibold tracking-tight text-[11px] sm:text-xs text-emerald-950 dark:text-zinc-200">
              {hero.announcementText}
            </span>

            {/* Interactive CTA Link with Animated Sliding Arrow */}
            {hero.announcementLink && (
              <a
                href={hero.announcementLink}
                className="group/cta inline-flex items-center gap-1 font-bold text-[11px] sm:text-xs text-emerald-700 hover:text-emerald-800 dark:text-emerald-400 dark:hover:text-emerald-300 underline underline-offset-2 transition-opacity ml-1"
              >
                <span>Claim Offer</span>
                <ArrowRight className="w-3 h-3 group-hover/cta:translate-x-1 transition-transform duration-200" />
              </a>
            )}
          </div>
        </div>
      )}

      {/* 💎 ULTRA-MODERN FLOATING GLASS NAVBAR */}
      <nav className="border-b border-border/80 dark:border-emerald-950/40 bg-white/80 dark:bg-black/40 backdrop-blur-2xl transition-all duration-300 shadow-sm dark:shadow-none">
        <div className="max-w-7xl mx-auto px-6 sm:px-10">
          <div className="flex items-center justify-between h-20">
            
            {/* Left: Brand Logo */}
            <div className="flex items-center gap-3">
              <Link href="/">
                <div className="flex items-center gap-3 group cursor-pointer">
                  {/* Real HKRiON ERP Logo */}
                  <div className="w-9 h-9 rounded-xl border border-emerald-500/30 dark:border-emerald-400/40 bg-emerald-50 dark:bg-emerald-950/60 p-1 flex items-center justify-center shadow-sm dark:shadow-[0_0_15px_rgba(16,185,129,0.3)] group-hover:scale-105 transition-transform duration-200 shrink-0">
                    <img
                      src="/logo.png"
                      alt="HKRiON ERP Logo"
                      className="w-full h-full object-contain"
                    />
                  </div>
                  
                  <div className="flex flex-col">
                    <span className="text-lg font-bold tracking-tight text-zinc-900 dark:text-white font-sans leading-tight">
                      HKRiON <span className="text-emerald-600 dark:text-emerald-400">ERP</span>
                    </span>
                    <span className="text-[9px] font-mono tracking-wider text-emerald-700 dark:text-emerald-400/80 uppercase -mt-0.5 font-semibold">
                      Cloud Suite
                    </span>
                  </div>
                </div>
              </Link>
            </div>

            {/* Center: Desktop Navigation Links */}
            <div className="hidden md:flex items-center gap-7">
              {navigation.map((item) => {
                const isActive = pathname === item.href;
                return (
                  <Link key={item.name} href={item.href}>
                    <span
                      className={cn(
                        "text-sm font-medium transition-all duration-200 cursor-pointer",
                        isActive
                          ? "text-emerald-600 dark:text-emerald-400 font-semibold"
                          : "text-zinc-600 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-white"
                      )}
                    >
                      {item.name}
                    </span>
                  </Link>
                );
              })}
            </div>

            {/* Right: Desktop Auth Buttons & Theme Toggle */}
            <div className="hidden md:flex items-center gap-4">
              {/* Theme Toggle Button */}
              <button
                onClick={toggleTheme}
                className="w-9 h-9 rounded-full border border-border dark:border-emerald-500/30 bg-card/80 dark:bg-emerald-950/40 hover:bg-muted dark:hover:bg-emerald-900/50 text-foreground dark:text-emerald-300 flex items-center justify-center transition-all duration-200 cursor-pointer shadow-sm dark:shadow-none"
                aria-label="Toggle Theme"
              >
                {theme === "dark" ? (
                  <Sun className="w-4 h-4 hover:rotate-45 transition-transform duration-300" />
                ) : (
                  <Moon className="w-4 h-4 hover:-rotate-12 transition-transform duration-300" />
                )}
              </button>

              {isLoggedIn ? (
                <Link href="/dashboard">
                  <Button className="text-xs h-10 px-5 rounded-full bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-black font-semibold shadow-md transition-all gap-1.5">
                    <span>Go to Workspace</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Button>
                </Link>
              ) : (
                <div className="flex items-center gap-3">
                  <Link href="/login">
                    <span className="text-sm font-medium text-zinc-600 hover:text-zinc-950 dark:text-zinc-300 dark:hover:text-white px-3 py-1.5 transition-colors cursor-pointer">
                      Sign In
                    </span>
                  </Link>
                  <Link href="/register">
                    <Button className="text-xs h-10 px-5 rounded-full bg-emerald-600 hover:bg-emerald-700 dark:bg-emerald-500 dark:hover:bg-emerald-400 text-white dark:text-black font-bold shadow-md shadow-emerald-500/20 dark:shadow-[0_0_20px_rgba(16,185,129,0.35)] transition-all gap-1.5">
                      <span>Register Business</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Button>
                  </Link>
                </div>
              )}
            </div>

            {/* Mobile Hamburger & Theme Toggle */}
            <div className="flex items-center gap-2 md:hidden">
              <button
                onClick={toggleTheme}
                className="w-9 h-9 rounded-full border border-border dark:border-emerald-500/30 bg-card/80 dark:bg-emerald-950/40 flex items-center justify-center text-foreground dark:text-emerald-300"
                aria-label="Toggle Theme"
              >
                {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>

              <button
                onClick={() => setIsOpen(!isOpen)}
                className="text-zinc-700 hover:text-zinc-950 dark:text-zinc-300 dark:hover:text-white p-2 rounded-lg hover:bg-muted dark:hover:bg-emerald-950/50 transition-colors"
              >
                {isOpen ? <X className="w-5 h-5 text-emerald-600 dark:text-emerald-400" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>

          </div>
        </div>

        {/* 📱 Mobile Drawer Overlay with Frosted Glass */}
        {isOpen && (
          <div className="md:hidden border-b border-border dark:border-emerald-900/40 bg-background/95 dark:bg-black/95 backdrop-blur-2xl px-6 py-5 space-y-4 animate-in slide-in-from-top-2 duration-200">
            <div className="flex flex-col gap-2">
              {navigation.map((item) => {
                const isActive = pathname === item.href;
                return (
                  <Link key={item.name} href={item.href} onClick={() => setIsOpen(false)}>
                    <span
                      className={cn(
                        "flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-all cursor-pointer",
                        isActive
                          ? "bg-emerald-500/15 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-400 font-semibold"
                          : "text-zinc-600 dark:text-zinc-400 hover:text-zinc-950 dark:hover:text-white hover:bg-muted dark:hover:bg-emerald-950/40"
                      )}
                    >
                      {item.name}
                    </span>
                  </Link>
                );
              })}
            </div>

            <div className="h-[1px] bg-border/80 dark:bg-emerald-900/30 my-3" />

            <div className="flex flex-col gap-2.5 pt-1">
              {isLoggedIn ? (
                <Link href="/dashboard" onClick={() => setIsOpen(false)}>
                  <Button className="w-full text-xs h-10 font-bold bg-zinc-900 text-white hover:bg-zinc-800 dark:bg-white dark:text-black dark:hover:bg-zinc-200">
                    Go to Workspace
                  </Button>
                </Link>
              ) : (
                <>
                  <Link href="/login" onClick={() => setIsOpen(false)}>
                    <Button variant="outline" className="w-full text-xs h-10 border-border dark:border-emerald-500/30 bg-transparent text-foreground dark:text-white hover:bg-muted dark:hover:bg-emerald-950/40">
                      Sign In
                    </Button>
                  </Link>
                  <Link href="/register" onClick={() => setIsOpen(false)}>
                    <Button className="w-full text-xs h-10 font-bold bg-emerald-600 hover:bg-emerald-700 dark:bg-emerald-500 dark:hover:bg-emerald-400 text-white dark:text-black shadow-md shadow-emerald-500/25">
                      Register Business Free
                    </Button>
                  </Link>
                </>
              )}
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
