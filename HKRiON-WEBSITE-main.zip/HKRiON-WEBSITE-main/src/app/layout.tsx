import type { Metadata } from "next";
import { Outfit, Plus_Jakarta_Sans, JetBrains_Mono } from "next/font/google";
import SmoothScroll from "@/components/SmoothScroll";
import "./globals.css";

const outfit = Outfit({
  variable: "--font-outfit",
  subsets: ["latin"],
  display: "swap",
});

const plusJakarta = Plus_Jakarta_Sans({
  variable: "--font-jakarta",
  subsets: ["latin"],
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-jetbrains",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL('https://hkrion.com'),
  title: {
    default: "HKRION (Pvt) Ltd | Enterprise ERP, IoT & Software Solutions",
    template: "%s | HKRION (Pvt) Ltd",
  },
  description: "HKRION (Pvt) Ltd is a software engineering company building Next-Gen Enterprise ERPs, IoT Smart Systems, Web Applications, Mobile Apps, and Cloud Infrastructure in Sri Lanka and globally.",
  keywords: [
    "HKRION",
    "HKRION (Pvt) Ltd",
    "HKRION POS",
    "HKRION ERP",
    "HKRION HRM",
    "IoT Telemetry Sri Lanka",
    "Software Development Company Sri Lanka",
    "Enterprise Software Solutions",
    "Next.js Web Development",
    "MySQL Prisma Database"
  ],
  authors: [{ name: "HKRION Engineering Team", url: "https://hkrion.com" }],
  creator: "HKRION (Pvt) Ltd",
  publisher: "HKRION (Pvt) Ltd",
  openGraph: {
    title: "HKRION (Pvt) Ltd | Enterprise ERP, IoT & Software Solutions",
    description: "Engineering Next-Gen Enterprise ERPs, IoT Hardware Telemetry, Web Applications, and Cloud Solutions.",
    url: "https://hkrion.com",
    siteName: "HKRION (Pvt) Ltd",
    locale: "en_US",
    type: "website",
    images: [
      {
        url: "https://hkrion.com/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "HKRION (Pvt) Ltd Enterprise Software Solutions",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "HKRION (Pvt) Ltd | Enterprise ERP & Software Solutions",
    description: "Custom ERPs, IoT Systems, Web & Mobile Applications.",
    creator: "@hkrion",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon.ico',
    apple: '/logo.png',
  },
  other: {
    'facebook-domain-verification': '7v5zdgjwwcfjr1vzsqkpgagt7x0vkn',
  },
};

const jsonLdData = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": "https://hkrion.com/#organization",
      "name": "HKRION (Pvt) Ltd",
      "url": "https://hkrion.com",
      "logo": "https://hkrion.com/logo.png",
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": "+94-77-000-0000",
        "contactType": "customer service",
        "areaServed": ["LK", "Global"],
        "availableLanguage": ["English", "Tamil"]
      },
      "sameAs": [
        "https://github.com/hkrion",
        "https://linkedin.com/company/hkrion",
        "https://twitter.com/hkrion"
      ]
    },
    {
      "@type": "SoftwareApplication",
      "name": "HKRION ERP & POS Suite",
      "operatingSystem": "All",
      "applicationCategory": "BusinessApplication",
      "offers": {
        "@type": "Offer",
        "price": "0",
        "priceCurrency": "USD",
        "availability": "https://schema.org/InStock"
      },
      "description": "Enterprise ERP, POS billing, HRM payroll, and inventory stock management software suite developed by HKRION (Pvt) Ltd."
    }
  ]
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      data-scroll-behavior="smooth"
      className={`${outfit.variable} ${plusJakarta.variable} ${jetbrainsMono.variable} h-full antialiased`}
    >
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLdData) }}
        />
      </head>
      <body className="min-h-full flex flex-col">
        <SmoothScroll>{children}</SmoothScroll>
      </body>
    </html>
  );
}
