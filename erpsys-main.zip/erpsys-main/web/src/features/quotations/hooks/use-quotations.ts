import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { quotationService } from '@/services/quotation-service';
import { queryKeys } from '@/lib/query-keys';
import { CreateQuotationPayload, QuotationsQueryParams } from '../types';

export function useQuotationsQuery(params: QuotationsQueryParams, options?: { enabled?: boolean }) {
  return useQuery({
    queryKey: queryKeys.quotations.list(params),
    queryFn: () => quotationService.getQuotations(params),
    enabled: options?.enabled ?? true,
  });
}

export function useQuotationDetailQuery(id: string) {
  return useQuery({
    queryKey: queryKeys.quotations.detail(id),
    queryFn: () => quotationService.getQuotation(id),
    enabled: !!id,
  });
}

export function useCreateQuotationMutation() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (payload: CreateQuotationPayload) => quotationService.create(payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.quotations.all });
    },
  });
}

export function useUpdateQuotationMutation() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, payload }: { id: string; payload: Partial<CreateQuotationPayload> }) =>
      quotationService.update(id, payload),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.quotations.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.quotations.detail(variables.id) });
    },
  });
}

export function useDeleteQuotationMutation() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: string) => quotationService.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.quotations.all });
    },
  });
}

export function useConvertToSaleMutation() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, body }: { id: string; body?: { payments?: any[]; useAdvance?: boolean } }) =>
      quotationService.convertToSale(id, body),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.quotations.all });
      queryClient.invalidateQueries({ queryKey: ['sales'] });
    },
  });
}
