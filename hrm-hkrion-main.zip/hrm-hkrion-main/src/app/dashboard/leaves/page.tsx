import { getLeaveRequests } from "@/actions/leaves";
import LeavesClient from "./leaves-client";

export const dynamic = "force-dynamic";

export default async function LeavesPage() {
  const res = await getLeaveRequests();

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <LeavesClient 
        records={res.data || []}
        currentUserId={res.currentUserId || 0}
        isAdmin={res.isAdmin || false}
      />
    </div>
  );
}
