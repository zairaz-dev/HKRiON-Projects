import AdminDashboard from "@/features/admin/AdminDashboard";

export default function OrdersPage() {
  return <AdminDashboard initialTab="orders" />;
}
