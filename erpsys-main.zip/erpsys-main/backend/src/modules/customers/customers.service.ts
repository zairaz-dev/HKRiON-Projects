import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateCustomerDto } from './dto/create-customer.dto';
import { UpdateCustomerDto } from './dto/update-customer.dto';

@Injectable()
export class CustomersService {
  constructor(private prisma: PrismaService) {}

  async create(createDto: CreateCustomerDto) {
    const { branchIds, ...data } = createDto;

    // Field validation
    const trimmedName = data.name?.trim();
    if (!trimmedName) {
      throw new BadRequestException('Customer name is required');
    }
    if (trimmedName.toLowerCase() === 'walk-in customer') {
      throw new BadRequestException('A customer with the reserved name "Walk-in Customer" cannot be manually created');
    }
    if (trimmedName.length < 2 || trimmedName.length > 100) {
      throw new BadRequestException('Customer name must be between 2 and 100 characters');
    }

    if (!data.businessId || !data.businessId.trim()) {
      throw new BadRequestException('Business ID is required');
    }

    const trimmedPhone = data.phone?.trim() || null;
    const trimmedEmail = data.email?.trim() || null;

    if (data.openingBalance !== undefined && data.openingBalance < 0) {
      throw new BadRequestException('Opening balance must be 0 or greater');
    }

    if (data.creditLimit !== undefined && data.creditLimit !== null && data.creditLimit < 0) {
      throw new BadRequestException('Credit limit must be 0 or greater');
    }

    if (data.address && data.address.length > 500) {
      throw new BadRequestException('Address cannot exceed 500 characters');
    }

    // 1. Check duplicate phone in the same business
    if (trimmedPhone) {
      const existingPhone = await this.prisma.customer.findFirst({
        where: {
          phone: { equals: trimmedPhone, mode: 'insensitive' },
          businessId: data.businessId,
        },
      });
      if (existingPhone) {
        throw new BadRequestException('A customer with this phone number already exists in this business');
      }
    }

    // 2. Check duplicate email in the same business
    if (trimmedEmail) {
      const existingEmail = await this.prisma.customer.findFirst({
        where: {
          email: { equals: trimmedEmail, mode: 'insensitive' },
          businessId: data.businessId,
        },
      });
      if (existingEmail) {
        throw new BadRequestException('A customer with this email already exists in this business');
      }
    }

    // 3. Verify customer group belongs to business if provided
    if (data.customerGroupId) {
      const group = await this.prisma.customerGroup.findFirst({
        where: { id: data.customerGroupId, businessId: data.businessId },
      });
      if (!group) {
        throw new BadRequestException('Customer group not found');
      }
    }

    // 4. Verify branches belong to the business if provided
    if (branchIds && branchIds.length > 0) {
      const validBranches = await this.prisma.branch.findMany({
        where: {
          id: { in: branchIds },
          businessId: data.businessId,
        },
      });
      if (validBranches.length !== branchIds.length) {
        throw new BadRequestException('One or more selected branches are invalid');
      }
    }

    const createData: any = {
      ...data,
      name: trimmedName,
      phone: trimmedPhone,
      email: trimmedEmail,
      businessName: data.businessName?.trim() || null,
      address: data.address?.trim() || null,
      taxNumber: data.taxNumber?.trim() || null,
      isDefault: false,
      allowCredit: data.allowCredit !== undefined
        ? (typeof data.allowCredit === 'string' ? data.allowCredit === 'true' : Boolean(data.allowCredit))
        : true,
      ...(data.isActive !== undefined && {
        isActive: typeof data.isActive === 'string' ? data.isActive === 'true' : Boolean(data.isActive),
      }),
      branches: branchIds && branchIds.length > 0
        ? {
            create: branchIds.map((branchId) => ({
              branchId,
            })),
          }
        : undefined,
    };

    return this.prisma.customer.create({
      data: createData,
      include: {
        customerGroup: true,
        branches: {
          include: {
            branch: true,
          },
        },
      },
    });
  }

  async findAll(businessId: string, branchId?: string) {
    // Ensure default Walk-in Customer exists for this business (auto-healing)
    const walkIn = await this.prisma.customer.findFirst({
      where: {
        businessId,
        OR: [
          { isDefault: true },
          { name: { equals: 'Walk-in Customer', mode: 'insensitive' } },
        ],
      },
    });

    if (!walkIn) {
      await this.prisma.customer.create({
        data: {
          name: 'Walk-in Customer',
          isDefault: true,
          allowCredit: false,
          creditLimit: 0,
          businessId,
        },
      });
    } else if (!walkIn.isDefault || walkIn.allowCredit) {
      await this.prisma.customer.update({
        where: { id: walkIn.id },
        data: { isDefault: true, allowCredit: false, creditLimit: 0 },
      });
    }

    const whereClause: any = { businessId };

    if (branchId) {
      whereClause.OR = [
        { isDefault: true },
        { name: { equals: 'Walk-in Customer', mode: 'insensitive' } },
        { branches: { none: {} } },
        { branches: { some: { branchId } } },
      ];
    }

    return this.prisma.customer.findMany({
      where: whereClause,
      include: {
        customerGroup: true,
        branches: {
          include: {
            branch: true,
          },
        },
        sales: {
          where: {
            status: 'FINAL',
          },
          select: {
            id: true,
            invoiceNumber: true,
            grandTotal: true,
            amountPaid: true,
            paymentStatus: true,
          },
        },
        advances: {
          select: {
            id: true,
            amount: true,
            amountRemaining: true,
          },
        },
      },
      orderBy: [
        { isDefault: 'desc' },
        { createdAt: 'desc' },
      ],
    });
  }

  async findOne(id: string, businessId: string) {
    const customer = await this.prisma.customer.findFirst({
      where: { id, businessId },
      include: {
        customerGroup: true,
        branches: {
          include: {
            branch: true,
          },
        },
        sales: {
          where: {
            status: 'FINAL',
          },
          select: {
            id: true,
            invoiceNumber: true,
            grandTotal: true,
            amountPaid: true,
            saleDate: true,
            paymentStatus: true,
          },
          orderBy: {
            saleDate: 'asc',
          },
        },
        advances: {
          select: {
            id: true,
            advanceNumber: true,
            amount: true,
            amountRemaining: true,
            advanceDate: true,
            paymentMethod: true,
          },
          orderBy: {
            advanceDate: 'desc',
          },
        },
      },
    });

    if (!customer) {
      throw new NotFoundException('Customer not found');
    }

    return customer;
  }

  async update(id: string, updateDto: UpdateCustomerDto) {
    const { branchIds, businessId, ...data } = updateDto;

    const customer = await this.prisma.customer.findUnique({
      where: { id },
    });

    if (!customer) {
      throw new NotFoundException('Customer not found');
    }

    if (customer.isDefault || customer.name.toLowerCase() === 'walk-in customer') {
      throw new BadRequestException('The default Walk-in Customer cannot be modified');
    }

    const bId = businessId || customer.businessId;

    let trimmedName: string | undefined = undefined;
    if (data.name !== undefined) {
      trimmedName = data.name.trim();
      if (!trimmedName) {
        throw new BadRequestException('Customer name cannot be empty');
      }
      if (trimmedName.length < 2 || trimmedName.length > 100) {
        throw new BadRequestException('Customer name must be between 2 and 100 characters');
      }
    }

    let trimmedPhone: string | null | undefined = undefined;
    if (data.phone !== undefined) {
      trimmedPhone = data.phone?.trim() || null;
      if (trimmedPhone && trimmedPhone !== customer.phone) {
        const existingPhone = await this.prisma.customer.findFirst({
          where: {
            id: { not: id },
            phone: { equals: trimmedPhone, mode: 'insensitive' },
            businessId: bId,
          },
        });
        if (existingPhone) {
          throw new BadRequestException('A customer with this phone number already exists in this business');
        }
      }
    }

    let trimmedEmail: string | null | undefined = undefined;
    if (data.email !== undefined) {
      trimmedEmail = data.email?.trim() || null;
      if (trimmedEmail && trimmedEmail !== customer.email) {
        const existingEmail = await this.prisma.customer.findFirst({
          where: {
            id: { not: id },
            email: { equals: trimmedEmail, mode: 'insensitive' },
            businessId: bId,
          },
        });
        if (existingEmail) {
          throw new BadRequestException('A customer with this email already exists in this business');
        }
      }
    }

    if (data.openingBalance !== undefined && data.openingBalance < 0) {
      throw new BadRequestException('Opening balance must be 0 or greater');
    }

    if (data.creditLimit !== undefined && data.creditLimit !== null && data.creditLimit < 0) {
      throw new BadRequestException('Credit limit must be 0 or greater');
    }

    if (data.address !== undefined && data.address !== null && data.address.length > 500) {
      throw new BadRequestException('Address cannot exceed 500 characters');
    }

    // Verify customer group belongs to business if changing
    if (data.customerGroupId !== undefined && data.customerGroupId !== null && data.customerGroupId !== customer.customerGroupId) {
      const group = await this.prisma.customerGroup.findFirst({
        where: { id: data.customerGroupId, businessId: bId },
      });
      if (!group) {
        throw new BadRequestException('Customer group not found');
      }
    }

    // Verify branches belong to the business if changing
    if (branchIds && branchIds.length > 0) {
      const validBranches = await this.prisma.branch.findMany({
        where: {
          id: { in: branchIds },
          businessId: bId,
        },
      });
      if (validBranches.length !== branchIds.length) {
        throw new BadRequestException('One or more selected branches are invalid');
      }
    }

    return this.prisma.$transaction(async (tx) => {
      if (branchIds !== undefined) {
        await tx.customerBranch.deleteMany({
          where: { customerId: id },
        });
      }

      const updateData: any = {
        ...data,
      };
      if (trimmedName !== undefined) updateData.name = trimmedName;
      if (trimmedPhone !== undefined) updateData.phone = trimmedPhone;
      if (trimmedEmail !== undefined) updateData.email = trimmedEmail;
      if (data.businessName !== undefined) updateData.businessName = data.businessName ? data.businessName.trim() : null;
      if (data.address !== undefined) updateData.address = data.address ? data.address.trim() : null;
      if (data.taxNumber !== undefined) updateData.taxNumber = data.taxNumber ? data.taxNumber.trim() : null;
      if (data.isActive !== undefined) {
        updateData.isActive = typeof data.isActive === 'string' ? data.isActive === 'true' : Boolean(data.isActive);
      }
      if (data.allowCredit !== undefined) {
        updateData.allowCredit = typeof data.allowCredit === 'string' ? data.allowCredit === 'true' : Boolean(data.allowCredit);
      }

      return tx.customer.update({
        where: { id },
        data: {
          ...updateData,
          branches: branchIds && branchIds.length > 0
            ? {
                create: branchIds.map((branchId) => ({
                  branchId,
                })),
              }
            : undefined,
        },
        include: {
          customerGroup: true,
          branches: {
            include: {
              branch: true,
            },
          },
        },
      });
    });
  }

  async remove(id: string, businessId: string) {
    const customer = await this.findOne(id, businessId);

    if (customer.isDefault || customer.name.toLowerCase() === 'walk-in customer') {
      throw new BadRequestException('The default Walk-in Customer cannot be deleted');
    }

    // 1. Check if customer has active sales, advances, payments, or returns
    const [salesCount, advancesCount, paymentsCount, returnsCount] = await Promise.all([
      this.prisma.sale.count({ where: { customerId: id } }),
      this.prisma.customerAdvance.count({ where: { customerId: id } }),
      this.prisma.salePayment.count({ where: { customerId: id } }),
      this.prisma.salesReturn.count({ where: { customerId: id } }),
    ]);

    const totalTransactions = salesCount + advancesCount + paymentsCount + returnsCount;
    if (totalTransactions > 0) {
      throw new BadRequestException(
        `Cannot delete customer because they have ${totalTransactions} associated record(s) (${salesCount} sale(s), ${advancesCount} advance(s), ${paymentsCount} payment(s), ${returnsCount} return(s)). Please deactivate this customer instead.`
      );
    }

    return this.prisma.customer.delete({
      where: { id },
    });
  }
}
