# HRM System — Clean SaaS UI/UX Theme Transformation Prompt

## Role

Act as a **Senior UI/UX Designer, SaaS Design System Architect, Color Theory Expert, Accessibility Specialist, and Product Designer**.

Your job is to completely redesign and standardize the existing **HRM (Human Resource Management) System** UI into a **clean, modern, premium, professional SaaS product**.

Do not make the interface unnecessarily colorful, decorative, crowded, or complicated.

The final result should feel like a high-quality product inspired by modern SaaS applications such as **Linear, Vercel, Stripe, Notion, and modern enterprise dashboards**, while maintaining its own visual identity.

---

# 1. Main Design Goal

Transform the entire HRM System into a:

- Clean UI
- Minimal UI
- Modern SaaS interface
- Professional enterprise product
- Premium-looking dashboard
- Consistent design system
- Highly readable interface
- Responsive interface
- Accessible interface
- Scalable component system
- Light + Dark mode experience

The UI should communicate:

> **Trust + Productivity + Simplicity + Professionalism**

Avoid visual noise.

Every element should have a clear purpose.

---

# 2. Design Philosophy

Follow these principles throughout the entire application:

### Clean First

Prefer whitespace, hierarchy, alignment, and typography over decoration.

### Less Is More

Do not add unnecessary:

- gradients
- glowing effects
- excessive shadows
- giant icons
- oversized cards
- decorative illustrations
- random colors
- excessive animations
- excessive rounded corners

### Visual Hierarchy

Every page should clearly communicate:

1. Where am I?
2. What information matters most?
3. What action should I take?
4. What information is secondary?

### Consistency

The same:

- colors
- spacing
- typography
- borders
- radii
- buttons
- inputs
- badges
- tables
- cards
- dialogs
- dropdowns
- navigation patterns

must be reused throughout the entire HRM system.

---

# 3. Color Theory Direction

Act as a professional color theorist.

Use a **restrained Indigo-based SaaS palette**.

The primary color should communicate:

- trust
- intelligence
- professionalism
- technology
- reliability

Avoid using multiple competing brand colors.

## Primary Palette

```text
Primary 500: #4F46E5
Primary 600: #4338CA
Primary 700: #3730A3
Primary 400: #6366F1
Primary 300: #818CF8
Primary 100: #E0E7FF
Primary 50:  #EEF2FF
```

Use the primary color mainly for:

- primary buttons
- active navigation
- links
- focused states
- selected states
- important indicators
- charts
- key actions

Do not use the primary color everywhere.

---

# 4. Neutral Color System

Use neutral colors to create visual breathing room.

## Light Mode

```text
Background:        #F8FAFC
Surface:           #FFFFFF
Surface Secondary: #F1F5F9

Text Primary:      #0F172A
Text Secondary:    #475569
Text Muted:        #64748B
Text Disabled:     #94A3B8

Border:            #E2E8F0
Border Strong:     #CBD5E1
```

## Dark Mode

```text
Background:        #0B1120
Surface:           #111827
Surface Secondary: #172033

Text Primary:      #F8FAFC
Text Secondary:    #CBD5E1
Text Muted:        #94A3B8
Text Disabled:     #64748B

Border:            #1E293B
Border Strong:     #334155
```

Do not create dark mode by simply inverting the light theme.

Dark mode must be intentionally designed.

---

# 5. Semantic Colors

Use semantic colors consistently.

## Success

```text
Success:       #16A34A
Success Light: #DCFCE7
```

## Warning

```text
Warning:       #D97706
Warning Light: #FEF3C7
```

## Error

```text
Error:       #DC2626
Error Light: #FEE2E2
```

## Info

```text
Info:       #0284C7
Info Light: #E0F2FE
```

Semantic colors should communicate meaning, not decoration.

Do not use red, green, yellow, or blue randomly.

---

# 6. Typography

Use **Inter** or **Geist** as the primary UI font.

If the project already has a good font system, preserve the existing font only if it meets modern SaaS readability standards.

## Typography Scale

```text
Display:  36px / 44px / 700
H1:       30px / 38px / 700
H2:       24px / 32px / 650
H3:       20px / 28px / 600
H4:       16px / 24px / 600

Body Large: 16px / 24px / 400
Body:       14px / 22px / 400
Body Small: 13px / 20px / 400

Label:      12px / 18px / 500
Caption:    11px / 16px / 400
```

Use font weight intentionally.

Do not make everything bold.

---

# 7. Spacing System

Use a consistent spacing scale.

```text
4px
8px
12px
16px
20px
24px
32px
40px
48px
64px
```

Prefer predictable spacing over manually chosen values.

Maintain consistent:

- page padding
- card padding
- section spacing
- form spacing
- table spacing
- navigation spacing

---

# 8. Border Radius

Use moderate rounded corners.

Recommended:

```text
Small:  6px
Medium: 8px
Large:  12px
XL:     16px
```

Default cards:

```text
border-radius: 12px
```

Avoid excessive pill-shaped elements.

Use pills mainly for:

- statuses
- tags
- filters
- compact indicators

---

# 9. Shadows

Keep shadows extremely subtle.

Prefer:

```text
border + subtle shadow
```

instead of heavy floating shadows.

Avoid:

- huge shadows
- glowing shadows
- neon effects
- excessive depth

The UI should feel flat, clean, and premium.

---

# 10. Layout

Use a professional SaaS dashboard structure.

## Desktop

```text
┌──────────────────────────────────────────────┐
│ Sidebar │ Top Navigation                     │
│         ├────────────────────────────────────┤
│         │ Page Header                        │
│         │                                    │
│         │ Main Content                       │
│         │                                    │
│         │ Cards / Tables / Charts            │
│         │                                    │
└─────────┴────────────────────────────────────┘
```

### Sidebar

- Clean
- Compact
- Fixed/sticky where appropriate
- Clear active state
- Simple icons
- Minimal separators
- User profile at bottom

### Top Bar

Include only useful controls:

- Search
- Notifications
- Theme switcher
- User profile
- Context actions

Do not overcrowd the header.

---

# 11. Dashboard

The dashboard should immediately communicate the organization's current state.

Use KPI cards such as:

- Total Employees
- Present Today
- On Leave
- New Employees
- Attendance Rate
- Payroll
- Pending Requests

Each KPI card should contain:

- clear label
- large value
- small contextual change
- optional icon
- optional comparison

Avoid making every KPI card visually different.

---

# 12. Cards

Cards should be:

- clean
- consistent
- spacious
- easy to scan

Default:

```text
background: surface
border: 1px solid border
radius: 12px
```

Avoid:

- random gradients
- colorful backgrounds
- oversized icons
- unnecessary illustrations

---

# 13. Tables

HRM systems rely heavily on tables.

Tables must be highly readable.

Use:

- clear headers
- sufficient row height
- subtle separators
- hover state
- sorting
- filtering
- pagination
- search
- bulk actions where appropriate

Example structure:

```text
Employee | Department | Position | Status | Joined | Actions
```

Status should use semantic badges.

Do not make entire table rows colorful.

---

# 14. Employee Profiles

Employee profile pages should feel organized and professional.

Recommended sections:

- Profile summary
- Personal information
- Contact information
- Employment information
- Attendance
- Leave
- Payroll
- Performance
- Documents
- Activity history

Use tabs where necessary.

Do not put everything on one enormous page.

---

# 15. Forms

Forms should be simple and predictable.

Inputs should have:

- clear labels
- optional helper text
- clear focus state
- validation state
- error messages
- consistent height

Recommended input height:

```text
40px–44px
```

Primary actions should be visually stronger than secondary actions.

---

# 16. Buttons

Use a clear hierarchy.

### Primary

Indigo filled button.

Used for:

- Create Employee
- Save
- Submit
- Approve
- Add

### Secondary

Neutral outlined button.

### Ghost

Minimal button for low-priority actions.

### Destructive

Red button only for dangerous actions.

Do not make every button primary.

---

# 17. Status Badges

Use consistent semantic badges.

Examples:

```text
Active
Inactive
Pending
Approved
Rejected
On Leave
Present
Absent
Late
Remote
Probation
Terminated
```

Keep badge colors soft.

Example:

```text
Active → green background + green text
Pending → amber background + amber text
Rejected → red background + red text
On Leave → indigo/blue background + matching text
```

---

# 18. Charts

Charts should be minimal and easy to understand.

Use the primary indigo color as the main visualization color.

Secondary chart colors should be limited.

Avoid rainbow charts.

Use:

- clean axes
- subtle grid lines
- clear tooltips
- readable legends
- meaningful labels

Recommended charts:

- Attendance trend
- Leave distribution
- Employee growth
- Department distribution
- Payroll overview
- Recruitment funnel

---

# 19. Navigation

Create clear information architecture.

Suggested navigation:

```text
Dashboard

People
  Employees
  Departments
  Positions

Attendance
  Attendance
  Timesheets

Leave
  Leave Requests
  Leave Policies

Payroll
  Payroll
  Payslips

Performance
  Reviews
  Goals

Recruitment
  Candidates
  Job Posts

Reports

Settings
```

Use icons from a consistent icon library such as **Lucide**.

Never mix multiple icon styles.

---

# 20. Search

Implement a professional SaaS search experience.

Search should support:

- employees
- departments
- pages
- actions
- records

Use keyboard shortcuts where appropriate.

Example:

```text
⌘ K
```

or

```text
Ctrl K
```

The search interface should feel fast and lightweight.

---

# 21. Notifications

Create a clean notification center.

Notifications should clearly distinguish:

- unread
- read
- important
- informational

Do not use excessive red notification indicators.

---

# 22. Modals and Dialogs

Modals should be:

- focused
- compact
- clearly structured
- easy to close

Use modals for:

- confirmations
- quick creation
- destructive actions
- short forms

Use full pages for complex workflows.

---

# 23. Empty States

Every empty state should be helpful.

Instead of:

> No data.

Use:

> No employees found

Then explain briefly what the user can do.

Example:

```text
No employees yet

Add your first employee to start managing your workforce.

[ Add Employee ]
```

---

# 24. Loading States

Use:

- skeleton loaders
- subtle spinners where necessary
- optimistic UI when appropriate

Avoid blocking the entire screen unnecessarily.

Skeletons should match the final content layout.

---

# 25. Error States

Errors must be understandable.

Never expose raw technical errors to normal users.

Instead of:

```text
500 Internal Server Error
```

prefer:

```text
Something went wrong

We couldn't load the employee information.
Please try again.

[ Try Again ]
```

---

# 26. Responsive Design

The entire HRM system must be responsive.

## Desktop

Use full sidebar + dashboard layout.

## Tablet

Optimize spacing and navigation.

## Mobile

Use:

- bottom navigation or collapsible sidebar
- stacked cards
- horizontally scrollable tables where necessary
- simplified headers
- touch-friendly controls

Minimum touch target:

```text
44px
```

Do not simply shrink the desktop UI.

Redesign layouts intelligently for mobile.

---

# 27. Accessibility

Follow WCAG principles.

Ensure:

- readable contrast
- keyboard navigation
- visible focus states
- semantic HTML
- accessible labels
- proper button states
- meaningful error messages
- screen-reader-friendly controls

Do not rely only on color to communicate status.

Example:

```text
● Active
```

rather than relying purely on a green color.

---

# 28. Animation

Animations should be subtle.

Use approximately:

```text
120ms–250ms
```

for UI transitions.

Good:

- hover
- focus
- dropdown
- modal
- sidebar
- page transitions
- loading states

Avoid:

- excessive bouncing
- dramatic transitions
- distracting animations

The interface should feel fast.

---

# 29. Dark Mode

Create a first-class dark mode.

Do not use pure black backgrounds everywhere.

Preferred:

```text
#0B1120
#111827
#172033
```

Maintain hierarchy through:

- surface differences
- borders
- typography
- subtle elevation

Charts and badges must also be optimized for dark mode.

---

# 30. Design Tokens

Create centralized design tokens.

Example:

```css
--color-primary: #4F46E5;
--color-primary-hover: #4338CA;

--color-background: #F8FAFC;
--color-surface: #FFFFFF;

--color-text-primary: #0F172A;
--color-text-secondary: #475569;
--color-text-muted: #64748B;

--color-border: #E2E8F0;

--color-success: #16A34A;
--color-warning: #D97706;
--color-error: #DC2626;
--color-info: #0284C7;

--radius-sm: 6px;
--radius-md: 8px;
--radius-lg: 12px;
--radius-xl: 16px;

--spacing-1: 4px;
--spacing-2: 8px;
--spacing-3: 12px;
--spacing-4: 16px;
--spacing-5: 20px;
--spacing-6: 24px;
--spacing-8: 32px;
```

Do not hardcode random colors throughout the application.

---

# 31. Component Consistency

Audit every existing component.

Standardize:

- Button
- Input
- Select
- Checkbox
- Radio
- Switch
- Badge
- Avatar
- Card
- Table
- Dropdown
- Tooltip
- Modal
- Drawer
- Tabs
- Pagination
- Breadcrumb
- Toast
- Alert
- Date picker
- Calendar
- Search
- Charts

Every component should belong to the same design language.

---

# 32. Existing UI Transformation Rules

Do NOT blindly rebuild the entire application logic.

Preserve:

- functionality
- routes
- business logic
- API integrations
- database behavior
- authentication
- permissions
- existing features

Focus primarily on the **visual and UX transformation**.

If a component is poorly structured, refactor it only when necessary to achieve the new design system.

Do not break existing functionality.

---

# 33. Remove Visual Problems

Identify and remove:

- inconsistent colors
- random border radii
- inconsistent spacing
- oversized headings
- excessive shadows
- unnecessary gradients
- duplicated UI patterns
- inconsistent button sizes
- inconsistent icon sizes
- poor alignment
- cramped layouts
- excessive whitespace
- unreadable tables
- low contrast
- visual clutter

---

# 34. Premium SaaS Feel

The final product should feel:

```text
Clean
Calm
Fast
Professional
Reliable
Modern
Premium
Enterprise-ready
```

It should NOT feel:

```text
Cheap
Colorful
Crowded
Generic
Template-like
Over-designed
```

---

# 35. Final UI Review

Before considering the redesign complete, perform a full UI/UX audit.

Check:

### Visual

- Is the color palette consistent?
- Is the spacing consistent?
- Is typography consistent?
- Are cards consistent?
- Are buttons consistent?
- Are icons consistent?

### UX

- Is navigation obvious?
- Are primary actions obvious?
- Are forms easy to complete?
- Are tables easy to scan?
- Are empty states helpful?
- Are errors understandable?

### Accessibility

- Is contrast sufficient?
- Are focus states visible?
- Can the UI be navigated by keyboard?
- Are labels meaningful?
- Does color alone communicate important information?

### Responsive

- Desktop
- Laptop
- Tablet
- Mobile

### Dark Mode

- Correct surfaces
- Correct contrast
- Correct borders
- Correct semantic colors
- Correct charts
- Correct hover/focus states

---

# 36. Important AI Instruction

**Do not redesign each page independently.**

First create a unified design system.

Then apply that design system consistently across the entire HRM System.

Think like a **Product Designer**, not a page decorator.

Before changing a component, ask:

> Does this component belong to the same visual system as the rest of the application?

If not, redesign it.

Always prioritize:

**Consistency → Clarity → Accessibility → Usability → Aesthetics**

in that order.

---

# 37. Final Command

Now analyze the existing HRM System and completely transform its visual language according to this specification.

**Act like a Senior UI/UX Designer + SaaS Design System Architect + Color Theory Expert.**

Create a cohesive, clean, modern, premium HRM SaaS experience.

Do not introduce unnecessary visual complexity.

Do not randomly change colors.

Do not create inconsistent components.

Do not sacrifice usability for aesthetics.

Do not break existing functionality.

The final interface should look like a **real production-ready SaaS product**, not a generic admin template.

**Make every screen feel like it belongs to the same product.**
