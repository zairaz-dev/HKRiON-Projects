export const RegisterBusinessBodySchema = {
  type: 'object',
  properties: {
    businessName: { type: 'string', example: 'HKR Retail Supermarket' },
    industry: { type: 'string', example: 'Retail & Supermarket' },
    phone: { type: 'string', example: '9876543210' },
    phoneCodeId: { type: 'string', example: 'pc_in_91' },
    countryId: { type: 'string', example: 'country_in' },
    currencyId: { type: 'string', example: 'curr_inr' },
    ownerName: { type: 'string', example: 'Ilham Hkr' },
    email: { type: 'string', example: 'ilham@hkr.com' },
    password: { type: 'string', example: 'Password@123' },
  },
  required: [
    'businessName',
    'industry',
    'phone',
    'phoneCodeId',
    'countryId',
    'currencyId',
    'ownerName',
    'email',
    'password',
  ],
};

export const RegisterBusinessResponseSchema = {
  type: 'object',
  properties: {
    token: { type: 'string', example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...' },
    user: {
      type: 'object',
      properties: {
        id: { type: 'string', example: 'usr_owner_01' },
        name: { type: 'string', example: 'Ilham Hkr' },
        email: { type: 'string', example: 'ilham@hkr.com' },
        role: { type: 'string', example: 'admin' },
        businessId: { type: 'string', example: 'biz_new_123' },
      },
    },
    business: {
      type: 'object',
      properties: {
        id: { type: 'string', example: 'biz_new_123' },
        name: { type: 'string', example: 'HKR Retail Supermarket' },
        industry: { type: 'string', example: 'Retail & Supermarket' },
      },
    },
  },
};

export const RegisterBusinessGoogleBodySchema = {
  type: 'object',
  properties: {
    businessName: { type: 'string', example: 'HKR Tech Solutions' },
    industry: { type: 'string', example: 'Information Technology' },
    phone: { type: 'string', example: '9876543210' },
    phoneCodeId: { type: 'string', example: 'pc_in_91' },
    countryId: { type: 'string', example: 'country_in' },
    currencyId: { type: 'string', example: 'curr_inr' },
    token: { type: 'string', example: 'ya29.a0AfH6SMD_GOOGLE_ID_OR_ACCESS_TOKEN' },
  },
  required: [
    'businessName',
    'industry',
    'phone',
    'phoneCodeId',
    'countryId',
    'currencyId',
    'token',
  ],
};

export const RegisterBusinessGoogleResponseSchema = RegisterBusinessResponseSchema;

export const GetBusinessResponseSchema = {
  type: 'object',
  properties: {
    id: { type: 'string', example: 'biz_12345' },
    name: { type: 'string', example: 'HKR Retail Supermarket' },
    industry: { type: 'string', example: 'Retail & Supermarket' },
    phone: { type: 'string', example: '9876543210' },
    country: {
      type: 'object',
      properties: {
        id: { type: 'string', example: 'country_in' },
        name: { type: 'string', example: 'India' },
        code: { type: 'string', example: 'IN' },
      },
    },
    currency: {
      type: 'object',
      properties: {
        id: { type: 'string', example: 'curr_inr' },
        name: { type: 'string', example: 'Indian Rupee' },
        symbol: { type: 'string', example: '₹' },
        code: { type: 'string', example: 'INR' },
      },
    },
    phoneCode: {
      type: 'object',
      properties: {
        id: { type: 'string', example: 'pc_in_91' },
        code: { type: 'string', example: '+91' },
      },
    },
  },
};

export const UpdateBusinessBodySchema = {
  type: 'object',
  properties: {
    name: { type: 'string', example: 'HKR Hypermarket Pvt Ltd' },
    phone: { type: 'string', example: '9998887776' },
    industry: { type: 'string', example: 'Wholesale & Retail' },
  },
};
