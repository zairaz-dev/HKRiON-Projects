import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { signToken, comparePassword } from '@/lib/auth';

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json();

    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email and password are required.' },
        { status: 400 }
      );
    }

    const cleanEmail = email.trim().toLowerCase();

    // 1. Fetch user exclusively from Database
    const userInDb = await prisma.user.findUnique({
      where: { email: cleanEmail },
      include: {
        role: true,
      },
    });

    if (!userInDb) {
      return NextResponse.json(
        { error: 'Invalid email or password.' },
        { status: 401 }
      );
    }

    // 2. Verify password against hashed password in Database
    const isMatch = await comparePassword(password, userInDb.password);
    if (!isMatch) {
      return NextResponse.json(
        { error: 'Invalid email or password.' },
        { status: 401 }
      );
    }

    // Extract role from DB relation or default
    const userRole = (userInDb.role?.name?.toUpperCase() || 'CUSTOMER') as 'ADMIN' | 'EMPLOYEE' | 'CUSTOMER';

    const authenticatedUser = {
      id: userInDb.id,
      name: userInDb.name,
      email: userInDb.email,
      role: userRole,
    };

    // 3. Issue Token & Cookie
    const token = await signToken(authenticatedUser);

    const redirectUrl =
      authenticatedUser.role === 'ADMIN'
        ? '/dashboard/admin'
        : authenticatedUser.role === 'EMPLOYEE'
        ? '/dashboard/employee'
        : '/dashboard/customer';

    const response = NextResponse.json(
      {
        success: true,
        message: 'Login successful!',
        user: authenticatedUser,
        redirectUrl,
      },
      { status: 200 }
    );

    response.cookies.set({
      name: 'hkrion_auth_token',
      value: token,
      httpOnly: true,
      path: '/',
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7, // 7 days
    });

    return response;
  } catch (error) {
    console.error('Database Authentication Error:', error);
    return NextResponse.json(
      { error: 'Database connection or authentication error occurred.' },
      { status: 500 }
    );
  }
}
