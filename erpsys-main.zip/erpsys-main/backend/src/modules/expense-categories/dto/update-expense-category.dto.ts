export class UpdateExpenseCategoryDto {
  name?: string;
  code?: string;
  description?: string;
  parentId?: string;
  businessId?: string;
  branchIds?: string[];
  isActive?: boolean;
  updatedById?: string;
}
