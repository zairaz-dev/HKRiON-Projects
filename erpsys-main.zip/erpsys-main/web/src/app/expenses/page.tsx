"use strict";
"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import { LoadingSession } from "@/components/ui/loading-session";
import {
  CreditCard,
  Plus,
  Edit2,
  Trash2,
  Loader2,
  CheckCircle,
  AlertCircle,
  Building2,
  Tag,
  Calendar,
  Eye
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { DataTable, ColumnDef, ActionsDropdown } from "@/components/ui/table";
import { ActionItem } from "@/components/ui/actions-dropdown";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";
import {
  ExpenseItem,
  ExpenseDialog,
  ExpenseDeleteDialog,
  ExpensePaymentDialog,
  ExpensePaymentsListDialog,
  useExpensesQuery
} from "@/features/expenses";
import { useExpenseCategoriesQuery } from "@/features/expense-categories/hooks/use-expense-categories";
import { useBranchesQuery } from "@/features/expense-categories/hooks/use-expense-categories";
import { useCurrency } from "@/hooks/use-currency";

function ExpenseManagementPageContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Notifications
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Modals
  const [isDialogOpen, setIsDialogOpen] = useState<boolean>(false);
  const [editingExpense, setEditingExpense] = useState<ExpenseItem | null>(null);
  const [isDeleteOpen, setIsDeleteOpen] = useState<boolean>(false);
  const [expenseToDelete, setExpenseToDelete] = useState<ExpenseItem | null>(null);
  const [isPaymentOpen, setIsPaymentOpen] = useState<boolean>(false);
  const [expenseToPay, setExpenseToPay] = useState<ExpenseItem | null>(null);
  const [isPaymentsListOpen, setIsPaymentsListOpen] = useState<boolean>(false);
  const [expenseForPaymentsList, setExpenseForPaymentsList] = useState<ExpenseItem | null>(null);

  // URL-driven State (Rule #3: Store filters/page/search in URL Search Params)
  const selectedBranchFilter = searchParams.get("branchId") || "all";
  const selectedCategoryFilter = searchParams.get("categoryId") || "all";
  const currentPage = Number(searchParams.get("page")) || 1;
  const searchQuery = searchParams.get("search") || "";
  const limit = 10;

  // Authenticate user on mount
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  const businessId = currentUser?.businessId || "";
  const { symbol, format } = useCurrency(businessId);

  // Data Queries
  const {
    data: expensesData = { items: [], total: 0, totalPages: 0 },
    isLoading: expensesLoading,
    error: expensesError
  } = useExpensesQuery(businessId, {
    branchId: selectedBranchFilter,
    categoryId: selectedCategoryFilter,
    search: searchQuery,
    page: currentPage,
    limit
  });

  const { data: categoriesList = [] } = useExpenseCategoriesQuery(businessId);
  const { data: branchesList = [] } = useBranchesQuery(businessId, currentUser?.id);

  // Calculate page totals
  const pageTotalAmount = expensesData.items?.reduce((sum, item) => sum + item.amount, 0) || 0;
  const pageTotalPaid = expensesData.items?.reduce((sum, item) => sum + item.amountPaid, 0) || 0;
  const pageTotalDue = pageTotalAmount - pageTotalPaid;

  // Handle Query Errors
  useEffect(() => {
    if (expensesError) {
      setError(expensesError.message || "Failed to load expenses.");
    }
  }, [expensesError]);

  // Auto-dismiss notifications
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  // Update URL Search Params
  const updateFilters = (updates: Record<string, string | number>) => {
    const params = new URLSearchParams(searchParams.toString());
    Object.entries(updates).forEach(([key, value]) => {
      if (value === "all" || value === "") {
        params.delete(key);
      } else {
        params.set(key, value.toString());
      }
    });
    // Reset to page 1 on filter changes unless page is explicitly updated
    if (!updates.page) {
      params.delete("page");
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  const handleOpenCreateModal = () => {
    setEditingExpense(null);
    setIsDialogOpen(true);
  };

  const handleOpenEditModal = (expense: ExpenseItem) => {
    setEditingExpense(expense);
    setIsDialogOpen(true);
  };

  const handleOpenDeleteModal = (expense: ExpenseItem) => {
    setExpenseToDelete(expense);
    setIsDeleteOpen(true);
  };

  const handleOpenPaymentModal = (expense: ExpenseItem) => {
    setExpenseToPay(expense);
    setIsPaymentOpen(true);
  };

  const handleOpenPaymentsListModal = (expense: ExpenseItem) => {
    setExpenseForPaymentsList(expense);
    setIsPaymentsListOpen(true);
  };

  // Table Columns Definition
  const columns: ColumnDef<ExpenseItem>[] = [
    {
      header: "Ref No",
      searchable: true,
      render: (expense) => (
        <span className="font-mono text-xs font-semibold text-foreground">
          {expense.refNo || "N/A"}
        </span>
      ),
    },
    {
      header: "Category",
      render: (expense) => (
        <span className="inline-flex items-center gap-1.5 text-xs text-foreground/80 font-medium">
          <Tag className="h-3.5 w-3.5 text-muted-foreground/60" />
          {expense.category?.name || "Uncategorized"}
        </span>
      ),
    },
    {
      header: "Branch",
      render: (expense) => (
        <span className="inline-flex items-center gap-1.5 text-xs text-foreground/80 font-medium">
          <Building2 className="h-3.5 w-3.5 text-muted-foreground/60" />
          {expense.branch?.name || "Global"}
        </span>
      ),
    },
    {
      header: "Total Amount",
      render: (expense) => (
        <span className="font-bold text-foreground text-xs">
          {format(expense.amount)}
        </span>
      ),
    },
    {
      header: "Paid Amount",
      render: (expense) => (
        <span className="font-semibold text-emerald-600 dark:text-emerald-400 text-xs">
          {format(expense.amountPaid)}
        </span>
      ),
    },
    {
      header: "Due Amount",
      render: (expense) => {
        const due = expense.amount - expense.amountPaid;
        return (
          <span className={`font-semibold text-xs ${due > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-muted-foreground'}`}>
            {format(due)}
          </span>
        );
      },
    },
    {
      header: "Payment Status",
      render: (expense) => {
        const colors = {
          PAID: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
          PARTIAL: "bg-blue-500/10 text-blue-500 border-blue-500/20",
          DUE: "bg-amber-500/10 text-amber-500 border-amber-500/20",
        };
        return (
          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${colors[expense.paymentStatus]}`}>
            {expense.paymentStatus}
          </span>
        );
      },
    },
    {
      header: "Expense Date",
      render: (expense) => (
        <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
          <Calendar className="h-3.5 w-3.5 text-muted-foreground/60" />
          {new Date(expense.expenseDate).toLocaleDateString()}
        </span>
      ),
    },
    {
      header: "Actions",
      render: (expense) => {
        const actions: ActionItem[] = [];
        if (expense.paymentStatus !== "PAID") {
          actions.push({
            label: "Add Payment",
            onClick: () => handleOpenPaymentModal(expense),
            icon: <CreditCard className="h-3.5 w-3.5" />,
          });
        }
        actions.push({
          label: "View Payments",
          onClick: () => handleOpenPaymentsListModal(expense),
          icon: <Eye className="h-3.5 w-3.5" />,
        });
        actions.push(
          {
            label: "Edit",
            onClick: () => handleOpenEditModal(expense),
            icon: <Edit2 className="h-3.5 w-3.5" />,
          },
          {
            label: "Delete",
            onClick: () => handleOpenDeleteModal(expense),
            icon: <Trash2 className="h-3.5 w-3.5" />,
            variant: "destructive",
          }
        );
        return <ActionsDropdown actions={actions} />;
      },
    },
  ];

  // Custom Filters for DataTable
  const customFilters = (
    <div className="flex flex-wrap items-center gap-3">

      {/* Category Filter */}
      <div className="flex items-center gap-2">
        <span className="text-xs font-semibold text-muted-foreground whitespace-nowrap">
          Category:
        </span>
        <select
          value={selectedCategoryFilter}
          onChange={(e) => updateFilters({ categoryId: e.target.value })}
          className="h-9 rounded-md border border-input bg-background px-3 py-1 text-xs shadow-sm focus:outline-none focus:ring-1 focus:ring-ring"
        >
          <option value="all">All Categories</option>
          {categoriesList.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </div>

      {/* Branch Filter */}
      <div className="flex items-center gap-2">
        <span className="text-xs font-semibold text-muted-foreground whitespace-nowrap">
          Branch:
        </span>
        <select
          value={selectedBranchFilter}
          onChange={(e) => updateFilters({ branchId: e.target.value })}
          className="h-9 rounded-md border border-input bg-background px-3 py-1 text-xs shadow-sm focus:outline-none focus:ring-1 focus:ring-ring"
        >
          <option value="all">All Branches</option>
          {branchesList.map((b) => (
            <option key={b.id} value={b.id}>
              {b.name}
            </option>
          ))}
        </select>
      </div>
    </div>
  );

  if (isAuthenticated === null) {
    return <LoadingSession />;
  }

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3">
          <Loader2 className="h-10 w-10 animate-spin text-primary mx-auto" />
          <p className="text-sm font-medium">Authenticating... Redirecting to login.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/expenses" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Expense Management" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <CreditCard className="h-7 w-7 text-primary" /> Expenses Tracker
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Track your business expenses, record payments, and manage categories.
              </p>
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Card className="bg-card/40 backdrop-blur-md border-border/50 shadow-sm">
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider">Total Expenses</p>
                  <h3 className="text-xl font-extrabold text-foreground mt-1">{format(pageTotalAmount)}</h3>
                </div>
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                  <CreditCard className="w-5 h-5" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card/40 backdrop-blur-md border-border/50 shadow-sm">
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider">Paid Amount</p>
                  <h3 className="text-xl font-extrabold text-emerald-600 dark:text-emerald-400 mt-1">{format(pageTotalPaid)}</h3>
                </div>
                <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-500">
                  <CheckCircle className="w-5 h-5" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card/40 backdrop-blur-md border-border/50 shadow-sm">
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider">Due Amount</p>
                  <h3 className="text-xl font-extrabold text-amber-600 dark:text-amber-400 mt-1">{format(pageTotalDue)}</h3>
                </div>
                <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-500">
                  <AlertCircle className="w-5 h-5" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Banner Notifications */}
          {successMessage && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 animate-in fade-in slide-in-from-top-4 duration-300">
              <CheckCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive animate-in fade-in slide-in-from-top-4 duration-300">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          {/* Main Table Content */}
          {expensesLoading ? (
            <div className="flex h-64 items-center justify-center">
              <div className="text-center space-y-2">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
                <span className="text-sm text-muted-foreground block">Loading expenses...</span>
              </div>
            </div>
          ) : (
            <DataTable
              data={expensesData.items}
              columns={columns}
              searchPlaceholder="Search ref no, notes..."
              serverSide={true}
              totalItems={expensesData.total}
              totalPages={expensesData.totalPages}
              currentPage={currentPage}
              onPageChange={(page) => updateFilters({ page })}
              searchQuery={searchQuery}
              onSearchQueryChange={(search) => updateFilters({ search, page: 1 })}
              onPageSizeChange={(size) => updateFilters({ limit: size, page: 1 })}
              actionButton={{
                label: "Add Expense",
                onClick: handleOpenCreateModal,
                icon: <Plus className="h-4 w-4" />
              }}
              customFilters={customFilters}
              reportTitle="Expenses Summary Report"
            />
          )}
        </main>
      </div>

      {/* Dialog Modals */}
      {currentUser && (
        <>
          <ExpenseDialog
            isOpen={isDialogOpen}
            onClose={() => setIsDialogOpen(false)}
            expense={editingExpense}
            currentUser={currentUser}
            onSuccess={(msg) => setSuccessMessage(msg)}
            onError={(msg) => setError(msg)}
          />

          <ExpenseDeleteDialog
            isOpen={isDeleteOpen}
            onClose={() => setIsDeleteOpen(false)}
            expense={expenseToDelete}
            currentUser={currentUser}
            onSuccess={(msg) => setSuccessMessage(msg)}
            onError={(msg) => setError(msg)}
          />

          <ExpensePaymentDialog
            isOpen={isPaymentOpen}
            onClose={() => setIsPaymentOpen(false)}
            expense={expenseToPay}
            currentUser={currentUser}
            onSuccess={(msg) => setSuccessMessage(msg)}
            onError={(msg) => setError(msg)}
          />

          <ExpensePaymentsListDialog
            isOpen={isPaymentsListOpen}
            onClose={() => setIsPaymentsListOpen(false)}
            expense={expenseForPaymentsList}
            currentUser={currentUser}
            onSuccess={(msg) => setSuccessMessage(msg)}
            onError={(msg) => setError(msg)}
          />
        </>
      )}
    </div>
  );
}

export default function ExpenseManagementPage() {
  return (
    <Suspense fallback={<LoadingSession />}>
      <ExpenseManagementPageContent />
    </Suspense>
  );
}
