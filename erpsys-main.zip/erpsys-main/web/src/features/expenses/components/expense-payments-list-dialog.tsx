import React from "react";
import { X, Loader2, Trash2, Calendar, CreditCard } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { User } from "@hkr/types";
import { ExpenseItem } from "../types";
import { useDeleteExpensePaymentMutation } from "../hooks/use-expenses";
import { useCurrency } from "@/hooks/use-currency";

interface ExpensePaymentsListDialogProps {
  isOpen: boolean;
  onClose: () => void;
  expense: ExpenseItem | null;
  currentUser: User;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

export function ExpensePaymentsListDialog({
  isOpen,
  onClose,
  expense,
  currentUser,
  onSuccess,
  onError,
}: ExpensePaymentsListDialogProps) {
  const deleteMutation = useDeleteExpensePaymentMutation();
  const businessId = currentUser?.businessId || "";
  const { symbol, format } = useCurrency(businessId);

  if (!isOpen || !expense) return null;

  const payments = expense.payments || [];

  const handleDelete = async (paymentId: string) => {
    if (!window.confirm("Are you sure you want to delete this payment record? This will increase the remaining due amount of this expense.")) {
      return;
    }

    try {
      await deleteMutation.mutateAsync({ paymentId, businessId });
      onSuccess("Payment record deleted successfully!");
      onClose(); // Close dialog to refresh state properly
    } catch (err: any) {
      onError(err.message || "Failed to delete payment record.");
    }
  };

  const isDeleting = deleteMutation.isPending;

  return (
    <Dialog
      isOpen={isOpen}
      onClose={onClose}
      size="lg"
      title={
        <>
          <CreditCard className="h-5 w-5 text-primary" />
          Payments History
        </>
      }
    >
      <div className="space-y-4">
        {/* Info header */}
        <div className="bg-muted/40 p-3 rounded-lg text-xs flex justify-between">
          <div>
            <span className="text-muted-foreground block font-medium">Ref No</span>
            <span className="font-extrabold text-foreground">{expense.refNo || expense.id}</span>
          </div>
          <div>
            <span className="text-muted-foreground block font-medium">Total Amount</span>
            <span className="font-extrabold text-foreground">{format(expense.amount)}</span>
          </div>
          <div>
            <span className="text-muted-foreground block font-medium">Remaining Due</span>
            <span className="font-extrabold text-amber-600 dark:text-amber-400">
              {format(expense.amount - expense.amountPaid)}
            </span>
          </div>
        </div>

        {/* Payments List */}
        {payments.length === 0 ? (
          <div className="text-center py-8 border border-dashed border-border/40 rounded-sm bg-secondary/10">
            <CreditCard className="h-8 w-8 text-muted-foreground/60 mx-auto mb-2" />
            <p className="text-sm font-semibold text-muted-foreground">No payment records found.</p>
            <p className="text-xs text-muted-foreground/60 mt-0.5">No payments have been recorded yet.</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-[40vh] overflow-y-auto pr-1">
            {payments.map((payment: any, index: number) => (
              <div
                key={payment.id}
                className="flex items-center justify-between p-3 border border-border/50 rounded-lg bg-background/50 hover:bg-background/80 transition-colors"
              >
                <div className="space-y-1.5 flex-1 pr-4">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-foreground">
                      Payment #{index + 1}
                    </span>
                    <span className="text-[10px] bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 font-extrabold px-1.5 py-0.5 rounded">
                      {format(payment.amount)}
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3.5 w-3.5" />
                      {new Date(payment.paymentDate).toLocaleDateString("en-IN", {
                        day: "2-digit",
                        month: "short",
                        year: "numeric",
                      })}
                    </span>
                    <span className="flex items-center gap-1 uppercase text-[10px] bg-secondary text-secondary-foreground font-bold px-1.5 py-0.5 rounded border border-border/40">
                      Method: {payment.paymentMethod?.name || "N/A"}
                    </span>
                  </div>

                  {payment.notes && (
                    <p className="text-xs text-muted-foreground/80 italic pl-1 border-l border-border mt-1">
                      Note: {payment.notes}
                    </p>
                  )}
                </div>

                <button
                  onClick={() => handleDelete(payment.id)}
                  disabled={isDeleting}
                  className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded transition-colors disabled:opacity-50"
                  title="Delete payment record"
                >
                  {isDeleting ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Trash2 className="h-4 w-4" />
                  )}
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Footer */}
        <div className="flex justify-end pt-3 border-t border-border/50">
          <Button variant="outline" onClick={onClose} className="h-9 text-xs">
            Close
          </Button>
        </div>
      </div>
    </Dialog>
  );
}
