'use client';

import { useState, useEffect } from 'react';
import { MessageCircle, ArrowUp } from 'lucide-react';

export default function FloatingWidgets() {
  const [showScroll, setShowScroll] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setShowScroll(true);
      } else {
        setShowScroll(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-50 flex flex-col items-center gap-3">
      
      {/* WhatsApp Button with Pulsing Glow Ring */}
      <a
        href="https://wa.me/94775014217?text=Hello%20HKRION%20(Pvt)%20Ltd,%20I%20would%20like%20to%20inquire%20about%20your%20services."
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat on WhatsApp"
        className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-[#1ABE56] text-black shadow-xl shadow-[#1ABE56]/50 flex items-center justify-center hover:scale-110 transition-all duration-300 group relative"
      >
        {/* Radar Ring */}
        <span className="absolute inset-0 rounded-full bg-[#1ABE56] animate-ping opacity-40 pointer-events-none" />
        
        <MessageCircle className="w-7 h-7 fill-black text-[#1ABE56] relative z-10" />
        <span className="absolute right-16 top-1/2 -translate-y-1/2 px-3.5 py-2 rounded-xl bg-black text-white font-mono text-xs border border-[#1ABE56]/50 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none shadow-2xl">
          💬 Chat Live with HKRION Team
        </span>
      </a>

      {/* Back to Top Button */}
      {showScroll && (
        <button
          onClick={scrollToTop}
          aria-label="Back to top"
          className="w-11 h-11 rounded-full bg-black/90 border border-[#1ABE56]/50 text-[#1ABE56] flex items-center justify-center hover:bg-[#1ABE56] hover:text-black transition-all shadow-lg hover:scale-110 animate-fade-in-up"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
      )}

    </div>
  );
}
