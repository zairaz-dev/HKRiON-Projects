import Navbar from '@/components/Navbar';
import Products from '@/components/Products';
import Footer from '@/components/Footer';
import FloatingWidgets from '@/components/FloatingWidgets';

export const metadata = {
  title: 'Products Suite | HKRION (Pvt) Ltd',
  description: 'Explore ready-to-deploy enterprise products: HKRION POS, HKRION ERP, HKRION HRM, HKRION CRM, HKRION Attendance, and HKRION Inventory.',
};

export default function ProductsPage() {
  return (
    <div className="min-h-screen bg-black text-neutral-100 flex flex-col font-sans">
      <Navbar />
      <main className="grow pt-24">
        
        {/* Dedicated Products Header Banner */}
        <section className="py-20 relative bg-neutral-950 border-b border-[#1ABE56]/30 overflow-hidden">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#1ABE56]/15 blur-[150px] rounded-full pointer-events-none" />
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-4">
            
            <h1 className="text-4xl sm:text-6xl font-extrabold text-white">
              HKRION <span className="gradient-text">Product Suite</span>
            </h1>
            <p className="text-neutral-300 max-w-2xl mx-auto text-base sm:text-lg leading-relaxed">
              Battle-tested software suites built for retail, warehouse management, staff payroll, customer relationships, and business intelligence.
            </p>
          </div>
        </section>

        <Products />
      </main>
      <Footer />
      <FloatingWidgets />
    </div>
  );
}
