import { NextResponse } from "next/server";
import { UserService } from "@/services/user.service";
import { SessionManager } from "@/core/auth/session";
import { SafeHttp } from "@/core/http/redirect";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  try {
    const session = await SessionManager.getCurrentSession();
    if (!session) {
      return SafeHttp.redirect("/login", request, 303);
    }

    const contentType = request.headers.get("content-type") || "";
    const isJson = contentType.includes("application/json");

    let id = "";
    let newPassword = "";
    let confirmPassword = "";

    if (isJson) {
      const body = await request.json();
      id = body.id || "";
      newPassword = body.newPassword || "";
      confirmPassword = body.confirmPassword || "";
    } else {
      const formData = await request.formData();
      id = (formData.get("id") as string) || "";
      newPassword = (formData.get("newPassword") as string) || "";
      confirmPassword = (formData.get("confirmPassword") as string) || "";
    }

    if (!id || !newPassword) {
      if (isJson) {
        return NextResponse.json({ success: false, error: "User ID and new password are required." }, { status: 400 });
      }
      return SafeHttp.redirect("/admin/users?error=Password+is+required", request, 303);
    }

    if (newPassword.length < 6) {
      if (isJson) {
        return NextResponse.json({ success: false, error: "Password must be at least 6 characters long." }, { status: 400 });
      }
      return SafeHttp.redirect("/admin/users?error=Password+must+be+at+least+6+characters", request, 303);
    }

    if (confirmPassword && newPassword !== confirmPassword) {
      if (isJson) {
        return NextResponse.json({ success: false, error: "Passwords do not match." }, { status: 400 });
      }
      return SafeHttp.redirect("/admin/users?error=Passwords+do+not+match", request, 303);
    }

    // Check user exists
    const targetUser = await UserService.getById(id);
    if (!targetUser) {
      if (isJson) {
        return NextResponse.json({ success: false, error: "User not found." }, { status: 404 });
      }
      return SafeHttp.redirect("/admin/users?error=User+not+found", request, 303);
    }

    const result = await UserService.updatePassword(id, newPassword);
    if (!result.success) {
      if (isJson) {
        return NextResponse.json({ success: false, error: result.error || "Failed to update password." }, { status: 400 });
      }
      return SafeHttp.redirect(`/admin/users?error=${encodeURIComponent(result.error || "Failed to update password")}`, request, 303);
    }

    revalidatePath("/admin/users");
    revalidatePath("/admin");

    if (isJson) {
      return NextResponse.json({ success: true, message: "Password updated successfully" });
    }

    return SafeHttp.redirect(`/admin/users?success=Password+updated+successfully`, request, 303);
  } catch (error: any) {
    console.error("Error updating user password:", error);
    const contentType = request.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      return NextResponse.json({ success: false, error: error.message || "Failed to update password" }, { status: 500 });
    }
    return SafeHttp.redirect(`/admin/users?error=${encodeURIComponent(error.message || "Failed to update password")}`, request, 303);
  }
}
