export type QuotationStatus = 'PENDING' | 'CONVERTED' | 'EXPIRED' | 'CANCELLED';

export interface QuotationLineItem {
  id?: string;
  quotationId?: string;
  variantId: string;
  quantity: number;
  unitPrice: number;
  discountAmount?: number;
  taxAmount?: number;
  subtotal: number;
  variant?: {
    id: string;
    sku: string;
    name: string;
    product?: {
      id: string;
      name: string;
    };
  };
}

export interface QuotationItem {
  id: string;
  quotationNumber: string;
  date: string;
  expiryDate?: string | null;
  status: QuotationStatus;
  discountType?: string | null;
  discountAmount: number;
  taxAmount: number;
  grandTotal: number;
  termsAndConditions?: string | null;
  notes?: string | null;
  customerId: string;
  branchId: string;
  businessId: string;
  createdById?: string | null;
  convertedSaleId?: string | null;
  customer: {
    id: string;
    name: string;
    phone?: string | null;
    email?: string | null;
    address?: string | null;
    taxNumber?: string | null;
  };
  branch: {
    id: string;
    name: string;
    phone?: string | null;
    email?: string | null;
    address?: string | null;
  };
  createdBy?: {
    id: string;
    name: string;
    email?: string | null;
  } | null;
  convertedSale?: {
    id: string;
    invoiceNumber: string;
    grandTotal?: number;
    saleDate?: string;
    status?: string;
  } | null;
  quotationLines: QuotationLineItem[];
  createdAt: string;
  updatedAt: string;
}

export interface CreateQuotationPayload {
  quotationNumber?: string;
  date?: string;
  expiryDate?: string;
  status?: QuotationStatus;
  discountType?: string;
  discountAmount?: number;
  taxAmount?: number;
  grandTotal: number;
  termsAndConditions?: string;
  notes?: string;
  customerId: string;
  branchId: string;
  quotationLines: {
    variantId: string;
    quantity: number;
    unitPrice: number;
    discountAmount?: number;
    taxAmount?: number;
    subtotal: number;
  }[];
}

export interface QuotationsQueryParams {
  branchId?: string;
  customerId?: string;
  status?: string;
  startDate?: string;
  endDate?: string;
  search?: string;
  page?: number;
  limit?: number;
}
