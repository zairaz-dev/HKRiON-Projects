'use client';

import { useState, useRef, useEffect } from 'react';
import { ArrowUpRight } from 'lucide-react';

const projects = [
  {
    title: 'HKRION Enterprise ERP Suite',
    category: 'ERP & Business Systems',
    description: 'A comprehensive cloud ERP solution featuring automated inventory tracking, HR analytics, financial ledger, and multi-branch management.',
    gradient: 'from-[#1ABE56]/30 to-black',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80',
    fallback: '/images/products/erp.png'
  },
  {
    title: 'Smart Cloud POS & Retail Engine',
    category: 'Web & POS Platform',
    description: 'High-speed point-of-sale software for retail chains with real-time barcode scanning, receipt generation, and live inventory sync.',
    gradient: 'from-emerald-600/30 to-black',
    image: 'https://images.unsplash.com/photo-1556742044-3c52d6e88c62?auto=format&fit=crop&w=800&q=80',
    fallback: '/images/products/pos.png'
  },
  {
    title: 'Digital Health & Clinic Portal',
    category: 'Healthcare App',
    description: 'HIPAA-compliant web portal for doctor appointment booking, patient medical history management, and automated SMS reminders.',
    gradient: 'from-green-600/30 to-black',
    image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=800&q=80',
    fallback: '/images/products/hrm.png'
  },
  {
    title: 'Automated Invoice & Document AI',
    category: 'AI & Automation',
    description: 'AI-assisted OCR platform for automated receipt parsing, invoice extraction, and ERP accounting reconciliation.',
    gradient: 'from-[#1ABE56]/30 to-black',
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80',
    fallback: '/images/products/crm.png'
  }
];

export default function Portfolio() {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Update active dot index based on scroll position
  const handleScroll = () => {
    if (!scrollRef.current) return;
    const container = scrollRef.current;
    const scrollPosition = container.scrollLeft;
    const cardWidth = container.firstElementChild?.clientWidth || 400;
    const gap = 24;
    const newIndex = Math.round(scrollPosition / (cardWidth + gap));
    setActiveIndex(Math.min(Math.max(0, newIndex), projects.length - 1));
  };

  // Scroll to a specific project card index
  const scrollToCard = (index: number) => {
    if (!scrollRef.current) return;
    const container = scrollRef.current;
    const card = container.children[index] as HTMLElement;
    if (card) {
      container.scrollTo({
        left: card.offsetLeft - container.offsetLeft,
        behavior: 'smooth'
      });
      setActiveIndex(index);
    }
  };

  // Automatic scrolling loop (every 3.5 seconds)
  useEffect(() => {
    if (isPaused) return;

    const interval = setInterval(() => {
      if (!scrollRef.current) return;
      const container = scrollRef.current;
      const maxScrollLeft = container.scrollWidth - container.clientWidth;

      if (container.scrollLeft >= maxScrollLeft - 10) {
        container.scrollTo({ left: 0, behavior: 'smooth' });
        setActiveIndex(0);
      } else {
        const nextIndex = (activeIndex + 1) % projects.length;
        scrollToCard(nextIndex);
      }
    }, 3500);

    return () => clearInterval(interval);
  }, [activeIndex, isPaused]);

  return (
    <section id="portfolio" className="py-24 relative bg-black overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Centered Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-14">
          <h2 className="text-xs font-semibold uppercase tracking-widest text-[#1ABE56] font-mono">
            FEATURED PROJECTS
          </h2>
          <p className="text-3xl sm:text-5xl font-semibold text-white tracking-tight">
            Solutions We Have <span className="gradient-text">Engineered</span>
          </p>
          <p className="text-neutral-400 text-base sm:text-lg">
            Explore some of our recent software enterprise projects built for clients across various industries.
          </p>
        </div>

        {/* Auto Scrolling Left to Right Container */}
        <div
          ref={scrollRef}
          onScroll={handleScroll}
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
          className="flex gap-5 overflow-x-auto snap-x snap-mandatory scroll-smooth pb-6 pt-2 scrollbar-none"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {projects.map((project, index) => (
            <div
              key={index}
              className="w-[82vw] sm:w-88 md:w-96 shrink-0 snap-start glass-card rounded-2xl overflow-hidden border border-[#1ABE56]/30 hover:border-[#1ABE56] transition-all duration-500 group flex flex-col justify-between bg-black/90 hover:-translate-y-1.5 hover:shadow-xl hover:shadow-[#1ABE56]/20"
            >
              <div className={`p-6 bg-linear-to-br ${project.gradient} border-b border-white/10 flex-1 flex flex-col justify-between`}>
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-mono font-medium px-2.5 py-0.5 rounded-full bg-[#1ABE56]/20 text-[#1ABE56] border border-[#1ABE56]/40">
                      {project.category}
                    </span>
                    <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white group-hover:bg-[#1ABE56] group-hover:text-black transition-colors">
                      <ArrowUpRight className="w-4 h-4" />
                    </div>
                  </div>

                  {/* Portfolio Preview Image */}
                  <div className="relative h-44 w-full mb-4 rounded-xl overflow-hidden border border-[#1ABE56]/20 group-hover:border-[#1ABE56]/60 transition-all bg-neutral-900">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-700"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        if (target.src !== project.fallback) {
                          target.src = project.fallback;
                        }
                      }}
                    />
                    <div className="absolute inset-0 bg-linear-to-t from-black via-black/20 to-transparent" />
                  </div>

                  <h3 className="text-lg font-bold text-white mb-2 group-hover:text-[#1ABE56] transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-neutral-300 text-xs leading-relaxed">
                    {project.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Pagination Dots Indicator */}
        <div className="flex items-center justify-center gap-2 mt-8">
          {projects.map((_, idx) => (
            <button
              key={idx}
              onClick={() => scrollToCard(idx)}
              aria-label={`Go to slide ${idx + 1}`}
              className={`h-2.5 rounded-full transition-all duration-300 cursor-pointer ${
                activeIndex === idx
                  ? 'w-8 bg-[#1ABE56] shadow-md shadow-[#1ABE56]/50'
                  : 'w-2.5 bg-neutral-700 hover:bg-neutral-500'
              }`}
            />
          ))}
        </div>

      </div>
    </section>
  );
}
