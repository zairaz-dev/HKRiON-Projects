import { SessionManager } from "@/core/auth/session";
import { SafeHttp } from "@/core/http/redirect";

export async function POST(request: Request) {
  const response = SafeHttp.redirect("/login", request, 303);
  SessionManager.clearCookieOnResponse(response);
  return response;
}

export async function GET(request: Request) {
  const response = SafeHttp.redirect("/login", request, 303);
  SessionManager.clearCookieOnResponse(response);
  return response;
}
