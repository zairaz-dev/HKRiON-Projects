import { Controller, Get, Put, Body, Query, UseGuards, Req } from '@nestjs/common';
import { PosSettingsService } from './pos-settings.service';
import { UpdatePosSettingsDto } from './dto/pos-settings.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('pos-settings')
export class PosSettingsController {
  constructor(private readonly posSettingsService: PosSettingsService) {}

  @Get()
  async getSettings(
    @Req() req: any,
    @Query('businessId') queryBusinessId?: string,
    @Query('branchId') branchId?: string,
  ) {
    const user = req.user;
    const bId = user.role === 'super-admin' && queryBusinessId ? queryBusinessId : user.businessId;
    return this.posSettingsService.getSettings(bId, branchId);
  }

  @Put()
  async updateSettings(@Req() req: any, @Body() dto: UpdatePosSettingsDto) {
    const user = req.user;
    const bId = user.role === 'super-admin' && dto.businessId ? dto.businessId : user.businessId;
    return this.posSettingsService.updateSettings(bId, dto);
  }
}
