import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateExpenseCategoryDto } from './dto/create-expense-category.dto';
import { UpdateExpenseCategoryDto } from './dto/update-expense-category.dto';

@Injectable()
export class ExpenseCategoriesService {
  constructor(private prisma: PrismaService) {}

  async create(createDto: CreateExpenseCategoryDto) {
    const { branchIds, ...data } = createDto;

    return this.prisma.expenseCategory.create({
      data: {
        ...data,
        parentId: data.parentId || null,
        branches: branchIds && branchIds.length > 0
          ? {
              create: branchIds.map((branchId) => ({
                branchId,
              })),
            }
          : undefined,
      },
      include: {
        parent: true,
        branches: {
          include: {
            branch: true,
          },
        },
      },
    });
  }

  async findAll(businessId: string, branchId?: string) {
    const whereClause: any = { businessId };

    if (branchId) {
      whereClause.branches = {
        some: { branchId },
      };
    }

    return this.prisma.expenseCategory.findMany({
      where: whereClause,
      include: {
        parent: true,
        branches: {
          include: {
            branch: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });
  }

  async findOne(id: string, businessId: string) {
    const category = await this.prisma.expenseCategory.findFirst({
      where: { id, businessId },
      include: {
        parent: true,
        branches: {
          include: {
            branch: true,
          },
        },
      },
    });

    if (!category) {
      throw new NotFoundException('Expense category not found');
    }

    return category;
  }

  async update(id: string, updateDto: UpdateExpenseCategoryDto) {
    const { branchIds, businessId, ...data } = updateDto;

    if (businessId) {
      await this.findOne(id, businessId);
    }

    return this.prisma.$transaction(async (tx) => {
      if (branchIds !== undefined) {
        await tx.expenseCategoryBranch.deleteMany({
          where: { expenseCategoryId: id },
        });
      }

      return tx.expenseCategory.update({
        where: { id },
        data: {
          ...data,
          parentId: data.parentId === "" ? null : data.parentId,
          branches: branchIds && branchIds.length > 0
            ? {
                create: branchIds.map((branchId) => ({
                  branchId,
                })),
              }
            : undefined,
        },
        include: {
          parent: true,
          branches: {
            include: {
              branch: true,
            },
          },
        },
      });
    });
  }

  async remove(id: string, businessId: string) {
    await this.findOne(id, businessId);

    return this.prisma.expenseCategory.delete({
      where: { id },
    });
  }
}
