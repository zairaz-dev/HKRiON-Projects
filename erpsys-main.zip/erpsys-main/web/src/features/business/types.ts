export interface BusinessDetails {
  id: string;
  name: string;
  industry: string;
  phone: string;
  phoneCodeId: string;
  countryId: string;
  currencyId: string;

  // Tax Details
  taxNumber?: string | null;
  taxName?: string | null;
  isTaxEnabled?: boolean;

  // Branding & Legal
  logo?: string | null;
  registrationNumber?: string | null;

  // Contact & Address
  email?: string | null;
  website?: string | null;
  alternatePhone?: string | null;
  address?: string | null;
  city?: string | null;
  state?: string | null;
  postalCode?: string | null;

  // Financial & Preferences
  financialYearStartMonth?: number | null;
  stockAccountingMethod?: string | null;
  timezone?: string | null;
  dateFormat?: string | null;
  currencySymbolPlacement?: string | null;
  decimalPrecision?: number | null;

  country?: {
    id: string;
    name: string;
    code: string;
  };
  currency?: {
    id: string;
    name: string;
    code: string;
    symbol: string;
  };
  phoneCode?: {
    id: string;
    name: string;
    code: string;
  };
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}
