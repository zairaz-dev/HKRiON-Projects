import React, { useEffect, useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  X,
  UserPlus,
  Loader2,
  User,
  Briefcase,
  Users,
  Mail,
  Phone,
  FileText,
  CreditCard,
  Wallet,
  MapPin,
  Upload,
  Image as ImageIcon,
  AlertCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog } from "@/components/ui/dialog";
import { MultiSelect } from "@/components/ui/multi-select";
import { User as UserType } from "@hkr/types";
import { customerFormSchema, CustomerFormSchema } from "../schema";
import { CustomerItem, BranchItem } from "../types";
import {
  useCreateCustomerMutation,
  useUpdateCustomerMutation,
  useCustomerGroupsQuery,
} from "../hooks/use-customers";
import { getFullAssetUrl } from "@/lib/utils";
import { customerService } from "@/services/customer-service";

interface CustomerDialogProps {
  isOpen: boolean;
  onClose: () => void;
  customer?: CustomerItem | null;
  branches: BranchItem[];
  currentUser: UserType;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
  onSaveSuccess?: (customer: CustomerItem) => void;
}

export function CustomerDialog({
  isOpen,
  onClose,
  customer,
  branches,
  currentUser,
  onSuccess,
  onError,
  onSaveSuccess,
}: CustomerDialogProps) {
  const isEditMode = !!customer;
  const createMutation = useCreateCustomerMutation();
  const updateMutation = useUpdateCustomerMutation();

  // File upload state
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>("");
  const [isUploadingImage, setIsUploadingImage] = useState<boolean>(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Fetch Customer Groups for the dropdown
  const { data: customerGroups = [] } = useCustomerGroupsQuery(currentUser.businessId || "");

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<CustomerFormSchema>({
    resolver: zodResolver(customerFormSchema),
    defaultValues: {
      name: "",
      image: null,
      businessName: "",
      email: "",
      phone: "",
      taxNumber: "",
      openingBalance: 0,
      creditLimit: null,
      address: "",
      customerGroupId: "",
      branchIds: [],
      isActive: true,
      allowCredit: true,
    },
  });

  const watchBranchIds = watch("branchIds") || [];
  const watchCustomerGroupId = watch("customerGroupId") || "";
  const watchIsActive = watch("isActive");

  // Populate form in edit mode
  useEffect(() => {
    setFormError(null);
    if (customer) {
      const assignedBranchIds = customer.branches?.map((cb) => cb.branch.id) || [];
      reset({
        name: customer.name,
        image: customer.image || null,
        businessName: customer.businessName || "",
        email: customer.email || "",
        phone: customer.phone || "",
        taxNumber: customer.taxNumber || "",
        openingBalance: customer.openingBalance,
        creditLimit: customer.creditLimit,
        address: customer.address || "",
        customerGroupId: customer.customerGroupId || "",
        branchIds: assignedBranchIds,
        isActive: customer.isActive,
        allowCredit: customer.allowCredit !== undefined ? customer.allowCredit : true,
      });
      setImagePreview(customer.image ? (getFullAssetUrl(customer.image) || customer.image) : "");
      setImageFile(null);
    } else {
      reset({
        name: "",
        image: null,
        businessName: "",
        email: "",
        phone: "",
        taxNumber: "",
        openingBalance: 0,
        creditLimit: null,
        address: "",
        customerGroupId: "",
        branchIds: [],
        isActive: true,
        allowCredit: true,
      });
      setImagePreview("");
      setImageFile(null);
    }
  }, [customer, reset, isOpen]);

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      onError("Image file size must be under 5MB.");
      return;
    }

    setImageFile(file);
    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      setImagePreview(uploadEvent.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveImage = () => {
    setImageFile(null);
    setImagePreview("");
    setValue("image", null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const branchOptions = branches.map((branch) => ({
    value: branch.id,
    label: branch.name,
  }));

  const handleBranchChange = (values: string[]) => {
    setValue("branchIds", values, { shouldValidate: true });
  };

  const onSubmit = async (data: CustomerFormSchema) => {
    if (!currentUser.businessId) return;

    try {
      let finalImageUrl: string | null = customer?.image || null;

      if (imageFile) {
        setIsUploadingImage(true);
        const uploadRes = await customerService.uploadImage(imageFile, customer?.id);
        finalImageUrl = uploadRes.imageUrl;
      } else if (!imagePreview) {
        finalImageUrl = null;
      }

      const payload = {
        name: data.name.trim(),
        image: finalImageUrl,
        businessName: data.businessName || "",
        email: data.email || null,
        phone: data.phone || null,
        taxNumber: data.taxNumber || "",
        openingBalance: data.openingBalance,
        creditLimit: data.creditLimit || null,
        address: data.address || "",
        customerGroupId: data.customerGroupId || null,
        branchIds: data.branchIds,
        isActive: data.isActive,
        allowCredit: data.allowCredit,
        businessId: currentUser.businessId,
        createdById: isEditMode ? undefined : currentUser.id,
        updatedById: isEditMode ? currentUser.id : undefined,
      };

      if (isEditMode && customer) {
        const res = await updateMutation.mutateAsync({ id: customer.id, data: payload });
        onSuccess("Customer updated successfully!");
        if (onSaveSuccess) onSaveSuccess(res);
      } else {
        const res = await createMutation.mutateAsync(payload);
        onSuccess("Customer created successfully!");
        if (onSaveSuccess) onSaveSuccess(res);
      }
      onClose();
    } catch (err: any) {
      const msg = err.message || "Failed to save customer.";
      setFormError(msg);
      onError(msg);
    } finally {
      setIsUploadingImage(false);
    }
  };

  const isLoading = createMutation.isPending || updateMutation.isPending || isUploadingImage;

  if (!isOpen) return null;

  return (
    <Dialog
      isOpen={isOpen}
      onClose={onClose}
      size="2xl"
      title={
        <span className="flex items-center gap-2">
          <UserPlus className="h-5 w-5 text-primary" />
          {isEditMode ? "Edit Customer" : "Add New Customer"}
        </span>
      }
    >

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          {formError && (
            <div className="p-3 rounded-md bg-destructive/15 border border-destructive/30 text-destructive text-xs flex items-center gap-2 animate-in fade-in duration-200">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{formError}</span>
            </div>
          )}
          {/* Customer Profile Photo */}
          <div className="p-3 rounded-sm border border-border bg-card/40 flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="relative w-16 h-16 rounded-full border-2 border-dashed border-border flex items-center justify-center bg-secondary/30 shrink-0 overflow-hidden group">
              {imagePreview ? (
                <>
                  <img
                    src={imagePreview}
                    alt="Customer Avatar"
                    className="w-full h-full object-cover"
                    onError={() => setImagePreview("")}
                  />
                  <button
                    type="button"
                    onClick={handleRemoveImage}
                    className="absolute top-0 right-0 bg-black/70 hover:bg-rose-600 text-white rounded-full p-0.5 transition-colors cursor-pointer"
                    title="Remove Photo"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </>
              ) : (
                <div className="text-center">
                  <User className="w-6 h-6 text-muted-foreground mx-auto opacity-60" />
                  <span className="text-[9px] text-muted-foreground block font-mono">No Photo</span>
                </div>
              )}

              {isUploadingImage && (
                <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
                  <Loader2 className="w-5 h-5 animate-spin text-primary" />
                </div>
              )}
            </div>

            <div className="space-y-1 flex-1">
              <h4 className="text-xs font-bold text-foreground font-mono uppercase">Customer Profile Photo</h4>
              <p className="text-[11px] text-muted-foreground">
                Displays on customer directory list, profile statement, and billing checkout.
              </p>
              <div className="flex items-center gap-2 pt-0.5">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png, image/jpeg, image/webp"
                  onChange={handleImageFileChange}
                  className="hidden"
                  id="customer-photo-file"
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isLoading}
                  className="h-7 text-xs font-mono font-semibold gap-1.5 rounded-sm border-border cursor-pointer"
                >
                  <Upload className="w-3 h-3" />
                  {imagePreview ? "Change Photo" : "Upload Photo"}
                </Button>
                {imagePreview && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={handleRemoveImage}
                    disabled={isLoading}
                    className="h-7 text-xs font-mono text-rose-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-sm cursor-pointer"
                  >
                    Remove
                  </Button>
                )}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Name */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1.5">
                <User className="h-3.5 w-3.5 text-muted-foreground/80" />
                <span>Customer Name <span className="text-destructive">*</span></span>
              </label>
              <Input
                placeholder="e.g., John Doe"
                {...register("name")}
                disabled={isLoading}
              />
              {errors.name && (
                <span className="text-xs text-rose-500">{errors.name.message}</span>
              )}
            </div>

            {/* Business Name */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1.5">
                <Briefcase className="h-3.5 w-3.5 text-muted-foreground/80" />
                <span>Business Name</span>
              </label>
              <Input
                placeholder="e.g., Acme Corp"
                {...register("businessName")}
                disabled={isLoading}
              />
            </div>

            {/* Customer Group */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1.5">
                <Users className="h-3.5 w-3.5 text-muted-foreground/80" />
                <span>Customer Group</span>
              </label>
              <Select
                value={watchCustomerGroupId}
                onValueChange={(val) => setValue("customerGroupId", val, { shouldValidate: true })}
                disabled={isLoading}
              >
                <option value="">None (No Group)</option>
                {customerGroups.map((group: any) => (
                  <option key={group.id} value={group.id}>
                    {group.name}
                  </option>
                ))}
              </Select>
              {errors.customerGroupId && (
                <span className="text-xs text-rose-500">{errors.customerGroupId.message}</span>
              )}
            </div>

            {/* Email */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1.5">
                <Mail className="h-3.5 w-3.5 text-muted-foreground/80" />
                <span>Email Address</span>
              </label>
              <Input
                type="email"
                placeholder="e.g., john@example.com"
                {...register("email")}
                disabled={isLoading}
              />
              {errors.email && (
                <span className="text-xs text-rose-500">{errors.email.message}</span>
              )}
            </div>

            {/* Phone */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1.5">
                <Phone className="h-3.5 w-3.5 text-muted-foreground/80" />
                <span>Phone Number</span>
              </label>
              <Input
                placeholder="e.g., 9876543210"
                {...register("phone")}
                disabled={isLoading}
              />
              {errors.phone && (
                <span className="text-xs text-rose-500">{errors.phone.message}</span>
              )}
            </div>

            {/* Tax Number */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1.5">
                <FileText className="h-3.5 w-3.5 text-muted-foreground/80" />
                <span>Tax Number (GSTIN/VAT)</span>
              </label>
              <Input
                placeholder="e.g., 22AAAAA1111A1Z1"
                {...register("taxNumber")}
                disabled={isLoading}
              />
            </div>

            {/* Credit Limit */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1.5">
                <CreditCard className="h-3.5 w-3.5 text-muted-foreground/80" />
                <span>Credit Limit</span>
              </label>
              <Input
                type="number"
                step="any"
                placeholder="e.g., 50000"
                {...register("creditLimit", { valueAsNumber: true })}
                disabled={isLoading}
              />
              {errors.creditLimit && (
                <span className="text-xs text-rose-500">{errors.creditLimit.message}</span>
              )}
            </div>

            {/* Opening Balance */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1.5">
                <Wallet className="h-3.5 w-3.5 text-muted-foreground/80" />
                <span>Opening Balance</span>
              </label>
              <Input
                type="number"
                step="any"
                placeholder="e.g., 0"
                {...register("openingBalance", { valueAsNumber: true })}
                disabled={isLoading}
              />
              {errors.openingBalance && (
                <span className="text-xs text-rose-500">{errors.openingBalance.message}</span>
              )}
            </div>

            {/* Status & Credit Permissions */}
            <div className="flex flex-col sm:flex-row gap-4 p-3 rounded-md bg-secondary/15 border border-border/40">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="isActive"
                  checked={watchIsActive}
                  onCheckedChange={(checked) => setValue("isActive", !!checked)}
                  disabled={isLoading}
                />
                <label htmlFor="isActive" className="text-xs font-semibold cursor-pointer select-none">
                  Active (Allow sales transactions)
                </label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="allowCredit"
                  checked={watch("allowCredit")}
                  onCheckedChange={(checked) => setValue("allowCredit", !!checked)}
                  disabled={isLoading}
                />
                <label htmlFor="allowCredit" className="text-xs font-semibold cursor-pointer select-none">
                  Allow Credit Sales (Due/Credit allowed)
                </label>
              </div>
            </div>
          </div>

          {/* Branch Scope */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase block">
              Branch Mapping (Optional - Leave empty for Global)
            </label>
            <MultiSelect
              options={branchOptions}
              selectedValues={watchBranchIds}
              onChange={handleBranchChange}
              placeholder="Select branches..."
              disabled={isLoading}
            />
          </div>

          {/* Address */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1.5">
              <MapPin className="h-3.5 w-3.5 text-muted-foreground/80" />
              <span>Address</span>
            </label>
            <textarea
              placeholder="Enter customer address"
              {...register("address")}
              disabled={isLoading}
              className="flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
            />
          </div>

          {/* Form Buttons */}
          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-border/50">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isLoading}
              className="h-9 px-4 text-xs"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isLoading}
              className="h-9 px-4 text-xs flex items-center gap-1.5"
            >
              {isLoading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
              {isEditMode ? "Save Changes" : "Add Customer"}
            </Button>
          </div>
        </form>
    </Dialog>
  );
}
