"use strict";

import React from "react";
import { PublicNavbar } from "@/components/layout/public-navbar";
import { PublicFooter } from "@/components/layout/public-footer";

export default function PublicLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col relative overflow-hidden selection:bg-emerald-500/30 selection:text-emerald-400">
      {/* 🌟 SHARED EMERALD AI SAAS BACKGROUND (FOR ALL PUBLIC PAGES) */}
      <div className="fixed inset-0 bg-[radial-gradient(rgba(16,185,129,0.18)_1.5px,transparent_1.5px)] [background-size:22px_22px] [mask-image:radial-gradient(ellipse_75%_65%_at_60%_35%,#000_65%,transparent_100%)] opacity-85 pointer-events-none z-0" />
      
      {/* Aurora glowing green ambiance blobs */}
      <div className="fixed top-[-5%] right-[10%] w-[650px] h-[650px] rounded-full bg-emerald-600/15 blur-[160px] pointer-events-none z-0" />
      <div className="fixed top-[12%] left-[-5%] w-[450px] h-[450px] rounded-full bg-emerald-500/10 blur-[140px] pointer-events-none z-0" />
      <div className="fixed top-[30%] right-[-2%] w-[450px] h-[450px] rounded-full bg-emerald-400/10 blur-[130px] pointer-events-none z-0" />
      <div className="fixed bottom-[-10%] left-[20%] w-[550px] h-[550px] rounded-full bg-emerald-600/10 blur-[160px] pointer-events-none z-0" />

      {/* Shared Header Navigation */}
      <PublicNavbar />
      
      {/* Content wrapper with top padding to clear the fixed navbar & announcement bar */}
      <div className="flex-1 pt-32 sm:pt-36 relative z-10">
        {children}
      </div>

      {/* Shared Footer */}
      <PublicFooter />
    </div>
  );
}
