"use client";

import React from "react";
import Link from "next/link";
import { useCMS } from "@/features/cms/useCMS";
import {
  ArmoredTruckIcon,
  SecurityLockIcon,
  CertificateShieldIcon,
  AwardIcon,
  CheckIcon
} from "@/components/ui/LuxuryIcons";

import { SITE_CONFIG } from "@/lib/constants/site";

export default function ShippingReturnsPage() {
  const { getBlock } = useCMS();
  const contactEmail = getBlock("contact.email", SITE_CONFIG.contact.email);
  return (
    <div className="bg-[#FAF8F5] min-h-screen py-12 lg:py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Page Header */}
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <span className="text-[11px] font-sans tracking-wide-luxury uppercase text-[#9A7B4F] block">
            Shipping & Returns
          </span>
          <h1 className="font-serif text-3xl sm:text-5xl text-[#18181D]">
            Secure Delivery & 30-Day Returns
          </h1>
          <p className="text-xs sm:text-sm text-[#6B655C] font-sans leading-relaxed">
            Every gemstone is fully insured and securely shipped to your door. If you're not satisfied, return it within 30 days for a full refund.
          </p>
        </div>

        {/* Section 1: Armored Shipping Protocol */}
        <div className="bg-white border border-[#E8E4DC] p-8 sm:p-10 shadow-sm space-y-6">
          <div className="flex items-center gap-3 border-b border-[#F2EFE9] pb-4">
            <ArmoredTruckIcon className="w-6 h-6 text-[#C5A880]" />
            <h2 className="font-serif text-2xl text-[#18181D]">
              How We Ship Your Gemstone
            </h2>
          </div>

          <div className="space-y-4 text-xs sm:text-sm font-sans text-[#554F47] leading-relaxed">
            <p>
              We don't use regular mail for gemstones. All deliveries are handled by specialized high-security courier services:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="p-4 bg-[#FAF8F5] border border-[#E8E4DC] space-y-1.5">
                <span className="font-serif text-base text-[#18181D] font-medium block">
                  Ferrari Logistics (Armored Air)
                </span>
                <p className="text-xs text-[#6B655C]">
                  Secure vehicle transport with insured door-to-door delivery directly to your home or bank.
                </p>
              </div>

              <div className="p-4 bg-[#FAF8F5] border border-[#E8E4DC] space-y-1.5">
                <span className="font-serif text-base text-[#18181D] font-medium block">
                  Malca-Amit Vault Logistics
                </span>
                <p className="text-xs text-[#6B655C]">
                  Direct secure transfers to major cities worldwide including London, New York, Hong Kong, and Singapore.
                </p>
              </div>
            </div>

            <div className="pt-2 space-y-2">
              <div className="flex items-start gap-2.5">
                <CheckIcon className="w-4 h-4 text-[#C5A880] flex-shrink-0 mt-0.5" />
                <span>Full Insurance: Every shipment is fully insured for its full value.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckIcon className="w-4 h-4 text-[#C5A880] flex-shrink-0 mt-0.5" />
                <span>Secure Packaging: Sealed in tamper-proof packaging with numbered security seals.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckIcon className="w-4 h-4 text-[#C5A880] flex-shrink-0 mt-0.5" />
                <span>ID Verification: Delivered only after confirming your identity with a valid ID.</span>
              </div>
            </div>
          </div>
        </div>

        {/* Section 2: 30-Day Risk-Free Inspection Guarantee */}
        <div className="bg-white border border-[#C5A880] p-8 sm:p-10 shadow-sm space-y-6">
          <div className="flex items-center gap-3 border-b border-[#F2EFE9] pb-4">
            <SecurityLockIcon className="w-6 h-6 text-[#C5A880]" />
            <h2 className="font-serif text-2xl text-[#18181D]">
              30-Day Money-Back Guarantee
            </h2>
          </div>

          <div className="space-y-4 text-xs sm:text-sm font-sans text-[#554F47] leading-relaxed">
            <p>
              We know that photos don't always do justice to a gemstone's beauty. That's why you get a full 30 days to inspect your purchase in person.
            </p>

            <p>
              After receiving your gemstone, you have 30 full days to examine it. You can show it to your local gemstone expert or jeweler for their opinion.
            </p>

            <div className="p-4 bg-[#FAF8F5] border border-[#E8E4DC] space-y-2 text-xs">
              <span className="font-serif text-sm font-medium text-[#18181D] block">
                How to Request a Return:
              </span>
              <ol className="list-decimal pl-5 space-y-1 text-[#6B655C]">
                <li>Email us at {contactEmail} within 30 days of receiving your order.</li>
                <li>We'll send a secure courier to pick up the gemstone from your address — free of charge.</li>
                <li>After we receive and inspect the stone, your full refund will be processed within 48 hours.</li>
              </ol>
            </div>
          </div>
        </div>

        {/* Support Link */}
        <div className="text-center pt-4">
          <Link
            href="/contact"
            className="inline-block px-8 py-3 bg-[#18181D] hover:bg-[#2A2A32] text-white text-xs uppercase tracking-luxury font-sans font-medium transition-colors"
          >
            Contact Us About Shipping &rarr;
          </Link>
        </div>
      </div>
    </div>
  );
}
