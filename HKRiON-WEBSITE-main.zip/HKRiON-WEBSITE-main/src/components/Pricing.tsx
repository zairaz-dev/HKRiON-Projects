'use client';

import { Check, ArrowRight, Sparkles } from 'lucide-react';

const plans = [
  {
    name: 'Starter / SME',
    price: 'Custom Quote',
    desc: 'Ideal for small businesses and retail shops looking for single-terminal POS & basic inventory.',
    features: [
      'Single Branch POS Billing',
      'Basic Inventory & Stock Alerts',
      'Daily Sales Reports',
      'Email & Phone Technical Support',
      'Standard Cloud Backup'
    ],
    popular: false,
    cta: 'Get Started'
  },
  {
    name: 'Business Growth',
    price: 'Custom Quote',
    desc: 'Perfect for growing companies requiring custom Web Apps, HRM payroll, or multi-store ERP.',
    features: [
      'Multi-Branch ERP & POS',
      'HRM & Biometric Payroll Sync',
      'Custom Web Application',
      'Real-time Analytics Dashboard',
      '24/7 Priority Support SLA',
      'Custom API & Payment Gateway'
    ],
    popular: true,
    cta: 'Request Business Plan'
  },
  {
    name: 'Enterprise Custom',
    price: 'Custom Proposal',
    desc: 'For large corporations needing full-suite ERP, IoT telemetry, AI automation & dedicated cloud.',
    features: [
      'Full HKRION Product Suite Access',
      'IoT Sensors & Hardware Telemetry',
      'Dedicated AWS/Docker Cloud Setup',
      'Custom AI & Automation Workflows',
      'Dedicated Solution Architect',
      'Custom SLA & On-Site Training'
    ],
    popular: false,
    cta: 'Contact Enterprise Team'
  }
];

export default function Pricing() {
  return (
    <section id="pricing" className="py-24 bg-black relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <h2 className="text-xs font-semibold uppercase tracking-widest text-[#1ABE56] font-mono">
            FLEXIBLE PRICING & ESTIMATES
          </h2>
          <p className="text-3xl sm:text-5xl font-semibold text-white tracking-tight">
            Transparent Plans for <span className="gradient-text">Every Scale</span>
          </p>
          <p className="text-neutral-400 text-base sm:text-lg">
            Choose a solution plan that matches your business needs or request a customized project quote.
          </p>
        </div>

        {/* Plans Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {plans.map((plan, idx) => (
            <div
              key={idx}
              className={`glass-card p-8 rounded-3xl border transition-all duration-300 relative flex flex-col justify-between ${
                plan.popular 
                  ? 'border-[#1ABE56] bg-black/95 shadow-xl shadow-[#1ABE56]/10 scale-105 z-10' 
                  : 'border-[#1ABE56]/30 bg-black/85 hover:border-[#1ABE56]'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-[#1ABE56] text-black font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 fill-black" />
                  Most Popular Choice
                </div>
              )}

              <div>
                <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
                <p className="text-neutral-400 text-xs leading-relaxed mb-6">{plan.desc}</p>

                <div className="mb-6 pb-6 border-b border-white/10">
                  <span className="text-3xl font-extrabold text-white font-mono">{plan.price}</span>
                  <span className="text-xs text-neutral-400 block mt-1">Tailored to project scope</span>
                </div>

                <div className="space-y-3 mb-8">
                  <span className="text-xs font-bold text-white uppercase tracking-wider font-mono block">Included Features:</span>
                  {plan.features.map((feat, fIdx) => (
                    <div key={fIdx} className="flex items-center gap-2 text-xs text-neutral-300">
                      <Check className="w-4 h-4 text-[#1ABE56] shrink-0" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              <a
                href="#contact"
                className={`w-full py-3.5 px-6 rounded-xl text-xs font-semibold text-center flex items-center justify-center gap-2 group transition-all ${
                  plan.popular
                    ? 'glow-btn text-white'
                    : 'bg-neutral-900 text-white border border-[#1ABE56]/40 hover:bg-[#1ABE56] hover:text-black'
                }`}
              >
                <span>{plan.cta}</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
