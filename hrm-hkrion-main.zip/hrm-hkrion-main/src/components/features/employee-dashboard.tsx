"use client";

import { useState } from "react";
import { clockIn, clockOut } from "@/actions/attendance";
import { Clock, LogIn, LogOut, CheckCircle2, CalendarOff, CalendarClock, ArrowRight, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Link from "next/link";

type TodayAttendance = {
  id: number;
  clockIn: Date | null;
  clockOut: Date | null;
  status: string;
} | null;

type RecentActivity = {
  id: number;
  date: Date;
  clockIn: Date | null;
  clockOut: Date | null;
};

type EmployeeDashboardProps = {
  todayAttendance: TodayAttendance;
  leavesTaken: number;
  pendingLeaves: number;
  recentActivity: RecentActivity[];
};

export default function EmployeeDashboard({
  todayAttendance,
  leavesTaken,
  pendingLeaves,
  recentActivity,
}: EmployeeDashboardProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const hasClockedIn = !!todayAttendance?.clockIn;
  const hasClockedOut = !!todayAttendance?.clockOut;

  const handleClockIn = async () => {
    setIsLoading(true);
    setError(null);
    const res = await clockIn();
    if (res.error) setError(res.error);
    setIsLoading(false);
  };

  const handleClockOut = async () => {
    setIsLoading(true);
    setError(null);
    const res = await clockOut();
    if (res.error) setError(res.error);
    setIsLoading(false);
  };

  const formatTime = (date: Date | null) => {
    if (!date) return "—";
    return new Date(date).toLocaleTimeString("en-US", { hour: '2-digit', minute: '2-digit' });
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("en-US", { weekday: 'short', month: 'short', day: 'numeric' });
  };

  return (
    <div className="space-y-6">
      {error && (
        <div className="p-3 rounded-md bg-error-bg border border-error-border text-error text-sm flex items-start gap-2">
          <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {/* Main Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Clock In/Out Widget */}
        <Card className="flex flex-col items-center justify-center text-center p-6 shadow-sm border-border bg-surface">
          <div className="text-sm font-medium text-text-secondary mb-1">Today's Status</div>
          <div className="text-2xl font-semibold text-text-primary mb-6">
            {!hasClockedIn ? "Not Clocked In" : hasClockedOut ? "Clocked Out" : "Clocked In"}
          </div>
          
          {!hasClockedIn ? (
            <Button
              onClick={handleClockIn}
              disabled={isLoading}
              className="w-full py-6 text-base bg-primary hover:bg-primary-600 text-white"
            >
              {isLoading ? (
                <div className="h-5 w-5 rounded-full border-2 border-white border-t-transparent animate-spin"></div>
              ) : (
                <>
                  <LogIn className="mr-2 h-5 w-5" />
                  Clock In
                </>
              )}
            </Button>
          ) : !hasClockedOut ? (
            <Button
              variant="destructive"
              onClick={handleClockOut}
              disabled={isLoading}
              className="w-full py-6 text-base"
            >
              {isLoading ? (
                <div className="h-5 w-5 rounded-full border-2 border-white border-t-transparent animate-spin"></div>
              ) : (
                <>
                  <LogOut className="mr-2 h-5 w-5" />
                  Clock Out
                </>
              )}
            </Button>
          ) : (
            <div className="w-full inline-flex items-center justify-center gap-2 rounded-md bg-surface-elevated border border-border px-4 py-3 text-sm font-medium text-text-secondary cursor-not-allowed">
              <CheckCircle2 className="h-5 w-5 text-success" />
              Completed for Today
            </div>
          )}
          
          {hasClockedIn && (
             <div className="mt-4 text-sm text-text-secondary font-mono flex items-center gap-2">
               <span>In: {formatTime(todayAttendance?.clockIn || null)}</span>
               {hasClockedOut && <span>• Out: {formatTime(todayAttendance?.clockOut || null)}</span>}
             </div>
          )}
        </Card>

        {/* Stats Column */}
        <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-6">
          <Card className="p-6 shadow-sm border-border bg-surface flex flex-col justify-center">
            <div className="flex items-center justify-between mb-4">
               <span className="text-sm font-medium text-text-secondary">Approved Leaves</span>
               <div className="h-10 w-10 flex items-center justify-center rounded-lg bg-success-light text-success">
                 <CalendarOff className="h-5 w-5" />
               </div>
            </div>
            <p className="text-3xl font-semibold text-text-primary">{leavesTaken}</p>
            <Link href="/dashboard/leaves" className="text-xs text-primary-600 hover:underline mt-2 inline-block">View Details &rarr;</Link>
          </Card>

          <Card className="p-6 shadow-sm border-border bg-surface flex flex-col justify-center">
            <div className="flex items-center justify-between mb-4">
               <span className="text-sm font-medium text-text-secondary">Pending Leaves</span>
               <div className="h-10 w-10 flex items-center justify-center rounded-lg bg-warning-light text-warning">
                 <CalendarClock className="h-5 w-5" />
               </div>
            </div>
            <p className="text-3xl font-semibold text-text-primary">{pendingLeaves}</p>
            <Link href="/dashboard/leaves" className="text-xs text-primary-600 hover:underline mt-2 inline-block">View Requests &rarr;</Link>
          </Card>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="rounded-xl border border-border bg-surface shadow-sm overflow-hidden">
        <div className="border-b border-border p-5 flex justify-between items-center">
          <h2 className="font-semibold text-text-primary">My Recent Attendance</h2>
          <Link href="/dashboard/attendance" className="text-sm text-primary-600 font-medium hover:underline">View All</Link>
        </div>
        <div className="p-0">
          {recentActivity.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 text-text-secondary text-sm">
              <CalendarClock className="h-8 w-8 text-border mb-2" />
              <p>No recent activity found.</p>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-surface-secondary/50 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-surface border border-border shadow-sm">
                      <Clock className="h-4 w-4 text-text-secondary" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-text-primary">
                        {formatDate(activity.date)}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-end gap-3 sm:gap-4">
                    <div className="flex flex-col">
                      <span className="text-[10px] font-medium uppercase tracking-wider text-text-secondary mb-1.5">Clock In</span>
                      <span className="inline-flex items-center justify-center rounded-md bg-surface-secondary px-2 py-1 text-xs font-mono font-medium text-text-primary border border-border">
                        {formatTime(activity.clockIn)}
                      </span>
                    </div>
                    
                    <div className="hidden sm:flex items-center justify-center h-[26px] mb-[1px]">
                      <ArrowRight className="h-4 w-4 text-text-secondary/40" />
                    </div>
                    
                    <div className="flex flex-col">
                      <span className="text-[10px] font-medium uppercase tracking-wider text-text-secondary mb-1.5">Clock Out</span>
                      <span className="inline-flex items-center justify-center rounded-md bg-surface-secondary px-2 py-1 text-xs font-mono font-medium text-text-primary border border-border">
                        {formatTime(activity.clockOut)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
