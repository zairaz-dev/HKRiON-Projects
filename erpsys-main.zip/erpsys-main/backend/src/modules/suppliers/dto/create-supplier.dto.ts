export class CreateSupplierDto {
  name: string;
  image?: string;
  businessName?: string;
  email?: string;
  phone?: string;
  taxNumber?: string;
  openingBalance?: number;
  address?: string;
  businessId: string;
  branchIds?: string[];
  createdById?: string;
}
