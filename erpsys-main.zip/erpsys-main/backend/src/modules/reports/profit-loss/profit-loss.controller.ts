import { Controller, Get, Query, UseGuards, Req } from '@nestjs/common';
import { ProfitLossService } from './profit-loss.service';
import { JwtAuthGuard } from '../../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { PermissionsGuard } from '../../../common/guards/permissions.guard';
import { Permissions } from '../../../common/decorators/permissions.decorator';
import { Permission } from '../../../common/enums/permission.enum';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('reports/profit-loss')
export class ProfitLossController {
  constructor(private readonly profitLossService: ProfitLossService) {}

  @Permissions(Permission.REPORT_VIEW)
  @Get()
  async getProfitAndLoss(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
    @Query('branchId') branchId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.profitLossService.getProfitAndLoss(bId, {
      startDate: startDate ? new Date(startDate) : undefined,
      endDate: endDate ? new Date(endDate) : undefined,
      branchId,
    });
  }
}

