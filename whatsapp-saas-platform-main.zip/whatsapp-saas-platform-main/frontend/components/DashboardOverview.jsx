'use client';
import { 
  Users, 
  UserCheck, 
  FileSpreadsheet, 
  Layers, 
  ArrowUpRight, 
  Play, 
  Download, 
  Zap,
  CheckCircle2,
  Clock,
  Sparkles
} from 'lucide-react';

export default function DashboardOverview({ onNavigate, onOpenQrModal, stats = {} }) {
  return (
    <div className="space-y-6">
      {/* Hero Welcome Banner */}
      <div className="glass-card rounded-3xl p-6 relative overflow-hidden border border-emerald-500/20 bg-gradient-to-r from-[#0d1c24] via-[#0e2428] to-[#0a161d]">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-800/60 text-emerald-400 text-xs font-medium mb-3">
              <Sparkles className="w-3.5 h-3.5" /> Next.js + Evolution API Architecture
            </div>
            <h2 className="text-2xl md:text-3xl font-heading font-extrabold text-white tracking-tight">
              WhatsApp Group Contact Pipeline
            </h2>
            <p className="text-sm text-slate-400 max-w-xl mt-1.5 leading-relaxed">
              Extract group members, remove duplicate numbers, filter existing contacts, and generate ready-to-import Google CSVs instantly.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenQrModal}
              className="bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-700 font-semibold px-4 py-2.5 rounded-xl text-xs flex items-center gap-2 transition-all"
            >
              <Zap className="w-4 h-4 text-amber-400" /> Link WhatsApp
            </button>
            <button
              onClick={() => onNavigate('extractor')}
              className="emerald-glow-btn text-slate-950 font-bold px-5 py-2.5 rounded-xl text-xs flex items-center gap-2 transition-all"
            >
              <Play className="w-4 h-4 fill-slate-950" /> Run Pipeline
            </button>
          </div>
        </div>
      </div>

      {/* 4 Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Groups */}
        <div className="glass-card glass-card-hover rounded-2xl p-5 border border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400">Total Groups</span>
            <div className="w-9 h-9 rounded-xl bg-cyan-950/60 border border-cyan-800/50 flex items-center justify-center text-cyan-400">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-white font-heading">
            {stats.groupsCount !== undefined ? stats.groupsCount : 12}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-cyan-400" /> Detected WhatsApp Groups
          </div>
        </div>

        {/* Extracted Contacts */}
        <div className="glass-card glass-card-hover rounded-2xl p-5 border border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400">Raw Contacts</span>
            <div className="w-9 h-9 rounded-xl bg-emerald-950/60 border border-emerald-800/50 flex items-center justify-center text-emerald-400">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-emerald-400 font-heading">
            {stats.extractedCount ? stats.extractedCount.toLocaleString() : '698'}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <span className="text-emerald-400 font-mono text-[10px]">extracted_contacts.csv</span>
          </div>
        </div>

        {/* Unique Contacts */}
        <div className="glass-card glass-card-hover rounded-2xl p-5 border border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400">Unique Contacts</span>
            <div className="w-9 h-9 rounded-xl bg-purple-950/60 border border-purple-800/50 flex items-center justify-center text-purple-400">
              <UserCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-purple-400 font-heading">
            {stats.uniqueCount ? stats.uniqueCount.toLocaleString() : '494'}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Duplicates Deduplicated
          </div>
        </div>

        {/* Google Ready */}
        <div className="glass-card glass-card-hover rounded-2xl p-5 border border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400">Google Ready</span>
            <div className="w-9 h-9 rounded-xl bg-amber-950/60 border border-amber-800/50 flex items-center justify-center text-amber-400">
              <FileSpreadsheet className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-amber-400 font-heading">
            {stats.googleCount ? stats.googleCount.toLocaleString() : '494'}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Split into Part 1 & Part 2 CSV
          </div>
        </div>
      </div>

      {/* Quick Action Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div 
          onClick={() => onNavigate('chats')}
          className="glass-card glass-card-hover rounded-2xl p-5 border border-slate-800/80 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-950/80 border border-emerald-800/60 text-emerald-400 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <Users className="w-5 h-5" />
          </div>
          <h3 className="font-heading font-bold text-sm text-white group-hover:text-emerald-400 transition-colors flex items-center justify-between">
            Live Chats Inbox <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
          </h3>
          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
            Real-time WhatsApp 2-way messaging, customer chat history & human agent replies.
          </p>
        </div>

        <div 
          onClick={() => onNavigate('aibot')}
          className="glass-card glass-card-hover rounded-2xl p-5 border border-slate-800/80 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-purple-950/80 border border-purple-800/60 text-purple-400 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <Sparkles className="w-5 h-5" />
          </div>
          <h3 className="font-heading font-bold text-sm text-white group-hover:text-purple-400 transition-colors flex items-center justify-between">
            AI Auto-Reply Bot <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
          </h3>
          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
            Configure OpenRouter AI models & custom business prompt instructions.
          </p>
        </div>

        <div 
          onClick={() => onNavigate('extractor')}
          className="glass-card glass-card-hover rounded-2xl p-5 border border-slate-800/80 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-cyan-950/80 border border-cyan-800/60 text-cyan-400 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <Layers className="w-5 h-5" />
          </div>
          <h3 className="font-heading font-bold text-sm text-white group-hover:text-cyan-400 transition-colors flex items-center justify-between">
            Group Scraper <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
          </h3>
          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
            Extract phone numbers from WhatsApp groups and format for Google Contacts.
          </p>
        </div>

        <div 
          onClick={() => onNavigate('downloads')}
          className="glass-card glass-card-hover rounded-2xl p-5 border border-slate-800/80 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-amber-950/80 border border-amber-800/60 text-amber-400 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <Download className="w-5 h-5" />
          </div>
          <h3 className="font-heading font-bold text-sm text-white group-hover:text-amber-400 transition-colors flex items-center justify-between">
            Downloads Hub <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
          </h3>
          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
            Download generated Google Contacts CSVs (Part 1, Part 2, and raw datasets).
          </p>
        </div>
      </div>
    </div>
  );
}
