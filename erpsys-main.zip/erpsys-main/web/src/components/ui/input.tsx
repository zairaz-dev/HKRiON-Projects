import * as React from "react"
import { cn } from "@/lib/utils"

/**
 * ==========================================================================
 * InputProps Interface
 * ==========================================================================
 */
export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  /**
   * Optional icon to display on the left side of the input.
   */
  icon?: React.ReactNode;
}

/**
 * ==========================================================================
 * Reusable Input Component
 * ==========================================================================
 * 
 * A premium styled text input field designed to match the dark theme and 
 * glassmorphism style of the ERP application.
 * Features custom border transitions, focus ring glow, and disabled states.
 * Supports an optional left-aligned icon.
 */
const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, icon, onClick, ...props }, ref) => {
    const handleDateClick = (e: React.MouseEvent<HTMLInputElement>) => {
      if (type === "date") {
        try {
          e.currentTarget.showPicker?.();
        } catch {}
      }
      onClick?.(e);
    };

    if (icon) {
      return (
        <div className="relative w-full">
          <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground/60 pointer-events-none">
            {icon}
          </div>
          <input
            type={type}
            className={cn(
              "flex h-10 w-full rounded-sm border border-input bg-background/50 pl-10 pr-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary disabled:cursor-not-allowed disabled:opacity-50 transition-all",
              type === "date" && "cursor-pointer",
              className
            )}
            onClick={handleDateClick}
            ref={ref}
            {...props}
          />
        </div>
      );
    }

    return (
      <input
        type={type}
        className={cn(
          "flex h-10 w-full rounded-sm border border-input bg-background/50 px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary disabled:cursor-not-allowed disabled:opacity-50 transition-all",
          type === "date" && "cursor-pointer",
          className
        )}
        onClick={handleDateClick}
        ref={ref}
        {...props}
      />
    );
  }
)
Input.displayName = "Input"

export { Input }
