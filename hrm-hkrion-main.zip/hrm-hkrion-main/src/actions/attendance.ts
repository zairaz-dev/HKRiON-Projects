"use server";

import { prisma } from "@/lib/db";
import { getSession } from "@/lib/session";
import { revalidatePath } from "next/cache";
import { Role } from "@prisma/client";

// Utility to get today's normalized midnight UTC date for the unique constraint
function getTodayDate() {
  const now = new Date();
  return new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()));
}

export async function getTodayAttendance() {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    const today = getTodayDate();
    
    const attendance = await prisma.attendance.findUnique({
      where: {
        userId_date: {
          userId: session.userId,
          date: today,
        },
      },
    });

    return { data: attendance };
  } catch (error) {
    console.error("Failed to fetch today's attendance:", error);
    return { error: "Failed to fetch attendance." };
  }
}

export async function getAttendanceRecords() {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    let records;

    if (session.role === Role.SUPER_ADMIN || session.role === Role.MANAGER) {
      // Admins and Managers see all records
      records = await prisma.attendance.findMany({
        include: {
          user: {
            select: {
              firstName: true,
              lastName: true,
              email: true,
            },
          },
        },
        orderBy: {
          date: "desc",
        },
        take: 100, // Limit for performance on the dashboard
      });
    } else {
      // Employees see only their own
      records = await prisma.attendance.findMany({
        where: {
          userId: session.userId,
        },
        include: {
          user: {
            select: {
              firstName: true,
              lastName: true,
              email: true,
            },
          },
        },
        orderBy: {
          date: "desc",
        },
        take: 100,
      });
    }

    return { data: records };
  } catch (error) {
    console.error("Failed to fetch attendance records:", error);
    return { error: "Failed to fetch records." };
  }
}

export async function clockIn() {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    const today = getTodayDate();
    const now = new Date();

    // Check if already clocked in today
    const existing = await prisma.attendance.findUnique({
      where: {
        userId_date: {
          userId: session.userId,
          date: today,
        },
      },
    });

    if (existing) {
      return { error: "Already clocked in today." };
    }

    // Determine status: Late if after 9:30 AM
    const isLate = now.getHours() > 9 || (now.getHours() === 9 && now.getMinutes() > 30);
    const status = isLate ? "LATE" : "PRESENT";

    await prisma.$transaction(async (tx) => {
      await tx.attendance.create({
        data: {
          userId: session.userId,
          date: today,
          clockIn: now,
          status,
        },
      });

      await tx.auditLog.create({
        data: {
          userId: session.userId,
          action: "CLOCK_IN",
          details: `User clocked in as ${status} at ${now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}`,
        },
      });
    });

    revalidatePath("/dashboard/attendance");
    revalidatePath("/dashboard");
    return { success: true };
  } catch (error) {
    console.error("Failed to clock in:", error);
    return { error: "Failed to clock in. Please try again." };
  }
}

export async function clockOut() {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    const today = getTodayDate();
    const now = new Date();

    const existing = await prisma.attendance.findUnique({
      where: {
        userId_date: {
          userId: session.userId,
          date: today,
        },
      },
    });

    if (!existing) {
      return { error: "No clock-in record found for today." };
    }

    if (existing.clockOut) {
      return { error: "Already clocked out today." };
    }

    await prisma.$transaction(async (tx) => {
      await tx.attendance.update({
        where: {
          id: existing.id,
        },
        data: {
          clockOut: now,
        },
      });

      await tx.auditLog.create({
        data: {
          userId: session.userId,
          action: "CLOCK_OUT",
          details: `User clocked out at ${now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}`,
        },
      });
    });

    revalidatePath("/dashboard/attendance");
    revalidatePath("/dashboard");
    return { success: true };
  } catch (error) {
    console.error("Failed to clock out:", error);
    return { error: "Failed to clock out. Please try again." };
  }
}
