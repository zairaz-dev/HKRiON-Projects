"use client";

import { 
  Users, Briefcase, UserCheck, ShieldAlert,
  LogIn, LogOut, UserPlus, UserMinus, UserCog, Key, CalendarOff, Settings, AlertCircle, PieChartIcon, Clock 
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';

type AuditLog = {
  id: number;
  action: string;
  details: string;
  createdAt: Date;
  user: {
    firstName: string;
    lastName: string;
    email: string;
  } | null;
};

type SuperAdminDashboardProps = {
  totalEmployees: number;
  totalPositions: number;
  presentToday: number;
  recentAuditLogs: AuditLog[];
};

export default function SuperAdminDashboard({
  totalEmployees,
  totalPositions,
  presentToday,
  recentAuditLogs,
}: SuperAdminDashboardProps) {

  const formatDateTime = (d: Date) => {
    return formatDistanceToNow(new Date(d), { addSuffix: true });
  };

  const getLogConfig = (action: string) => {
    switch (action) {
      case "USER_LOGIN":
        return { icon: <LogIn className="h-4 w-4" />, colorClass: "text-info bg-info-bg border-info-border" };
      case "USER_LOGOUT":
        return { icon: <LogOut className="h-4 w-4" />, colorClass: "text-text-secondary bg-surface-secondary border-border" };
      case "CREATE_EMPLOYEE":
        return { icon: <UserPlus className="h-4 w-4" />, colorClass: "text-success bg-success-bg border-success-border" };
      case "DELETE_EMPLOYEE":
        return { icon: <UserMinus className="h-4 w-4" />, colorClass: "text-error bg-error-bg border-error-border" };
      case "UPDATE_EMPLOYEE":
        return { icon: <UserCog className="h-4 w-4" />, colorClass: "text-warning bg-warning-bg border-warning-border" };
      case "CREATE_POSITION":
      case "UPDATE_POSITION":
      case "DELETE_POSITION":
        return { icon: <Briefcase className="h-4 w-4" />, colorClass: "text-primary bg-primary-bg border-primary-border" };
      case "UPDATE_PROFILE":
        return { icon: <Settings className="h-4 w-4" />, colorClass: "text-primary bg-primary-bg border-primary-border" };
      case "UPDATE_PASSWORD":
        return { icon: <Key className="h-4 w-4" />, colorClass: "text-primary bg-primary-bg border-primary-border" };
      case "CLOCK_IN":
        return { icon: <Clock className="h-4 w-4" />, colorClass: "text-success bg-success-bg border-success-border" };
      case "CLOCK_OUT":
        return { icon: <Clock className="h-4 w-4" />, colorClass: "text-text-secondary bg-surface-secondary border-border" };
      case "SUBMIT_LEAVE":
      case "UPDATE_LEAVE_STATUS":
        return { icon: <CalendarOff className="h-4 w-4" />, colorClass: "text-info bg-info-bg border-info-border" };
      default:
        return { icon: <AlertCircle className="h-4 w-4" />, colorClass: "text-text-secondary bg-surface-secondary border-border" };
    }
  };

  const actionCounts = recentAuditLogs.reduce((acc, log) => {
    acc[log.action] = (acc[log.action] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const chartData = Object.entries(actionCounts).map(([name, value]) => ({
    name: name.replace(/_/g, ' '),
    value
  }));
  
  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#64748b'];

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {[
          {
            label: "Global Headcount",
            value: totalEmployees.toString(),
            icon: <Users className="h-5 w-5" />,
            trend: "Active Employees",
          },
          {
            label: "Global Positions",
            value: totalPositions.toString(),
            icon: <Briefcase className="h-5 w-5" />,
            trend: "Defined",
          },
          {
            label: "Global Present Today",
            value: presentToday.toString(),
            icon: <UserCheck className="h-5 w-5" />,
            trend: "Clocked In",
          },
        ].map((stat, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: i * 0.1 }}>
            <Card className="p-5 shadow-sm transition-shadow hover:shadow-md border-border bg-surface h-full">
              <div className="mb-4 flex items-center justify-between">
                <span className="text-sm font-medium text-text-secondary">
                  {stat.label}
                </span>
                <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-bg text-primary">
                  {stat.icon}
                </span>
              </div>
              <div className="flex items-baseline gap-2">
                <p className="text-3xl font-semibold text-text-primary">
                  {stat.value}
                </p>
                <span className="text-xs font-medium text-success">
                  {stat.trend}
                </span>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Main Content Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Recent Audit Logs Feed */}
        <div className="lg:col-span-2 rounded-xl border border-border bg-surface shadow-sm flex flex-col">
          <div className="border-b border-border p-5 flex items-center justify-between">
            <h2 className="font-semibold text-text-primary flex items-center gap-2">
              <ShieldAlert className="h-5 w-5 text-warning" /> 
              Live Security Audit Feed
            </h2>
          </div>
          <div className="flex-1 p-0 overflow-hidden">
            {recentAuditLogs.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-48 text-text-secondary text-sm">
                <ShieldAlert className="h-8 w-8 text-border mb-2" />
                <p>No recent audit logs found.</p>
              </div>
            ) : (
              <div className="divide-y divide-border h-[400px] overflow-y-auto custom-scrollbar">
                {recentAuditLogs.map((log) => {
                  const { icon, colorClass } = getLogConfig(log.action);
                  
                  return (
                    <div key={log.id} className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-surface-secondary/50 transition-colors">
                      <div className="flex items-start sm:items-center gap-4">
                        <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full border shadow-sm ${colorClass}`}>
                          {icon}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-text-primary">
                            {log.details}
                          </p>
                          <p className="text-xs text-text-secondary mt-1">
                            Action by: {log.user ? `${log.user.firstName} ${log.user.lastName}` : "System"}
                          </p>
                        </div>
                      </div>
                      
                      <div suppressHydrationWarning className="flex items-center text-xs font-mono text-text-secondary bg-surface-elevated px-3 py-1.5 rounded-md border border-border shrink-0">
                        {formatDateTime(log.createdAt)}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Audit Logs Distribution Chart */}
        <div className="lg:col-span-1 rounded-xl border border-border bg-surface shadow-sm flex flex-col">
          <div className="border-b border-border p-5 flex items-center justify-between">
            <h2 className="font-semibold text-text-primary flex items-center gap-2">
              <PieChartIcon className="h-5 w-5 text-primary" /> 
              Activity Distribution
            </h2>
          </div>
          <div className="flex-1 p-5 flex items-center justify-center min-h-[300px]">
            {chartData.length === 0 ? (
              <div className="flex flex-col items-center justify-center text-text-secondary text-sm">
                <PieChartIcon className="h-8 w-8 text-border mb-2" />
                <p>Not enough data for chart.</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={chartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ borderRadius: '8px', border: '1px solid var(--border)', backgroundColor: 'var(--surface-elevated)' }}
                    itemStyle={{ color: 'var(--text-primary)' }}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
        
      </div>
    </div>
  );
}
