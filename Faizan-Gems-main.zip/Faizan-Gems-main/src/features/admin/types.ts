import {
  GemstoneType,
  GemstoneCut,
  CertificationLab,
  TreatmentType,
  GemstoneVariant,
} from "@/types/gemstone";

export type AdminTab =
  | "overview"
  | "inventory"
  | "orders"
  | "clients"
  | "inquiries"
  | "cms"
  | "vault_security";

export type AdminOrderStatus =
  | "pending_verification"
  | "pending_inspection"
  | "accepted"
  | "vault_packed"
  | "in_transit"
  | "delivered"
  | "rejected";

export interface AdminOrder {
  id: string;
  dbId?: string;
  orderNumber?: string;
  createdAt?: string | null;
  date: string;
  clientName: string;
  email: string;
  phone: string;
  gemstoneName: string;
  carat: number;
  total: number;
  subtotal?: number;
  currency?: string;
  status: AdminOrderStatus;
  courier: string;
  destination: string;
  shippingAddress?: string;
  city?: string;
  state?: string;
  country?: string;
  postalCode?: string;
  paymentMethod?: string;
  bankReference?: string;
  paymentSlipUrl?: string;
  trackingNumber?: string | null;
  items?: Array<{
    gemstone?: {
      name?: string;
      carat?: number;
      price?: number;
      type?: string;
      images?: string[];
    };
    setting?: {
      name?: string;
      price?: number;
    };
    ringSize?: string;
    giftBox?: boolean;
    tamperSealInspected?: boolean;
    notes?: string;
  }>;
}

export interface SalonInquiry {
  id: string;
  date: string;
  clientName: string;
  email: string;
  phone: string;
  gemstoneId?: string;
  gemstoneName?: string;
  location: string;
  salon?: string;
  message: string;
  status: "new" | "scheduled" | "resolved";
}

export interface VIPClient {
  name: string;
  email: string;
  phone: string;
  totalSpent: number;
  acquisitions: number;
  tier: string;
  location: string;
  salon?: string;
}

export interface NewGemstoneForm {
  name: string;
  type: GemstoneType;
  variety: string;
  carat: number;
  price: number;
  cut: GemstoneCut;
  cutDetail: string;
  color: string;
  colorGrade: string;
  clarity: string;
  origin: string;
  originCountry?: string;
  species?: string;
  treatment?: TreatmentType;
  isUnheated?: boolean;
  lab?: CertificationLab;
  reportNumber?: string;
  issueDate?: string;
  comments?: string;
  rarityScore?: number;
  description: string;
  imageUrl: string;
  images?: string[];
  variants?: GemstoneVariant[];
  size?: string;
  inStock?: boolean;
  certificateUrl?: string;
  certificateFileName?: string;
  video?: string;
}

export interface AdminUser {
  name: string;
  email: string;
  phone?: string;
  role?: string;
}

export interface AdminDashboardProps {
  initialTab?: AdminTab;
}
