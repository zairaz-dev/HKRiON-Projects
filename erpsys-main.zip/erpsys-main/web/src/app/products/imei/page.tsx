"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Smartphone,
  Search,
  Plus,
  Loader2,
  CheckCircle,
  AlertCircle,
  Building2,
  Filter,
  Package,
  Calendar,
  User,
  Receipt,
  ShieldCheck,
  Tag,
  ArrowRight,
  RefreshCw,
  Clock,
  ChevronLeft,
  Barcode,
  Sparkles,
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { authService } from "@/services/auth-service";
import { branchService } from "@/services/branch-service";
import { productService } from "@/services/product-service";
import { imeiService, ProductImeiItem } from "@/services/imei-service";

export default function ImeiTrackingPage() {
  const router = useRouter();

  const [currentUser, setCurrentUser] = useState<any>(null);
  const [businessId, setBusinessId] = useState<string>("");

  const [branches, setBranches] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);

  const [selectedBranch, setSelectedBranch] = useState<string>("all");
  const [selectedStatus, setSelectedStatus] = useState<string>("all");
  const [searchKeyword, setSearchKeyword] = useState<string>("");

  const [imeiList, setImeiList] = useState<ProductImeiItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [page, setPage] = useState<number>(1);
  const [total, setTotal] = useState<number>(0);

  // Quick Tracker Search
  const [trackQuery, setTrackQuery] = useState<string>("");
  const [trackingResult, setTrackingResult] = useState<ProductImeiItem | null>(null);
  const [searchingTrack, setSearchingTrack] = useState<boolean>(false);
  const [trackSearched, setTrackSearched] = useState<boolean>(false);

  // Add IMEI Modal State
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [addBranchId, setAddBranchId] = useState<string>("");
  const [addProductId, setAddProductId] = useState<string>("");
  const [addVariantId, setAddVariantId] = useState<string>("");
  const [rawImeiText, setRawImeiText] = useState<string>("");
  const [savingImei, setSavingImei] = useState<boolean>(false);

  const [notification, setNotification] = useState<{ type: "success" | "error"; message: string } | null>(null);

  useEffect(() => {
    const user = authService.getCurrentUser();
    if (!user || !user.businessId) {
      router.push("/login");
      return;
    }
    setCurrentUser(user);
    setBusinessId(user.businessId);

    loadMetaAndData(user.businessId);
  }, []);

  const loadMetaAndData = async (bId: string) => {
    setLoading(true);
    try {
      const [branchRes, prodRes] = await Promise.all([
        branchService.getBranches(bId).catch(() => []),
        productService.getProducts(bId, { all: true }).then((res: any) => res?.data || res || []).catch(() => []),
      ]);

      setBranches(branchRes || []);
      setProducts(Array.isArray(prodRes) ? prodRes : (prodRes as any)?.data || []);
      if (branchRes && branchRes.length > 0) {
        setAddBranchId(branchRes[0].id);
      }

      await fetchImeis(bId, 1, selectedBranch, selectedStatus, searchKeyword);
    } catch (err: any) {
      showNotice("error", err.message || "Failed to load initial data.");
    } finally {
      setLoading(false);
    }
  };

  const fetchImeis = async (
    bId: string,
    p: number,
    branch: string,
    status: string,
    search: string
  ) => {
    setLoading(true);
    try {
      const res = await imeiService.getImeis({
        businessId: bId,
        branchId: branch === "all" ? undefined : branch,
        status: status === "all" ? undefined : status,
        search: search || undefined,
        page: p,
        limit: 15,
      });

      setImeiList(res.items || []);
      setTotal(res.total || 0);
      setPage(res.page || 1);
    } catch (err: any) {
      showNotice("error", err.message || "Failed to fetch IMEI list.");
    } finally {
      setLoading(false);
    }
  };

  const showNotice = (type: "success" | "error", message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 4500);
  };

  const handleTrackSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!trackQuery.trim()) {
      setTrackingResult(null);
      setTrackSearched(false);
      return;
    }

    setSearchingTrack(true);
    setTrackSearched(true);
    try {
      const results = await imeiService.searchImei(trackQuery, businessId);
      if (results && results.length > 0) {
        setTrackingResult(results[0]);
      } else {
        setTrackingResult(null);
      }
    } catch (err: any) {
      showNotice("error", "Error searching IMEI.");
    } finally {
      setSearchingTrack(false);
    }
  };

  const handleBulkAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!addBranchId || !addProductId || !addVariantId || !rawImeiText.trim()) {
      showNotice("error", "Please select branch, product, variant and enter at least one IMEI.");
      return;
    }

    const lines = rawImeiText
      .split(/[\n,]+/)
      .map((l) => l.trim())
      .filter(Boolean);

    if (lines.length === 0) {
      showNotice("error", "No valid IMEI numbers found.");
      return;
    }

    const imeis = lines.map((line) => ({
      imeiNumber: line.trim(),
    }));

    setSavingImei(true);
    try {
      const res = await imeiService.bulkAdd({
        businessId,
        branchId: addBranchId,
        productId: addProductId,
        variantId: addVariantId,
        imeis,
      });

      showNotice("success", `Successfully added ${res.count} IMEI/Serial numbers!`);
      setShowAddModal(false);
      setRawImeiText("");
      fetchImeis(businessId, 1, selectedBranch, selectedStatus, searchKeyword);
    } catch (err: any) {
      showNotice("error", err.message || "Failed to save IMEIs.");
    } finally {
      setSavingImei(false);
    }
  };

  const handleStatusChange = async (id: string, newStatus: string) => {
    try {
      await imeiService.updateStatus(id, businessId, { status: newStatus });
      showNotice("success", `Status updated to ${newStatus}`);
      fetchImeis(businessId, page, selectedBranch, selectedStatus, searchKeyword);
      if (trackingResult && trackingResult.id === id) {
        setTrackingResult({ ...trackingResult, status: newStatus as any });
      }
    } catch (err: any) {
      showNotice("error", err.message || "Failed to update status.");
    }
  };

  const selectedProductVariants =
    products.find((p) => p.id === addProductId)?.variants || [];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "IN_STOCK":
        return "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30";
      case "SOLD":
        return "bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-500/30";
      case "RETURNED":
        return "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30";
      case "DEFECTIVE":
        return "bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30";
      default:
        return "bg-muted text-muted-foreground border-border/50";
    }
  };

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/products" />
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Ambient Glows */}
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-primary/5 blur-[120px] pointer-events-none z-0" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[550px] h-[550px] rounded-full bg-primary/5 blur-[130px] pointer-events-none z-0" />

        <Navbar title="IMEI & Serial Tracker" className="relative z-10" />

        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 relative z-10">
          <div className="max-w-6xl mx-auto space-y-6">

            {/* Top Bar Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <button
                  onClick={() => router.push("/products")}
                  className="inline-flex items-center text-xs font-semibold text-muted-foreground hover:text-primary mb-2 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4 mr-1" /> Back to Products
                </button>
                <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                  <Smartphone className="h-7 w-7 text-primary" /> IMEI & Serial Number Management
                </h1>
                <p className="text-sm text-muted-foreground mt-1">
                  Lookup IMEI lifecycles, track stock inventory by serial numbers, and verify warranty dates.
                </p>
              </div>

              <Button
                onClick={() => setShowAddModal(true)}
                className="gap-2 shadow-md shadow-primary/10"
              >
                <Plus className="w-4 h-4" /> Add IMEI / Serial
              </Button>
            </div>

            {/* Notification Alert */}
            {notification && (
              <div
                className={`p-3.5 rounded-lg border text-sm flex items-center gap-2 animate-in fade-in ${
                  notification.type === "success"
                    ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400"
                    : "bg-destructive/10 border-destructive/30 text-destructive"
                }`}
              >
                {notification.type === "success" ? (
                  <CheckCircle className="w-4 h-4 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0" />
                )}
                <span>{notification.message}</span>
              </div>
            )}

            {/* Instant IMEI Lifecycle Search Box */}
            <Card className="border border-primary/30 bg-gradient-to-br from-primary/5 via-card/40 to-background/50 backdrop-blur-md shadow-lg">
              <CardContent className="p-5 space-y-4">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-primary animate-pulse" />
                  <h2 className="text-sm font-bold text-foreground">
                    Instant IMEI / Serial Lifecycle Lookup
                  </h2>
                </div>

                <form onSubmit={handleTrackSearch} className="flex gap-2">
                  <div className="relative flex-1">
                    <Input
                      type="text"
                      placeholder="Scan or Enter 15-digit IMEI or Serial Number..."
                      value={trackQuery}
                      onChange={(e) => setTrackQuery(e.target.value)}
                      className="h-11 font-mono text-sm pl-10 bg-background/80"
                    />
                    <Barcode className="w-5 h-5 text-muted-foreground absolute left-3 top-3" />
                  </div>
                  <Button type="submit" disabled={searchingTrack} className="h-11 px-5 gap-2">
                    {searchingTrack ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                    Search
                  </Button>
                </form>

                {/* Search Result Card */}
                {trackSearched && (
                  <div>
                    {trackingResult ? (
                      <div className="p-4 rounded-xl border border-border/60 bg-card/60 space-y-3 animate-in fade-in">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-border/40 pb-2.5">
                          <div className="flex items-center gap-2.5">
                            <span className="font-mono font-extrabold text-base text-primary">
                              IMEI: {trackingResult.imeiNumber}
                            </span>
                          </div>
                          <span
                            className={`px-2.5 py-1 text-xs font-bold uppercase rounded-full border ${getStatusBadge(
                              trackingResult.status
                            )}`}
                          >
                            {trackingResult.status.replace("_", " ")}
                          </span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                          <div className="space-y-0.5">
                            <span className="text-muted-foreground text-[10px]">Product / Model:</span>
                            <p className="font-bold">{trackingResult.product?.name || (trackingResult as any).productName || "Unknown"}</p>
                            <p className="text-[10px] text-muted-foreground">
                              {trackingResult.variant?.name || (trackingResult as any).variantName}
                            </p>
                          </div>

                          <div className="space-y-0.5">
                            <span className="text-muted-foreground text-[10px]">Branch Location:</span>
                            <p className="font-bold flex items-center gap-1">
                              <Building2 className="w-3.5 h-3.5 text-primary" />
                              {trackingResult.branch?.name || (trackingResult as any).branchName}
                            </p>
                          </div>

                          <div className="space-y-0.5">
                            <span className="text-muted-foreground text-[10px]">Purchase Inflow:</span>
                            <p className="font-medium">
                              {trackingResult.purchaseDate
                                ? new Date(trackingResult.purchaseDate).toLocaleDateString()
                                : "N/A"}
                            </p>
                          </div>

                          <div className="space-y-0.5">
                            <span className="text-muted-foreground text-[10px]">Sales Outflow:</span>
                            {trackingResult.soldDate ? (
                              <div>
                                <p className="font-bold text-sky-500">
                                  Sold on {new Date(trackingResult.soldDate).toLocaleDateString()}
                                </p>
                                {trackingResult.saleLine?.sale && (
                                  <p className="text-[10px] text-muted-foreground">
                                    Inv: {trackingResult.saleLine.sale.invoiceNumber} (
                                    {trackingResult.saleLine.sale.customer?.name})
                                  </p>
                                )}
                              </div>
                            ) : (
                              <p className="text-emerald-500 font-semibold">Available for Sale</p>
                            )}
                          </div>
                        </div>

                        {/* Status update selector */}
                        <div className="flex items-center gap-2 pt-2 border-t border-border/40 text-xs">
                          <span className="text-muted-foreground text-[11px]">Quick Status Change:</span>
                          <select
                            value={trackingResult.status}
                            onChange={(e) => handleStatusChange(trackingResult.id, e.target.value)}
                            className="h-8 px-2 rounded bg-background border border-border text-xs font-semibold focus:outline-none"
                          >
                            <option value="IN_STOCK">IN STOCK</option>
                            <option value="SOLD">SOLD</option>
                            <option value="RETURNED">RETURNED</option>
                            <option value="DEFECTIVE">DEFECTIVE</option>
                          </select>
                        </div>
                      </div>
                    ) : (
                      <div className="p-4 text-center text-xs text-muted-foreground bg-background/50 rounded-lg border border-dashed border-border/60">
                        No product found matching IMEI / Serial Number: <strong>"{trackQuery}"</strong>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Filter and IMEI Table */}
            <div className="space-y-3">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-card/40 p-3 rounded-xl border border-border/60 backdrop-blur-md">
                <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                  {/* Branch Filter */}
                  <div className="flex items-center gap-1.5 bg-background/80 px-2.5 py-1.5 rounded-lg border border-border/60 text-xs">
                    <Building2 className="w-3.5 h-3.5 text-primary" />
                    <select
                      value={selectedBranch}
                      onChange={(e) => {
                        setSelectedBranch(e.target.value);
                        fetchImeis(businessId, 1, e.target.value, selectedStatus, searchKeyword);
                      }}
                      className="bg-transparent font-semibold focus:outline-none cursor-pointer"
                    >
                      <option value="all">All Branches</option>
                      {branches.map((b) => (
                        <option key={b.id} value={b.id}>
                          {b.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Status Filter */}
                  <div className="flex items-center gap-1.5 bg-background/80 px-2.5 py-1.5 rounded-lg border border-border/60 text-xs">
                    <Filter className="w-3.5 h-3.5 text-primary" />
                    <select
                      value={selectedStatus}
                      onChange={(e) => {
                        setSelectedStatus(e.target.value);
                        fetchImeis(businessId, 1, selectedBranch, e.target.value, searchKeyword);
                      }}
                      className="bg-transparent font-semibold focus:outline-none cursor-pointer"
                    >
                      <option value="all">All Statuses</option>
                      <option value="IN_STOCK">In Stock</option>
                      <option value="SOLD">Sold</option>
                      <option value="RETURNED">Returned</option>
                      <option value="DEFECTIVE">Defective</option>
                    </select>
                  </div>
                </div>

                {/* Table Search */}
                <div className="relative w-full sm:w-64">
                  <Input
                    type="text"
                    placeholder="Search table..."
                    value={searchKeyword}
                    onChange={(e) => {
                      setSearchKeyword(e.target.value);
                      fetchImeis(businessId, 1, selectedBranch, selectedStatus, e.target.value);
                    }}
                    className="h-9 text-xs pl-8 bg-background/80"
                  />
                  <Search className="w-3.5 h-3.5 text-muted-foreground absolute left-2.5 top-2.5" />
                </div>
              </div>

              {/* Table Card */}
              <Card className="border border-border/50 bg-card/30 backdrop-blur-md overflow-hidden">
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-muted/40 border-b border-border/40 text-muted-foreground font-semibold">
                        <tr>
                          <th className="p-3.5">IMEI / Serial Number</th>
                          <th className="p-3.5">Product & Model</th>
                          <th className="p-3.5">Branch</th>
                          <th className="p-3.5">Status</th>
                          <th className="p-3.5">Purchase Date</th>
                          <th className="p-3.5">Sold Date</th>
                          <th className="p-3.5 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border/30">
                        {loading ? (
                          <tr>
                            <td colSpan={7} className="p-8 text-center text-muted-foreground">
                              <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-primary" />
                              Loading IMEI records...
                            </td>
                          </tr>
                        ) : imeiList.length > 0 ? (
                          imeiList.map((item) => (
                            <tr key={item.id} className="hover:bg-primary/5 transition-colors">
                              <td className="p-3.5">
                                <div className="font-mono font-bold text-foreground">
                                  {item.imeiNumber}
                                </div>
                              </td>
                              <td className="p-3.5">
                                <div className="font-semibold text-foreground">
                                  {item.product?.name || (item as any).productName || "Product"}
                                </div>
                                <div className="text-[10px] text-muted-foreground">
                                  {item.variant?.name || (item as any).variantName}
                                </div>
                              </td>
                              <td className="p-3.5">
                                <span className="inline-flex items-center gap-1">
                                  <Building2 className="w-3 h-3 text-muted-foreground" />
                                  {item.branch?.name || (item as any).branchName}
                                </span>
                              </td>
                              <td className="p-3.5">
                                <span
                                  className={`px-2 py-0.5 rounded-full border text-[10px] font-bold ${getStatusBadge(
                                    item.status
                                  )}`}
                                >
                                  {item.status.replace("_", " ")}
                                </span>
                              </td>
                              <td className="p-3.5 text-muted-foreground">
                                {item.purchaseDate
                                  ? new Date(item.purchaseDate).toLocaleDateString()
                                  : "-"}
                              </td>
                              <td className="p-3.5">
                                {item.soldDate ? (
                                  <span className="text-sky-600 dark:text-sky-400 font-medium">
                                    {new Date(item.soldDate).toLocaleDateString()}
                                  </span>
                                ) : (
                                  <span className="text-muted-foreground text-[11px]">-</span>
                                )}
                              </td>
                              <td className="p-3.5 text-right">
                                <select
                                  value={item.status}
                                  onChange={(e) => handleStatusChange(item.id, e.target.value)}
                                  className="h-7 px-1.5 rounded bg-background/80 border border-border/60 text-[11px] font-medium focus:outline-none"
                                >
                                  <option value="IN_STOCK">In Stock</option>
                                  <option value="SOLD">Sold</option>
                                  <option value="RETURNED">Returned</option>
                                  <option value="DEFECTIVE">Defective</option>
                                </select>
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={7} className="p-8 text-center text-muted-foreground italic">
                              No IMEI / Serial number records found.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              {/* Total & Pagination */}
              <div className="flex items-center justify-between text-xs text-muted-foreground px-1">
                <span>Total records: <strong>{total}</strong></span>
              </div>
            </div>

          </div>
        </main>
      </div>

      {/* Add IMEI Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <Card className="w-full max-w-lg border border-border/80 bg-background shadow-2xl animate-in zoom-in-95 duration-150">
            <form onSubmit={handleBulkAdd}>
              <div className="p-5 border-b border-border/60 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-primary/10 text-primary">
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <h3 className="text-sm font-bold text-foreground">
                    Add IMEI / Serial Numbers to Stock
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="text-muted-foreground hover:text-foreground text-sm"
                >
                  ✕
                </button>
              </div>

              <CardContent className="p-5 space-y-4">
                {/* Branch */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold">Stock Branch</label>
                  <select
                    value={addBranchId}
                    onChange={(e) => setAddBranchId(e.target.value)}
                    className="w-full h-10 px-3 rounded-md bg-background border border-border text-xs focus:ring-1 focus:ring-primary focus:outline-none"
                  >
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Product */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold">Select Product</label>
                  <select
                    value={addProductId}
                    onChange={(e) => {
                      setAddProductId(e.target.value);
                      const prod = products.find((p) => p.id === e.target.value);
                      if (prod && prod.variants && prod.variants.length > 0) {
                        setAddVariantId(prod.variants[0].id);
                      } else {
                        setAddVariantId("");
                      }
                    }}
                    className="w-full h-10 px-3 rounded-md bg-background border border-border text-xs focus:ring-1 focus:ring-primary focus:outline-none"
                  >
                    <option value="">-- Choose Product --</option>
                    {products.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Variant */}
                {selectedProductVariants.length > 0 && (
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold">Product Variant / SKU</label>
                    <select
                      value={addVariantId}
                      onChange={(e) => setAddVariantId(e.target.value)}
                      className="w-full h-10 px-3 rounded-md bg-background border border-border text-xs focus:ring-1 focus:ring-primary focus:outline-none"
                    >
                      {selectedProductVariants.map((v: any) => (
                        <option key={v.id} value={v.id}>
                          {v.name} (SKU: {v.sku})
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {/* Paste IMEI Textarea */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold">
                    IMEI / Serial Numbers (One per line or comma separated)
                  </label>
                  <textarea
                    rows={5}
                    value={rawImeiText}
                    onChange={(e) => setRawImeiText(e.target.value)}
                    placeholder={"354892019283741\n354892019283742\n354892019283743"}
                    className="w-full p-3 font-mono text-xs rounded-md bg-background border border-border focus:ring-1 focus:ring-primary focus:outline-none"
                  />
                  <p className="text-[10px] text-muted-foreground">
                    Tip: Enter one IMEI / Serial number per line.
                  </p>
                </div>
              </CardContent>

              <div className="p-4 border-t border-border/60 flex items-center justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowAddModal(false)}
                  className="text-xs"
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={savingImei} className="text-xs gap-1.5">
                  {savingImei ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
                  Save IMEIs to Stock
                </Button>
              </div>
            </form>
          </Card>
        </div>
      )}
    </div>
  );
}
