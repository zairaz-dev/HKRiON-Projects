import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { SalesAiTool } from './tools/sales-ai.tool';
import { ProductsAiTool } from './tools/products-ai.tool';
import { CustomersAiTool } from './tools/customers-ai.tool';
import { SuppliersAiTool } from './tools/suppliers-ai.tool';
import { UsersAiTool } from './tools/users-ai.tool';
import { FinanceAiTool } from './tools/finance-ai.tool';

@Injectable()
export class AiToolsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly salesTool: SalesAiTool,
    private readonly productsTool: ProductsAiTool,
    private readonly customersTool: CustomersAiTool,
    private readonly suppliersTool: SuppliersAiTool,
    private readonly usersTool: UsersAiTool,
    private readonly financeTool: FinanceAiTool,
  ) {}

  /**
   * General KPI snapshot of the business
   */
  async getBusinessSnapshot(businessId: string) {
    const [productsCount, customersCount, branchesCount] = await Promise.all([
      this.prisma.product.count({ where: { businessId } }),
      this.prisma.customer.count({ where: { businessId } }),
      this.prisma.branch.count({ where: { businessId } }),
    ]);

    const business = await this.prisma.business.findUnique({
      where: { id: businessId },
      select: { name: true, currency: true },
    });

    return {
      businessName: business?.name || 'HKRION Business',
      currency: business?.currency || 'LKR',
      totalProducts: productsCount,
      totalCustomers: customersCount,
      totalBranches: branchesCount,
    };
  }

  /**
   * Intelligently orchestrates modular tools based on keywords and role permissions
   */
  async buildAiContext(
    businessId: string,
    userMessage: string,
    branchId?: string,
    userRole = 'CASHIER',
  ) {
    const lower = userMessage.toLowerCase();
    const contextData: Record<string, any> = {};

    // 1. Always include baseline business identity
    contextData.snapshot = await this.getBusinessSnapshot(businessId);

    // 2. Sales tool trigger
    if (
      lower.includes('sale') ||
      lower.includes('today') ||
      lower.includes('revenue') ||
      lower.includes('invoice') ||
      lower.includes('income') ||
      lower.includes('bill') ||
      lower.includes('விற்பனை') ||
      lower.includes('இன்றைய') ||
      lower.includes('பில்')
    ) {
      contextData.sales = await this.salesTool.getSalesContext(businessId, branchId, userRole);
    }

    // 3. Products & Stock tool trigger
    if (
      lower.includes('stock') ||
      lower.includes('product') ||
      lower.includes('item') ||
      lower.includes('low stock') ||
      lower.includes('inventory') ||
      lower.includes('catalog') ||
      lower.includes('price') ||
      lower.includes('rate') ||
      lower.includes('பொருள்') ||
      lower.includes('பொருட்கள்') ||
      lower.includes('இருப்பு') ||
      lower.includes('விலை')
    ) {
      contextData.inventory = await this.productsTool.getProductsContext(businessId);
    }

    // 4. Customers & Receivables tool trigger
    if (
      lower.includes('customer') ||
      lower.includes('due') ||
      lower.includes('credit') ||
      lower.includes('client') ||
      lower.includes('receivable') ||
      lower.includes('வாடிக்கையாளர்') ||
      lower.includes('நிலுவை')
    ) {
      contextData.customers = await this.customersTool.getCustomersContext(businessId);
    }

    // 5. Suppliers & Payables tool trigger
    if (
      lower.includes('supplier') ||
      lower.includes('purchase') ||
      lower.includes('vendor') ||
      lower.includes('payable') ||
      lower.includes('சப்ளையர்') ||
      lower.includes('கொள்முதல்')
    ) {
      contextData.suppliers = await this.suppliersTool.getSuppliersContext(businessId, userRole);
    }

    // 6. Users & Staff directory tool trigger
    if (
      lower.includes('user') ||
      lower.includes('staff') ||
      lower.includes('employee') ||
      lower.includes('cashier') ||
      lower.includes('பணியாளர்') ||
      lower.includes('ஊழியர்')
    ) {
      contextData.users = await this.usersTool.getUsersContext(businessId, userRole);
    }

    // 7. Finance & Expenses tool trigger
    if (
      lower.includes('expense') ||
      lower.includes('cost') ||
      lower.includes('spending') ||
      lower.includes('profit') ||
      lower.includes('margin') ||
      lower.includes('செலவு') ||
      lower.includes('லாபம்')
    ) {
      contextData.finance = await this.financeTool.getFinanceContext(businessId, userRole);
    }

    return contextData;
  }
}
