https://chatgpt.com/share/6a42e65e-6c04-83ee-9f05-cc4082f8631f
