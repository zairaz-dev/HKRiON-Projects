"use client";

import React, { useState, useEffect, useRef } from "react";
import {
  Bot,
  Sparkles,
  X,
  Send,
  RotateCcw,
  Copy,
  Check,
  ChevronDown,
  Loader2,
  TrendingUp,
  AlertTriangle,
  Users,
  DollarSign,
  HelpCircle,
  Zap,
} from "lucide-react";
import { aiService, ChatMessage, AiStatusResponse } from "@/services/ai-service";
import { authService } from "@/services/auth-service";

/**
 * Lightweight markdown-like formatter for AI responses
 */
function FormattedMessageContent({ text }: { text: string }) {
  const lines = text.split("\n");

  return (
    <div className="space-y-1.5 text-xs leading-relaxed break-words">
      {lines.map((line, idx) => {
        const trimmed = line.trim();
        if (!trimmed) {
          return <div key={idx} className="h-1" />;
        }

        // Bullet point
        if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
          const content = trimmed.substring(2);
          return (
            <div key={idx} className="flex items-start gap-2 pl-2">
              <span className="text-primary font-bold">•</span>
              <span>{renderInlineStyles(content)}</span>
            </div>
          );
        }

        // Numbered list
        const numMatch = trimmed.match(/^(\d+)\.\s+(.*)/);
        if (numMatch) {
          return (
            <div key={idx} className="flex items-start gap-2 pl-2">
              <span className="font-mono text-primary font-bold text-[11px]">
                {numMatch[1]}.
              </span>
              <span>{renderInlineStyles(numMatch[2])}</span>
            </div>
          );
        }

        // Header ###
        if (trimmed.startsWith("### ")) {
          return (
            <div key={idx} className="font-bold text-foreground font-mono pt-1 text-xs">
              {renderInlineStyles(trimmed.substring(4))}
            </div>
          );
        }

        return <div key={idx}>{renderInlineStyles(line)}</div>;
      })}
    </div>
  );
}

function renderInlineStyles(text: string): React.ReactNode {
  // Simple bold parser **bold**
  const parts = text.split(/(\*\*.*?\*\*|`.*?`)/g);
  return parts.map((part, i) => {
    if (part.startsWith("**") && part.endsWith("**")) {
      return (
        <strong key={i} className="font-semibold text-foreground">
          {part.slice(2, -2)}
        </strong>
      );
    }
    if (part.startsWith("`") && part.endsWith("`")) {
      return (
        <code
          key={i}
          className="px-1 py-0.5 rounded bg-secondary/80 text-primary font-mono text-[11px]"
        >
          {part.slice(1, -1)}
        </code>
      );
    }
    return part;
  });
}

/**
 * Custom Robot Chat Bubble Icon matching HKRION ERP AI Copilot branding
 */
function RobotChatIcon({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Top Antenna with Ball */}
      <line
        x1="12"
        y1="5.8"
        x2="12"
        y2="3.8"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      />
      <circle cx="12" cy="2.5" r="1.5" fill="currentColor" />

      {/* Left Ear */}
      <rect
        x="1.5"
        y="9.5"
        width="2.5"
        height="5.5"
        rx="1.25"
        fill="currentColor"
      />

      {/* Right Ear */}
      <rect
        x="20"
        y="9.5"
        width="2.5"
        height="5.5"
        rx="1.25"
        fill="currentColor"
      />

      {/* Robot Face & Speech Bubble Outline */}
      <path
        d="M8 6h8a3.5 3.5 0 0 1 3.5 3.5v4a3.5 3.5 0 0 1-3.5 3.5H8.8L4.5 20.2L5 15.8A3.5 3.5 0 0 1 4.5 13.5v-4A3.5 3.5 0 0 1 8 6z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Left Eye */}
      <circle cx="9" cy="11.5" r="1.6" fill="currentColor" />

      {/* Right Eye */}
      <circle cx="15" cy="11.5" r="1.6" fill="currentColor" />

      {/* Friendly Smile */}
      <path
        d="M9.2 14.5c.8 1.4 2 1.8 2.8 1.8s2-.4 2.8-1.8"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function AiCopilotWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [status, setStatus] = useState<AiStatusResponse | null>(null);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Check login state
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const authed = authService.isAuthenticated();
    setIsLoggedIn(authed);
    if (authed) {
      aiService.getAiStatus().then((s) => setStatus(s)).catch(() => {});
    }
  }, []);

  useEffect(() => {
    if (isOpen) {
      aiService.getAiStatus().then((s) => setStatus(s)).catch(() => {});
      setTimeout(() => {
        inputRef.current?.focus({ preventScroll: true });
      }, 50);
    }
  }, [isOpen]);

  useEffect(() => {
    if (isOpen && messages.length > 0) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
  }, [messages.length, isOpen]);

  if (!isLoggedIn) return null;

  const quickPrompts = [
    { label: "Today's Sales", prompt: "Show today's sales summary and invoice overview", icon: TrendingUp },
    { label: "Low Stock Alert", prompt: "Which products are currently low on stock?", icon: AlertTriangle },
    { label: "Top Customers", prompt: "Show top 5 customers and outstanding receivables", icon: Users },
    { label: "Monthly Expenses", prompt: "What are this month's total expenses and breakdown?", icon: DollarSign },
  ];

  const handleSendMessage = async (customPrompt?: string) => {
    const textToSend = (customPrompt || inputMessage).trim();
    if (!textToSend || isLoading) return;

    const newMessages: ChatMessage[] = [
      ...messages,
      { role: "user", content: textToSend },
    ];

    setMessages(newMessages);
    setInputMessage("");
    setIsLoading(true);

    try {
      // Optimize token payload: send sliding window of last 6 messages
      const payloadMessages = newMessages.slice(-6);
      const response = await aiService.sendChatMessage(payloadMessages);
      setMessages([
        ...newMessages,
        { role: "assistant", content: response.reply },
      ]);
    } catch (err: any) {
      setMessages([
        ...newMessages,
        {
          role: "assistant",
          content: `⚠️ **Error:** ${err.message || "Failed to reach AI Copilot. Please check your internet or settings."}`,
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  const handleClearHistory = () => {
    setMessages([]);
  };

  return (
    <>
      {/* Floating Trigger Button */}
      <div className="fixed bottom-6 right-6 z-50">
        {!isOpen && (
          <div className="group relative flex items-center justify-center">
            {/* Tooltip on Hover */}
            <div className="pointer-events-none absolute right-full mr-3.5 px-3 py-1.5 rounded-lg bg-card/95 backdrop-blur-md border border-border/80 text-foreground text-xs font-semibold shadow-xl whitespace-nowrap opacity-0 translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-200 z-50 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              <span>HKRION AI</span>
              {/* Tooltip Arrow */}
              <div className="absolute left-full top-1/2 -translate-y-1/2 -ml-[1px] border-4 border-transparent border-l-card/95" />
            </div>

            {/* Circular Trigger Button with Primary Color and Robot Icon */}
            <button
              type="button"
              onClick={() => setIsOpen(true)}
              aria-label="Open AI Copilot"
              className="relative w-12 h-12 rounded-full bg-primary text-primary-foreground shadow-lg shadow-primary/30 hover:shadow-primary/50 hover:scale-110 active:scale-95 flex items-center justify-center transition-all duration-300 border border-primary/60 focus:outline-none"
            >
              {/* Live Status Pulse Indicator */}
              <span className="absolute top-0.5 right-0.5 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-400 border-2 border-background"></span>
              </span>

              <RobotChatIcon className="w-6 h-6 transition-transform group-hover:scale-110" />
            </button>
          </div>
        )}
      </div>

      {/* Floating Chat Modal / Window with Animated Primary Border Beam */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 w-[90vw] sm:w-[375px] h-[510px] max-h-[78vh] p-[1px] rounded-[8px] overflow-hidden ai-modal-glow animate-fadeIn bg-primary/25">
          {/* Animated Conic Light Beam using Primary Theme Color */}
          <div className="absolute inset-[-200%] bg-[conic-gradient(from_0deg,transparent_0_240deg,hsl(var(--primary)/0.35)_290deg,hsl(var(--primary))_360deg)] ai-beam-spin pointer-events-none" />

          {/* Inner Chat Card Container with Solid Dark Background */}
          <div className="relative z-10 w-full h-full rounded-[7px] bg-card flex flex-col overflow-hidden shadow-2xl">
            {/* Header */}
            <div className="p-3 px-3.5 bg-secondary/40 border-b border-border/70 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-md bg-primary text-primary-foreground flex items-center justify-center shadow-md shadow-primary/25">
                  <RobotChatIcon className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="text-xs font-bold text-foreground font-mono">
                      HKRION AI
                    </h3>
                  </div>
                  {/* <p className="text-[10px] text-muted-foreground truncate max-w-[180px]">
                    {status?.model || "Connecting..."}
                  </p> */}
                </div>
              </div>

            <div className="flex items-center gap-1">
              {messages.length > 0 && (
                <button
                  type="button"
                  title="Clear Chat History"
                  onClick={handleClearHistory}
                  className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-secondary/60 transition-colors text-xs"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              )}
              <button
                type="button"
                title="Close"
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-secondary/60 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Body: Messages or Welcome screen */}
          <div className="flex-1 min-h-0 overflow-y-auto p-4 space-y-3.5 select-text">
            {/* If AI is disabled globally */}
            {status && !status.isEnabled && (
              <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
                <div>
                  <div className="font-bold">AI Copilot is Disabled</div>
                  <div className="text-[11px] opacity-90 mt-0.5">
                    An Administrator can enable OpenRouter AI in <strong>Super Admin → Settings → AI Copilot</strong>.
                  </div>
                </div>
              </div>
            )}

            {messages.length === 0 ? (
              <div className="h-full flex flex-col justify-center items-center text-center space-y-4 px-2 my-auto">
                <div className="w-12 h-12 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary shadow-inner">
                  <RobotChatIcon className="w-6 h-6 text-primary animate-pulse" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-foreground">
                    How can I assist you today?
                  </h4>
                  <p className="text-xs text-muted-foreground mt-1 max-w-[280px]">
                    Ask about sales, inventory, low stock, customer balances, or ERP guidance.
                  </p>
                </div>

                {/* Quick Suggestion Chips */}
                <div className="w-full space-y-1.5 pt-2">
                  <span className="text-[10px] uppercase font-bold text-muted-foreground font-mono block text-left pl-1">
                    Quick Insights:
                  </span>
                  <div className="grid grid-cols-2 gap-1.5 text-left">
                    {quickPrompts.map((qp) => {
                      const Icon = qp.icon;
                      return (
                        <button
                          key={qp.label}
                          type="button"
                          onClick={() => handleSendMessage(qp.prompt)}
                          className="flex items-center gap-1.5 p-2 rounded-md bg-secondary/40 border border-border/60 hover:bg-secondary/80 hover:border-primary/40 transition-all text-[11px] text-foreground text-left"
                        >
                          <Icon className="w-3.5 h-3.5 text-primary shrink-0" />
                          <span className="truncate">{qp.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            ) : (
              messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex flex-col ${
                    m.role === "user" ? "items-end" : "items-start"
                  }`}
                >
                  <div
                    className={`max-w-[88%] rounded-lg p-3 text-xs ${
                      m.role === "user"
                        ? "bg-primary text-primary-foreground rounded-br-none shadow-md shadow-primary/10"
                        : "bg-secondary/60 text-foreground border border-border/60 rounded-bl-none shadow-sm"
                    }`}
                  >
                    <FormattedMessageContent text={m.content} />

                    {m.role === "assistant" && (
                      <div className="flex justify-end pt-1.5 mt-1 border-t border-border/30">
                        <button
                          type="button"
                          onClick={() => handleCopy(m.content, idx)}
                          className="text-[10px] text-muted-foreground hover:text-foreground flex items-center gap-1 font-mono transition-colors"
                        >
                          {copiedIdx === idx ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-400" /> Copied
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" /> Copy
                            </>
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}

            {/* Thinking Indicator */}
            {isLoading && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-secondary/40 border border-border/50 text-xs text-muted-foreground w-fit animate-pulse">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-primary" />
                <span className="font-mono text-[11px]">
                  Analyzing ERP database...
                </span>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Footer Input Bar */}
          <div className="p-3 bg-secondary/30 border-t border-border/70 shrink-0">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center gap-2"
            >
              <input
                ref={inputRef}
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Ask HKRION AI ..."
                className="flex-1 h-9 px-3 text-xs rounded-md bg-background/80 border border-border focus:outline-none focus:ring-1 focus:ring-primary text-foreground"
              />
              <button
                type="submit"
                disabled={isLoading || !inputMessage.trim()}
                className="h-9 w-9 rounded-md bg-primary text-primary-foreground flex items-center justify-center hover:opacity-90 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed transition-all shrink-0 shadow-md shadow-primary/20"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
            <div className="flex items-center justify-between text-[9px] text-muted-foreground px-1 pt-1.5 font-mono">
              {/* <span>Powered by OpenRouter AI</span> */}
              <span className="flex items-center gap-1">
                {/* <Zap className="w-2.5 h-2.5 text-amber-400" /> Live Data Guard */}
              </span>
            </div>
          </div>
        </div>
      </div>
      )}
    </>
  );
}
