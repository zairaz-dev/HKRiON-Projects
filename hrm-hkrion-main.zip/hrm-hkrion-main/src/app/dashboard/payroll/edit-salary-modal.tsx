"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { toast } from "sonner";
import { Banknote, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Modal } from "@/components/ui/modal";
import { updateBaseSalary } from "@/actions/payroll";

const salarySchema = z.object({
  baseSalary: z.preprocess((val) => Number(val), z.number().min(0, "Salary must be a positive number")),
  currency: z.string().min(1, "Currency is required"),
  effectiveDate: z.preprocess((val) => (typeof val === "string" || typeof val === "number" ? new Date(val) : val), z.date()),
});

type SalaryFormValues = z.infer<typeof salarySchema>;

type EditSalaryModalProps = {
  employee: {
    id: number;
    firstName: string;
    lastName: string;
    compensations: { baseSalary: any; currency: string; effectiveDate: Date }[];
  };
  onClose: () => void;
};

export default function EditSalaryModal({ employee, onClose }: EditSalaryModalProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const activeComp = employee.compensations[0];

  const form = useForm<SalaryFormValues>({
    resolver: zodResolver(salarySchema) as any,
    defaultValues: {
      baseSalary: activeComp ? Number(activeComp.baseSalary) : 0,
      currency: activeComp?.currency || "LKR",
      effectiveDate: new Date().toISOString().split('T')[0] as any, // Cast for form typings
    },
  });

  const onSubmit = async (data: SalaryFormValues) => {
    setIsSubmitting(true);
    const res = await updateBaseSalary(employee.id, data.baseSalary, data.currency, data.effectiveDate);
    
    if (res.error) {
      toast.error(res.error);
    } else {
      toast.success(`Updated salary for ${employee.firstName} successfully.`);
      onClose();
    }
    setIsSubmitting(false);
  };

  return (
    <Modal isOpen={true} onClose={onClose} size="sm" title="Update Employee Salary">
      <div className="mb-6 pb-4 border-b border-border/60">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-full bg-primary-soft text-primary flex items-center justify-center border border-primary/20">
            <Banknote className="h-5 w-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-text-primary">{employee.firstName} {employee.lastName}</h3>
            <p className="text-xs text-text-muted">Set new base compensation</p>
          </div>
        </div>
      </div>

      <form onSubmit={form.handleSubmit(onSubmit as any)} className="space-y-4">
        {/* Base Salary */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-text-secondary">Base Salary (Monthly)</label>
          <div className="relative">
            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted font-mono text-sm">
              {form.watch("currency") === "LKR" ? "Rs" : form.watch("currency") === "USD" ? "$" : ""}
            </div>
            <Input
              type="number"
              step="0.01"
              placeholder="0.00"
              className={`pl-8 bg-surface-secondary border-border ${form.formState.errors.baseSalary ? "border-error focus-visible:ring-error" : ""}`}
              {...form.register("baseSalary")}
            />
          </div>
          {form.formState.errors.baseSalary && (
            <p className="text-[11px] text-error flex items-center gap-1 mt-1">
              <AlertCircle className="h-3 w-3" />
              {form.formState.errors.baseSalary.message}
            </p>
          )}
        </div>

        {/* Currency & Effective Date Row */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-text-secondary">Currency</label>
            <Input
              type="text"
              className={`bg-surface-secondary border-border uppercase ${form.formState.errors.currency ? "border-error focus-visible:ring-error" : ""}`}
              {...form.register("currency")}
            />
            {form.formState.errors.currency && (
              <p className="text-[11px] text-error flex items-center gap-1 mt-1">
                <AlertCircle className="h-3 w-3" />
                {form.formState.errors.currency.message}
              </p>
            )}
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-text-secondary">Effective Date</label>
            <Input
              type="date"
              className={`bg-surface-secondary border-border ${form.formState.errors.effectiveDate ? "border-error focus-visible:ring-error" : ""}`}
              {...form.register("effectiveDate")}
            />
            {form.formState.errors.effectiveDate && (
              <p className="text-[11px] text-error flex items-center gap-1 mt-1">
                <AlertCircle className="h-3 w-3" />
                {form.formState.errors.effectiveDate.message}
              </p>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-border mt-6">
          <Button type="button" variant="ghost" onClick={onClose} disabled={isSubmitting} className="text-sm cursor-pointer">
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting} className="gap-2 font-semibold shadow-sm cursor-pointer">
            {isSubmitting ? "Saving..." : "Save Compensation"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
