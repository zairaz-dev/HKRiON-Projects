"use client";

import React, { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { useAuth } from "@/features/auth/context/AuthContext";
import { SecurityLockIcon, GoogleIcon } from "@/components/ui/LuxuryIcons";
import { LuxurySelect } from "@/components/ui/LuxurySelect";
import { PHONE_CODE_OPTIONS, getPhoneCodeByCountryCode, getPhoneFormat } from "@/lib/data/countries";

function getSafeInternalUrl(url: string | null, fallback: string): string {
  if (!url) return fallback;
  if (
    url.startsWith("/") &&
    !url.startsWith("//") &&
    !url.startsWith("/\\") &&
    !url.toLowerCase().includes("javascript:") &&
    url !== "/admindashboard" &&
    !url.startsWith("/admindashboard/")
  ) {
    return url;
  }
  return fallback;
}

function UnifiedLoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { refreshProfile, user, isAuthenticated, isLoading: authLoading } = useAuth();

  const from = searchParams.get("from");
  const reason = searchParams.get("reason");

  // If already authenticated, redirect straight to target destination
  useEffect(() => {
    if (!authLoading && isAuthenticated) {
      if (user?.role === "ADMIN") {
        router.replace("/admindashboard");
        return;
      }
      const target = getSafeInternalUrl(from, "/account");
      router.replace(target);
    }
  }, [authLoading, isAuthenticated, user, from, router]);

  const [activeMode, setActiveMode] = useState<"signin" | "register">("signin");

  // Sign In state
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(() => {
    if (reason === "expired") {
      return "Your security session has expired. Please re-authenticate.";
    }
    const errParam = searchParams.get("error");
    return errParam ? decodeURIComponent(errParam) : null;
  });
  const [isLoading, setIsLoading] = useState(false);

  // Registration state
  const [regName, setRegName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regPhone, setRegPhone] = useState("");
  const [regPhoneCode, setRegPhoneCode] = useState("LK");

  // Google OAuth state
  const [isGoogleRedirecting, setIsGoogleRedirecting] = useState(false);

  const handleGoogleClick = async () => {
    setError(null);
    setIsGoogleRedirecting(true);
    try {
      const checkRes = await fetch("/api/auth/google?check=1");
      const checkData = await checkRes.json();
      if (checkData?.configured) {
        const safeFrom = getSafeInternalUrl(from, "");
        window.location.href = `/api/auth/google?from=${encodeURIComponent(safeFrom)}`;
        return;
      }
      setIsGoogleRedirecting(false);
      setError("Google Sign-In is not configured yet. Please sign in with your email and password.");
    } catch {
      setIsGoogleRedirecting(false);
      setError("Unable to connect to Google authentication service. Please sign in with your email and password.");
    }
  };

  const handleSignIn = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    const formData = new FormData(e.currentTarget);
    const activeEmail = ((formData.get("email") as string) || email).trim();
    const activePassword = (formData.get("password") as string) || password;

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: activeEmail, password: activePassword }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Authentication failed. Please verify credentials.");
        setIsLoading(false);
        return;
      }

      if (data.success) {
        await refreshProfile();

        // Admins can only go to admin dashboard
        if (data.role === "ADMIN" || data.user?.role === "ADMIN") {
          router.push("/admindashboard");
          router.refresh();
          return;
        }

        // Determine customer destination
        const target = getSafeInternalUrl(from || data.redirectUrl, "/account");
        router.push(target);
        router.refresh();
      }
    } catch {
      setError("Network or authentication service unavailable. Check connection.");
      setIsLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);

    const formData = new FormData(e.currentTarget);
    const activeName = ((formData.get("name") as string) || regName).trim();
    const activeEmail = ((formData.get("email") as string) || regEmail).trim();
    const activePhoneRaw = ((formData.get("phone") as string) || regPhone).trim();
    const activePassword = (formData.get("password") as string) || regPassword;

    if (!activePhoneRaw) {
      setError("Please enter your phone number.");
      return;
    }

    const phoneDigits = activePhoneRaw.replace(/\D/g, "");
    const phoneFmt = getPhoneFormat(regPhoneCode);
    if (!phoneFmt.validate(phoneDigits)) {
      const countryName = PHONE_CODE_OPTIONS.find((o) => o.value === regPhoneCode)?.sublabel || "this country";
      setError(`Please enter a valid phone number for ${countryName}.`);
      return;
    }

    setIsLoading(true);

    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: activeName,
          email: activeEmail,
          password: activePassword,
          phone: `${getPhoneCodeByCountryCode(regPhoneCode)} ${activePhoneRaw}`,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Registration failed. Please try again.");
        setIsLoading(false);
        return;
      }

      if (data.success) {
        await refreshProfile();
        const target = getSafeInternalUrl(from, "/account");
        router.push(target);
        router.refresh();
      }
    } catch {
      setError("Network or registration service unavailable.");
      setIsLoading(false);
    }
  };

  return (
    <div
      style={{ colorScheme: "dark" }}
      className="w-full max-w-md bg-[#131318] border border-[#2A2A36] shadow-2xl relative flex flex-col text-white rounded-none select-text my-auto z-10 login-dark-surface"
    >
      {/* Top Gold Gradient Accent */}
      <div className="h-1 bg-gradient-to-r from-[#9A7B4F] via-[#C5A880] to-[#E0CFA9] shrink-0" />

      <div className="p-5 sm:p-7 flex flex-col">
        {/* Branding */}
        <div className="text-center space-y-1.5 shrink-0 mb-3">
          <Link href="/" className="inline-block transition-opacity hover:opacity-85">
            <Image
              src="/logo.png"
              alt="Faizan Gems"
              width={64}
              height={64}
              className="h-12 w-12 sm:h-14 sm:w-14 object-contain mx-auto"
              priority
              unoptimized
            />
          </Link>

          <div>
            <h1 className="font-serif text-2xl text-white font-light mt-1">
              Faizan Gems
            </h1>
            <p className="text-[11px] text-[#8C867D] font-sans mt-0.5">
              Sign in to your account to continue.
            </p>
          </div>
        </div>

        {/* Checkout Prompt Notice */}
        {from === "/checkout" && (
          <div className="p-3 bg-[#C5A880]/15 border border-[#C5A880]/35 text-[#E0CFA9] text-xs font-sans mb-3 rounded flex items-center gap-2.5">
            <SecurityLockIcon className="w-4 h-4 text-[#C5A880] shrink-0" />
            <span>Please sign in or register to complete your secure checkout.</span>
          </div>
        )}

        {/* Mode Selector Tabs */}
        <div className="flex border-b border-[#24242C] text-xs font-sans shrink-0 mb-3">
          <button
            type="button"
            onClick={() => {
              setActiveMode("signin");
              setError(null);
            }}
            className={`flex-1 pb-2.5 uppercase tracking-wider transition-colors relative ${
              activeMode === "signin"
                ? "text-white font-medium after:absolute after:bottom-[-1px] after:inset-x-0 after:h-[2px] after:bg-[#C5A880]"
                : "text-[#8C867D] hover:text-white"
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveMode("register");
              setError(null);
            }}
            className={`flex-1 pb-2.5 uppercase tracking-wider transition-colors relative ${
              activeMode === "register"
                ? "text-white font-medium after:absolute after:bottom-[-1px] after:inset-x-0 after:h-[2px] after:bg-[#C5A880]"
                : "text-[#8C867D] hover:text-white"
            }`}
          >
            Register
          </button>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="p-2.5 bg-red-950/40 border border-red-900/60 rounded-sm text-red-200 text-xs font-sans shrink-0 mb-3">
            {error}
          </div>
        )}

        {/* Form Body - Fully accessible and naturally scrollable on mobile */}
        <div className="w-full">
          {/* 1. Sign In Form (For Both Admin and Customer) */}
          {activeMode === "signin" ? (
            <div className="space-y-4">
              <form onSubmit={handleSignIn} className="space-y-4">
                <div>
                  <label htmlFor="login-email" className="block text-[10px] uppercase font-mono tracking-wider text-[#A29F96] mb-1">
                    Email Address
                  </label>
                  <input
                    id="login-email"
                    name="email"
                    type="email"
                    required
                    autoComplete="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    style={{ colorScheme: "dark" }}
                    className="w-full h-11 sm:h-10 px-3.5 bg-[#1B1B22] border border-[#2A2A36] text-white text-base sm:text-xs font-sans placeholder-[#55524C] focus:outline-none focus:border-[#C5A880] transition-colors scroll-mt-4 dark-autofill-input"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label htmlFor="login-password" className="text-[10px] uppercase font-mono tracking-wider text-[#A29F96]">
                      Password
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="text-[10px] text-[#8C867D] hover:text-[#C5A880] transition-colors py-0.5 px-1"
                    >
                      {showPassword ? "Hide" : "Show"}
                    </button>
                  </div>
                  <input
                    id="login-password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    required
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    style={{ colorScheme: "dark" }}
                    className="w-full h-11 sm:h-10 px-3.5 bg-[#1B1B22] border border-[#2A2A36] text-white text-base sm:text-xs font-sans placeholder-[#55524C] focus:outline-none focus:border-[#C5A880] transition-colors scroll-mt-4 dark-autofill-input"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-xs uppercase font-sans font-semibold tracking-wider transition-colors disabled:opacity-50 mt-1 cursor-pointer active:scale-[0.99]"
                >
                  {isLoading ? "Signing In..." : "Sign In"}
                </button>
              </form>

              <div className="relative flex items-center justify-center my-3">
                <div className="border-t border-[#24242C] w-full" />
                <span className="bg-[#131318] px-3 text-[10px] uppercase font-mono tracking-widest text-[#737069] whitespace-nowrap">
                  or continue with
                </span>
                <div className="border-t border-[#24242C] w-full" />
              </div>

              {/* Continue with Google */}
              <button
                type="button"
                onClick={handleGoogleClick}
                disabled={isLoading || isGoogleRedirecting}
                className="w-full py-2.5 px-4 bg-[#1B1B24] hover:bg-[#252532] border border-[#2E2E3C] hover:border-[#C5A880] text-white text-xs font-sans font-medium flex items-center justify-center gap-3 transition-all duration-150 shadow-sm disabled:opacity-50 cursor-pointer active:scale-[0.99]"
              >
                <GoogleIcon className="w-4 h-4 shrink-0" />
                <span>{isGoogleRedirecting ? "Connecting to Google..." : "Continue with Google"}</span>
              </button>
            </div>
          ) : (
            /* 2. Register Patron Form */
            <div className="space-y-4">
              <form onSubmit={handleRegister} className="space-y-3 text-xs font-sans">
                <div>
                  <label htmlFor="reg-name" className="block text-[10px] uppercase font-mono tracking-wider text-[#A29F96] mb-1">
                    Full Name
                  </label>
                  <input
                    id="reg-name"
                    name="name"
                    type="text"
                    required
                    autoComplete="name"
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder="e.g. John Doe"
                    style={{ colorScheme: "dark" }}
                    className="w-full h-11 sm:h-10 px-3.5 bg-[#1B1B22] border border-[#2A2A36] text-white text-base sm:text-xs placeholder-[#55524C] focus:outline-none focus:border-[#C5A880] scroll-mt-4 dark-autofill-input"
                  />
                </div>

                <div>
                  <label htmlFor="reg-email" className="block text-[10px] uppercase font-mono tracking-wider text-[#A29F96] mb-1">
                    Email Address
                  </label>
                  <input
                    id="reg-email"
                    name="email"
                    type="email"
                    required
                    autoComplete="email"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="name@example.com"
                    style={{ colorScheme: "dark" }}
                    className="w-full h-11 sm:h-10 px-3.5 bg-[#1B1B22] border border-[#2A2A36] text-white text-base sm:text-xs placeholder-[#55524C] focus:outline-none focus:border-[#C5A880] scroll-mt-4 dark-autofill-input"
                  />
                </div>

                <div>
                  <label htmlFor="reg-phone" className="block text-[10px] uppercase font-mono tracking-wider text-[#A29F96] mb-1">
                    Phone Number
                  </label>
                  <div className="flex items-stretch gap-0 w-full">
                    <div className="w-[105px] sm:w-[115px] shrink-0 h-11 sm:h-10 relative">
                      <LuxurySelect
                        value={regPhoneCode}
                        onChange={(val) => setRegPhoneCode(val)}
                        options={PHONE_CODE_OPTIONS}
                        placeholder="+94"
                        searchable={true}
                        searchPlaceholder="Search code..."
                        variant="dark"
                        size="sm"
                        className="h-full !block"
                        triggerClassName="!h-full !rounded-none !border-r-0 !py-0 !px-2.5 sm:!px-3 !text-sm sm:!text-xs !bg-[#1B1B22] !border-[#2A2A36] focus:!border-[#C5A880] active:!scale-100 flex items-center justify-between"
                        menuClassName="!min-w-[240px]"
                      />
                    </div>
                    <input
                      id="reg-phone"
                      name="phone"
                      type="tel"
                      required
                      autoComplete="tel-national"
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      placeholder={getPhoneFormat(regPhoneCode).placeholder}
                      style={{ colorScheme: "dark" }}
                      className="flex-1 min-w-0 h-11 sm:h-10 px-3.5 bg-[#1B1B22] border border-[#2A2A36] text-white text-base sm:text-xs placeholder-[#55524C] focus:outline-none focus:border-[#C5A880] focus:z-10 relative scroll-mt-4 dark-autofill-input"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="reg-password" className="block text-[10px] uppercase font-mono tracking-wider text-[#A29F96] mb-1">
                    Password (min. 6 characters)
                  </label>
                  <input
                    id="reg-password"
                    name="password"
                    type="password"
                    required
                    minLength={6}
                    autoComplete="new-password"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="••••••••••••"
                    style={{ colorScheme: "dark" }}
                    className="w-full h-11 sm:h-10 px-3.5 bg-[#1B1B22] border border-[#2A2A36] text-white text-base sm:text-xs placeholder-[#55524C] focus:outline-none focus:border-[#C5A880] scroll-mt-4 dark-autofill-input"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-xs uppercase font-sans font-semibold tracking-wider transition-colors disabled:opacity-50 mt-1 cursor-pointer active:scale-[0.99]"
                >
                  {isLoading ? "Creating Account..." : "Create Account"}
                </button>
              </form>

              <div className="relative flex items-center justify-center my-3">
                <div className="border-t border-[#24242C] w-full" />
                <span className="bg-[#131318] px-3 text-[10px] uppercase font-mono tracking-widest text-[#737069] whitespace-nowrap">
                  or continue with
                </span>
                <div className="border-t border-[#24242C] w-full" />
              </div>

              {/* Continue with Google */}
              <button
                type="button"
                onClick={handleGoogleClick}
                disabled={isLoading || isGoogleRedirecting}
                className="w-full py-2.5 px-4 bg-[#1B1B24] hover:bg-[#252532] border border-[#2E2E3C] hover:border-[#C5A880] text-white text-xs font-sans font-medium flex items-center justify-center gap-3 transition-all duration-150 shadow-sm disabled:opacity-50 cursor-pointer active:scale-[0.99]"
              >
                <GoogleIcon className="w-4 h-4 shrink-0" />
                <span>{isGoogleRedirecting ? "Connecting to Google..." : "Continue with Google"}</span>
              </button>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="pt-3 mt-4 border-t border-[#24242C] flex items-center justify-between text-[11px] text-[#8C867D] shrink-0">
          <Link
            href="/"
            className="hover:text-[#C5A880] transition-colors"
          >
            &larr; Back to Home
          </Link>
        </div>

      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <div
      style={{ colorScheme: "dark" }}
      className="min-h-screen min-h-[100dvh] w-full bg-[#0B0B0E] flex flex-col items-center justify-center p-3 sm:p-6 py-6 sm:py-12 selection:bg-[#C5A880] selection:text-[#0D0D11] relative overflow-y-auto overscroll-y-auto login-dark-surface"
    >
      {/* Background Radial Ambient Glow */}
      <div className="fixed inset-0 bg-[radial-gradient(circle_at_center,rgba(197,168,128,0.06)_0%,transparent_70%)] pointer-events-none" />

      <Suspense
        fallback={
          <div className="p-8 text-center text-[#8C867D] font-mono text-xs">
            Initializing Gateway...
          </div>
        }
      >
        <UnifiedLoginForm />
      </Suspense>
    </div>
  );
}

