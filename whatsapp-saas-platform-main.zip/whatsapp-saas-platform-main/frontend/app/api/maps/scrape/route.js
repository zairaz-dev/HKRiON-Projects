import { NextResponse } from 'next/server';
import { scrapeGoogleMaps } from '@/lib/gmapsScraper';
import { saveLeads } from '@/lib/leadsStore';

export async function POST(req) {
  try {
    const body = await req.json();
    const { category = 'Restaurants', location = 'Trincomalee, Sri Lanka', limit = 20, autoSave = true } = body;

    if (!location) {
      return NextResponse.json({ error: 'Location is required (e.g. Trincomalee, Sri Lanka)' }, { status: 400 });
    }

    const results = await scrapeGoogleMaps({
      category,
      location,
      limit: parseInt(limit, 10) || 20,
    });

    if (autoSave && results.leads?.length > 0) {
      try {
        saveLeads(results.leads);
      } catch (e) {
        console.warn('Failed to auto-save leads to disk:', e.message);
      }
    }

    return NextResponse.json(results);
  } catch (err) {
    console.error('[API Maps Scrape Error]:', err.message);
    return NextResponse.json({ error: err.message || 'Failed to scrape Google Maps' }, { status: 500 });
  }
}
