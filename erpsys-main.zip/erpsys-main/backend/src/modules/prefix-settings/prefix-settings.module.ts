import { Module } from '@nestjs/common';
import { PrefixSettingsController } from './prefix-settings.controller';
import { PrefixSettingsService } from './prefix-settings.service';
import { PrismaModule } from '../prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [PrefixSettingsController],
  providers: [PrefixSettingsService],
  exports: [PrefixSettingsService],
})
export class PrefixSettingsModule {}
