"use client";

import React, { useMemo } from "react";
import Link from "next/link";
import { Gemstone } from "@/types/gemstone";
import { AdminOrder, AdminTab, AdminUser } from "../types";
import { LuxuryPrice } from "@/components/ui/LuxuryPrice";
import {
  GemIcon,
  ScaleIcon,
  ArmoredTruckIcon,
  SparklesIcon,
  CertificateShieldIcon,
  SecurityLockIcon,
} from "@/components/ui/LuxuryIcons";

interface OverviewTabProps {
  adminUser: AdminUser | null;
  gemstonesList: Gemstone[];
  ordersList: AdminOrder[];
  totalRevenue: number;
  totalVaultValue: number;
  activeShipments: number;
  newInquiriesCount: number;
  formatPrice: (price: number) => string;
  setActiveTab: (tab: AdminTab) => void;
  onOpenAddModal: () => void;
}

const TYPE_GRADIENTS: Record<string, string> = {
  Sapphire: "from-[#1A365D] via-[#2B6CB0] to-[#C5A880]",
  Ruby: "from-[#742A2A] via-[#9B2C2C] to-[#E53E3E]",
  Emerald: "from-[#1C4532] via-[#276749] to-[#38A169]",
  Alexandrite: "from-[#322659] via-[#553C9A] to-[#319795]",
  Tourmaline: "from-[#702459] via-[#97266D] to-[#D53F8C]",
  Spinel: "from-[#7B341E] via-[#C05621] to-[#DD6B20]",
  default: "from-[#9A7B4F] via-[#C5A880] to-[#E0CFA9]",
};

export function OverviewTab({
  adminUser,
  gemstonesList,
  ordersList,
  totalRevenue,
  totalVaultValue,
  activeShipments,
  newInquiriesCount,
  setActiveTab,
  onOpenAddModal,
}: OverviewTabProps) {
  const avgCarat = useMemo(() => {
    if (!gemstonesList.length) return "0.00";
    return (
      gemstonesList.reduce((acc, g) => acc + g.carat, 0) / gemstonesList.length
    ).toFixed(2);
  }, [gemstonesList]);

  const unheatedPercentage = useMemo(() => {
    if (!gemstonesList.length) return 0;
    return Math.round(
      (gemstonesList.filter((g) => g.isUnheated).length / gemstonesList.length) * 100
    );
  }, [gemstonesList]);

  // Dynamically compute varieties distribution
  const portfolioBreakdown = useMemo(() => {
    const counts: Record<string, { count: number; valuation: number }> = {};
    for (const g of gemstonesList) {
      const t = g.type || "Other";
      if (!counts[t]) counts[t] = { count: 0, valuation: 0 };
      counts[t].count += 1;
      counts[t].valuation += g.price;
    }

    const totalCount = gemstonesList.length || 1;
    return Object.entries(counts)
      .map(([type, data]) => ({
        type,
        count: data.count,
        valuation: data.valuation,
        percentage: Math.round((data.count / totalCount) * 100),
      }))
      .sort((a, b) => b.valuation - a.valuation);
  }, [gemstonesList]);

  return (
    <div className="space-y-6">
      {/* 1. Header Banner */}
      <div className="border-b border-[#24242C] pb-6">
        <h1 className="font-sans text-xl sm:text-2xl text-white font-semibold tracking-tight">
          Dashboard Overview
        </h1>
        <p className="text-xs text-[#A1A1AA] font-sans mt-1">
          Real-time summary of sales, gemstone inventory, and customer orders.
        </p>
      </div>

      {/* 2. KPI Metrics Cards - Simple & Clear English */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        {/* KPI 1: Total Sales */}
        <div className="bg-[#141419] border border-[#24242C] p-5 rounded-sm relative overflow-hidden group card-luxury-hover-dark hover:border-[#C5A880]/50">
          <div className="absolute top-0 right-0 w-24 h-24 bg-[#C5A880]/5 rounded-full blur-2xl group-hover:bg-[#C5A880]/10 transition-all pointer-events-none" />
          <div className="flex items-center justify-between">
            <span className="text-[#8C867D] uppercase tracking-widest text-[10px] sm:text-[11px] font-sans font-medium">
              Total Sales
            </span>
            <SparklesIcon className="w-4 h-4 text-[#C5A880]/80" />
          </div>
          <div className="mt-2.5">
            <LuxuryPrice amount={totalRevenue} size="xl" color="white" weight="bold" />
          </div>
        </div>

        {/* KPI 2: Inventory Value */}
        <div className="bg-[#141419] border border-[#24242C] p-5 rounded-sm relative overflow-hidden group card-luxury-hover-dark hover:border-[#C5A880]/50">
          <div className="absolute top-0 right-0 w-24 h-24 bg-[#C5A880]/5 rounded-full blur-2xl group-hover:bg-[#C5A880]/10 transition-all pointer-events-none" />
          <div className="flex items-center justify-between">
            <span className="text-[#8C867D] uppercase tracking-widest text-[10px] sm:text-[11px] font-sans font-medium">
              Inventory Value
            </span>
            <GemIcon className="w-4 h-4 text-[#C5A880]/80" />
          </div>
          <div className="mt-2.5">
            <LuxuryPrice amount={totalVaultValue} size="xl" color="white" weight="bold" />
          </div>
          <div className="mt-3 text-[11px] text-[#C5A880] font-sans flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#C5A880] inline-block" />
            <span>{gemstonesList.length} gemstones in stock</span>
          </div>
        </div>

        {/* KPI 3: Active Shipments */}
        <div className="bg-[#141419] border border-[#24242C] p-5 rounded-sm relative overflow-hidden group card-luxury-hover-dark hover:border-[#C5A880]/50">
          <div className="absolute top-0 right-0 w-24 h-24 bg-[#C5A880]/5 rounded-full blur-2xl group-hover:bg-[#C5A880]/10 transition-all pointer-events-none" />
          <div className="flex items-center justify-between">
            <span className="text-[#8C867D] uppercase tracking-widest text-[10px] sm:text-[11px] font-sans font-medium">
              Active Shipments
            </span>
            <ArmoredTruckIcon className="w-4 h-4 text-[#C5A880]/80" />
          </div>
          <div className="mt-2.5 flex items-baseline gap-2">
            <span className="font-mono text-2xl sm:text-3xl font-bold text-white tabular-nums tracking-tight">
              {activeShipments}
            </span>
            <span className="text-xs uppercase tracking-wider text-[#8C867D] font-sans font-medium">
              In Delivery
            </span>
          </div>
          <div className="mt-3 text-[11px] text-blue-400 font-sans flex items-center gap-1.5">
            <SecurityLockIcon className="w-3 h-3" />
            <span>Insured courier delivery</span>
          </div>
        </div>

        {/* KPI 4: Average Carat Weight & Purity */}
        <div className="bg-[#141419] border border-[#24242C] p-5 rounded-sm relative overflow-hidden group card-luxury-hover-dark hover:border-[#C5A880]/50">
          <div className="absolute top-0 right-0 w-24 h-24 bg-[#C5A880]/5 rounded-full blur-2xl group-hover:bg-[#C5A880]/10 transition-all pointer-events-none" />
          <div className="flex items-center justify-between">
            <span className="text-[#8C867D] uppercase tracking-widest text-[10px] sm:text-[11px] font-sans font-medium">
              Average Weight
            </span>
            <ScaleIcon className="w-4 h-4 text-[#C5A880]/80" />
          </div>
          <div className="mt-2.5 flex items-baseline gap-2">
            <span className="font-mono text-2xl sm:text-3xl font-bold text-white tabular-nums tracking-tight">
              {avgCarat}
            </span>
            <span className="text-xs uppercase tracking-wider text-[#8C867D] font-sans font-medium">
              Carats Avg
            </span>
          </div>
          <div className="mt-3 text-[11px] text-[#A29F96] font-sans flex items-center gap-1.5">
            <CertificateShieldIcon className="w-3 h-3 text-[#C5A880]" />
            <span className="font-mono tabular-nums">{unheatedPercentage}%</span>
            <span>natural unheated</span>
          </div>
        </div>
      </div>

      {/* 3. Analytics Breakdown & Fast Operations Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 sm:gap-6">
        {/* Gemstone Type Distribution */}
        <div className="lg:col-span-2 bg-[#141419] border border-[#24242C] p-5 sm:p-6 rounded-sm space-y-4">
          <div className="flex items-center justify-between border-b border-[#24242C] pb-3">
            <div>
              <h2 className="font-sans text-base sm:text-lg text-white font-semibold tracking-tight">
                Gemstone Inventory Breakdown
              </h2>
              <p className="text-[11px] text-[#8C867D] font-sans">
                Current inventory value and quantity by gemstone type
              </p>
            </div>
            <span className="text-xs font-mono tabular-nums font-semibold text-[#C5A880] bg-[#C5A880]/10 px-2 py-0.5 rounded border border-[#C5A880]/20">
              {gemstonesList.length} Total Units
            </span>
          </div>

          <div className="space-y-3.5 pt-1">
            {portfolioBreakdown.length === 0 ? (
              <p className="text-xs text-[#8C867D] py-4 text-center">
                No gemstones in inventory yet.
              </p>
            ) : (
              portfolioBreakdown.slice(0, 6).map((item) => {
                const gradient = TYPE_GRADIENTS[item.type] || TYPE_GRADIENTS.default;
                return (
                  <div key={item.type} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs font-sans">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-[#C5A880]" />
                        <span className="text-white font-medium">{item.type}</span>
                        <span className="text-[#8C867D] text-[11px]">
                          ({item.count} pcs • {item.percentage}%)
                        </span>
                      </div>
                      <LuxuryPrice amount={item.valuation} size="xs" color="gold" weight="medium" />
                    </div>
                    <div className="w-full h-1.5 bg-[#1F1E26] rounded-full overflow-hidden">
                      <div
                        className={`h-full bg-gradient-to-r ${gradient} rounded-full transition-all duration-500`}
                        style={{ width: `${Math.max(item.percentage, 4)}%` }}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Operations & Quick Controls */}
        <div className="bg-[#141419] border border-[#24242C] p-5 sm:p-6 rounded-sm space-y-4 flex flex-col justify-between">
          <div>
            <h2 className="font-sans text-base sm:text-lg text-white font-semibold tracking-tight border-b border-[#24242C] pb-3">
              Quick Actions
            </h2>
            <div className="space-y-2.5 pt-3">
              <button
                type="button"
                onClick={onOpenAddModal}
                className="w-full text-left p-3 bg-[#181820] hover:bg-[#20202A] border border-[#2A2A36] hover:border-[#C5A880]/50 rounded-sm text-xs font-sans flex items-center justify-between text-white transition-colors group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-6 h-6 rounded bg-[#C5A880]/15 flex items-center justify-center text-[#C5A880]">
                    <span className="text-sm font-bold leading-none">+</span>
                  </div>
                  <span className="font-medium">Add New Gemstone</span>
                </div>
                <span className="text-[#8C867D] group-hover:text-white transition-colors">&rarr;</span>
              </button>

              <Link
                href="/orders"
                onClick={(e) => {
                  e.preventDefault();
                  setActiveTab("orders");
                }}
                className="w-full text-left p-3 bg-[#181820] hover:bg-[#20202A] border border-[#2A2A36] hover:border-[#C5A880]/50 rounded-sm text-xs font-sans flex items-center justify-between text-white transition-colors group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-6 h-6 rounded bg-blue-500/15 flex items-center justify-center text-blue-400">
                    <ArmoredTruckIcon className="w-3.5 h-3.5" />
                  </div>
                  <span className="font-medium">View {activeShipments} Active Shipments</span>
                </div>
                <span className="text-[#8C867D] group-hover:text-white transition-colors">&rarr;</span>
              </Link>

              <Link
                href="/inquiries"
                onClick={(e) => {
                  e.preventDefault();
                  setActiveTab("inquiries");
                }}
                className="w-full text-left p-3 bg-[#181820] hover:bg-[#20202A] border border-[#2A2A36] hover:border-[#C5A880]/50 rounded-sm text-xs font-sans flex items-center justify-between text-white transition-colors group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-6 h-6 rounded bg-amber-500/15 flex items-center justify-center text-amber-400">
                    <span className="text-xs">✉</span>
                  </div>
                  <span className="font-medium">
                    Customer Messages ({newInquiriesCount} New)
                  </span>
                </div>
                <span className="text-[#8C867D] group-hover:text-white transition-colors">&rarr;</span>
              </Link>

              <Link
                href="/inventory"
                onClick={(e) => {
                  e.preventDefault();
                  setActiveTab("inventory");
                }}
                className="w-full text-left p-3 bg-[#181820] hover:bg-[#20202A] border border-[#2A2A36] hover:border-[#C5A880]/50 rounded-sm text-xs font-sans flex items-center justify-between text-white transition-colors group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-6 h-6 rounded bg-[#C5A880]/15 flex items-center justify-center text-[#C5A880]">
                    <GemIcon className="w-3.5 h-3.5" />
                  </div>
                  <span className="font-medium">Manage Inventory & Stock</span>
                </div>
                <span className="text-[#8C867D] group-hover:text-white transition-colors">&rarr;</span>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Recent Orders Table */}
      <div className="bg-[#141419] border border-[#24242C] p-5 sm:p-6 rounded-sm space-y-4">
        <div className="flex items-center justify-between border-b border-[#24242C] pb-3">
          <div>
            <h2 className="font-sans text-base sm:text-lg text-white font-semibold tracking-tight">
              Recent Orders
            </h2>
            <p className="text-xs text-[#8C867D] font-sans">
              Latest customer purchases and delivery status.
            </p>
          </div>
          <Link
            href="/orders"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab("orders");
            }}
            className="text-xs font-sans text-[#C5A880] hover:underline flex items-center gap-1"
          >
            <span>View All Orders</span>
            <span>&rarr;</span>
          </Link>
        </div>

        {ordersList.length === 0 ? (
          <div className="py-8 text-center text-[#8C867D] text-xs">
            <ArmoredTruckIcon className="w-8 h-8 text-[#554F47] mx-auto mb-2" />
            <p>No orders recorded yet.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-left text-xs font-sans">
              <thead>
                <tr className="border-b border-[#24242C] text-[#8C867D] uppercase text-[10px] tracking-wider">
                  <th className="py-2.5 font-medium">Order ID</th>
                  <th className="py-2.5 font-medium">Customer</th>
                  <th className="py-2.5 font-medium">Gemstone</th>
                  <th className="py-2.5 font-medium text-right">Weight</th>
                  <th className="py-2.5 font-medium text-right">Total Price</th>
                  <th className="py-2.5 font-medium">Courier</th>
                  <th className="py-2.5 font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1F1E26]">
                {ordersList.slice(0, 5).map((order) => (
                  <tr key={order.id} className="hover:bg-[#181820] transition-colors">
                    <td className="py-3 font-mono text-[#C5A880] font-semibold tabular-nums">{order.id}</td>
                    <td className="py-3 text-white font-medium">{order.clientName}</td>
                    <td className="py-3 font-sans text-white font-medium">{order.gemstoneName}</td>
                    <td className="py-3 text-[#A29F96] text-right font-mono tabular-nums">{order.carat.toFixed(2)} ct</td>
                    <td className="py-3 text-right">
                      <div className="flex justify-end">
                        <LuxuryPrice amount={order.total} size="sm" color="white" weight="semibold" />
                      </div>
                    </td>
                    <td className="py-3 text-[#8C867D]">{order.courier}</td>
                    <td className="py-3">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-mono uppercase ${
                          order.status === "delivered" || order.status === "accepted"
                            ? "bg-emerald-950/60 text-emerald-300 border border-emerald-800/60"
                            : order.status === "vault_packed"
                            ? "bg-purple-950/60 text-purple-300 border border-purple-800/60"
                            : order.status === "in_transit"
                            ? "bg-blue-950/60 text-blue-300 border border-blue-800/60"
                            : order.status === "rejected"
                            ? "bg-red-950/60 text-red-300 border border-red-800/60"
                            : "bg-amber-950/60 text-amber-300 border border-amber-800/60"
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            order.status === "delivered" || order.status === "accepted"
                              ? "bg-emerald-400"
                              : order.status === "in_transit"
                              ? "bg-blue-400"
                              : order.status === "vault_packed"
                              ? "bg-purple-400"
                              : order.status === "rejected"
                              ? "bg-red-400"
                              : "bg-amber-400"
                          }`}
                        />
                        {order.status === "accepted"
                          ? "Payment Confirmed"
                          : order.status === "rejected"
                          ? "Payment Rejected"
                          : order.status.replace("_", " ")}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
