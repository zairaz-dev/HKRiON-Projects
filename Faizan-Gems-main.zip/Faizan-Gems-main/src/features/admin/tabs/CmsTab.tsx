import React, { useState, useEffect } from "react";
import { createPortal } from "react-dom";
import Image from "next/image";
import { CloseIcon, CheckIcon, CopyIcon, GemIcon } from "@/components/ui/LuxuryIcons";
import { LuxurySelect } from "@/components/ui/LuxurySelect";
import { useToast } from "@/components/ui/LuxuryToast";
import { AdminTab } from "../types";
import {
  CMSCollectionCard,
  DEFAULT_COLLECTION_CARDS,
  getParsedCollectionCards,
} from "@/lib/data/collections";
import { SITE_CONFIG } from "@/lib/constants/site";

interface CmsTabProps {
  setActiveTab: (tab: AdminTab) => void;
}

export function CmsTab({ setActiveTab }: CmsTabProps) {
  const { toast, confirm } = useToast();
  const [cmsSubTab, setCmsSubTab] = useState<"banking" | "hero" | "shop" | "collections" | "about" | "contact">("banking");
  const [isSavingCMS, setIsSavingCMS] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  // Banking Fields
  const [bankName, setBankName] = useState<string>(SITE_CONFIG.banking.bankName);
  const [bankShortName, setBankShortName] = useState<string>(SITE_CONFIG.banking.bankShortName);
  const [branchName, setBranchName] = useState<string>(SITE_CONFIG.banking.branchName);
  const [accountName, setAccountName] = useState<string>(SITE_CONFIG.banking.accountName);
  const [accountNumber, setAccountNumber] = useState<string>(SITE_CONFIG.banking.accountNumber);
  const [bankLogo, setBankLogo] = useState<string>(SITE_CONFIG.banking.bankLogo);
  const [isUploadingBankLogo, setIsUploadingBankLogo] = useState(false);
  const [bankLogoUploadError, setBankLogoUploadError] = useState("");
  const [previewCopiedKey, setPreviewCopiedKey] = useState<string | null>(null);

  // Hero Fields
  const [heroEyebrow, setHeroEyebrow] = useState("Untreated Natural Gemstones • Certified Authentic");
  const [heroHeadline, setHeroHeadline] = useState("Discover Rare Natural Gemstones");
  const [heroSubheadline, setHeroSubheadline] = useState("Natural unheated sapphires, rubies, emeralds, and fine gemstones. Certified for quality, color, and authenticity.");
  const [heroCtaPrimaryText, setHeroCtaPrimaryText] = useState("Browse Gemstones");
  const [heroCtaPrimaryLink, setHeroCtaPrimaryLink] = useState("/shop");
  const [heroCtaSecondaryText, setHeroCtaSecondaryText] = useState("Our Collection");
  const [heroCtaSecondaryLink, setHeroCtaSecondaryLink] = useState("/shop");
  const [heroImage, setHeroImage] = useState("/uploads/banners/hero-1789651834163-md9w3c.webp");
  const [isUploadingHeroImage, setIsUploadingHeroImage] = useState(false);
  const [heroImageUploadError, setHeroImageUploadError] = useState("");

  const [homepageActiveSection, setHomepageActiveSection] = useState<
    "all" | "hero" | "metrics" | "trust" | "collections" | "vault" | "loupe" | "story" | "consultation"
  >("all");

  // Section 1: Hero Metrics
  const [metric1Val, setMetric1Val] = useState("100%");
  const [metric1Lbl, setMetric1Lbl] = useState("Certified Natural");
  const [metric2Val, setMetric2Val] = useState("GIA & GRS");
  const [metric2Lbl, setMetric2Lbl] = useState("Independent Reports");
  const [metric3Val, setMetric3Val] = useState("Armored");
  const [metric3Lbl, setMetric3Lbl] = useState("Worldwide Courier");
  const [metric4Val, setMetric4Val] = useState("30 Days");
  const [metric4Lbl, setMetric4Lbl] = useState("Inspection Period");

  // Section 2: Trust strip
  const [trust1Title, setTrust1Title] = useState("Independently Certified Labs");
  const [trust1Desc, setTrust1Desc] = useState("GIA, Gübelin, SSEF & GRS lab reports you can verify online");
  const [trust2Title, setTrust2Title] = useState("30-Day Money-Back Guarantee");
  const [trust2Desc, setTrust2Desc] = useState("Not satisfied? Return within 30 days for a full refund — no questions asked");

  // Section 3: Collections
  const [collectionsEyebrow, setCollectionsEyebrow] = useState("Our Collections");
  const [collectionsHeadline, setCollectionsHeadline] = useState("Explore Our Gemstone Collections");
  const [collectionsSubheadline, setCollectionsSubheadline] = useState(
    "Browse collections of the world's finest natural gemstones — sourced directly from the mines and cut by expert craftsmen."
  );

  // Section 4: Vault
  const [vaultEyebrow, setVaultEyebrow] = useState("New Arrivals");
  const [vaultHeadline, setVaultHeadline] = useState("Certified Natural Gemstones");
  const [vaultSubheadline, setVaultSubheadline] = useState(
    "One-of-a-kind natural gemstones, each with an official lab certificate from GIA, Gübelin, SSEF, or GRS."
  );
  const [vaultCtaText, setVaultCtaText] = useState("View All Gemstones");

  // Section 5: Loupe Showcase
  const [loupeEyebrow, setLoupeEyebrow] = useState("See Every Detail Online");
  const [loupeHeadline, setLoupeHeadline] = useState("Zoom In & Inspect Every Gemstone Up Close");
  const [loupeSubheadline, setLoupeSubheadline] = useState(
    "Can't visit in person? No problem. Our high-resolution image viewer lets you examine every detail of the gemstone — just like a professional gemologist would."
  );
  const [loupeFeat1Title, setLoupeFeat1Title] = useState("10x Zoom Magnification");
  const [loupeFeat1Desc, setLoupeFeat1Desc] = useState("See the natural details and clarity of each stone up close.");
  const [loupeFeat2Title, setLoupeFeat2Title] = useState("Detailed Photo Gallery");
  const [loupeFeat2Desc, setLoupeFeat2Desc] = useState("View the cut quality, light performance, and sparkle from every angle.");
  const [loupeFeat3Title, setLoupeFeat3Title] = useState("Lab Certificate Included");
  const [loupeFeat3Desc, setLoupeFeat3Desc] = useState("Every gemstone comes with its original lab report and certificate.");
  const [loupeCtaText, setLoupeCtaText] = useState("View a Gemstone Up Close →");
  const [loupeCtaLink, setLoupeCtaLink] = useState("/shop");
  const [loupeImage, setLoupeImage] = useState(
    "/uploads/banners/hero-1789651917652-xw752j.webp"
  );
  const [loupeImageCaption, setLoupeImageCaption] = useState("ROYAL BLUE CEYLON SAPPHIRE • CLOSE-UP VIEW");
  const [isUploadingLoupeImage, setIsUploadingLoupeImage] = useState(false);
  const [loupeImageUploadError, setLoupeImageUploadError] = useState("");


  // Section 7: Story
  const [storyImage, setStoryImage] = useState(
    "/uploads/banners/hero-1789651886835-6o989i.webp"
  );
  const [storyImageBadge, setStoryImageBadge] = useState("Ethically Sourced");
  const [storyImageCaption, setStoryImageCaption] = useState("From Sri Lankan mines to expertly cut gemstones.");
  const [storyEyebrow, setStoryEyebrow] = useState("Our Story");
  const [storyHeadline, setStoryHeadline] = useState("Crafted by Nature. Delivered with Trust.");
  const [storyP1, setStoryP1] = useState(
    "At Faizan Gems, we believe the world's finest gemstones should stay 100% natural — no heating, no chemical treatment, no artificial enhancements."
  );
  const [storyP2, setStoryP2] = useState(
    "We work directly with miners in Sri Lanka, Colombia, and Thailand. Every stone is bought from small-scale, eco-friendly mining operations — ensuring fair pay for workers and minimal impact on the environment."
  );
  const [storyStat1Val, setStoryStat1Val] = useState("100%");
  const [storyStat1Lbl, setStoryStat1Lbl] = useState("Natural & Untreated");
  const [storyStat2Val, setStoryStat2Val] = useState("3");
  const [storyStat2Lbl, setStoryStat2Lbl] = useState("Generations of Expert Cutters");
  const [storyStat3Val, setStoryStat3Val] = useState("Direct");
  const [storyStat3Lbl, setStoryStat3Lbl] = useState("Mine-to-You Direct");
  const [storyCtaText, setStoryCtaText] = useState("Read Our Story →");
  const [storyCtaLink, setStoryCtaLink] = useState("/about");
  const [isUploadingStoryImage, setIsUploadingStoryImage] = useState(false);
  const [storyImageUploadError, setStoryImageUploadError] = useState("");

  // Section 8: Consultation
  const [consultationEyebrow, setConsultationEyebrow] = useState("Need Help Choosing?");
  const [consultationHeadline, setConsultationHeadline] = useState("Looking for a Specific Gemstone?");
  const [consultationDesc, setConsultationDesc] = useState(
    "Our gemstone experts are happy to help — visit our Trincomalee showroom or book a free video call consultation."
  );
  const [consultationBtnText, setConsultationBtnText] = useState("Book a Free Consultation");

  // Shop Page Fields
  const [shopEyebrow, setShopEyebrow] = useState("Faizan Gems Collection");
  const [shopHeadline, setShopHeadline] = useState("Certified Natural Gemstones");
  const [shopSubheadline, setShopSubheadline] = useState(
    "Each gemstone is individually authenticated and certified by world-recognized gemological laboratories. 100% natural and untreated unless explicitly specified."
  );
  const [shopBannerImage, setShopBannerImage] = useState("");
  const [isUploadingShopBanner, setIsUploadingShopBanner] = useState(false);
  const [shopBannerUploadError, setShopBannerUploadError] = useState("");
  const [shopNoticeBadge, setShopNoticeBadge] = useState("");
  const [shopNoticeActive, setShopNoticeActive] = useState(false);

  // About Page Subtab Active Filter
  type AboutSectionTab = "all" | "hero" | "overview" | "mission_vision" | "ceo" | "locations";
  const [aboutActiveSection, setAboutActiveSection] = useState<AboutSectionTab>("all");

  // Section 1: Hero & Brand Identity
  const [aboutBrandSlogan, setAboutBrandSlogan] = useState("From the Heart of Sri Lanka to the World.");
  const [aboutBrandTagline, setAboutBrandTagline] = useState("Natural Gemstones • Custom Jewellery • Trusted Service");
  const [aboutPageIntro, setAboutPageIntro] = useState(
    "Faizan Gems (Pvt) Ltd is a Sri Lankan gemstone trading and jewellery company specializing in the buying and selling of natural gemstones, with a special focus on Sri Lankan sapphires."
  );

  // Section 2: Company Overview & Specialization
  const [aboutTradingDesc, setAboutTradingDesc] = useState(
    "We source and trade carefully selected natural gemstones from Sri Lanka, including Blue Sapphires, Yellow Sapphires, Padparadscha Sapphires, Ruby, Chrysoberyl, Cat’s Eye, Emerald, Aquamarine, Garnet and other precious and semi-precious gemstones."
  );
  const [aboutJewelleryDesc, setAboutJewelleryDesc] = useState(
    "In addition to gemstone trading, we offer custom jewellery manufacturing, creating unique rings, earrings, pendants, bracelets and necklaces according to our customers’ requirements. Our jewellery combines carefully selected natural gemstones with quality craftsmanship to create beautiful and timeless pieces."
  );
  const [aboutTrustDesc, setAboutTrustDesc] = useState(
    "At Faizan Gems, we believe that trust, authenticity, quality and customer satisfaction are the foundation of a successful gemstone business. We are committed to providing genuine natural gemstones, transparent service and professional assistance to both local and international customers."
  );
  const [aboutVisionShort, setAboutVisionShort] = useState(
    "Our vision is to connect the rich Sri Lankan gemstone heritage with customers and jewellery markets around the world, while building long-term relationships based on trust, quality and excellence."
  );

  // Section 3: Mission & Vision Statements
  const [aboutMissionStatement, setAboutMissionStatement] = useState(
    "Faizan Gems (Pvt) Ltd is committed to sourcing and trading genuine natural gemstones, especially Sri Lankan sapphires, while creating high-quality custom jewellery that combines the beauty of natural gemstones with modern craftsmanship. We aim to provide our local and international customers with authenticity, transparency, competitive value, and reliable service from gemstone selection to the final jewellery piece."
  );
  const [aboutVisionStatement, setAboutVisionStatement] = useState(
    "To become a trusted and internationally recognized Sri Lankan gemstone and jewellery company, renowned for genuine natural gemstones, exceptional craftsmanship, ethical business practices, and lasting customer relationships."
  );

  // Section 4: Message from the CEO
  const [aboutFounderName, setAboutFounderName] = useState("Riyas Abdul Aziz (JP)");
  const [aboutFounderTitle, setAboutFounderTitle] = useState("CEO / Founder");
  const [aboutFounderCredentials, setAboutFounderCredentials] = useState("BSc in Psychology & Counselling");
  const [aboutFounderImage, setAboutFounderImage] = useState("/uploads/gemstones/gem-1789653639242-gt09cd.webp");
  const [aboutFounderGreeting, setAboutFounderGreeting] = useState("Assalamu Alaikum and warm greetings,");
  const [aboutFounderP1, setAboutFounderP1] = useState(
    "It is my great pleasure to welcome you to Faizan Gems (Pvt) Ltd, a Sri Lankan gemstone trading and jewellery company built on trust, authenticity, quality and customer satisfaction."
  );
  const [aboutFounderP2, setAboutFounderP2] = useState(
    "Sri Lanka is world-renowned for its exceptional natural gemstones, particularly its beautiful sapphires. At Faizan Gems, our aim is to share this valuable heritage with customers in Sri Lanka and around the world through carefully selected natural gemstones and professionally crafted custom jewellery."
  );
  const [aboutFounderP3, setAboutFounderP3] = useState(
    "Our business is not only about buying and selling gemstones. We are committed to building long-term relationships with our customers by providing honest information, reliable service and quality products. Whether you are looking for a natural Sri Lankan sapphire, a gemstone for investment, or a unique custom-made ring, pendant, bracelet or other jewellery, our team is ready to assist you."
  );
  const [aboutFounderP4, setAboutFounderP4] = useState(
    "We continuously strive to improve our standards, expand our international presence and introduce the beauty of Sri Lankan gemstones to new markets."
  );
  const [aboutFounderP5, setAboutFounderP5] = useState(
    "I sincerely thank all our customers, business partners and supporters for their trust in Faizan Gems. We look forward to growing together and creating lasting value through Sri Lankan gemstones and fine craftsmanship."
  );

  // Section 5: Our Locations
  const [aboutHeadOfficeTitle, setAboutHeadOfficeTitle] = useState("Head Office – Trincomalee");
  const [aboutHeadOfficeBadge, setAboutHeadOfficeBadge] = useState<string>(SITE_CONFIG.showroom.badge);
  const [aboutHeadOfficeAddress, setAboutHeadOfficeAddress] = useState<string>(SITE_CONFIG.showroom.fullAddress);
  const [aboutHeadOfficeDesc, setAboutHeadOfficeDesc] = useState(
    "Our main showroom and gemological facility where stones are inspected, certified, and dispatched worldwide."
  );
  const [aboutHeadOfficePhone, setAboutHeadOfficePhone] = useState<string>(SITE_CONFIG.showroom.phone);

  const [aboutKalutaraTitle, setAboutKalutaraTitle] = useState<string>(SITE_CONFIG.branches.kalutara.title);
  const [aboutKalutaraBadge, setAboutKalutaraBadge] = useState<string>(SITE_CONFIG.branches.kalutara.badge);
  const [aboutKalutaraAddress, setAboutKalutaraAddress] = useState<string>(SITE_CONFIG.branches.kalutara.address);
  const [aboutKalutaraDesc, setAboutKalutaraDesc] = useState(
    "Our western province gemstone trading and client consultation centre along the historic coastal gemstone corridor."
  );
  const [aboutKalutaraPhone, setAboutKalutaraPhone] = useState<string>(SITE_CONFIG.branches.kalutara.phone);

  const [isUploadingAboutImage, setIsUploadingAboutImage] = useState<string | null>(null);
  const [aboutImageUploadError, setAboutImageUploadError] = useState("");

  // Contact Page Fields (All CMS Dynamic)
  const [contactPageEyebrow, setContactPageEyebrow] = useState("Get in Touch");
  const [contactPageTitle, setContactPageTitle] = useState("Book a Consultation");
  const [contactPageSubtitle, setContactPageSubtitle] = useState(
    "Have a question about a gemstone? Want to visit our showroom? Or need help with a custom order? We're here to help."
  );

  const [contactCardTitle, setContactCardTitle] = useState("Contact Information");
  const [contactAddressLabel, setContactAddressLabel] = useState("Showroom Address");
  const [contactAddress, setContactAddress] = useState<string>(SITE_CONFIG.showroom.address);
  const [contactCountry, setContactCountry] = useState<string>(SITE_CONFIG.showroom.country);
  const [contactHours, setContactHours] = useState<string>(SITE_CONFIG.contact.hours);
  const [contactPhoneLabel, setContactPhoneLabel] = useState("Phone Number & WhatsApp");
  const [contactPhone, setContactPhone] = useState<string>(SITE_CONFIG.contact.phone);
  const [contactSecondaryPhone, setContactSecondaryPhone] = useState<string>(SITE_CONFIG.contact.secondaryPhone);
  const [contactLandline, setContactLandline] = useState<string>(SITE_CONFIG.contact.landline);
  const [contactResponseTime, setContactResponseTime] = useState<string>(SITE_CONFIG.contact.responseTime);
  const [contactEmailLabel, setContactEmailLabel] = useState("Email");
  const [contactEmail, setContactEmail] = useState<string>(SITE_CONFIG.contact.email);

  const [contactDeliveryBadge, setContactDeliveryBadge] = useState("100% Authenticity & Lifetime Guarantee");
  const [contactDeliveryDescription, setContactDeliveryDescription] = useState(
    "Every gemstone is guaranteed 100% natural, independently certified by premier gemological laboratories, and backed by our unconditional lifetime guarantee of authenticity."
  );

  // Curated Collection Cards CMS State
  const [collectionCards, setCollectionCards] = useState<CMSCollectionCard[]>(DEFAULT_COLLECTION_CARDS);
  const [uploadingCardId, setUploadingCardId] = useState<string | null>(null);
  // Collections Page Editorial Headers
  const [collectionsPageEyebrow, setCollectionsPageEyebrow] = useState("Faizan Gems Vault Collections");
  const [collectionsPageHeadline, setCollectionsPageHeadline] = useState("Curated Gemstone Portfolios");
  const [collectionsPageSubheadline, setCollectionsPageSubheadline] = useState(
    "Browse collections of the world's finest natural gemstones — sourced directly from historic alluvial deposits and cut by master craftsmen. Each untreated specimen is individually certified by leading gemological institutes."
  );
  const [collectionsShowcaseEyebrow, setCollectionsShowcaseEyebrow] = useState("World-Renowned Provenance");
  const [collectionsShowcaseTitle, setCollectionsShowcaseTitle] = useState("Our Signature Portfolios");
  const [collectionsShowcaseSubtitle, setCollectionsShowcaseSubtitle] = useState(
    "Explore the world's most exceptional unheated natural gemstones sourced directly from legendary deposits."
  );
  const [collectionCardError, setCollectionCardError] = useState("");

  // Add New Card Modal State
  const [isAddCardModalOpen, setIsAddCardModalOpen] = useState(false);
  const [newCardName, setNewCardName] = useState("");
  const [newCardSlug, setNewCardSlug] = useState("");
  const [newCardImage, setNewCardImage] = useState("");
  const [newCardShowOnHome, setNewCardShowOnHome] = useState(true);
  const [isUploadingNewCardImage, setIsUploadingNewCardImage] = useState(false);



  // Fetch CMS Content from MySQL
  useEffect(() => {
    fetch("/api/cms")
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          if (data.blocks) {
            if (data.blocks["homepage.hero_eyebrow"]) setHeroEyebrow(data.blocks["homepage.hero_eyebrow"]);
            if (data.blocks["homepage.hero_headline"]) setHeroHeadline(data.blocks["homepage.hero_headline"]);
            if (data.blocks["homepage.hero_subheadline"]) setHeroSubheadline(data.blocks["homepage.hero_subheadline"]);
            if (data.blocks["homepage.hero_cta_primary_text"]) setHeroCtaPrimaryText(data.blocks["homepage.hero_cta_primary_text"]);
            if (data.blocks["homepage.hero_cta_primary_link"]) setHeroCtaPrimaryLink(data.blocks["homepage.hero_cta_primary_link"]);
            if (data.blocks["homepage.hero_cta_secondary_text"]) setHeroCtaSecondaryText(data.blocks["homepage.hero_cta_secondary_text"]);
            if (data.blocks["homepage.hero_cta_secondary_link"]) setHeroCtaSecondaryLink(data.blocks["homepage.hero_cta_secondary_link"]);
            if (data.blocks["homepage.hero_image"]) setHeroImage(data.blocks["homepage.hero_image"]);
            if (data.blocks["homepage.metric1_val"]) setMetric1Val(data.blocks["homepage.metric1_val"]);
            if (data.blocks["homepage.metric1_lbl"]) setMetric1Lbl(data.blocks["homepage.metric1_lbl"]);
            if (data.blocks["homepage.metric2_val"]) setMetric2Val(data.blocks["homepage.metric2_val"]);
            if (data.blocks["homepage.metric2_lbl"]) setMetric2Lbl(data.blocks["homepage.metric2_lbl"]);
            if (data.blocks["homepage.metric3_val"]) setMetric3Val(data.blocks["homepage.metric3_val"]);
            if (data.blocks["homepage.metric3_lbl"]) setMetric3Lbl(data.blocks["homepage.metric3_lbl"]);
            if (data.blocks["homepage.metric4_val"]) setMetric4Val(data.blocks["homepage.metric4_val"]);
            if (data.blocks["homepage.metric4_lbl"]) setMetric4Lbl(data.blocks["homepage.metric4_lbl"]);
            if (data.blocks["homepage.trust1_title"]) setTrust1Title(data.blocks["homepage.trust1_title"]);
            if (data.blocks["homepage.trust1_desc"]) setTrust1Desc(data.blocks["homepage.trust1_desc"]);
            if (data.blocks["homepage.trust2_title"]) setTrust2Title(data.blocks["homepage.trust2_title"]);
            if (data.blocks["homepage.trust2_desc"]) setTrust2Desc(data.blocks["homepage.trust2_desc"]);
            if (data.blocks["homepage.collections_eyebrow"]) setCollectionsEyebrow(data.blocks["homepage.collections_eyebrow"]);
            if (data.blocks["homepage.collections_headline"]) setCollectionsHeadline(data.blocks["homepage.collections_headline"]);
            if (data.blocks["homepage.collections_subheadline"]) setCollectionsSubheadline(data.blocks["homepage.collections_subheadline"]);
            if (data.blocks["homepage.vault_eyebrow"]) setVaultEyebrow(data.blocks["homepage.vault_eyebrow"]);
            if (data.blocks["homepage.vault_headline"]) setVaultHeadline(data.blocks["homepage.vault_headline"]);
            if (data.blocks["homepage.vault_subheadline"]) setVaultSubheadline(data.blocks["homepage.vault_subheadline"]);
            if (data.blocks["homepage.vault_cta_text"]) setVaultCtaText(data.blocks["homepage.vault_cta_text"]);
            if (data.blocks["homepage.loupe_eyebrow"]) setLoupeEyebrow(data.blocks["homepage.loupe_eyebrow"]);
            if (data.blocks["homepage.loupe_headline"]) setLoupeHeadline(data.blocks["homepage.loupe_headline"]);
            if (data.blocks["homepage.loupe_subheadline"]) setLoupeSubheadline(data.blocks["homepage.loupe_subheadline"]);
            if (data.blocks["homepage.loupe_feat1_title"]) setLoupeFeat1Title(data.blocks["homepage.loupe_feat1_title"]);
            if (data.blocks["homepage.loupe_feat1_desc"]) setLoupeFeat1Desc(data.blocks["homepage.loupe_feat1_desc"]);
            if (data.blocks["homepage.loupe_feat2_title"]) setLoupeFeat2Title(data.blocks["homepage.loupe_feat2_title"]);
            if (data.blocks["homepage.loupe_feat2_desc"]) setLoupeFeat2Desc(data.blocks["homepage.loupe_feat2_desc"]);
            if (data.blocks["homepage.loupe_feat3_title"]) setLoupeFeat3Title(data.blocks["homepage.loupe_feat3_title"]);
            if (data.blocks["homepage.loupe_feat3_desc"]) setLoupeFeat3Desc(data.blocks["homepage.loupe_feat3_desc"]);
            if (data.blocks["homepage.loupe_cta_text"]) setLoupeCtaText(data.blocks["homepage.loupe_cta_text"]);
            if (data.blocks["homepage.loupe_cta_link"]) setLoupeCtaLink(data.blocks["homepage.loupe_cta_link"]);
            if (data.blocks["homepage.loupe_image"]) setLoupeImage(data.blocks["homepage.loupe_image"]);
            if (data.blocks["homepage.loupe_image_caption"]) setLoupeImageCaption(data.blocks["homepage.loupe_image_caption"]);
            if (data.blocks["homepage.story_image"]) setStoryImage(data.blocks["homepage.story_image"]);
            if (data.blocks["homepage.story_image_badge"]) setStoryImageBadge(data.blocks["homepage.story_image_badge"]);
            if (data.blocks["homepage.story_image_caption"]) setStoryImageCaption(data.blocks["homepage.story_image_caption"]);
            if (data.blocks["homepage.story_eyebrow"]) setStoryEyebrow(data.blocks["homepage.story_eyebrow"]);
            if (data.blocks["homepage.story_headline"]) setStoryHeadline(data.blocks["homepage.story_headline"]);
            if (data.blocks["homepage.story_p1"]) setStoryP1(data.blocks["homepage.story_p1"]);
            if (data.blocks["homepage.story_p2"]) setStoryP2(data.blocks["homepage.story_p2"]);
            if (data.blocks["homepage.story_stat1_val"]) setStoryStat1Val(data.blocks["homepage.story_stat1_val"]);
            if (data.blocks["homepage.story_stat1_lbl"]) setStoryStat1Lbl(data.blocks["homepage.story_stat1_lbl"]);
            if (data.blocks["homepage.story_stat2_val"]) setStoryStat2Val(data.blocks["homepage.story_stat2_val"]);
            if (data.blocks["homepage.story_stat2_lbl"]) setStoryStat2Lbl(data.blocks["homepage.story_stat2_lbl"]);
            if (data.blocks["homepage.story_stat3_val"]) setStoryStat3Val(data.blocks["homepage.story_stat3_val"]);
            if (data.blocks["homepage.story_stat3_lbl"]) setStoryStat3Lbl(data.blocks["homepage.story_stat3_lbl"]);
            if (data.blocks["homepage.story_cta_text"]) setStoryCtaText(data.blocks["homepage.story_cta_text"]);
            if (data.blocks["homepage.story_cta_link"]) setStoryCtaLink(data.blocks["homepage.story_cta_link"]);
            if (data.blocks["homepage.consultation_eyebrow"]) setConsultationEyebrow(data.blocks["homepage.consultation_eyebrow"]);
            if (data.blocks["homepage.consultation_headline"]) setConsultationHeadline(data.blocks["homepage.consultation_headline"]);
            if (data.blocks["homepage.consultation_desc"]) setConsultationDesc(data.blocks["homepage.consultation_desc"]);
            if (data.blocks["homepage.consultation_button_text"]) setConsultationBtnText(data.blocks["homepage.consultation_button_text"]);
            if (data.blocks["shop.eyebrow"]) setShopEyebrow(data.blocks["shop.eyebrow"]);
            if (data.blocks["shop.headline"]) setShopHeadline(data.blocks["shop.headline"]);
            if (data.blocks["shop.subheadline"]) setShopSubheadline(data.blocks["shop.subheadline"]);
            if (data.blocks["shop.banner_image"] !== undefined) setShopBannerImage(data.blocks["shop.banner_image"]);
            if (data.blocks["shop.notice_badge"]) setShopNoticeBadge(data.blocks["shop.notice_badge"]);
            if (data.blocks["shop.notice_active"]) setShopNoticeActive(data.blocks["shop.notice_active"] === "true");
            // About Us CMS Blocks Loading
            if (data.blocks["about.brand_slogan"]) setAboutBrandSlogan(data.blocks["about.brand_slogan"]);
            if (data.blocks["about.brand_tagline"]) setAboutBrandTagline(data.blocks["about.brand_tagline"]);
            if (data.blocks["about.page_intro"]) setAboutPageIntro(data.blocks["about.page_intro"]);

            if (data.blocks["about.trading_desc"]) setAboutTradingDesc(data.blocks["about.trading_desc"]);
            if (data.blocks["about.jewellery_desc"]) setAboutJewelleryDesc(data.blocks["about.jewellery_desc"]);
            if (data.blocks["about.trust_desc"]) setAboutTrustDesc(data.blocks["about.trust_desc"]);
            if (data.blocks["about.vision_short"]) setAboutVisionShort(data.blocks["about.vision_short"]);

            if (data.blocks["about.mission_statement"]) setAboutMissionStatement(data.blocks["about.mission_statement"]);
            if (data.blocks["about.vision_statement"]) setAboutVisionStatement(data.blocks["about.vision_statement"]);

            if (data.blocks["about.founder_name"]) setAboutFounderName(data.blocks["about.founder_name"]);
            if (data.blocks["about.founder_title"]) setAboutFounderTitle(data.blocks["about.founder_title"]);
            if (data.blocks["about.founder_credentials"]) setAboutFounderCredentials(data.blocks["about.founder_credentials"]);
            if (data.blocks["about.founder_image"]) setAboutFounderImage(data.blocks["about.founder_image"]);
            if (data.blocks["about.founder_greeting"]) setAboutFounderGreeting(data.blocks["about.founder_greeting"]);
            if (data.blocks["about.founder_p1"]) setAboutFounderP1(data.blocks["about.founder_p1"]);
            if (data.blocks["about.founder_p2"]) setAboutFounderP2(data.blocks["about.founder_p2"]);
            if (data.blocks["about.founder_p3"]) setAboutFounderP3(data.blocks["about.founder_p3"]);
            if (data.blocks["about.founder_p4"]) setAboutFounderP4(data.blocks["about.founder_p4"]);
            if (data.blocks["about.founder_p5"]) setAboutFounderP5(data.blocks["about.founder_p5"]);

            if (data.blocks["about.headoffice_title"]) setAboutHeadOfficeTitle(data.blocks["about.headoffice_title"]);
            if (data.blocks["about.headoffice_badge"]) setAboutHeadOfficeBadge(data.blocks["about.headoffice_badge"]);
            if (data.blocks["about.headoffice_address"]) setAboutHeadOfficeAddress(data.blocks["about.headoffice_address"]);
            if (data.blocks["about.headoffice_desc"]) setAboutHeadOfficeDesc(data.blocks["about.headoffice_desc"]);
            if (data.blocks["about.headoffice_phone"]) setAboutHeadOfficePhone(data.blocks["about.headoffice_phone"]);

            if (data.blocks["about.kalutara_title"]) setAboutKalutaraTitle(data.blocks["about.kalutara_title"]);
            if (data.blocks["about.kalutara_badge"]) setAboutKalutaraBadge(data.blocks["about.kalutara_badge"]);
            if (data.blocks["about.kalutara_address"]) setAboutKalutaraAddress(data.blocks["about.kalutara_address"]);
            if (data.blocks["about.kalutara_desc"]) setAboutKalutaraDesc(data.blocks["about.kalutara_desc"]);
            if (data.blocks["about.kalutara_phone"]) setAboutKalutaraPhone(data.blocks["about.kalutara_phone"]);
            if (data.blocks["contact.page_eyebrow"]) setContactPageEyebrow(data.blocks["contact.page_eyebrow"]);
            if (data.blocks["contact.page_title"]) setContactPageTitle(data.blocks["contact.page_title"]);
            if (data.blocks["contact.page_subtitle"]) setContactPageSubtitle(data.blocks["contact.page_subtitle"]);
            if (data.blocks["contact.card_title"]) setContactCardTitle(data.blocks["contact.card_title"]);
            if (data.blocks["contact.address_label"]) setContactAddressLabel(data.blocks["contact.address_label"]);
            if (data.blocks["contact.address"]) setContactAddress(data.blocks["contact.address"]);
            if (data.blocks["contact.country"]) setContactCountry(data.blocks["contact.country"]);
            if (data.blocks["contact.secondary_phone"]) {
              setContactSecondaryPhone(data.blocks["contact.secondary_phone"]);
              setContactLandline(data.blocks["contact.secondary_phone"]);
            } else if (data.blocks["contact.landline"]) {
              setContactSecondaryPhone(data.blocks["contact.landline"]);
              setContactLandline(data.blocks["contact.landline"]);
            }
            if (data.blocks["contact.hours"]) setContactHours(data.blocks["contact.hours"]);
            if (data.blocks["contact.phone_label"]) setContactPhoneLabel(data.blocks["contact.phone_label"]);
            if (data.blocks["contact.phone"]) setContactPhone(data.blocks["contact.phone"]);
            if (data.blocks["contact.response_time"]) setContactResponseTime(data.blocks["contact.response_time"]);
            if (data.blocks["contact.email_label"]) setContactEmailLabel(data.blocks["contact.email_label"]);
            if (data.blocks["contact.email"]) setContactEmail(data.blocks["contact.email"]);
            if (data.blocks["contact.delivery_badge"]) setContactDeliveryBadge(data.blocks["contact.delivery_badge"]);
            if (data.blocks["contact.delivery_description"]) setContactDeliveryDescription(data.blocks["contact.delivery_description"]);
            if (data.blocks["banking.bank_name"]) setBankName(data.blocks["banking.bank_name"]);
            if (data.blocks["banking.bank_short_name"]) setBankShortName(data.blocks["banking.bank_short_name"]);
            if (data.blocks["banking.branch_name"]) setBranchName(data.blocks["banking.branch_name"]);
            if (data.blocks["banking.account_name"]) setAccountName(data.blocks["banking.account_name"]);
            if (data.blocks["banking.account_number"]) setAccountNumber(data.blocks["banking.account_number"]);
            if (data.blocks["banking.bank_logo"]) setBankLogo(data.blocks["banking.bank_logo"]);
            if (data.blocks["collections.page.eyebrow"]) setCollectionsPageEyebrow(data.blocks["collections.page.eyebrow"]);
            if (data.blocks["collections.page.headline"]) setCollectionsPageHeadline(data.blocks["collections.page.headline"]);
            if (data.blocks["collections.page.subheadline"]) setCollectionsPageSubheadline(data.blocks["collections.page.subheadline"]);
            if (data.blocks["collections.showcase.eyebrow"]) setCollectionsShowcaseEyebrow(data.blocks["collections.showcase.eyebrow"]);
            if (data.blocks["collections.showcase.title"]) setCollectionsShowcaseTitle(data.blocks["collections.showcase.title"]);
            if (data.blocks["collections.showcase.subtitle"]) setCollectionsShowcaseSubtitle(data.blocks["collections.showcase.subtitle"]);
            if (data.blocks["collections.cards_list"] !== undefined) {
              setCollectionCards(getParsedCollectionCards(data.blocks["collections.cards_list"]));
            } else {
              setCollectionCards((prev) =>
                prev.map((c) => ({
                  ...c,
                  name: data.blocks[`collection.${c.slug}.title`] || c.name,
                  image: data.blocks[`collection.${c.slug}.hero_image`] || c.image,
                }))
              );
            }
          }
        }
      })
      .catch(() => { });
  }, []);

  const handleCopyPreviewText = (text: string, key: string) => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setPreviewCopiedKey(key);
      setTimeout(() => setPreviewCopiedKey(null), 2000);
    }
  };

  const handleUploadBankLogo = async (file: File) => {
    if (!file) return;
    const validTypes = ["image/png", "image/jpeg", "image/webp", "image/svg+xml"];
    if (!validTypes.includes(file.type) && !/\.(png|jpe?g|webp|svg)$/i.test(file.name)) {
      setBankLogoUploadError("Please select a valid PNG, SVG, WEBP, or JPEG bank logo image.");
      return;
    }

    setIsUploadingBankLogo(true);
    setBankLogoUploadError("");

    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("category", "branding");

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        body: formData,
      });

      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to upload bank logo");

      if (json.url) {
        setBankLogo(json.url);
        toast.success("Bank Logo Uploaded", "Bank logo uploaded. Click 'Save Bank Details' to apply changes.");
      }
    } catch (err) {
      setBankLogoUploadError((err as Error).message);
      toast.error("Upload Failed", (err as Error).message);
    } finally {
      setIsUploadingBankLogo(false);
    }
  };

  const handleSaveBankingSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingCMS(true);
    setBankLogoUploadError("");
    try {
      const res = await fetch("/api/cms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "blocks",
          items: [
            { section: "banking", key: "bank_name", value: bankName.trim() },
            { section: "banking", key: "bank_short_name", value: bankShortName.trim() },
            { section: "banking", key: "branch_name", value: branchName.trim() },
            { section: "banking", key: "account_name", value: accountName.trim() },
            { section: "banking", key: "account_number", value: accountNumber.trim() },
            { section: "banking", key: "swift_code", value: "" },
            { section: "banking", key: "bank_logo", value: bankLogo.trim() },
          ],
        }),
      });

      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to save bank transfer settings");

      if (typeof window !== "undefined") {
        window.dispatchEvent(new CustomEvent("cms-updated"));
      }

      toast.success(
        "Bank Details Saved",
        "Bank transfer details updated successfully across checkout."
      );
    } catch (err) {
      toast.error("Save Error", (err as Error).message);
    } finally {
      setIsSavingCMS(false);
    }
  };

  const handleHeroImageUpload = async (file: File) => {
    if (!file) return;

    // Validate MIME type
    const validMimes = ["image/jpeg", "image/png", "image/webp", "image/avif"];
    if (!validMimes.includes(file.type) && !/\.(jpe?g|png|webp|avif)$/i.test(file.name)) {
      setHeroImageUploadError("Please select a valid image file (JPEG, PNG, WEBP, or AVIF).");
      return;
    }

    if (file.size > 25 * 1024 * 1024) {
      setHeroImageUploadError("Image file size exceeds the 25MB limit.");
      return;
    }

    setIsUploadingHeroImage(true);
    setHeroImageUploadError("");

    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("category", "banners");

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        body: formData,
      });

      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to upload banner image");

      if (json.url) {
        setHeroImage(json.url);

        // Auto-save hero image block directly to MySQL CMS immediately
        try {
          await fetch("/api/cms", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              type: "block",
              section: "homepage",
              key: "hero_image",
              value: json.url,
            }),
          });
          if (typeof window !== "undefined") {
            window.dispatchEvent(new CustomEvent("cms-updated"));
          }
        } catch (saveErr) {
          console.error("Auto-save hero image error:", saveErr);
        }

        toast.success("Banner Image Saved", "Homepage banner image updated successfully.");
      }
    } catch (err) {
      setHeroImageUploadError((err as Error).message);
      toast.error("Upload Error", (err as Error).message);
    } finally {
      setIsUploadingHeroImage(false);
    }
  };

  const handleLoupeImageUpload = async (file: File) => {
    if (!file) return;
    const validMimes = ["image/jpeg", "image/png", "image/webp", "image/avif"];
    if (!validMimes.includes(file.type) && !/\.(jpe?g|png|webp|avif)$/i.test(file.name)) {
      setLoupeImageUploadError("Please select a valid image file (JPEG, PNG, WEBP, or AVIF).");
      return;
    }
    if (file.size > 25 * 1024 * 1024) {
      setLoupeImageUploadError("Image file size exceeds the 25MB limit.");
      return;
    }

    setIsUploadingLoupeImage(true);
    setLoupeImageUploadError("");

    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("category", "banners");

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        body: formData,
      });

      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to upload image");

      if (json.url) {
        setLoupeImage(json.url);
        try {
          await fetch("/api/cms", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              type: "block",
              section: "homepage",
              key: "loupe_image",
              value: json.url,
            }),
          });
          if (typeof window !== "undefined") {
            window.dispatchEvent(new CustomEvent("cms-updated"));
          }
        } catch (saveErr) {
          console.error("Auto-save loupe image error:", saveErr);
        }
        toast.success("Loupe Image Saved", "Showcase image updated successfully.");
      }
    } catch (err) {
      setLoupeImageUploadError((err as Error).message);
      toast.error("Upload Error", (err as Error).message);
    } finally {
      setIsUploadingLoupeImage(false);
    }
  };

  const handleStoryImageUpload = async (file: File) => {
    if (!file) return;
    const validMimes = ["image/jpeg", "image/png", "image/webp", "image/avif"];
    if (!validMimes.includes(file.type) && !/\.(jpe?g|png|webp|avif)$/i.test(file.name)) {
      setStoryImageUploadError("Please select a valid image file (JPEG, PNG, WEBP, or AVIF).");
      return;
    }
    if (file.size > 25 * 1024 * 1024) {
      setStoryImageUploadError("Image file size exceeds the 25MB limit.");
      return;
    }

    setIsUploadingStoryImage(true);
    setStoryImageUploadError("");

    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("category", "banners");

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        body: formData,
      });

      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to upload image");

      if (json.url) {
        setStoryImage(json.url);
        try {
          await fetch("/api/cms", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              type: "block",
              section: "homepage",
              key: "story_image",
              value: json.url,
            }),
          });
          if (typeof window !== "undefined") {
            window.dispatchEvent(new CustomEvent("cms-updated"));
          }
        } catch (saveErr) {
          console.error("Auto-save story image error:", saveErr);
        }
        toast.success("Story Image Saved", "Brand story image updated successfully.");
      }
    } catch (err) {
      setStoryImageUploadError((err as Error).message);
      toast.error("Upload Error", (err as Error).message);
    } finally {
      setIsUploadingStoryImage(false);
    }
  };

  const handleResetHomepageToDefault = async () => {
    const isConfirmed = await confirm({
      title: "Reset Homepage to Default?",
      message: "This will reset all 8 homepage sections to their default luxury copy and photography in this form. Click Save afterwards to commit to the live site. Continue?",
      confirmLabel: "Reset to Default",
      cancelLabel: "Cancel",
      variant: "danger",
    });
    if (!isConfirmed) return;

    setHeroEyebrow("Natural Gemstones • Certified by GIA & Swiss Labs");
    setHeroHeadline("Discover Nature's Rarest Gemstones");
    setHeroSubheadline("Handpicked natural sapphires, rubies, emeralds, and rare gems. Each stone is carefully selected for its color, clarity, and origin — certified by the world's top labs.");
    setHeroCtaPrimaryText("Browse All Gemstones");
    setHeroCtaPrimaryLink("/shop");
    setHeroCtaSecondaryText("Premium Collection");
    setHeroCtaSecondaryLink("/collections/collectors-vault");
    setHeroImage("/uploads/banners/hero-1789651834163-md9w3c.webp");
    setMetric1Val("100%");
    setMetric1Lbl("Certified Natural");
    setMetric2Val("GIA & GRS");
    setMetric2Lbl("Independent Reports");
    setMetric3Val("Armored");
    setMetric3Lbl("Worldwide Courier");
    setMetric4Val("30 Days");
    setMetric4Lbl("Inspection Period");
    setTrust1Title("Independently Certified Labs");
    setTrust1Desc("GIA, Gübelin, SSEF & GRS lab reports you can verify online");
    setTrust2Title("30-Day Money-Back Guarantee");
    setTrust2Desc("Not satisfied? Return within 30 days for a full refund — no questions asked");
    setCollectionsEyebrow("Our Collections");
    setCollectionsHeadline("Explore Our Gemstone Collections");
    setCollectionsSubheadline("Browse collections of the world's finest natural gemstones — sourced directly from the mines and cut by expert craftsmen.");
    setVaultEyebrow("New Arrivals");
    setVaultHeadline("Certified Natural Gemstones");
    setVaultSubheadline("One-of-a-kind natural gemstones, each with an official lab certificate from GIA, Gübelin, SSEF, or GRS.");
    setVaultCtaText("View All Gemstones");
    setLoupeEyebrow("See Every Detail Online");
    setLoupeHeadline("Zoom In & Inspect Every Gemstone Up Close");
    setLoupeSubheadline("Can't visit in person? No problem. Our high-resolution image viewer lets you examine every detail of the gemstone — just like a professional gemologist would.");
    setLoupeFeat1Title("10x Zoom Magnification");
    setLoupeFeat1Desc("See the natural details and clarity of each stone up close.");
    setLoupeFeat2Title("Detailed Photo Gallery");
    setLoupeFeat2Desc("View the cut quality, light performance, and sparkle from every angle.");
    setLoupeFeat3Title("Lab Certificate Included");
    setLoupeFeat3Desc("Every gemstone comes with its original lab report and certificate.");
    setLoupeCtaText("View a Gemstone Up Close →");
    setLoupeCtaLink("/shop");
    setLoupeImage("/uploads/banners/hero-1789651917652-xw752j.webp");
    setLoupeImageCaption("ROYAL BLUE CEYLON SAPPHIRE • CLOSE-UP VIEW");
    setStoryImage("/uploads/banners/hero-1789651886835-6o989i.webp");
    setStoryImageBadge("Ethically Sourced");
    setStoryImageCaption("From Sri Lankan mines to expertly cut gemstones.");
    setStoryEyebrow("Our Story");
    setStoryHeadline("Crafted by Nature. Delivered with Trust.");
    setStoryP1("At Faizan Gems, we believe the world's finest gemstones should stay 100% natural — no heating, no chemical treatment, no artificial enhancements.");
    setStoryP2("We work directly with miners in Sri Lanka, Colombia, and Thailand. Every stone is bought from small-scale, eco-friendly mining operations — ensuring fair pay for workers and minimal impact on the environment.");
    setStoryStat1Val("100%");
    setStoryStat1Lbl("Natural & Untreated");
    setStoryStat2Val("3");
    setStoryStat2Lbl("Generations of Expert Cutters");
    setStoryStat3Val("Direct");
    setStoryStat3Lbl("Mine-to-You Direct");
    setStoryCtaText("Read Our Story →");
    setStoryCtaLink("/about");
    setConsultationEyebrow("Need Help Choosing?");
    setConsultationHeadline("Looking for a Specific Gemstone?");
    setConsultationDesc("Our gemstone experts are happy to help — visit our Trincomalee showroom or book a free video call consultation.");
    setConsultationBtnText("Book a Free Consultation");

    toast.info("Defaults Restored", "All homepage section defaults loaded. Click 'Save Homepage Content' to persist.");
  };

  const handleSaveHeroSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingCMS(true);
    setHeroImageUploadError("");
    try {
      const res = await fetch("/api/cms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "blocks",
          items: [
            // Section 1: Hero Banner
            { section: "homepage", key: "hero_eyebrow", value: heroEyebrow },
            { section: "homepage", key: "hero_headline", value: heroHeadline },
            { section: "homepage", key: "hero_subheadline", value: heroSubheadline },
            { section: "homepage", key: "hero_cta_primary_text", value: heroCtaPrimaryText },
            { section: "homepage", key: "hero_cta_primary_link", value: heroCtaPrimaryLink },
            { section: "homepage", key: "hero_cta_secondary_text", value: heroCtaSecondaryText },
            { section: "homepage", key: "hero_cta_secondary_link", value: heroCtaSecondaryLink },
            { section: "homepage", key: "hero_image", value: heroImage },
            // Section 1: Metrics
            { section: "homepage", key: "metric1_val", value: metric1Val },
            { section: "homepage", key: "metric1_lbl", value: metric1Lbl },
            { section: "homepage", key: "metric2_val", value: metric2Val },
            { section: "homepage", key: "metric2_lbl", value: metric2Lbl },
            { section: "homepage", key: "metric3_val", value: metric3Val },
            { section: "homepage", key: "metric3_lbl", value: metric3Lbl },
            { section: "homepage", key: "metric4_val", value: metric4Val },
            { section: "homepage", key: "metric4_lbl", value: metric4Lbl },
            // Section 2: Trust
            { section: "homepage", key: "trust1_title", value: trust1Title },
            { section: "homepage", key: "trust1_desc", value: trust1Desc },
            { section: "homepage", key: "trust2_title", value: trust2Title },
            { section: "homepage", key: "trust2_desc", value: trust2Desc },
            // Section 3: Collections
            { section: "homepage", key: "collections_eyebrow", value: collectionsEyebrow },
            { section: "homepage", key: "collections_headline", value: collectionsHeadline },
            { section: "homepage", key: "collections_subheadline", value: collectionsSubheadline },
            // Section 4: Vault
            { section: "homepage", key: "vault_eyebrow", value: vaultEyebrow },
            { section: "homepage", key: "vault_headline", value: vaultHeadline },
            { section: "homepage", key: "vault_subheadline", value: vaultSubheadline },
            { section: "homepage", key: "vault_cta_text", value: vaultCtaText },
            // Section 5: Loupe Showcase
            { section: "homepage", key: "loupe_eyebrow", value: loupeEyebrow },
            { section: "homepage", key: "loupe_headline", value: loupeHeadline },
            { section: "homepage", key: "loupe_subheadline", value: loupeSubheadline },
            { section: "homepage", key: "loupe_feat1_title", value: loupeFeat1Title },
            { section: "homepage", key: "loupe_feat1_desc", value: loupeFeat1Desc },
            { section: "homepage", key: "loupe_feat2_title", value: loupeFeat2Title },
            { section: "homepage", key: "loupe_feat2_desc", value: loupeFeat2Desc },
            { section: "homepage", key: "loupe_feat3_title", value: loupeFeat3Title },
            { section: "homepage", key: "loupe_feat3_desc", value: loupeFeat3Desc },
            { section: "homepage", key: "loupe_cta_text", value: loupeCtaText },
            { section: "homepage", key: "loupe_cta_link", value: loupeCtaLink },
            { section: "homepage", key: "loupe_image", value: loupeImage },
            { section: "homepage", key: "loupe_image_caption", value: loupeImageCaption },
            // Section 7: Story
            { section: "homepage", key: "story_image", value: storyImage },
            { section: "homepage", key: "story_image_badge", value: storyImageBadge },
            { section: "homepage", key: "story_image_caption", value: storyImageCaption },
            { section: "homepage", key: "story_eyebrow", value: storyEyebrow },
            { section: "homepage", key: "story_headline", value: storyHeadline },
            { section: "homepage", key: "story_p1", value: storyP1 },
            { section: "homepage", key: "story_p2", value: storyP2 },
            { section: "homepage", key: "story_stat1_val", value: storyStat1Val },
            { section: "homepage", key: "story_stat1_lbl", value: storyStat1Lbl },
            { section: "homepage", key: "story_stat2_val", value: storyStat2Val },
            { section: "homepage", key: "story_stat2_lbl", value: storyStat2Lbl },
            { section: "homepage", key: "story_stat3_val", value: storyStat3Val },
            { section: "homepage", key: "story_stat3_lbl", value: storyStat3Lbl },
            { section: "homepage", key: "story_cta_text", value: storyCtaText },
            { section: "homepage", key: "story_cta_link", value: storyCtaLink },
            // Section 8: Consultation
            { section: "homepage", key: "consultation_eyebrow", value: consultationEyebrow },
            { section: "homepage", key: "consultation_headline", value: consultationHeadline },
            { section: "homepage", key: "consultation_desc", value: consultationDesc },
            { section: "homepage", key: "consultation_button_text", value: consultationBtnText },
          ],
        }),
      });
      if (res.ok) {
        if (typeof window !== "undefined") {
          window.dispatchEvent(new CustomEvent("cms-updated"));
        }
        toast.success("Homepage Saved", "All 8 homepage sections updated successfully and are now live.");
      } else {
        const json = await res.json();
        const errStr = "Failed to save homepage content: " + (json.error || "Server error");
        setHeroImageUploadError(errStr);
        toast.error("Save Failed", errStr);
      }
    } catch (err) {
      const errStr = "Failed to save homepage content: " + (err as Error).message;
      setHeroImageUploadError(errStr);
      toast.error("Save Error", errStr);
    } finally {
      setIsSavingCMS(false);
    }
  };

  const handleSaveShop = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingCMS(true);
    try {
      const res = await fetch("/api/cms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "blocks",
          items: [
            { section: "shop", key: "eyebrow", value: shopEyebrow },
            { section: "shop", key: "headline", value: shopHeadline },
            { section: "shop", key: "subheadline", value: shopSubheadline },
            { section: "shop", key: "banner_image", value: shopBannerImage },
            { section: "shop", key: "notice_badge", value: shopNoticeBadge },
            { section: "shop", key: "notice_active", value: shopNoticeActive ? "true" : "false" },
          ],
        }),
      });
      if (res.ok) {
        toast.success("Shop Settings Saved", "Shop page text and banner updated successfully.");
      } else {
        toast.error("Save Failed", "Could not save shop settings.");
      }
    } catch (err) {
      toast.error("Network Error", "Failed to communicate with server.");
    } finally {
      setIsSavingCMS(false);
    }
  };

  const handleShopBannerUpload = async (file: File) => {
    if (!file) return;

    // Validate MIME type
    const validMimes = ["image/jpeg", "image/png", "image/webp", "image/avif"];
    if (!validMimes.includes(file.type) && !/\.(jpe?g|png|webp|avif)$/i.test(file.name)) {
      setShopBannerUploadError("Please select a valid image file (JPEG, PNG, WEBP, or AVIF).");
      return;
    }

    if (file.size > 25 * 1024 * 1024) {
      setShopBannerUploadError("Image file size exceeds the 25MB limit.");
      return;
    }

    setIsUploadingShopBanner(true);
    setShopBannerUploadError("");

    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("category", "banners");

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        body: formData,
      });

      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to upload shop banner image");

      if (json.url) {
        setShopBannerImage(json.url);

        // Auto-save shop banner image block directly to MySQL CMS immediately
        try {
          await fetch("/api/cms", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              type: "block",
              section: "shop",
              key: "banner_image",
              value: json.url,
            }),
          });
          if (typeof window !== "undefined") {
            window.dispatchEvent(new CustomEvent("cms-updated"));
          }
        } catch (saveErr) {
          console.error("Auto-save shop banner image error:", saveErr);
        }

        toast.success(
          "Banner Uploaded",
          "Shop header banner image uploaded and updated successfully."
        );
      }
    } catch (err) {
      setShopBannerUploadError((err as Error).message);
      toast.error("Upload Error", (err as Error).message);
    } finally {
      setIsUploadingShopBanner(false);
    }
  };

  const handleUploadAboutImage = async (
    file: File,
    setter: (url: string) => void,
    fieldId: string
  ) => {
    if (!file) return;

    const validMimes = ["image/jpeg", "image/png", "image/webp", "image/avif"];
    if (!validMimes.includes(file.type) && !/\.(jpe?g|png|webp|avif)$/i.test(file.name)) {
      setAboutImageUploadError("Please select a valid image file (JPEG, PNG, WEBP, or AVIF).");
      return;
    }

    if (file.size > 25 * 1024 * 1024) {
      setAboutImageUploadError("Image file size exceeds the 25MB limit.");
      return;
    }

    setIsUploadingAboutImage(fieldId);
    setAboutImageUploadError("");

    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("category", "about");

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        body: formData,
      });

      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to upload image");

      if (json.url) {
        setter(json.url);
        toast.success("Image Uploaded", "Image uploaded successfully. Click 'Save Changes' to persist changes.");
      }
    } catch (err) {
      setAboutImageUploadError((err as Error).message);
      toast.error("Upload Error", (err as Error).message);
    } finally {
      setIsUploadingAboutImage(null);
    }
  };

  const handleSaveAbout = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSavingCMS(true);
    try {
      const res = await fetch("/api/cms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "blocks",
          items: [
            // Section 1: Hero & Brand Identity
            { section: "about", key: "brand_slogan", value: aboutBrandSlogan },
            { section: "about", key: "brand_tagline", value: aboutBrandTagline },
            { section: "about", key: "page_intro", value: aboutPageIntro },

            // Section 2: Company Overview & Specialization
            { section: "about", key: "trading_desc", value: aboutTradingDesc },
            { section: "about", key: "jewellery_desc", value: aboutJewelleryDesc },
            { section: "about", key: "trust_desc", value: aboutTrustDesc },
            { section: "about", key: "vision_short", value: aboutVisionShort },

            // Section 3: Mission & Vision
            { section: "about", key: "mission_statement", value: aboutMissionStatement },
            { section: "about", key: "vision_statement", value: aboutVisionStatement },

            // Section 4: Message from the CEO
            { section: "about", key: "founder_name", value: aboutFounderName },
            { section: "about", key: "founder_title", value: aboutFounderTitle },
            { section: "about", key: "founder_credentials", value: aboutFounderCredentials },
            { section: "about", key: "founder_image", value: aboutFounderImage },
            { section: "about", key: "founder_greeting", value: aboutFounderGreeting },
            { section: "about", key: "founder_p1", value: aboutFounderP1 },
            { section: "about", key: "founder_p2", value: aboutFounderP2 },
            { section: "about", key: "founder_p3", value: aboutFounderP3 },
            { section: "about", key: "founder_p4", value: aboutFounderP4 },
            { section: "about", key: "founder_p5", value: aboutFounderP5 },

            // Section 5: Our Locations
            { section: "about", key: "headoffice_title", value: aboutHeadOfficeTitle },
            { section: "about", key: "headoffice_badge", value: aboutHeadOfficeBadge },
            { section: "about", key: "headoffice_address", value: aboutHeadOfficeAddress },
            { section: "about", key: "headoffice_desc", value: aboutHeadOfficeDesc },
            { section: "about", key: "headoffice_phone", value: aboutHeadOfficePhone },

            { section: "about", key: "kalutara_title", value: aboutKalutaraTitle },
            { section: "about", key: "kalutara_badge", value: aboutKalutaraBadge },
            { section: "about", key: "kalutara_address", value: aboutKalutaraAddress },
            { section: "about", key: "kalutara_desc", value: aboutKalutaraDesc },
            { section: "about", key: "kalutara_phone", value: aboutKalutaraPhone },
          ],
        }),
      });
      if (res.ok) {
        if (typeof window !== "undefined") {
          window.dispatchEvent(new CustomEvent("cms-updated"));
        }
        toast.success("About Us Saved", "About us page content updated successfully.");
      } else {
        toast.error("Save Failed", "Could not save about us content.");
      }
    } catch {
      toast.error("Network Error", "Failed to communicate with server.");
    } finally {
      setIsSavingCMS(false);
    }
  };

  const handleSaveContact = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSavingCMS(true);
    try {
      const res = await fetch("/api/cms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "blocks",
          items: [
            { section: "contact", key: "page_eyebrow", value: contactPageEyebrow },
            { section: "contact", key: "page_title", value: contactPageTitle },
            { section: "contact", key: "page_subtitle", value: contactPageSubtitle },
            { section: "contact", key: "card_title", value: contactCardTitle },
            { section: "contact", key: "address_label", value: contactAddressLabel },
            { section: "contact", key: "address", value: contactAddress },
            { section: "contact", key: "country", value: contactCountry },
            { section: "contact", key: "hours", value: contactHours },
            { section: "contact", key: "phone_label", value: contactPhoneLabel },
            { section: "contact", key: "phone", value: contactPhone },
            { section: "contact", key: "secondary_phone", value: contactSecondaryPhone },
            { section: "contact", key: "landline", value: contactSecondaryPhone },
            { section: "contact", key: "response_time", value: contactResponseTime },
            { section: "contact", key: "email_label", value: contactEmailLabel },
            { section: "contact", key: "email", value: contactEmail },
            { section: "contact", key: "delivery_badge", value: contactDeliveryBadge },
            { section: "contact", key: "delivery_description", value: contactDeliveryDescription },
          ],
        }),
      });
      if (res.ok) {
        if (typeof window !== "undefined") {
          window.dispatchEvent(new CustomEvent("cms-updated"));
        }
        toast.success("Contact Page Saved", "Contact page information updated successfully.");
      } else {
        toast.error("Save Failed", "Could not save contact page information.");
      }
    } catch (err) {
      toast.error("Network Error", "Failed to communicate with server.");
    } finally {
      setIsSavingCMS(false);
    }
  };

  const handleUpdateCardField = <K extends keyof CMSCollectionCard>(
    id: string,
    field: K,
    value: CMSCollectionCard[K]
  ) => {
    setCollectionCards((prev) =>
      prev.map((c) => {
        if (c.id !== id) return c;
        if (field === "name") {
          const autoSlug =
            String(value).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || c.slug;
          return { ...c, name: value as string, slug: autoSlug };
        }
        return { ...c, [field]: value };
      })
    );
  };


  const handleToggleCardShowOnHome = (id: string) => {
    setCollectionCards((prev) =>
      prev.map((c) => (c.id === id ? { ...c, showOnHome: !c.showOnHome } : c))
    );
  };

  const handleMoveCard = (id: string, direction: "up" | "down") => {
    setCollectionCards((prev) => {
      const idx = prev.findIndex((c) => c.id === id);
      if (idx === -1) return prev;
      if (direction === "up" && idx === 0) return prev;
      if (direction === "down" && idx === prev.length - 1) return prev;
      const targetIdx = direction === "up" ? idx - 1 : idx + 1;
      const next = [...prev];
      const temp = next[idx];
      next[idx] = next[targetIdx];
      next[targetIdx] = temp;
      return next.map((item, i) => ({ ...item, orderIndex: i }));
    });
  };

  const handleUploadCardImage = async (file: File, id: string) => {
    if (!file) return;
    const validMimes = ["image/jpeg", "image/png", "image/webp", "image/avif"];
    if (!validMimes.includes(file.type) && !/\.(jpe?g|png|webp|avif)$/i.test(file.name)) {
      setCollectionCardError("Please select a valid image file (JPEG, PNG, WEBP, or AVIF).");
      return;
    }
    if (file.size > 25 * 1024 * 1024) {
      setCollectionCardError("Image file size exceeds the 25MB limit.");
      return;
    }

    setUploadingCardId(id);
    setCollectionCardError("");

    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("category", "banners");

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        body: formData,
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to upload image");

      if (json.url) {
        handleUpdateCardField(id, "image", json.url);
        toast.success("Image Uploaded", "Card image updated. Click 'Save Collection Cards' to publish.");
      }
    } catch (err) {
      setCollectionCardError((err as Error).message);
      toast.error("Upload Error", (err as Error).message);
    } finally {
      setUploadingCardId(null);
    }
  };

  const handleUploadNewCardImage = async (file: File) => {
    if (!file) return;
    const validMimes = ["image/jpeg", "image/png", "image/webp", "image/avif"];
    if (!validMimes.includes(file.type) && !/\.(jpe?g|png|webp|avif)$/i.test(file.name)) {
      setCollectionCardError("Please select a valid image file (JPEG, PNG, WEBP, or AVIF).");
      return;
    }
    if (file.size > 25 * 1024 * 1024) {
      setCollectionCardError("Image file size exceeds the 25MB limit.");
      return;
    }

    setIsUploadingNewCardImage(true);
    setCollectionCardError("");

    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("category", "banners");

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        body: formData,
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to upload image");

      if (json.url) {
        setNewCardImage(json.url);
        toast.success("Image Uploaded", "Card image ready.");
      }
    } catch (err) {
      setCollectionCardError((err as Error).message);
      toast.error("Upload Error", (err as Error).message);
    } finally {
      setIsUploadingNewCardImage(false);
    }
  };

  const handleAddNewCard = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = newCardName.trim();
    if (!trimmedName) {
      toast.error("Validation Error", "Please provide a name for the gemstone collection.");
      return;
    }

    if (!newCardImage) {
      toast.error("Validation Error", "Please upload a cover image file for this collection card.");
      return;
    }

    const slug =
      (newCardSlug.trim() || trimmedName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")) ||
      `collection-${Date.now()}`;
    const image = newCardImage.trim();

    const newCard: CMSCollectionCard = {
      id: `col-${Date.now()}`,
      slug,
      name: trimmedName,
      image,
      showOnHome: newCardShowOnHome,
      orderIndex: collectionCards.length,
    };

    setCollectionCards((prev) => [...prev, newCard]);
    setNewCardName("");
    setNewCardSlug("");
    setNewCardImage("");
    setNewCardShowOnHome(true);
    setIsAddCardModalOpen(false);
    toast.success("Card Added", `"${trimmedName}" added. Click 'Save Collection Cards' to publish.`);
  };

  const handleDeleteCard = async (id: string, name: string) => {
    const isConfirmed = await confirm({
      title: `Delete Collection Card?`,
      message: `Are you sure you want to remove "${name}" from collections? This will immediately remove the card from the collection page and homepage.`,
      confirmLabel: "Delete Card",
      cancelLabel: "Cancel",
      variant: "danger",
    });
    if (!isConfirmed) return;

    const updatedCards = collectionCards.filter((c) => c.id !== id);
    setCollectionCards(updatedCards);

    try {
      const items = [
        { section: "collections", key: "cards_list", value: JSON.stringify(updatedCards) },
      ];

      const res = await fetch("/api/cms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "blocks", items }),
      });

      if (res.ok) {
        if (typeof window !== "undefined") {
          window.dispatchEvent(new CustomEvent("cms-updated"));
        }
        toast.success("Card Deleted", `"${name}" removed and collections updated live.`);
      } else {
        const json = await res.json().catch(() => ({}));
        toast.error("Delete Failed", json.error || "Could not persist card removal to server.");
      }
    } catch {
      toast.error("Network Error", "Failed to communicate with server to delete card.");
    }
  };

  const handleResetCollectionsToDefault = async () => {
    const isConfirmed = await confirm({
      title: "Reset Collections to Defaults?",
      message: "Are you sure you want to restore the default 5 gemstone collections? Any custom cards or edits will be reverted.",
      confirmLabel: "Reset to Defaults",
      cancelLabel: "Cancel",
      variant: "danger",
    });
    if (!isConfirmed) return;

    setCollectionCards(DEFAULT_COLLECTION_CARDS);

    try {
      const items = [
        { section: "collections", key: "cards_list", value: JSON.stringify(DEFAULT_COLLECTION_CARDS) },
      ];

      const res = await fetch("/api/cms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "blocks", items }),
      });

      if (res.ok) {
        if (typeof window !== "undefined") {
          window.dispatchEvent(new CustomEvent("cms-updated"));
        }
        toast.success("Reset Applied", "Collections restored to defaults and saved live.");
      } else {
        toast.info("Reset Applied", "Collections reset to original defaults. Click 'Save Collection Cards' to persist.");
      }
    } catch {
      toast.info("Reset Applied", "Collections reset in editor. Click 'Save Collection Cards' to persist.");
    }
  };

  const handleSaveCollections = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSavingCMS(true);
    try {
      const items: { section: string; key: string; value: string }[] = [
        { section: "collections", key: "cards_list", value: JSON.stringify(collectionCards) },
        { section: "collections.page", key: "eyebrow", value: collectionsPageEyebrow },
        { section: "collections.page", key: "headline", value: collectionsPageHeadline },
        { section: "collections.page", key: "subheadline", value: collectionsPageSubheadline },
        { section: "collections.showcase", key: "eyebrow", value: collectionsShowcaseEyebrow },
        { section: "collections.showcase", key: "title", value: collectionsShowcaseTitle },
        { section: "collections.showcase", key: "subtitle", value: collectionsShowcaseSubtitle },
      ];

      for (const card of collectionCards) {
        items.push(
          { section: "collection", key: `${card.slug}.title`, value: card.name },
          { section: "collection", key: `${card.slug}.hero_image`, value: card.image }
        );
      }

      const res = await fetch("/api/cms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "blocks", items }),
      });

      if (res.ok) {
        if (typeof window !== "undefined") {
          window.dispatchEvent(new CustomEvent("cms-updated"));
        }
        toast.success("Collections Saved", "Collection cards and homepage display settings updated live.");
      } else {
        const json = await res.json();
        toast.error("Save Failed", json.error || "Could not save collection cards.");
      }
    } catch (err) {
      toast.error("Save Error", (err as Error).message);
    } finally {
      setIsSavingCMS(false);
    }
  };

  const cmsSubTabs: {
    id: "banking" | "hero" | "shop" | "collections" | "about" | "contact";
    label: string;
    badge?: string;
  }[] = [
    { id: "banking", label: "Bank Account" },
    { id: "hero", label: "Homepage" },
    { id: "shop", label: "Shop Page" },
    { id: "collections", label: "Collections Page" },
    { id: "about", label: "About Us Page" },
    { id: "contact", label: "Contact Us Page" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#24242C] pb-6">
        <div>
          <div className="flex flex-wrap items-center gap-2.5">
            <h1 className="font-sans font-bold text-xl sm:text-2xl text-white tracking-tight">
              Website Content Settings
            </h1>
          </div>
          <p className="text-xs text-[#8C867D] font-sans mt-1">
            Manage your bank details, homepage banners, and shop text in real-time.
          </p>
        </div>
      </div>

      {/* Mobile Sub-Navigation Dropdown (LuxurySelect for Mobile Responsive) */}
      <div className="md:hidden relative z-30 pb-3 border-b border-[#24242C]">
        <label className="block text-[10px] font-mono uppercase tracking-wider text-[#8C867D] mb-1.5 select-none">
          CMS Section:
        </label>
        <LuxurySelect
          variant="dark"
          size="md"
          value={cmsSubTab}
          onChange={(val) => setCmsSubTab(val as typeof cmsSubTab)}
          options={cmsSubTabs.map((tab) => ({
            value: tab.id,
            label: tab.label,
            badge: tab.badge,
          }))}
        />
      </div>

      {/* Desktop Sub-Navigation Tabs */}
      <div className="hidden md:flex flex-wrap items-center gap-2 border-b border-[#24242C] pb-3 text-xs font-sans">
        {cmsSubTabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setCmsSubTab(tab.id)}
            className={`px-3.5 py-2 rounded-sm text-xs font-medium font-sans flex items-center gap-2 transition-colors duration-150 cursor-pointer select-none ${
              cmsSubTab === tab.id
                ? "bg-[#C5A880] text-[#0D0D11] shadow-xs"
                : "bg-[#1A1A22] text-[#8C867D] hover:text-white hover:bg-[#23232D]"
            }`}
          >
            <span>{tab.label}</span>
            {tab.badge !== undefined && (
              <span
                className={`text-[9px] font-mono tabular-nums px-1.5 py-0.5 rounded-sm font-semibold ${
                  cmsSubTab === tab.id
                    ? "bg-[#0D0D11]/20 text-[#0D0D11]"
                    : "bg-[#252534] text-[#C5A880] border border-[#343448]"
                }`}
              >
                {tab.badge}
              </span>
            )}
          </button>
        ))}
      </div>


      {/* SUBTAB: BANK ACCOUNT DETAILS */}
      {cmsSubTab === "banking" && (
        <form onSubmit={handleSaveBankingSettings} className="space-y-6">
          {bankLogoUploadError && (
            <div className="p-3.5 bg-red-950/40 border border-red-800/60 rounded-sm text-red-200 text-xs font-sans flex items-center justify-between">
              <span>⚠️ {bankLogoUploadError}</span>
              <button
                type="button"
                onClick={() => setBankLogoUploadError("")}
                className="text-red-400 hover:text-white"
              >
                ✕
              </button>
            </div>
          )}

          {/* Section Action Banner */}
          <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-5 rounded-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-sans text-base text-white font-semibold tracking-tight">
                Bank Account &amp; Wire Instructions
              </h3>
              <p className="text-xs text-[#8C867D] font-sans mt-0.5">
                Bank transfer details displayed to clients at checkout and on invoices.
              </p>
            </div>
            <button
              type="submit"
              disabled={isSavingCMS || isUploadingBankLogo}
              className="w-full sm:w-auto min-w-[145px] px-5 py-2.5 bg-[#C5A880] hover:bg-[#E0CFA9] disabled:bg-[#44382B] disabled:cursor-not-allowed text-[#0D0D11] text-xs uppercase font-sans font-semibold tracking-wider rounded-sm transition-colors shadow-md flex items-center justify-center gap-2 cursor-pointer shrink-0 select-none whitespace-nowrap"
            >
              {isSavingCMS ? "Saving..." : "Save Changes"}
            </button>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
            {/* Left: Configuration Inputs */}
            <div className="xl:col-span-7 space-y-6">
              {/* Card 1: Bank Account Details */}
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-5">
                <div className="flex items-center justify-between border-b border-[#24242C] pb-3">
                  <div>
                    <h3 className="font-sans text-base text-white font-semibold tracking-tight">
                      Bank Account for Customer Payments
                    </h3>
                    <p className="text-[11px] text-[#8C867D] font-sans mt-0.5">
                      These details are shown to customers when they choose Bank Transfer at checkout.
                    </p>
                  </div>
                  <span className="px-2.5 py-0.5 bg-[#1F1E26] text-[#C5A880] text-[10px] uppercase tracking-wider font-mono rounded">
                    Bank Transfer
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-sans">
                  {/* Bank Legal Name */}
                  <div className="sm:col-span-2">
                    <label className="block text-[#C5A880] uppercase text-[10px] font-mono tracking-wider mb-1.5">
                      Bank Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={bankName}
                      onChange={(e) => setBankName(e.target.value)}
                      placeholder={`e.g. ${SITE_CONFIG.banking.bankName}`}
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] font-sans rounded-sm transition-colors text-sm"
                    />
                    <p className="text-[10px] text-[#8C867D] mt-1">
                      Official bank name shown to customers at checkout.
                    </p>
                  </div>

                  {/* Bank Short Name / Badge */}
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] font-mono tracking-wider mb-1.5">
                      Short Bank Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={bankShortName}
                      onChange={(e) => setBankShortName(e.target.value)}
                      placeholder={`e.g. ${SITE_CONFIG.banking.bankShortName}`}
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] font-sans rounded-sm transition-colors"
                    />
                    <p className="text-[10px] text-[#8C867D] mt-1">
                      Short name displayed on the payment option badge.
                    </p>
                  </div>

                  {/* Branch Name */}
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] font-mono tracking-wider mb-1.5">
                      Branch Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={branchName}
                      onChange={(e) => setBranchName(e.target.value)}
                      placeholder={`e.g. ${SITE_CONFIG.banking.branchName}`}
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] font-sans rounded-sm transition-colors"
                    />
                    <p className="text-[10px] text-[#8C867D] mt-1">
                      Branch where the account is held.
                    </p>
                  </div>

                  {/* Account Name */}
                  <div className="sm:col-span-2">
                    <label className="block text-[#C5A880] uppercase text-[10px] font-mono tracking-wider mb-1.5">
                      Account Holder Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={accountName}
                      onChange={(e) => setAccountName(e.target.value)}
                      placeholder={`e.g. ${SITE_CONFIG.banking.accountName}`}
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] font-sans rounded-sm transition-colors text-sm"
                    />
                    <p className="text-[10px] text-[#8C867D] mt-1">
                      Account name that customers should send money to.
                    </p>
                  </div>

                  {/* Account Number */}
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] font-mono tracking-wider mb-1.5">
                      Account Number *
                    </label>
                    <input
                      type="text"
                      required
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value)}
                      placeholder={`e.g. ${SITE_CONFIG.banking.accountNumber}`}
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] font-mono rounded-sm transition-colors text-sm tracking-wider"
                    />
                    <p className="text-[10px] text-[#8C867D] mt-1">
                      Bank account number where customers send payment.
                    </p>
                  </div>
                </div>
              </div>

              {/* Card 2: Bank Branding & Logo */}
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-5">
                <div className="border-b border-[#24242C] pb-3">
                  <h3 className="font-sans text-base text-white font-semibold tracking-tight">
                    Bank Logo Image
                  </h3>
                  <p className="text-[11px] text-[#8C867D] font-sans mt-0.5">
                    Visual badge image displayed on the bank transfer card.
                  </p>
                </div>

                <div className="space-y-4 text-xs font-sans">
                  {/* Bank Logo Picker */}
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] font-mono tracking-wider mb-2">
                      Bank Logo Image
                    </label>
                    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                      {/* Logo Preview Container */}
                      <div className="w-24 h-12 bg-white rounded p-1 border border-white/20 flex items-center justify-center shrink-0 shadow-sm relative overflow-hidden">
                        {bankLogo ? (
                          <Image
                            src={bankLogo}
                            alt="Bank Logo"
                            width={90}
                            height={40}
                            className="max-h-full max-w-full object-contain"
                            unoptimized
                          />
                        ) : (
                          <span className="text-[9px] text-[#8C867D] uppercase font-mono">No Logo</span>
                        )}
                      </div>

                      <div className="flex-1 w-full space-y-2">
                        <div className="flex flex-wrap items-center gap-2">
                          <label className="px-3.5 py-1.5 bg-[#24242C] hover:bg-[#2F2F3A] text-white text-[11px] uppercase font-mono tracking-wider rounded-sm cursor-pointer border border-[#3A3A46] transition-colors shrink-0">
                            {isUploadingBankLogo ? "Uploading..." : "Upload Logo"}
                            <input
                              type="file"
                              accept="image/png,image/jpeg,image/webp,image/svg+xml"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) handleUploadBankLogo(file);
                              }}
                              disabled={isUploadingBankLogo}
                              className="hidden"
                            />
                          </label>
                          {bankLogo && (
                            <button
                              type="button"
                              onClick={() => setBankLogo("")}
                              className="px-3 py-1.5 bg-red-950/40 hover:bg-red-900/60 text-red-300 text-[11px] uppercase font-mono tracking-wider rounded-sm border border-red-800/40 transition-colors cursor-pointer"
                            >
                              Remove Logo
                            </button>
                          )}
                          <span className="text-[10px] text-[#8C867D]">PNG, SVG, or WEBP with transparent or white background.</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Live Customer Checkout Simulation */}
            <div className="xl:col-span-5 space-y-6">
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-4 xl:sticky xl:top-6">
                <div className="flex items-center justify-between border-b border-[#24242C] pb-3">
                  <div>
                    <h3 className="font-sans text-base text-white font-semibold tracking-tight">
                      Checkout Preview
                    </h3>
                    <p className="text-[11px] text-[#8C867D] font-sans mt-0.5">
                      How customers see your bank details during checkout
                    </p>
                  </div>
                  <span className="px-2 py-0.5 bg-emerald-950/60 border border-emerald-700/60 text-emerald-400 text-[10px] font-mono rounded uppercase">
                    Live Preview
                  </span>
                </div>

                {/* Customer Payment Card Preview */}
                <div className="p-4 sm:p-5 bg-gradient-to-br from-[#1F1E26] via-[#141419] to-[#0D0D11] border border-[#C5A880]/30 rounded-sm shadow-xl space-y-4 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-[#C5A880]/5 rounded-full blur-2xl pointer-events-none" />

                  {/* Header Row */}
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-3 relative z-10">
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-widest text-[#C5A880] block">
                        Direct Bank Transfer
                      </span>
                      <h4 className="font-sans text-sm sm:text-base text-white font-semibold">
                        Faizan Gems Bank Account
                      </h4>
                    </div>

                    {/* Bank Badge */}
                    <div className="flex items-center gap-2 bg-white px-2.5 py-1 rounded shadow-sm shrink-0">
                      {bankLogo && (
                        <div className="relative h-5 w-10 flex-shrink-0">
                          <Image
                            src={bankLogo}
                            alt={bankName || "Bank Logo"}
                            fill
                            className="object-contain"
                            unoptimized
                          />
                        </div>
                      )}
                      <span className="text-[10px] uppercase tracking-wider font-mono text-[#18181D] font-bold border-l border-gray-200 pl-2">
                        {bankShortName || "Bank"}
                      </span>
                    </div>
                  </div>

                  {/* Copy Helper & Copy All Button */}
                  <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-[#A69E92] relative z-10">
                    <span>Use the details below to complete your transfer:</span>
                    <button
                      type="button"
                      onClick={() => {
                        const details = [
                          "FAIZAN GEMS - BANK TRANSFER DETAILS",
                          `Bank Name: ${bankName}`,
                          `Branch: ${branchName}`,
                          `Account Name: ${accountName}`,
                          `Account Number: ${accountNumber}`,
                        ].join("\n");
                        handleCopyPreviewText(details, "all");
                      }}
                      className="text-[10px] font-mono uppercase tracking-wider px-2.5 py-1 bg-white/10 hover:bg-white/20 text-[#DFC9A9] hover:text-white rounded border border-white/15 transition-colors duration-150 flex items-center gap-1.5 cursor-pointer"
                    >
                      {previewCopiedKey === "all" ? (
                        <>
                          <CheckIcon className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-300 font-bold">All Details Copied!</span>
                        </>
                      ) : (
                        <>
                          <CopyIcon className="w-3.5 h-3.5 text-[#C5A880]" />
                          <span>Copy All Details</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Detail Rows */}
                  <div className="space-y-2 relative z-10 text-xs">
                    {/* Bank Name Row */}
                    <div className="p-2.5 bg-white/[0.04] border border-white/10 rounded flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <span className="text-[9px] uppercase font-mono tracking-widest text-[#A69E92] block">
                          Bank Name
                        </span>
                        <span className="text-xs sm:text-sm font-medium text-white block truncate select-all">
                          {bankName || "—"}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleCopyPreviewText(bankName, "bankName")}
                        className="px-2 py-1 text-[10px] font-mono rounded bg-white/10 hover:bg-white/20 text-[#DFC9A9] hover:text-white flex items-center gap-1 shrink-0 transition-colors duration-150 cursor-pointer"
                      >
                        {previewCopiedKey === "bankName" ? (
                          <span className="text-emerald-300">Copied</span>
                        ) : (
                          <>
                            <CopyIcon className="w-3 h-3 text-[#C5A880]" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* Branch Row */}
                    <div className="p-2.5 bg-white/[0.04] border border-white/10 rounded flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <span className="text-[9px] uppercase font-mono tracking-widest text-[#A69E92] block">
                          Branch
                        </span>
                        <span className="text-xs sm:text-sm font-medium text-white block truncate select-all">
                          {branchName || "—"}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleCopyPreviewText(branchName, "branch")}
                        className="px-2 py-1 text-[10px] font-mono rounded bg-white/10 hover:bg-white/20 text-[#DFC9A9] hover:text-white flex items-center gap-1 shrink-0 transition-colors duration-150 cursor-pointer"
                      >
                        {previewCopiedKey === "branch" ? (
                          <span className="text-emerald-300">Copied</span>
                        ) : (
                          <>
                            <CopyIcon className="w-3 h-3 text-[#C5A880]" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* Account Name Row */}
                    <div className="p-2.5 bg-white/[0.04] border border-white/10 rounded flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <span className="text-[9px] uppercase font-mono tracking-widest text-[#A69E92] block">
                          Account Name
                        </span>
                        <span className="text-xs sm:text-sm font-medium text-white block truncate select-all">
                          {accountName || "—"}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleCopyPreviewText(accountName, "accountName")}
                        className="px-2 py-1 text-[10px] font-mono rounded bg-white/10 hover:bg-white/20 text-[#DFC9A9] hover:text-white flex items-center gap-1 shrink-0 transition-colors duration-150 cursor-pointer"
                      >
                        {previewCopiedKey === "accountName" ? (
                          <span className="text-emerald-300">Copied</span>
                        ) : (
                          <>
                            <CopyIcon className="w-3 h-3 text-[#C5A880]" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* Account Number Row (Highlighted) */}
                    <div className="p-3 bg-gradient-to-r from-[#C5A880]/20 via-[#C5A880]/10 to-transparent border border-[#C5A880]/40 rounded flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <span className="text-[9px] uppercase font-mono tracking-widest text-[#DFC9A9] block font-semibold">
                          Account Number
                        </span>
                        <span className="font-mono text-sm sm:text-base font-bold text-white tracking-widest block truncate select-all">
                          {accountNumber ? accountNumber.replace(/\s+/g, "").replace(/(\d{4})(?=\d)/g, "$1 ") : "—"}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleCopyPreviewText(accountNumber.replace(/\s+/g, ""), "accountNumber")}
                        className="px-3 py-1.5 bg-[#C5A880] hover:bg-[#B3956D] text-[#18181D] font-medium text-xs font-sans rounded flex items-center gap-1.5 transition-colors duration-150 shrink-0 cursor-pointer shadow-sm"
                      >
                        {previewCopiedKey === "accountNumber" ? (
                          <span className="font-bold">Copied!</span>
                        ) : (
                          <>
                            <CopyIcon className="w-3.5 h-3.5 text-[#18181D]" />
                            <span className="font-semibold">Copy</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-[#1A1A22] border border-[#24242C] rounded text-[11px] text-[#8C867D] font-sans space-y-1">
                  <span className="text-[#C5A880] font-mono uppercase text-[10px] block">⚡ Live Updates</span>
                  <p>
                    Changes made here are saved immediately and updated on the checkout page.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <button type="submit" className="hidden" aria-hidden="true" tabIndex={-1} />
        </form>
      )}

      {/* SUBTAB 1: HOMEPAGE (ALL 8 SECTIONS) */}
      {cmsSubTab === "hero" && (
        <div className="space-y-6">
          {/* Top Control & Notification Bar */}
          <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-5 rounded-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-sans text-base text-white font-semibold tracking-tight">
                  Homepage CMS &amp; Live Section Editor
                </h3>
              </div>
              <p className="text-xs text-[#8C867D] font-sans mt-0.5">
                Every section of the homepage is fully editable here. Changes save directly to MySQL and immediately update the public storefront.
              </p>
            </div>

            <div className="w-full md:w-auto flex items-center gap-2 sm:gap-3">
              <button
                type="button"
                onClick={handleSaveHeroSettings}
                disabled={isSavingCMS || isUploadingHeroImage || isUploadingLoupeImage || isUploadingStoryImage}
                className="w-full md:w-auto min-w-[145px] px-5 py-2.5 bg-[#C5A880] hover:bg-[#E0CFA9] disabled:bg-[#44382B] disabled:cursor-not-allowed text-[#0D0D11] text-xs uppercase font-sans font-semibold tracking-wider rounded-sm transition-colors shadow-md flex items-center justify-center gap-2 cursor-pointer shrink-0 select-none whitespace-nowrap"
              >
                {isSavingCMS ? (
                  <>
                    <span className="animate-spin text-sm">↻</span>
                    <span>Saving...</span>
                  </>
                ) : (
                  <span>Save Changes</span>
                )}
              </button>
            </div>
          </div>

          {/* Mobile Homepage Section Select */}
          <div className="md:hidden relative z-20 pb-1">
            <label className="block text-[10px] font-mono uppercase tracking-wider text-[#8C867D] mb-1.5 select-none">
              Jump to Homepage Section:
            </label>
            <LuxurySelect
              variant="dark"
              size="sm"
              value={homepageActiveSection}
              onChange={(val) => setHomepageActiveSection(val as typeof homepageActiveSection)}
              options={[
                { value: "all", label: "All Sections" },
                { value: "hero", label: "1. Hero Banner" },
                { value: "metrics", label: "2. Metrics Strip" },
                { value: "trust", label: "3. Trust & Guarantees" },
                { value: "collections", label: "4. Collections" },
                { value: "vault", label: "5. Gemstones Vault" },
                { value: "loupe", label: "6. Loupe Magnifier" },
                { value: "story", label: "7. Brand Story" },
                { value: "consultation", label: "8. Consultation CTA" },
              ]}
            />
          </div>

          {/* Desktop Section Navigation Tabs */}
          <div className="hidden md:flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-thin text-xs font-sans border-b border-[#24242C]">
            {[
              { id: "all" as const, label: "All Sections" },
              { id: "hero" as const, label: "1. Hero Banner" },
              { id: "metrics" as const, label: "2. Metrics Strip" },
              { id: "trust" as const, label: "3. Trust & Guarantees" },
              { id: "collections" as const, label: "4. Collections" },
              { id: "vault" as const, label: "5. Gemstones Vault" },
              { id: "loupe" as const, label: "6. Loupe Magnifier" },
              { id: "story" as const, label: "7. Brand Story" },
              { id: "consultation" as const, label: "8. Consultation CTA" },
            ].map((sec) => (
              <button
                key={sec.id}
                type="button"
                onClick={() => setHomepageActiveSection(sec.id)}
                className={`px-3 py-1.5 rounded-sm whitespace-nowrap transition-colors duration-150 ${
                  homepageActiveSection === sec.id
                    ? "bg-[#C5A880] text-[#0D0D11] font-semibold shadow-sm"
                    : "bg-[#16161D] text-[#8C867D] hover:text-white hover:bg-[#1E1E26] border border-[#24242C]"
                }`}
              >
                {sec.label}
              </button>
            ))}
          </div>

          <form onSubmit={handleSaveHeroSettings} noValidate className="space-y-8">
            {/* 1. HERO BANNER SECTION */}
            {(homepageActiveSection === "all" || homepageActiveSection === "hero") && (
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-6">
                <div className="flex items-center justify-between border-b border-[#24242C] pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 text-[10px] font-mono bg-[#1E1E28] border border-[#C5A880]/30 text-[#C5A880] rounded">
                        Section 1
                      </span>
                      <h4 className="font-sans text-base text-white font-semibold tracking-tight">Cinematic Hero Banner</h4>
                    </div>
                    <p className="text-xs text-[#8C867D] font-sans mt-0.5">
                      The primary entrance of the storefront: headline, description, call-to-actions, and high-resolution background.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Left Column: Form inputs */}
                  <div className="lg:col-span-7 space-y-4 text-xs font-sans">
                    <div>
                      <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                        Small Eyebrow / Badge Text
                      </label>
                      <input
                        type="text"
                        value={heroEyebrow}
                        onChange={(e) => setHeroEyebrow(e.target.value)}
                        placeholder="Natural Gemstones • Certified by GIA & Swiss Labs"
                        className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                      />
                    </div>

                    <div>
                      <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                        Main Headline Title
                      </label>
                      <input
                        type="text"
                        value={heroHeadline}
                        onChange={(e) => setHeroHeadline(e.target.value)}
                        placeholder="Discover Nature's Rarest Gemstones"
                        className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                      />
                    </div>

                    <div>
                      <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                        Subtitle / Introductory Description
                      </label>
                      <textarea
                        rows={3}
                        value={heroSubheadline}
                        onChange={(e) => setHeroSubheadline(e.target.value)}
                        placeholder="Handpicked natural sapphires, rubies, emeralds, and rare gems..."
                        className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                          Primary Button Text
                        </label>
                        <input
                          type="text"
                          value={heroCtaPrimaryText}
                          onChange={(e) => setHeroCtaPrimaryText(e.target.value)}
                          placeholder="Browse All Gemstones"
                          className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                          Primary Button Link
                        </label>
                        <input
                          type="text"
                          value={heroCtaPrimaryLink}
                          onChange={(e) => setHeroCtaPrimaryLink(e.target.value)}
                          placeholder="/shop"
                          className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                          Secondary Button Text
                        </label>
                        <input
                          type="text"
                          value={heroCtaSecondaryText}
                          onChange={(e) => setHeroCtaSecondaryText(e.target.value)}
                          placeholder="Premium Collection"
                          className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                          Secondary Button Link
                        </label>
                        <input
                          type="text"
                          value={heroCtaSecondaryLink}
                          onChange={(e) => setHeroCtaSecondaryLink(e.target.value)}
                          placeholder="/collections/collectors-vault"
                          className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Hero Image Suite & Live Preview */}
                  <div className="lg:col-span-5 space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <label className="block text-[#C5A880] uppercase text-[10px] font-mono tracking-wider font-semibold">
                          Hero Background Photo
                        </label>
                        <span className="text-[10px] text-[#8C867D]">
                          1920 × 1080 px recommended
                        </span>
                      </div>

                      {heroImageUploadError && (
                        <div className="p-2.5 bg-red-900/30 border border-red-500/50 text-red-200 text-xs rounded-sm flex items-center justify-between">
                          <span>{heroImageUploadError}</span>
                          <button
                            type="button"
                            onClick={() => setHeroImageUploadError("")}
                            className="text-red-400 hover:text-white text-xs ml-2 font-mono"
                          >
                            ✕
                          </button>
                        </div>
                      )}

                      {/* Dropzone */}
                      <div className="relative border-2 border-dashed border-[#2E2E3C] hover:border-[#C5A880] transition-colors rounded-sm p-4 text-center bg-[#17171F] group">
                        <input
                          type="file"
                          accept="image/jpeg,image/png,image/webp,image/avif"
                          disabled={isUploadingHeroImage}
                          onChange={(e) => {
                            const f = e.target.files?.[0];
                            if (f) handleHeroImageUpload(f);
                            e.target.value = "";
                          }}
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed z-10"
                        />
                        <div className="space-y-1 pointer-events-none">
                          <div className="w-10 h-10 rounded-full bg-[#1F1E28] border border-[#C5A880]/30 text-[#C5A880] flex items-center justify-center mx-auto text-lg group-hover:scale-105 transition-transform">
                            {isUploadingHeroImage ? "⏳" : "⬆"}
                          </div>
                          <p className="text-xs text-white font-medium">
                            {isUploadingHeroImage ? "Uploading Photo..." : "Click or drag & drop banner photo"}
                          </p>
                          <p className="text-[10px] text-[#8C867D]">JPG, PNG, WEBP • Max 25MB</p>
                        </div>
                      </div>

                      {/* URL Override */}
                      <details className="text-[11px] text-[#8C867D] group/details pt-1">
                        <summary className="cursor-pointer text-[#C5A880] hover:underline font-mono text-[10px] uppercase tracking-wider select-none">
                          + Or paste direct image URL
                        </summary>
                        <div className="mt-2 space-y-1">
                          <input
                            type="text"
                            value={heroImage}
                            onChange={(e) => setHeroImage(e.target.value)}
                            placeholder="https://..."
                            className="w-full p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs font-mono focus:outline-none focus:border-[#C5A880]"
                          />
                        </div>
                      </details>

                      {/* Live Mini Preview */}
                      <div className="relative rounded overflow-hidden p-5 text-center border border-[#2A2A36] min-h-[200px] flex flex-col justify-center items-center bg-[#0D0D11]">
                        <div
                          className="absolute inset-0 bg-cover bg-center opacity-30"
                          style={{ backgroundImage: `url(${heroImage})` }}
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D11] to-transparent" />
                        <div className="relative z-10 space-y-2">
                          <span className="inline-block px-2 py-0.5 rounded-full bg-white/10 text-[#C5A880] text-[8px] uppercase tracking-wider border border-[#C5A880]/30">
                            {heroEyebrow}
                          </span>
                          <h5 className="font-serif text-base text-white font-light leading-tight">
                            {heroHeadline}
                          </h5>
                          <p className="text-[10px] text-[#C5C0B6] line-clamp-2 max-w-xs mx-auto">
                            {heroSubheadline}
                          </p>
                          <div className="pt-1 flex justify-center gap-1.5">
                            <span className="px-2.5 py-1 bg-[#C5A880] text-[#0D0D11] text-[8px] font-semibold uppercase tracking-wider">
                              {heroCtaPrimaryText}
                            </span>
                            <span className="px-2.5 py-1 border border-[#C5A880] text-[#C5A880] text-[8px] uppercase tracking-wider">
                              {heroCtaSecondaryText}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 2. QUICK METRICS STRIP */}
            {(homepageActiveSection === "all" || homepageActiveSection === "metrics") && (
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-5">
                <div className="flex items-center justify-between border-b border-[#24242C] pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 text-[10px] font-mono bg-[#1E1E28] border border-[#C5A880]/30 text-[#C5A880] rounded">
                        Section 2
                      </span>
                      <h4 className="font-sans text-base text-white font-semibold tracking-tight">Hero Quick Metrics (4 Stat Counters)</h4>
                    </div>
                    <p className="text-xs text-[#8C867D] font-sans mt-0.5">
                      The four assurance counters displayed directly beneath the hero headline.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs font-sans">
                  {/* Metric 1 */}
                  <div className="p-3.5 bg-[#1C1C24] border border-[#2A2A36] rounded-sm space-y-2">
                    <span className="text-[10px] font-mono uppercase text-[#C5A880] block">Metric 1</span>
                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1">Value / Figure</label>
                      <input
                        type="text"
                        value={metric1Val}
                        onChange={(e) => setMetric1Val(e.target.value)}
                        placeholder="100%"
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-[#C5A880] font-mono tabular-nums text-sm focus:outline-none focus:border-[#C5A880]"
                      />
                    </div>
                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1">Label / Title</label>
                      <input
                        type="text"
                        value={metric1Lbl}
                        onChange={(e) => setMetric1Lbl(e.target.value)}
                        placeholder="Certified Natural"
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white"
                      />
                    </div>
                  </div>

                  {/* Metric 2 */}
                  <div className="p-3.5 bg-[#1C1C24] border border-[#2A2A36] rounded-sm space-y-2">
                    <span className="text-[10px] font-mono uppercase text-[#C5A880] block">Metric 2</span>
                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1">Value / Figure</label>
                      <input
                        type="text"
                        value={metric2Val}
                        onChange={(e) => setMetric2Val(e.target.value)}
                        placeholder="GIA & GRS"
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-[#C5A880] font-mono tabular-nums text-sm focus:outline-none focus:border-[#C5A880]"
                      />
                    </div>
                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1">Label / Title</label>
                      <input
                        type="text"
                        value={metric2Lbl}
                        onChange={(e) => setMetric2Lbl(e.target.value)}
                        placeholder="Independent Reports"
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white"
                      />
                    </div>
                  </div>

                  {/* Metric 3 */}
                  <div className="p-3.5 bg-[#1C1C24] border border-[#2A2A36] rounded-sm space-y-2">
                    <span className="text-[10px] font-mono uppercase text-[#C5A880] block">Metric 3</span>
                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1">Value / Figure</label>
                      <input
                        type="text"
                        value={metric3Val}
                        onChange={(e) => setMetric3Val(e.target.value)}
                        placeholder="Armored"
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-[#C5A880] font-mono tabular-nums text-sm focus:outline-none focus:border-[#C5A880]"
                      />
                    </div>
                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1">Label / Title</label>
                      <input
                        type="text"
                        value={metric3Lbl}
                        onChange={(e) => setMetric3Lbl(e.target.value)}
                        placeholder="Worldwide Courier"
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white"
                      />
                    </div>
                  </div>

                  {/* Metric 4 */}
                  <div className="p-3.5 bg-[#1C1C24] border border-[#2A2A36] rounded-sm space-y-2">
                    <span className="text-[10px] font-mono uppercase text-[#C5A880] block">Metric 4</span>
                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1">Value / Figure</label>
                      <input
                        type="text"
                        value={metric4Val}
                        onChange={(e) => setMetric4Val(e.target.value)}
                        placeholder="30 Days"
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-[#C5A880] font-mono tabular-nums text-sm focus:outline-none focus:border-[#C5A880]"
                      />
                    </div>
                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1">Label / Title</label>
                      <input
                        type="text"
                        value={metric4Lbl}
                        onChange={(e) => setMetric4Lbl(e.target.value)}
                        placeholder="Inspection Period"
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 3. TRUST & ASSURANCE STRIP */}
            {(homepageActiveSection === "all" || homepageActiveSection === "trust") && (
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-5">
                <div className="flex items-center justify-between border-b border-[#24242C] pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 text-[10px] font-mono bg-[#1E1E28] border border-[#C5A880]/30 text-[#C5A880] rounded">
                        Section 3
                      </span>
                      <h4 className="font-sans text-base text-white font-semibold tracking-tight">Trust &amp; Assurance Guarantees Strip</h4>
                    </div>
                    <p className="text-xs text-[#8C867D] font-sans mt-0.5">
                      The trust bar displayed immediately below the hero, reassuring high-value gemstone buyers.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs font-sans">
                  <div className="p-4 bg-[#1C1C24] border border-[#2A2A36] rounded-sm space-y-3">
                    <span className="text-[10px] font-mono uppercase text-[#C5A880] block">Trust Card 1</span>
                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1">Card Title</label>
                      <input
                        type="text"
                        value={trust1Title}
                        onChange={(e) => setTrust1Title(e.target.value)}
                        placeholder="Independently Certified Labs"
                        className="w-full p-2.5 bg-[#141419] border border-[#2A2A36] text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1">Card Description</label>
                      <input
                        type="text"
                        value={trust1Desc}
                        onChange={(e) => setTrust1Desc(e.target.value)}
                        placeholder="GIA, Gübelin, SSEF & GRS lab reports you can verify online"
                        className="w-full p-2.5 bg-[#141419] border border-[#2A2A36] text-white"
                      />
                    </div>
                  </div>

                  <div className="p-4 bg-[#1C1C24] border border-[#2A2A36] rounded-sm space-y-3">
                    <span className="text-[10px] font-mono uppercase text-[#C5A880] block">Trust Card 2</span>
                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1">Card Title</label>
                      <input
                        type="text"
                        value={trust2Title}
                        onChange={(e) => setTrust2Title(e.target.value)}
                        placeholder="30-Day Money-Back Guarantee"
                        className="w-full p-2.5 bg-[#141419] border border-[#2A2A36] text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1">Card Description</label>
                      <input
                        type="text"
                        value={trust2Desc}
                        onChange={(e) => setTrust2Desc(e.target.value)}
                        placeholder="Not satisfied? Return within 30 days for a full refund — no questions asked"
                        className="w-full p-2.5 bg-[#141419] border border-[#2A2A36] text-white"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 4. FEATURED EDITORIAL COLLECTIONS */}
            {(homepageActiveSection === "all" || homepageActiveSection === "collections") && (
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-5">
                <div className="flex items-center justify-between border-b border-[#24242C] pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 text-[10px] font-mono bg-[#1E1E28] border border-[#C5A880]/30 text-[#C5A880] rounded">
                        Section 4
                      </span>
                      <h4 className="font-sans text-base text-white font-semibold tracking-tight">Featured Collections Header</h4>
                    </div>
                    <p className="text-xs text-[#8C867D] font-sans mt-0.5">
                      Header text introducing the curated gemstone collection showcases.
                    </p>
                  </div>
                </div>

                <div className="space-y-4 text-xs font-sans">
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Category Eyebrow Text
                    </label>
                    <input
                      type="text"
                      value={collectionsEyebrow}
                      onChange={(e) => setCollectionsEyebrow(e.target.value)}
                      placeholder="Our Collections"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                    />
                  </div>

                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Main Section Headline
                    </label>
                    <input
                      type="text"
                      value={collectionsHeadline}
                      onChange={(e) => setCollectionsHeadline(e.target.value)}
                      placeholder="Explore Our Gemstone Collections"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                    />
                  </div>

                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Section Description Paragraph
                    </label>
                    <textarea
                      rows={2}
                      value={collectionsSubheadline}
                      onChange={(e) => setCollectionsSubheadline(e.target.value)}
                      placeholder="Browse collections of the world's finest natural gemstones..."
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                    />
                  </div>

                  <div className="p-3 bg-[#1A1A22] border border-[#24242C] rounded text-[11px] text-[#8C867D] font-sans flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[#C5A880]">ℹ</span>
                      <span>Featured collection cards (images &amp; names) can be customized and selected in the Collections Page CMS.</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setCmsSubTab("collections")}
                      className="text-[#C5A880] hover:text-[#E0CFA9] underline text-xs font-medium self-start sm:self-auto flex-shrink-0"
                    >
                      Manage Collection Cards →
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 5. FEATURED GEMSTONES VAULT (PRODUCT GRID) */}
            {(homepageActiveSection === "all" || homepageActiveSection === "vault") && (
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-5">
                <div className="flex items-center justify-between border-b border-[#24242C] pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 text-[10px] font-mono bg-[#1E1E28] border border-[#C5A880]/30 text-[#C5A880] rounded">
                        Section 5
                      </span>
                      <h4 className="font-sans text-base text-white font-semibold tracking-tight">Featured Gemstones Vault</h4>
                    </div>
                    <p className="text-xs text-[#8C867D] font-sans mt-0.5">
                      Header and call-to-action for the live gemstones showcase grid.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-sans">
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Badge / Eyebrow Text
                    </label>
                    <input
                      type="text"
                      value={vaultEyebrow}
                      onChange={(e) => setVaultEyebrow(e.target.value)}
                      placeholder="New Arrivals"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      CTA Button Text
                    </label>
                    <input
                      type="text"
                      value={vaultCtaText}
                      onChange={(e) => setVaultCtaText(e.target.value)}
                      placeholder="View All Gemstones"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Main Section Headline
                    </label>
                    <input
                      type="text"
                      value={vaultHeadline}
                      onChange={(e) => setVaultHeadline(e.target.value)}
                      placeholder="Certified Natural Gemstones"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Vault Description
                    </label>
                    <textarea
                      rows={2}
                      value={vaultSubheadline}
                      onChange={(e) => setVaultSubheadline(e.target.value)}
                      placeholder="One-of-a-kind natural gemstones, each with an official lab certificate..."
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 6. INTERACTIVE LOUPE MAGNIFICATION SHOWCASE */}
            {(homepageActiveSection === "all" || homepageActiveSection === "loupe") && (
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-6">
                <div className="flex items-center justify-between border-b border-[#24242C] pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 text-[10px] font-mono bg-[#1E1E28] border border-[#C5A880]/30 text-[#C5A880] rounded">
                        Section 6
                      </span>
                      <h4 className="font-sans text-base text-white font-semibold tracking-tight">Interactive Loupe &amp; Magnifier Showcase</h4>
                    </div>
                    <p className="text-xs text-[#8C867D] font-sans mt-0.5">
                      Highlights online gem inspection capabilities with 3 key feature points and high-res macro imagery.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-xs font-sans">
                  {/* Left Column: Loupe Copy & 3 Features */}
                  <div className="lg:col-span-7 space-y-4">
                    <div>
                      <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                        Eyebrow Label
                      </label>
                      <input
                        type="text"
                        value={loupeEyebrow}
                        onChange={(e) => setLoupeEyebrow(e.target.value)}
                        placeholder="See Every Detail Online"
                        className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                        Main Headline
                      </label>
                      <input
                        type="text"
                        value={loupeHeadline}
                        onChange={(e) => setLoupeHeadline(e.target.value)}
                        placeholder="Zoom In & Inspect Every Gemstone Up Close"
                        className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                        Introductory Subtitle
                      </label>
                      <textarea
                        rows={2}
                        value={loupeSubheadline}
                        onChange={(e) => setLoupeSubheadline(e.target.value)}
                        placeholder="Can't visit in person? No problem. Our high-resolution viewer..."
                        className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                      />
                    </div>

                    {/* 3 Features */}
                    <div className="space-y-3 pt-2 border-t border-[#24242C]">
                      <span className="text-[10px] font-mono uppercase text-[#C5A880] block font-semibold">
                        Showcase Feature Bullets
                      </span>

                      {/* Feature 1 */}
                      <div className="p-3 bg-[#1C1C24] border border-[#2A2A36] rounded space-y-2">
                        <span className="text-[10px] text-[#A29F96] font-mono">Feature 1</span>
                        <input
                          type="text"
                          value={loupeFeat1Title}
                          onChange={(e) => setLoupeFeat1Title(e.target.value)}
                          placeholder="10x Zoom Magnification"
                          className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white"
                        />
                        <input
                          type="text"
                          value={loupeFeat1Desc}
                          onChange={(e) => setLoupeFeat1Desc(e.target.value)}
                          placeholder="See the natural details and clarity of each stone up close."
                          className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white text-[11px]"
                        />
                      </div>

                      {/* Feature 2 */}
                      <div className="p-3 bg-[#1C1C24] border border-[#2A2A36] rounded space-y-2">
                        <span className="text-[10px] text-[#A29F96] font-mono">Feature 2</span>
                        <input
                          type="text"
                          value={loupeFeat2Title}
                          onChange={(e) => setLoupeFeat2Title(e.target.value)}
                          placeholder="Detailed Photo Gallery"
                          className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white"
                        />
                        <input
                          type="text"
                          value={loupeFeat2Desc}
                          onChange={(e) => setLoupeFeat2Desc(e.target.value)}
                          placeholder="View the cut quality, light performance, and sparkle from every angle."
                          className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white text-[11px]"
                        />
                      </div>

                      {/* Feature 3 */}
                      <div className="p-3 bg-[#1C1C24] border border-[#2A2A36] rounded space-y-2">
                        <span className="text-[10px] text-[#A29F96] font-mono">Feature 3</span>
                        <input
                          type="text"
                          value={loupeFeat3Title}
                          onChange={(e) => setLoupeFeat3Title(e.target.value)}
                          placeholder="Lab Certificate Included"
                          className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white"
                        />
                        <input
                          type="text"
                          value={loupeFeat3Desc}
                          onChange={(e) => setLoupeFeat3Desc(e.target.value)}
                          placeholder="Every gemstone comes with its original lab report and certificate."
                          className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white text-[11px]"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                      <div>
                        <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                          Button Text
                        </label>
                        <input
                          type="text"
                          value={loupeCtaText}
                          onChange={(e) => setLoupeCtaText(e.target.value)}
                          placeholder="View a Gemstone Up Close →"
                          className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                          Button Link
                        </label>
                        <input
                          type="text"
                          value={loupeCtaLink}
                          onChange={(e) => setLoupeCtaLink(e.target.value)}
                          placeholder="/shop"
                          className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Loupe Image & Caption */}
                  <div className="lg:col-span-5 space-y-4">
                    <span className="text-[10px] font-mono uppercase text-[#C5A880] block font-semibold">
                      Showcase Loupe Image
                    </span>

                    {loupeImageUploadError && (
                      <div className="p-2.5 bg-red-900/30 border border-red-500/50 text-red-200 text-xs rounded flex items-center justify-between">
                        <span>{loupeImageUploadError}</span>
                        <button
                          type="button"
                          onClick={() => setLoupeImageUploadError("")}
                          className="text-red-400 hover:text-white"
                        >
                          ✕
                        </button>
                      </div>
                    )}

                    {/* Image Preview Box */}
                    <div className="relative aspect-square w-full max-w-sm mx-auto rounded border border-[#C5A880]/30 overflow-hidden bg-black shadow-xl">
                      <Image
                        src={loupeImage}
                        alt="Loupe Showcase Preview"
                        fill
                        unoptimized={loupeImage.startsWith("/uploads")}
                        className="object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20 pointer-events-none" />
                      <div className="absolute bottom-4 inset-x-4 text-center">
                        <span className="inline-block px-2.5 py-1 bg-black/90 border border-[#C5A880] text-[#E0CFA9] text-[9px] font-mono tracking-wider uppercase">
                          {loupeImageCaption}
                        </span>
                      </div>
                    </div>

                    {/* Dropzone */}
                    <div className="relative border-2 border-dashed border-[#2E2E3C] hover:border-[#C5A880] transition-colors rounded-sm p-4 text-center bg-[#17171F] group">
                      <input
                        type="file"
                        accept="image/jpeg,image/png,image/webp,image/avif"
                        disabled={isUploadingLoupeImage}
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) handleLoupeImageUpload(f);
                          e.target.value = "";
                        }}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed z-10"
                      />
                      <div className="space-y-1 pointer-events-none">
                        <div className="w-9 h-9 rounded-full bg-[#1F1E28] border border-[#C5A880]/30 text-[#C5A880] flex items-center justify-center mx-auto text-base group-hover:scale-105 transition-transform">
                          {isUploadingLoupeImage ? "⏳" : "⬆"}
                        </div>
                        <p className="text-xs text-white font-medium">
                          {isUploadingLoupeImage ? "Uploading..." : "Click or drag & drop showcase photo"}
                        </p>
                        <p className="text-[10px] text-[#8C867D]">Square / 1:1 format recommended</p>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1 font-mono uppercase">
                        Image Caption Ribbon Text
                      </label>
                      <input
                        type="text"
                        value={loupeImageCaption}
                        onChange={(e) => setLoupeImageCaption(e.target.value)}
                        placeholder="ROYAL BLUE CEYLON SAPPHIRE • CLOSE-UP VIEW"
                        className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                      />
                    </div>

                    <details className="text-[11px] text-[#8C867D]">
                      <summary className="cursor-pointer text-[#C5A880] hover:underline font-mono text-[10px] uppercase tracking-wider">
                        + Or enter image URL directly
                      </summary>
                      <input
                        type="text"
                        value={loupeImage}
                        onChange={(e) => setLoupeImage(e.target.value)}
                        placeholder="https://..."
                        className="mt-2 w-full p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs font-mono"
                      />
                    </details>
                  </div>
                </div>
              </div>
            )}

            {/* 8. FAIZAN GEMS HERITAGE & ETHICAL SOURCING */}
            {(homepageActiveSection === "all" || homepageActiveSection === "story") && (
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-6">
                <div className="flex items-center justify-between border-b border-[#24242C] pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 text-[10px] font-mono bg-[#1E1E28] border border-[#C5A880]/30 text-[#C5A880] rounded">
                        Section 8
                      </span>
                      <h4 className="font-sans text-base text-white font-semibold tracking-tight">Brand Story &amp; Ethical Sourcing</h4>
                    </div>
                    <p className="text-xs text-[#8C867D] font-sans mt-0.5">
                      Highlights company heritage, direct-mine relationships, artisanal cutting, and ethical guarantees.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-xs font-sans">
                  {/* Left Column: Photo & Badges */}
                  <div className="lg:col-span-5 space-y-4">
                    <span className="text-[10px] font-mono uppercase text-[#C5A880] block font-semibold">
                      Story Showcase Image
                    </span>

                    {storyImageUploadError && (
                      <div className="p-2.5 bg-red-900/30 border border-red-500/50 text-red-200 text-xs rounded flex items-center justify-between">
                        <span>{storyImageUploadError}</span>
                        <button
                          type="button"
                          onClick={() => setStoryImageUploadError("")}
                          className="text-red-400 hover:text-white"
                        >
                          ✕
                        </button>
                      </div>
                    )}

                    <div className="relative aspect-[4/5] w-full max-w-sm mx-auto rounded border border-[#2A2A36] overflow-hidden bg-black shadow-xl">
                      <Image
                        src={storyImage}
                        alt="Story Showcase Preview"
                        fill
                        unoptimized={storyImage.startsWith("/uploads")}
                        className="object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
                      <div className="absolute bottom-4 inset-x-4 text-white text-xs font-sans">
                        <span className="text-[#C5A880] uppercase tracking-wider text-[10px] block font-mono">
                          {storyImageBadge}
                        </span>
                        <span className="text-[11px] text-[#D3CBBF]">{storyImageCaption}</span>
                      </div>
                    </div>

                    {/* Dropzone */}
                    <div className="relative border-2 border-dashed border-[#2E2E3C] hover:border-[#C5A880] transition-colors rounded-sm p-4 text-center bg-[#17171F] group">
                      <input
                        type="file"
                        accept="image/jpeg,image/png,image/webp,image/avif"
                        disabled={isUploadingStoryImage}
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) handleStoryImageUpload(f);
                          e.target.value = "";
                        }}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed z-10"
                      />
                      <div className="space-y-1 pointer-events-none">
                        <div className="w-9 h-9 rounded-full bg-[#1F1E28] border border-[#C5A880]/30 text-[#C5A880] flex items-center justify-center mx-auto text-base group-hover:scale-105 transition-transform">
                          {isUploadingStoryImage ? "⏳" : "⬆"}
                        </div>
                        <p className="text-xs text-white font-medium">
                          {isUploadingStoryImage ? "Uploading..." : "Click or drag & drop story photo"}
                        </p>
                        <p className="text-[10px] text-[#8C867D]">Portrait 4:5 format recommended</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[#8C867D] text-[10px] mb-1 font-mono uppercase">
                          Photo Badge
                        </label>
                        <input
                          type="text"
                          value={storyImageBadge}
                          onChange={(e) => setStoryImageBadge(e.target.value)}
                          placeholder="Ethically Sourced"
                          className="w-full p-2 bg-[#1C1C24] border border-[#2A2A36] text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[#8C867D] text-[10px] mb-1 font-mono uppercase">
                          Photo Caption
                        </label>
                        <input
                          type="text"
                          value={storyImageCaption}
                          onChange={(e) => setStoryImageCaption(e.target.value)}
                          placeholder="From Sri Lankan mines..."
                          className="w-full p-2 bg-[#1C1C24] border border-[#2A2A36] text-white"
                        />
                      </div>
                    </div>

                    <details className="text-[11px] text-[#8C867D]">
                      <summary className="cursor-pointer text-[#C5A880] hover:underline font-mono text-[10px] uppercase tracking-wider">
                        + Or enter image URL directly
                      </summary>
                      <input
                        type="text"
                        value={storyImage}
                        onChange={(e) => setStoryImage(e.target.value)}
                        placeholder="https://..."
                        className="mt-2 w-full p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs font-mono"
                      />
                    </details>
                  </div>

                  {/* Right Column: Story Copy & 3 Stats */}
                  <div className="lg:col-span-7 space-y-4">
                    <div>
                      <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                        Eyebrow Text
                      </label>
                      <input
                        type="text"
                        value={storyEyebrow}
                        onChange={(e) => setStoryEyebrow(e.target.value)}
                        placeholder="Our Story"
                        className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                        Story Headline
                      </label>
                      <input
                        type="text"
                        value={storyHeadline}
                        onChange={(e) => setStoryHeadline(e.target.value)}
                        placeholder="Crafted by Nature. Delivered with Trust."
                        className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                        Paragraph 1 (Philosophy / Natural Guarantee)
                      </label>
                      <textarea
                        rows={3}
                        value={storyP1}
                        onChange={(e) => setStoryP1(e.target.value)}
                        placeholder="At Faizan Gems, we believe the world's finest gemstones should stay 100% natural..."
                        className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                        Paragraph 2 (Direct Sourcing / Mining)
                      </label>
                      <textarea
                        rows={3}
                        value={storyP2}
                        onChange={(e) => setStoryP2(e.target.value)}
                        placeholder="We work directly with miners in Sri Lanka, Colombia, and Thailand..."
                        className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                      />
                    </div>

                    {/* 3 Story Stats */}
                    <div className="pt-2 border-t border-[#24242C] space-y-3">
                      <span className="text-[10px] font-mono uppercase text-[#C5A880] block font-semibold">
                        Story Key Metrics (3 Counters)
                      </span>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div className="p-3 bg-[#1C1C24] border border-[#2A2A36] rounded space-y-1.5">
                          <span className="text-[9px] text-[#8C867D] font-mono uppercase">Stat 1</span>
                          <input
                            type="text"
                            value={storyStat1Val}
                            onChange={(e) => setStoryStat1Val(e.target.value)}
                            placeholder="100%"
                            className="w-full p-1.5 bg-[#141419] border border-[#2A2A36] text-[#C5A880] font-mono tabular-nums text-sm focus:outline-none focus:border-[#C5A880]"
                          />
                          <input
                            type="text"
                            value={storyStat1Lbl}
                            onChange={(e) => setStoryStat1Lbl(e.target.value)}
                            placeholder="Natural & Untreated"
                            className="w-full p-1.5 bg-[#141419] border border-[#2A2A36] text-white text-[10px]"
                          />
                        </div>

                        <div className="p-3 bg-[#1C1C24] border border-[#2A2A36] rounded space-y-1.5">
                          <span className="text-[9px] text-[#8C867D] font-mono uppercase">Stat 2</span>
                          <input
                            type="text"
                            value={storyStat2Val}
                            onChange={(e) => setStoryStat2Val(e.target.value)}
                            placeholder="3"
                            className="w-full p-1.5 bg-[#141419] border border-[#2A2A36] text-[#C5A880] font-mono tabular-nums text-sm focus:outline-none focus:border-[#C5A880]"
                          />
                          <input
                            type="text"
                            value={storyStat2Lbl}
                            onChange={(e) => setStoryStat2Lbl(e.target.value)}
                            placeholder="Generations of Expert Cutters"
                            className="w-full p-1.5 bg-[#141419] border border-[#2A2A36] text-white text-[10px]"
                          />
                        </div>

                        <div className="p-3 bg-[#1C1C24] border border-[#2A2A36] rounded space-y-1.5">
                          <span className="text-[9px] text-[#8C867D] font-mono uppercase">Stat 3</span>
                          <input
                            type="text"
                            value={storyStat3Val}
                            onChange={(e) => setStoryStat3Val(e.target.value)}
                            placeholder="Direct"
                            className="w-full p-1.5 bg-[#141419] border border-[#2A2A36] text-[#C5A880] font-mono tabular-nums text-sm focus:outline-none focus:border-[#C5A880]"
                          />
                          <input
                            type="text"
                            value={storyStat3Lbl}
                            onChange={(e) => setStoryStat3Lbl(e.target.value)}
                            placeholder="Mine-to-You Direct"
                            className="w-full p-1.5 bg-[#141419] border border-[#2A2A36] text-white text-[10px]"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                      <div>
                        <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                          Story Button Text
                        </label>
                        <input
                          type="text"
                          value={storyCtaText}
                          onChange={(e) => setStoryCtaText(e.target.value)}
                          placeholder="Read Our Story →"
                          className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                          Story Button Link
                        </label>
                        <input
                          type="text"
                          value={storyCtaLink}
                          onChange={(e) => setStoryCtaLink(e.target.value)}
                          placeholder="/about"
                          className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 9. CONCIERGE & ADVISORY CONSULTATION CTA */}
            {(homepageActiveSection === "all" || homepageActiveSection === "consultation") && (
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-5">
                <div className="flex items-center justify-between border-b border-[#24242C] pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 text-[10px] font-mono bg-[#1E1E28] border border-[#C5A880]/30 text-[#C5A880] rounded">
                        Section 9
                      </span>
                      <h4 className="font-sans text-base text-white font-semibold tracking-tight">Concierge Consultation CTA</h4>
                    </div>
                    <p className="text-xs text-[#8C867D] font-sans mt-0.5">
                      The bottom high-conversion call-to-action banner inviting clients to book a personal showroom visit or video call.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-sans">
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Eyebrow Text
                    </label>
                    <input
                      type="text"
                      value={consultationEyebrow}
                      onChange={(e) => setConsultationEyebrow(e.target.value)}
                      placeholder="Need Help Choosing?"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Button Text
                    </label>
                    <input
                      type="text"
                      value={consultationBtnText}
                      onChange={(e) => setConsultationBtnText(e.target.value)}
                      placeholder="Book a Free Consultation"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Headline Title
                    </label>
                    <input
                      type="text"
                      value={consultationHeadline}
                      onChange={(e) => setConsultationHeadline(e.target.value)}
                      placeholder="Looking for a Specific Gemstone?"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Consultation Description
                    </label>
                    <textarea
                      rows={2}
                      value={consultationDesc}
                      onChange={(e) => setConsultationDesc(e.target.value)}
                      placeholder="Our gemstone experts are happy to help — visit our Trincomalee showroom or book a free video call consultation."
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white"
                    />
                  </div>
                </div>
              </div>
            )}

            <button type="submit" className="hidden" aria-hidden="true" tabIndex={-1} />
          </form>
        </div>
      )}

      {/* SUBTAB 2: SHOP PAGE & CATALOG */}
      {cmsSubTab === "shop" && (
        <div className="space-y-6">
          {/* Section Action Banner */}
          <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-5 rounded-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-sans text-base text-white font-semibold tracking-tight">
                Shop Page Header &amp; Content
              </h3>
              <p className="text-xs text-[#8C867D] font-sans mt-0.5">
                Manage the title, description, promotional announcement, and shipping badges on the shop page.
              </p>
            </div>
            <div className="w-full sm:w-auto flex items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  const form = document.getElementById("cms-shop-form") as HTMLFormElement;
                  form?.requestSubmit();
                }}
                disabled={isSavingCMS || isUploadingShopBanner}
                className="w-full sm:w-auto min-w-[145px] px-5 py-2.5 bg-[#C5A880] hover:bg-[#E0CFA9] disabled:bg-[#44382B] disabled:cursor-not-allowed text-[#0D0D11] text-xs uppercase font-sans font-semibold tracking-wider rounded-sm transition-colors shadow-md flex items-center justify-center gap-2 cursor-pointer shrink-0 select-none whitespace-nowrap"
              >
                {isSavingCMS ? "Saving..." : isUploadingShopBanner ? "Uploading..." : "Save Changes"}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-7 bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-6">
              <div className="flex items-center justify-between border-b border-[#24242C] pb-3">
                <div>
                  <h3 className="font-sans text-base text-white font-semibold tracking-tight">
                    Shop Page Header &amp; Text
                  </h3>
                  <p className="text-[11px] text-[#8C867D] font-sans mt-0.5">
                    Manage the title, description, and promotional announcement on the shop page.
                  </p>
                </div>
              </div>

              <form id="cms-shop-form" onSubmit={handleSaveShop} className="space-y-4 text-xs font-sans">
              <div>
                <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                  Small Category Label
                </label>
                <input
                  type="text"
                  value={shopEyebrow}
                  onChange={(e) => setShopEyebrow(e.target.value)}
                  placeholder="Faizan Gems Collection"
                  className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                />
              </div>

              <div>
                <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                  Shop Page Title
                </label>
                <input
                  type="text"
                  value={shopHeadline}
                  onChange={(e) => setShopHeadline(e.target.value)}
                  placeholder="Certified Natural Gemstones"
                  className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                />
              </div>

              <div>
                <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                  Shop Description
                </label>
                <textarea
                  rows={3}
                  value={shopSubheadline}
                  onChange={(e) => setShopSubheadline(e.target.value)}
                  placeholder="Describe your gemstone quality and standards..."
                  className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] resize-none"
                />
              </div>

              <div className="p-4 bg-[#1C1C24] border border-[#2A2A36] rounded-sm space-y-3">
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    id="shopNoticeToggle"
                    checked={shopNoticeActive}
                    onChange={(e) => setShopNoticeActive(e.target.checked)}
                    className="w-4 h-4 accent-[#C5A880]"
                  />
                  <label htmlFor="shopNoticeToggle" className="text-white cursor-pointer font-medium text-xs">
                    Show Announcement Banner on Shop Page
                  </label>
                </div>
                {shopNoticeActive && (
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                      Announcement Text
                    </label>
                    <input
                      type="text"
                      value={shopNoticeBadge}
                      onChange={(e) => setShopNoticeBadge(e.target.value)}
                      placeholder="e.g. Insured Worldwide Delivery on All Orders"
                      className="w-full p-2.5 bg-[#141419] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                    />
                  </div>
                )}
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block text-[#C5A880] uppercase text-[10px] font-mono tracking-wider">
                    Header Background Image (Optional)
                  </label>
                  {shopBannerImage && (
                    <button
                      type="button"
                      onClick={async () => {
                        setShopBannerImage("");
                        try {
                          await fetch("/api/cms", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({
                              type: "block",
                              section: "shop",
                              key: "banner_image",
                              value: "",
                            }),
                          });
                          if (typeof window !== "undefined") {
                            window.dispatchEvent(new CustomEvent("cms-updated"));
                          }
                          toast.success("Banner Removed", "Shop page header image removed (reverted to clean text header).");
                        } catch {
                          // silent fallback
                        }
                      }}
                      className="text-[10px] text-[#A84A4A] hover:text-[#ff6b6b] hover:underline transition-colors"
                    >
                      Remove Image
                    </button>
                  )}
                </div>

                {/* Active Image Preview if present */}
                {shopBannerImage && (
                  <div className="relative aspect-[21/9] w-full max-h-40 overflow-hidden rounded border border-[#2A2A36] bg-[#0D0D11] group">
                    <Image
                      src={shopBannerImage}
                      alt="Shop Header Background Preview"
                      fill
                      className="object-cover"
                      unoptimized={shopBannerImage.startsWith("/uploads")}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent pointer-events-none" />
                    <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between pointer-events-none">
                      <span className="text-[9px] font-mono px-2 py-0.5 bg-black/80 text-[#C5A880] rounded border border-white/10 truncate max-w-[70%]">
                        {shopBannerImage}
                      </span>
                      <span className="text-[9px] font-sans px-2 py-0.5 bg-black/80 text-[#A8D5BA] rounded border border-white/10">
                        Active Banner
                      </span>
                    </div>
                  </div>
                )}

                {/* Upload Dropzone / File Picker */}
                <div className="relative border-2 border-dashed border-[#2E2E3C] hover:border-[#C5A880] transition-colors rounded-sm p-6 text-center bg-[#17171F] group">
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp,image/avif"
                    disabled={isUploadingShopBanner}
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) handleShopBannerUpload(f);
                      e.target.value = "";
                    }}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed z-10"
                  />
                  <div className="space-y-2 pointer-events-none">
                    <div className="w-12 h-12 rounded-full bg-[#1F1E28] border border-[#C5A880]/30 text-[#C5A880] flex items-center justify-center mx-auto text-xl group-hover:scale-105 transition-transform">
                      {isUploadingShopBanner ? "⏳" : "⬆"}
                    </div>
                    <p className="text-xs text-white font-medium">
                      {isUploadingShopBanner
                        ? "Uploading Shop Banner Image..."
                        : "Click or drag & drop header banner image here"}
                    </p>
                    <p className="text-[10px] text-[#8C867D]">
                      Supports JPG, PNG, WEBP, AVIF • Max 25MB (leave empty for clean text header)
                    </p>
                  </div>
                </div>

                {shopBannerUploadError && (
                  <p className="text-xs text-[#A84A4A] mt-1">{shopBannerUploadError}</p>
                )}

              </div>

              <button type="submit" className="hidden" aria-hidden="true" tabIndex={-1} />
            </form>
          </div>

          {/* Right Column: Live Storefront Preview */}
          <div className="lg:col-span-5 bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono uppercase text-[#8C867D]">
                Shop Header Preview
              </span>
              <span className="text-[10px] font-mono text-[#C5A880] uppercase">
                {shopBannerImage ? "Banner Mode" : "Text Only Mode"}
              </span>
            </div>

            <div className="rounded-sm border border-[#2A2A36] bg-[#FAF8F5] p-5 text-left transition-all">
              {shopBannerImage ? (
                <div className="relative rounded overflow-hidden p-5 text-left border border-[#E8E4DC] min-h-[220px] flex flex-col justify-end">
                  <div
                    className="absolute inset-0 bg-cover bg-center"
                    style={{ backgroundImage: `url(${shopBannerImage})` }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#18181D]/90 via-[#18181D]/45 to-black/20" />
                  <div className="relative z-10 space-y-2">
                    {shopNoticeActive && shopNoticeBadge && (
                      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-white/10 backdrop-blur-md border border-white/20 text-[#E5C396] text-[8px] uppercase tracking-wider">
                        <span className="w-1 h-1 rounded-full bg-[#E5C396]" />
                        <span className="truncate max-w-[200px]">{shopNoticeBadge}</span>
                      </span>
                    )}
                    <span className="text-[9px] font-sans tracking-widest uppercase text-[#E5C396] block">
                      {shopEyebrow}
                    </span>
                    <h4 className="font-serif text-lg text-white font-normal leading-tight">
                      {shopHeadline}
                    </h4>
                    <p className="text-[10px] text-[#E0DDD8] line-clamp-2">
                      {shopSubheadline}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="border-b border-[#E8E4DC] pb-4">
                  {shopNoticeActive && shopNoticeBadge && (
                    <div className="mb-2 inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-[#F5EFE6] border border-[#C5A880]/40 text-[#6D5228] text-[9px] font-sans">
                      <span className="w-1 h-1 rounded-full bg-[#C5A880]" />
                      <span className="truncate max-w-[220px]">{shopNoticeBadge}</span>
                    </div>
                  )}
                  <span className="text-[9px] font-sans tracking-widest uppercase text-[#9A7B4F] block mb-1">
                    {shopEyebrow}
                  </span>
                  <h4 className="font-serif text-xl text-[#18181D] font-normal">
                    {shopHeadline}
                  </h4>
                  <p className="mt-1 text-[11px] text-[#6B655C] font-sans line-clamp-2">
                    {shopSubheadline}
                  </p>
                </div>
              )}

              <div className="mt-3 pt-3 border-t border-[#E8E4DC]/60 flex items-center justify-between text-[9px] text-[#8C867D] font-sans">
                <span>Showing <strong>12</strong> of 12 gemstones</span>
                <span className="text-[#C5A880] font-mono">Filter Active</span>
              </div>
            </div>

            <div className="p-4 bg-[#1C1C24] border border-[#2A2A36] rounded-sm text-xs space-y-2">
              <div className="text-[#C5A880] font-semibold text-[11px] flex items-center gap-2">
                <span>ℹ️</span>
                <span>Gemstone Inventory Note</span>
              </div>
              <p className="text-[#8C867D] text-[11px] leading-relaxed">
                To add, edit, or delete individual gemstones, prices (USD), or stock, use the <strong className="text-white">Inventory</strong> tab. The settings on this page control only the text and banner shown at the top of the shop.
              </p>
            </div>
          </div>
        </div>
      </div>
      )}

      {/* SUBTAB: CURATED COLLECTIONS */}
      {cmsSubTab === "collections" && (
        <div className="space-y-6 w-full">
          {/* Header & Quick Action Bar */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#141419] border border-[#24242C] p-4 sm:p-5 rounded-sm">
            <div>
              <h3 className="font-sans text-base text-white font-semibold tracking-tight">
                Curated Collection Cards
              </h3>
              <p className="text-xs text-[#8C867D] font-sans mt-1">
                Card-by-card visual editor for storefront collections. Toggle which cards appear on the homepage, edit names &amp; images, reorder, or add more cards. Storefront cards show strictly the gem image and name.
              </p>
            </div>
            <div className="grid grid-cols-2 sm:flex sm:items-center gap-2.5 w-full sm:w-auto shrink-0">
              <button
                type="button"
                onClick={() => setIsAddCardModalOpen(true)}
                className="w-full sm:w-auto px-5 py-2.5 bg-[#1E1E28] hover:bg-[#282836] border border-[#C5A880]/50 hover:border-[#C5A880] text-[#E0CFA9] hover:text-white text-xs uppercase font-sans font-semibold tracking-wider rounded-sm transition-colors shadow-md flex items-center justify-center gap-1.5 cursor-pointer shrink-0 select-none whitespace-nowrap"
              >
                <span>+ Add</span>
              </button>
              <button
                type="button"
                onClick={() => handleSaveCollections()}
                disabled={isSavingCMS || Boolean(uploadingCardId)}
                className="w-full sm:w-auto min-w-0 sm:min-w-[145px] px-5 py-2.5 bg-[#C5A880] hover:bg-[#E0CFA9] disabled:bg-[#44382B] disabled:cursor-not-allowed text-[#0D0D11] text-xs uppercase font-sans font-semibold tracking-wider rounded-sm transition-colors shadow-md flex items-center justify-center gap-2 cursor-pointer shrink-0 select-none whitespace-nowrap"
              >
                {isSavingCMS ? (
                  <>
                    <span className="animate-spin text-sm">↻</span>
                    <span>Saving...</span>
                  </>
                ) : (
                  <span>Save Changes</span>
                )}
              </button>
            </div>
          </div>

          {collectionCardError && (
            <div className="p-3.5 bg-red-950/40 border border-red-800/60 rounded-sm text-red-200 text-xs font-sans flex items-center justify-between">
              <span>⚠️ {collectionCardError}</span>
              <button
                type="button"
                onClick={() => setCollectionCardError("")}
                className="text-red-400 hover:text-white"
              >
                ✕
              </button>
            </div>
          )}

          {/* SECTION 1: COLLECTIONS PAGE HEADER */}
          <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-5">
            <div className="border-b border-[#24242C] pb-3 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 text-[10px] font-mono bg-[#1E1E28] border border-[#C5A880]/30 text-[#C5A880] rounded">
                    Section 1
                  </span>
                  <h4 className="font-sans text-base text-white font-semibold tracking-tight">
                    Collections Page Header
                  </h4>
                </div>
                <p className="text-xs text-[#8C867D] font-sans mt-1">
                  Customize the title, eyebrow, and description displayed on the top shop-style header of <code className="text-[#C5A880]">/collections</code>.
                </p>
              </div>
            </div>

            {/* Top Page Header Inputs */}
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-sans">
                <div>
                  <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono tracking-wider">
                    Header Eyebrow
                  </label>
                  <input
                    type="text"
                    value={collectionsPageEyebrow}
                    onChange={(e) => setCollectionsPageEyebrow(e.target.value)}
                    placeholder="Faizan Gems Vault Collections"
                    className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] rounded-sm"
                  />
                </div>
                <div>
                  <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono tracking-wider">
                    Main Page Headline
                  </label>
                  <input
                    type="text"
                    value={collectionsPageHeadline}
                    onChange={(e) => setCollectionsPageHeadline(e.target.value)}
                    placeholder="Curated Gemstone Portfolios"
                    className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] rounded-sm"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono tracking-wider">
                  Page Description / Subheadline
                </label>
                <textarea
                  rows={2}
                  value={collectionsPageSubheadline}
                  onChange={(e) => setCollectionsPageSubheadline(e.target.value)}
                  placeholder="Browse collections of the world's finest natural gemstones..."
                  className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] rounded-sm text-xs leading-relaxed"
                />
              </div>
            </div>
          </div>

          {/* SECTION 2: CARD-BY-CARD LIST */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#24242C] pb-3 pt-2">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 text-[10px] font-mono bg-[#1E1E28] border border-[#C5A880]/30 text-[#C5A880] rounded">
                Section 2
              </span>
              <h4 className="font-sans text-base text-white font-semibold tracking-tight">
                Curated Collection Cards ({collectionCards.length})
              </h4>
            </div>
            <span className="text-xs text-[#8C867D]">
              Cards display strictly gem cover image and name
            </span>
          </div>

          <div className="space-y-5">
            {collectionCards.map((card, idx) => (
              <div
                key={card.id}
                className="bg-[#141419] border border-[#24242C] hover:border-[#33333F] rounded-sm p-4 sm:p-5 transition-colors space-y-4"
              >
                {/* Card Top Bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#24242C] pb-3">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="w-6 h-6 rounded-full bg-[#1F1F2A] border border-[#2D2D3D] text-[11px] font-mono text-[#C5A880] flex items-center justify-center font-bold shrink-0">
                      {idx + 1}
                    </span>
                    <h4 className="font-sans text-sm text-white font-semibold truncate">
                      {card.name || "Untitled Gemstone"}
                    </h4>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap justify-between sm:justify-end w-full sm:w-auto">
                    {/* Homepage Visibility Toggle */}
                    <button
                      type="button"
                      onClick={() => handleToggleCardShowOnHome(card.id)}
                      className={`flex-1 sm:flex-none justify-center px-3 py-1.5 rounded text-xs font-sans font-medium transition-colors flex items-center gap-1.5 border select-none ${
                        card.showOnHome
                          ? "bg-emerald-950/70 border-emerald-500/60 text-emerald-300 hover:bg-emerald-900/80"
                          : "bg-[#1A1A22] border-[#2A2A36] text-[#8C867D] hover:text-white"
                      }`}
                      title={card.showOnHome ? "Click to hide from Homepage" : "Click to show on Homepage"}
                    >
                      <span
                        className={`w-2 h-2 rounded-full shrink-0 ${
                          card.showOnHome ? "bg-emerald-400" : "bg-zinc-600"
                        }`}
                      />
                      <span className="whitespace-nowrap">{card.showOnHome ? "Shown on Homepage" : "Hidden"}</span>
                    </button>

                    <div className="flex items-center gap-2 shrink-0">
                      {/* Move Up/Down */}
                      <div className="flex items-center border border-[#2A2A36] rounded overflow-hidden">
                        <button
                          type="button"
                          onClick={() => handleMoveCard(card.id, "up")}
                          disabled={idx === 0}
                          className="px-2.5 py-1 bg-[#1A1A22] hover:bg-[#252532] text-[#C5C0B6] disabled:opacity-30 disabled:hover:bg-[#1A1A22] text-xs transition-colors"
                          title="Move Up"
                        >
                          ▲
                        </button>
                        <button
                          type="button"
                          onClick={() => handleMoveCard(card.id, "down")}
                          disabled={idx === collectionCards.length - 1}
                          className="px-2.5 py-1 bg-[#1A1A22] hover:bg-[#252532] text-[#C5C0B6] disabled:opacity-30 disabled:hover:bg-[#1A1A22] text-xs transition-colors border-l border-[#2A2A36]"
                          title="Move Down"
                        >
                          ▼
                        </button>
                      </div>

                      {/* Delete Card */}
                      <button
                        type="button"
                        onClick={() => handleDeleteCard(card.id, card.name)}
                        className="px-2.5 py-1 text-red-400 hover:text-red-300 hover:bg-red-950/30 border border-transparent hover:border-red-900/50 rounded text-xs transition-colors"
                        title="Delete Collection Card"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </div>

                {/* Card Main Body: 2 Columns */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                  {/* Left Column: Live Storefront Card Preview (Image & Name ONLY) */}
                  <div className="md:col-span-4 space-y-2">
                    <div className="flex items-center justify-between text-[10px] font-mono uppercase tracking-wider text-[#8C867D]">
                      <span>Live Card Preview</span>
                      <span className="text-[#C5A880]">Only Image &amp; Name</span>
                    </div>

                    <div className="relative aspect-[4/3] w-full rounded-sm overflow-hidden bg-[#0A0A0E] border border-[#2A2A36] shadow-md group flex flex-col justify-end">
                      {card.image ? (
                        <Image
                          src={card.image}
                          alt={card.name}
                          fill
                          unoptimized={card.image.startsWith("/uploads")}
                          className="object-cover transition-transform duration-700 group-hover:scale-105"
                        />
                      ) : (
                        <div className="absolute inset-0 flex flex-col items-center justify-center text-[#5A554E] gap-2">
                          <GemIcon className="w-8 h-8 text-[#5A554E]/80" />
                          <span className="text-[11px] uppercase tracking-wider font-mono">No cover image</span>
                        </div>
                      )}

                      {/* Storefront gradient overlay */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-transparent" />

                      {/* Storefront Card Content: Gem Name ONLY */}
                      <div className="relative z-10 p-4 text-center">
                        <h5 className="font-serif text-lg text-white font-light tracking-wide drop-shadow-sm">
                          {card.name || "Gemstone Name"}
                        </h5>
                      </div>
                    </div>

                    <div className="text-[10px] text-[#6A655C] font-sans text-center">
                      Storefront card shows strictly gem cover &amp; title.
                    </div>
                  </div>

                  {/* Right Column: Editable Fields */}
                  <div className="md:col-span-8 space-y-4 text-xs font-sans">
                    <div>
                      <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono tracking-wider">
                        Gem / Collection Name *
                      </label>
                      <input
                        type="text"
                        value={card.name}
                        onChange={(e) => handleUpdateCardField(card.id, "name", e.target.value)}
                        placeholder="e.g. Ceylon Sapphires"
                        className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] rounded-sm"
                      />
                    </div>

                    {/* Image Settings */}
                    <div className="space-y-1.5 pt-1">
                      <label className="block text-[#C5A880] uppercase text-[10px] font-mono tracking-wider">
                        Cover Image (Upload File) *
                      </label>

                      <label className="relative flex items-center justify-between px-4 py-3 bg-[#1C1C24] hover:bg-[#23232D] border border-dashed border-[#2A2A36] hover:border-[#C5A880] rounded-sm cursor-pointer transition-colors duration-150">
                        <input
                          type="file"
                          accept="image/jpeg,image/png,image/webp,image/avif"
                          disabled={uploadingCardId === card.id}
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleUploadCardImage(file, card.id);
                          }}
                          className="absolute inset-0 opacity-0 cursor-pointer w-full h-full disabled:cursor-not-allowed"
                        />
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded bg-[#181820] border border-[#2D2D3B] flex items-center justify-center text-[#C5A880] flex-shrink-0">
                            {card.image ? (
                              <CheckIcon className="w-4 h-4 text-emerald-400" />
                            ) : (
                              <svg className="w-4 h-4 text-[#C5A880]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
                              </svg>
                            )}
                          </div>
                          <div>
                            <span className="text-white text-xs font-medium block">
                              {uploadingCardId === card.id
                                ? "Uploading image file..."
                                : card.image
                                ? "Replace current image"
                                : "Choose or drag image file"}
                            </span>
                            <span className="text-[#8C867D] text-[10px] font-sans">
                              JPEG, PNG, WEBP, AVIF up to 25MB
                            </span>
                          </div>
                        </div>
                        <span className="px-3 py-1.5 bg-[#C5A880]/15 border border-[#C5A880]/30 text-[#E0CFA9] text-[11px] rounded font-medium shrink-0">
                          {uploadingCardId === card.id ? "Uploading..." : card.image ? "Replace" : "Browse File"}
                        </span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>



          {/* ADD COLLECTION CARD MODAL (PORTALED TO BODY FOR FIXED CENTERED DISPLAY) */}
          {isAddCardModalOpen && mounted && typeof document !== "undefined" && createPortal(
            <div
              className="fixed inset-0 z-[99999] flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-md animate-luxury-backdrop overflow-y-auto"
              onClick={(e) => {
                if (e.target === e.currentTarget) setIsAddCardModalOpen(false);
              }}
            >
              <div className="relative w-full max-w-lg bg-[#141419] border border-[#C5A880]/60 shadow-2xl p-5 sm:p-8 max-h-[90vh] overflow-y-auto text-white animate-luxury-modal my-auto rounded-sm space-y-5">
                <div className="flex items-center justify-between border-b border-[#24242C] pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-[#1C1C24] border border-[#C5A880]/40 flex items-center justify-center text-[#C5A880]">
                      <GemIcon className="w-4 h-4" />
                    </div>
                    <h4 className="font-sans text-base text-white font-semibold tracking-tight">
                      Add New Collection Card
                    </h4>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsAddCardModalOpen(false)}
                    className="text-[#8C867D] hover:text-white text-sm p-1 transition-colors"
                  >
                    <CloseIcon className="w-5 h-5" />
                  </button>
                </div>

                <form onSubmit={handleAddNewCard} className="space-y-4 text-xs font-sans">
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono tracking-wider">
                      Gemstone / Collection Name *
                    </label>
                    <input
                      type="text"
                      value={newCardName}
                      onChange={(e) => {
                        const val = e.target.value;
                        setNewCardName(val);
                        setNewCardSlug(val.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""));
                      }}
                      placeholder="e.g. Tsavorite Garnet"
                      required
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] rounded-sm text-xs"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-[#C5A880] uppercase text-[10px] font-mono tracking-wider">
                      Cover Image (Upload File) *
                    </label>
                    <label className="relative flex items-center justify-between px-4 py-3 bg-[#1C1C24] hover:bg-[#23232D] border border-dashed border-[#2A2A36] hover:border-[#C5A880] rounded-sm cursor-pointer transition-colors duration-150">
                      <input
                        type="file"
                        accept="image/jpeg,image/png,image/webp,image/avif"
                        disabled={isUploadingNewCardImage}
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handleUploadNewCardImage(file);
                        }}
                        className="absolute inset-0 opacity-0 cursor-pointer w-full h-full disabled:cursor-not-allowed"
                      />
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-[#181820] border border-[#2D2D3B] flex items-center justify-center text-[#C5A880] flex-shrink-0">
                          {newCardImage ? (
                            <CheckIcon className="w-4 h-4 text-emerald-400" />
                          ) : (
                            <svg className="w-4 h-4 text-[#C5A880]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                              <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
                            </svg>
                          )}
                        </div>
                        <div>
                          <span className="text-white text-xs font-medium block">
                            {isUploadingNewCardImage
                              ? "Uploading image file..."
                              : newCardImage
                              ? "Image uploaded successfully"
                              : "Choose or drag image file"}
                          </span>
                          <span className="text-[#8C867D] text-[10px] font-sans">
                            {newCardImage ? "Click to replace file" : "JPEG, PNG, WEBP, AVIF up to 25MB"}
                          </span>
                        </div>
                      </div>
                      <span className="px-3 py-1.5 bg-[#C5A880]/15 border border-[#C5A880]/30 text-[#E0CFA9] text-[11px] rounded font-medium shrink-0">
                        {isUploadingNewCardImage ? "Uploading..." : newCardImage ? "Replace" : "Browse File"}
                      </span>
                    </label>
                  </div>

                  {/* Homepage toggle */}
                  <div className="p-3 bg-[#1A1A22] border border-[#2A2A36] rounded-sm flex items-center justify-between">
                    <div>
                      <div className="font-medium text-white text-xs">Show on Homepage</div>
                      <div className="text-[10px] text-[#8C867D]">
                        Display this card in the homepage collections showcase
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setNewCardShowOnHome(!newCardShowOnHome)}
                      className={`px-3 py-1.5 rounded text-xs font-medium transition-colors duration-150 border flex items-center gap-1.5 ${
                        newCardShowOnHome
                          ? "bg-emerald-950/70 border-emerald-500/60 text-emerald-300"
                          : "bg-[#141419] border-[#2A2A36] text-[#8C867D]"
                      }`}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full ${newCardShowOnHome ? "bg-emerald-400" : "bg-zinc-600"}`} />
                      <span>{newCardShowOnHome ? "Active" : "Hidden"}</span>
                    </button>
                  </div>

                  <div className="flex flex-col-reverse sm:flex-row items-center justify-end gap-2.5 sm:gap-3 pt-3 border-t border-[#24242C]">
                    <button
                      type="button"
                      onClick={() => setIsAddCardModalOpen(false)}
                      className="w-full sm:w-auto px-4 py-2.5 border border-[#2A2A36] hover:border-[#3A3A46] text-[#C5C0B6] text-xs rounded-sm transition-colors text-center"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="w-full sm:w-auto px-5 py-2.5 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-xs font-semibold rounded-sm transition-colors shadow text-center"
                    >
                      Add Collection Card
                    </button>
                  </div>
                </form>
              </div>
            </div>,
            document.body
          )}
        </div>
      )}

      {/* SUBTAB 4: FAIZAN GEMS ABOUT US PAGE */}
      {cmsSubTab === "about" && (
        <div className="space-y-6 w-full">
          {/* Header & Quick Action Bar */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#141419] border border-[#24242C] p-4 sm:p-5 rounded-sm">
            <div>
              <h3 className="font-sans text-base text-white font-semibold tracking-tight">
                About Us Page Content
              </h3>
              <p className="text-xs text-[#8C867D] font-sans mt-0.5">
                Customize brand identity, company overview, mission &amp; vision, CEO message &amp; portrait, and office locations shown on <span className="font-mono text-[#C5A880]">/about</span>.
              </p>
            </div>
            <div className="w-full sm:w-auto flex items-center gap-3">
              <button
                type="button"
                onClick={() => handleSaveAbout()}
                disabled={isSavingCMS || !!isUploadingAboutImage}
                className="w-full sm:w-auto min-w-[145px] px-5 py-2.5 bg-[#C5A880] hover:bg-[#E0CFA9] disabled:bg-[#44382B] disabled:cursor-not-allowed text-[#0D0D11] text-xs uppercase font-sans font-semibold tracking-wider rounded-sm transition-colors shadow-md flex items-center justify-center gap-2 cursor-pointer shrink-0 select-none whitespace-nowrap"
              >
                {isSavingCMS ? "Saving..." : "Save Changes"}
              </button>
            </div>
          </div>

          {aboutImageUploadError && (
            <div className="p-3 bg-red-950/40 border border-red-800 text-red-300 text-xs flex items-center justify-between rounded-sm">
              <span>⚠️ {aboutImageUploadError}</span>
              <button
                type="button"
                onClick={() => setAboutImageUploadError("")}
                className="text-red-400 hover:text-red-200 text-sm ml-2"
              >
                ✕
              </button>
            </div>
          )}

          {/* Mobile About Us Section Select (LuxurySelect for Mobile Responsive) */}
          <div className="md:hidden relative z-20 pb-1">
            <label className="block text-[10px] font-mono uppercase tracking-wider text-[#8C867D] mb-1.5 select-none">
              Jump to About Us Section:
            </label>
            <LuxurySelect
              variant="dark"
              size="sm"
              value={aboutActiveSection}
              onChange={(val) => setAboutActiveSection(val as AboutSectionTab)}
              options={[
                { value: "all", label: "All Sections" },
                { value: "hero", label: "1. Hero & Brand Slogan" },
                { value: "overview", label: "2. Company Overview" },
                { value: "mission_vision", label: "3. Mission & Vision" },
                { value: "ceo", label: "4. Message from CEO" },
                { value: "locations", label: "5. Our Locations" },
              ]}
            />
          </div>

          {/* Desktop Section Filter Pills Bar */}
          <div className="hidden md:flex items-center gap-1.5 overflow-x-auto pb-2 border-b border-[#24242C] scrollbar-thin text-xs font-sans">
            {(
              [
                { id: "all", label: "All Sections" },
                { id: "hero", label: "1. Hero & Brand Slogan" },
                { id: "overview", label: "2. Company Overview" },
                { id: "mission_vision", label: "3. Mission & Vision" },
                { id: "ceo", label: "4. Message from CEO" },
                { id: "locations", label: "5. Our Locations" },
              ] as { id: AboutSectionTab; label: string }[]
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setAboutActiveSection(tab.id)}
                className={`px-3 py-1.5 text-xs font-mono rounded-sm transition-colors whitespace-nowrap ${
                  aboutActiveSection === tab.id
                    ? "bg-[#C5A880] text-[#0D0D11] font-semibold"
                    : "bg-[#141419] text-[#8C867D] hover:text-white border border-[#24242C] hover:border-[#3A3A48]"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <form onSubmit={handleSaveAbout} className="space-y-6 text-xs font-sans">
            {/* ================================================================ */}
            {/* Section 1: Hero & Brand Identity                                 */}
            {/* ================================================================ */}
            {(aboutActiveSection === "all" || aboutActiveSection === "hero") && (
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-4">
                <div className="border-b border-[#24242C] pb-3">
                  <h4 className="text-sm font-medium uppercase tracking-wider font-mono text-[#C5A880]">
                    1. Hero &amp; Brand Identity
                  </h4>
                  <p className="text-[11px] text-[#8C867D] mt-0.5">
                    Headline brand slogan quote, secondary tagline, and opening introductory statement in the luxury dark hero banner.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Main Brand Slogan / Hero Quote
                    </label>
                    <input
                      type="text"
                      value={aboutBrandSlogan}
                      onChange={(e) => setAboutBrandSlogan(e.target.value)}
                      placeholder="From the Heart of Sri Lanka to the World."
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                    />
                    <span className="text-[10px] text-[#6B655C] mt-1 block">
                      Rendered in large display serif with quotation marks.
                    </span>
                  </div>

                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Sub-Tagline
                    </label>
                    <input
                      type="text"
                      value={aboutBrandTagline}
                      onChange={(e) => setAboutBrandTagline(e.target.value)}
                      placeholder="Natural Gemstones • Custom Jewellery • Trusted Service"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                    />
                    <span className="text-[10px] text-[#6B655C] mt-1 block">
                      Gold uppercase subtitle below the slogan.
                    </span>
                  </div>
                </div>

                <div>
                  <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                    Hero Introductory Statement
                  </label>
                  <textarea
                    rows={3}
                    value={aboutPageIntro}
                    onChange={(e) => setAboutPageIntro(e.target.value)}
                    placeholder="Faizan Gems (Pvt) Ltd is a Sri Lankan gemstone trading and jewellery company specializing in the buying and selling of natural gemstones, with a special focus on Sri Lankan sapphires."
                    className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] leading-relaxed"
                  />
                </div>
              </div>
            )}

            {/* ================================================================ */}
            {/* Section 2: Company Overview & Specializations                    */}
            {/* ================================================================ */}
            {(aboutActiveSection === "all" || aboutActiveSection === "overview") && (
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-5">
                <div className="border-b border-[#24242C] pb-3">
                  <h4 className="text-sm font-medium uppercase tracking-wider font-mono text-[#C5A880]">
                    2. Company Overview &amp; Specializations
                  </h4>
                  <p className="text-[11px] text-[#8C867D] mt-0.5">
                    Descriptions for natural gemstone trading, bespoke jewellery manufacturing, core trust pillars, and heritage vision quote.
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Natural Gemstone Trading Description (Card 1)
                    </label>
                    <textarea
                      rows={3}
                      value={aboutTradingDesc}
                      onChange={(e) => setAboutTradingDesc(e.target.value)}
                      placeholder="We source and trade carefully selected natural gemstones from Sri Lanka, with a special focus on Sri Lankan sapphires..."
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] leading-relaxed"
                    />
                  </div>

                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Custom Jewellery Manufacturing Description (Card 2)
                    </label>
                    <textarea
                      rows={3}
                      value={aboutJewelleryDesc}
                      onChange={(e) => setAboutJewelleryDesc(e.target.value)}
                      placeholder="In addition to gemstone trading, we offer custom jewellery manufacturing, creating unique rings, earrings, pendants, bracelets and necklaces..."
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] leading-relaxed"
                    />
                  </div>

                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Our Pillars of Trust Description (Card 3)
                    </label>
                    <textarea
                      rows={3}
                      value={aboutTrustDesc}
                      onChange={(e) => setAboutTrustDesc(e.target.value)}
                      placeholder="At Faizan Gems, we believe that trust, authenticity, quality and customer satisfaction are the foundation of a successful gemstone business..."
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] leading-relaxed"
                    />
                  </div>

                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Heritage Vision Short Quote
                    </label>
                    <textarea
                      rows={2}
                      value={aboutVisionShort}
                      onChange={(e) => setAboutVisionShort(e.target.value)}
                      placeholder="Connecting the rich Sri Lankan gemstone heritage with customers and jewellery markets around the world..."
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] leading-relaxed italic"
                    />
                    <span className="text-[10px] text-[#6B655C] mt-1 block">
                      Italicized quote displayed at the bottom of the Pillars of Trust card.
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* ================================================================ */}
            {/* Section 3: Mission & Vision Statements                           */}
            {/* ================================================================ */}
            {(aboutActiveSection === "all" || aboutActiveSection === "mission_vision") && (
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-4">
                <div className="border-b border-[#24242C] pb-3">
                  <h4 className="text-sm font-medium uppercase tracking-wider font-mono text-[#C5A880]">
                    3. Purpose &amp; Direction (Mission &amp; Vision)
                  </h4>
                  <p className="text-[11px] text-[#8C867D] mt-0.5">
                    Official mission and vision statements displayed side-by-side in the dark luxury section.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="p-4 bg-[#1C1C24] border border-[#2A2A36] rounded-sm space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono uppercase tracking-wider text-[#C5A880] font-semibold">
                        Our Mission
                      </span>
                      <span className="text-sm text-[#C5A880]">✦</span>
                    </div>
                    <label className="block text-[#A29C91] text-[11px]">
                      Mission Statement
                    </label>
                    <textarea
                      rows={5}
                      value={aboutMissionStatement}
                      onChange={(e) => setAboutMissionStatement(e.target.value)}
                      placeholder="Faizan Gems (Pvt) Ltd is committed to sourcing and trading genuine natural gemstones..."
                      className="w-full p-2.5 bg-[#141419] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] leading-relaxed"
                    />
                  </div>

                  <div className="p-4 bg-[#1C1C24] border border-[#2A2A36] rounded-sm space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono uppercase tracking-wider text-[#C5A880] font-semibold">
                        Our Vision
                      </span>
                      <span className="text-sm text-[#C5A880]">✦</span>
                    </div>
                    <label className="block text-[#A29C91] text-[11px]">
                      Vision Statement
                    </label>
                    <textarea
                      rows={5}
                      value={aboutVisionStatement}
                      onChange={(e) => setAboutVisionStatement(e.target.value)}
                      placeholder="To become a trusted and internationally recognized Sri Lankan gemstone and jewellery company..."
                      className="w-full p-2.5 bg-[#141419] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] leading-relaxed"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* ================================================================ */}
            {/* Section 4: Message from the CEO                                  */}
            {/* ================================================================ */}
            {(aboutActiveSection === "all" || aboutActiveSection === "ceo") && (
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-5">
                <div className="border-b border-[#24242C] pb-3">
                  <h4 className="text-sm font-medium uppercase tracking-wider font-mono text-[#C5A880]">
                    4. Message from the CEO
                  </h4>
                  <p className="text-[11px] text-[#8C867D] mt-0.5">
                    Official executive letter, credentials, portrait photo upload, and personal address from the founder.
                  </p>
                </div>

                {/* CEO Photo Upload & Preview */}
                <div className="p-4 bg-[#1C1C24] border border-[#2A2A36] rounded-sm space-y-3">
                  <span className="text-xs font-mono text-[#C5A880] uppercase tracking-wider block">
                    CEO Portrait Photo
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
                    {aboutFounderImage && (
                      <div className="relative aspect-[3/4] w-28 rounded overflow-hidden border border-[#2A2A36] bg-[#0E0E12]">
                        <Image
                          src={aboutFounderImage}
                          alt={aboutFounderName || "CEO"}
                          fill
                          unoptimized={aboutFounderImage.startsWith("/uploads")}
                          className="object-cover"
                        />
                      </div>
                    )}
                    <div className={`space-y-2 ${aboutFounderImage ? "sm:col-span-2" : "sm:col-span-3"}`}>
                      <div className="relative border-2 border-dashed border-[#2E2E3C] hover:border-[#C5A880] transition-colors rounded-sm p-3 text-center bg-[#141419]">
                        <input
                          type="file"
                          accept="image/jpeg,image/png,image/webp,image/avif"
                          disabled={isUploadingAboutImage === "founder"}
                          onChange={(e) => {
                            const f = e.target.files?.[0];
                            if (f) handleUploadAboutImage(f, setAboutFounderImage, "founder");
                            e.target.value = "";
                          }}
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed z-10"
                        />
                        <p className="text-xs text-white">
                          {isUploadingAboutImage === "founder" ? "Uploading..." : "Upload New Portrait Photo"}
                        </p>
                        <p className="text-[10px] text-[#8C867D] mt-0.5">
                          JPEG, PNG, WEBP, or AVIF (Up to 25MB)
                        </p>
                      </div>
                               <input
                        type="text"
                        value={aboutFounderImage}
                        onChange={(e) => setAboutFounderImage(e.target.value)}
                        placeholder="/uploads/gemstones/gem-1789653639242-gt09cd.webp"
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] text-xs font-mono"
                      />
                    </div>
                  </div>
                </div>

                {/* Name, Title, Credentials, Greeting */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Founder / CEO Full Name
                    </label>
                    <input
                      type="text"
                      value={aboutFounderName}
                      onChange={(e) => setAboutFounderName(e.target.value)}
                      placeholder="Riyas Abdul Aziz (JP)"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                    />
                  </div>
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Title / Position
                    </label>
                    <input
                      type="text"
                      value={aboutFounderTitle}
                      onChange={(e) => setAboutFounderTitle(e.target.value)}
                      placeholder="CEO / Founder"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                    />
                  </div>
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Credentials &amp; Post-nominals
                    </label>
                    <input
                      type="text"
                      value={aboutFounderCredentials}
                      onChange={(e) => setAboutFounderCredentials(e.target.value)}
                      placeholder="BSc in Psychology &amp; Counselling"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                    Greeting Salutation
                  </label>
                  <input
                    type="text"
                    value={aboutFounderGreeting}
                    onChange={(e) => setAboutFounderGreeting(e.target.value)}
                    placeholder="Assalamu Alaikum and warm greetings,"
                    className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                  />
                </div>

                {/* CEO Paragraphs 1-5 */}
                <div className="space-y-3">
                  <span className="text-xs font-mono uppercase text-[#C5A880] font-semibold block">
                    CEO Letter Paragraphs
                  </span>
                  <div>
                    <label className="block text-[#8C867D] text-[10px] mb-1 font-mono">
                      Paragraph 1 (Welcome &amp; Introduction)
                    </label>
                    <textarea
                      rows={3}
                      value={aboutFounderP1}
                      onChange={(e) => setAboutFounderP1(e.target.value)}
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] leading-relaxed"
                    />
                  </div>
                  <div>
                    <label className="block text-[#8C867D] text-[10px] mb-1 font-mono">
                      Paragraph 2 (Sri Lankan Heritage)
                    </label>
                    <textarea
                      rows={3}
                      value={aboutFounderP2}
                      onChange={(e) => setAboutFounderP2(e.target.value)}
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] leading-relaxed"
                    />
                  </div>
                  <div>
                    <label className="block text-[#8C867D] text-[10px] mb-1 font-mono">
                      Paragraph 3 (Commitment &amp; Customer Relations)
                    </label>
                    <textarea
                      rows={3}
                      value={aboutFounderP3}
                      onChange={(e) => setAboutFounderP3(e.target.value)}
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] leading-relaxed"
                    />
                  </div>
                  <div>
                    <label className="block text-[#8C867D] text-[10px] mb-1 font-mono">
                      Paragraph 4 (Future &amp; Global Expansion)
                    </label>
                    <textarea
                      rows={2}
                      value={aboutFounderP4}
                      onChange={(e) => setAboutFounderP4(e.target.value)}
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] leading-relaxed"
                    />
                  </div>
                  <div>
                    <label className="block text-[#8C867D] text-[10px] mb-1 font-mono">
                      Paragraph 5 (Closing Appreciation)
                    </label>
                    <textarea
                      rows={2}
                      value={aboutFounderP5}
                      onChange={(e) => setAboutFounderP5(e.target.value)}
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] leading-relaxed"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* ================================================================ */}
            {/* Section 5: Our Locations                                         */}
            {/* ================================================================ */}
            {(aboutActiveSection === "all" || aboutActiveSection === "locations") && (
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-6">
                <div className="border-b border-[#24242C] pb-3">
                  <h4 className="text-sm font-medium uppercase tracking-wider font-mono text-[#C5A880]">
                    5. Our Locations (Head Office &amp; Regional Branch)
                  </h4>
                  <p className="text-[11px] text-[#8C867D] mt-0.5">
                    Official company locations in Trincomalee (Corporate Headquarters) and Kalutara (Regional Trading Office).
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Head Office Trincomalee */}
                  <div className="p-4 bg-[#1C1C24] border border-[#2A2A36] rounded-sm space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono uppercase tracking-wider text-[#C5A880] font-semibold">
                        Location 1: Trincomalee
                      </span>
                      <span className="text-[10px] px-2 py-0.5 bg-[#C5A880]/15 text-[#C5A880] border border-[#C5A880]/30 rounded">
                        Head Office
                      </span>
                    </div>

                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1 font-mono">Office Title</label>
                      <input
                        type="text"
                        value={aboutHeadOfficeTitle}
                        onChange={(e) => setAboutHeadOfficeTitle(e.target.value)}
                        placeholder="Head Office – Trincomalee"
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                      />
                    </div>

                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1 font-mono">Badge / Sub-heading</label>
                      <input
                        type="text"
                        value={aboutHeadOfficeBadge}
                        onChange={(e) => setAboutHeadOfficeBadge(e.target.value)}
                        placeholder="Corporate Headquarters & Flagship"
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                      />
                    </div>

                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1 font-mono">Full Physical Address</label>
                      <input
                        type="text"
                        value={aboutHeadOfficeAddress}
                        onChange={(e) => setAboutHeadOfficeAddress(e.target.value)}
                        placeholder="283/2, N.C. Road, Trincomalee, Sri Lanka."
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                      />
                    </div>

                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1 font-mono">Telephone / WhatsApp</label>
                      <input
                        type="text"
                        value={aboutHeadOfficePhone}
                        onChange={(e) => setAboutHeadOfficePhone(e.target.value)}
                        placeholder={SITE_CONFIG.showroom.phone}
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                      />
                    </div>

                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1 font-mono">Description / Notes</label>
                      <textarea
                        rows={3}
                        value={aboutHeadOfficeDesc}
                        onChange={(e) => setAboutHeadOfficeDesc(e.target.value)}
                        placeholder="Our main showroom and gemological facility..."
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] leading-relaxed"
                      />
                    </div>
                  </div>

                  {/* Kalutara Office */}
                  <div className="p-4 bg-[#1C1C24] border border-[#2A2A36] rounded-sm space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono uppercase tracking-wider text-[#C5A880] font-semibold">
                        Location 2: Kalutara
                      </span>
                      <span className="text-[10px] px-2 py-0.5 bg-[#C5A880]/15 text-[#C5A880] border border-[#C5A880]/30 rounded">
                        Trading Office
                      </span>
                    </div>

                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1 font-mono">Office Title</label>
                      <input
                        type="text"
                        value={aboutKalutaraTitle}
                        onChange={(e) => setAboutKalutaraTitle(e.target.value)}
                        placeholder="Kalutara Office"
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                      />
                    </div>

                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1 font-mono">Badge / Sub-heading</label>
                      <input
                        type="text"
                        value={aboutKalutaraBadge}
                        onChange={(e) => setAboutKalutaraBadge(e.target.value)}
                        placeholder="Regional Trading Office"
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                      />
                    </div>

                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1 font-mono">Full Physical Address</label>
                      <input
                        type="text"
                        value={aboutKalutaraAddress}
                        onChange={(e) => setAboutKalutaraAddress(e.target.value)}
                        placeholder="20A, Galle Road, Kalutara, Sri Lanka."
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                      />
                    </div>

                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1 font-mono">Telephone / WhatsApp</label>
                      <input
                        type="text"
                        value={aboutKalutaraPhone}
                        onChange={(e) => setAboutKalutaraPhone(e.target.value)}
                        placeholder={SITE_CONFIG.branches.kalutara.phone}
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                      />
                    </div>

                    <div>
                      <label className="block text-[#8C867D] text-[10px] mb-1 font-mono">Description / Notes</label>
                      <textarea
                        rows={3}
                        value={aboutKalutaraDesc}
                        onChange={(e) => setAboutKalutaraDesc(e.target.value)}
                        placeholder="Our western province gemstone trading and client consultation centre..."
                        className="w-full p-2 bg-[#141419] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] leading-relaxed"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            <button type="submit" className="hidden" aria-hidden="true" tabIndex={-1} />
          </form>
        </div>
      )}

      {/* SUBTAB 5: CONTACT INFORMATION & SHOWROOM */}
      {cmsSubTab === "contact" && (
        <div className="space-y-6 w-full">
          {/* Header & Quick Action Bar */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#141419] border border-[#24242C] p-4 sm:p-5 rounded-sm">
            <div>
              <h3 className="font-sans text-base text-white font-semibold tracking-tight">
                Contact Page &amp; Showroom Information
              </h3>
              <p className="text-xs text-[#8C867D] font-sans mt-0.5">
                Customize showroom address, telephone, WhatsApp, business hours, and delivery terms shown on <span className="font-mono text-[#C5A880]">/contact</span> and the website footer.
              </p>
            </div>
            <div className="w-full sm:w-auto flex items-center gap-3">
              <button
                type="button"
                onClick={() => handleSaveContact()}
                disabled={isSavingCMS}
                className="w-full sm:w-auto min-w-[145px] px-5 py-2.5 bg-[#C5A880] hover:bg-[#E0CFA9] disabled:bg-[#44382B] disabled:cursor-not-allowed text-[#0D0D11] text-xs uppercase font-sans font-semibold tracking-wider rounded-sm transition-colors shadow-md flex items-center justify-center gap-2 cursor-pointer shrink-0 select-none whitespace-nowrap"
              >
                {isSavingCMS ? "Saving..." : "Save Changes"}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Column: Form Fields (7 cols) */}
            <form onSubmit={handleSaveContact} className="lg:col-span-7 space-y-6 text-xs font-sans">
              {/* Card 1: Page Header */}
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-4">
                <div className="border-b border-[#24242C] pb-3">
                  <h4 className="text-sm font-medium text-white uppercase tracking-wider font-mono text-[#C5A880]">
                    1. Page Header & Introduction
                  </h4>
                  <p className="text-[11px] text-[#8C867D] mt-0.5">
                    Title and introductory message at the top of the Contact page.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Page Eyebrow
                    </label>
                    <input
                      type="text"
                      value={contactPageEyebrow}
                      onChange={(e) => setContactPageEyebrow(e.target.value)}
                      placeholder="Get in Touch"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                    />
                  </div>

                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Main Title
                    </label>
                    <input
                      type="text"
                      value={contactPageTitle}
                      onChange={(e) => setContactPageTitle(e.target.value)}
                      placeholder="Book a Consultation"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                    Subtitle Description
                  </label>
                  <textarea
                    rows={2}
                    value={contactPageSubtitle}
                    onChange={(e) => setContactPageSubtitle(e.target.value)}
                    placeholder="Have a question about a gemstone? Want to visit our showroom? Or need help with a custom order? We're here to help."
                    className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] leading-relaxed"
                  />
                </div>
              </div>

              {/* Card 2: Showroom Address & Hours */}
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-4">
                <div className="border-b border-[#24242C] pb-3">
                  <h4 className="text-sm font-medium text-white uppercase tracking-wider font-mono text-[#C5A880]">
                    2. Showroom & Physical Location
                  </h4>
                  <p className="text-[11px] text-[#8C867D] mt-0.5">
                    Physical location, landline telephone, and showroom opening hours.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Card Heading
                    </label>
                    <input
                      type="text"
                      value={contactCardTitle}
                      onChange={(e) => setContactCardTitle(e.target.value)}
                      placeholder="Contact Information"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                    />
                  </div>
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Address Label
                    </label>
                    <input
                      type="text"
                      value={contactAddressLabel}
                      onChange={(e) => setContactAddressLabel(e.target.value)}
                      placeholder="Showroom Address"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                    Full Physical Address
                  </label>
                  <input
                    type="text"
                    value={contactAddress}
                    onChange={(e) => setContactAddress(e.target.value)}
                    placeholder="No. 283/2, N.C Road, Trincomalee"
                    className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                  />
                  <p className="text-[10px] text-[#8C867D] mt-1">
                    Also synchronizes automatically with the website footer Trincomalee Showroom section.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Country / Region
                    </label>
                    <input
                      type="text"
                      value={contactCountry}
                      onChange={(e) => setContactCountry(e.target.value)}
                      placeholder="Sri Lanka"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                    />
                  </div>
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Opening Hours
                    </label>
                    <input
                      type="text"
                      value={contactHours}
                      onChange={(e) => setContactHours(e.target.value)}
                      placeholder="Hours: Monday - Saturday, 9:00 AM - 6:00 PM"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                    />
                  </div>
                </div>
              </div>

              {/* Card 3: Telephone, WhatsApp & Email */}
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-4">
                <div className="border-b border-[#24242C] pb-3">
                  <h4 className="text-sm font-medium text-white uppercase tracking-wider font-mono text-[#C5A880]">
                    3. Direct WhatsApp, Phone & Email
                  </h4>
                  <p className="text-[11px] text-[#8C867D] mt-0.5">
                    Direct numbers for inquiries, concierge service, and customer responses.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Section Label
                    </label>
                    <input
                      type="text"
                      value={contactPhoneLabel}
                      onChange={(e) => setContactPhoneLabel(e.target.value)}
                      placeholder="Phone Number & WhatsApp"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                    />
                  </div>
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Phone Number 1 & WhatsApp
                    </label>
                    <input
                      type="text"
                      value={contactPhone}
                      onChange={(e) => setContactPhone(e.target.value)}
                      placeholder={SITE_CONFIG.contact.phone}
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Phone Number 2 & WhatsApp
                    </label>
                    <input
                      type="text"
                      value={contactSecondaryPhone}
                      onChange={(e) => {
                        setContactSecondaryPhone(e.target.value);
                        setContactLandline(e.target.value);
                      }}
                      placeholder={SITE_CONFIG.contact.secondaryPhone}
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                    Response Guarantee Note
                  </label>
                  <input
                    type="text"
                    value={contactResponseTime}
                    onChange={(e) => setContactResponseTime(e.target.value)}
                    placeholder="Direct response within 2 business hours"
                    className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-[#24242C]">
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Email Label
                    </label>
                    <input
                      type="text"
                      value={contactEmailLabel}
                      onChange={(e) => setContactEmailLabel(e.target.value)}
                      placeholder="Email"
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                    />
                  </div>
                  <div>
                    <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                      Concierge Email Address
                    </label>
                    <input
                      type="email"
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      placeholder={SITE_CONFIG.contact.email}
                      className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Card 4: Authenticity & Trust Assurance Card */}
              <div className="bg-[#141419] border border-[#24242C] p-4 sm:p-6 rounded-sm space-y-4">
                <div className="border-b border-[#24242C] pb-3">
                  <h4 className="text-sm font-medium text-white uppercase tracking-wider font-mono text-[#C5A880]">
                    4. Authenticity & Trust Assurance Banner
                  </h4>
                  <p className="text-[11px] text-[#8C867D] mt-0.5">
                    The highlighted dark assurance banner below the contact card on the Contact page.
                  </p>
                </div>

                <div>
                  <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                    Banner Badge / Title
                  </label>
                  <input
                    type="text"
                    value={contactDeliveryBadge}
                    onChange={(e) => setContactDeliveryBadge(e.target.value)}
                    placeholder="100% Authenticity & Lifetime Guarantee"
                    className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                  />
                </div>

                <div>
                  <label className="block text-[#C5A880] uppercase text-[10px] mb-1 font-mono">
                    Banner Trust Statement & Description
                  </label>
                  <textarea
                    rows={3}
                    value={contactDeliveryDescription}
                    onChange={(e) => setContactDeliveryDescription(e.target.value)}
                    placeholder="Every gemstone is guaranteed 100% natural, independently certified by premier gemological laboratories, and backed by our unconditional lifetime guarantee of authenticity."
                    className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] leading-relaxed"
                  />
                </div>
              </div>

              <button type="submit" className="hidden" aria-hidden="true" tabIndex={-1} />
            </form>

            {/* Right Column: Live Card Simulation (5 cols) */}
            <div className="lg:col-span-5 space-y-5">
              <div className="sticky top-6 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-mono tracking-wider text-[#A29F96]">
                    Live Contact Card Preview
                  </span>
                  <span className="px-2 py-0.5 bg-[#1F1E26] text-[#C5A880] text-[9px] uppercase font-mono rounded">
                    Client View
                  </span>
                </div>

                {/* Simulated Contact Information Card */}
                <div className="bg-white border border-[#E8E4DC] p-6 space-y-6 text-xs font-sans shadow-sm rounded-sm">
                  {contactCardTitle && (
                    <h3 className="font-serif text-lg text-[#18181D] border-b border-[#F2EFE9] pb-3 font-medium">
                      {contactCardTitle}
                    </h3>
                  )}

                  <div className="space-y-4 text-[#554F47]">
                    <div>
                      <span className="text-[#8C867D] uppercase tracking-wider text-[10px] block font-medium">
                        {contactAddressLabel || "Showroom Address"}
                      </span>
                      <p className="text-[#18181D] font-medium mt-0.5">{contactAddress || SITE_CONFIG.showroom.address}</p>
                      <p className="text-[#18181D] font-medium">{contactCountry || SITE_CONFIG.showroom.country}</p>
                      {contactHours && <p className="text-[10px] text-[#A29F96] mt-1">{contactHours}</p>}
                    </div>

                    <div className="pt-3 border-t border-[#F2EFE9] space-y-1">
                      <span className="text-[#8C867D] uppercase tracking-wider text-[10px] block font-medium">
                        {contactPhoneLabel || "Phone Number & WhatsApp"}
                      </span>
                      <p className="text-[#18181D] font-medium mt-0.5">{contactPhone || SITE_CONFIG.contact.phone}</p>
                      {(contactSecondaryPhone || contactLandline) && (
                        <p className="text-[#18181D] font-medium">
                          {contactSecondaryPhone || contactLandline}
                        </p>
                      )}
                      {contactResponseTime && (
                        <p className="text-[#8C867D] text-[10px] pt-0.5">{contactResponseTime}</p>
                      )}
                    </div>

                    <div className="pt-3 border-t border-[#F2EFE9]">
                      <span className="text-[#8C867D] uppercase tracking-wider text-[10px] block font-medium">
                        {contactEmailLabel || "Email"}
                      </span>
                      <p className="text-[#9A7B4F] font-mono mt-0.5">{contactEmail || SITE_CONFIG.contact.email}</p>
                    </div>
                  </div>
                </div>

                {/* Simulated Delivery Banner Card */}
                <div className="p-5 bg-[#18181D] text-white border border-[#2A2A32] space-y-2 text-xs font-sans rounded-sm shadow-sm">
                  <div className="flex items-center gap-2 text-[#C5A880]">
                    <span className="text-base">🏆</span>
                    <span className="uppercase tracking-wider font-medium text-[11px]">
                      {contactDeliveryBadge || "100% Authenticity & Lifetime Guarantee"}
                    </span>
                  </div>
                  <p className="text-[#D3CBBF] text-[11px] leading-relaxed">
                    {contactDeliveryDescription}
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
