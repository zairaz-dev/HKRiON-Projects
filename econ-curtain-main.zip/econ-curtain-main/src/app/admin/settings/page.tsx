"use client";

import { useState, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import {
  Building,
  Palette,
  PhoneCall,
  Share2,
  Globe,
  Shield,
  Save,
  CheckCircle2,
  AlertCircle,
  KeyRound,
  Eye,
  EyeOff,
  Lock,
  ExternalLink,
  MessageCircle,
} from "lucide-react";
import { defaultSiteSettings, SiteSettingsData } from "@/types/settings";

// Platform SVG Icons
const InstagramIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/>
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
  </svg>
);

const FacebookIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>
  </svg>
);

const LinkedInIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/>
    <rect width="4" height="12" x="2" y="9"/>
    <circle cx="4" cy="4" r="2"/>
  </svg>
);

const TikTokIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5"/>
  </svg>
);

const WhatsAppIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 21l1.65-3.8a9 9 0 1 1 3.4 2.9L3 21"/>
    <path d="M9 10a.5.5 0 0 0 1 0V9a.5.5 0 0 0-1 0v1a5 5 0 0 0 5 5h1a.5.5 0 0 0 0-1h-1a.5.5 0 0 0 0 1"/>
  </svg>
);

const YouTubeIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"/>
    <polygon points="10 15 15 12 10 9 10 15"/>
  </svg>
);

function SettingsContent() {
  const searchParams = useSearchParams();
  const initialTab = (searchParams.get("tab") as any) || "social";
  const urlSuccess = searchParams.get("success");
  const urlError = searchParams.get("error");

  const [activeTab, setActiveTab] = useState<
    "general" | "brand" | "contact" | "social" | "seo" | "security"
  >(initialTab);

  const [settings, setSettings] = useState<SiteSettingsData>(defaultSiteSettings);
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    fetch("/api/admin/settings")
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data) {
          setSettings(data);
        }
      })
      .catch((err) => console.error("Error loading settings:", err));
  }, []);

  const tabs = [
    { id: "social", label: "Social Media", icon: Share2, desc: "Instagram, Facebook, LinkedIn, TikTok & WhatsApp" },
    { id: "general", label: "General", icon: Building, desc: "Company name, logo & details" },
    { id: "brand", label: "Brand Style", icon: Palette, desc: "Colors & visual tone" },
    { id: "contact", label: "Contact & Hours", icon: PhoneCall, desc: "Hotline, email & address" },
    { id: "seo", label: "Global SEO", icon: Globe, desc: "Meta tags & descriptions" },
    { id: "security", label: "Password & Security", icon: KeyRound, desc: "Change admin password" },
  ];

  const handleInputChange = (field: keyof SiteSettingsData, value: string) => {
    setSettings((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="space-y-6 w-full pb-16">
      {/* Header */}
      <div className="bg-white dark:bg-black p-6 sm:p-7 rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 px-2.5 py-0.5 rounded-none">
              CONFIGURATION
            </span>
            <span className="text-xs text-neutral-400 dark:text-neutral-500">• Master Website Settings</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white tracking-tight">
            Global Settings Center
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Manage social media profiles (LinkedIn, TikTok, WhatsApp, Instagram, Facebook), contacts, SEO, and account security.
          </p>
        </div>

        {urlSuccess && (
          <div className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-none bg-emerald-50 dark:bg-emerald-400/10 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-400/30 text-xs font-bold animate-in fade-in">
            <CheckCircle2 size={14} />
            <span>{urlSuccess}</span>
          </div>
        )}

        {urlError && (
          <div className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-none bg-red-50 dark:bg-red-400/10 text-red-700 dark:text-red-400 border border-red-200 dark:border-red-400/30 text-xs font-bold animate-in fade-in">
            <AlertCircle size={14} />
            <span>{urlError}</span>
          </div>
        )}

        {isSaved && (
          <div className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-none bg-emerald-50 dark:bg-emerald-400/10 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-400/30 text-xs font-bold animate-in fade-in">
            <CheckCircle2 size={14} />
            <span>Settings saved successfully!</span>
          </div>
        )}
      </div>

      {/* Main Settings Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Tab Navigation (4 cols) */}
        <div className="lg:col-span-4 bg-white dark:bg-black rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs p-3 space-y-1">
          <div className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-neutral-400 dark:text-neutral-500">
            Settings Sections
          </div>
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`w-full flex items-start gap-3 p-3 rounded-none text-left transition-all cursor-pointer border ${
                  isActive
                    ? "bg-amber-50 dark:bg-amber-400/10 text-amber-950 dark:text-amber-400 border-amber-300 dark:border-amber-400/30 font-bold shadow-2xs"
                    : "bg-white dark:bg-black hover:bg-neutral-50 dark:hover:bg-neutral-900 text-neutral-700 dark:text-neutral-300 border-transparent"
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-none flex items-center justify-center shrink-0 ${
                    isActive ? "bg-amber-500 text-slate-950 font-bold" : "bg-neutral-100 dark:bg-neutral-900 text-neutral-500 dark:text-neutral-400"
                  }`}
                >
                  <Icon size={16} />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-bold truncate">{tab.label}</p>
                  <p className="text-[10px] text-neutral-400 dark:text-neutral-500 truncate">{tab.desc}</p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Right: Tab Content Form (8 cols) */}
        <div className="lg:col-span-8 bg-white dark:bg-black rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs p-6 sm:p-8">
          {/* SECURITY & PASSWORD TAB */}
          {activeTab === "security" ? (
            <form method="POST" action="/api/admin/change-password" className="space-y-6 text-xs animate-in fade-in duration-150">
              <div className="border-b border-neutral-100 dark:border-neutral-800 pb-3">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-none bg-amber-50 dark:bg-amber-400/10 text-amber-800 dark:text-amber-400 text-[10px] font-bold uppercase tracking-wider mb-1 border border-amber-200 dark:border-amber-400/30">
                  <Shield size={12} /> Security Center
                </div>
                <h3 className="text-base font-bold text-neutral-900 dark:text-white">Change Admin Password</h3>
                <p className="text-neutral-500 dark:text-neutral-400 mt-0.5">
                  Update your administrator account login password. Please choose a strong, secure password.
                </p>
              </div>

              {/* Current Password */}
              <div>
                <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Current Password
                </label>
                <div className="relative">
                  <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-500 pointer-events-none" />
                  <input
                    type={showCurrentPassword ? "text" : "password"}
                    name="currentPassword"
                    required
                    placeholder="Enter current password"
                    className="w-full pl-9 pr-10 py-2.5 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 dark:placeholder:text-neutral-500 outline-hidden font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-200 p-1 cursor-pointer"
                  >
                    {showCurrentPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>

              {/* New Password */}
              <div>
                <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">
                  New Password
                </label>
                <div className="relative">
                  <KeyRound size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-500 pointer-events-none" />
                  <input
                    type={showNewPassword ? "text" : "password"}
                    name="newPassword"
                    required
                    minLength={6}
                    placeholder="Minimum 6 characters"
                    className="w-full pl-9 pr-10 py-2.5 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 dark:placeholder:text-neutral-500 outline-hidden font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-200 p-1 cursor-pointer"
                  >
                    {showNewPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>

              {/* Confirm New Password */}
              <div>
                <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Confirm New Password
                </label>
                <div className="relative">
                  <KeyRound size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-500 pointer-events-none" />
                  <input
                    type={showConfirmPassword ? "text" : "password"}
                    name="confirmPassword"
                    required
                    minLength={6}
                    placeholder="Re-enter new password"
                    className="w-full pl-9 pr-10 py-2.5 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 dark:placeholder:text-neutral-500 outline-hidden font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-200 p-1 cursor-pointer"
                  >
                    {showConfirmPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>

              {/* Password Guidelines Card */}
              <div className="p-4 rounded-none bg-amber-50/50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 text-neutral-600 dark:text-neutral-300 space-y-1">
                <p className="font-bold text-amber-900 dark:text-amber-400 text-xs">Password Safety Guidelines:</p>
                <ul className="list-disc list-inside space-y-0.5 text-[11px] text-neutral-600 dark:text-neutral-400">
                  <li>Use at least 6 characters.</li>
                  <li>Include a mix of letters and numbers for higher security.</li>
                  <li>Do not share your administrator credentials with unauthorized staff.</li>
                </ul>
              </div>

              {/* Submit Button */}
              <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-end">
                <button
                  type="submit"
                  className="inline-flex items-center gap-1.5 px-6 py-2.5 rounded-none bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-xs cursor-pointer transition-all active:scale-95"
                >
                  <Save size={14} />
                  <span>Update Password</span>
                </button>
              </div>
            </form>
          ) : (
            <form method="POST" action="/api/admin/settings" className="space-y-6 text-xs">
              <input type="hidden" name="_tab" value={activeTab} />

              {/* 1. SOCIAL MEDIA TAB */}
              {activeTab === "social" && (
                <div className="space-y-5 animate-in fade-in duration-150">
                  <div className="border-b border-neutral-100 dark:border-neutral-800 pb-3">
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-none bg-amber-50 dark:bg-amber-400/10 text-amber-800 dark:text-amber-400 text-[10px] font-bold uppercase tracking-wider mb-1 border border-amber-200 dark:border-amber-400/30">
                      <Share2 size={12} /> Social Channels Management
                    </div>
                    <h3 className="text-base font-bold text-neutral-900 dark:text-white">Social Media Profiles & Links</h3>
                    <p className="text-neutral-500 dark:text-neutral-400 mt-0.5">
                      Configure your active social media channels. Leave any field blank if you do not want its icon to show on the website footer.
                    </p>
                  </div>

                  {/* Info Notice Box */}
                  <div className="p-4 rounded-none bg-amber-50/70 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/20 text-neutral-700 dark:text-neutral-300">
                    <p className="font-bold text-amber-900 dark:text-amber-400 text-xs flex items-center gap-1.5">
                      <CheckCircle2 size={14} className="text-amber-600 dark:text-amber-400" />
                      Dynamic Website Footer Connection
                    </p>
                    <p className="text-[11px] text-neutral-600 dark:text-neutral-400 mt-1 leading-relaxed">
                      Only social channels with valid links/numbers will appear in the public website bottom bar. When visitors click the icons, they will open your direct profile in a new tab.
                    </p>
                  </div>

                  {/* Instagram */}
                  <div className="space-y-1.5">
                    <label className="flex items-center gap-2 font-bold text-neutral-700 dark:text-neutral-300">
                      <div className="w-6 h-6 rounded-none bg-pink-500/10 text-pink-600 dark:text-pink-400 flex items-center justify-center">
                        <InstagramIcon />
                      </div>
                      <span>Instagram Profile URL</span>
                      <span className="text-[10px] text-neutral-400 font-normal">(e.g. https://instagram.com/shadeitblinds)</span>
                    </label>
                    <input
                      type="text"
                      name="instagram"
                      value={settings.instagram}
                      onChange={(e) => handleInputChange("instagram", e.target.value)}
                      placeholder="https://instagram.com/shadeitblinds"
                      className="w-full px-3.5 py-2.5 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-mono"
                    />
                  </div>

                  {/* Facebook */}
                  <div className="space-y-1.5">
                    <label className="flex items-center gap-2 font-bold text-neutral-700 dark:text-neutral-300">
                      <div className="w-6 h-6 rounded-none bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                        <FacebookIcon />
                      </div>
                      <span>Facebook Page URL</span>
                      <span className="text-[10px] text-neutral-400 font-normal">(e.g. https://facebook.com/shadeitblinds)</span>
                    </label>
                    <input
                      type="text"
                      name="facebook"
                      value={settings.facebook}
                      onChange={(e) => handleInputChange("facebook", e.target.value)}
                      placeholder="https://www.facebook.com/share/1dsD22Xaae/"
                      className="w-full px-3.5 py-2.5 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-mono"
                    />
                  </div>

                  {/* LinkedIn */}
                  <div className="space-y-1.5">
                    <label className="flex items-center gap-2 font-bold text-neutral-700 dark:text-neutral-300">
                      <div className="w-6 h-6 rounded-none bg-sky-500/10 text-sky-600 dark:text-sky-400 flex items-center justify-center">
                        <LinkedInIcon />
                      </div>
                      <span>LinkedIn Company / Profile URL</span>
                      <span className="text-[10px] text-neutral-400 font-normal">(e.g. https://linkedin.com/company/shadeit-blinds)</span>
                    </label>
                    <input
                      type="text"
                      name="linkedin"
                      value={settings.linkedin}
                      onChange={(e) => handleInputChange("linkedin", e.target.value)}
                      placeholder="https://www.linkedin.com/company/shadeitblinds"
                      className="w-full px-3.5 py-2.5 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-mono"
                    />
                  </div>

                  {/* TikTok */}
                  <div className="space-y-1.5">
                    <label className="flex items-center gap-2 font-bold text-neutral-700 dark:text-neutral-300">
                      <div className="w-6 h-6 rounded-none bg-neutral-900/10 dark:bg-white/10 text-neutral-900 dark:text-white flex items-center justify-center">
                        <TikTokIcon />
                      </div>
                      <span>TikTok Profile URL</span>
                      <span className="text-[10px] text-neutral-400 font-normal">(e.g. https://www.tiktok.com/@shadeitblinds)</span>
                    </label>
                    <input
                      type="text"
                      name="tiktok"
                      value={settings.tiktok}
                      onChange={(e) => handleInputChange("tiktok", e.target.value)}
                      placeholder="https://www.tiktok.com/@shadeitblinds"
                      className="w-full px-3.5 py-2.5 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-mono"
                    />
                  </div>

                  {/* WhatsApp */}
                  <div className="space-y-1.5">
                    <label className="flex items-center gap-2 font-bold text-neutral-700 dark:text-neutral-300">
                      <div className="w-6 h-6 rounded-none bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                        <WhatsAppIcon />
                      </div>
                      <span>WhatsApp Direct Number or Chat Link</span>
                      <span className="text-[10px] text-neutral-400 font-normal">(e.g. +94 75 807 9921 or https://wa.me/94758079921)</span>
                    </label>
                    <input
                      type="text"
                      name="whatsapp"
                      value={settings.whatsapp}
                      onChange={(e) => handleInputChange("whatsapp", e.target.value)}
                      placeholder="+94 75 807 9921"
                      className="w-full px-3.5 py-2.5 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-mono"
                    />
                  </div>

                  {/* YouTube */}
                  <div className="space-y-1.5">
                    <label className="flex items-center gap-2 font-bold text-neutral-700 dark:text-neutral-300">
                      <div className="w-6 h-6 rounded-none bg-red-500/10 text-red-600 dark:text-red-400 flex items-center justify-center">
                        <YouTubeIcon />
                      </div>
                      <span>YouTube Channel URL (Optional)</span>
                      <span className="text-[10px] text-neutral-400 font-normal">(e.g. https://youtube.com/@shadeitblinds)</span>
                    </label>
                    <input
                      type="text"
                      name="youtube"
                      value={settings.youtube}
                      onChange={(e) => handleInputChange("youtube", e.target.value)}
                      placeholder="https://youtube.com/@shadeitblinds"
                      className="w-full px-3.5 py-2.5 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-mono"
                    />
                  </div>
                </div>
              )}

              {/* 2. GENERAL TAB */}
              {activeTab === "general" && (
                <div className="space-y-4 animate-in fade-in duration-150">
                  <div className="border-b border-neutral-100 dark:border-neutral-800 pb-3">
                    <h3 className="text-base font-bold text-neutral-900 dark:text-white">General Information</h3>
                    <p className="text-neutral-500 dark:text-neutral-400 mt-0.5">Primary business name, tagline, and display branding.</p>
                  </div>

                  <div>
                    <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">Company / Brand Name</label>
                    <input
                      type="text"
                      name="companyName"
                      value={settings.companyName}
                      onChange={(e) => handleInputChange("companyName", e.target.value)}
                      className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">Business Tagline</label>
                    <input
                      type="text"
                      name="tagline"
                      value={settings.tagline}
                      onChange={(e) => handleInputChange("tagline", e.target.value)}
                      className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">Established Year</label>
                      <input
                        type="text"
                        name="establishedYear"
                        value={settings.establishedYear}
                        onChange={(e) => handleInputChange("establishedYear", e.target.value)}
                        className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">Currency Symbol</label>
                      <input
                        type="text"
                        name="currencySymbol"
                        value={settings.currencySymbol}
                        onChange={(e) => handleInputChange("currencySymbol", e.target.value)}
                        className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* 3. BRAND STYLE TAB */}
              {activeTab === "brand" && (
                <div className="space-y-4 animate-in fade-in duration-150">
                  <div className="border-b border-neutral-100 dark:border-neutral-800 pb-3">
                    <h3 className="text-base font-bold text-neutral-900 dark:text-white">Brand Style & Aesthetics</h3>
                    <p className="text-neutral-500 dark:text-neutral-400 mt-0.5">Control signature accents and visual tone.</p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="p-4 rounded-none border border-amber-300 dark:border-amber-400/40 bg-amber-50/40 dark:bg-amber-400/10 space-y-2">
                      <span className="text-[10px] font-bold uppercase text-amber-800 dark:text-amber-400">Primary Accent</span>
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-none bg-amber-500 shadow-xs" />
                        <div>
                          <div className="font-bold text-neutral-900 dark:text-white">SHADEIT Signature Gold</div>
                          <div className="text-[11px] text-neutral-500 dark:text-neutral-400 font-mono">#F59E0B / Amber 500</div>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 rounded-none border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-black space-y-2">
                      <span className="text-[10px] font-bold uppercase text-neutral-600 dark:text-neutral-400">Website Theme</span>
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-none bg-black border border-neutral-800 shadow-xs" />
                        <div>
                          <div className="font-bold text-neutral-900 dark:text-white">Pure Black Canvas</div>
                          <div className="text-[11px] text-neutral-500 dark:text-neutral-400 font-mono">#000000 / Pure Black</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 4. CONTACT TAB */}
              {activeTab === "contact" && (
                <div className="space-y-4 animate-in fade-in duration-150">
                  <div className="border-b border-neutral-100 dark:border-neutral-800 pb-3">
                    <h3 className="text-base font-bold text-neutral-900 dark:text-white">Contact Details & WhatsApp Direct</h3>
                    <p className="text-neutral-500 dark:text-neutral-400 mt-0.5">Where inquiries and floating WhatsApp buttons route to.</p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">WhatsApp Direct Number</label>
                      <input
                        type="text"
                        name="whatsapp"
                        value={settings.whatsapp}
                        onChange={(e) => handleInputChange("whatsapp", e.target.value)}
                        className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">Support Email</label>
                      <input
                        type="email"
                        name="email"
                        value={settings.email}
                        onChange={(e) => handleInputChange("email", e.target.value)}
                        className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">Showroom Address</label>
                    <input
                      type="text"
                      name="address"
                      value={settings.address}
                      onChange={(e) => handleInputChange("address", e.target.value)}
                      className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">Working Hours</label>
                    <input
                      type="text"
                      name="workingHours"
                      value={settings.workingHours}
                      onChange={(e) => handleInputChange("workingHours", e.target.value)}
                      className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                    />
                  </div>
                </div>
              )}

              {/* 5. SEO TAB */}
              {activeTab === "seo" && (
                <div className="space-y-4 animate-in fade-in duration-150">
                  <div className="border-b border-neutral-100 dark:border-neutral-800 pb-3">
                    <h3 className="text-base font-bold text-neutral-900 dark:text-white">Search Engine Optimization (SEO)</h3>
                    <p className="text-neutral-500 dark:text-neutral-400 mt-0.5">Global meta titles and social share cards.</p>
                  </div>

                  <div>
                    <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">Default Meta Title</label>
                    <input
                      type="text"
                      name="metaTitle"
                      value={settings.metaTitle}
                      onChange={(e) => handleInputChange("metaTitle", e.target.value)}
                      className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">Meta Description</label>
                    <textarea
                      rows={3}
                      name="metaDescription"
                      value={settings.metaDescription}
                      onChange={(e) => handleInputChange("metaDescription", e.target.value)}
                      className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                    />
                  </div>
                </div>
              )}

              {/* Save Button Bar */}
              <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-end">
                <button
                  type="submit"
                  className="inline-flex items-center gap-1.5 px-6 py-2.5 rounded-none bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-xs cursor-pointer transition-all active:scale-95"
                >
                  <Save size={14} />
                  <span>Save All Settings</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

export default function AdminSettingsPage() {
  return (
    <Suspense fallback={<div className="p-8 text-neutral-400 dark:text-neutral-500">Loading settings...</div>}>
      <SettingsContent />
    </Suspense>
  );
}


