import * as React from "react"
import { cn } from "@/lib/utils"
import { ChevronDown, Check, Search } from "lucide-react"

/**
 * ==========================================================================
 * SelectProps Interface
 * ==========================================================================
 */
export interface SelectProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /**
   * Currently selected value.
   */
  value?: string;
  /**
   * Triggered when a new option is selected (custom React State style).
   */
  onValueChange?: (value: string) => void;
  /**
   * Triggered with a mock HTML change event (native form compatibility).
   */
  onChange?: (e: any) => void;
  /**
   * If true, enables a search input at the top of the dropdown menu to filter options.
   */
  showSearch?: boolean;
  /**
   * Optional icon to display on the left side of the select trigger button.
   */
  icon?: React.ReactNode;
}

/**
 * ==========================================================================
 * Reusable Select (Dropdown) Component
 * ==========================================================================
 * 
 * A premium custom dropdown component. Supports:
 * - Traditional `<select>` & `<option>` children structure parsing.
 * - Optional sticky search bar filtering.
 * - Click outside detection to close the dropdown.
 * - Smooth transition animations and dark glassmorphism styling.
 * - Optional left-aligned icon.
 */
const Select = React.forwardRef<HTMLButtonElement, SelectProps>(
  ({ className, children, value, onValueChange, onChange, disabled, showSearch = false, icon, ...props }, ref) => {
    const [isOpen, setIsOpen] = React.useState(false);
    const [searchQuery, setSearchQuery] = React.useState("");
    const containerRef = React.useRef<HTMLDivElement>(null);
    const searchInputRef = React.useRef<HTMLInputElement>(null);

    // Parse traditional HTML <option> elements from React Children dynamically
    const options = React.useMemo(() => {
      const opts: { value: string; label: string }[] = [];
      React.Children.forEach(children, (child) => {
        if (React.isValidElement(child)) {
          if (child.type === "option") {
            opts.push({
              value: String(child.props.value || ""),
              label: String(child.props.children || ""),
            });
          }
        }
      });
      return opts;
    }, [children]);

    // Filter options based on search query when search is enabled
    const filteredOptions = React.useMemo(() => {
      if (!showSearch || !searchQuery) return options;
      return options.filter((opt) =>
        opt.label.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }, [options, searchQuery, showSearch]);

    const selectedOption = options.find((opt) => opt.value === value);

    const handleSelect = (val: string) => {
      if (onValueChange) onValueChange(val);
      if (onChange) {
        // Create a mock change event to mimic standard HTML select behavior
        onChange({ target: { value: val } } as any);
      }
      setIsOpen(false);
      setSearchQuery(""); // Reset search query on select
    };

    // Close the dropdown when clicking anywhere outside of the component
    React.useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
        if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
          setIsOpen(false);
          setSearchQuery(""); // Reset search query on close
        }
      };
      document.addEventListener("mousedown", handleClickOutside);
      return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    // Auto-focus search input when dropdown opens
    React.useEffect(() => {
      if (isOpen && showSearch) {
        const timer = setTimeout(() => {
          searchInputRef.current?.focus();
        }, 50);
        return () => clearTimeout(timer);
      }
    }, [isOpen, showSearch]);

    return (
      // Container wrapper: dynamically receives z-30 when open to overlay over sibling components
      <div className={cn("relative w-full", isOpen && "z-30")} ref={containerRef}>
        
        {/* Dropdown Trigger Button */}
        <button
          type="button"
          ref={ref}
          disabled={disabled}
          onClick={() => setIsOpen(!isOpen)}
          className={cn(
            "flex h-10 w-full items-center justify-between rounded-sm border border-input bg-background/50 hover:bg-secondary/30 px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary disabled:cursor-not-allowed disabled:opacity-50 transition-all text-left",
            icon && "pl-10",
            className
          )}
          {...props}
        >
          {icon && (
            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground/60">
              {icon}
            </div>
          )}
          <span className={cn(!selectedOption && "text-muted-foreground/60")}>
            {selectedOption ? selectedOption.label : "Select..."}
          </span>
          <ChevronDown 
            className={cn(
              "w-4 h-4 text-muted-foreground transition-transform duration-200", 
              isOpen && "transform rotate-180"
            )} 
          />
        </button>

        {/* Dropdown Overlay Menu */}
        {isOpen && (
          <div className="absolute z-50 mt-1.5 w-full rounded-sm border border-border bg-card/95 backdrop-blur-md p-1 shadow-2xl max-h-60 overflow-y-auto animate-in fade-in slide-in-from-top-1 duration-150">
            
            {/* Search Input field (Only rendered when showSearch={true}) */}
            {showSearch && (
              <div className="p-2 border-b border-border sticky top-0 bg-card/95 backdrop-blur-md z-10">
                <div className="relative">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                  <input
                    ref={searchInputRef}
                    type="text"
                    placeholder="Search..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onClick={(e) => e.stopPropagation()} // Prevent closing dropdown on input click
                    className="h-8 w-full rounded-sm border border-input bg-card/60 pl-8 pr-3 text-xs text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-1 focus:ring-primary transition-all"
                  />
                </div>
              </div>
            )}

            {/* Rendered Options List */}
            <div className="py-1">
              {filteredOptions.length > 0 ? (
                filteredOptions.map((opt) => (
                  <div
                    key={opt.value}
                    onClick={() => handleSelect(opt.value)}
                    className={cn(
                      "relative flex w-full cursor-pointer select-none items-center justify-between rounded-sm px-3 py-2 text-sm text-muted-foreground hover:bg-accent hover:text-foreground transition-colors",
                      opt.value === value && "bg-primary/10 text-primary font-semibold"
                    )}
                  >
                    <span>{opt.label}</span>
                    {opt.value === value && <Check className="w-3.5 h-3.5 text-primary" />}
                  </div>
                ))
              ) : (
                // Shown when no option matches the search query
                <div className="py-3 text-center text-xs text-muted-foreground font-mono">
                  No results found
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  }
);
Select.displayName = "Select"

export { Select }
