export class UpdateEmailSettingsDto {
  businessId?: string;
  enableEmailNotifications?: boolean;
  mailDriver?: string;
  mailHost?: string;
  mailPort?: number;
  mailUsername?: string;
  mailPassword?: string;
  mailEncryption?: string;
  mailFromAddress?: string;
  mailFromName?: string;

  sendSaleInvoiceEmail?: boolean;
  sendPaymentReceiptEmail?: boolean;
  sendPurchaseOrderEmail?: boolean;
}

export class TestEmailDto {
  businessId?: string;
  recipientEmail: string;
}
