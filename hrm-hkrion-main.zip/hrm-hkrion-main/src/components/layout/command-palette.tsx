"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { 
  Search, 
  LayoutDashboard, 
  ClipboardCheck, 
  Users, 
  Briefcase, 
  CalendarClock, 
  CalendarOff, 
  Settings, 
  BarChart3, 
  Plus, 
  User, 
  Shield, 
  Moon, 
  Sun,
  ArrowRight,
  Command,
  X
} from "lucide-react";
import { useTheme } from "@/components/theme-provider";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

interface CommandItem {
  id: string;
  title: string;
  category: "Navigation" | "Actions" | "Preferences";
  icon: React.ReactNode;
  href?: string;
  action?: () => void;
  keywords?: string;
}

export function CommandPalette({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const router = useRouter();
  const { theme, setTheme } = useTheme();
  const [query, setQuery] = useState("");
  const [selectedIndex, setSelectedIndex] = useState(0);

  const isDark = theme === "dark";

  const commands: CommandItem[] = [
    // Navigation
    { id: "nav-dashboard", title: "Dashboard Overview", category: "Navigation", icon: <LayoutDashboard className="h-4 w-4" />, href: "/dashboard", keywords: "home stats analytics" },
    { id: "nav-tasks", title: "Task Workspace", category: "Navigation", icon: <ClipboardCheck className="h-4 w-4" />, href: "/dashboard/tasks", keywords: "todos projects milestones" },
    { id: "nav-employees", title: "Employees Directory", category: "Navigation", icon: <Users className="h-4 w-4" />, href: "/dashboard/employees", keywords: "team staff people directory" },
    { id: "nav-positions", title: "Positions & Hierarchy", category: "Navigation", icon: <Briefcase className="h-4 w-4" />, href: "/dashboard/positions", keywords: "jobs roles hierarchy org" },
    { id: "nav-attendance", title: "Attendance Tracking", category: "Navigation", icon: <CalendarClock className="h-4 w-4" />, href: "/dashboard/attendance", keywords: "clock in clock out time timesheet" },
    { id: "nav-leaves", title: "Leaves & Time Off", category: "Navigation", icon: <CalendarOff className="h-4 w-4" />, href: "/dashboard/leaves", keywords: "vacation sick off holiday" },
    { id: "nav-manager", title: "Manager Analytics", category: "Navigation", icon: <BarChart3 className="h-4 w-4" />, href: "/dashboard/manager", keywords: "reports team performance" },
    { id: "nav-settings-profile", title: "Profile Settings", category: "Navigation", icon: <User className="h-4 w-4" />, href: "/dashboard/settings?tab=profile", keywords: "account user info" },
    { id: "nav-settings-security", title: "Security & Passwords", category: "Navigation", icon: <Shield className="h-4 w-4" />, href: "/dashboard/settings?tab=security", keywords: "password 2fa auth" },
    
    // Quick Actions
    { id: "act-create-task", title: "Create New Task", category: "Actions", icon: <Plus className="h-4 w-4 text-primary" />, href: "/dashboard/tasks/create", keywords: "new todo add assign" },
    
    // Preferences
    { 
      id: "pref-theme", 
      title: isDark ? "Switch to Light Mode" : "Switch to Dark Mode", 
      category: "Preferences", 
      icon: isDark ? <Sun className="h-4 w-4 text-warning" /> : <Moon className="h-4 w-4 text-text-secondary" />, 
      action: () => setTheme(isDark ? "light" : "dark"),
      keywords: "theme dark light mode color"
    },
  ];

  const filteredCommands = commands.filter((cmd) => {
    if (!query.trim()) return true;
    const q = query.toLowerCase();
    return (
      cmd.title.toLowerCase().includes(q) ||
      cmd.category.toLowerCase().includes(q) ||
      (cmd.keywords && cmd.keywords.toLowerCase().includes(q))
    );
  });

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        if (isOpen) onClose();
        else {
          // Open triggered by parent state
        }
      }

      if (!isOpen) return;

      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
      } else if (e.key === "ArrowDown") {
        e.preventDefault();
        setSelectedIndex((prev) => (prev + 1) % (filteredCommands.length || 1));
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setSelectedIndex((prev) => (prev - 1 + filteredCommands.length) % (filteredCommands.length || 1));
      } else if (e.key === "Enter") {
        e.preventDefault();
        const selected = filteredCommands[selectedIndex];
        if (selected) {
          executeCommand(selected);
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, selectedIndex, filteredCommands]);

  const executeCommand = (cmd: CommandItem) => {
    onClose();
    if (cmd.action) {
      cmd.action();
    } else if (cmd.href) {
      router.push(cmd.href);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 sm:pt-28 px-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            onClick={onClose}
          />

          {/* Palette Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -10 }}
            transition={{ duration: 0.15 }}
            className="relative w-full max-w-xl rounded-2xl border border-border bg-surface shadow-2xl overflow-hidden z-10"
          >
            {/* Search Input Box */}
            <div className="flex items-center gap-3 px-4 py-3.5 border-b border-border bg-surface-secondary/30">
              <Search className="h-4 w-4 text-text-muted shrink-0" />
              <input
                type="text"
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Type a command or search pages..."
                className="w-full bg-transparent text-sm text-text-primary placeholder:text-text-muted focus:outline-none"
              />
              <span className="text-[10px] font-mono font-semibold px-1.5 py-0.5 rounded border border-border bg-surface text-text-muted shrink-0">
                ESC
              </span>
            </div>

            {/* Results List */}
            <div className="max-h-80 overflow-y-auto p-2 space-y-1 custom-scrollbar">
              {filteredCommands.length === 0 ? (
                <div className="py-10 text-center text-xs text-text-muted">
                  No commands or pages matching &quot;{query}&quot;
                </div>
              ) : (
                filteredCommands.map((cmd, idx) => {
                  const isSelected = idx === selectedIndex;
                  return (
                    <button
                      key={cmd.id}
                      type="button"
                      onClick={() => executeCommand(cmd)}
                      onMouseEnter={() => setSelectedIndex(idx)}
                      className={cn(
                        "w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all text-left cursor-pointer",
                        isSelected 
                          ? "bg-primary text-white shadow-xs" 
                          : "text-text-primary hover:bg-surface-secondary"
                      )}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className={cn(
                          "shrink-0 p-1 rounded-md",
                          isSelected ? "text-white bg-white/20" : "text-text-secondary bg-surface-secondary"
                        )}>
                          {cmd.icon}
                        </span>
                        <span className="truncate">{cmd.title}</span>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className={cn(
                          "text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded",
                          isSelected ? "text-white/80 bg-white/10" : "text-text-muted bg-surface-secondary"
                        )}>
                          {cmd.category}
                        </span>
                        {isSelected && <ArrowRight className="h-3 w-3 text-white" />}
                      </div>
                    </button>
                  );
                })
              )}
            </div>

            {/* Footer tips */}
            <div className="flex items-center justify-between px-4 py-2 bg-surface-secondary/40 border-t border-border text-[11px] text-text-muted">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1">
                  <kbd className="font-mono bg-surface border border-border px-1 rounded text-[9px]">↑</kbd>
                  <kbd className="font-mono bg-surface border border-border px-1 rounded text-[9px]">↓</kbd>
                  <span>Navigate</span>
                </span>
                <span className="flex items-center gap-1">
                  <kbd className="font-mono bg-surface border border-border px-1 rounded text-[9px]">↵</kbd>
                  <span>Open</span>
                </span>
              </div>
              <span>HKRiON Fast Navigation</span>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
