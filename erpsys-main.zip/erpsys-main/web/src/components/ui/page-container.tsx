import * as React from "react"
import { cn } from "@/lib/utils"

export interface PageContainerProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  size?: "default" | "sm" | "lg" | "full";
  withGlows?: boolean;
}

const PageContainer = React.forwardRef<HTMLDivElement, PageContainerProps>(
  ({ className, children, size = "default", withGlows = true, ...props }, ref) => {
    
    // Determine maximum width based on size prop
    const maxWidthClass = {
      sm: "max-w-3xl",
      default: "max-w-5xl",
      lg: "max-w-7xl",
      full: "max-w-full",
    }[size];

    return (
      <div 
        className="min-h-screen relative w-full bg-background text-foreground flex flex-col overflow-x-hidden p-4 md:p-8 animate-in fade-in duration-300 no-scrollbar"
      >
        {/* Background Glows */}
        {withGlows && (
          <>
            <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-emerald-500/5 blur-[120px] pointer-events-none z-0" />
            <div className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] rounded-full bg-teal-500/5 blur-[150px] pointer-events-none z-0" />
          </>
        )}

        {/* Content Wrapper */}
        <div 
          ref={ref}
          className={cn("relative z-10 w-full mx-auto flex-1 flex flex-col", maxWidthClass, className)}
          {...props}
        >
          {children}
        </div>
      </div>
    );
  }
);
PageContainer.displayName = "PageContainer"

export { PageContainer }
