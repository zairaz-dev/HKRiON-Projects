import { NextResponse } from "next/server";
import { UserService } from "@/services/user.service";
import { SessionManager } from "@/core/auth/session";
import { SafeHttp } from "@/core/http/redirect";

export async function POST(request: Request) {
  try {
    const session = await SessionManager.getCurrentSession();
    if (!session) {
      return SafeHttp.redirect("/login", request, 303);
    }

    const contentType = request.headers.get("content-type") || "";
    const isJson = contentType.includes("application/json");

    let currentPassword = "";
    let newPassword = "";
    let confirmPassword = "";

    if (isJson) {
      const body = await request.json();
      currentPassword = body.currentPassword;
      newPassword = body.newPassword;
      confirmPassword = body.confirmPassword;
    } else {
      const formData = await request.formData();
      currentPassword = formData.get("currentPassword") as string;
      newPassword = formData.get("newPassword") as string;
      confirmPassword = formData.get("confirmPassword") as string;
    }

    if (newPassword !== confirmPassword) {
      if (isJson) {
        return NextResponse.json(
          { success: false, error: "New password and confirmation do not match." },
          { status: 400 }
        );
      }
      return SafeHttp.redirect(
        `/admin/settings?tab=security&error=${encodeURIComponent("New password and confirmation do not match.")}`,
        request,
        303
      );
    }

    const result = await UserService.changePassword(
      session.userId,
      currentPassword,
      newPassword
    );

    if (!result.success) {
      if (isJson) {
        return NextResponse.json({ success: false, error: result.error }, { status: 400 });
      }
      return SafeHttp.redirect(
        `/admin/settings?tab=security&error=${encodeURIComponent(result.error || "Failed to update password.")}`,
        request,
        303
      );
    }

    if (isJson) {
      return NextResponse.json({ success: true, message: "Password updated successfully!" });
    }

    return SafeHttp.redirect(
      `/admin/settings?tab=security&success=${encodeURIComponent("Password changed successfully!")}`,
      request,
      303
    );
  } catch (error) {
    console.error("Change password error:", error);
    return SafeHttp.redirect(
      `/admin/settings?tab=security&error=${encodeURIComponent("An unexpected error occurred.")}`,
      request,
      303
    );
  }
}
