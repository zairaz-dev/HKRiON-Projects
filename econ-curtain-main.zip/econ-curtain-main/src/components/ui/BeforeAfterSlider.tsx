"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { MoveHorizontal } from "lucide-react";

interface BeforeAfterSliderProps {
  beforeImage: string;
  afterImage: string;
  beforeLabel?: string;
  afterLabel?: string;
}

export default function BeforeAfterSlider({
  beforeImage,
  afterImage,
  beforeLabel = "Plain Window",
  afterLabel = "With SHADEIT Blinds"
}: BeforeAfterSliderProps) {
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const isPointerDraggingRef = useRef(false);

  // Position calculation from clientX
  const updatePosition = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    if (rect.width <= 0) return;

    const x = clientX - rect.left;
    const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSliderPosition(Math.round(percentage * 10) / 10);
  }, []);

  // Subtle nudge animation on initial mount to demonstrate draggability
  useEffect(() => {
    const timer1 = setTimeout(() => setSliderPosition(40), 1000);
    const timer2 = setTimeout(() => setSliderPosition(60), 1600);
    const timer3 = setTimeout(() => setSliderPosition(50), 2200);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, []);

  // Mobile Touch Listener with non-passive touchmove for 100% reliable swipe on iOS & Android
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    let startX = 0;
    let isSliding = false;

    const onTouchStart = (e: TouchEvent) => {
      if (e.touches && e.touches[0]) {
        startX = e.touches[0].clientX;
        isSliding = true;
        setIsDragging(true);
        updatePosition(e.touches[0].clientX);
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (!isSliding || !e.touches || !e.touches[0]) return;
      
      // Prevent screen from scrolling vertically while user is dragging slider horizontally
      if (e.cancelable) {
        e.preventDefault();
      }
      updatePosition(e.touches[0].clientX);
    };

    const onTouchEnd = () => {
      isSliding = false;
      setIsDragging(false);
    };

    el.addEventListener("touchstart", onTouchStart, { passive: true });
    el.addEventListener("touchmove", onTouchMove, { passive: false });
    el.addEventListener("touchend", onTouchEnd, { passive: true });
    el.addEventListener("touchcancel", onTouchEnd, { passive: true });

    return () => {
      el.removeEventListener("touchstart", onTouchStart);
      el.removeEventListener("touchmove", onTouchMove);
      el.removeEventListener("touchend", onTouchEnd);
      el.removeEventListener("touchcancel", onTouchEnd);
    };
  }, [updatePosition]);

  // Desktop Mouse / Pointer Events
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === "touch") return; // Handled natively by touch listeners
    isPointerDraggingRef.current = true;
    setIsDragging(true);
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {}
    updatePosition(e.clientX);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === "touch" || !isPointerDraggingRef.current) return;
    updatePosition(e.clientX);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === "touch") return;
    isPointerDraggingRef.current = false;
    setIsDragging(false);
    try {
      if (e.currentTarget.hasPointerCapture(e.pointerId)) {
        e.currentTarget.releasePointerCapture(e.pointerId);
      }
    } catch {}
  };

  const handlePointerCancel = () => {
    isPointerDraggingRef.current = false;
    setIsDragging(false);
  };

  // Keyboard accessibility
  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "ArrowLeft") {
      e.preventDefault();
      setSliderPosition((prev) => Math.max(0, prev - 5));
    } else if (e.key === "ArrowRight") {
      e.preventDefault();
      setSliderPosition((prev) => Math.min(100, prev + 5));
    }
  };

  return (
    <div
      ref={containerRef}
      role="slider"
      aria-label="Before and after transformation comparison slider"
      aria-valuenow={Math.round(sliderPosition)}
      aria-valuemin={0}
      aria-valuemax={100}
      tabIndex={0}
      onKeyDown={handleKeyDown}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerCancel}
      onClick={(e) => updatePosition(e.clientX)}
      style={{ touchAction: "pan-y" }}
      className="relative w-full h-[360px] sm:h-[480px] md:h-[550px] rounded-3xl overflow-hidden shadow-2xl select-none border border-slate-700/80 cursor-ew-resize focus:outline-hidden focus:ring-2 focus:ring-amber-400"
    >
      {/* After Image (Background Layer) */}
      <img
        src={afterImage}
        alt={afterLabel}
        className="absolute inset-0 w-full h-full object-cover pointer-events-none select-none"
        draggable={false}
      />
      <div className="absolute top-4 right-4 z-10 bg-black/80 backdrop-blur-md text-amber-400 border border-amber-500/40 px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-bold shadow-lg pointer-events-none select-none">
        {afterLabel}
      </div>

      {/* Before Image (Top Layer clipped with CSS inset for universal mobile support) */}
      <div
        className="absolute inset-0 w-full h-full pointer-events-none select-none"
        style={{
          clipPath: `inset(0 ${100 - sliderPosition}% 0 0)`,
          WebkitClipPath: `inset(0 ${100 - sliderPosition}% 0 0)`
        }}
      >
        <img
          src={beforeImage}
          alt={beforeLabel}
          className="absolute inset-0 w-full h-full object-cover pointer-events-none select-none"
          draggable={false}
        />
        <div className="absolute top-4 left-4 z-10 bg-slate-950/85 backdrop-blur-md text-slate-200 border border-white/20 px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-bold shadow-lg pointer-events-none select-none">
          {beforeLabel}
        </div>
      </div>

      {/* Vertical Divider Line */}
      <div
        className="absolute top-0 bottom-0 z-20 w-1 bg-white shadow-2xl pointer-events-none -translate-x-1/2"
        style={{ left: `${sliderPosition}%` }}
      />

      {/* Large Extended Touch-Friendly Handle Area */}
      <div
        className="absolute top-0 bottom-0 z-30 w-16 -translate-x-1/2 flex items-center justify-center pointer-events-none"
        style={{ left: `${sliderPosition}%` }}
      >
        {/* Center Knob */}
        <div
          className={`w-12 h-12 sm:w-14 sm:h-14 bg-amber-400 text-slate-950 rounded-full flex items-center justify-center shadow-2xl border-2 border-white transition-transform duration-75 ${
            isDragging ? "scale-115 shadow-amber-400/80 ring-4 ring-amber-400/40" : ""
          }`}
        >
          <MoveHorizontal size={24} className="stroke-[2.5]" />
        </div>
      </div>

      {/* Subtle Hint Text at bottom */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-10 bg-slate-950/70 backdrop-blur-xs text-slate-300 text-[11px] sm:text-xs font-medium px-3 py-1 rounded-full border border-white/10 pointer-events-none select-none">
        Drag or tap anywhere to slide
      </div>
    </div>
  );
}



