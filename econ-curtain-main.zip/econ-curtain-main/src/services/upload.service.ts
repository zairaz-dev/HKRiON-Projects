import { writeFile, mkdir } from "fs/promises";
import { join } from "path";
import sharp from "sharp";

export class UploadService {
  private static readonly MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 MB
  private static readonly ALLOWED_MIME_TYPES = new Set([
    "image/jpeg",
    "image/jpg",
    "image/png",
    "image/webp",
    "image/avif",
  ]);

  /**
   * Processes and safely saves an uploaded image file.
   * Validates file size, enforces strict MIME types, sanitizes filename,
   * applies compression and watermark via Sharp.
   * @param file The file to upload
   * @returns The public URL of the securely saved image
   */
  static async processAndSave(file: File): Promise<string> {
    // 1. Enforce file size limit (5MB)
    if (file.size > this.MAX_FILE_SIZE) {
      throw new Error(`File "${file.name}" exceeds the maximum allowed size of 5MB.`);
    }

    // 2. Validate MIME type strictly (Disallow SVGs, HTML, scripts)
    const mimeType = (file.type || "").toLowerCase().trim();
    if (!this.ALLOWED_MIME_TYPES.has(mimeType)) {
      throw new Error(
        `Invalid file type "${mimeType}". Only JPG, PNG, WEBP, and AVIF image formats are allowed.`
      );
    }

    const uploadsDir = join(process.cwd(), "public", "uploads");
    await mkdir(uploadsDir, { recursive: true });

    const watermarkPath = join(process.cwd(), "public", "shadeit_watermark.png");
    const bytes = await file.arrayBuffer();
    let buffer = Buffer.from(bytes);

    // 3. Process image with Sharp (ensures binary is a valid image & strips malicious embedded tags)
    try {
      const sharpInstance = sharp(buffer);
      const metadata = await sharpInstance.metadata();

      if (!metadata.format) {
        throw new Error("Invalid or corrupted image file structure.");
      }

      // Re-encode to safe WEBP format with watermark
      try {
        buffer = await sharpInstance
          .resize({ width: 1920, withoutEnlargement: true })
          .composite([{ input: watermarkPath, gravity: "center" }])
          .webp({ quality: 85 })
          .toBuffer();
      } catch {
        // Fallback without watermark if watermark file is missing
        buffer = await sharp(buffer)
          .resize({ width: 1920, withoutEnlargement: true })
          .webp({ quality: 85 })
          .toBuffer();
      }
    } catch (sharpError: unknown) {
      console.error("Image processing / validation error:", sharpError);
      const message = sharpError instanceof Error ? sharpError.message : "Failed to process image file safely.";
      throw new Error(message);
    }

    // 4. Generate sanitized safe filename
    const safeBaseName = file.name
      .replace(/\.[^/.]+$/, "")
      .replace(/[^a-zA-Z0-9_-]/g, "_")
      .substring(0, 50);

    const uniqueName = `${Date.now()}-${safeBaseName || "upload"}.webp`;
    const finalPath = join(uploadsDir, uniqueName);

    await writeFile(finalPath, buffer);
    return `/uploads/${uniqueName}`;
  }
}
