import { ContactService } from "@/services/contact.service";
import {
  Sparkles,
  Save,
  Globe,
  Phone,
  Mail,
  MapPin,
  Clock,
  ExternalLink,
  Zap,
  Send,
  MessageSquare,
} from "lucide-react";
import Link from "next/link";

export const dynamic = "force-dynamic";

interface AdminContactPageProps {
  searchParams?: Promise<{ tab?: string; success?: string; error?: string }>;
}

export default async function AdminContactPageCMS({ searchParams }: AdminContactPageProps) {
  const params = await searchParams;
  const activeTab = params?.tab || "details";
  const content = await ContactService.getContent();

  const tabs = [
    { id: "details", label: "Contact Details & Channels", icon: Phone, count: "9 fields" },
    { id: "header", label: "Page Header", icon: Sparkles, count: "3 fields" },
    { id: "form", label: "Inquiry Form Copy", icon: Send, count: "3 fields" },
  ];

  return (
    <div className="space-y-6 w-full pb-20">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-black p-6 sm:p-8 rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-none bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 text-amber-700 dark:text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
            <MessageSquare size={14} /> Live Site CMS
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white tracking-tight">
            Contact Page Content Editor
          </h1>
          <p className="text-neutral-500 dark:text-neutral-400 text-xs sm:text-sm mt-1">
            Update your phone, email, WhatsApp, showroom address, working hours, and inquiry form texts in real-time.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/admin/cms"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-none bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-900 dark:hover:bg-neutral-850 text-neutral-800 dark:text-neutral-200 border border-[#E5E5E0] dark:border-neutral-800 text-xs font-bold transition-all"
          >
            <span>← Back to CMS Hub</span>
          </Link>
          <Link
            href="/contact"
            target="_blank"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-none bg-emerald-50 dark:bg-emerald-500/10 hover:bg-emerald-100 dark:hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-500/30 text-xs font-bold transition-all"
          >
            <Globe size={15} />
            <span>View Contact Page</span>
            <ExternalLink size={13} className="text-emerald-500 dark:text-emerald-400" />
          </Link>
        </div>
      </div>

      {/* Main CMS Form */}
      <form method="POST" action="/api/admin/contact" className="space-y-6">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <Link
                key={tab.id}
                href={`/admin/contact?tab=${tab.id}`}
                scroll={false}
                className={`flex items-center gap-2.5 px-5 py-3 rounded-none text-xs font-bold transition-all whitespace-nowrap border shrink-0 ${
                  isActive
                    ? "bg-amber-500 text-slate-950 border-amber-600 shadow-xs"
                    : "bg-white dark:bg-black text-neutral-600 dark:text-neutral-400 border-[#E5E5E0] dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-900 hover:text-neutral-900 dark:hover:text-white"
                }`}
              >
                <Icon size={16} className={isActive ? "text-slate-950" : "text-neutral-400 dark:text-neutral-500"} />
                <span>{tab.label}</span>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-none font-medium ${
                    isActive ? "bg-slate-950/20 text-slate-950" : "bg-neutral-100 dark:bg-neutral-950 text-neutral-500 dark:text-neutral-500"
                  }`}
                >
                  {tab.count}
                </span>
              </Link>
            );
          })}
        </div>

        {/* TAB 1: CONTACT DETAILS & CHANNELS */}
        {activeTab === "details" && (
          <div className="bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none p-6 sm:p-8 space-y-6 shadow-xs">
            <div className="border-b border-neutral-100 dark:border-neutral-800 pb-4">
              <h2 className="text-lg font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                <Phone className="text-amber-500" size={18} />
                <span>Direct Contact Channels & Showroom Details</span>
              </h2>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                These contact coordinates appear on the contact page and customer communication sections.
              </p>
            </div>

            {/* Section Info Text */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Section Header Title
                </label>
                <input
                  type="text"
                  name="sectionTitle"
                  defaultValue={content.sectionTitle}
                  placeholder="Contact Details"
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  WhatsApp Direct Number
                </label>
                <input
                  type="text"
                  name="whatsapp"
                  defaultValue={content.whatsapp}
                  placeholder="+94 75 807 9921"
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm font-mono focus:outline-none focus:ring-1 focus:ring-amber-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                Section Introduction Description
              </label>
              <textarea
                name="sectionDescription"
                rows={2}
                defaultValue={content.sectionDescription}
                placeholder="Ready to transform your home or workspace..."
                className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none p-4 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 resize-none font-medium"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2 border-t border-neutral-100 dark:border-neutral-800/80">
              {/* Phone */}
              <div className="p-5 rounded-none bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 space-y-3">
                <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 text-xs font-bold uppercase tracking-wider">
                  <Phone size={16} />
                  <span>Phone Number</span>
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-500 dark:text-neutral-400 mb-1">Phone String</label>
                  <input
                    type="text"
                    name="phone"
                    defaultValue={content.phone}
                    className="w-full bg-white dark:bg-black border border-neutral-200 dark:border-neutral-800 rounded-none px-3.5 py-2 text-neutral-900 dark:text-white text-sm focus:border-amber-400 focus:outline-none font-medium"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-500 dark:text-neutral-400 mb-1">Availability Subtitle</label>
                  <input
                    type="text"
                    name="phoneSubtitle"
                    defaultValue={content.phoneSubtitle}
                    className="w-full bg-white dark:bg-black border border-neutral-200 dark:border-neutral-800 rounded-none px-3.5 py-2 text-neutral-700 dark:text-neutral-300 text-xs focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>

              {/* Email */}
              <div className="p-5 rounded-none bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 space-y-3">
                <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 text-xs font-bold uppercase tracking-wider">
                  <Mail size={16} />
                  <span>Email Address</span>
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-500 dark:text-neutral-400 mb-1">Email String</label>
                  <input
                    type="text"
                    name="email"
                    defaultValue={content.email}
                    className="w-full bg-white dark:bg-black border border-neutral-200 dark:border-neutral-800 rounded-none px-3.5 py-2 text-neutral-900 dark:text-white text-sm focus:border-amber-400 focus:outline-none font-medium"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-500 dark:text-neutral-400 mb-1">Support Subtitle</label>
                  <input
                    type="text"
                    name="emailSubtitle"
                    defaultValue={content.emailSubtitle}
                    className="w-full bg-white dark:bg-black border border-neutral-200 dark:border-neutral-800 rounded-none px-3.5 py-2 text-neutral-700 dark:text-neutral-300 text-xs focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>

              {/* Address */}
              <div className="p-5 rounded-none bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 space-y-3">
                <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 text-xs font-bold uppercase tracking-wider">
                  <MapPin size={16} />
                  <span>Showroom Location</span>
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-500 dark:text-neutral-400 mb-1">Address Line 1</label>
                  <input
                    type="text"
                    name="addressLine1"
                    defaultValue={content.addressLine1}
                    className="w-full bg-white dark:bg-black border border-neutral-200 dark:border-neutral-800 rounded-none px-3.5 py-2 text-neutral-900 dark:text-white text-sm focus:border-amber-400 focus:outline-none font-medium"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-500 dark:text-neutral-400 mb-1">City, State & Postal Code</label>
                  <input
                    type="text"
                    name="addressLine2"
                    defaultValue={content.addressLine2}
                    className="w-full bg-white dark:bg-black border border-neutral-200 dark:border-neutral-800 rounded-none px-3.5 py-2 text-neutral-700 dark:text-neutral-300 text-xs focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>

              {/* Working Hours */}
              <div className="p-5 rounded-none bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 space-y-3">
                <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 text-xs font-bold uppercase tracking-wider">
                  <Clock size={16} />
                  <span>Working Hours</span>
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-500 dark:text-neutral-400 mb-1">Weekday Hours</label>
                  <input
                    type="text"
                    name="workingHoursLine1"
                    defaultValue={content.workingHoursLine1}
                    className="w-full bg-white dark:bg-black border border-neutral-200 dark:border-neutral-800 rounded-none px-3.5 py-2 text-neutral-900 dark:text-white text-sm focus:border-amber-400 focus:outline-none font-medium"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-500 dark:text-neutral-400 mb-1">Weekend / Holiday Hours</label>
                  <input
                    type="text"
                    name="workingHoursLine2"
                    defaultValue={content.workingHoursLine2}
                    className="w-full bg-white dark:bg-black border border-neutral-200 dark:border-neutral-800 rounded-none px-3.5 py-2 text-neutral-700 dark:text-neutral-300 text-xs focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PAGE HEADER */}
        {activeTab === "header" && (
          <div className="bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none p-6 sm:p-8 space-y-6 shadow-xs">
            <div className="border-b border-neutral-100 dark:border-neutral-800 pb-4">
              <h2 className="text-lg font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                <Sparkles className="text-amber-500" size={18} />
                <span>Contact Page Hero Banner</span>
              </h2>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                Top banner introducing visitors to the contact form.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Header Title Prefix
                </label>
                <input
                  type="text"
                  name="headerTitlePrefix"
                  defaultValue={content.headerTitlePrefix}
                  placeholder="Get in"
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 mb-1.5">
                  Header Title Highlight (Gold Text)
                </label>
                <input
                  type="text"
                  name="headerTitleHighlight"
                  defaultValue={content.headerTitleHighlight}
                  placeholder="Touch"
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-amber-400/50 focus:border-amber-400 rounded-none px-4 py-2.5 text-amber-700 dark:text-amber-300 text-sm font-semibold focus:outline-none focus:ring-1 focus:ring-amber-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                Header Subtitle / Tagline
              </label>
              <textarea
                name="headerSubtitle"
                rows={3}
                defaultValue={content.headerSubtitle}
                placeholder="Have a question or need a quote? We're here to help..."
                className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none p-4 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 resize-none font-medium"
              />
            </div>
          </div>
        )}

        {/* TAB 3: INQUIRY FORM */}
        {activeTab === "form" && (
          <div className="bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none p-6 sm:p-8 space-y-6 shadow-xs">
            <div className="border-b border-neutral-100 dark:border-neutral-800 pb-4">
              <h2 className="text-lg font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                <Send className="text-amber-500" size={18} />
                <span>Inquiry Form Card Copy</span>
              </h2>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                Titles and button copy on the interactive inquiry submission card.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Form Headline
                </label>
                <input
                  type="text"
                  name="formTitle"
                  defaultValue={content.formTitle}
                  placeholder="Send an Inquiry"
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Submit Button Text
                </label>
                <input
                  type="text"
                  name="formButtonText"
                  defaultValue={content.formButtonText}
                  placeholder="Send Inquiry"
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                Form Subtitle Notice
              </label>
              <textarea
                name="formSubtitle"
                rows={2}
                defaultValue={content.formSubtitle}
                placeholder="Fill out the form below and we'll get back to you within 24 hours."
                className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none p-4 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 resize-none font-medium"
              />
            </div>
          </div>
        )}

        {/* Floating Action Bar / Save Button */}
        <div className="sticky bottom-6 z-30 p-4 rounded-none bg-white/95 dark:bg-black/95 backdrop-blur-xl border border-[#E5E5E0] dark:border-neutral-800 shadow-2xl flex items-center justify-between gap-4">
          <div className="hidden sm:flex items-center gap-3">
            <div className="w-9 h-9 rounded-none bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 flex items-center justify-center text-amber-700 dark:text-amber-400">
              <Zap size={18} />
            </div>
            <div>
              <p className="text-xs font-bold text-neutral-900 dark:text-white">Live Site Sync</p>
              <p className="text-[10px] text-neutral-500 dark:text-neutral-400">Updates will reflect immediately on the Contact Page</p>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
            <button
              type="submit"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3 rounded-none bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold text-sm transition-all shadow-xs active:scale-95 cursor-pointer"
            >
              <Save size={16} />
              <span>Save Contact Page Changes</span>
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
