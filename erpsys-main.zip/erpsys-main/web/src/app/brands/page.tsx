"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import {
  Layers,
  Plus,
  Edit2,
  Trash2,
  Loader2,
  CheckCircle,
  AlertCircle,
  Folder,
  Globe,
  Building2
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { DataTable, ColumnDef, ActionsDropdown } from "@/components/ui/table";
import { ActionItem } from "@/components/ui/actions-dropdown";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";
import { getFullAssetUrl } from "@/lib/utils";
import { LoadingSession } from "@/components/ui/loading-session";

import {
  BrandItem,
  BrandDialog,
  BrandDeleteDialog,
  useBrandsQuery,
  useBranchesQuery
} from "@/features/brands";

function BrandManagementPageContent() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Notifications
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Dialog States
  const [isDialogOpen, setIsDialogOpen] = useState<boolean>(false);
  const [editingBrand, setEditingBrand] = useState<BrandItem | null>(null);
  const [brandToDelete, setBrandToDelete] = useState<BrandItem | null>(null);

  // URL-driven Filter & Pagination state (Rule #3: Always store table filters in URL Search Params)
  const selectedBranchFilter = searchParams.get("branchId") || "all";
  const currentPage = Number(searchParams.get("page")) || 1;
  const searchQuery = searchParams.get("search") || "";
  const limit = Number(searchParams.get("limit")) || 10;

  const setSelectedBranchFilter = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1"); // Reset to page 1 on filter change
    if (value === "all") {
      params.delete("branchId");
    } else {
      params.set("branchId", value);
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  const handlePageChange = (newPage: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", String(newPage));
    router.push(`${pathname}?${params.toString()}`);
  };

  const handleSearchChange = (newSearch: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1"); // Reset to page 1 on search change
    if (newSearch) {
      params.set("search", newSearch);
    } else {
      params.delete("search");
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  const handleLimitChange = (newLimit: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("limit", String(newLimit));
    params.set("page", "1"); // Reset to page 1 when limit changes
    router.push(`${pathname}?${params.toString()}`);
  };

  // Authenticate
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  // Fetch Data via React Query
  const businessId = currentUser?.businessId || "";
  const { data: brandsResponse, isLoading: brandsLoading, isFetching: brandsFetching, error: brandsError } = useBrandsQuery(
    businessId,
    {
      branchId: selectedBranchFilter === "all" ? undefined : selectedBranchFilter,
      page: currentPage,
      limit,
      search: searchQuery,
    }
  );
  const brandsList = brandsResponse?.data || [];
  const meta = brandsResponse?.meta || { totalItems: 0, totalPages: 1, currentPage: 1, limit: 10 };
  const { data: branchesList = [], isLoading: branchesLoading } = useBranchesQuery(businessId, currentUser?.id);

  const isTableLoading = brandsLoading || brandsFetching;

  // Handle Query Errors
  useEffect(() => {
    if (brandsError) {
      setError(brandsError.message || "Failed to load brands.");
    }
  }, [brandsError]);

  // Auto-dismiss notifications
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  const handleOpenCreateModal = () => {
    setEditingBrand(null);
    setIsDialogOpen(true);
  };

  const handleOpenEditModal = (brand: BrandItem) => {
    setEditingBrand(brand);
    setIsDialogOpen(true);
  };


  // Filter Brands (already paginated and filtered by backend)
  const getFilteredBrands = () => {
    return brandsList;
  };

  const filteredList = getFilteredBrands();

  // Helper to render branch names
  const renderBranchNames = (brand: BrandItem) => {
    if (!brand.branches || brand.branches.length === 0) {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground font-medium">
          <Globe className="h-3.5 w-3.5 text-muted-foreground/60" />
          Global (All Branches)
        </span>
      );
    }

    if (brand.branches.length === 1) {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs text-foreground/90 font-medium">
          <Building2 className="h-3.5 w-3.5 text-muted-foreground" />
          {brand.branches[0].branch.name}
        </span>
      );
    }

    if (brand.branches.length === branchesList.length) {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs text-foreground/90 font-medium">
          <Building2 className="h-3.5 w-3.5 text-muted-foreground" />
          All Branches ({brand.branches.length})
        </span>
      );
    }

    const names = brand.branches.map((bb) => bb.branch.name);
    if (names.length <= 2) {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs text-foreground/90 font-medium">
          <Building2 className="h-3.5 w-3.5 text-muted-foreground" />
          {names.join(", ")}
        </span>
      );
    }

    return (
      <span className="inline-flex items-center gap-1.5 text-xs text-foreground/90 font-medium" title={names.join(", ")}>
        <Building2 className="h-3.5 w-3.5 text-muted-foreground" />
        {names[0]}, {names[1]} +{names.length - 2} more
      </span>
    );
  };

  // DataTable columns definition
  const columns: ColumnDef<BrandItem>[] = [
    {
      header: "Brand Name",
      searchable: true,
      render: (brand) => (
        <div className="flex items-center gap-3">
          {/* Logo Preview */}
          <div className="h-9 w-9 rounded-md bg-secondary/50 border border-border/60 overflow-hidden shrink-0 flex items-center justify-center">
            {brand.logoUrl ? (
              <img
                src={getFullAssetUrl(brand.logoUrl) || ""}
                alt={brand.name}
                className="h-full w-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "";
                }}
              />
            ) : (
              <Folder className="h-4.5 w-4.5 text-muted-foreground" />
            )}
          </div>

          <div className="truncate">
            <span className="font-semibold text-foreground block truncate">
              {brand.name}
            </span>
            {brand.description && (
              <span className="text-[10px] text-muted-foreground block truncate max-w-[200px] md:max-w-[300px]">
                {brand.description}
              </span>
            )}
          </div>
        </div>
      ),
    },
    {
      header: "Branch Scope",
      render: (brand) => renderBranchNames(brand),
    },
    {
      header: "Status",
      render: (brand) => (
        <span
          className={`inline-flex items-center px-2.5 py-0.5 rounded-sm text-[10px] font-semibold border ${
            brand.isActive
              ? "bg-emerald-500/10 text-emerald-455 border-emerald-500/20"
              : "bg-secondary text-secondary-foreground border border-border"
          }`}
        >
          {brand.isActive ? "ACTIVE" : "INACTIVE"}
        </span>
      ),
    },
    {
      header: "Actions",
      render: (brand) => {
        const actions: ActionItem[] = [
          {
            label: "Edit",
            onClick: () => handleOpenEditModal(brand),
            icon: <Edit2 className="h-3.5 w-3.5" />,
          },
          {
            label: "Delete",
            onClick: () => setBrandToDelete(brand),
            icon: <Trash2 className="h-3.5 w-3.5" />,
            variant: "destructive",
          },
        ];
        return <ActionsDropdown actions={actions} />;
      },
    },
  ];

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-4">
          <Loader2 className="h-10 w-10 animate-spin text-primary mx-auto" />
          <p className="text-lg font-medium">Redirecting to login...</p>
        </div>
      </div>
    );
  }

  const isLoading = brandsLoading || branchesLoading;

  const customFilters = (
    <div className="flex items-center gap-2">
      <span className="text-xs font-semibold text-muted-foreground whitespace-nowrap">Branch:</span>
      <select
        value={selectedBranchFilter}
        onChange={(e) => setSelectedBranchFilter(e.target.value)}
        className="h-9 rounded-md border border-input bg-background px-3 py-1 text-xs shadow-sm focus:outline-none focus:ring-1 focus:ring-ring"
      >
        <option value="all">All Branches</option>
        <option value="global">Global Only</option>
        {branchesList.map((b) => (
          <option key={b.id} value={b.id}>
            {b.name}
          </option>
        ))}
      </select>
    </div>
  );

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/brands" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Product Brands" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          
          {/* Notifications */}
          {successMessage && (
            <div className="flex items-center gap-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-450 p-4 rounded-sm animate-in fade-in slide-in-from-top duration-300">
              <CheckCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 bg-rose-500/10 border border-rose-500/20 text-rose-450 p-4 rounded-sm animate-in fade-in slide-in-from-top duration-300">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <Layers className="h-7 w-7 text-primary" /> Product Brands
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Manage your product brands, associate them with specific branches, and upload brand logos.
              </p>
            </div>
          </div>

          {/* Brands List */}
          {isLoading ? (
            <div className="flex h-64 items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (brandsList.length === 0 && !searchQuery) ? (
            <Card className="p-12 text-center border-dashed border-border/50 bg-card/10">
              <CardContent className="space-y-4 pt-6">
                <div className="bg-secondary h-16 w-16 rounded-2xl flex items-center justify-center mx-auto text-muted-foreground">
                  <Layers className="h-8 w-8" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-xl font-semibold text-foreground">No Brands Yet</h3>
                  <p className="text-muted-foreground max-w-sm mx-auto">
                    Get started by creating your first product brand.
                  </p>
                </div>
                <Button onClick={handleOpenCreateModal} className="bg-primary hover:bg-primary/90 text-primary-foreground">
                  Create Brand
                </Button>
              </CardContent>
            </Card>
          ) : (
            <DataTable
              data={filteredList}
              columns={columns}
              searchPlaceholder="Search brands by name or description..."
              reportTitle="Product Brands Report"
              pageSize={limit}
              customFilters={customFilters}
              actionButton={{
                label: "Add Brand",
                onClick: handleOpenCreateModal,
                icon: <Plus className="h-4 w-4" />
              }}
              serverSide={true}
              totalItems={meta.totalItems}
              totalPages={meta.totalPages}
              currentPage={meta.currentPage}
              onPageChange={handlePageChange}
              searchQuery={searchQuery}
              onSearchQueryChange={handleSearchChange}
              isLoading={isTableLoading}
              onPageSizeChange={handleLimitChange}
            />
          )}
        </main>
      </div>

      {/* Brand Create/Edit Dialog */}
      {currentUser && (
        <BrandDialog
          isOpen={isDialogOpen}
          onClose={() => {
            setIsDialogOpen(false);
            setEditingBrand(null);
          }}
          brand={editingBrand}
          branches={branchesList}
          currentUser={currentUser}
          onSuccess={setSuccessMessage}
          onError={setError}
        />
      )}

      {/* Delete Confirmation Dialog */}
      {currentUser && brandToDelete && (
        <BrandDeleteDialog
          isOpen={!!brandToDelete}
          onClose={() => setBrandToDelete(null)}
          brand={brandToDelete}
          currentUser={currentUser}
          onSuccess={setSuccessMessage}
          onError={setError}
        />
      )}
    </div>
  );
}

export default function BrandManagementPage() {
  return (
    <Suspense fallback={<LoadingSession />}>
      <BrandManagementPageContent />
    </Suspense>
  );
}
