'use client';

import { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';

const faqs = [
  {
    q: 'How long does a typical software or ERP implementation take?',
    a: 'Ready-to-deploy products like HKRION POS, HRM, or Inventory can be configured and deployed within 3 to 7 business days. Custom enterprise ERP or Web App projects typically take 4 to 12 weeks depending on scope.'
  },
  {
    q: 'Can HKRION products be customized for our specific business workflows?',
    a: 'Yes, absolutely. All HKRION products (POS, ERP, HRM, CRM) are modular and can be tailored to incorporate custom fields, approval chains, specific tax rules, or custom print formats.'
  },
  {
    q: 'How is data security and database hosting handled?',
    a: 'We use secure MySQL relational databases with Prisma ORM type-safety, encrypted connections (SSL/TLS), role-based access control (RBAC), and automated daily cloud backups hosted on AWS or dedicated local servers.'
  },
  {
    q: 'Do you provide on-site staff training and 24/7 technical support?',
    a: 'Yes! Every HKRION deployment includes hands-on staff training, user manuals, and dedicated 24/7 technical support to resolve any operational questions immediately.'
  },
  {
    q: 'Can we integrate IoT hardware sensors or biometric attendance machines?',
    a: 'Yes. HKRION specializes in IoT telemetry and hardware integration, connecting biometric fingerprint/facial scanners, thermal barcode printers, and industrial IoT sensors directly to your cloud dashboard.'
  }
];

export default function FAQ() {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpenIdx(openIdx === idx ? null : idx);
  };

  return (
    <section id="faq" className="py-24 bg-neutral-950 relative overflow-hidden border-y border-white/10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-xs font-semibold uppercase tracking-widest text-[#1ABE56] font-mono flex items-center justify-center gap-2">
            <HelpCircle className="w-4 h-4 text-[#1ABE56]" />
            FREQUENTLY ASKED QUESTIONS
          </h2>
          <p className="text-3xl sm:text-5xl font-semibold text-white tracking-tight">
            Got Questions? <span className="gradient-text">We Have Answers</span>
          </p>
          <p className="text-neutral-400 text-base sm:text-lg">
            Everything you need to know about partnering with HKRION (Pvt) Ltd.
          </p>
        </div>

        {/* Accordion */}
        <div className="space-y-4">
          {faqs.map((faq, idx) => {
            const isOpen = openIdx === idx;
            return (
              <div
                key={idx}
                className="glass-card rounded-2xl border border-[#1ABE56]/30 bg-black/90 overflow-hidden transition-all"
              >
                <button
                  onClick={() => toggle(idx)}
                  className="w-full p-6 text-left flex items-center justify-between gap-4 font-bold text-white text-base hover:text-[#1ABE56] transition-colors"
                >
                  <span>{faq.q}</span>
                  <ChevronDown className={`w-5 h-5 text-[#1ABE56] shrink-0 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
                </button>

                {isOpen && (
                  <div className="px-6 pb-6 text-sm text-neutral-300 leading-relaxed border-t border-white/5 pt-4">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
