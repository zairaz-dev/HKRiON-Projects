import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import pool from "@/lib/db";
import { RowDataPacket } from "mysql2";
import {
  verifyPassword,
  hashPassword,
  timingSafeCompare,
  createSessionToken,
  SESSION_COOKIE_NAME,
  createCustomerSessionToken,
  CUSTOMER_SESSION_COOKIE_NAME,
} from "@/lib/auth";

import { getClientIp } from "@/lib/request-ip";

// Brute-force & Rate Guard Store
interface LoginAttemptRecord {
  failures: number;
  lockedUntil: number;
}
const loginAttempts = new Map<string, LoginAttemptRecord>();

const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 5 * 60 * 1000; // 5 minutes

function getClientIdentifier(request: Request, email: string): string {
  const ip = getClientIp(request);
  return `${ip}::${email.trim().toLowerCase()}`;
}

function pruneLoginAttempts(now: number): void {
  if (loginAttempts.size > 1000) {
    for (const [key, record] of loginAttempts.entries()) {
      if (record.lockedUntil <= now) {
        loginAttempts.delete(key);
      }
    }
  }
}

function recordFailedAttempt(clientKey: string): void {
  const now = Date.now();
  const rec = loginAttempts.get(clientKey) || { failures: 0, lockedUntil: 0 };
  rec.failures += 1;
  if (rec.failures >= MAX_FAILED_ATTEMPTS) {
    rec.lockedUntil = now + LOCKOUT_DURATION_MS;
  }
  loginAttempts.set(clientKey, rec);
}

export async function POST(request: Request) {
  try {
    const now = Date.now();
    pruneLoginAttempts(now);

    const body = await request.json();
    const { email, password } = body;

    if (!email || !password) {
      return NextResponse.json(
        { error: "Email and password are required" },
        { status: 400 }
      );
    }

    const normalizedEmail = email.trim().toLowerCase();
    const clientKey = getClientIdentifier(request, normalizedEmail);

    // 1. Check Rate Limiting & Lockout
    const attemptRecord = loginAttempts.get(clientKey);
    if (attemptRecord && attemptRecord.lockedUntil > now) {
      const waitSeconds = Math.ceil((attemptRecord.lockedUntil - now) / 1000);
      return NextResponse.json(
        {
          error: `Account temporarily locked due to consecutive failed attempts. Please wait ${waitSeconds} seconds.`,
          locked: true,
          retryAfter: waitSeconds,
        },
        { status: 429, headers: { "Retry-After": waitSeconds.toString() } }
      );
    }

    const adminEmail = process.env.ADMIN_EMAIL ? process.env.ADMIN_EMAIL.trim().toLowerCase() : null;
    const adminPassword = process.env.ADMIN_PASSWORD;

    const cookieStore = await cookies();

    // 2. Direct check against primary environment Administrator credentials (only if configured in env)
    const isEnvAdmin = Boolean(
      adminEmail &&
      adminPassword &&
      timingSafeCompare(normalizedEmail, adminEmail) &&
      timingSafeCompare(password, adminPassword)
    );

    if (isEnvAdmin) {
      // Clear failed attempts upon successful login
      loginAttempts.delete(clientKey);

      const adminToken = createSessionToken({
        email: normalizedEmail,
        name: process.env.ADMIN_NAME || "Admin",
      });
      cookieStore.set(SESSION_COOKIE_NAME, adminToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
        path: "/",
        maxAge: 7 * 24 * 60 * 60,
      });

      // Also set customer session so admin can seamlessly browse customer views
      const custToken = createCustomerSessionToken({
        id: "admin-vault-officer",
        email: normalizedEmail,
        name: process.env.ADMIN_NAME || "Admin",
        phone: "+41 22 700 8900",
      });
      cookieStore.set(CUSTOMER_SESSION_COOKIE_NAME, custToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        path: "/",
        maxAge: 7 * 24 * 60 * 60,
      });

      return NextResponse.json({
        success: true,
        role: "ADMIN",
        redirectUrl: "/admindashboard",
        user: {
          id: "admin-vault-officer",
          email: normalizedEmail,
          name: process.env.ADMIN_NAME || "Admin",
          role: "ADMIN",
        },
      });
    }

    // 3. Query user in MySQL users table
    const [rows] = await pool.query<RowDataPacket[]>(
      "SELECT id, name, email, password_hash, phone, role FROM users WHERE email = ? LIMIT 1",
      [normalizedEmail]
    );

    if (!rows || rows.length === 0) {
      recordFailedAttempt(clientKey);
      return NextResponse.json(
        { error: "No account found with this email address. Please register or verify credentials." },
        { status: 401 }
      );
    }

    const user = rows[0];
    let isPasswordValid = false;
    let needsRehash = false;

    if (user.password_hash) {
      if (typeof user.password_hash === "string" && user.password_hash.startsWith("$2")) {
        isPasswordValid = await verifyPassword(password, user.password_hash);
      } else {
        isPasswordValid = timingSafeCompare(user.password_hash, password);
        if (isPasswordValid) {
          needsRehash = true;
        }
      }
    }

    // Allow configured environment admin credentials only for the designated primary admin user
    if (
      !isPasswordValid &&
      user.role === "ADMIN" &&
      adminPassword &&
      adminEmail &&
      timingSafeCompare(normalizedEmail, adminEmail)
    ) {
      isPasswordValid = timingSafeCompare(password, adminPassword);
      if (isPasswordValid) {
        needsRehash = true;
      }
    }

    if (!isPasswordValid) {
      recordFailedAttempt(clientKey);
      return NextResponse.json(
        { error: "Incorrect password. Please verify your credentials." },
        { status: 401 }
      );
    }

    // Automatically rehash and upgrade legacy plaintext password to secure bcrypt hash
    if (needsRehash) {
      try {
        const upgradedHash = await hashPassword(password);
        await pool.query("UPDATE users SET password_hash = ? WHERE id = ?", [
          upgradedHash,
          user.id,
        ]);
      } catch (rehashErr) {
        console.warn("Failed to upgrade legacy password hash:", rehashErr);
      }
    }

    // Login successful: reset failed attempt counter
    loginAttempts.delete(clientKey);

    // 4. User is an Administrator in database
    if (user.role === "ADMIN") {
      const adminToken = createSessionToken({
        email: normalizedEmail,
        name: user.name || "Vault Administrator",
      });
      cookieStore.set(SESSION_COOKIE_NAME, adminToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
        path: "/",
        maxAge: 7 * 24 * 60 * 60,
      });

      const custToken = createCustomerSessionToken({
        id: user.id,
        email: normalizedEmail,
        name: user.name || "Vault Administrator",
        phone: user.phone || "",
      });
      cookieStore.set(CUSTOMER_SESSION_COOKIE_NAME, custToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        path: "/",
        maxAge: 7 * 24 * 60 * 60,
      });

      return NextResponse.json({
        success: true,
        role: "ADMIN",
        redirectUrl: "/admindashboard",
        user: {
          id: user.id,
          name: user.name,
          email: normalizedEmail,
          phone: user.phone || "",
          role: "ADMIN",
        },
      });
    }

    // 5. User is a Customer / Patron
    let clientMeta = {
      tier: "Regular Customer",
      location: "Sri Lanka",
      salon: "Sri Lanka",
      totalSpent: 0,
      acquisitions: 0,
    };

    try {
      const [clientRows] = await pool.query<RowDataPacket[]>(
        "SELECT tier, location, total_spent, acquisitions FROM clients WHERE email = ? LIMIT 1",
        [normalizedEmail]
      );
      if (clientRows && clientRows.length > 0) {
        const loc = clientRows[0].location || "Sri Lanka";
        clientMeta = {
          tier: clientRows[0].tier || "Regular Customer",
          location: loc,
          salon: loc,
          totalSpent: Number(clientRows[0].total_spent || 0),
          acquisitions: Number(clientRows[0].acquisitions || 0),
        };
      }
    } catch {
      // Continue with defaults
    }

    // Issue customer session token
    const token = createCustomerSessionToken({
      id: user.id,
      email: normalizedEmail,
      name: user.name || "Private Patron",
      phone: user.phone || "",
    });

    cookieStore.set(CUSTOMER_SESSION_COOKIE_NAME, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 14 * 24 * 60 * 60,
    });

    return NextResponse.json({
      success: true,
      role: "CUSTOMER",
      redirectUrl: "/account",
      user: {
        id: user.id,
        name: user.name,
        email: normalizedEmail,
        phone: user.phone || "",
        role: "CUSTOMER",
        ...clientMeta,
      },
    });
  } catch (error) {
    console.error("Unified authentication error:", error);
    return NextResponse.json(
      { error: "Authentication service unavailable" },
      { status: 500 }
    );
  }
}
