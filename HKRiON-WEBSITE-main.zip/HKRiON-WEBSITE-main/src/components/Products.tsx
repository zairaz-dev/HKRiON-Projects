'use client';

import { 
  ShoppingBag, 
  Layers, 
  Users, 
  ExternalLink,
  CheckCircle2,
  Sparkles
} from 'lucide-react';

const products = [
  {
    name: 'IHM TECH POS',
    tagline: 'Smart Retail & Restaurant Billing',
    icon: ShoppingBag,
    desc: 'Fast counter billing, barcode scanning, offline mode, and receipt printing for retail shops and restaurants.',
    features: ['Instant Billing', 'Multi-Terminal POS', 'Offline Cache', 'Thermal Printer Support'],
    badge: 'Popular Retail',
    image: '/images/products/ihmtech.png',
    link: 'https://ihmtech.com/'
  },
  {
    name: 'HKRION ERP',
    tagline: 'Complete Business Management System',
    icon: Layers,
    desc: 'Manage company finances, sales, purchases, stock, and executive reports in one simple dashboard.',
    features: ['Financial Accounting', 'Procurement & Sales', 'Real-Time Analytics', 'Role Access Control'],
    badge: 'Enterprise Core',
    image: '/images/products/hkrion_erp.png',
    link: 'https://erp.hkrion.com'
  },
  {
    name: 'HKRION HRM',
    tagline: 'Staff Attendance & Payroll Software',
    icon: Users,
    desc: 'Track employee attendance, calculate monthly salaries automatically, and manage leave requests effortlessly.',
    features: ['Payroll & Payslip Generator', 'Leave Management', 'Employee Portal', 'Compliance Audit'],
    badge: 'Human Resources',
    image: '/images/products/hrm.png'
  }
];

export default function Products() {
  return (
    <section id="products" className="py-24 bg-neutral-950 relative overflow-hidden">
      
      {/* Background ambient light */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-125 h-125 bg-[#1ABE56]/15 blur-[160px] rounded-full pointer-events-none animate-pulse-slow" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <h2 className="text-xs font-semibold uppercase tracking-widest text-[#1ABE56] font-mono flex items-center justify-center gap-2">
            <Sparkles className="w-4 h-4 text-[#1ABE56] animate-pulse" />
            HKRION PRODUCTS SUITE
          </h2>
          <p className="text-3xl sm:text-5xl font-semibold text-white tracking-tight">
            Ready-to-Deploy <span className="gradient-text">Enterprise Products</span>
          </p>
          <p className="text-neutral-400 text-base sm:text-lg">
            Powerful, battle-tested software products developed by HKRION (Pvt) Ltd to streamline operations for businesses of all sizes.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product, idx) => {
            const Icon = product.icon;
            return (
              <div
                key={idx}
                className="glass-card p-6 sm:p-7 rounded-md border border-[#1ABE56]/30 hover:border-[#1ABE56] bg-black/90 transition-all duration-500 group hover:-translate-y-2 flex flex-col justify-between hover:shadow-2xl hover:shadow-[#1ABE56]/25 relative overflow-hidden"
              >
                {/* Glowing corner overlay */}
                <div className="absolute -top-12 -right-12 w-28 h-28 bg-[#1ABE56]/10 rounded-full blur-2xl group-hover:bg-[#1ABE56]/30 transition-all" />

                <div>
                  {/* Top Header: Icon & Badge */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-md bg-[#1ABE56]/10 border border-[#1ABE56]/30 flex items-center justify-center group-hover:bg-[#1ABE56] transition-all shrink-0">
                        <Icon className="w-5 h-5 text-[#1ABE56] group-hover:text-black transition-colors" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-white group-hover:text-[#1ABE56] transition-colors leading-tight">
                          {product.name}
                        </h3>
                        <span className="text-[11px] text-[#1ABE56] font-mono block">{product.tagline}</span>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono font-semibold px-2.5 py-1 rounded-md bg-[#1ABE56]/20 text-[#1ABE56] border border-[#1ABE56]/40 shrink-0">
                      {product.badge}
                    </span>
                  </div>

                  {/* Software UI Dashboard Preview Image */}
                  <div className="relative h-44 w-full mb-5 rounded-md overflow-hidden border border-[#1ABE56]/25 group-hover:border-[#1ABE56]/70 transition-all bg-neutral-900 shadow-md">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-linear-to-t from-black/70 via-transparent to-transparent pointer-events-none" />
                  </div>

                  {/* Description */}
                  <p className="text-neutral-300 text-xs sm:text-sm leading-relaxed mb-5">
                    {product.desc}
                  </p>

                  {/* Key Features */}
                  <div className="space-y-2 mb-6">
                    {product.features.map((feat, fIdx) => (
                      <div key={fIdx} className="flex items-center gap-2 text-xs text-neutral-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#1ABE56] shrink-0" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-4 border-t border-white/10">
                  <a
                    href={product.link || "#contact"}
                    target={product.link ? "_blank" : undefined}
                    rel={product.link ? "noopener noreferrer" : undefined}
                    className="w-full py-3 px-4 rounded-md text-xs font-semibold text-white bg-neutral-900 border border-[#1ABE56]/40 hover:bg-[#1ABE56] hover:text-black transition-all flex items-center justify-center gap-2 group/btn hover:shadow-lg hover:shadow-[#1ABE56]/30"
                  >
                    <span>Request Live Demo</span>
                    <ExternalLink className="w-3.5 h-3.5 group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5 transition-transform" />
                  </a>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
