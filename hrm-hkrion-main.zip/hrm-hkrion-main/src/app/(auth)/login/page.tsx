"use client";

import { useActionState, useState } from "react";
import { login, type LoginState } from "@/actions/auth";
import { 
  Lock, 
  Mail, 
  Eye, 
  EyeOff, 
  ArrowRight, 
  ShieldAlert,
  ClipboardCheck, 
  CalendarClock, 
  Users2,
  Sun, 
  Moon, 
  AlertTriangle,
  Loader2,
  HelpCircle,
  Building,
  ShieldCheck,
  Sparkles
} from "lucide-react";
import { useTheme } from "@/components/theme-provider";

export default function LoginPage() {
  const [state, formAction, isPending] = useActionState<LoginState, FormData>(
    login,
    undefined
  );
  
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const { theme, setTheme } = useTheme();
  const isDark = theme === "dark";

  return (
    <div className="h-screen max-h-screen w-full overflow-hidden grid grid-cols-1 lg:grid-cols-12 bg-background text-text-primary selection:bg-primary-soft selection:text-primary">
      
      {/* 1. LEFT SHOWCASE COLUMN: HKRiON Internal Portal Overview */}
      <div className="hidden lg:flex lg:col-span-6 xl:col-span-7 flex-col justify-between pt-6 sm:pt-8 xl:pt-10 px-6 sm:px-8 xl:px-10 pb-0 relative overflow-hidden bg-surface border-r border-border h-full">
        {/* Subtle Ambient Glow Lights */}
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute -top-24 -left-24 w-80 h-80 bg-primary/10 rounded-full blur-[100px]" />
          <div className="absolute -bottom-24 -right-24 w-80 h-80 bg-indigo-500/10 rounded-full blur-[100px]" />
          <div className="absolute inset-0 bg-[radial-gradient(#80808012_1px,transparent_1px)] [background-size:24px_24px] opacity-70" />
        </div>

        {/* Top Internal Branding - Height 11 */}
        <div className="relative z-10 h-11 flex items-center shrink-0">
          <div className="flex items-center gap-3">
            <div className="relative flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-tr from-primary to-indigo-500 text-white shadow-md shadow-primary/25">
              <span className="font-extrabold text-base tracking-wider">H</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-base font-extrabold tracking-tight text-text-primary">
                  HKRiON
                </span>
                <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-primary-soft text-primary">
                  Staff Portal
                </span>
              </div>
              <p className="text-[11px] text-text-muted font-medium">
                Internal Human Resource & Operations System
              </p>
            </div>
          </div>
        </div>

        {/* Center Content: Internal Workspace Pillars */}
        <div className="relative z-10 my-auto py-2 xl:py-4 space-y-4 xl:space-y-6 max-w-lg">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-primary-soft border border-primary/20 text-[11px] font-semibold text-primary">
              <Building className="h-3 w-3" />
              <span>HKRiON Private Workplace</span>
            </div>
            <h1 className="text-2xl xl:text-3xl font-extrabold tracking-tight text-text-primary leading-tight">
              HKRiON Internal Operations & Team Workspace
            </h1>
            <p className="text-xs xl:text-sm text-text-secondary leading-relaxed line-clamp-2 xl:line-clamp-none">
              Centralized workspace for HKRiON employees, team leads, and administration to manage daily project milestones, attendance, and team operations.
            </p>
          </div>

          {/* 3 Solid Pillars */}
          <div className="grid grid-cols-1 gap-2.5 xl:gap-3">
            <div className="flex items-start gap-3 p-2.5 xl:p-3 rounded-xl bg-surface-secondary/60 border border-border shadow-2xs hover:border-primary/40 transition-colors">
              <div className="p-1.5 rounded-lg bg-primary-soft text-primary shrink-0 mt-0.5">
                <ClipboardCheck className="h-4 w-4" />
              </div>
              <div>
                <h3 className="font-semibold text-xs text-text-primary">Project Tasks & Daily Milestones</h3>
                <p className="text-[11px] text-text-secondary mt-0.5 leading-relaxed">
                  Track assigned deliverables, post task updates, and coordinate with leads.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-2.5 xl:p-3 rounded-xl bg-surface-secondary/60 border border-border shadow-2xs hover:border-primary/40 transition-colors">
              <div className="p-1.5 rounded-lg bg-violet-500/10 text-violet-600 dark:text-violet-400 shrink-0 mt-0.5">
                <CalendarClock className="h-4 w-4" />
              </div>
              <div>
                <h3 className="font-semibold text-xs text-text-primary">Daily Attendance & Leave Requests</h3>
                <p className="text-[11px] text-text-secondary mt-0.5 leading-relaxed">
                  Daily clock-in/out logging, official time-off submissions, and holiday schedules.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-2.5 xl:p-3 rounded-xl bg-surface-secondary/60 border border-border shadow-2xs hover:border-primary/40 transition-colors">
              <div className="p-1.5 rounded-lg bg-teal-500/10 text-teal-600 dark:text-teal-400 shrink-0 mt-0.5">
                <Users2 className="h-4 w-4" />
              </div>
              <div>
                <h3 className="font-semibold text-xs text-text-primary">Staff Directory & Organization</h3>
                <p className="text-[11px] text-text-secondary mt-0.5 leading-relaxed">
                  Internal contact information, departmental structures, and reporting managers.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Internal Security Notice - Moved directly to bottom edge */}
        <div className="relative z-10 h-13 flex items-center justify-between border-t border-border text-[11px] text-text-muted shrink-0 -mx-6 sm:-mx-8 xl:-mx-10 px-6 sm:px-8 xl:px-10 bg-surface">
          <div className="flex items-center gap-1.5">
            <ShieldAlert className="h-3.5 w-3.5 text-amber-500" />
            <span className="font-medium">Authorized Staff Only • All Activity Logged</span>
          </div>
          <div className="flex items-center gap-1.5 font-mono">
            <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" />
            <span>Systems Active</span>
          </div>
        </div>
      </div>

      {/* 2. RIGHT SIGN-IN COLUMN: Clean Solid Staff Sign In Form */}
      <div className="col-span-1 lg:col-span-6 xl:col-span-5 flex flex-col justify-between pt-6 sm:pt-8 xl:pt-10 px-6 sm:px-8 xl:px-10 pb-0 relative bg-surface-secondary/30 h-full overflow-y-auto lg:overflow-hidden">
        
        {/* Subtle Ambient Dots */}
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute top-10 right-10 w-64 h-64 bg-primary/5 rounded-full blur-[90px]" />
          <div className="absolute bottom-10 left-10 w-64 h-64 bg-indigo-500/5 rounded-full blur-[90px]" />
          <div className="absolute inset-0 bg-[radial-gradient(#80808012_1px,transparent_1px)] [background-size:20px_20px] opacity-50" />
        </div>

        {/* Top Right Header: Mobile Brand & Theme Toggle - Height 11 */}
        <div className="relative z-10 flex items-center justify-between w-full h-11 shrink-0">
          {/* Mobile Logo */}
          <div className="flex lg:hidden items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-tr from-primary to-indigo-500 text-white font-bold text-sm shadow-sm">
              H
            </div>
            <div>
              <span className="font-bold text-sm text-text-primary block leading-none">HKRiON</span>
              <span className="text-[10px] text-text-muted font-medium">Internal Portal</span>
            </div>
          </div>

          <div className="hidden lg:block">
            {/* Spacer */}
          </div>

          {/* Theme Switcher Button */}
          <button
            type="button"
            onClick={() => setTheme(isDark ? "light" : "dark")}
            className="p-2 rounded-xl border border-border bg-surface text-text-secondary hover:text-text-primary hover:bg-surface-secondary transition-colors cursor-pointer shadow-2xs"
            title="Toggle theme"
          >
            {isDark ? <Sun className="h-4 w-4 text-amber-500" /> : <Moon className="h-4 w-4 text-indigo-400" />}
          </button>
        </div>

        {/* Sign In Main Form */}
        <div className="relative z-10 w-full max-w-sm mx-auto my-auto">
          
          {/* Sign In Card Container (Clean Solid Card) */}
          <div className="p-6 sm:p-7 rounded-2xl bg-surface border border-border shadow-md space-y-4">
            
            {/* Heading */}
            <div className="space-y-0.5 text-center sm:text-left">
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-text-primary">
                Employee Sign In
              </h2>
              <p className="text-xs text-text-secondary">
                Sign in with your official HKRiON company credentials.
              </p>
            </div>

            {/* Error Alert Box */}
            {state?.error && (
              <div className="p-2.5 rounded-xl bg-error-bg border border-error-border text-error text-xs flex items-start gap-2 shadow-2xs animate-in fade-in slide-in-from-top-1 duration-200">
                <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="font-semibold text-xs">Authentication Failed</p>
                  <p className="text-[11px] mt-0.5 leading-tight">{state.error}</p>
                </div>
              </div>
            )}

            {/* Form */}
            <form action={formAction} className="space-y-3.5">
              
              {/* Email Address */}
              <div className="space-y-1">
                <label
                  htmlFor="email"
                  className="text-xs font-semibold text-text-primary flex items-center justify-between"
                >
                  <span>HKRiON Email</span>
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-text-muted transition-colors group-focus-within:text-primary" />
                  <input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    required
                    placeholder="name@hkrion.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full rounded-xl border border-border bg-surface-secondary focus:bg-surface py-2.5 pl-9 pr-3 text-xs sm:text-sm text-text-primary placeholder-text-muted outline-none transition-all duration-200 focus:border-primary focus:ring-2 focus:ring-primary/20 shadow-2xs font-mono"
                  />
                </div>
              </div>

              {/* Password */}
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label
                    htmlFor="password"
                    className="text-xs font-semibold text-text-primary"
                  >
                    Password
                  </label>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-text-muted" />
                  <input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    autoComplete="current-password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full rounded-xl border border-border bg-surface-secondary focus:bg-surface py-2.5 pl-9 pr-10 text-xs sm:text-sm text-text-primary placeholder-text-muted outline-none transition-all duration-200 focus:border-primary focus:ring-2 focus:ring-primary/20 shadow-2xs"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 flex items-center pr-3 text-text-muted hover:text-text-primary transition-colors cursor-pointer"
                    tabIndex={-1}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              {/* Submit Button */}
              <button
                id="login-submit"
                type="submit"
                disabled={isPending}
                className="w-full mt-1 flex items-center justify-center gap-2 rounded-xl bg-primary text-white font-semibold py-2.5 px-4 text-sm hover:bg-primary-hover active:scale-[0.99] transition-all shadow-md shadow-primary/20 disabled:opacity-50 disabled:pointer-events-none cursor-pointer"
              >
                {isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Signing in...</span>
                  </>
                ) : (
                  <>
                    <span>Sign In to Staff Portal</span>
                    <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </button>
            </form>

            {/* Internal IT Support Help Desk Notice */}
            <div className="p-2.5 rounded-xl bg-surface-secondary border border-border text-xs text-text-muted flex items-center gap-2">
              <HelpCircle className="h-3.5 w-3.5 text-text-secondary shrink-0" />
              <p className="text-[11px] leading-snug">
                Need assistance? Contact the <span className="font-semibold text-text-primary">HKRiON IT Desk</span>.
              </p>
            </div>

          </div>

        </div>

        {/* Footer: Moved directly to bottom edge */}
        <div className="relative z-10 h-13 flex items-center justify-between border-t border-border text-[11px] text-text-muted shrink-0 -mx-6 sm:-mx-8 xl:-mx-10 px-6 sm:px-8 xl:px-10 bg-surface-secondary/20">
          <p className="text-[11px] text-text-muted">
            © {new Date().getFullYear()} HKRiON (Pvt) Ltd.
          </p>
          <p className="text-[10px] text-text-disabled uppercase tracking-wider font-semibold">
            Confidential • Internal Only
          </p>
        </div>

      </div>

    </div>
  );
}
