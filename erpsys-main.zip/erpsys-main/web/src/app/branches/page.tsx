"use strict";
"use client";

import React, { useEffect, useState, useMemo, useRef } from "react";
import {
  Building2,
  Plus,
  Edit2,
  Trash2,
  Loader2,
  CheckCircle,
  AlertCircle,
  X,
  MapPin,
  Phone,
  Mail,
  Users,
  Search,
  Hash,
  User as UserIcon,
  Warehouse,
  ShoppingBag,
  Store,
  ShieldCheck,
  Star,
  Monitor,
  Upload,
  Image as ImageIcon,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { authService } from "@/services/auth-service";
import { branchService } from "@/services/branch-service";
import { User } from "@hkr/types";
import { getFullAssetUrl } from "@/lib/utils";

interface BranchItem {
  id: string;
  name: string;
  code?: string | null;
  logo?: string | null;
  type?: string | null;
  isMainBranch?: boolean;
  managerName?: string | null;
  phone: string | null;
  alternatePhone?: string | null;
  email: string | null;
  address: string | null;
  city?: string | null;
  state?: string | null;
  postalCode?: string | null;
  taxNumber?: string | null;
  allowPosSales?: boolean;
  isActive: boolean;
  businessId: string;
}

export default function BranchManagementPage() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // State
  const [branchesList, setBranchesList] = useState<BranchItem[]>([]);
  const [businessUsers, setBusinessUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [actionLoading, setActionLoading] = useState<boolean>(false);
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<string>("all");

  // Branch Modal State
  const [isBranchModalOpen, setIsBranchModalOpen] = useState<boolean>(false);
  const [branchModalMode, setBranchModalMode] = useState<"create" | "edit">("create");
  const [editingBranchId, setEditingBranchId] = useState<string>("");

  // Logo upload state
  const [formLogo, setFormLogo] = useState<string>("");
  const [logoPreview, setLogoPreview] = useState<string>("");
  const [isUploadingLogo, setIsUploadingLogo] = useState<boolean>(false);

  // Form Fields
  const [formName, setFormName] = useState<string>("");
  const [formCode, setFormCode] = useState<string>("");
  const [formType, setFormType] = useState<string>("retail");
  const [formIsMainBranch, setFormIsMainBranch] = useState<boolean>(false);
  const [formManagerName, setFormManagerName] = useState<string>("");
  const [formPhone, setFormPhone] = useState<string>("");
  const [formAlternatePhone, setFormAlternatePhone] = useState<string>("");
  const [formEmail, setFormEmail] = useState<string>("");
  const [formAddress, setFormAddress] = useState<string>("");
  const [formCity, setFormCity] = useState<string>("");
  const [formState, setFormState] = useState<string>("");
  const [formPostalCode, setFormPostalCode] = useState<string>("");
  const [formTaxNumber, setFormTaxNumber] = useState<string>("");
  const [formAllowPosSales, setFormAllowPosSales] = useState<boolean>(true);
  const [formIsActive, setFormIsActive] = useState<boolean>(true);

  // Delete Confirmation State
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState<boolean>(false);
  const [branchToDelete, setBranchToDelete] = useState<BranchItem | null>(null);

  // User Assignment Modal State
  const [isUserModalOpen, setIsUserModalOpen] = useState<boolean>(false);
  const [activeBranch, setActiveBranch] = useState<BranchItem | null>(null);
  const [assignedUserIds, setAssignedUserIds] = useState<string[]>([]);
  const [usersInBranchLoading, setUsersInBranchLoading] = useState<boolean>(false);

  // Authenticate and fetch data
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
      return;
    }

    if (user && user.businessId) {
      fetchBranches(user);
      fetchUsers(user.businessId);
    }
  }, []);

  const fetchBranches = async (userObj: User) => {
    const businessId = userObj.businessId;
    if (!businessId) return;
    setLoading(true);
    setError("");
    try {
      const data = await branchService.getBranches(businessId, userObj.id);
      setBranchesList(data);
    } catch (err: any) {
      setError(err.message || "Failed to load branches.");
    } finally {
      setLoading(false);
    }
  };

  const fetchUsers = async (businessId: string) => {
    try {
      const users = await authService.getUsers(businessId);
      setBusinessUsers(users);
    } catch (err: any) {
      console.error("Failed to load users", err);
    }
  };

  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  const handleOpenCreateModal = () => {
    setBranchModalMode("create");
    setEditingBranchId("");
    setFormLogo("");
    setLogoPreview("");
    setFormName("");
    setFormCode(`BR-${(branchesList.length + 1).toString().padStart(2, "0")}`);
    setFormType("retail");
    setFormIsMainBranch(branchesList.length === 0);
    setFormManagerName("");
    setFormPhone("");
    setFormAlternatePhone("");
    setFormEmail("");
    setFormAddress("");
    setFormCity("");
    setFormState("");
    setFormPostalCode("");
    setFormTaxNumber("");
    setFormAllowPosSales(true);
    setFormIsActive(true);
    setIsBranchModalOpen(true);
  };

  const handleOpenEditModal = (branch: BranchItem) => {
    setBranchModalMode("edit");
    setEditingBranchId(branch.id);
    setFormLogo(branch.logo || "");
    setLogoPreview(branch.logo ? (getFullAssetUrl(branch.logo) || branch.logo) : "");
    setFormName(branch.name);
    setFormCode(branch.code || "");
    setFormType(branch.type || "retail");
    setFormIsMainBranch(Boolean(branch.isMainBranch));
    setFormManagerName(branch.managerName || "");
    setFormPhone(branch.phone || "");
    setFormAlternatePhone(branch.alternatePhone || "");
    setFormEmail(branch.email || "");
    setFormAddress(branch.address || "");
    setFormCity(branch.city || "");
    setFormState(branch.state || "");
    setFormPostalCode(branch.postalCode || "");
    setFormTaxNumber(branch.taxNumber || "");
    setFormAllowPosSales(branch.allowPosSales !== false);
    setFormIsActive(branch.isActive);
    setIsBranchModalOpen(true);
  };

  const handleLogoFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Show local preview immediately
    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      setLogoPreview(uploadEvent.target?.result as string);
    };
    reader.readAsDataURL(file);

    try {
      setIsUploadingLogo(true);
      const res = await branchService.uploadLogo(file, editingBranchId || undefined);
      setFormLogo(res.logoUrl);
      setSuccessMessage("Branch logo uploaded successfully!");
    } catch (err: any) {
      setError(err.message || "Failed to upload branch logo.");
    } finally {
      setIsUploadingLogo(false);
    }
  };

  const handleRemoveLogo = () => {
    setFormLogo("");
    setLogoPreview("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleOpenDeleteConfirm = (branch: BranchItem) => {
    setBranchToDelete(branch);
    setIsDeleteConfirmOpen(true);
  };

  const handleOpenUserModal = async (branch: BranchItem) => {
    setActiveBranch(branch);
    setIsUserModalOpen(true);
    setUsersInBranchLoading(true);
    try {
      const assigned: string[] = [];
      for (const u of businessUsers) {
        const uBranches = await branchService.getUserBranches(u.id, branch.businessId);
        if (uBranches.some((b) => b.id === branch.id)) {
          assigned.push(u.id);
        }
      }
      setAssignedUserIds(assigned);
    } catch (err: any) {
      setError("Failed to load assigned users.");
    } finally {
      setUsersInBranchLoading(false);
    }
  };

  const handleBranchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      setError("Branch name is required.");
      return;
    }
    if (!currentUser?.businessId) return;

    setActionLoading(true);
    setError("");
    try {
      const payload = {
        name: formName.trim(),
        code: formCode.trim() || undefined,
        logo: formLogo || undefined,
        type: formType,
        isMainBranch: formIsMainBranch,
        managerName: formManagerName.trim() || undefined,
        phone: formPhone.trim() || undefined,
        alternatePhone: formAlternatePhone.trim() || undefined,
        email: formEmail.trim() || undefined,
        address: formAddress.trim() || undefined,
        city: formCity.trim() || undefined,
        state: formState.trim() || undefined,
        postalCode: formPostalCode.trim() || undefined,
        taxNumber: formTaxNumber.trim() || undefined,
        allowPosSales: formAllowPosSales,
        isActive: formIsActive,
        businessId: currentUser.businessId,
      };

      if (branchModalMode === "create") {
        await branchService.createBranch({
          ...payload,
          createdById: currentUser.id,
        });
        setSuccessMessage("Branch created successfully!");
      } else {
        await branchService.updateBranch(editingBranchId, {
          ...payload,
          updatedById: currentUser.id,
        });
        setSuccessMessage("Branch updated successfully!");
      }
      setIsBranchModalOpen(false);
      fetchBranches(currentUser);
    } catch (err: any) {
      setError(err.message || "Failed to save branch.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteBranch = async () => {
    if (!branchToDelete || !currentUser?.businessId) return;
    setActionLoading(true);
    try {
      await branchService.deleteBranch(branchToDelete.id, currentUser.businessId);
      setSuccessMessage("Branch deleted successfully!");
      setIsDeleteConfirmOpen(false);
      setBranchToDelete(null);
      fetchBranches(currentUser);
    } catch (err: any) {
      setError(err.message || "Failed to delete branch.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleToggleUserAssignment = async (userId: string) => {
    if (!activeBranch || !currentUser?.businessId) return;

    const isAssigned = assignedUserIds.includes(userId);
    setUsersInBranchLoading(true);
    try {
      if (isAssigned) {
        await branchService.removeUserFromBranch(userId, activeBranch.id, currentUser.businessId);
        setAssignedUserIds((prev) => prev.filter((id) => id !== userId));
      } else {
        await branchService.assignUserToBranch({
          userId,
          branchId: activeBranch.id,
          businessId: currentUser.businessId,
        });
        setAssignedUserIds((prev) => [...prev, userId]);
      }
    } catch (err: any) {
      setError(err.message || "Failed to update user assignment.");
    } finally {
      setUsersInBranchLoading(false);
    }
  };

  // Filtered branches list
  const filteredBranches = useMemo(() => {
    return branchesList.filter((branch) => {
      const matchesSearch =
        branch.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (branch.code && branch.code.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (branch.city && branch.city.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (branch.managerName && branch.managerName.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesType =
        selectedTypeFilter === "all" ||
        (selectedTypeFilter === "retail" && (branch.type === "retail" || !branch.type)) ||
        branch.type === selectedTypeFilter;

      return matchesSearch && matchesType;
    });
  }, [branchesList, searchQuery, selectedTypeFilter]);

  // Statistics calculation
  const totalBranches = branchesList.length;
  const retailOutlets = branchesList.filter((b) => b.type === "retail" || !b.type).length;
  const warehouses = branchesList.filter((b) => b.type === "warehouse").length;
  const activeLocations = branchesList.filter((b) => b.isActive).length;

  const getTypeBadge = (type?: string | null) => {
    switch (type) {
      case "warehouse":
        return {
          label: "Warehouse",
          icon: Warehouse,
          className: "bg-amber-500/10 text-amber-400 border-amber-500/25",
        };
      case "showroom":
        return {
          label: "Showroom",
          icon: ShoppingBag,
          className: "bg-purple-500/10 text-purple-400 border-purple-500/25",
        };
      case "head_office":
        return {
          label: "Head Office",
          icon: Building2,
          className: "bg-sky-500/10 text-sky-400 border-sky-500/25",
        };
      case "retail":
      default:
        return {
          label: "Retail Outlet",
          icon: Store,
          className: "bg-emerald-500/10 text-emerald-400 border-emerald-500/25",
        };
    }
  };

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-4">
          <Loader2 className="h-10 w-10 animate-spin text-primary mx-auto" />
          <p className="text-lg font-medium">Redirecting to login...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/branches" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Branches" />
        
        {/* Full-width container matching User Profile & Settings standard */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Notifications */}
          {successMessage && (
            <div className="flex items-center gap-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 p-3.5 rounded-sm text-xs animate-in fade-in-50">
              <CheckCircle className="h-4 w-4 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 bg-rose-500/10 border border-rose-500/30 text-rose-400 p-3.5 rounded-sm text-xs animate-in fade-in-50">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Navigation / Header Actions */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border pb-4">
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold uppercase tracking-wider font-mono text-foreground flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-primary" /> Branch & Location Management
                </h1>
                <span className="text-[10px] text-muted-foreground font-mono">
                  #{branchesList.length} LOCATIONS
                </span>
              </div>
              <p className="text-xs text-muted-foreground">
                Manage business branches, retail shops, storage depots, and assign staff permissions.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <Button
                onClick={handleOpenCreateModal}
                className="h-8 px-4 rounded-sm bg-primary text-primary-foreground hover:bg-primary/90 text-xs font-mono font-bold uppercase tracking-wider gap-1.5 shadow-sm cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Add New Branch
              </Button>
            </div>
          </div>

          {/* Summary KPI Cards Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <Card className="border border-border/70 bg-card/60">
              <CardContent className="p-4 space-y-1">
                <span className="text-[10px] font-mono font-bold uppercase text-muted-foreground">Total Locations</span>
                <p className="text-xl font-mono font-bold text-foreground">{totalBranches}</p>
              </CardContent>
            </Card>

            <Card className="border border-border/70 bg-card/60">
              <CardContent className="p-4 space-y-1">
                <span className="text-[10px] font-mono font-bold uppercase text-muted-foreground">Retail Outlets</span>
                <p className="text-xl font-mono font-bold text-emerald-400">{retailOutlets}</p>
              </CardContent>
            </Card>

            <Card className="border border-border/70 bg-card/60">
              <CardContent className="p-4 space-y-1">
                <span className="text-[10px] font-mono font-bold uppercase text-muted-foreground">Warehouses</span>
                <p className="text-xl font-mono font-bold text-amber-400">{warehouses}</p>
              </CardContent>
            </Card>

            <Card className="border border-border/70 bg-card/60">
              <CardContent className="p-4 space-y-1">
                <span className="text-[10px] font-mono font-bold uppercase text-muted-foreground">Active Status</span>
                <p className="text-xl font-mono font-bold text-primary">{activeLocations}</p>
              </CardContent>
            </Card>
          </div>

          {/* Search and Filters Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative flex-1 w-full sm:max-w-md">
              <Input
                type="text"
                placeholder="Search by branch name, code, manager, city..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                icon={<Search className="w-4 h-4 text-muted-foreground" />}
                className="w-full h-9 text-xs bg-card/40 border-border font-mono"
              />
            </div>

            {/* Type Filter Tabs */}
            <div className="flex items-center gap-1 overflow-x-auto scrollbar-none w-full sm:w-auto">
              {[
                { id: "all", label: "All" },
                { id: "retail", label: "Retail" },
                { id: "warehouse", label: "Warehouse" },
                { id: "showroom", label: "Showroom" },
                { id: "head_office", label: "Head Office" },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setSelectedTypeFilter(tab.id)}
                  className={`px-3 py-1.5 text-xs font-mono font-bold uppercase rounded-sm border transition-colors cursor-pointer whitespace-nowrap ${
                    selectedTypeFilter === tab.id
                      ? "bg-primary text-primary-foreground border-primary"
                      : "border-border text-muted-foreground hover:text-foreground hover:bg-card/40"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Grid List */}
          {loading ? (
            <div className="flex h-64 items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredBranches.length === 0 ? (
            <Card className="p-12 text-center border-dashed border-border/60 bg-card/20 rounded-sm">
              <CardContent className="space-y-4">
                <div className="bg-secondary/40 h-14 w-14 rounded-full flex items-center justify-center mx-auto text-muted-foreground">
                  <Building2 className="h-7 w-7 text-primary" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-bold text-foreground font-mono uppercase">No Branches Found</h3>
                  <p className="text-xs text-muted-foreground max-w-sm mx-auto">
                    {searchQuery
                      ? "No branches match your filter query."
                      : "Get started by adding your first enterprise branch or warehouse outlet."}
                  </p>
                </div>
                <Button
                  onClick={handleOpenCreateModal}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground text-xs font-mono font-bold uppercase"
                >
                  Add Branch
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredBranches.map((branch) => {
                const typeInfo = getTypeBadge(branch.type);
                const TypeIcon = typeInfo.icon;

                return (
                  <Card
                    key={branch.id}
                    className="bg-card/60 backdrop-blur-md border border-border hover:border-primary/40 shadow-sm relative overflow-hidden group transition-all duration-200 flex flex-col justify-between"
                  >
                    {/* Top Status Border Line */}
                    <div
                      className={`absolute top-0 left-0 right-0 h-[2px] ${
                        branch.isActive ? "bg-primary" : "bg-muted-foreground/30"
                      }`}
                    />

                    <CardHeader className="pb-3 pt-5 px-5">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          {/* Circular Branch Logo */}
                          <div className="relative w-11 h-11 rounded-full border border-border/70 bg-secondary/40 overflow-hidden flex items-center justify-center shrink-0 shadow-sm">
                            {branch.logo ? (
                              <img
                                src={getFullAssetUrl(branch.logo) || branch.logo}
                                alt={branch.name}
                                className="w-full h-full object-contain p-1"
                              />
                            ) : (
                              <div className="text-xs font-bold font-mono text-primary uppercase">
                                {branch.name.substring(0, 2)}
                              </div>
                            )}
                          </div>

                          <div className="space-y-1.5 flex-1 min-w-0">
                            {/* Badges Bar */}
                            <div className="flex flex-wrap items-center gap-1.5">
                              {branch.code && (
                                <span className="inline-flex items-center px-1.5 py-0.5 rounded-sm text-[10px] font-mono font-bold uppercase bg-secondary text-foreground border border-border">
                                  #{branch.code}
                                </span>
                              )}

                              <span
                                className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-sm text-[10px] font-mono font-bold uppercase border ${typeInfo.className}`}
                              >
                                <TypeIcon className="w-3 h-3" />
                                {typeInfo.label}
                              </span>

                              {branch.isMainBranch && (
                                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-sm text-[10px] font-mono font-bold uppercase bg-amber-500/10 text-amber-400 border border-amber-500/25">
                                  <Star className="w-3 h-3 fill-amber-400" /> HQ
                                </span>
                              )}
                            </div>

                            <CardTitle className="text-sm sm:text-base font-bold text-foreground font-mono truncate group-hover:text-primary transition-colors">
                              {branch.name}
                            </CardTitle>
                          </div>
                        </div>

                        {/* Status Dot */}
                        <div
                          className={`shrink-0 w-2.5 h-2.5 rounded-full ${
                            branch.isActive ? "bg-emerald-400 animate-pulse" : "bg-muted-foreground/40"
                          }`}
                          title={branch.isActive ? "Active Branch" : "Inactive Branch"}
                        />
                      </div>
                    </CardHeader>

                    <CardContent className="p-5 pt-2 space-y-4 flex-1 flex flex-col justify-between">
                      <div className="space-y-2 text-xs text-muted-foreground font-mono">
                        {/* Manager */}
                        {branch.managerName && (
                          <div className="flex items-center gap-2 text-foreground font-semibold">
                            <UserIcon className="h-3.5 w-3.5 text-primary shrink-0" />
                            <span>Mgr: {branch.managerName}</span>
                          </div>
                        )}

                        {/* Location */}
                        <div className="flex items-start gap-2">
                          <MapPin className="h-3.5 w-3.5 text-primary/70 shrink-0 mt-0.5" />
                          <span className="line-clamp-1">
                            {branch.city || branch.state
                              ? `${branch.city ? branch.city + ", " : ""}${branch.state || ""}`
                              : branch.address || "No location specified"}
                          </span>
                        </div>

                        {/* Phone / Alternate Phone */}
                        {(branch.phone || branch.alternatePhone) && (
                          <div className="flex items-center gap-2">
                            <Phone className="h-3.5 w-3.5 text-primary/70 shrink-0" />
                            <span>
                              {branch.phone}
                              {branch.alternatePhone ? ` / ${branch.alternatePhone}` : ""}
                            </span>
                          </div>
                        )}

                        {/* Email */}
                        {branch.email && (
                          <div className="flex items-center gap-2">
                            <Mail className="h-3.5 w-3.5 text-primary/70 shrink-0" />
                            <span className="truncate">{branch.email}</span>
                          </div>
                        )}

                        {/* Tax Number */}
                        {branch.taxNumber && (
                          <div className="flex items-center gap-2">
                            <Hash className="h-3.5 w-3.5 text-primary/70 shrink-0" />
                            <span>Tax ID: {branch.taxNumber}</span>
                          </div>
                        )}

                        {/* POS Availability Pill */}
                        <div className="pt-1">
                          <span
                            className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-sm border uppercase ${
                              branch.allowPosSales !== false
                                ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/25"
                                : "bg-muted text-muted-foreground border-border"
                            }`}
                          >
                            <Monitor className="w-3 h-3" />
                            {branch.allowPosSales !== false ? "POS Terminal Active" : "Warehouse Storage Only"}
                          </span>
                        </div>
                      </div>

                      {/* Bottom Actions Bar */}
                      <div className="pt-4 border-t border-border/50 flex items-center justify-between gap-2">
                        <Button
                          variant="outline"
                          onClick={() => handleOpenUserModal(branch)}
                          className="h-8 text-xs font-mono bg-card border-border hover:bg-primary/10 hover:text-primary rounded-sm flex items-center gap-1.5 cursor-pointer"
                        >
                          <Users className="h-3.5 w-3.5" />
                          Assign Staff
                        </Button>

                        <div className="flex items-center gap-1.5">
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => handleOpenEditModal(branch)}
                            className="h-8 w-8 text-muted-foreground hover:text-primary bg-card border-border hover:bg-primary/10 cursor-pointer"
                            title="Edit Branch"
                          >
                            <Edit2 className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => handleOpenDeleteConfirm(branch)}
                            className="h-8 w-8 text-muted-foreground hover:text-rose-500 bg-card border-border hover:bg-rose-500/10 cursor-pointer"
                            title="Delete Branch"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </main>
      </div>

      {/* Spacious 2-Column Branch Create / Edit Modal */}
      {isBranchModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-2xl bg-card border border-border rounded-sm shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150 my-8">
            <div className="flex items-center justify-between border-b border-border p-5 bg-background/50">
              <div className="flex items-center gap-2.5">
                <Building2 className="w-5 h-5 text-primary" />
                <h2 className="text-sm font-bold text-foreground tracking-wider uppercase font-mono">
                  {branchModalMode === "create" ? "Add Enterprise Branch" : "Edit Branch Configuration"}
                </h2>
              </div>
              <button
                onClick={() => setIsBranchModalOpen(false)}
                className="text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleBranchSubmit} className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
              {/* Section 1: Identification & Classification */}
              <div className="space-y-4">
                <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-primary flex items-center gap-2">
                  <Building2 className="w-4 h-4" /> 1. Identification & Classification
                </h3>

                {/* Branch Logo Upload Box */}
                <div className="p-3.5 rounded-sm border border-border bg-card/40 flex flex-col sm:flex-row sm:items-center gap-4">
                  <div className="relative w-16 h-16 rounded-full border-2 border-dashed border-border flex items-center justify-center bg-secondary/30 shrink-0 overflow-hidden group">
                    {logoPreview ? (
                      <>
                        <img
                          src={logoPreview}
                          alt="Branch Logo"
                          className="w-full h-full object-contain p-1"
                          onError={() => setLogoPreview("")}
                        />
                        <button
                          type="button"
                          onClick={handleRemoveLogo}
                          className="absolute top-0 right-0 bg-black/70 hover:bg-rose-600 text-white rounded-full p-0.5 transition-colors cursor-pointer"
                          title="Remove Logo"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </>
                    ) : (
                      <div className="text-center">
                        <ImageIcon className="w-5 h-5 text-muted-foreground mx-auto opacity-60" />
                        <span className="text-[9px] text-muted-foreground block font-mono">No Logo</span>
                      </div>
                    )}

                    {isUploadingLogo && (
                      <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
                        <Loader2 className="w-5 h-5 animate-spin text-primary" />
                      </div>
                    )}
                  </div>

                  <div className="space-y-1 flex-1">
                    <h4 className="text-xs font-bold text-foreground font-mono uppercase">Branch Specific Logo</h4>
                    <p className="text-[11px] text-muted-foreground">
                      Overrides the business logo on thermal receipts and invoice headers issued by this branch.
                    </p>
                    <div className="flex items-center gap-2 pt-0.5">
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/png, image/jpeg, image/webp, image/svg+xml"
                        onChange={handleLogoFileChange}
                        className="hidden"
                        id="branch-logo-file"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => fileInputRef.current?.click()}
                        disabled={isUploadingLogo}
                        className="h-7 text-xs font-mono font-semibold gap-1.5 rounded-sm border-border cursor-pointer"
                      >
                        <Upload className="w-3 h-3" />
                        {logoPreview ? "Change Logo" : "Upload Logo"}
                      </Button>
                      {logoPreview && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={handleRemoveLogo}
                          className="h-7 text-xs font-mono text-rose-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-sm cursor-pointer"
                        >
                          Remove
                        </Button>
                      )}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Branch Name */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">
                      Branch Name *
                    </label>
                    <Input
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                      placeholder="e.g. Colombo Central Outlet"
                      className="text-xs h-9 rounded-sm"
                      required
                    />
                  </div>

                  {/* Branch Code */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono flex items-center gap-1">
                      <Hash className="w-3 h-3 text-primary" /> Branch Code
                    </label>
                    <Input
                      value={formCode}
                      onChange={(e) => setFormCode(e.target.value)}
                      placeholder="e.g. BR-01 or COL-MAIN"
                      className="text-xs h-9 rounded-sm font-mono uppercase"
                    />
                  </div>

                  {/* Branch Type */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">
                      Branch Type
                    </label>
                    <select
                      value={formType}
                      onChange={(e) => setFormType(e.target.value)}
                      className="w-full h-9 px-3 bg-background border border-input text-foreground rounded-sm text-xs focus:outline-none focus:border-primary transition-all font-mono"
                    >
                      <option value="retail">Retail Store / Outlet</option>
                      <option value="warehouse">Warehouse / Storage Depot</option>
                      <option value="showroom">Showroom / Display Center</option>
                      <option value="head_office">Head Office / Headquarters</option>
                    </select>
                  </div>

                  {/* Is Main Branch Toggle */}
                  <div className="flex items-center gap-3 pt-5">
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formIsMainBranch}
                        onChange={(e) => setFormIsMainBranch(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-secondary peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-primary"></div>
                    </label>
                    <div>
                      <span className="text-xs font-bold font-mono uppercase text-foreground flex items-center gap-1">
                        <Star className="w-3 h-3 text-amber-400" /> Main Headquarters Branch
                      </span>
                      <p className="text-[10px] text-muted-foreground">Sets this location as the default primary entity.</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Section 2: Manager & Contact Details */}
              <div className="space-y-4 pt-4 border-t border-border">
                <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-primary flex items-center gap-2">
                  <UserIcon className="w-4 h-4" /> 2. Management & Contacts
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Manager Name */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">
                      Branch Manager / Contact Person
                    </label>
                    <Input
                      value={formManagerName}
                      onChange={(e) => setFormManagerName(e.target.value)}
                      placeholder="e.g. Mohamed Ilham"
                      className="text-xs h-9 rounded-sm"
                    />
                  </div>

                  {/* Official Email */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">
                      Branch Email
                    </label>
                    <Input
                      type="email"
                      value={formEmail}
                      onChange={(e) => setFormEmail(e.target.value)}
                      placeholder="e.g. colombo@hkrsystems.com"
                      className="text-xs h-9 rounded-sm font-mono"
                    />
                  </div>

                  {/* Primary Phone */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">
                      Primary Phone Number
                    </label>
                    <Input
                      value={formPhone}
                      onChange={(e) => setFormPhone(e.target.value)}
                      placeholder="e.g. 011 234 5678"
                      className="text-xs h-9 rounded-sm font-mono"
                    />
                  </div>

                  {/* Alternate / WhatsApp Phone */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">
                      Alternate / WhatsApp Phone
                    </label>
                    <Input
                      value={formAlternatePhone}
                      onChange={(e) => setFormAlternatePhone(e.target.value)}
                      placeholder="e.g. 077 123 4567"
                      className="text-xs h-9 rounded-sm font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Section 3: Physical Address */}
              <div className="space-y-4 pt-4 border-t border-border">
                <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-primary flex items-center gap-2">
                  <MapPin className="w-4 h-4" /> 3. Address & Geographical Location
                </h3>

                {/* Street Address */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">
                    Street Address / Building Premise
                  </label>
                  <Input
                    value={formAddress}
                    onChange={(e) => setFormAddress(e.target.value)}
                    placeholder="e.g. No. 124, Galle Road, Commercial Plaza"
                    className="text-xs h-9 rounded-sm"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {/* City */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">
                      City / Town
                    </label>
                    <Input
                      value={formCity}
                      onChange={(e) => setFormCity(e.target.value)}
                      placeholder="e.g. Colombo"
                      className="text-xs h-9 rounded-sm"
                    />
                  </div>

                  {/* State */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">
                      State / Province
                    </label>
                    <Input
                      value={formState}
                      onChange={(e) => setFormState(e.target.value)}
                      placeholder="e.g. Western"
                      className="text-xs h-9 rounded-sm"
                    />
                  </div>

                  {/* Postal Code */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono">
                      Postal Code
                    </label>
                    <Input
                      value={formPostalCode}
                      onChange={(e) => setFormPostalCode(e.target.value)}
                      placeholder="e.g. 00300"
                      className="text-xs h-9 rounded-sm font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Section 4: Operations & Tax */}
              <div className="space-y-4 pt-4 border-t border-border">
                <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-primary flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4" /> 4. Operations & Tax Configuration
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Branch Tax Number */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider font-mono flex items-center gap-1">
                      <Hash className="w-3 h-3 text-primary" /> Branch Tax / VAT / TIN Number
                    </label>
                    <Input
                      value={formTaxNumber}
                      onChange={(e) => setFormTaxNumber(e.target.value)}
                      placeholder="e.g. VAT-987654-000"
                      className="text-xs h-9 rounded-sm font-mono uppercase"
                    />
                  </div>

                  {/* Allow POS Sales Toggle */}
                  <div className="flex items-center gap-3 pt-4">
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formAllowPosSales}
                        onChange={(e) => setFormAllowPosSales(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-secondary peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-primary"></div>
                    </label>
                    <div>
                      <span className="text-xs font-bold font-mono uppercase text-foreground">
                        Enable POS Terminal Checkout
                      </span>
                      <p className="text-[10px] text-muted-foreground">Allows cashiers to bill sales from this location.</p>
                    </div>
                  </div>
                </div>

                {/* Active Status */}
                <div className="flex items-center gap-3 pt-2">
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formIsActive}
                      onChange={(e) => setFormIsActive(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-secondary peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-primary"></div>
                  </label>
                  <div>
                    <span className="text-xs font-bold font-mono uppercase text-foreground">
                      Branch Active & Operational
                    </span>
                    <p className="text-[10px] text-muted-foreground">Uncheck to temporarily suspend operations.</p>
                  </div>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="flex items-center justify-end gap-3 pt-5 border-t border-border">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsBranchModalOpen(false)}
                  className="h-9 px-4 text-xs font-mono rounded-sm border-border cursor-pointer"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={actionLoading}
                  className="h-9 px-6 text-xs font-mono font-bold uppercase rounded-sm bg-primary text-primary-foreground hover:bg-primary/90 cursor-pointer"
                >
                  {actionLoading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : branchModalMode === "create" ? (
                    "Create Branch"
                  ) : (
                    "Save Changes"
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* User Assignment Modal */}
      {isUserModalOpen && activeBranch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg bg-card border border-border rounded-sm shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-border p-5 bg-background/50">
              <div>
                <h2 className="text-sm font-bold text-foreground tracking-wider uppercase font-mono flex items-center gap-2">
                  <Users className="w-4 h-4 text-primary" /> Assign Team Members
                </h2>
                <p className="text-xs text-muted-foreground font-mono mt-0.5">
                  Location: <span className="text-foreground font-bold">{activeBranch.name}</span>
                </p>
              </div>
              <button
                onClick={() => setIsUserModalOpen(false)}
                className="text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="p-5 max-h-96 overflow-y-auto space-y-2">
              {usersInBranchLoading ? (
                <div className="py-10 flex items-center justify-center text-muted-foreground">
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                </div>
              ) : businessUsers.length === 0 ? (
                <div className="text-center py-8 text-xs text-muted-foreground font-mono">
                  No staff members available in this business.
                </div>
              ) : (
                businessUsers.map((user) => {
                  const isAssigned = assignedUserIds.includes(user.id);
                  return (
                    <div
                      key={user.id}
                      onClick={() => handleToggleUserAssignment(user.id)}
                      className={`flex items-center justify-between p-3 rounded-sm border cursor-pointer transition-colors ${
                        isAssigned
                          ? "bg-primary/10 border-primary/30 text-foreground"
                          : "bg-card/40 border-border hover:bg-card text-muted-foreground"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-xs font-mono font-bold text-primary">
                          {(user.name || user.email).substring(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <p className="text-xs font-bold font-mono text-foreground">{user.name || "Unnamed User"}</p>
                          <p className="text-[10px] text-muted-foreground font-mono">{user.email}</p>
                        </div>
                      </div>

                      <span
                        className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-sm border uppercase ${
                          isAssigned
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-secondary text-muted-foreground border-border"
                        }`}
                      >
                        {isAssigned ? "Assigned" : "Assign"}
                      </span>
                    </div>
                  );
                })
              )}
            </div>

            <div className="p-4 border-t border-border bg-background/30 flex justify-end">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsUserModalOpen(false)}
                className="text-xs font-mono rounded-sm border-border cursor-pointer"
              >
                Close
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {isDeleteConfirmOpen && branchToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm bg-card border border-border rounded-sm shadow-2xl p-5 space-y-4">
            <div className="flex items-center gap-3 text-rose-500">
              <AlertCircle className="w-6 h-6" />
              <h3 className="text-sm font-bold uppercase font-mono">Delete Branch Location</h3>
            </div>
            <p className="text-xs text-muted-foreground">
              Are you sure you want to delete <span className="font-bold text-foreground">{branchToDelete.name}</span>?
              This action cannot be undone.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsDeleteConfirmOpen(false)}
                className="text-xs font-mono rounded-sm"
              >
                Cancel
              </Button>
              <Button
                size="sm"
                onClick={handleDeleteBranch}
                disabled={actionLoading}
                className="text-xs font-mono font-bold uppercase bg-rose-600 hover:bg-rose-700 text-white rounded-sm"
              >
                {actionLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : "Delete Branch"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
