import React from "react";
import { AdminUser } from "../types";
import { SITE_CONFIG } from "@/lib/constants/site";

interface SecurityTabProps {
  adminUser: AdminUser | null;
}

export function SecurityTab({ adminUser }: SecurityTabProps) {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#24242C] pb-6">
        <div>
          <h1 className="font-sans text-xl sm:text-2xl text-white font-semibold tracking-tight">
            System &amp; Database Status
          </h1>
          <p className="text-xs text-[#A1A1AA] font-sans mt-1">
            System health, database connection details, and active admin session.
          </p>
        </div>
        <span className="flex items-center gap-2 px-3 py-1.5 bg-emerald-950/50 border border-emerald-800 text-emerald-300 font-mono text-xs tabular-nums rounded-sm">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          Database Connected &amp; Live
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Database Parameters Card */}
        <div className="bg-[#141419] border border-[#24242C] p-6 rounded-sm space-y-4">
          <h3 className="font-sans text-base font-semibold text-white tracking-tight border-b border-[#24242C] pb-3">
            Database Connection Details
          </h3>
          <div className="space-y-2.5 text-xs font-mono tabular-nums">
            <div className="flex justify-between py-1 border-b border-[#1F1E26]">
              <span className="text-[#8C867D]">Database Name:</span>
              <span className="text-white">gem_ecommerce</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1F1E26]">
              <span className="text-[#8C867D]">Host Address:</span>
              <span className="text-white">127.0.0.1:3306</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1F1E26]">
              <span className="text-[#8C867D]">Driver:</span>
              <span className="text-emerald-400">mysql2 (Connection Pool Singleton)</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1F1E26]">
              <span className="text-[#8C867D]">ORM Engine:</span>
              <span className="text-[#C5A880]">Prisma 7.9.1</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1F1E26]">
              <span className="text-[#8C867D]">Database Seed:</span>
              <span className="text-white">prisma/seed.mjs (Verified)</span>
            </div>
          </div>
        </div>

        {/* Session & Cryptography Card */}
        <div className="bg-[#141419] border border-[#24242C] p-6 rounded-sm space-y-4">
          <h3 className="font-sans text-base font-semibold text-white tracking-tight border-b border-[#24242C] pb-3">
            Admin Session Details
          </h3>
          <div className="space-y-2.5 text-xs font-mono tabular-nums">
            <div className="flex justify-between py-1 border-b border-[#1F1E26]">
              <span className="text-[#8C867D]">Login Security:</span>
              <span className="text-white">HMAC SHA-256 Signed Tokens</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1F1E26]">
              <span className="text-[#8C867D]">Session Cookie:</span>
              <span className="text-white">faizan_admin_session (HttpOnly, Secure)</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1F1E26]">
              <span className="text-[#8C867D]">Current User:</span>
              <span className="text-white">{adminUser?.name || "Admin"}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1F1E26]">
              <span className="text-[#8C867D]">User Email:</span>
              <span className="text-[#C5A880]">{adminUser?.email || SITE_CONFIG.contact.adminEmail}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1F1E26]">
              <span className="text-[#8C867D]">Access Level:</span>
              <span className="text-emerald-400">Admin (Full Access)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
