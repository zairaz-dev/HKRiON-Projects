import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { stockTransferService } from "@/services/stock-transfer-service";
import { queryKeys } from "@/lib/query-keys";

export function useStockTransfersQuery(
  businessId: string,
  filters: {
    fromBranchId?: string;
    toBranchId?: string;
    status?: 'PENDING' | 'COMPLETED' | 'CANCELLED';
    search?: string;
    page?: number;
    limit?: number;
  },
) {
  return useQuery({
    queryKey: queryKeys.stockTransfers.list(
      businessId,
      filters.fromBranchId,
      filters.toBranchId,
      filters.status,
      filters.search,
      filters.page,
      filters.limit,
    ),
    queryFn: () => stockTransferService.getStockTransfers(businessId, filters),
    enabled: !!businessId,
  });
}

export function useCreateStockTransferMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: Parameters<typeof stockTransferService.createStockTransfer>[0]) =>
      stockTransferService.createStockTransfer(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.stockTransfers.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.purchases.all });
    },
  });
}

export function useUpdateTransferStatusMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, businessId, status }: { id: string; businessId: string; status: 'PENDING' | 'COMPLETED' | 'CANCELLED' }) =>
      stockTransferService.updateTransferStatus(id, businessId, status),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.stockTransfers.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.purchases.all });
    },
  });
}

export function useStockTransferDetailQuery(id: string, businessId: string) {
  return useQuery({
    queryKey: queryKeys.stockTransfers.detail(id),
    queryFn: () => stockTransferService.getStockTransferById(id, businessId),
    enabled: !!id && !!businessId,
  });
}
