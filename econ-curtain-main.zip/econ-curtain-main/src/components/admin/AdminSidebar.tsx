"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Home,
  Info,
  Layers,
  Package,
  FolderKanban,
  Image as ImageIcon,
  MessageSquare,
  PhoneCall,
  Settings,
  Users,
  LogOut,
  X,
} from "lucide-react";

interface AdminSidebarProps {
  user: {
    name: string;
    email: string;
    role: string;
  };
}

interface NavItem {
  label: string;
  href: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  active: boolean;
  badge?: string;
  badgeColor?: string;
}

interface NavGroup {
  title: string;
  items: NavItem[];
}

export default function AdminSidebar({ user }: AdminSidebarProps) {
  const pathname = usePathname();

  const navGroups: NavGroup[] = [
    {
      title: "OVERVIEW",
      items: [
        {
          label: "Dashboard",
          href: "/admin",
          icon: LayoutDashboard,
          active: pathname === "/admin",
          badge: "Overview",
        },
      ],
    },
    {
      title: "WEBSITE CONTENT",
      items: [
        {
          label: "Home Page (CMS)",
          href: "/admin/homepage",
          icon: Home,
          active: pathname.startsWith("/admin/homepage") || pathname === "/admin/cms",
          badge: "Editor",
        },
        {
          label: "About Page",
          href: "/admin/about",
          icon: Info,
          active: pathname.startsWith("/admin/about"),
        },
        {
          label: "Solutions",
          href: "/admin/categories",
          icon: Layers,
          active: pathname.startsWith("/admin/categories"),
        },
        {
          label: "Products Catalog",
          href: "/admin/products",
          icon: Package,
          active: pathname.startsWith("/admin/products"),
          badge: "13 Items",
        },
        {
          label: "Featured Projects",
          href: "/admin/projects",
          icon: FolderKanban,
          active: pathname.startsWith("/admin/projects"),
        },
      ],
    },
    {
      title: "BUSINESS & CRM",
      items: [
        {
          label: "Leads & Inquiries",
          href: "/admin/inquiries",
          icon: MessageSquare,
          active: pathname.startsWith("/admin/inquiries"),
          badge: "Live",
          badgeColor: "bg-emerald-50 text-emerald-700 border-emerald-200",
        },
        {
          label: "Contact Details",
          href: "/admin/contact",
          icon: PhoneCall,
          active: pathname.startsWith("/admin/contact"),
        },
      ],
    },
    {
      title: "SYSTEM & ASSETS",
      items: [
        {
          label: "Media Library",
          href: "/admin/media",
          icon: ImageIcon,
          active: pathname.startsWith("/admin/media"),
        },
        {
          label: "Global Settings",
          href: "/admin/settings",
          icon: Settings,
          active: pathname.startsWith("/admin/settings"),
        },
        {
          label: "Admin Users",
          href: "/admin/users",
          icon: Users,
          active: pathname.startsWith("/admin/users"),
        },
      ],
    },
  ];

  return (
    <>
      {/* Pure HTML Native Checkbox for Zero-JS Mobile Toggle */}
      <input
        type="checkbox"
        id="admin-sidebar-toggle"
        className="peer hidden"
        aria-hidden="true"
      />

      {/* Mobile Backdrop Overlay */}
      <label
        htmlFor="admin-sidebar-toggle"
        className="hidden peer-checked:block lg:peer-checked:hidden fixed inset-0 z-40 bg-neutral-900/60 backdrop-blur-xs cursor-pointer select-none transition-opacity"
        aria-label="Close sidebar"
      />

      {/* Main Sidebar */}
      <aside
        id="admin-sidebar"
        className="fixed top-0 bottom-0 left-0 z-50 w-64 bg-white dark:bg-black border-r border-[#E5E5E0] dark:border-neutral-800 flex flex-col justify-between transition-transform duration-300 ease-in-out -translate-x-full peer-checked:translate-x-0 lg:translate-x-0 shadow-xl lg:shadow-none"
      >
        {/* Top: Brand Header */}
        <div className="flex flex-col h-full overflow-hidden">
          <div className="h-16 px-5 border-b border-[#E5E5E0] dark:border-neutral-800 flex items-center justify-between shrink-0 bg-white dark:bg-black">
            <Link href="/admin" className="flex items-center gap-2.5 group">
              <div className="w-8 h-8 rounded-none bg-amber-500 flex items-center justify-center text-slate-950 font-black text-xs shadow-xs group-hover:brightness-110 transition-all">
                S
              </div>
              <div className="flex flex-col">
                <span className="text-sm font-black tracking-tight text-neutral-900 dark:text-white">SHADEIT</span>
                <span className="text-[10px] uppercase font-bold tracking-widest text-amber-700 dark:text-amber-400 -mt-1">CONTROL CENTER</span>
              </div>
            </Link>

            {/* Mobile Close Button */}
            <label
              htmlFor="admin-sidebar-toggle"
              className="lg:hidden p-1.5 rounded-none text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-900 cursor-pointer select-none"
              aria-label="Close sidebar"
            >
              <X size={18} />
            </label>
          </div>

          {/* Grouped Navigation Links */}
          <div className="p-3 overflow-y-auto grow space-y-6 scrollbar-thin">
            {navGroups.map((group) => (
              <div key={group.title} className="space-y-1">
                <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-neutral-400 dark:text-neutral-500">
                  {group.title}
                </div>
                <nav className="space-y-0.5">
                  {group.items.map((item) => {
                    const Icon = item.icon;
                    return (
                      <Link
                        key={item.label}
                        href={item.href}
                        className={`flex items-center justify-between px-3 py-2 rounded-none text-xs font-semibold transition-all ${
                          item.active
                            ? "bg-amber-500/10 dark:bg-amber-500/15 text-amber-950 dark:text-amber-300 font-bold border-l-2 border-amber-500"
                            : "text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-900"
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <Icon
                            size={16}
                            className={item.active ? "text-amber-600 dark:text-amber-400" : "text-neutral-500 dark:text-neutral-400"}
                          />
                          <span>{item.label}</span>
                        </div>
                        {item.badge && (
                          <span
                            className={`text-[9px] px-1.5 py-0.5 rounded-none font-bold uppercase tracking-wider border ${
                              item.badgeColor ||
                              (item.active
                                ? "bg-amber-500 text-black border-amber-600 font-extrabold"
                                : "bg-neutral-100 dark:bg-neutral-900 text-neutral-500 dark:text-neutral-400 border-neutral-200 dark:border-neutral-800")
                            }`}
                          >
                            {item.badge}
                          </span>
                        )}
                      </Link>
                    );
                  })}
                </nav>
              </div>
            ))}
          </div>

          {/* Bottom Profile & Logout Footer */}
          <div className="p-3 border-t border-[#E5E5E0] dark:border-neutral-800 bg-neutral-50 dark:bg-black space-y-2 shrink-0">
            {/* User Profile info */}
            <div className="flex items-center gap-2.5 px-2.5 py-2 rounded-none bg-white dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800">
              <div className="w-8 h-8 rounded-none bg-amber-100 dark:bg-amber-500/20 border border-amber-300 dark:border-amber-500/40 text-amber-800 dark:text-amber-400 font-bold text-xs flex items-center justify-center shrink-0">
                {user.name ? user.name.charAt(0).toUpperCase() : "A"}
              </div>
              <div className="overflow-hidden min-w-0">
                <p className="text-xs font-bold text-neutral-900 dark:text-white truncate">{user.name}</p>
                <p className="text-[10px] text-neutral-500 dark:text-neutral-400 truncate">{user.email}</p>
              </div>
            </div>

            {/* Logout Action */}
            <form method="POST" action="/api/auth/logout" className="w-full">
              <button
                type="submit"
                className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-none text-neutral-500 dark:text-neutral-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-500/10 text-xs font-medium transition-colors cursor-pointer"
              >
                <LogOut size={13} />
                <span>Sign Out</span>
              </button>
            </form>
          </div>
        </div>
      </aside>
    </>
  );
}
