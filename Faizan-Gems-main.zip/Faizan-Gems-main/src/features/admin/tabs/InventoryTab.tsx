import React, { useState, useMemo, useRef, useEffect } from "react";
import { createPortal } from "react-dom";
import Image from "next/image";
import Link from "next/link";
import {
  Gemstone,
  GemstoneType,
  GemstoneCut,
  GemstoneVariant,
  TreatmentType,
  CertificationLab,
  extractCountryFromOrigin,
} from "@/types/gemstone";
import { SearchIcon, CloseIcon } from "@/components/ui/LuxuryIcons";
import { LuxurySelect } from "@/components/ui/LuxurySelect";
import { ImageCropModal, CropCoordinates } from "@/components/ui/ImageCropModal";
import { EditGemstoneModal } from "../components/EditGemstoneModal";
import { LuxuryPrice } from "@/components/ui/LuxuryPrice";
import { useToast } from "@/components/ui/LuxuryToast";
import { NewGemstoneForm } from "../types";
import { useGemstoneAttributes, AttributeCategory } from "../hooks/useGemstoneAttributes";
import { compressAndLimitVideo } from "@/lib/video-compressor";

interface InventoryTabProps {
  gemstonesList: Gemstone[];
  totalVaultValue: number;
  formatPrice: (price: number) => string;
  isAddModalOpen: boolean;
  setIsAddModalOpen: (open: boolean) => void;
  onAddGemstone: (gem: NewGemstoneForm) => void;
  onDeleteGemstone: (id: string) => void;
  onUpdateGemstone?: (id: string, updated: Partial<Gemstone>) => Promise<void> | void;
}

const INITIAL_NEW_GEM: NewGemstoneForm = {
  name: "",
  type: "Sapphire",
  variety: "",
  carat: 0,
  price: 0,
  cut: "Cushion",
  cutDetail: "",
  color: "",
  colorGrade: "",
  clarity: "Eye Clean",
  origin: "",
  originCountry: "",
  treatment: "Unheated / Untreated",
  description: "",
  imageUrl: "",
};

export function InventoryTab({
  gemstonesList,
  totalVaultValue,
  formatPrice,
  isAddModalOpen,
  setIsAddModalOpen,
  onAddGemstone,
  onDeleteGemstone,
  onUpdateGemstone,
}: InventoryTabProps) {
  const { toast } = useToast();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const [inventorySearch, setInventorySearch] = useState("");
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<string>("All");

  const {
    types: availableTypes,
    cuts: availableCuts,
    clarities: availableClarities,
    treatments: availableTreatments,
    addCustomOption,
    editCustomOption,
    deleteCustomOption,
  } = useGemstoneAttributes(gemstonesList);

  const varietyFilterOptions = useMemo(() => {
    return ["All", ...availableTypes.slice(0, 8)].map((type) => ({
      value: type,
      label: type === "All" ? "All Varieties" : type,
    }));
  }, [availableTypes]);

  const [addingField, setAddingField] = useState<AttributeCategory | null>(null);
  const [customAttributeInput, setCustomAttributeInput] = useState("");

  const handleSaveCustomAttribute = (category: AttributeCategory) => {
    if (!customAttributeInput.trim()) return;
    const added = addCustomOption(category, customAttributeInput);
    if (added) {
      if (category === "type") {
        setNewGem((prev) => ({
          ...prev,
          type: added as GemstoneType,
          variety: `Natural ${added}`,
        }));
      } else if (category === "cut") {
        setNewGem((prev) => ({
          ...prev,
          cut: added as GemstoneCut,
          cutDetail: `${added} Precision Cut`,
        }));
      } else if (category === "clarity") {
        setNewGem((prev) => ({
          ...prev,
          clarity: added,
        }));
      } else if (category === "treatment") {
        setNewGem((prev) => ({
          ...prev,
          treatment: added as TreatmentType,
          isUnheated: added.toLowerCase().includes("unheated"),
        }));
      }
      toast.success("Option Added", `"${added}" added to ${category} and selected.`);
    }
    setAddingField(null);
    setCustomAttributeInput("");
  };

  // Multi-Image Upload & Management States (No default image)
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [photoUploadError, setPhotoUploadError] = useState<string | null>(null);

  // Crop States
  const [cropFile, setCropFile] = useState<File | null>(null);
  const [cropUrl, setCropUrl] = useState<string | null>(null);
  const [cropTargetIndex, setCropTargetIndex] = useState<number | null>(null);
  const [isCropModalOpen, setIsCropModalOpen] = useState(false);
  const [isCroppingAndSaving, setIsCroppingAndSaving] = useState(false);

  const photoFileInputRef = useRef<HTMLInputElement>(null);

  // Video Showcase State (Strict 8s time limit & auto-compression)
  const [uploadedVideo, setUploadedVideo] = useState<string | null>(null);
  const [isProcessingVideo, setIsProcessingVideo] = useState(false);
  const [videoProcessingStatus, setVideoProcessingStatus] = useState<string>("");
  const [videoError, setVideoError] = useState<string | null>(null);
  const videoFileInputRef = useRef<HTMLInputElement>(null);

  // Specimen Carat Weight, Price, Stock & Dimensions State (Blank with placeholder hints)
  const [specimenWeight, setSpecimenWeight] = useState<number | string>("");
  const [specimenPrice, setSpecimenPrice] = useState<number | string>("");
  const [specimenStock, setSpecimenStock] = useState<number | string>("");
  const [specimenSize, setSpecimenSize] = useState<string>("");

  // Edit Gemstone Modal State
  const [editingGem, setEditingGem] = useState<Gemstone | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  const handleSaveEditedGem = async (id: string, updated: Partial<Gemstone>) => {
    if (onUpdateGemstone) {
      await onUpdateGemstone(id, updated);
    } else {
      const res = await fetch(`/api/gemstones/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updated),
      });
      if (!res.ok) {
        throw new Error("Failed to update gemstone in vault");
      }
    }
  };

  // Actions Dropdown State
  const [actionDropdownId, setActionDropdownId] = useState<string | null>(null);

  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest("[data-action-menu]")) {
        setActionDropdownId(null);
      }
    };
    if (actionDropdownId) {
      document.addEventListener("mousedown", handleOutsideClick);
      return () => document.removeEventListener("mousedown", handleOutsideClick);
    }
  }, [actionDropdownId]);

  const [newGem, setNewGem] = useState<NewGemstoneForm>(INITIAL_NEW_GEM);

  const filteredInventory = useMemo(() => {
    return gemstonesList.filter((g) => {
      const matchesSearch =
        inventorySearch === "" ||
        g.name.toLowerCase().includes(inventorySearch.toLowerCase()) ||
        g.sku.toLowerCase().includes(inventorySearch.toLowerCase()) ||
        g.origin.toLowerCase().includes(inventorySearch.toLowerCase());

      const matchesType =
        selectedTypeFilter === "All" || g.type === selectedTypeFilter;

      return matchesSearch && matchesType;
    });
  }, [gemstonesList, inventorySearch, selectedTypeFilter]);

  // Upload Multi-Files directly
  const handleMultiFileUpload = async (files: FileList | File[]) => {
    setIsUploadingPhoto(true);
    setPhotoUploadError(null);

    try {
      const newUrls: string[] = [];
      for (const file of Array.from(files)) {
        const formData = new FormData();
        formData.append("file", file);
        formData.append("category", "gemstones");

        const res = await fetch("/api/admin/upload", {
          method: "POST",
          body: formData,
        });

        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || "Upload failed");
        }
        newUrls.push(data.url);
      }

      setUploadedImages((prev) => [...prev, ...newUrls]);
      toast.success("Photos Uploaded", `${newUrls.length} gemstone photo(s) added.`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Failed to upload photo";
      setPhotoUploadError(msg);
      toast.error("Upload Error", msg);
    } finally {
      setIsUploadingPhoto(false);
    }
  };

  // Select a single photo to crop
  const handleOpenCropForIndex = (index: number) => {
    setCropTargetIndex(index);
    setCropFile(null);
    setCropUrl(uploadedImages[index]);
    setIsCropModalOpen(true);
  };

  // Process Crop and Save with Sharp
  const handleCropAndSave = async (cropData: CropCoordinates) => {
    setIsCroppingAndSaving(true);
    setPhotoUploadError(null);

    try {
      const formData = new FormData();
      if (cropFile) {
        formData.append("file", cropFile);
      } else if (cropUrl) {
        formData.append("imageUrl", cropUrl);
      }
      formData.append("category", "gemstones");
      formData.append("crop", JSON.stringify(cropData));

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        body: formData,
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Cropping and upload failed");
      }

      if (cropTargetIndex !== null) {
        setUploadedImages((prev) =>
          prev.map((img, idx) => (idx === cropTargetIndex ? data.url : img))
        );
      } else {
        setUploadedImages((prev) => [...prev, data.url]);
      }

      setIsCropModalOpen(false);
      setCropTargetIndex(null);
      toast.success("Photo Cropped", "Gemstone image updated successfully.");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Failed to crop and save photo";
      setPhotoUploadError(msg);
      toast.error("Photo Error", msg);
    } finally {
      setIsCroppingAndSaving(false);
    }
  };

  const handleRemoveImage = (indexToRemove: number) => {
    setUploadedImages((prev) => prev.filter((_, idx) => idx !== indexToRemove));
  };

  const handleVideoUpload = async (file: File) => {
    setIsProcessingVideo(true);
    setVideoError(null);
    setVideoProcessingStatus("Analyzing video duration & quality...");

    try {
      // 1. Enforce strict 8-second time limit & compress video quality
      const result = await compressAndLimitVideo(file, 8.0, (_pct, msg) => {
        setVideoProcessingStatus(msg);
      });

      setVideoProcessingStatus("Uploading compressed showcase video...");

      // 2. Upload to server
      const formData = new FormData();
      formData.append("file", result.file);
      formData.append("category", "gemstones");

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        body: formData,
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to upload video");
      }

      setUploadedVideo(data.url);
      const originalMB = (result.originalSize / (1024 * 1024)).toFixed(1);
      const compressedMB = (result.compressedSize / (1024 * 1024)).toFixed(1);

      const isOriginal = result.compressedSize === result.originalSize;
      toast.success(
        "Showcase Video Ready",
        isOriginal
          ? `MP4 video validated & uploaded (${originalMB}MB, ${result.duration.toFixed(1)}s).`
          : result.wasTrimmed
          ? `Trimmed to 8s limit & compressed (${originalMB}MB → ${compressedMB}MB).`
          : `Compressed (${originalMB}MB → ${compressedMB}MB, ${result.duration.toFixed(1)}s).`
      );
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Video processing failed";
      setVideoError(msg);
      toast.error("Video Error", msg);
    } finally {
      setIsProcessingVideo(false);
      setVideoProcessingStatus("");
    }
  };

  const handleRemoveVideo = () => {
    setUploadedVideo(null);
    setVideoError(null);
    setVideoProcessingStatus("");
  };

  const resetAddForm = () => {
    setNewGem(INITIAL_NEW_GEM);
    setSpecimenWeight("");
    setSpecimenPrice("");
    setSpecimenStock("");
    setSpecimenSize("");
    setUploadedImages([]);
    setPhotoUploadError(null);
    setUploadedVideo(null);
    setIsProcessingVideo(false);
    setVideoProcessingStatus("");
    setVideoError(null);
    setAddingField(null);
    setCustomAttributeInput("");
  };

  useEffect(() => {
    if (isAddModalOpen) {
      resetAddForm();
    }
  }, [isAddModalOpen]);

  const handleSubmitAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (uploadedImages.length === 0) {
      toast.error("Photo Required", "Please upload at least one gemstone photo.");
      return;
    }

    const parsedWeight = parseFloat(String(specimenWeight)) || 0;
    const parsedPrice = parseFloat(String(specimenPrice)) || 0;
    const parsedStock = parseInt(String(specimenStock), 10) || 0;

    if (!parsedWeight || parsedWeight <= 0) {
      toast.error("Weight Required", "Please enter a valid carat weight.");
      return;
    }
    if (!parsedPrice || parsedPrice <= 0) {
      toast.error("Price Required", "Please enter a valid price.");
      return;
    }

    const trimmedSize = specimenSize.trim();
    const primaryVariant: GemstoneVariant = {
      id: `var-${Date.now()}`,
      weight: parsedWeight,
      price: parsedPrice,
      stock: parsedStock,
      size: trimmedSize || undefined,
    };

    onAddGemstone({
      ...newGem,
      variety: newGem.variety?.trim() || `Natural ${newGem.type}`,
      cutDetail: newGem.cutDetail?.trim() || `${newGem.cut} Precision Cut`,
      originCountry: newGem.originCountry?.trim() || extractCountryFromOrigin(newGem.origin),
      carat: parsedWeight,
      price: parsedPrice,
      inStock: parsedStock > 0,
      size: trimmedSize || undefined,
      variants: [primaryVariant],
      images: uploadedImages,
      imageUrl: uploadedImages[0] || "",
      video: uploadedVideo || undefined,
    });
    resetAddForm();
    setIsAddModalOpen(false);
  };

  const handleOpenAddModal = () => {
    resetAddForm();
    setIsAddModalOpen(true);
  };

  const handleCloseAddModal = () => {
    resetAddForm();
    setIsAddModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls Toolbar */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-[#24242C] pb-6">
        <div>
          <h1 className="font-sans text-xl sm:text-2xl text-white font-semibold tracking-tight">
            Gemstone Inventory
          </h1>
          <p className="text-xs text-[#A1A1AA] mt-1 font-sans">
            Manage your gemstone catalog, prices, available stock, and photos.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs text-[#A1A1AA] font-sans flex items-baseline gap-1.5">
            Total Inventory Value: <LuxuryPrice amount={totalVaultValue} size="sm" color="gold" weight="bold" />
          </span>
          <button
            onClick={handleOpenAddModal}
            className="px-4 py-2 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-xs uppercase font-sans font-semibold tracking-wider rounded-sm transition-colors shadow-sm"
          >
            + Add Gemstone
          </button>
        </div>
      </div>

      {/* Filters Toolbar */}
      <div className="bg-[#141419] border border-[#24242C] p-4 rounded-sm flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Search Field */}
        <div className="relative w-full md:w-80">
          <SearchIcon className="w-4 h-4 text-[#8C867D] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={inventorySearch}
            onChange={(e) => setInventorySearch(e.target.value)}
            placeholder="Search by name, SKU, or origin..."
            className="w-full text-xs font-sans pl-9 pr-3 py-2 bg-[#1B1B22] border border-[#2A2A36] text-white placeholder-[#554F47] focus:outline-none focus:border-[#C5A880]"
          />
        </div>

        {/* Variety Quick Pills - Desktop Only */}
        <div className="hidden md:flex flex-wrap items-center gap-1.5 text-xs font-sans">
          {["All", ...availableTypes.slice(0, 8)].map((type) => (
            <button
              key={type}
              onClick={() => setSelectedTypeFilter(type)}
              className={`px-3 py-1.5 rounded-sm transition-colors ${
                selectedTypeFilter === type
                  ? "bg-[#C5A880] text-[#0D0D11] font-semibold"
                  : "bg-[#1C1C24] text-[#8C867D] hover:text-white"
              }`}
            >
              {type}
            </button>
          ))}
        </div>

        {/* Variety LuxurySelect - Mobile Only */}
        <div className="block md:hidden w-full">
          <LuxurySelect
            variant="dark"
            size="md"
            value={selectedTypeFilter}
            onChange={(val) => setSelectedTypeFilter(val)}
            options={varietyFilterOptions}
            placeholder="Filter by variety..."
            triggerClassName="w-full min-h-[44px] bg-[#1B1B22] border-[#2A2A36] text-white text-xs px-3 hover:border-[#C5A880] focus:border-[#C5A880]"
          />
        </div>
      </div>

      {/* Inventory Table */}
      <div className="bg-[#141419] border border-[#24242C] shadow-sm rounded-sm overflow-x-auto">
        <table className="w-full min-w-[850px] text-left text-xs font-sans">
          <thead>
            <tr className="border-b border-[#24242C] text-[#8C867D] uppercase text-[10px] bg-[#121217]">
              <th className="py-3 px-4">Preview</th>
              <th className="py-3 px-4">SKU & Gemstone</th>
              <th className="py-3 px-4 text-right">Weight (Carats)</th>
              <th className="py-3 px-4">Origin</th>
              <th className="py-3 px-4 text-right">Price</th>
              <th className="py-3 px-4">Stock</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1F1E26]">
            {filteredInventory.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-16 text-center text-[#8C867D]">
                  <p className="text-sm font-medium text-[#C5A880]">No gemstones in vault inventory</p>
                  <p className="text-xs text-[#8C867D] mt-1.5">Click &quot;Add Gemstone&quot; above to create your first gemstone listing.</p>
                </td>
              </tr>
            ) : (
              filteredInventory.map((gem, index) => (
                <tr key={gem.id} className="hover:bg-[#181820] transition-colors">
                <td className="py-3 px-4">
                  <div className="relative w-12 h-12 bg-[#1A1A22] border border-[#2A2A36] overflow-hidden rounded-sm">
                    <Image
                      src={gem.images?.[0] || (gem as any).imageUrl || "/uploads/gemstones/gem-1789652077476-hwzsqu.webp"}
                      alt={gem.name}
                      fill
                      unoptimized={Boolean((gem.images?.[0] || (gem as any).imageUrl)?.startsWith("/uploads"))}
                      className="object-cover"
                    />
                  </div>
                </td>
                <td className="py-3 px-4">
                  <span className="font-mono text-xs font-semibold text-[#C5A880] tabular-nums block">{gem.sku}</span>
                  <Link
                    href={`/gemstones/${gem.id}`}
                    target="_blank"
                    className="font-sans text-sm text-white hover:text-[#C5A880] font-medium block transition-colors"
                  >
                    {gem.name}
                  </Link>
                  <span className="text-[11px] text-[#71717A] font-sans">
                    {gem.species} • {gem.cut}
                  </span>
                </td>
                <td className="py-3 px-4 text-right">
                  <span className="font-mono text-xs sm:text-sm font-medium text-white tabular-nums block">{gem.carat.toFixed(2)} ct</span>
                  {gem.variants && gem.variants.length > 1 && (
                    <span className="text-[10px] text-[#C5A880] font-mono tabular-nums block text-right">
                      {gem.variants.length} Weights ({gem.variants.map((v) => `${v.weight}ct`).join(", ")})
                    </span>
                  )}
                </td>
                <td className="py-3 px-4 text-[#A29F96]">{gem.origin}</td>
                <td className="py-3 px-4 text-right">
                  <div className="flex flex-col items-end">
                    <LuxuryPrice amount={gem.price} size="sm" weight="medium" color="white" />
                    {gem.variants && gem.variants.length > 1 && (
                      <span className="text-[10px] text-[#8C867D] block text-right">Starting Valuation</span>
                    )}
                  </div>
                </td>
                <td className="py-3 px-4">
                  {(() => {
                    const hasVariants = gem.variants && gem.variants.length > 0;
                    if (hasVariants) {
                      const totalVariantStock = gem.variants!.reduce((sum, v) => sum + (v.stock ?? 0), 0);
                      const isOutOfStock = totalVariantStock <= 0 || gem.inStock === false;
                      return (
                        <div>
                          {isOutOfStock ? (
                            <span
                              title="Sold Out (0 available)"
                              className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-mono uppercase tracking-wider bg-red-950/60 text-red-400 border border-red-800/40"
                            >
                              <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                              0
                            </span>
                          ) : (
                            <span
                              title={`${totalVariantStock} available in stock`}
                              className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-mono uppercase tracking-wider bg-emerald-950/60 text-emerald-400 border border-emerald-800/40"
                            >
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                              {totalVariantStock}
                            </span>
                          )}
                          {gem.variants!.length > 1 && (
                            <span className="text-[10px] text-[#8C867D] font-mono block mt-0.5">
                              {gem.variants!.map((v) => `${v.stock ?? 0}`).join(" / ")} units
                            </span>
                          )}
                        </div>
                      );
                    } else {
                      const isAvailable = Boolean(gem.inStock);
                      return isAvailable ? (
                        <span
                          title="1 available in stock"
                          className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-mono uppercase tracking-wider bg-emerald-950/60 text-emerald-400 border border-emerald-800/40"
                        >
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                          1
                        </span>
                      ) : (
                        <span
                          title="Sold Out (0 available)"
                          className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-mono uppercase tracking-wider bg-red-950/60 text-red-400 border border-red-800/40"
                        >
                          <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                          0
                        </span>
                      );
                    }
                  })()}
                </td>
                <td className="py-3 px-4 text-right whitespace-nowrap">
                  <div className="relative inline-block text-left w-24 sm:w-28" data-action-menu>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setActionDropdownId(actionDropdownId === gem.id ? null : gem.id);
                      }}
                      className={`w-full flex items-center justify-between border rounded-none transition-all duration-150 outline-none btn-luxury-press px-2.5 py-1.5 text-xs font-sans ${
                        actionDropdownId === gem.id
                          ? "bg-[#1A1A22] text-[#C5A880] border-[#C5A880] ring-1 ring-[#C5A880]/30 shadow-sm"
                          : "bg-[#1A1A22] text-white border-[#2A2A36] hover:border-[#C5A880]"
                      }`}
                      aria-expanded={actionDropdownId === gem.id}
                    >
                      <span className="truncate block text-left font-sans text-white text-xs">Action</span>
                      <span
                        className={`shrink-0 transition-transform duration-200 ${
                          actionDropdownId === gem.id ? "rotate-180 text-[#C5A880]" : "text-[#8C867D]"
                        }`}
                        aria-hidden="true"
                      >
                        <svg className="w-3.5 h-3.5" viewBox="0 0 16 16" fill="none" stroke="currentColor">
                          <path d="M4 6l4 4 4-4" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                      </span>
                    </button>

                    {actionDropdownId === gem.id && (
                      <div
                        className={`absolute left-0 right-0 w-full z-50 bg-[#15151C] border border-[#2A2A38] text-white shadow-2xl rounded-none py-1 text-left animate-luxury-popover ${
                          index >= filteredInventory.length - 2 && filteredInventory.length > 2
                            ? "bottom-full mb-1"
                            : "top-full mt-1"
                        }`}
                      >
                        {/* Edit Option */}
                        <button
                          type="button"
                          onClick={() => {
                            setActionDropdownId(null);
                            setEditingGem(gem);
                            setIsEditModalOpen(true);
                          }}
                          className="w-full flex items-center gap-2 px-2.5 py-1.5 text-xs font-sans text-[#E0DFD5] hover:text-[#C5A880] hover:bg-[#1C1C26] transition-colors cursor-pointer text-left whitespace-nowrap"
                        >
                          <svg className="w-3.5 h-3.5 text-[#C5A880] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                          </svg>
                          <span className="font-medium">Edit</span>
                        </button>

                        <div className="my-0.5 border-t border-[#232330]" />

                        {/* Delete Option */}
                        <button
                          type="button"
                          onClick={() => {
                            setActionDropdownId(null);
                            onDeleteGemstone(gem.id);
                          }}
                          className="w-full flex items-center gap-2 px-2.5 py-1.5 text-xs font-sans text-red-400 hover:text-red-300 hover:bg-[#251417] transition-colors cursor-pointer text-left whitespace-nowrap"
                        >
                          <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <polyline points="3 6 5 6 21 6" />
                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                          </svg>
                          <span className="font-medium">Delete</span>
                        </button>
                      </div>
                    )}
                  </div>
                </td>
              </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Add Gemstone Modal */}
      {isAddModalOpen && mounted && createPortal(
        <div
          className="fixed inset-0 z-[99999] flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-luxury-backdrop"
        >
          <div
            className="relative w-full max-w-3xl bg-[#141419] border border-[#C5A880]/60 shadow-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto text-white animate-luxury-modal my-auto"
          >
            <button
              onClick={handleCloseAddModal}
              className="absolute top-4 right-4 text-[#8C867D] hover:text-white transition-colors"
            >
              <CloseIcon className="w-5 h-5" />
            </button>

            <div className="mb-6 border-b border-[#24242C] pb-4">
              <span className="text-[10px] text-[#C5A880] font-sans uppercase tracking-widest block">
                Inventory
              </span>
              <h2 className="font-sans font-semibold text-xl text-white tracking-tight">
                Add New Gemstone
              </h2>
              <p className="text-xs text-[#8C867D] mt-1 font-sans">
                Enter gemstone details, prices, stock, and photos.
              </p>
            </div>

            <form onSubmit={handleSubmitAdd} className="space-y-5 text-xs font-sans">
              {/* Gem Commercial Name & Gem Type */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                    Gemstone Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={newGem.name}
                    onChange={(e) => setNewGem({ ...newGem, name: e.target.value })}
                    placeholder="e.g. Natural Unheated Ruby"
                    className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                  />
                </div>

                <div>
                  <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                    Gemstone Type *
                  </label>

                  {addingField === "type" && (
                    <div className="mb-2 p-2.5 bg-[#121218] border border-[#C5A880] rounded-sm space-y-2 animate-fadeIn">
                      <div className="flex items-center justify-between">
                        <span className="text-[9px] font-mono text-[#C5A880] uppercase tracking-wider">
                          Add New Gemstone Type
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setAddingField(null);
                            setCustomAttributeInput("");
                          }}
                          className="text-[#8C867D] hover:text-white text-xs px-1"
                        >
                          ✕
                        </button>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          autoFocus
                          value={customAttributeInput}
                          onChange={(e) => setCustomAttributeInput(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              e.preventDefault();
                              handleSaveCustomAttribute("type");
                            } else if (e.key === "Escape") {
                              setAddingField(null);
                              setCustomAttributeInput("");
                            }
                          }}
                          placeholder="e.g. Morganite, Tsavorite, Paraiba..."
                          className="flex-1 p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs focus:outline-none focus:border-[#C5A880]"
                        />
                        <button
                          type="button"
                          onClick={() => handleSaveCustomAttribute("type")}
                          className="px-3 py-2 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors shrink-0"
                        >
                          Add & Select
                        </button>
                      </div>
                    </div>
                  )}

                  <LuxurySelect
                    variant="dark"
                    value={newGem.type}
                    onChange={(val) => {
                      if (val === "__ADD_NEW_TYPE__") {
                        setAddingField("type");
                        setCustomAttributeInput("");
                      } else {
                        setNewGem({ ...newGem, type: val as GemstoneType });
                      }
                    }}
                    onEditOption={(oldVal, newVal) => {
                      const success = editCustomOption("type", oldVal, newVal);
                      if (success) {
                        toast.success("Type Renamed", `"${oldVal}" renamed to "${newVal.trim()}".`);
                        if (newGem.type === oldVal) {
                          setNewGem((prev) => ({ ...prev, type: newVal.trim() as GemstoneType }));
                        }
                        return true;
                      } else {
                        toast.error("Duplicate Type", `"${newVal.trim()}" already exists.`);
                        return false;
                      }
                    }}
                    onDeleteOption={(val) => {
                      if (availableTypes.length <= 1) {
                        toast.error("Cannot Delete", "At least one gemstone type must remain.");
                        return false;
                      }
                      const success = deleteCustomOption("type", val);
                      if (success) {
                        toast.success("Type Removed", `"${val}" deleted.`);
                        if (newGem.type === val) {
                          const nextType = (availableTypes.find((t) => t !== val) || "Sapphire") as GemstoneType;
                          setNewGem((prev) => ({ ...prev, type: nextType }));
                        }
                        return true;
                      } else {
                        toast.error("Delete Failed", `Could not remove "${val}".`);
                        return false;
                      }
                    }}
                    options={[
                      ...availableTypes,
                      {
                        value: "__ADD_NEW_TYPE__",
                        label: "+ Add New Gemstone Type...",
                        badge: "Add",
                      },
                    ]}
                  />
                </div>
              </div>

              {/* Shape & Cut + Colour */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                    Cut & Shape *
                  </label>

                  {addingField === "cut" && (
                    <div className="mb-2 p-2.5 bg-[#121218] border border-[#C5A880] rounded-sm space-y-2 animate-fadeIn">
                      <div className="flex items-center justify-between">
                        <span className="text-[9px] font-mono text-[#C5A880] uppercase tracking-wider">
                          Add New Cut & Shape
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setAddingField(null);
                            setCustomAttributeInput("");
                          }}
                          className="text-[#8C867D] hover:text-white text-xs px-1"
                        >
                          ✕
                        </button>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          autoFocus
                          value={customAttributeInput}
                          onChange={(e) => setCustomAttributeInput(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              e.preventDefault();
                              handleSaveCustomAttribute("cut");
                            } else if (e.key === "Escape") {
                              setAddingField(null);
                              setCustomAttributeInput("");
                            }
                          }}
                          placeholder="e.g. Trilliant, Asscher, Modified Cushion..."
                          className="flex-1 p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs focus:outline-none focus:border-[#C5A880]"
                        />
                        <button
                          type="button"
                          onClick={() => handleSaveCustomAttribute("cut")}
                          className="px-3 py-2 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors shrink-0"
                        >
                          Add & Select
                        </button>
                      </div>
                    </div>
                  )}

                  <LuxurySelect
                    variant="dark"
                    value={newGem.cut}
                    onChange={(val) => {
                      if (val === "__ADD_NEW_CUT__") {
                        setAddingField("cut");
                        setCustomAttributeInput("");
                      } else {
                        setNewGem({
                          ...newGem,
                          cut: val as GemstoneCut,
                          cutDetail: `${val} Precision Cut`,
                        });
                      }
                    }}
                    options={[
                      ...availableCuts,
                      {
                        value: "__ADD_NEW_CUT__",
                        label: "+ Add New Cut & Shape...",
                        badge: "Add",
                      },
                    ]}
                  />
                </div>

                <div>
                  <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                    Color *
                  </label>
                  <input
                    type="text"
                    required
                    value={newGem.color}
                    onChange={(e) => setNewGem({ ...newGem, color: e.target.value })}
                    placeholder="e.g. Red, Royal Blue, Pigeon Blood"
                    className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] placeholder:text-[#555]"
                  />
                </div>
              </div>

              {/* Clarity, Treatment & Origin */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                    Clarity *
                  </label>

                  {addingField === "clarity" && (
                    <div className="mb-2 p-2.5 bg-[#121218] border border-[#C5A880] rounded-sm space-y-2 animate-fadeIn">
                      <div className="flex items-center justify-between">
                        <span className="text-[9px] font-mono text-[#C5A880] uppercase tracking-wider">
                          Add New Clarity Grade
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setAddingField(null);
                            setCustomAttributeInput("");
                          }}
                          className="text-[#8C867D] hover:text-white text-xs px-1"
                        >
                          ✕
                        </button>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          autoFocus
                          value={customAttributeInput}
                          onChange={(e) => setCustomAttributeInput(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              e.preventDefault();
                              handleSaveCustomAttribute("clarity");
                            } else if (e.key === "Escape") {
                              setAddingField(null);
                              setCustomAttributeInput("");
                            }
                          }}
                          placeholder="e.g. VS2, SI1, Slightly Included..."
                          className="flex-1 p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs focus:outline-none focus:border-[#C5A880]"
                        />
                        <button
                          type="button"
                          onClick={() => handleSaveCustomAttribute("clarity")}
                          className="px-3 py-2 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors shrink-0"
                        >
                          Add & Select
                        </button>
                      </div>
                    </div>
                  )}

                  <LuxurySelect
                    variant="dark"
                    value={newGem.clarity}
                    onChange={(val) => {
                      if (val === "__ADD_NEW_CLARITY__") {
                        setAddingField("clarity");
                        setCustomAttributeInput("");
                      } else {
                        setNewGem({ ...newGem, clarity: val });
                      }
                    }}
                    options={[
                      ...availableClarities,
                      {
                        value: "__ADD_NEW_CLARITY__",
                        label: "+ Add New Clarity...",
                        badge: "Add New",
                      },
                    ]}
                  />
                </div>

                <div>
                  <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                    Treatment *
                  </label>

                  {addingField === "treatment" && (
                    <div className="mb-2 p-2.5 bg-[#121218] border border-[#C5A880] rounded-sm space-y-2 animate-fadeIn">
                      <div className="flex items-center justify-between">
                        <span className="text-[9px] font-mono text-[#C5A880] uppercase tracking-wider">
                          Add New Treatment Type
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setAddingField(null);
                            setCustomAttributeInput("");
                          }}
                          className="text-[#8C867D] hover:text-white text-xs px-1"
                        >
                          ✕
                        </button>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          autoFocus
                          value={customAttributeInput}
                          onChange={(e) => setCustomAttributeInput(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              e.preventDefault();
                              handleSaveCustomAttribute("treatment");
                            } else if (e.key === "Escape") {
                              setAddingField(null);
                              setCustomAttributeInput("");
                            }
                          }}
                          placeholder="e.g. Low Temperature Heat, Beryllium, None..."
                          className="flex-1 p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs focus:outline-none focus:border-[#C5A880]"
                        />
                        <button
                          type="button"
                          onClick={() => handleSaveCustomAttribute("treatment")}
                          className="px-3 py-2 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors shrink-0"
                        >
                          Add & Select
                        </button>
                      </div>
                    </div>
                  )}

                  <LuxurySelect
                    variant="dark"
                    value={newGem.treatment || "Unheated"}
                    onChange={(val) => {
                      if (val === "__ADD_NEW_TREATMENT__") {
                        setAddingField("treatment");
                        setCustomAttributeInput("");
                      } else {
                        setNewGem({
                          ...newGem,
                          treatment: val as any,
                          isUnheated: val === "Unheated" || val.toLowerCase().includes("unheated"),
                        });
                      }
                    }}
                    options={[
                      ...availableTreatments,
                      {
                        value: "__ADD_NEW_TREATMENT__",
                        label: "+ Add New Treatment...",
                        badge: "Add New",
                      },
                    ]}
                  />
                </div>

                <div>
                  <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                    Origin (Country / City) *
                  </label>
                  <input
                    type="text"
                    required
                    value={newGem.origin}
                    onChange={(e) => {
                      const val = e.target.value;
                      setNewGem({
                        ...newGem,
                        origin: val,
                        originCountry: extractCountryFromOrigin(val),
                      });
                    }}
                    placeholder="e.g. Ratnapura, Sri Lanka or Muzo, Colombia"
                    className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880]"
                  />
                </div>
              </div>

              {/* CARAT WEIGHT, PRICE, STOCK & SIZE (NO MULTIPLE ADD OPTION) */}
              <div className="border border-[#C5A880]/30 bg-[#171720] p-4 rounded-sm space-y-3">
                <div className="pb-2 border-b border-[#2A2A36]">
                  <label className="text-[#C5A880] uppercase text-[11px] font-semibold block">
                    Weight, Price &amp; Stock
                  </label>
                  <span className="text-[10px] text-[#8C867D]">
                    Enter the gemstone carat weight, price, available stock quantity, and size.
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 p-3 bg-[#121217] border border-[#2A2A36] rounded items-end">
                  <div>
                    <label className="block text-[10px] text-[#8C867D] mb-1">
                      Weight (ct) *
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      required
                      value={specimenWeight}
                      onChange={(e) => setSpecimenWeight(e.target.value)}
                      placeholder="e.g. 0.55"
                      className="w-full p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs focus:outline-none focus:border-[#C5A880] placeholder:text-[#555] text-right font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] text-[#8C867D] mb-1">
                      Price (USD $) *
                    </label>
                    <input
                      type="number"
                      required
                      value={specimenPrice}
                      onChange={(e) => setSpecimenPrice(e.target.value)}
                      placeholder="e.g. 45000"
                      className="w-full p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs focus:outline-none focus:border-[#C5A880] placeholder:text-[#555] text-right font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] text-[#8C867D] mb-1">
                      Stock Qty *
                    </label>
                    <input
                      type="number"
                      min="0"
                      required
                      value={specimenStock}
                      onChange={(e) => setSpecimenStock(e.target.value)}
                      placeholder="e.g. 5"
                      className="w-full p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs focus:outline-none focus:border-[#C5A880] placeholder:text-[#555]"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] text-[#8C867D] mb-1">
                      Size / Dimensions <span className="text-[#6B655C]">(Optional)</span>
                    </label>
                    <input
                      type="text"
                      value={specimenSize}
                      onChange={(e) => setSpecimenSize(e.target.value)}
                      placeholder="e.g. 6.6 x 3.4 x 2.1mm (Optional)"
                      className="w-full p-2 bg-[#1C1C24] border border-[#2A2A36] text-white text-xs focus:outline-none focus:border-[#C5A880] placeholder:text-[#555]"
                    />
                  </div>
                </div>
              </div>

              {/* SPECIMEN MULTIPLE PHOTOGRAPHY (NO DEFAULT IMAGE & NO ENTER URL) */}
              <div className="space-y-3 border border-[#2A2A36] p-4 bg-[#181820] rounded-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-[#C5A880] uppercase text-[11px] font-semibold block">
                      Gemstone Photos *
                    </label>
                    <span className="text-[10px] text-[#8C867D]">
                      Upload photos from your device. The first photo will be the main cover image.
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => photoFileInputRef.current?.click()}
                    className="px-3 py-1 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-[10px] uppercase font-mono font-semibold rounded transition-colors"
                  >
                    + Upload Images
                  </button>
                </div>

                <input
                  ref={photoFileInputRef}
                  type="file"
                  multiple
                  accept="image/jpeg,image/png,image/webp,image/avif"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files && e.target.files.length > 0) {
                      handleMultiFileUpload(e.target.files);
                      e.target.value = "";
                    }
                  }}
                />

                {/* Empty State or Uploaded Photos Grid */}
                {uploadedImages.length === 0 ? (
                  <div
                    onClick={() => photoFileInputRef.current?.click()}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => {
                      e.preventDefault();
                      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                        handleMultiFileUpload(e.dataTransfer.files);
                      }
                    }}
                    className="border-2 border-dashed border-[#343444] hover:border-[#C5A880] bg-[#141419] rounded-sm p-6 text-center cursor-pointer transition-all group"
                  >
                    {isUploadingPhoto ? (
                      <div className="space-y-2">
                        <span className="inline-block animate-spin text-2xl text-[#C5A880]">↻</span>
                        <p className="text-xs text-[#C5A880] font-mono">Uploading gemstone photo...</p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <div className="w-10 h-10 mx-auto rounded-full bg-[#1C1C24] border border-[#2A2A36] group-hover:border-[#C5A880] flex items-center justify-center text-[#C5A880] text-lg transition-colors">
                          📷
                        </div>
                        <div>
                          <p className="text-xs text-white font-medium">Click or drag photos here to upload</p>
                          <p className="text-[10px] text-[#8C867D] mt-0.5">Upload multiple JPEG, PNG, WEBP high-resolution photos</p>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                    {uploadedImages.map((imgUrl, idx) => (
                      <div
                        key={idx}
                        className="relative aspect-square bg-[#121217] border border-[#2A2A36] rounded-sm overflow-hidden group"
                      >
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={imgUrl}
                          alt={`Gemstone photo ${idx + 1}`}
                          className="w-full h-full object-cover"
                        />

                        {/* Primary Badge */}
                        {idx === 0 && (
                          <span className="absolute top-1.5 left-1.5 bg-[#C5A880] text-[#0D0D11] font-mono text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">
                            Primary
                          </span>
                        )}

                        {/* Action buttons on hover */}
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1.5 p-2">
                          <button
                            type="button"
                            onClick={() => handleOpenCropForIndex(idx)}
                            className="px-2 py-1 bg-[#C5A880] text-[#0D0D11] text-[10px] font-mono rounded font-semibold uppercase hover:bg-white"
                          >
                            Crop
                          </button>
                          <button
                            type="button"
                            onClick={() => handleRemoveImage(idx)}
                            className="px-2 py-1 bg-red-600/80 hover:bg-red-600 text-white text-[10px] font-mono rounded font-semibold uppercase"
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    ))}

                    {/* Add More Box */}
                    <div
                      onClick={() => photoFileInputRef.current?.click()}
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={(e) => {
                        e.preventDefault();
                        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                          handleMultiFileUpload(e.dataTransfer.files);
                        }
                      }}
                      className="border-2 border-dashed border-[#343444] hover:border-[#C5A880] bg-[#141419] rounded-sm flex flex-col items-center justify-center p-4 text-center cursor-pointer transition-colors aspect-square"
                    >
                      {isUploadingPhoto ? (
                        <div className="space-y-1">
                          <span className="inline-block animate-spin text-base text-[#C5A880]">↻</span>
                          <p className="text-[10px] text-[#C5A880]">Uploading...</p>
                        </div>
                      ) : (
                        <div className="space-y-1 text-xs">
                          <span className="text-xl text-[#C5A880]">+</span>
                          <p className="text-[10px] text-[#8C867D]">Add More</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {photoUploadError && (
                  <p className="text-red-400 text-[11px] mt-1">{photoUploadError}</p>
                )}
              </div>

              {/* GEMSTONE SHOWCASE VIDEO (MAX 8s • AUTO-COMPRESSED) */}
              <div className="space-y-3 border border-[#2A2A36] p-4 bg-[#181820] rounded-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-[#C5A880] uppercase text-[11px] font-semibold flex items-center gap-2">
                      <span>Showcase Video (MP4)</span>
                      <span className="text-[9px] px-1.5 py-0.5 bg-[#C5A880]/15 text-[#C5A880] border border-[#C5A880]/30 rounded font-mono">
                        8s Limit • MP4 Supported • Quality Compressed
                      </span>
                    </label>
                    <span className="text-[10px] text-[#8C867D]">
                      Upload an MP4 (or MOV/WEBM) video up to 8 seconds to showcase gemstone luster, optical fire, and brilliance.
                    </span>
                  </div>

                  {uploadedVideo && (
                    <button
                      type="button"
                      onClick={handleRemoveVideo}
                      className="px-2.5 py-1 bg-red-600/80 hover:bg-red-600 text-white text-[10px] uppercase font-mono rounded transition-colors"
                    >
                      Remove Video
                    </button>
                  )}
                </div>

                <input
                  ref={videoFileInputRef}
                  type="file"
                  accept="video/mp4,.mp4,.m4v,video/webm,video/quicktime,.mov,video/*"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      handleVideoUpload(e.target.files[0]);
                      e.target.value = "";
                    }
                  }}
                />

                {!uploadedVideo ? (
                  <div
                    onClick={() => !isProcessingVideo && videoFileInputRef.current?.click()}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => {
                      e.preventDefault();
                      if (!isProcessingVideo && e.dataTransfer.files && e.dataTransfer.files[0]) {
                        handleVideoUpload(e.dataTransfer.files[0]);
                      }
                    }}
                    className={`border-2 border-dashed ${
                      isProcessingVideo ? "border-[#C5A880] bg-[#1a1a24]" : "border-[#343444] hover:border-[#C5A880] bg-[#141419]"
                    } rounded-sm p-5 text-center cursor-pointer transition-all`}
                  >
                    {isProcessingVideo ? (
                      <div className="space-y-2 py-2">
                        <span className="inline-block animate-spin text-2xl text-[#C5A880]">↻</span>
                        <p className="text-xs text-[#C5A880] font-mono font-medium">
                          {videoProcessingStatus || "Processing showcase video..."}
                        </p>
                        <p className="text-[10px] text-[#8C867D]">
                          Enforcing 8s limit &amp; compressing video quality for instant web streaming
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <div className="w-10 h-10 mx-auto rounded-full bg-[#1C1C24] border border-[#2A2A36] flex items-center justify-center text-[#C5A880] text-lg">
                          ▶
                        </div>
                        <div>
                          <p className="text-xs text-white font-medium">
                            Click or drag MP4 video here to upload
                          </p>
                          <p className="text-[10px] text-[#8C867D] mt-0.5">
                            MP4 fully supported (also WEBM, MOV) • Auto-trimmed to 8s max &amp; compressed
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="relative rounded-sm overflow-hidden bg-black border border-[#2A2A36] p-3 flex flex-col sm:flex-row items-center gap-4">
                    <div className="relative w-full sm:w-48 aspect-video bg-black rounded overflow-hidden flex-shrink-0 border border-white/10">
                      <video
                        key={uploadedVideo}
                        src={uploadedVideo}
                        preload="auto"
                        autoPlay
                        loop
                        playsInline
                        controls
                        className="w-full h-full object-contain"
                      />
                    </div>
                    <div className="flex-1 space-y-1 text-left">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-emerald-400" />
                        <span className="text-xs font-semibold text-white">8s Showcase Video Attached</span>
                      </div>
                      <p className="text-[11px] text-[#8C867D]">
                        Video will appear next to the gallery view on the product detail page and quick view.
                      </p>
                      <div className="pt-2 flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => videoFileInputRef.current?.click()}
                          className="px-2.5 py-1 bg-[#2A2A36] hover:bg-[#343444] text-white text-[10px] font-mono rounded transition-colors"
                        >
                          Replace Video
                        </button>
                        <button
                          type="button"
                          onClick={handleRemoveVideo}
                          className="px-2.5 py-1 bg-red-600/20 text-red-400 hover:bg-red-600/30 text-[10px] font-mono rounded transition-colors"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {videoError && (
                  <p className="text-red-400 text-[11px] mt-1">{videoError}</p>
                )}
              </div>

              <div>
                <label className="block text-[#C5A880] uppercase text-[10px] mb-1">
                  Description
                </label>
                <textarea
                  rows={3}
                  value={newGem.description}
                  onChange={(e) => setNewGem({ ...newGem, description: e.target.value })}
                  placeholder="e.g. An extraordinary natural unheated gemstone with remarkable crystallization, high luster, and fire."
                  className="w-full p-2.5 bg-[#1C1C24] border border-[#2A2A36] text-white focus:outline-none focus:border-[#C5A880] placeholder:text-[#555]"
                />
              </div>

              <div className="pt-4 flex gap-3">
                <button
                  type="button"
                  onClick={handleCloseAddModal}
                  className="px-6 py-3 border border-[#2A2A36] text-xs text-[#8C867D] hover:text-white uppercase transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isUploadingPhoto || isProcessingVideo}
                  className="flex-1 py-3 bg-[#C5A880] hover:bg-[#E0CFA9] disabled:bg-[#44382B] text-[#0D0D11] text-xs uppercase font-semibold tracking-wider transition-colors"
                >
                  {isUploadingPhoto ? "Uploading Photos..." : isProcessingVideo ? "Processing Video..." : "Add Gemstone"}
                </button>
              </div>
            </form>
          </div>
        </div>,
        document.body
      )}

      {/* Edit Gemstone Modal */}
      <EditGemstoneModal
        isOpen={isEditModalOpen}
        onClose={() => {
          setIsEditModalOpen(false);
          setEditingGem(null);
        }}
        gemstone={editingGem}
        onSave={handleSaveEditedGem}
        formatPrice={formatPrice}
      />

      {/* Interactive Crop Studio Modal using Sharp */}
      <ImageCropModal
        isOpen={isCropModalOpen}
        onClose={() => setIsCropModalOpen(false)}
        imageFile={cropFile}
        imageUrl={cropUrl}
        onCropComplete={handleCropAndSave}
        isSaving={isCroppingAndSaving}
      />
    </div>
  );
}
