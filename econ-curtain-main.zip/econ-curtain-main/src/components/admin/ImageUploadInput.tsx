"use client";

import { useState } from "react";
import { Loader2 } from "lucide-react";

interface ImageUploadInputProps {
  name: string;
  defaultValue?: string;
  placeholder?: string;
}

export default function ImageUploadInput({ name, defaultValue = "", placeholder }: ImageUploadInputProps) {
  const [url, setUrl] = useState(defaultValue);
  const [isUploading, setIsUploading] = useState(false);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    try {
      const uploadData = new FormData();
      uploadData.append("files", files[0]);

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        body: uploadData,
      });

      const data = await res.json();
      if (data.success && data.urls.length > 0) {
        setUrl(data.urls[0]);
      } else {
        alert("Upload failed: " + data.error);
      }
    } catch (err) {
      console.error("Upload error:", err);
      alert("Failed to upload image.");
    } finally {
      setIsUploading(false);
      e.target.value = "";
    }
  };

  return (
    <div className="space-y-2">
      {/* Hidden input to pass the actual URL string to the parent form action */}
      <input type="hidden" name={name} value={url} />

      {/* Image Preview */}
      {url && (
        <div className="relative aspect-video w-48 rounded-md overflow-hidden bg-neutral-200 dark:bg-neutral-900 border border-[#E5E5E0] dark:border-neutral-800">
          <img src={url} alt="Preview" className="w-full h-full object-cover" />
        </div>
      )}

      {/* The File Input */}
      <div className="relative flex items-center gap-2">
        <div className="relative grow">
          <input
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            disabled={isUploading}
            className="w-full px-3 py-2 bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 disabled:opacity-50"
          />
          {isUploading && (
            <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 text-amber-600">
              <Loader2 size={14} className="animate-spin" />
              <span className="text-[10px] font-bold">UPLOADING...</span>
            </div>
          )}
        </div>
      </div>
      
      {/* Show URL for debugging/copying */}
      {url && (
        <p className="text-[10px] text-neutral-500 font-mono truncate">Path: {url}</p>
      )}
    </div>
  );
}
