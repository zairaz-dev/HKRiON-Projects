"use client";

import React, { useState } from "react";
import { useCMS } from "@/features/cms/useCMS";
import { SITE_CONFIG } from "@/lib/constants/site";

interface WhatsAppFloatingButtonProps {
  phoneNumber?: string;
  customMessage?: string;
}

export function WhatsAppFloatingButton({
  phoneNumber: propPhone,
  customMessage = "Hello Faizan Gems, I would like to inquire about your natural gemstones.",
}: WhatsAppFloatingButtonProps) {
  const { getBlock } = useCMS();
  const [isHovered, setIsHovered] = useState(false);

  // Dynamic phone from CMS if not passed as prop
  const rawPhone = propPhone || getBlock("contact.phone", SITE_CONFIG.contact.phone);
  // Clean phone number so it contains only digits (e.g., 94761119823)
  const cleanPhone = rawPhone.replace(/[^0-9]/g, "");

  const encodedMessage = encodeURIComponent(customMessage);
  const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodedMessage}`;

  return (
    <aside
      aria-label="WhatsApp Contact"
      className="fixed bottom-[max(1.25rem,calc(1rem+env(safe-area-inset-bottom,0px)))] right-4 sm:bottom-8 sm:right-8 z-40 flex items-center group pointer-events-auto"
    >
      {/* Luxury Pill Tooltip on Hover */}
      <div
        className={`hidden sm:flex items-center gap-2.5 px-3.5 py-2 mr-3 rounded-full bg-[#141419]/95 border border-[#C5A880]/40 backdrop-blur-md shadow-2xl transition-all duration-300 pointer-events-none transform ${
          isHovered
            ? "opacity-100 translate-x-0"
            : "opacity-0 translate-x-3 pointer-events-none"
        }`}
      >
        <span className="relative flex h-2 w-2">
          <span className="inline-flex rounded-full h-2 w-2 bg-[#25D366]" />
        </span>
        <div className="flex flex-col">
          <span className="text-[11px] font-sans font-medium text-white tracking-wide">
            Chat with Gemologist
          </span>
          <span className="text-[9px] font-mono text-[#C5A880] uppercase tracking-wider">
            WhatsApp Online
          </span>
        </div>
      </div>

      {/* Floating Action Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        aria-label="Chat with Faizan Gems on WhatsApp"
        className="relative flex items-center justify-center w-14 h-14 sm:w-15 sm:h-15 rounded-full bg-[#25D366] hover:bg-[#20bd5a] text-white shadow-[0_8px_30px_rgba(37,211,102,0.45)] hover:shadow-[0_12px_35px_rgba(37,211,102,0.65)] transform hover:scale-105 active:scale-95 transition-all duration-300 border-2 border-white/20 focus:outline-none focus:ring-4 focus:ring-[#25D366]/40 cursor-pointer"
      >

        {/* Official WhatsApp Vector Icon */}
        <svg
          className="w-7 h-7 sm:w-8 sm:h-8 relative z-10 fill-current drop-shadow-sm"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
          aria-hidden="true"
        >
          <path d="M17.472 14.382c-.301-.15-1.78-.878-2.056-.979-.276-.1-.477-.15-.678.15-.201.3-.777.979-.953 1.18-.176.2-.352.226-.653.076-.301-.15-1.272-.469-2.424-1.496-.897-.798-1.503-1.784-1.68-2.085-.176-.3-.019-.462.132-.612.136-.135.301-.351.452-.527.15-.176.201-.301.301-.502.1-.2.05-.376-.025-.526-.075-.15-.678-1.634-.929-2.238-.244-.588-.493-.508-.678-.518-.176-.009-.377-.01-.578-.01-.201 0-.527.075-.803.376-.276.3-1.054 1.03-1.054 2.511 0 1.482 1.079 2.912 1.23 3.113.15.2 2.124 3.242 5.145 4.547.719.31 1.28.496 1.718.636.722.23 1.378.198 1.9.12.581-.088 1.78-.727 2.03-1.429.25-.702.25-1.304.175-1.43-.075-.125-.276-.201-.577-.351z" />
          <path d="M12.004 2c-5.517 0-10 4.484-10 10 0 1.761.458 3.479 1.328 4.996l-1.411 5.158 5.291-1.387c1.464.799 3.11 1.233 4.792 1.233 5.517 0 10-4.484 10-10s-4.483-10-10-10zm0 18.25c-1.506 0-2.981-.406-4.269-1.173l-.306-.183-3.17.831.846-3.09-.2-.319c-.84-1.336-1.285-2.894-1.285-4.466 0-4.549 3.702-8.25 8.25-8.25 4.548 0 8.25 3.701 8.25 8.25 0 4.549-3.702 8.25-8.25 8.25z" />
        </svg>
      </a>
    </aside>
  );
}
