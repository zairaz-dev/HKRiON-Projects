"use client";

import React, { use, useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { COLLECTIONS } from "@/lib/data/collections";
import { Gemstone } from "@/types/gemstone";
import { GemstoneCard } from "@/features/gemstones/components/GemstoneCard";
import { GemstoneCardSkeleton } from "@/features/gemstones/components/GemstoneCardSkeleton";
import { ChevronRightIcon, SparklesIcon } from "@/components/ui/LuxuryIcons";
import { useCMS } from "@/features/cms/useCMS";

export default function CollectionDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const resolvedParams = use(params);
  const collection = COLLECTIONS.find((c) => c.slug === resolvedParams.slug);

  if (!collection) {
    notFound();
  }

  const { getBlock } = useCMS();

  // Dynamic CMS fields per collection
  const badgeText = getBlock(`collection.${collection.slug}.badge`, "Faizan Gems Curated Collection");
  const title = getBlock(`collection.${collection.slug}.title`, collection.title);
  const tagline = getBlock(`collection.${collection.slug}.tagline`, collection.tagline);
  const description = getBlock(`collection.${collection.slug}.description`, collection.description);
  const heroImage = getBlock(`collection.${collection.slug}.hero_image`, collection.heroImage);
  const curatorQuote = getBlock(`collection.${collection.slug}.curator_quote`, collection.curatorQuote);
  const specimensHeading = getBlock(`collection.${collection.slug}.specimens_heading`, "Available Specimens");
  const catalogLinkText = getBlock(`collection.${collection.slug}.catalog_link_text`, "View All Catalog →");
  const catalogLinkUrl = getBlock(`collection.${collection.slug}.catalog_link_url`, "/shop");
  const emptyTitle = getBlock(`collection.${collection.slug}.empty_title`, "All Specimens In This Collection Currently Reserved");
  const emptyDesc = getBlock(`collection.${collection.slug}.empty_desc`, "Our gemologists are currently curating new acquisitions from this deposit. Contact our concierge for advance previews.");
  const emptyBtnText = getBlock(`collection.${collection.slug}.empty_btn_text`, "Request Private Acquisition");
  const emptyBtnLink = getBlock(`collection.${collection.slug}.empty_btn_link`, "/contact");

  const [gemstonesList, setGemstonesList] = useState<Gemstone[]>([]);
  const [isLoadingGems, setIsLoadingGems] = useState<boolean>(true);

  useEffect(() => {
    let isMounted = true;
    fetch("/api/gemstones")
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (isMounted && Array.isArray(data)) {
          setGemstonesList(data);
        }
      })
      .catch(() => {})
      .finally(() => {
        if (isMounted) {
          setIsLoadingGems(false);
        }
      });
    return () => {
      isMounted = false;
    };
  }, []);

  // Filter gemstones matching this collection
  const collectionGems = gemstonesList.filter((gem) => {
    if (collection.slug === "ceylon-sapphires") {
      return gem.type === "Sapphire" && gem.originCountry === "Sri Lanka";
    }
    if (collection.slug === "rubies") {
      return gem.type === "Ruby";
    }
    if (collection.slug === "colombian-emeralds") {
      return gem.type === "Emerald" && gem.originCountry === "Colombia";
    }
    if (collection.slug === "rare-gems") {
      return ["Alexandrite", "Padparadscha", "Tourmaline", "Spinel"].includes(gem.type);
    }
    if (collection.slug === "collectors-vault") {
      return gem.investmentGrade && gem.rarityScore >= 95;
    }
    return true;
  });

  return (
    <div className="bg-[#FAF8F5] min-h-screen">
      {/* Editorial Collection Hero */}
      <section className="relative min-h-[50vh] flex items-center justify-center bg-[#0D0D11] text-white overflow-hidden py-20 px-4 sm:px-6 lg:px-8">
        {heroImage && (
          <div className="absolute inset-0 z-0">
            <Image
              src={heroImage}
              alt={title}
              fill
              priority
              sizes="100vw"
              unoptimized={heroImage.startsWith("/uploads")}
              className="object-cover object-center opacity-35"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D11] via-[#0D0D11]/50 to-transparent" />
          </div>
        )}

        <div className="relative z-10 max-w-4xl mx-auto text-center space-y-4">
          {badgeText && (
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 border border-[#C5A880]/30 text-[#E0CFA9] text-[11px] font-sans uppercase tracking-widest">
              <SparklesIcon className="w-3.5 h-3.5 text-[#C5A880]" />
              <span>{badgeText}</span>
            </div>
          )}

          <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-white font-light tracking-wide">
            {title}
          </h1>

          {tagline && (
            <p className="text-xs sm:text-sm font-sans text-[#C5A880] uppercase tracking-wide-luxury font-medium">
              {tagline}
            </p>
          )}

          {description && (
            <p className="max-w-2xl mx-auto text-xs sm:text-sm text-[#D3CBBF] font-sans leading-relaxed pt-2">
              {description}
            </p>
          )}

          {curatorQuote && (
            <div className="pt-4 italic font-serif text-sm text-[#E0CFA9]/80">
              &ldquo;{curatorQuote}&rdquo;
            </div>
          )}
        </div>
      </section>

      {/* Gemstones Grid */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-baseline justify-between mb-8 pb-4 border-b border-[#E8E4DC]">
          <div>
            <h2 className="font-serif text-2xl text-[#18181D]">{specimensHeading}</h2>
            <span className="text-xs font-sans text-[#8C867D]">
              {isLoadingGems ? (
                <span className="inline-block w-28 h-3 bg-[#E8E4DC] rounded-xs animate-pulse align-middle" />
              ) : (
                `${collectionGems.length} certified pieces in vault`
              )}
            </span>
          </div>

          <Link href={catalogLinkUrl} className="text-xs uppercase tracking-luxury text-[#9A7B4F] font-sans hover:underline">
            {catalogLinkText}
          </Link>
        </div>

        {isLoadingGems ? (
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6 lg:gap-8">
            {[...Array(6)].map((_, i) => (
              <GemstoneCardSkeleton key={i} />
            ))}
          </div>
        ) : collectionGems.length === 0 ? (
          <div className="bg-white border border-[#E8E4DC] p-12 text-center">
            <h3 className="font-serif text-xl text-[#18181D]">{emptyTitle}</h3>
            <p className="mt-2 text-xs text-[#8C867D] font-sans max-w-sm mx-auto">
              {emptyDesc}
            </p>
            <Link href={emptyBtnLink} className="inline-block mt-4 px-6 py-2.5 bg-[#18181D] text-white text-xs uppercase font-sans">
              {emptyBtnText}
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6 lg:gap-8">
            {collectionGems.map((gem) => (
              <GemstoneCard key={gem.id} gemstone={gem} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
