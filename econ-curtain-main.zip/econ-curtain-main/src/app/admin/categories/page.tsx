import { CategoryService, CategoryItem } from "@/services/category.service";
import {
  Layers,
  Plus,
  Edit3,
  Trash2,
  CheckCircle2,
  XCircle,
  Sparkles,
  Image as ImageIcon,
  Package,
  ArrowUpDown,
  X,
  Save,
} from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import ImageUploadInput from "@/components/admin/ImageUploadInput";

export const dynamic = "force-dynamic";

interface AdminCategoriesPageProps {
  searchParams?: Promise<{ success?: string; error?: string; create?: string; edit?: string }>;
}

export default async function AdminCategoriesPage({ searchParams }: AdminCategoriesPageProps) {
  const params = await searchParams;
  const isCreateOpen = params?.create === "true";
  const editCategoryId = params?.edit;

  const categories: CategoryItem[] = await CategoryService.getAllForAdmin();
  const editingCategory: CategoryItem | null = editCategoryId
    ? categories.find((c: CategoryItem) => c.id === editCategoryId) || null
    : null;

  const totalCategories = categories.length;
  const activeCategories = categories.filter((c: CategoryItem) => c.isActive).length;
  const totalLinkedProducts = categories.reduce((sum: number, c: CategoryItem) => sum + (c.products?.length || 0), 0);

  return (
    <div className="space-y-6 w-full">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-black p-6 sm:p-8 rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-none bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 text-amber-700 dark:text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
            <Sparkles size={14} /> Taxonomy Control
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white tracking-tight">
            Product Categories
          </h1>
          <p className="text-neutral-500 dark:text-neutral-400 text-xs sm:text-sm mt-1">
            Manage your product divisions, display order, category cover images, and taxonomy in SQLite.
          </p>
        </div>

        <Link
          href="/admin/categories?create=true"
          scroll={false}
          className="inline-flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-5 py-2.5 rounded-none text-xs sm:text-sm shadow-xs transition-all active:scale-95 shrink-0"
        >
          <Plus size={16} />
          <span>Add New Category</span>
        </Link>
      </div>

      {/* Metrics Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
        <div className="p-6 rounded-none bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-none bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 flex items-center justify-center text-amber-700 dark:text-amber-400">
            <Layers size={24} />
          </div>
          <div>
            <p className="text-xs uppercase tracking-wider text-neutral-400 dark:text-neutral-500 font-bold">Total Categories</p>
            <h3 className="text-2xl font-black text-neutral-900 dark:text-white">{totalCategories}</h3>
          </div>
        </div>

        <div className="p-6 rounded-none bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-none bg-emerald-50 dark:bg-emerald-400/10 border border-emerald-200 dark:border-emerald-400/30 flex items-center justify-center text-emerald-700 dark:text-emerald-400">
            <CheckCircle2 size={24} />
          </div>
          <div>
            <p className="text-xs uppercase tracking-wider text-neutral-400 dark:text-neutral-500 font-bold">Active in Catalog</p>
            <h3 className="text-2xl font-black text-neutral-900 dark:text-white">{activeCategories}</h3>
          </div>
        </div>

        <div className="p-6 rounded-none bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-none bg-purple-50 dark:bg-purple-400/10 border border-purple-200 dark:border-purple-400/30 flex items-center justify-center text-purple-700 dark:text-purple-400">
            <Package size={24} />
          </div>
          <div>
            <p className="text-xs uppercase tracking-wider text-neutral-400 dark:text-neutral-500 font-bold">Linked Products</p>
            <h3 className="text-2xl font-black text-neutral-900 dark:text-white">{totalLinkedProducts}</h3>
          </div>
        </div>
      </div>

      {/* Categories Database Table */}
      <div className="bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none overflow-hidden shadow-xs">
        <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-neutral-900 dark:text-white flex items-center gap-2">
              <span>Database Category Records</span>
              <span className="text-xs bg-amber-50 dark:bg-amber-400/10 text-amber-800 dark:text-amber-400 border border-amber-200 dark:border-amber-400/30 px-2.5 py-0.5 rounded-none font-bold">
                categories table
              </span>
            </h2>
            <p className="text-neutral-500 dark:text-neutral-400 text-xs mt-0.5">
              Categories dynamically power filters on the website catalog and product management dropdowns.
            </p>
          </div>
          <span className="text-xs bg-neutral-100 dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300 px-3.5 py-1.5 rounded-none border border-[#E5E5E0] dark:border-neutral-800 font-medium self-start sm:self-auto">
            {categories.length} Categories Registered
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-neutral-700 dark:text-neutral-300">
            <thead className="bg-neutral-50 dark:bg-neutral-950 text-xs uppercase font-bold text-neutral-500 dark:text-neutral-400 border-b border-neutral-100 dark:border-neutral-800">
              <tr>
                <th className="py-4 px-6">Category</th>
                <th className="py-4 px-6">Slug</th>
                <th className="py-4 px-6">Order</th>
                <th className="py-4 px-6">Linked Products</th>
                <th className="py-4 px-6">Status</th>
                <th className="py-4 px-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
              {categories.map((cat: CategoryItem) => (
                <tr key={cat.id} className="hover:bg-neutral-50/80 dark:hover:bg-neutral-900/60 transition-colors">
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-3.5">
                      <div className="w-12 h-12 rounded-none overflow-hidden bg-neutral-100 dark:bg-neutral-950 shrink-0 border border-neutral-200 dark:border-neutral-800 relative group">
                        {cat.imageUrl ? (
                          <Image
                            src={cat.imageUrl}
                            alt={cat.name}
                            fill
                            sizes="48px"
                            className="object-cover"
                            unoptimized
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-amber-500">
                            <Layers size={20} />
                          </div>
                        )}
                      </div>
                      <div>
                        <p className="font-bold text-neutral-900 dark:text-white text-sm">{cat.name}</p>
                        <p className="text-xs text-neutral-500 dark:text-neutral-400 line-clamp-1 max-w-xs font-light">
                          {cat.description || "No description"}
                        </p>
                      </div>
                    </div>
                  </td>

                  <td className="py-4 px-6 font-mono text-xs text-amber-700 dark:text-amber-400">
                    /{cat.slug}
                  </td>

                  <td className="py-4 px-6">
                    <span className="inline-flex items-center gap-1 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 px-2.5 py-1 rounded-none text-xs font-mono font-bold text-neutral-700 dark:text-neutral-300">
                      <ArrowUpDown size={11} className="text-neutral-400 dark:text-neutral-500" />
                      #{cat.order}
                    </span>
                  </td>

                  <td className="py-4 px-6">
                    <span className="bg-purple-50 dark:bg-purple-500/10 text-purple-700 dark:text-purple-400 border border-purple-200 dark:border-purple-500/30 text-xs px-3 py-1 rounded-none font-bold">
                      {cat.products?.length || 0} Products
                    </span>
                  </td>

                  <td className="py-4 px-6">
                    {cat.isActive ? (
                      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/30 px-3 py-1 rounded-none whitespace-nowrap">
                        <CheckCircle2 size={13} /> Active
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-rose-700 dark:text-rose-400 bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/30 px-3 py-1 rounded-none whitespace-nowrap">
                        <XCircle size={13} /> Inactive
                      </span>
                    )}
                  </td>

                  <td className="py-4 px-6 text-right">
                    <div className="inline-flex items-center gap-2">
                      <Link
                        href={`/admin/categories?edit=${encodeURIComponent(cat.id)}`}
                        scroll={false}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-none bg-amber-50 dark:bg-amber-400/10 hover:bg-amber-100 dark:hover:bg-amber-400/20 text-amber-800 dark:text-amber-400 border border-amber-200 dark:border-amber-400/30 text-xs font-bold transition-all active:scale-95"
                      >
                        <Edit3 size={13} />
                        <span>Edit</span>
                      </Link>

                      <form method="POST" action="/api/admin/categories/delete" className="inline">
                        <input type="hidden" name="id" value={cat.id} />
                        <button
                          type="submit"
                          className="p-1.5 rounded-none bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 transition-all cursor-pointer active:scale-95"
                          title="Delete Category"
                          aria-label="Delete Category"
                        >
                          <Trash2 size={14} />
                        </button>
                      </form>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Category Modal */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
          <Link
            href="/admin/categories"
            scroll={false}
            className="fixed inset-0 cursor-default"
            aria-label="Close modal"
          />

          <div className="bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none p-6 sm:p-8 max-w-lg w-full shadow-2xl relative z-10 my-8">
            <div className="flex items-center justify-between pb-6 border-b border-neutral-100 dark:border-neutral-800">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-none bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 text-amber-700 dark:text-amber-400 text-[10px] font-black uppercase tracking-widest mb-1.5">
                  <Plus size={12} />
                  <span>Taxonomy</span>
                </div>
                <h3 className="text-xl font-extrabold text-neutral-900 dark:text-white">Create New Category</h3>
              </div>
              <Link
                href="/admin/categories"
                scroll={false}
                className="p-2 rounded-none bg-neutral-100 dark:bg-neutral-900 text-neutral-500 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white transition-colors"
                aria-label="Close"
              >
                <X size={18} />
              </Link>
            </div>

            <form method="POST" action="/api/admin/categories/create" className="space-y-4 pt-6">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Category Name *
                </label>
                <input
                  type="text"
                  name="name"
                  required
                  placeholder="e.g. Motorized Blinds"
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Icon / Image Upload
                </label>
                <ImageUploadInput
                  name="imageUrl"
                  placeholder="/icon_blinds_1786042796413.png"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Description
                </label>
                <textarea
                  name="description"
                  rows={3}
                  placeholder="Brief description of this product division..."
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none p-4 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                    Display Order #
                  </label>
                  <input
                    type="number"
                    name="order"
                    defaultValue={categories.length + 1}
                    className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400"
                  />
                </div>

                <div className="flex items-center gap-3 pt-6">
                  <input
                    type="checkbox"
                    id="cat-isActive"
                    name="isActive"
                    defaultChecked
                    className="w-4 h-4 rounded-none bg-neutral-50 dark:bg-neutral-950 border border-neutral-300 dark:border-neutral-800 text-amber-500 focus:ring-amber-400"
                  />
                  <label htmlFor="cat-isActive" className="text-xs font-bold text-neutral-700 dark:text-neutral-300 cursor-pointer">
                    Active on Store
                  </label>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-6 border-t border-neutral-100 dark:border-neutral-800">
                <Link
                  href="/admin/categories"
                  scroll={false}
                  className="px-5 py-2.5 rounded-none bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-900 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 text-xs font-bold transition-all"
                >
                  Cancel
                </Link>
                <button
                  type="submit"
                  className="inline-flex items-center gap-2 px-6 py-2.5 rounded-none bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95"
                >
                  <Save size={15} />
                  <span>Create Category</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Category Modal */}
      {editingCategory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
          <Link
            href="/admin/categories"
            scroll={false}
            className="fixed inset-0 cursor-default"
            aria-label="Close modal"
          />

          <div className="bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none p-6 sm:p-8 max-w-lg w-full shadow-2xl relative z-10 my-8">
            <div className="flex items-center justify-between pb-6 border-b border-neutral-100 dark:border-neutral-800">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-none bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 text-amber-700 dark:text-amber-400 text-[10px] font-black uppercase tracking-widest mb-1.5">
                  <Edit3 size={12} />
                  <span>Modify Category</span>
                </div>
                <h3 className="text-xl font-extrabold text-neutral-900 dark:text-white">Edit &quot;{editingCategory.name}&quot;</h3>
              </div>
              <Link
                href="/admin/categories"
                scroll={false}
                className="p-2 rounded-none bg-neutral-100 dark:bg-neutral-900 text-neutral-500 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white transition-colors"
                aria-label="Close"
              >
                <X size={18} />
              </Link>
            </div>

            <form method="POST" action="/api/admin/categories/update" className="space-y-4 pt-6">
              <input type="hidden" name="id" value={editingCategory.id} />

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Category Name *
                </label>
                <input
                  type="text"
                  name="name"
                  required
                  defaultValue={editingCategory.name}
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Icon / Image Upload
                </label>
                <ImageUploadInput
                  name="imageUrl"
                  defaultValue={editingCategory.imageUrl || ""}
                  placeholder="/icon_blinds_1786042796413.png"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Description
                </label>
                <textarea
                  name="description"
                  rows={3}
                  defaultValue={editingCategory.description || ""}
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none p-4 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                    Display Order #
                  </label>
                  <input
                    type="number"
                    name="order"
                    defaultValue={editingCategory.order}
                    className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400"
                  />
                </div>

                <div className="flex items-center gap-3 pt-6">
                  <input
                    type="checkbox"
                    id="edit-cat-isActive"
                    name="isActive"
                    defaultChecked={editingCategory.isActive}
                    className="w-4 h-4 rounded-none bg-neutral-50 dark:bg-neutral-950 border border-neutral-300 dark:border-neutral-800 text-amber-500 focus:ring-amber-400"
                  />
                  <label htmlFor="edit-cat-isActive" className="text-xs font-bold text-neutral-700 dark:text-neutral-300 cursor-pointer">
                    Active on Store
                  </label>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-6 border-t border-neutral-100 dark:border-neutral-800">
                <Link
                  href="/admin/categories"
                  scroll={false}
                  className="px-5 py-2.5 rounded-none bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-900 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 text-xs font-bold transition-all"
                >
                  Cancel
                </Link>
                <button
                  type="submit"
                  className="inline-flex items-center gap-2 px-6 py-2.5 rounded-none bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95"
                >
                  <Save size={15} />
                  <span>Save Changes</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
