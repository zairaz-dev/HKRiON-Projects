"use strict";
"use client";

import React, { useEffect, useState } from "react";
import {
  Shield,
  Users,
  Lock,
  Check,
  RotateCcw,
  Save,
  Loader2,
  CheckCircle,
  AlertCircle,
  XCircle,
  HelpCircle
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { authService } from "@/services/auth-service";
import { LoadingSession } from "@/components/ui/loading-session";
import { User } from "@hkr/types";
import Link from "next/link";

// Define Permission Structure
interface PermissionItem {
  id: string;
  name: string;
  description: string;
}

interface PermissionGroup {
  category: string;
  items: PermissionItem[];
}

const permissionGroups: PermissionGroup[] = [
  {
    category: "Point of Sale (POS)",
    items: [
      { id: "pos:view", name: "Access POS Terminal", description: "Allows opening the POS selling screen." },
      { id: "pos:create_transaction", name: "Create Transactions", description: "Allows processing sales and completing checkouts." },
      { id: "pos:void_transaction", name: "Void Transactions", description: "Allows voiding active or completed sales." },
      { id: "pos:refund", name: "Process Refunds", description: "Allows refunding items and returning cash/credit." },
      { id: "pos:edit_price", name: "Modify Selling Price", description: "Allows changing the unit price of items in the cart." },
      { id: "pos:apply_discount", name: "Apply Discounts", description: "Allows giving percentage or fixed bill discounts." },
      { id: "pos:credit_sale", name: "Allow Credit / Due Sale", description: "Allows completing sales with unpaid / due balances." },
      { id: "pos:hold_sale", name: "Hold / Resume Bills", description: "Allows saving in-progress sales as hold bills and resuming them." },
      { id: "pos:quick_add_product", name: "Quick Add Products in POS", description: "Allows creating new products directly from POS." },
      { id: "pos:close_register", name: "Close Register & Shift", description: "Allows closing cash registers and submitting cash reports." },
      { id: "pos:reprint_receipt", name: "Reprint Receipts", description: "Allows reprinting past receipts." }
    ]
  },
  {
    category: "Quotations (Estimates)",
    items: [
      { id: "quotations:view", name: "View Quotations", description: "Allows viewing customer quotation estimates." },
      { id: "quotations:create", name: "Create Quotations", description: "Allows creating new price quotations for customers." },
      { id: "quotations:edit", name: "Edit Quotations", description: "Allows modifying pending quotations." },
      { id: "quotations:delete", name: "Delete Quotations", description: "Allows removing price quotations." }
    ]
  },
  {
    category: "Inventory & Stock",
    items: [
      { id: "inventory:view", name: "View Inventory", description: "Allows browsing product lists and stock levels." },
      { id: "inventory:add_product", name: "Add New Products", description: "Allows creating new product listings." },
      { id: "inventory:edit_product", name: "Edit Products", description: "Allows updating product names, prices, and details." },
      { id: "inventory:delete_product", name: "Delete Products", description: "Allows removing products from the system." },
      { id: "inventory:adjust_stock", name: "Adjust Stock Levels", description: "Allows manually updating stock counts." },
      { id: "inventory:transfer_stock", name: "Transfer Stock", description: "Allows transferring items between branches." }
    ]
  },
  {
    category: "Purchases & Procurement",
    items: [
      { id: "purchases:view", name: "View Purchases", description: "Allows browsing purchase orders and supplier bills." },
      { id: "purchases:create", name: "Create Purchases", description: "Allows recording new purchases from suppliers." },
      { id: "purchases:edit", name: "Edit Purchases", description: "Allows modifying purchase orders and received items." },
      { id: "purchases:delete", name: "Delete Purchases", description: "Allows removing purchase invoices." }
    ]
  },
  {
    category: "Contacts & CRM",
    items: [
      { id: "contacts:view", name: "View Contacts", description: "Allows viewing customers and suppliers directory." },
      { id: "contacts:create", name: "Create Contacts", description: "Allows adding new customers and suppliers." },
      { id: "contacts:edit", name: "Edit Contacts", description: "Allows updating customer and supplier details." },
      { id: "contacts:delete", name: "Delete Contacts", description: "Allows deleting customer and supplier profiles." }
    ]
  },
  {
    category: "User & HR Management",
    items: [
      { id: "users:view", name: "View Team Directory", description: "Allows viewing list of employees and roles." },
      { id: "users:create", name: "Add New Users", description: "Allows registering new employee accounts." },
      { id: "users:edit", name: "Edit User Profiles", description: "Allows updating names, emails, and roles." },
      { id: "users:delete", name: "Delete Users", description: "Allows terminating employee accounts." },
      { id: "users:manage_permissions", name: "Manage Permissions", description: "Allows editing role-permission mappings." }
    ]
  },
  {
    category: "Financial Ledger & Expenses",
    items: [
      { id: "finance:view_ledger", name: "View General Ledger", description: "Allows viewing overall sales revenue and expenses." },
      { id: "finance:add_expense", name: "Record Expenses", description: "Allows logging business costs and payouts." },
      { id: "finance:view_reports", name: "Financial Analytics & Reports", description: "Allows viewing detailed profit & loss charts." }
    ]
  },
  {
    category: "System Settings",
    items: [
      { id: "settings:view", name: "View ERP Settings", description: "Allows viewing store configuration details." },
      { id: "settings:edit", name: "Modify ERP Settings", description: "Allows changing store details, currency, and tax." }
    ]
  }
];

const roles = [
  { id: "admin", name: "Admin", color: "text-violet-400 border-violet-500/20 bg-violet-500/10" },
  { id: "manager", name: "Manager", color: "text-indigo-400 border-indigo-500/20 bg-indigo-500/10" },
  { id: "cashier", name: "Cashier", color: "text-blue-400 border-blue-500/20 bg-blue-500/10" },
  { id: "employee", name: "Employee", color: "text-slate-400 border-slate-500/20 bg-slate-500/10" }
];

export default function RolesPermissionsPage() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Permissions state
  const [permissionsMap, setPermissionsMap] = useState<Record<string, string[]>>({});
  const [originalMap, setOriginalMap] = useState<Record<string, string[]>>({});
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");
  const [hasChanges, setHasChanges] = useState<boolean>(false);

  // Authenticate and fetch permissions
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
      return;
    }

    if (user) {
      fetchPermissions(user.businessId || undefined);
    }
  }, []);

  const fetchPermissions = async (businessId?: string) => {
    setLoading(true);
    setError("");
    try {
      const data = await authService.getRolePermissions(businessId);
      setPermissionsMap(data);
      setOriginalMap(JSON.parse(JSON.stringify(data)));
      setHasChanges(false);
    } catch (err: any) {
      setError(err.message || "Failed to load permissions. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // Check if there are changes
  useEffect(() => {
    if (Object.keys(permissionsMap).length === 0) return;
    const hasDiff = JSON.stringify(permissionsMap) !== JSON.stringify(originalMap);
    setHasChanges(hasDiff);
  }, [permissionsMap, originalMap]);

  // Auto-dismiss notifications
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  const handleTogglePermission = (roleId: string, permissionId: string) => {
    setPermissionsMap((prev) => {
      const rolePerms = prev[roleId] || [];
      const updatedPerms = rolePerms.includes(permissionId)
        ? rolePerms.filter((id) => id !== permissionId)
        : [...rolePerms, permissionId];
      
      return {
        ...prev,
        [roleId]: updatedPerms
      };
    });
  };

  const handleSaveChanges = async () => {
    setSaving(true);
    setError("");
    try {
      await authService.saveRolePermissions(permissionsMap, currentUser?.businessId || undefined);
      setOriginalMap(JSON.parse(JSON.stringify(permissionsMap)));
      setSuccessMessage("Roles & permissions updated successfully!");
      setHasChanges(false);
    } catch (err: any) {
      setError(err.message || "Failed to save changes. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const handleResetToDefault = () => {
    const defaultPermissions = {
      admin: [
        "pos:view", "pos:create_transaction", "pos:void_transaction", "pos:refund",
        "inventory:view", "inventory:add_product", "inventory:edit_product", "inventory:delete_product", "inventory:adjust_stock",
        "users:view", "users:create", "users:edit", "users:delete", "users:manage_permissions",
        "finance:view_ledger", "finance:add_expense", "finance:view_reports",
        "settings:view", "settings:edit"
      ],
      manager: [
        "pos:view", "pos:create_transaction", "pos:void_transaction",
        "inventory:view", "inventory:add_product", "inventory:edit_product", "inventory:adjust_stock",
        "users:view", "users:create", "users:edit",
        "finance:view_ledger", "finance:add_expense",
        "settings:view"
      ],
      cashier: [
        "pos:view", "pos:create_transaction"
      ],
      employee: [
        "inventory:view"
      ]
    };
    setPermissionsMap(defaultPermissions);
  };

  if (isAuthenticated === null) {
    return <LoadingSession />;
  }

  if (isAuthenticated === false) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-4 text-center p-4">
        <XCircle className="w-12 h-12 text-red-500 animate-bounce" />
        <h2 className="text-xl font-bold text-white">Access Denied</h2>
        <p className="text-sm text-slate-400 max-w-sm">
          You must be signed in to access the Roles & Permissions page. Redirecting to login page...
        </p>
        <Link href="/login">
          <Button className="bg-emerald-600 hover:bg-emerald-500 text-white mt-2">
            Go to Login
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="h-screen bg-background text-slate-100 flex overflow-hidden">
      {/* Sidebar */}
      <Sidebar activePath="/users" />

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        {/* Glowing Background Orbs */}
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-emerald-500/5 blur-[120px] pointer-events-none z-0" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[550px] h-[550px] rounded-full bg-teal-500/5 blur-[130px] pointer-events-none z-0" />

        {/* Navbar */}
        <Navbar title="Roles & Permissions" subtitle="Configure system access levels" className="relative z-10" />

        {/* Scrollable Main Content */}
        <main className="flex-1 overflow-y-auto py-6 px-4 relative z-10">
          <div className="w-full space-y-6 pb-24 max-w-7xl mx-auto">

            {/* Status Notifications */}
            {successMessage && (
              <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-450 p-4 rounded-sm text-xs animate-fadeIn">
                <CheckCircle className="w-4 h-4 flex-shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}

            {error && (
              <div className="flex items-center gap-2 bg-rose-500/10 border border-rose-500/20 text-rose-450 p-4 rounded-sm text-xs animate-fadeIn">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Tab Navigation */}
            <div className="flex border-b border-slate-900 gap-6">
              <Link href="/users">
                <span className="pb-3 text-xs font-semibold text-slate-400 hover:text-white cursor-pointer transition-colors block">
                  Users Directory
                </span>
              </Link>
              <span className="pb-3 text-xs font-semibold text-violet-400 border-b-2 border-violet-500 cursor-default block">
                Roles & Permissions
              </span>
              <Link href="/roles">
                <span className="pb-3 text-xs font-semibold text-slate-400 hover:text-white cursor-pointer transition-colors block">
                  Role Management
                </span>
              </Link>
            </div>

            {/* Matrix Card */}
            <div className="glass rounded-sm border border-slate-800/80 overflow-hidden">
              
              <div className="px-6 py-4 border-b border-slate-900 bg-slate-950/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-sm font-bold text-white">System Access Control Matrix</h3>
                  <p className="text-[11px] text-slate-500 mt-1">Configure which features are available for each system role.</p>
                </div>
                <Button
                  onClick={handleResetToDefault}
                  variant="outline"
                  className="bg-slate-950/40 border-slate-800 text-slate-400 hover:text-white text-xs h-8 gap-1.5 self-start sm:self-auto rounded-sm"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Reset to Defaults
                </Button>
              </div>

              {loading ? (
                <div className="py-24 flex flex-col items-center justify-center gap-3 text-slate-400 font-mono text-xs">
                  <Loader2 className="w-6 h-6 animate-spin text-violet-500" />
                  Loading permissions matrix...
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-800/80 bg-slate-950/40 text-slate-400 uppercase tracking-wider font-mono">
                        <th className="py-4 px-6 font-semibold w-1/3">Permission Module & Action</th>
                        {roles.map((role) => (
                          <th key={role.id} className="py-4 px-4 font-semibold text-center w-1/6">
                            <span className={`inline-block px-2.5 py-0.5 rounded-sm text-[10px] font-semibold border ${role.color}`}>
                              {role.name}
                            </span>
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-900">
                      {permissionGroups.map((group) => (
                        <React.Fragment key={group.category}>
                          {/* Category Header Row */}
                          <tr className="bg-slate-950/20">
                            <td colSpan={5} className="py-3 px-6 font-bold text-slate-400 tracking-wider text-[10px] uppercase font-mono border-y border-slate-900">
                              {group.category}
                            </td>
                          </tr>
                          {/* Items Rows */}
                          {group.items.map((item) => (
                            <tr key={item.id} className="hover:bg-slate-900/10 transition-colors duration-150">
                              <td className="py-4 px-6">
                                <div className="space-y-1">
                                  <h4 className="font-semibold text-white flex items-center gap-1.5">
                                    {item.name}
                                    <span className="text-[9px] font-mono text-slate-500 font-normal">({item.id})</span>
                                  </h4>
                                  <p className="text-[10px] text-slate-500 font-medium leading-relaxed max-w-lg">
                                    {item.description}
                                  </p>
                                </div>
                              </td>
                              {roles.map((role) => {
                                const isChecked = (permissionsMap[role.id] || []).includes(item.id);
                                return (
                                  <td key={role.id} className="py-4 px-4 text-center">
                                    <div className="flex items-center justify-center">
                                      <button
                                        type="button"
                                        onClick={() => handleTogglePermission(role.id, item.id)}
                                        className={`w-5 h-5 rounded-sm border flex items-center justify-center transition-all duration-150 ${
                                          isChecked
                                            ? "bg-violet-600 border-violet-500 text-white shadow-md shadow-violet-500/10"
                                            : "bg-slate-950/80 border-slate-800 hover:border-slate-700 text-transparent"
                                        }`}
                                      >
                                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                                      </button>
                                    </div>
                                  </td>
                                );
                              })}
                            </tr>
                          ))}
                        </React.Fragment>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

          </div>
        </main>

        {/* Floating Save Action Bar */}
        {hasChanges && (
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30 bg-slate-950/90 border border-violet-500/20 backdrop-blur-md px-6 py-4 rounded-sm shadow-2xl flex items-center gap-6 animate-slideUp">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-violet-400 animate-pulse" />
              <p className="text-xs font-semibold text-white">Unsaved changes in permissions matrix</p>
            </div>
            <div className="flex items-center gap-3">
              <Button
                onClick={() => fetchPermissions(currentUser?.businessId || undefined)}
                variant="outline"
                className="bg-slate-900 border-slate-800 text-slate-400 hover:text-white text-xs h-8 rounded-sm"
              >
                Discard
              </Button>
              <Button
                onClick={handleSaveChanges}
                disabled={saving}
                className="bg-violet-600 hover:bg-violet-500 text-white text-xs h-8 px-4 rounded-sm shadow-md shadow-violet-500/10 flex items-center gap-1"
              >
                {saving ? (
                  <>
                    <Loader2 className="w-3 h-3 animate-spin" /> Saving...
                  </>
                ) : (
                  <>
                    <Save className="w-3.5 h-3.5" /> Save Changes
                  </>
                )}
              </Button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
