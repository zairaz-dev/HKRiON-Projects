import { writeFile, mkdir } from "fs/promises";
import { join } from "path";
import { existsSync } from "fs";
import sharp from "sharp";

export async function uploadProfilePicture(file: File, userId: number): Promise<string> {
  const bytes = await file.arrayBuffer();
  const buffer = Buffer.from(bytes);

  // Always output as webp for maximum compression and consistency
  const extension = 'webp';
  
  // Create a unique filename for the user
  const fileName = `user-${userId}-${Date.now()}.${extension}`;
  
  // Path to public/uploads/profiles directory
  const uploadDir = join(process.cwd(), "public", "uploads", "profiles");
  
  // Ensure the directory exists
  if (!existsSync(uploadDir)) {
    await mkdir(uploadDir, { recursive: true });
  }

  const filePath = join(uploadDir, fileName);
  
  // Compress and resize the image using sharp
  const compressedBuffer = await sharp(buffer)
    .resize(400, 400, {
      fit: 'cover',
      position: 'center'
    })
    .webp({ quality: 80 })
    .toBuffer();

  // Write the file to the disk
  await writeFile(filePath, compressedBuffer);

  // Return the public URL path
  return `/uploads/profiles/${fileName}`;
}
