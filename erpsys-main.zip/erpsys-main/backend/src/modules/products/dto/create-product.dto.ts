import {
  IsString,
  IsNotEmpty,
  IsOptional,
  IsEnum,
  IsBoolean,
  IsNumber,
  Min,
  MaxLength,
  IsArray,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import { ProductType } from '@prisma/client';

export class GroupPriceDto {
  @IsString()
  @IsNotEmpty()
  sellingPriceGroupId: string;

  @IsNumber()
  @Min(0, { message: 'Group price must be 0 or greater' })
  price: number;
}

export class VariantDto {
  @IsOptional()
  @IsString()
  id?: string;

  @IsString()
  @IsNotEmpty({ message: 'Variant name is required' })
  @MaxLength(150)
  name: string;

  @IsOptional()
  @IsString()
  @MaxLength(50)
  sku?: string;

  @IsOptional()
  @IsString()
  @MaxLength(50)
  barcode?: string;

  @IsNumber()
  @Min(0, { message: 'Purchase price must be 0 or greater' })
  purchasePrice: number;

  @IsNumber()
  @Min(0, { message: 'Selling price must be 0 or greater' })
  sellingPrice: number;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  valueIds?: string[];

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => GroupPriceDto)
  groupPrices?: GroupPriceDto[];

  @IsOptional()
  @IsNumber()
  @Min(0)
  openingStock?: number;

  @IsOptional()
  @IsString()
  openingStockBranchId?: string;
}

export class CreateProductDto {
  @IsString()
  @IsNotEmpty({ message: 'Product name is required' })
  @MaxLength(150, { message: 'Product name cannot exceed 150 characters' })
  name: string;

  @IsOptional()
  @IsString()
  @MaxLength(1000)
  description?: string;

  @IsOptional()
  @IsString()
  imageUrl?: string;

  @IsEnum(ProductType, { message: 'Product type must be SINGLE or VARIABLE' })
  type: ProductType;

  @IsOptional()
  @IsBoolean()
  isActive?: boolean;

  @IsOptional()
  @IsBoolean()
  enableStock?: boolean;

  @IsOptional()
  @IsBoolean()
  enableImei?: boolean;

  @IsOptional()
  @IsBoolean()
  isImei?: boolean;

  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Alert quantity cannot be negative' })
  alertQuantity?: number;

  @IsOptional()
  @IsBoolean()
  notForSelling?: boolean;

  @IsOptional()
  @IsNumber()
  @Min(0)
  weight?: number;

  @IsString()
  @IsNotEmpty({ message: 'Business ID is required' })
  businessId: string;

  @IsOptional()
  @IsString()
  categoryId?: string;

  @IsOptional()
  @IsString()
  brandId?: string;

  @IsOptional()
  @IsString()
  unitId?: string;

  @IsOptional()
  @IsString()
  warrantyId?: string;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  branchIds?: string[];

  // For SINGLE type
  @IsOptional()
  @IsString()
  @MaxLength(50)
  sku?: string;

  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Purchase price must be 0 or greater' })
  purchasePrice?: number;

  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Selling price must be 0 or greater' })
  sellingPrice?: number;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => GroupPriceDto)
  groupPrices?: GroupPriceDto[];

  @IsOptional()
  @IsNumber()
  @Min(0)
  openingStock?: number;

  @IsOptional()
  @IsString()
  openingStockBranchId?: string;

  // For VARIABLE type
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => VariantDto)
  variants?: VariantDto[];

  @IsOptional()
  @IsString()
  createdById?: string;
}
