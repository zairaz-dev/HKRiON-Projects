import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import {
  verifySessionToken,
  createSessionToken,
  SESSION_COOKIE_NAME,
  hashPassword,
  verifyPassword,
  timingSafeCompare,
} from "@/lib/auth";
import { pool } from "@/lib/db";
import { RowDataPacket } from "mysql2";
import { SITE_CONFIG } from "@/lib/constants/site";

export const dynamic = "force-dynamic";
export const revalidate = 0;

// GET: Fetch Admin Profile
export async function GET() {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get(SESSION_COOKIE_NAME)?.value;

    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const sessionUser = verifySessionToken(token);
    if (!sessionUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Query admin user from users table
    const [rows] = await pool.query<RowDataPacket[]>(
      "SELECT id, name, email, phone, role, created_at FROM users WHERE email = ? AND role = 'ADMIN' LIMIT 1",
      [sessionUser.email]
    );

    const admin = rows && rows.length > 0 ? rows[0] : null;

    return NextResponse.json({
      user: {
        name: admin?.name || sessionUser.name || "Admin",
        email: admin?.email || sessionUser.email || process.env.ADMIN_EMAIL || SITE_CONFIG.contact.adminEmail,
        phone: admin?.phone || process.env.ADMIN_PHONE || SITE_CONFIG.contact.phone,
        role: admin?.role || "ADMIN",
        createdAt: admin?.created_at || null,
      },
    });
  } catch (error) {
    console.error("GET /api/admin/profile error:", error);
    return NextResponse.json(
      { error: "Failed to load admin profile" },
      { status: 500 }
    );
  }
}

// PUT: Update Admin Profile & Credentials
export async function PUT(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get(SESSION_COOKIE_NAME)?.value;

    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const sessionUser = verifySessionToken(token);
    if (!sessionUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { name, email, phone, currentPassword, newPassword } = body;

    if (!name || !name.trim()) {
      return NextResponse.json({ error: "Name cannot be empty." }, { status: 400 });
    }

    if (!email || !email.trim() || !email.includes("@")) {
      return NextResponse.json({ error: "A valid email address is required." }, { status: 400 });
    }

    // Retrieve current admin record strictly matching the authenticated admin
    const [rows] = await pool.query<RowDataPacket[]>(
      "SELECT id, name, email, phone, password_hash, role FROM users WHERE email = ? AND role = 'ADMIN' LIMIT 1",
      [sessionUser.email]
    );

    if (!rows || rows.length === 0) {
      return NextResponse.json({ error: "Admin record not found in database." }, { status: 404 });
    }

    const currentAdmin = rows[0];
    const targetEmail = email.trim().toLowerCase();
    const targetName = name.trim();
    const targetPhone = (phone || "").trim();

    // If changing email address, verify that it is not already in use by another user
    if (targetEmail !== sessionUser.email.toLowerCase()) {
      const [existingUsers] = await pool.query<RowDataPacket[]>(
        "SELECT id FROM users WHERE email = ? AND id != ? LIMIT 1",
        [targetEmail, currentAdmin.id]
      );
      if (existingUsers && existingUsers.length > 0) {
        return NextResponse.json(
          { error: "This email address is already in use by another account." },
          { status: 409 }
        );
      }
    }

    // Check if new password is requested
    let passwordHashToSave = currentAdmin.password_hash;
    if (newPassword && newPassword.trim()) {
      if (!currentPassword) {
        return NextResponse.json(
          { error: "Current password is required to set a new password." },
          { status: 400 }
        );
      }

      if (newPassword.trim().length < 6) {
        return NextResponse.json(
          { error: "New password must be at least 6 characters long." },
          { status: 400 }
        );
      }

      // Verify current password
      const envAdminPass = process.env.ADMIN_PASSWORD;
      const adminEmail = process.env.ADMIN_EMAIL ? process.env.ADMIN_EMAIL.trim().toLowerCase() : null;
      let isCurrentValid = false;
      if (currentAdmin.password_hash) {
        if (typeof currentAdmin.password_hash === "string" && currentAdmin.password_hash.startsWith("$2")) {
          isCurrentValid = await verifyPassword(currentPassword, currentAdmin.password_hash);
        } else {
          isCurrentValid = timingSafeCompare(currentAdmin.password_hash, currentPassword);
        }
      }
      if (!isCurrentValid && envAdminPass && adminEmail && timingSafeCompare(sessionUser.email.toLowerCase(), adminEmail)) {
        isCurrentValid = timingSafeCompare(currentPassword, envAdminPass);
      }

      if (!isCurrentValid) {
        return NextResponse.json(
          { error: "Current password is incorrect. Please verify and try again." },
          { status: 400 }
        );
      }

      passwordHashToSave = await hashPassword(newPassword.trim());
    }

    // Update in MySQL users table
    await pool.query(
      `UPDATE users 
       SET name = ?, email = ?, phone = ?, password_hash = ? 
       WHERE id = ?`,
      [targetName, targetEmail, targetPhone, passwordHashToSave, currentAdmin.id]
    );

    // Also update clients table only for this admin's previous CRM record
    await pool.query(
      `UPDATE clients 
       SET name = ?, email = ?, phone = ? 
       WHERE email = ?`,
      [targetName, targetEmail, targetPhone, sessionUser.email]
    );

    // Re-issue updated session cookie
    const newToken = createSessionToken({
      email: targetEmail,
      name: targetName,
    });

    const response = NextResponse.json({
      success: true,
      user: {
        name: targetName,
        email: targetEmail,
        phone: targetPhone,
        role: "ADMIN",
      },
    });

    response.cookies.set(SESSION_COOKIE_NAME, newToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 7 * 24 * 60 * 60, // 7 days
      path: "/",
    });

    return response;
  } catch (error) {
    console.error("PUT /api/admin/profile error:", error);
    return NextResponse.json(
      { error: "Failed to update admin profile." },
      { status: 500 }
    );
  }
}
