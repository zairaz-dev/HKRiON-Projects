import React, { useState, useEffect } from "react";
import {
  X,
  Loader2,
  ArrowRightLeft,
  Building2,
  Calendar,
  Search,
  Plus,
  Trash2,
  Truck,
  Package
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { useCreateStockTransferMutation } from "../hooks/use-stock-transfers";
import { useBranchesQuery } from "@/features/suppliers/hooks/use-suppliers";
import { useProductsQuery } from "@/features/products/hooks/use-products";
import { useCurrency } from "@/hooks/use-currency";

interface CreateTransferDialogProps {
  isOpen: boolean;
  onClose: () => void;
  businessId: string;
  userId: string;
  onSuccess: (msg: string) => void;
  onError: (msg: string) => void;
}

interface LineItem {
  variantId: string;
  productName: string;
  sku: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
}

export function CreateTransferDialog({
  isOpen,
  onClose,
  businessId,
  userId,
  onSuccess,
  onError,
}: CreateTransferDialogProps) {
  const { symbol } = useCurrency(businessId);
  const createMutation = useCreateStockTransferMutation();
  const { data: branchesList = [] } = useBranchesQuery(businessId, userId);
  const { data: productsList = [] } = useProductsQuery(businessId);

  const [fromBranchId, setFromBranchId] = useState("");
  const [toBranchId, setToBranchId] = useState("");
  const [status, setStatus] = useState<"COMPLETED" | "PENDING">("COMPLETED");
  const [transferDate, setTransferDate] = useState("");
  const [shippingCharges, setShippingCharges] = useState("0");
  const [notes, setNotes] = useState("");
  const [lines, setLines] = useState<LineItem[]>([]);

  // Search state for line item addition
  const [productSearch, setProductSearch] = useState("");
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const firstBranch = branchesList[0]?.id || "";
      const secondBranch = branchesList[1]?.id || branchesList[0]?.id || "";
      setFromBranchId(firstBranch);
      setToBranchId(secondBranch !== firstBranch ? secondBranch : "");
      setStatus("COMPLETED");
      setTransferDate(new Date().toISOString().split("T")[0]);
      setShippingCharges("0");
      setNotes("");
      setLines([]);
    }
  }, [isOpen, branchesList]);

  if (!isOpen) return null;

  // Flatten products into variants list
  const availableVariants: Array<{
    variantId: string;
    displayName: string;
    sku: string;
    price: number;
  }> = [];

  productsList.forEach((prod: any) => {
    if (prod.variants && prod.variants.length > 0) {
      prod.variants.forEach((v: any) => {
        availableVariants.push({
          variantId: v.id,
          displayName: `${prod.name} ${v.name !== prod.name ? `(${v.name})` : ""}`,
          sku: v.sku,
          price: v.purchasePrice || 0,
        });
      });
    }
  });

  const filteredVariants = availableVariants.filter(
    (v) =>
      v.displayName.toLowerCase().includes(productSearch.toLowerCase()) ||
      v.sku.toLowerCase().includes(productSearch.toLowerCase()),
  );

  const handleAddVariant = (v: typeof availableVariants[0]) => {
    const existingIndex = lines.findIndex((l) => l.variantId === v.variantId);
    if (existingIndex >= 0) {
      const updated = [...lines];
      updated[existingIndex].quantity += 1;
      updated[existingIndex].subtotal = updated[existingIndex].quantity * updated[existingIndex].unitPrice;
      setLines(updated);
    } else {
      setLines([
        ...lines,
        {
          variantId: v.variantId,
          productName: v.displayName,
          sku: v.sku,
          quantity: 1,
          unitPrice: v.price,
          subtotal: v.price,
        },
      ]);
    }
    setProductSearch("");
    setIsSearchOpen(false);
  };

  const handleQuantityChange = (index: number, val: string) => {
    let q = parseFloat(val) || 0;
    if (q < 0) q = 0;
    const updated = [...lines];
    updated[index].quantity = q;
    updated[index].subtotal = q * updated[index].unitPrice;
    setLines(updated);
  };

  const handleUnitPriceChange = (index: number, val: string) => {
    let p = parseFloat(val) || 0;
    if (p < 0) p = 0;
    const updated = [...lines];
    updated[index].unitPrice = p;
    updated[index].subtotal = updated[index].quantity * p;
    setLines(updated);
  };

  const handleRemoveLine = (index: number) => {
    setLines(lines.filter((_, i) => i !== index));
  };

  const itemsTotal = lines.reduce((sum, l) => sum + l.subtotal, 0);
  const totalAmount = itemsTotal + (parseFloat(shippingCharges) || 0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!fromBranchId || !toBranchId) {
      onError("Please select both Source and Destination branches.");
      return;
    }

    if (fromBranchId === toBranchId) {
      onError("Source and Destination branches cannot be the same.");
      return;
    }

    if (lines.length === 0) {
      onError("Please add at least one product item to transfer.");
      return;
    }

    const payload = {
      transferDate: transferDate ? new Date(transferDate).toISOString() : undefined,
      status,
      fromBranchId,
      toBranchId,
      businessId,
      shippingCharges: parseFloat(shippingCharges) || 0,
      notes: notes.trim() || undefined,
      createdById: userId,
      transferLines: lines.map((l) => ({
        variantId: l.variantId,
        quantity: l.quantity,
        unitPrice: l.unitPrice,
      })),
    };

    try {
      const res = await createMutation.mutateAsync(payload);
      onSuccess(`Stock Transfer ${res.transferNumber || ""} created successfully!`);
      onClose();
    } catch (err: any) {
      onError(err.message || "Failed to create stock transfer.");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
      <div className="w-full max-w-3xl rounded-xl border border-border bg-card p-6 shadow-2xl animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh] overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border pb-3 mb-4 shrink-0">
          <div className="flex items-center gap-2">
            <ArrowRightLeft className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-bold">New Stock Transfer</h3>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="h-8 w-8 rounded-full"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto space-y-4 pr-1 pb-4">
            
            {/* Top Grid: From Branch, To Branch, Status, Date */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 bg-muted/30 p-3.5 rounded-lg border border-border/40 text-xs">
              
              {/* From Branch */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                  <Building2 className="h-3 w-3 text-rose-500" /> From Branch (Source)
                </label>
                <Select
                  value={fromBranchId}
                  onValueChange={setFromBranchId}
                  className="h-9 text-xs"
                >
                  {branchesList.map((b: any) => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </Select>
              </div>

              {/* To Branch */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                  <Building2 className="h-3 w-3 text-emerald-500" /> To Branch (Destination)
                </label>
                <Select
                  value={toBranchId}
                  onValueChange={setToBranchId}
                  className="h-9 text-xs"
                >
                  <option value="">Select Destination...</option>
                  {branchesList
                    .filter((b: any) => b.id !== fromBranchId)
                    .map((b: any) => (
                      <option key={b.id} value={b.id}>{b.name}</option>
                    ))}
                </Select>
              </div>

              {/* Transfer Status */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-muted-foreground uppercase">
                  Transfer Status
                </label>
                <Select
                  value={status}
                  onValueChange={(val: any) => setStatus(val)}
                  className="h-9 text-xs"
                >
                  <option value="COMPLETED">Completed (Immediate Transfer)</option>
                  <option value="PENDING">Pending (In-Transit)</option>
                </Select>
              </div>

              {/* Date */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                  <Calendar className="h-3 w-3 text-primary" /> Date
                </label>
                <Input
                  type="date"
                  value={transferDate}
                  onChange={(e) => setTransferDate(e.target.value)}
                  className="h-9 text-xs"
                  required
                />
              </div>
            </div>

            {/* Product Selector Autocomplete */}
            <div className="space-y-2 relative">
              <span className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider block">
                Add Items to Transfer
              </span>

              <div className="relative">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  value={productSearch}
                  onChange={(e) => {
                    setProductSearch(e.target.value);
                    setIsSearchOpen(true);
                  }}
                  onFocus={() => setIsSearchOpen(true)}
                  placeholder="Type product name or SKU to add item..."
                  className="pl-9 h-9 text-xs"
                />
              </div>

              {/* Dropdown suggestions */}
              {isSearchOpen && productSearch.trim().length > 0 && (
                <div className="absolute left-0 right-0 z-30 max-h-48 overflow-y-auto rounded-lg border border-border bg-card shadow-xl p-1 text-xs">
                  {filteredVariants.length === 0 ? (
                    <div className="p-3 text-center text-muted-foreground">
                      No matching products found
                    </div>
                  ) : (
                    filteredVariants.map((v) => (
                      <button
                        key={v.variantId}
                        type="button"
                        onClick={() => handleAddVariant(v)}
                        className="w-full text-left p-2 rounded hover:bg-muted/60 flex items-center justify-between transition-colors"
                      >
                        <div>
                          <span className="font-semibold text-foreground block">{v.displayName}</span>
                          <span className="text-[10px] font-mono text-muted-foreground">SKU: {v.sku}</span>
                        </div>
                        <span className="font-mono text-muted-foreground text-[11px]">
                          Cost: {symbol}{v.price.toFixed(2)}
                        </span>
                      </button>
                    ))
                  )}
                </div>
              )}
            </div>

            {/* Items Table */}
            <div className="border border-border/60 rounded-lg overflow-hidden">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="bg-muted/40 border-b border-border/60">
                    <th className="p-3 font-semibold text-muted-foreground">Product</th>
                    <th className="p-3 font-semibold text-muted-foreground text-center w-28">Quantity</th>
                    <th className="p-3 font-semibold text-muted-foreground text-right w-32">Unit Cost ({symbol})</th>
                    <th className="p-3 font-semibold text-muted-foreground text-right w-32">Subtotal ({symbol})</th>
                    <th className="p-3 text-center w-12">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {lines.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="p-8 text-center text-muted-foreground">
                        <Package className="h-8 w-8 mx-auto text-muted-foreground/50 mb-1" />
                        No items added yet. Search and select products above.
                      </td>
                    </tr>
                  ) : (
                    lines.map((line, idx) => (
                      <tr key={line.variantId} className="border-b border-border/40">
                        <td className="p-3">
                          <span className="font-semibold text-foreground block">{line.productName}</span>
                          <span className="text-[10px] font-mono text-muted-foreground">SKU: {line.sku}</span>
                        </td>
                        <td className="p-3 text-center">
                          <Input
                            type="number"
                            min="1"
                            step="any"
                            value={line.quantity}
                            onChange={(e) => handleQuantityChange(idx, e.target.value)}
                            className="h-8 text-center text-xs w-full font-bold"
                          />
                        </td>
                        <td className="p-3 text-right">
                          <Input
                            type="number"
                            min="0"
                            step="any"
                            value={line.unitPrice}
                            onChange={(e) => handleUnitPriceChange(idx, e.target.value)}
                            className="h-8 text-right text-xs w-full font-mono"
                          />
                        </td>
                        <td className="p-3 text-right font-mono font-bold">
                          {symbol}{line.subtotal.toFixed(2)}
                        </td>
                        <td className="p-3 text-center">
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            onClick={() => handleRemoveLine(idx)}
                            className="h-7 w-7 text-destructive hover:bg-destructive/10"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Bottom Fields: Shipping Charges & Notes */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                  <Truck className="h-3 w-3 text-primary" /> Shipping / Freight Charges ({symbol})
                </label>
                <Input
                  type="number"
                  min="0"
                  step="any"
                  value={shippingCharges}
                  onChange={(e) => setShippingCharges(e.target.value)}
                  className="h-9 text-xs font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-muted-foreground uppercase">
                  Notes / Driver Details
                </label>
                <Input
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Driver name, vehicle #, dispatch details..."
                  className="h-9 text-xs"
                />
              </div>
            </div>
          </div>

          {/* Footer controls */}
          <div className="border-t border-border pt-4 shrink-0 flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-muted-foreground uppercase">Total Transfer Value</span>
              <span className="text-xl font-extrabold text-primary font-mono">
                {symbol}{totalAmount.toFixed(2)}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="h-9 text-xs"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createMutation.isPending || lines.length === 0}
                className="h-9 text-xs gap-1.5 shadow-md shadow-primary/10"
              >
                {createMutation.isPending && <Loader2 className="h-3 w-3 animate-spin" />}
                Confirm Transfer
              </Button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
