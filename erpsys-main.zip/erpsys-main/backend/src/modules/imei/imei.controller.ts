import { Controller, Get, Post, Patch, Body, Param, Query, UseGuards, Req } from '@nestjs/common';
import { ImeiService } from './imei.service';
import { BulkAddImeiDto, UpdateImeiStatusDto, QueryImeiDto } from './dto/imei.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('imei')
export class ImeiController {
  constructor(private readonly imeiService: ImeiService) {}

  @Permissions(Permission.PRODUCT_VIEW)
  @Get('search')
  async searchImei(@Req() req: any, @Query('query') query: string, @Query('businessId') queryBusinessId?: string) {
    const user = req.user;
    const bId = user.role === 'super-admin' && queryBusinessId ? queryBusinessId : user.businessId;
    return this.imeiService.searchImei(bId, query);
  }

  @Permissions(Permission.PRODUCT_VIEW)
  @Get('available/:variantId')
  async getAvailableImeis(
    @Req() req: any,
    @Param('variantId') variantId: string,
    @Query('branchId') branchId?: string,
    @Query('businessId') queryBusinessId?: string,
  ) {
    const user = req.user;
    const bId = user.role === 'super-admin' && queryBusinessId ? queryBusinessId : user.businessId;
    return this.imeiService.getAvailableImeis(bId, variantId, branchId);
  }

  @Permissions(Permission.PRODUCT_VIEW)
  @Get()
  async getImeiList(@Req() req: any, @Query() queryDto: QueryImeiDto) {
    const user = req.user;
    const bId = user.role === 'super-admin' && queryDto.businessId ? queryDto.businessId : user.businessId;
    return this.imeiService.getImeiList(bId, queryDto);
  }

  @Permissions(Permission.PRODUCT_CREATE)
  @Post('bulk-add')
  async bulkAddImeis(@Req() req: any, @Body() dto: BulkAddImeiDto) {
    const user = req.user;
    const bId = user.role === 'super-admin' && dto.businessId ? dto.businessId : user.businessId;
    return this.imeiService.bulkAddImeis(bId, dto);
  }

  @Permissions(Permission.PRODUCT_UPDATE)
  @Patch(':id/status')
  async updateImeiStatus(
    @Req() req: any,
    @Param('id') id: string,
    @Body() dto: UpdateImeiStatusDto,
  ) {
    const user = req.user;
    const bId = user.role === 'super-admin' && dto.businessId ? dto.businessId : user.businessId;
    return this.imeiService.updateImeiStatus(id, bId, dto);
  }
}
