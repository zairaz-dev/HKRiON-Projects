import { NextResponse } from 'next/server';
import { getContacts, saveContact, deleteContact, bulkImportContacts } from '@/lib/contactsStore';
import { getChats } from '@/lib/chatStore';

// GET all contacts (with merged active chat stats)
export async function GET() {
  try {
    const contactsMap = getContacts();
    const chatsMap = getChats();

    // Automatically register any active WhatsApp chat contacts if not in directory yet
    Object.values(chatsMap).forEach((chat) => {
      const num = chat.phoneNumber || chat.id;
      if (num && !contactsMap[num]) {
        contactsMap[num] = {
          id: num,
          phoneNumber: num,
          name: chat.name || `+${num}`,
          email: '',
          tags: ['Chat Customer'],
          notes: 'Auto-detected from WhatsApp conversations',
          source: 'WhatsApp Chat',
          createdAt: chat.lastTimestamp || new Date().toISOString(),
          updatedAt: chat.lastTimestamp || new Date().toISOString(),
        };
      }
    });

    const contactList = Object.values(contactsMap).map((contact) => {
      const activeChat = chatsMap[contact.phoneNumber] || null;
      return {
        ...contact,
        hasActiveChat: !!activeChat,
        lastMessage: activeChat?.lastMessage || null,
        lastActive: activeChat?.lastTimestamp || contact.updatedAt || contact.createdAt,
      };
    }).sort((a, b) => new Date(b.lastActive || 0) - new Date(a.lastActive || 0));

    return NextResponse.json({
      success: true,
      contacts: contactList,
      total: contactList.length,
    });
  } catch (err) {
    console.error('[API /api/contacts GET Error]:', err);
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

// POST create, edit, bulk import, or delete contacts
export async function POST(req) {
  try {
    const body = await req.json();
    const { action } = body;

    // Action: Bulk Import
    if (action === 'bulk_import' && Array.isArray(body.contacts)) {
      const result = bulkImportContacts(body.contacts, body.source || 'CSV Import');
      return NextResponse.json({ success: true, ...result });
    }

    // Action: Delete
    if (action === 'delete' && body.phoneNumber) {
      const deleted = deleteContact(body.phoneNumber);
      return NextResponse.json({ success: deleted });
    }

    // Action: Single Save / Create / Update
    const { phoneNumber, name, email, tags, notes, source } = body;
    if (!phoneNumber) {
      return NextResponse.json({ success: false, error: 'Phone number is required' }, { status: 400 });
    }

    const saved = saveContact({
      phoneNumber,
      name,
      email,
      tags: typeof tags === 'string' ? tags.split(',').map(t => t.trim()) : tags,
      notes,
      source,
    });

    return NextResponse.json({
      success: true,
      contact: saved,
    });
  } catch (err) {
    console.error('[API /api/contacts POST Error]:', err);
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
