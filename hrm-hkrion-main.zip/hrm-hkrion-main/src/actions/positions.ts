"use server";

import { prisma } from "@/lib/db";
import { revalidatePath } from "next/cache";
import { getSession } from "@/lib/session";
import { Role } from "@prisma/client";

export async function getPositions() {
  try {
    const session = await getSession();
    if (!session || session.role === Role.EMPLOYEE) {
      return { error: "Unauthorized access" };
    }

    const positions = await prisma.position.findMany({
      include: {
        _count: {
          select: { users: true },
        },
      },
      orderBy: { title: "asc" },
    });
    return { data: positions };
  } catch (error) {
    console.error("Failed to fetch positions:", error);
    return { error: "Failed to fetch positions." };
  }
}

export async function createPosition(formData: FormData) {
  const title = (formData.get("title") as string)?.trim();

  if (!title || title.length < 2) {
    return { error: "Position title must be at least 2 characters." };
  }

  if (title.length > 100) {
    return { error: "Position title cannot exceed 100 characters." };
  }

  try {
    const session = await getSession();
    if (!session || session.role === Role.EMPLOYEE) {
      return { error: "Unauthorized access" };
    }

    const existing = await prisma.position.findUnique({
      where: { title },
    });

    if (existing) {
      return { error: "A position with this title already exists." };
    }

    await prisma.$transaction(async (tx) => {
      const pos = await tx.position.create({
        data: {
          title,
        },
      });

      await tx.auditLog.create({
        data: {
          userId: session.userId,
          action: "CREATE_POSITION",
          details: `Created job position "${title}" (ID: ${pos.id})`,
        },
      });
    });

    revalidatePath("/dashboard/positions");
    revalidatePath("/dashboard/employees");
    return { success: true };
  } catch (error) {
    console.error("Failed to create position:", error);
    return { error: "Failed to create position." };
  }
}

export async function updatePosition(id: number, formData: FormData) {
  const title = (formData.get("title") as string)?.trim();

  if (!title || title.length < 2) {
    return { error: "Position title must be at least 2 characters." };
  }

  if (title.length > 100) {
    return { error: "Position title cannot exceed 100 characters." };
  }

  try {
    const session = await getSession();
    if (!session || session.role === Role.EMPLOYEE) {
      return { error: "Unauthorized access" };
    }

    const target = await prisma.position.findUnique({
      where: { id },
    });

    if (!target) {
      return { error: "Position not found." };
    }

    const existing = await prisma.position.findUnique({
      where: { title },
    });

    if (existing && existing.id !== id) {
      return { error: "A position with this title already exists." };
    }

    await prisma.$transaction(async (tx) => {
      await tx.position.update({
        where: { id },
        data: {
          title,
        },
      });

      await tx.auditLog.create({
        data: {
          userId: session.userId,
          action: "UPDATE_POSITION",
          details: `Renamed position "${target.title}" to "${title}" (ID: ${id})`,
        },
      });
    });

    revalidatePath("/dashboard/positions");
    revalidatePath("/dashboard/employees");
    return { success: true };
  } catch (error) {
    console.error("Failed to update position:", error);
    return { error: "Failed to update position." };
  }
}

export async function deletePosition(id: number) {
  try {
    const session = await getSession();
    if (!session || session.role === Role.EMPLOYEE) {
      return { error: "Unauthorized access" };
    }

    const target = await prisma.position.findUnique({
      where: { id },
      include: {
        _count: {
          select: { users: true },
        },
      },
    });

    if (!target) {
      return { error: "Position not found." };
    }

    await prisma.$transaction(async (tx) => {
      await tx.position.delete({
        where: { id },
      });

      await tx.auditLog.create({
        data: {
          userId: session.userId,
          action: "DELETE_POSITION",
          details: `Deleted position "${target.title}" (ID: ${id}, ${target._count.users} user(s) unassigned)`,
        },
      });
    });

    revalidatePath("/dashboard/positions");
    revalidatePath("/dashboard/employees");
    return { success: true };
  } catch (error) {
    console.error("Failed to delete position:", error);
    return { error: "Failed to delete position." };
  }
}
