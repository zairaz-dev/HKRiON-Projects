export interface SiteSettingsData {
  id: string;

  // General
  companyName: string;
  tagline: string;
  establishedYear: string;
  currencySymbol: string;

  // Contact
  phone: string;
  email: string;
  address: string;
  workingHours: string;

  // Social Channels
  instagram: string;
  facebook: string;
  linkedin: string;
  tiktok: string;
  whatsapp: string;
  youtube: string;
  twitter: string;

  // SEO
  metaTitle: string;
  metaDescription: string;

  updatedAt?: Date | string;
}

export const defaultSiteSettings: SiteSettingsData = {
  id: "settings_default",
  companyName: "SHADEIT BLINDS",
  tagline: "Luxury Blinds, Curtains & Outdoor Shade Solutions",
  establishedYear: "2016",
  currencySymbol: "Rs.",

  phone: "+94 75 807 9921",
  email: "info@shadeitblinds.com",
  address: "No.188/29A, Brandiyawatha, Wellampitiya, Colombo",
  workingHours: "Monday – Saturday: 9:00 AM – 8:00 PM",

  instagram: "https://instagram.com/shadeitblinds",
  facebook: "https://www.facebook.com/share/1dsD22Xaae/",
  linkedin: "",
  tiktok: "",
  whatsapp: "+94 75 807 9921",
  youtube: "",
  twitter: "",

  metaTitle: "SHADEIT BLINDS | Luxury Blinds, Curtains & Outdoor Shade Solutions",
  metaDescription:
    "Leading manufacturer & installer of Monsoon Blinds, Zebra Blinds, Roller & Roman Blinds, Luxury Curtains, Pergolas, Awnings, Canopies, and Outdoor UV Clear PVC shades.",
};
