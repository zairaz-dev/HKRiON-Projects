import { NextResponse } from "next/server";
import { getInquiries, createInquiry, updateInquiryStatus } from "@/lib/data/inquiries-db";
import { requireAdmin } from "@/lib/require-admin";
import { sanitizeString } from "@/lib/sanitize";

// GET /api/inquiries — Admin only
export async function GET() {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const inquiries = await getInquiries();
    return NextResponse.json({ inquiries });
  } catch {
    return NextResponse.json({ error: "Failed to fetch inquiries" }, { status: 500 });
  }
}

import { getClientIp } from "@/lib/request-ip";

// Rate limiting store for public consultation inquiries
interface InquiryRecord {
  count: number;
  resetAt: number;
}
const inquiryLimits = new Map<string, InquiryRecord>();
const MAX_INQUIRIES_PER_WINDOW = 10;
const INQUIRY_WINDOW_MS = 15 * 60 * 1000; // 15 minutes

function pruneInquiryLimits(now: number): void {
  if (inquiryLimits.size > 1000) {
    for (const [key, record] of inquiryLimits.entries()) {
      if (record.resetAt <= now) {
        inquiryLimits.delete(key);
      }
    }
  }
}

// POST /api/inquiries — Public (customer inquiry form with rate limit & validation)
export async function POST(request: Request) {
  try {
    const ip = getClientIp(request);
    const now = Date.now();
    pruneInquiryLimits(now);

    let record = inquiryLimits.get(ip);
    if (!record || record.resetAt <= now) {
      record = { count: 0, resetAt: now + INQUIRY_WINDOW_MS };
    }

    if (record.count >= MAX_INQUIRIES_PER_WINDOW) {
      const waitMinutes = Math.ceil((record.resetAt - now) / 60000);
      return NextResponse.json(
        {
          error: `Inquiry rate limit exceeded. Please wait ${waitMinutes} minutes before submitting another consultation request.`,
        },
        { status: 429, headers: { "Retry-After": Math.ceil((record.resetAt - now) / 1000).toString() } }
      );
    }

    const body = await request.json();
    const name = sanitizeString(body.name);
    const email = sanitizeString(body.email).toLowerCase();
    const phone = sanitizeString(body.phone);
    const preferredLocation = sanitizeString(body.preferredLocation || body.preferredSalon);
    const message = sanitizeString(body.message);
    const gemstoneId = sanitizeString(body.gemstoneId);
    const gemstoneName = sanitizeString(body.gemstoneName);

    if (!name || name.length < 2 || name.length > 100) {
      return NextResponse.json(
        { error: "A valid name is required (between 2 and 100 characters)." },
        { status: 400 }
      );
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || email.length > 150 || !emailRegex.test(email)) {
      return NextResponse.json(
        { error: "A valid email address is required (maximum 150 characters)." },
        { status: 400 }
      );
    }

    if (phone && phone.length > 30) {
      return NextResponse.json(
        { error: "Phone number cannot exceed 30 characters." },
        { status: 400 }
      );
    }

    if (message && message.length > 3000) {
      return NextResponse.json(
        { error: "Message cannot exceed 3,000 characters." },
        { status: 400 }
      );
    }

    // Increment rate limit record
    record.count += 1;
    inquiryLimits.set(ip, record);

    const success = await createInquiry({
      name,
      email,
      phone,
      preferredLocation,
      message,
      gemstoneId,
      gemstoneName,
    });

    if (!success) {
      return NextResponse.json({ error: "Failed to persist inquiry" }, { status: 500 });
    }

    return NextResponse.json({ success: true }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Invalid request payload" }, { status: 400 });
  }
}

// PATCH /api/inquiries — Admin only
export async function PATCH(request: Request) {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const body = await request.json();
    const { id, status } = body;

    if (!id || !["new", "scheduled", "resolved"].includes(status)) {
      return NextResponse.json({ error: "Valid ID and status are required" }, { status: 400 });
    }

    const success = await updateInquiryStatus(id, status);

    if (!success) {
      return NextResponse.json({ error: "Failed to update inquiry status" }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Invalid request payload" }, { status: 400 });
  }
}
