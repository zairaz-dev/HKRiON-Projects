import React, { useState, useEffect } from "react";
import { X, Loader2, Trash2, Calendar, CreditCard, Clipboard, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { User } from "@hkr/types";
import { SaleItem } from "@/features/pos/types";
import { useCustomerPaymentsQuery, useDeleteCustomerPaymentMutation } from "../hooks/use-customer-payments";
import { useCurrency } from "@/hooks/use-currency";

interface CustomerPaymentsListDialogProps {
  isOpen: boolean;
  onClose: () => void;
  sale: SaleItem | null;
  customer?: any | null; // Customer item
  currentUser: User;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

export function CustomerPaymentsListDialog({
  isOpen,
  onClose,
  sale,
  customer,
  currentUser,
  onSuccess,
  onError,
}: CustomerPaymentsListDialogProps) {
  const deleteMutation = useDeleteCustomerPaymentMutation();
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setErrorMessage(null);
    }
  }, [isOpen]);

  const businessId = currentUser?.businessId || "";
  const { format } = useCurrency(businessId);

  // Check if customer or sale is for Walk-in Customer / no-credit customer
  const isWalkIn =
    (customer &&
      (customer.isDefault ||
        customer.name?.toLowerCase() === "walk-in customer" ||
        customer.allowCredit === false)) ||
    (sale &&
      ((sale.customer as any)?.isDefault ||
        sale.customer?.name?.toLowerCase() === "walk-in customer" ||
        (sale.customer as any)?.allowCredit === false));

  // Query payments for this specific sale or customer
  const { data: payments = [], isLoading } = useCustomerPaymentsQuery(
    businessId,
    sale
      ? { saleId: sale.id }
      : { customerId: customer?.id || "" }
  );

  if (!isOpen || (!sale && !customer)) return null;

  const handleDelete = async (paymentId: string) => {
    if (!window.confirm("Are you sure you want to delete this payment record? This will increase the remaining due on the invoice.")) {
      return;
    }
    setErrorMessage(null);

    try {
      await deleteMutation.mutateAsync({ id: paymentId, businessId });
      onSuccess("Payment record deleted successfully!");
    } catch (err: any) {
      const msg = err.message || "Failed to delete payment record.";
      setErrorMessage(msg);
      onError(msg);
    }
  };

  const isDeleting = deleteMutation.isPending;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl bg-card border border-border rounded-sm shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between border-b border-border p-5 bg-background/40">
          <div>
            <h2 className="text-lg font-bold text-foreground">
              Payments History
            </h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {sale ? (
                <>
                  Invoice #: <span className="font-mono font-semibold text-foreground">{sale.invoiceNumber}</span>
                </>
              ) : (
                <>
                  Customer: <span className="font-semibold text-foreground">{customer?.name}</span>
                </>
              )}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {errorMessage && (
          <div className="mx-5 my-2 p-3 bg-destructive/15 text-destructive border border-destructive/30 rounded text-xs flex items-center gap-2 animate-in fade-in duration-150">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <div className="p-5 max-h-[60vh] overflow-y-auto space-y-4">
          {isLoading ? (
            <div className="flex h-32 items-center justify-center">
              <div className="text-center space-y-2">
                <Loader2 className="h-6 w-6 animate-spin text-primary mx-auto" />
                <span className="text-xs text-muted-foreground block">Loading payment history...</span>
              </div>
            </div>
          ) : payments.length === 0 ? (
            <div className="text-center py-8 border border-dashed border-border/40 rounded-sm bg-secondary/20">
              <CreditCard className="h-8 w-8 text-muted-foreground/60 mx-auto mb-2" />
              <p className="text-sm font-semibold text-muted-foreground">No payment records found.</p>
              <p className="text-xs text-muted-foreground/60 mt-0.5">No payments have been recorded yet.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {payments.map((payment) => (
                <div
                  key={payment.id}
                  className="flex items-center justify-between p-4 border border-border/60 rounded-sm bg-background/50 hover:bg-background/80 transition-colors"
                >
                  <div className="space-y-1.5 flex-1 pr-4">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-foreground">
                        {payment.paymentNumber}
                      </span>
                      <span className="text-[10px] bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 font-extrabold px-1.5 py-0.5 rounded">
                        {format(payment.amount)}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3.5 w-3.5" />
                        {new Date(payment.paymentDate).toLocaleDateString("en-IN", {
                          day: "2-digit",
                          month: "short",
                          year: "numeric",
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </span>
                      <span className="flex items-center gap-1 uppercase text-[10px] bg-secondary text-secondary-foreground font-bold px-1.5 py-0.5 rounded border border-border/40">
                        Method: {payment.paymentMethod?.name}
                      </span>
                      {payment.transactionNo && (
                        <span className="flex items-center gap-1 font-mono text-[10px]">
                          <Clipboard className="h-3 w-3" /> Ref: {payment.transactionNo}
                        </span>
                      )}
                    </div>

                    {payment.notes && (
                      <p className="text-xs text-muted-foreground/80 italic pl-1 border-l border-border mt-1">
                        Note: {payment.notes}
                      </p>
                    )}
                  </div>

                  {!isWalkIn &&
                    !(
                      payment.customer &&
                      (payment.customer.isDefault ||
                        payment.customer.name?.toLowerCase() === "walk-in customer" ||
                        payment.customer.allowCredit === false)
                    ) && (
                      <button
                        onClick={() => handleDelete(payment.id)}
                        disabled={isDeleting}
                        className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded transition-colors disabled:opacity-50"
                        title="Delete payment record"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex justify-end p-5 border-t border-border bg-background/20">
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </div>
      </div>
    </div>
  );
}
