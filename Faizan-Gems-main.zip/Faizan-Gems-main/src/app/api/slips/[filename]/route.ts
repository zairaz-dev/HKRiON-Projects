import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { readFile, stat } from "fs/promises";
import path from "path";
import pool from "@/lib/db";
import { RowDataPacket } from "mysql2";
import {
  SESSION_COOKIE_NAME,
  CUSTOMER_SESSION_COOKIE_NAME,
  verifySessionToken,
  verifyCustomerSessionToken,
  verifySlipAccessToken,
  verifyOrderAccessToken,
} from "@/lib/auth";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function GET(
  request: Request,
  props: { params: Promise<{ filename: string }> }
) {
  try {
    const { filename } = await props.params;

    // 1. Path Traversal & Filename Sanitization
    const safeFilename = path.basename(filename);
    if (!safeFilename || safeFilename.includes("..") || safeFilename !== filename) {
      return NextResponse.json({ error: "Invalid filename" }, { status: 400 });
    }

    const cookieStore = await cookies();
    const adminToken = cookieStore.get(SESSION_COOKIE_NAME)?.value;
    const customerToken = cookieStore.get(CUSTOMER_SESSION_COOKIE_NAME)?.value;

    let isAuthorized = false;

    // 2. Authorization Check: Admin
    if (adminToken && verifySessionToken(adminToken)) {
      isAuthorized = true;
    }

    // 3. Authorization Check: Direct Slip Access Token (query param or cookie)
    if (!isAuthorized) {
      const url = new URL(request.url);
      const querySlipToken = url.searchParams.get("token");
      const cookieSlipToken = cookieStore.get(`fg_slip_${safeFilename}`)?.value;
      const candidateSlipToken = querySlipToken || cookieSlipToken;

      if (candidateSlipToken && verifySlipAccessToken(safeFilename, candidateSlipToken)) {
        isAuthorized = true;
      }
    }

    // 4. Authorization Check: Customer owning the order or Guest Order Access Token
    if (!isAuthorized) {
      try {
        const [orders] = await pool.query<RowDataPacket[]>(
          "SELECT id, order_number, client_email, client_id, payment_slip, items FROM orders WHERE payment_slip LIKE ? OR items LIKE ? LIMIT 5",
          [`%${safeFilename}%`, `%${safeFilename}%`]
        );

        if (orders && orders.length > 0) {
          const customerSession = customerToken ? verifyCustomerSessionToken(customerToken) : null;

          for (const order of orders) {
            // Check if logged-in customer is the order owner
            if (
              customerSession &&
              ((order.client_id && order.client_id === customerSession.id) ||
                (order.client_email &&
                  order.client_email.toLowerCase() === customerSession.email.toLowerCase()))
            ) {
              isAuthorized = true;
              break;
            }

            // Check if guest order access token is valid
            const orderRef = order.order_number || order.id;
            const cookieOrderToken =
              cookieStore.get(`fg_order_${orderRef}`)?.value ||
              cookieStore.get(`fg_order_${order.id}`)?.value;
            const url = new URL(request.url);
            const queryOrderToken = url.searchParams.get("order_token");
            const candidateOrderToken = queryOrderToken || cookieOrderToken;

            if (
              candidateOrderToken &&
              (verifyOrderAccessToken(orderRef, candidateOrderToken) ||
                verifyOrderAccessToken(order.id, candidateOrderToken))
            ) {
              isAuthorized = true;
              break;
            }
          }
        }
      } catch (dbErr) {
        console.error("Error verifying slip order ownership in DB:", dbErr);
      }
    }

    if (!isAuthorized) {
      return NextResponse.json(
        { error: "Access denied. Payment slips are restricted to authorized personnel and verified order owners." },
        { status: 403 }
      );
    }

    // 5. Resolve file path (check configured dir, private_uploads, then legacy public/uploads)
    const configuredDir = process.env.SLIP_STORAGE_DIR ? path.resolve(process.env.SLIP_STORAGE_DIR) : null;
    const privateDir = path.resolve(process.cwd(), "private_uploads", "slips");
    const legacyDir = path.resolve(process.cwd(), "public", "uploads", "slips");

    const primaryDir = configuredDir || privateDir;
    const privatePath = path.resolve(primaryDir, safeFilename);
    const legacyPath = path.resolve(legacyDir, safeFilename);

    // Verify path confinement against directory traversal
    if (!privatePath.startsWith(primaryDir + path.sep) && !legacyPath.startsWith(legacyDir + path.sep)) {
      return NextResponse.json({ error: "Access denied: Invalid filename" }, { status: 400 });
    }

    let targetPath = privatePath;
    try {
      await stat(privatePath);
    } catch {
      try {
        await stat(legacyPath);
        targetPath = legacyPath;
      } catch {
        return NextResponse.json({ error: "Slip file not found on server." }, { status: 404 });
      }
    }

    const fileBuffer = await readFile(targetPath);
    const ext = path.extname(safeFilename).toLowerCase();
    let contentType = "application/octet-stream";
    if (ext === ".pdf") contentType = "application/pdf";
    else if (ext === ".webp") contentType = "image/webp";
    else if (ext === ".png") contentType = "image/png";
    else if (ext === ".jpg" || ext === ".jpeg") contentType = "image/jpeg";
    else if (ext === ".avif") contentType = "image/avif";
    else if (ext === ".gif") contentType = "image/gif";

    return new NextResponse(fileBuffer, {
      status: 200,
      headers: {
        "Content-Type": contentType,
        "X-Content-Type-Options": "nosniff",
        "Cache-Control": "private, max-age=3600",
        "Content-Disposition": `inline; filename="${safeFilename}"`,
      },
    });
  } catch (error) {
    console.error("Error serving payment slip:", error);
    return NextResponse.json({ error: "Failed to retrieve payment slip." }, { status: 500 });
  }
}
