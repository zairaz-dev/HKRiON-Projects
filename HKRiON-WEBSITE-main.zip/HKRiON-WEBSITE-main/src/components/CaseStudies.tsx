'use client';

import { CheckCircle2, ArrowUpRight, TrendingUp } from 'lucide-react';

const caseStudies = [
  {
    client: 'Lanka Super Retail Chain',
    category: 'Retail POS & Inventory',
    problem: 'Manual billing caused long queues, inventory discrepancy, and delayed daily sales reporting across 12 branch outlets.',
    solution: 'Implemented HKRION POS & Multi-Warehouse Inventory with real-time barcode scanning and cloud database sync.',
    results: [
      '60% Faster Checkout & Billing Speed',
      '100% Real-Time Inventory Visibility',
      'Automated Daily Profit & Expense Reports'
    ],
    metric: '+65% Efficiency'
  },
  {
    client: 'Ceylon Logistics & Freight',
    category: 'IoT Fleet Telemetry',
    problem: 'Lack of real-time temperature and location monitoring for cold-chain delivery trucks leading to perishable goods loss.',
    solution: 'Deployed custom HKRION IoT Telemetry Sensors + Real-time Web & Mobile Dashboard with automated temperature alert triggers.',
    results: [
      'Zero Cargo Spoilage Incidents',
      'GPS Tracking with Geofence Alerts',
      '24/7 Remote Temperature Graphing'
    ],
    metric: '99.9% Reliability'
  },
  {
    client: 'Apex Apparel Manufacturing',
    category: 'Enterprise HRM & Payroll',
    problem: 'Complex shift rotation and manual paper-based attendance tracking for over 800 factory employees.',
    solution: 'Installed HKRION Biometric Attendance integrated with HKRION HRM for automated OT, shift allowance, and bank payroll generation.',
    results: [
      'Reduced Payroll Processing Time from 5 Days to 2 Hours',
      'Eliminated Buddy Punching with Biometric Sync',
      'Self-Service Mobile Leave App for Staff'
    ],
    metric: '85% Time Saved'
  }
];

export default function CaseStudies() {
  return (
    <section id="casestudies" className="py-24 bg-black relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <h2 className="text-xs font-semibold uppercase tracking-widest text-[#1ABE56] font-mono">
            CASE STUDIES & PROVEN RESULTS
          </h2>
          <p className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            Real Stories of <span className="gradient-text">Digital Transformation</span>
          </p>
          <p className="text-neutral-400 text-base sm:text-lg">
            See how HKRION software solutions solve real-world operational challenges and drive measurable growth.
          </p>
        </div>

        {/* Case Studies Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {caseStudies.map((cs, idx) => (
            <div
              key={idx}
              className="glass-card p-8 rounded-3xl border border-[#1ABE56]/30 bg-black/90 hover:border-[#1ABE56] transition-all group flex flex-col justify-between"
            >
              <div>
                {/* Header Badge */}
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs font-mono font-semibold px-3 py-1 rounded-full bg-[#1ABE56]/20 text-[#1ABE56] border border-[#1ABE56]/30">
                    {cs.category}
                  </span>
                  <span className="text-xs font-mono font-bold text-[#1ABE56] flex items-center gap-1">
                    <TrendingUp className="w-3.5 h-3.5" />
                    {cs.metric}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-white mb-4 group-hover:text-[#1ABE56] transition-colors">
                  {cs.client}
                </h3>

                {/* Problem & Solution */}
                <div className="space-y-3 mb-6 text-xs leading-relaxed">
                  <div className="p-3 rounded-xl bg-neutral-900/80 border border-white/5">
                    <span className="font-bold text-red-400 block mb-1">Challenge:</span>
                    <span className="text-neutral-300">{cs.problem}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-neutral-900/80 border border-[#1ABE56]/20">
                    <span className="font-bold text-[#1ABE56] block mb-1">HKRION Solution:</span>
                    <span className="text-neutral-300">{cs.solution}</span>
                  </div>
                </div>

                {/* Results Bullet Points */}
                <div className="space-y-2 mb-6">
                  <span className="text-xs font-bold text-white uppercase tracking-wider block font-mono">
                    Key Outcomes:
                  </span>
                  {cs.results.map((res, rIdx) => (
                    <div key={rIdx} className="flex items-center gap-2 text-xs text-neutral-200">
                      <CheckCircle2 className="w-4 h-4 text-[#1ABE56] shrink-0" />
                      <span>{res}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action */}
              <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs text-[#1ABE56] font-semibold group-hover:translate-x-1 transition-transform">
                <span>View Full Case Study</span>
                <ArrowUpRight className="w-4 h-4" />
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
