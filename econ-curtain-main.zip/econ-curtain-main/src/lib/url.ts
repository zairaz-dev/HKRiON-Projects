import { NextResponse } from "next/server";

/**
 * Returns a safe, routeable origin (never 0.0.0.0 which breaks browser redirects).
 * Accurately extracts the user's actual host (localhost:3001 or 192.168.1.10:3001).
 */
export function getSafeOrigin(request: Request): string {
  // 1. Try Referer header (highest accuracy of where user actually is)
  const referer = request.headers.get("referer");
  if (referer) {
    try {
      const refUrl = new URL(referer);
      if (!refUrl.hostname.includes("0.0.0.0")) {
        return refUrl.origin;
      }
    } catch {}
  }

  // 2. Try Host headers
  const host =
    request.headers.get("x-forwarded-host") ||
    request.headers.get("host") ||
    "localhost:3001";
  const proto = request.headers.get("x-forwarded-proto") || "http";

  const cleanHost = host.includes("0.0.0.0") ? "localhost:3001" : host;
  return `${proto}://${cleanHost}`;
}

export function safeRedirect(path: string, request: Request, status: number = 303): NextResponse {
  const origin = getSafeOrigin(request);
  const cleanPath = path.startsWith("/") ? path : `/${path}`;
  return NextResponse.redirect(`${origin}${cleanPath}`, status);
}
