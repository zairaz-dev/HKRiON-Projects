'use client';

import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    quote: "HKRION ERP & POS transformed our entire retail operations across Sri Lanka. The billing speed and real-time inventory synchronization are phenomenal.",
    author: "Kamal Perera",
    title: "Managing Director",
    company: "Lanka Super Retail",
    stars: 5,
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=200&h=200&q=80"
  },
  {
    quote: "Working with HKRION for our IoT telemetry mobile application was seamless. Their engineering standards, security, and continuous support are world-class.",
    author: "Mohamed Rilwan",
    title: "Chief Operating Officer",
    company: "Ceylon Logistics Group",
    stars: 5,
    image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=200&h=200&q=80"
  },
  {
    quote: "Their custom HRM software cut our monthly payroll calculation time from days to just two hours! Highly recommended for any growing enterprise.",
    author: "Sanjaya Bandara",
    title: "Head of HR",
    company: "Apex Apparel Manufacturing",
    stars: 5,
    image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=200&h=200&q=80"
  }
];

export default function Testimonials() {
  return (
    <section className="py-24 bg-neutral-950 relative overflow-hidden border-y border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <h2 className="text-xs font-semibold uppercase tracking-widest text-[#1ABE56] font-mono">
            CLIENT TESTIMONIALS
          </h2>
          <p className="text-3xl sm:text-5xl font-semibold text-white tracking-tight">
            Loved by <span className="gradient-text">Business Leaders</span>
          </p>
          <p className="text-neutral-400 text-base sm:text-lg">
            Hear directly from CEOs, directors, and operations managers who rely on HKRION solutions every day.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, idx) => (
            <div
              key={idx}
              className="glass-card p-8 rounded-3xl border border-[#1ABE56]/30 bg-black/90 hover:border-[#1ABE56] transition-all group flex flex-col justify-between"
            >
              <div>
                {/* Stars & Quote Icon */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-1">
                    {[...Array(t.stars)].map((_, sIdx) => (
                      <Star key={sIdx} className="w-4 h-4 text-[#1ABE56] fill-[#1ABE56]" />
                    ))}
                  </div>
                  <Quote className="w-6 h-6 text-[#1ABE56]/40" />
                </div>

                <p className="text-neutral-300 text-sm leading-relaxed italic mb-8">
                  &ldquo;{t.quote}&rdquo;
                </p>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center gap-3">
                <img
                  src={t.image}
                  alt={t.author}
                  className="w-11 h-11 rounded-full object-cover border-2 border-[#1ABE56]/50 group-hover:border-[#1ABE56] transition-colors shadow-md shrink-0"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.onerror = null;
                    target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(t.author)}&background=1ABE56&color=000`;
                  }}
                />
                <div>
                  <h4 className="text-sm font-bold text-white group-hover:text-[#1ABE56] transition-colors">{t.author}</h4>
                  <p className="text-xs text-neutral-400 font-mono">{t.title}, {t.company}</p>
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
