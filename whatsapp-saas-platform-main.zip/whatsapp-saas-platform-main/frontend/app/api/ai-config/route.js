import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

const CONFIG_FILE = path.join(process.cwd(), 'data', 'ai_config.json');

const DEFAULT_CONFIG = {
  apiKey: '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',
  model: 'meta-llama/llama-3.3-70b-instruct',
  systemPrompt: `You are an AI customer support assistant for our business.
Respond to customer queries friendly and concisely (1-3 sentences max).

Available Services:
- Business websites
- Web applications
- Mobile applications
- POS systems

STRICT RULES:
1. Only answer questions using the company details provided above.
2. Do not invent company names or services not listed here.
3. If asked about unsupported services, politely inform the user.`,
  enabled: true,
  // Voice AI Configuration
  voiceEnabled: true,
  voiceReplyMode: 'match_incoming', // 'match_incoming' | 'always_voice' | 'always_text'
  sttProvider: 'openrouter_gemini', // 'openrouter_gemini' (uses existing key) | 'gemini_studio' | 'groq' | 'openai'
  ttsProvider: 'free_google', // 'free_google' (100% free) | 'openai'
  ttsVoice: 'nova',
  geminiApiKey: '', // Google AI Studio free key
  groqApiKey: process.env.GROQ_API_KEY || '',
  openAiApiKey: process.env.OPENAI_API_KEY || '',
};

function ensureDir() {
  const dir = path.dirname(CONFIG_FILE);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

export async function GET() {
  try {
    ensureDir();
    if (fs.existsSync(CONFIG_FILE)) {
      const data = fs.readFileSync(CONFIG_FILE, 'utf-8');
      return NextResponse.json({ ...DEFAULT_CONFIG, ...JSON.parse(data) });
    }
    return NextResponse.json(DEFAULT_CONFIG);
  } catch (error) {
    return NextResponse.json(DEFAULT_CONFIG);
  }
}

export async function POST(req) {
  try {
    const body = await req.json();
    ensureDir();
    
    let currentConfig = DEFAULT_CONFIG;
    if (fs.existsSync(CONFIG_FILE)) {
      try {
        currentConfig = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8'));
      } catch (e) {}
    }

    const updatedConfig = { ...currentConfig, ...body };
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(updatedConfig, null, 2), 'utf-8');
    return NextResponse.json({ success: true, config: updatedConfig });
  } catch (error) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
