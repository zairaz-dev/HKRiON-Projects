import { SRI_LANKA_DISTRICTS } from "@/lib/data/districts";

export interface AddressFieldSpec {
  label: string;
  placeholder: string;
  required: boolean;
  type?: "text" | "select";
  options?: string[];
  helpText?: string;
}

export interface AddressFormatConfig {
  countryCode: string;
  countryName: string;
  hasPostalCode: boolean;
  fields: {
    addressLine1: AddressFieldSpec;
    addressLine2?: AddressFieldSpec;
    city: AddressFieldSpec;
    state: AddressFieldSpec;
    postalCode?: AddressFieldSpec;
  };
}

export const US_STATES: string[] = [
  "Alabama",
  "Alaska",
  "Arizona",
  "Arkansas",
  "California",
  "Colorado",
  "Connecticut",
  "Delaware",
  "Florida",
  "Georgia",
  "Hawaii",
  "Idaho",
  "Illinois",
  "Indiana",
  "Iowa",
  "Kansas",
  "Kentucky",
  "Louisiana",
  "Maine",
  "Maryland",
  "Massachusetts",
  "Michigan",
  "Minnesota",
  "Mississippi",
  "Missouri",
  "Montana",
  "Nebraska",
  "Nevada",
  "New Hampshire",
  "New Jersey",
  "New Mexico",
  "New York",
  "North Carolina",
  "North Dakota",
  "Ohio",
  "Oklahoma",
  "Oregon",
  "Pennsylvania",
  "Rhode Island",
  "South Carolina",
  "South Dakota",
  "Tennessee",
  "Texas",
  "Utah",
  "Vermont",
  "Virginia",
  "Washington",
  "West Virginia",
  "Wisconsin",
  "Wyoming",
  "District of Columbia",
];

export const UAE_EMIRATES: string[] = [
  "Abu Dhabi",
  "Dubai",
  "Sharjah",
  "Ajman",
  "Umm Al Quwain",
  "Ras Al Khaimah",
  "Fujairah",
];

export const JAPAN_PREFECTURES: string[] = [
  "Aichi",
  "Akita",
  "Aomori",
  "Chiba",
  "Ehime",
  "Fukui",
  "Fukuoka",
  "Fukushima",
  "Gifu",
  "Gunma",
  "Hiroshima",
  "Hokkaido",
  "Hyogo",
  "Ibaraki",
  "Ishikawa",
  "Iwate",
  "Kagawa",
  "Kagoshima",
  "Kanagawa",
  "Kochi",
  "Kumamoto",
  "Kyoto",
  "Mie",
  "Miyagi",
  "Miyazaki",
  "Nagano",
  "Nagasaki",
  "Nara",
  "Niigata",
  "Oita",
  "Okayama",
  "Okinawa",
  "Osaka",
  "Saga",
  "Saitama",
  "Shiga",
  "Shimane",
  "Shizuoka",
  "Tochigi",
  "Tokushima",
  "Tokyo",
  "Tottori",
  "Toyama",
  "Wakayama",
  "Yamagata",
  "Yamaguchi",
  "Yamanashi",
];

export const CANADIAN_PROVINCES: string[] = [
  "Alberta",
  "British Columbia",
  "Manitoba",
  "New Brunswick",
  "Newfoundland and Labrador",
  "Northwest Territories",
  "Nova Scotia",
  "Nunavut",
  "Ontario",
  "Prince Edward Island",
  "Quebec",
  "Saskatchewan",
  "Yukon",
];

export const AUSTRALIAN_STATES: string[] = [
  "Australian Capital Territory",
  "New South Wales",
  "Northern Territory",
  "Queensland",
  "South Australia",
  "Tasmania",
  "Victoria",
  "Western Australia",
];

/**
 * Countries that do not utilize postal codes for physical delivery.
 */
export const COUNTRIES_WITHOUT_POSTAL_CODES: readonly string[] = [
  "AE",
  "UNITED ARAB EMIRATES",
  "UAE",
  "QA",
  "QATAR",
  "OM",
  "OMAN",
];

/**
 * Check whether a given country requires a postal / ZIP code.
 */
export function requiresPostalCode(countryCodeOrName?: string | null): boolean {
  if (!countryCodeOrName) return true;
  const normalized = countryCodeOrName.trim().toUpperCase();
  return !COUNTRIES_WITHOUT_POSTAL_CODES.some(
    (c) => c === normalized || normalized.includes(c)
  );
}

/**
 * Normalize country identifier for lookup
 */
export function normalizeCountryKey(country?: string | null): string {
  if (!country) return "US";
  const val = country.trim().toUpperCase();
  if (val === "US" || val === "USA" || val.includes("UNITED STATES")) return "US";
  if (val === "GB" || val === "UK" || val.includes("UNITED KINGDOM") || val === "GREAT BRITAIN") return "GB";
  if (val === "JP" || val.includes("JAPAN") || val === "JPN") return "JP";
  if (val === "AE" || val === "UAE" || val.includes("UNITED ARAB EMIRATES")) return "AE";
  if (val === "LK" || val.includes("SRI LANKA") || val === "CEYLON") return "LK";
  if (val === "CA" || val.includes("CANADA")) return "CA";
  if (val === "AU" || val.includes("AUSTRALIA")) return "AU";
  return val;
}

/**
 * Return dynamic address form specifications and validation constraints for any destination country.
 */
export function getAddressFormat(countryCodeOrName?: string | null): AddressFormatConfig {
  const key = normalizeCountryKey(countryCodeOrName);

  switch (key) {
    case "US":
      return {
        countryCode: "US",
        countryName: "United States",
        hasPostalCode: true,
        fields: {
          addressLine1: {
            label: "Address Line 1",
            placeholder: "Street address, P.O. box, company name",
            required: true,
          },
          addressLine2: {
            label: "Address Line 2 (Optional)",
            placeholder: "Apartment, suite, unit, building, floor, etc.",
            required: false,
          },
          city: {
            label: "City",
            placeholder: "e.g. New York, Beverly Hills, Chicago",
            required: true,
          },
          state: {
            label: "State",
            placeholder: "Select State",
            required: true,
            type: "select",
            options: US_STATES,
          },
          postalCode: {
            label: "ZIP Code",
            placeholder: "e.g. 10001 or 90210",
            required: true,
          },
        },
      };

    case "GB":
      return {
        countryCode: "GB",
        countryName: "United Kingdom",
        hasPostalCode: true,
        fields: {
          addressLine1: {
            label: "Address Line 1",
            placeholder: "Street address, house number or property name",
            required: true,
          },
          addressLine2: {
            label: "Address Line 2 (Optional)",
            placeholder: "Flat, suite, unit, etc.",
            required: false,
          },
          city: {
            label: "Town / City",
            placeholder: "e.g. London, Manchester, Edinburgh",
            required: true,
          },
          state: {
            label: "County (Optional)",
            placeholder: "e.g. Greater London, West Midlands, Yorkshire",
            required: false,
            type: "text",
          },
          postalCode: {
            label: "Postcode",
            placeholder: "e.g. SW1A 1AA, EC1A 1BB, W1J 7NT",
            required: true,
          },
        },
      };

    case "JP":
      return {
        countryCode: "JP",
        countryName: "Japan",
        hasPostalCode: true,
        fields: {
          state: {
            label: "Prefecture",
            placeholder: "Select Prefecture",
            required: true,
            type: "select",
            options: JAPAN_PREFECTURES,
          },
          city: {
            label: "City / Ward / Town / Village",
            placeholder: "e.g. Shibuya-ku, Minato-ku, Chiyoda-ku",
            required: true,
          },
          addressLine1: {
            label: "Block / Building",
            placeholder: "e.g. 1-1-1, Roppongi Hills Mori Tower 15F",
            required: true,
          },
          postalCode: {
            label: "Postal Code",
            placeholder: "e.g. 100-0001, 150-0002",
            required: true,
          },
        },
      };

    case "AE":
      return {
        countryCode: "AE",
        countryName: "United Arab Emirates",
        hasPostalCode: false,
        fields: {
          addressLine1: {
            label: "Address (Villa / Building)",
            placeholder: "e.g. Villa 12, Street 4B, Al Barsha or Burj Crown Apt 1402",
            required: true,
          },
          city: {
            label: "City",
            placeholder: "e.g. Dubai, Abu Dhabi, Sharjah, Al Ain",
            required: true,
          },
          state: {
            label: "Emirate",
            placeholder: "Select Emirate",
            required: true,
            type: "select",
            options: UAE_EMIRATES,
          },
          addressLine2: {
            label: "Landmark (Optional)",
            placeholder: "e.g. Near Mall of the Emirates, Behind Spinneys",
            required: false,
          },
        },
      };

    case "CA":
      return {
        countryCode: "CA",
        countryName: "Canada",
        hasPostalCode: true,
        fields: {
          addressLine1: {
            label: "Address Line 1",
            placeholder: "Street address, P.O. box",
            required: true,
          },
          addressLine2: {
            label: "Address Line 2 (Optional)",
            placeholder: "Apartment, suite, unit, etc.",
            required: false,
          },
          city: {
            label: "City",
            placeholder: "e.g. Toronto, Vancouver, Montreal",
            required: true,
          },
          state: {
            label: "Province / Territory",
            placeholder: "Select Province",
            required: true,
            type: "select",
            options: CANADIAN_PROVINCES,
          },
          postalCode: {
            label: "Postal Code",
            placeholder: "e.g. M5V 2T6, H3B 1A7",
            required: true,
          },
        },
      };

    case "AU":
      return {
        countryCode: "AU",
        countryName: "Australia",
        hasPostalCode: true,
        fields: {
          addressLine1: {
            label: "Address Line 1",
            placeholder: "Street address, P.O. box",
            required: true,
          },
          addressLine2: {
            label: "Address Line 2 (Optional)",
            placeholder: "Apartment, suite, unit, etc.",
            required: false,
          },
          city: {
            label: "Suburb / City",
            placeholder: "e.g. Sydney, Melbourne, Brisbane",
            required: true,
          },
          state: {
            label: "State / Territory",
            placeholder: "Select State",
            required: true,
            type: "select",
            options: AUSTRALIAN_STATES,
          },
          postalCode: {
            label: "Postcode",
            placeholder: "e.g. 2000, 3000, 4000",
            required: true,
          },
        },
      };

    case "LK":
      return {
        countryCode: "LK",
        countryName: "Sri Lanka",
        hasPostalCode: true,
        fields: {
          addressLine1: {
            label: "Address Line 1",
            placeholder: "Street address, house number or premises",
            required: true,
          },
          addressLine2: {
            label: "Address Line 2 (Optional)",
            placeholder: "Apartment, suite, unit (optional)",
            required: false,
          },
          city: {
            label: "City / Town",
            placeholder: "e.g. Colombo 03, Kandy, Galle",
            required: true,
          },
          state: {
            label: "District",
            placeholder: "Select District",
            required: true,
            type: "select",
            options: SRI_LANKA_DISTRICTS,
          },
          postalCode: {
            label: "Postal Code",
            placeholder: "e.g. 00300, 20000",
            required: true,
          },
        },
      };

    default: {
      const needsPostal = requiresPostalCode(countryCodeOrName);
      return {
        countryCode: key,
        countryName: countryCodeOrName?.trim() || "Worldwide",
        hasPostalCode: needsPostal,
        fields: {
          addressLine1: {
            label: "Address Line 1",
            placeholder: "Street address, P.O. box, company name",
            required: true,
          },
          addressLine2: {
            label: "Address Line 2 (Optional)",
            placeholder: "Apartment, suite, unit, floor (optional)",
            required: false,
          },
          city: {
            label: "City / Town",
            placeholder: "e.g. Zurich, Singapore, Frankfurt, Paris",
            required: true,
          },
          state: {
            label: "State / Province / Region",
            placeholder: "e.g. Canton, Region, State (optional)",
            required: false,
            type: "text",
          },
          ...(needsPostal
            ? {
                postalCode: {
                  label: "Postal / ZIP Code",
                  placeholder: "e.g. 8001, 049318, 75001",
                  required: true,
                },
              }
            : {}),
        },
      };
    }
  }
}

/**
 * Format address lines cleanly into a single deliverable street string.
 */
export function formatFullStreetAddress(line1?: string | null, line2?: string | null): string {
  const parts = [line1?.trim(), line2?.trim()].filter(Boolean);
  return parts.join(", ");
}
