"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { Gemstone } from "@/types/gemstone";
import { useWishlist } from "@/features/wishlist/context/WishlistContext";
import { useAuth } from "@/features/auth/context/AuthContext";
import { GemstoneCard } from "@/features/gemstones/components/GemstoneCard";
import {
  HeartIcon,
  SecurityLockIcon,
  CertificateShieldIcon,
  ArmoredTruckIcon,
  AwardIcon
} from "@/components/ui/LuxuryIcons";

export default function WishlistPage() {
  const { wishlist } = useWishlist();
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const [allGems, setAllGems] = useState<Gemstone[]>([]);

  useEffect(() => {
    fetch("/api/gemstones")
      .then((res) => {
        if (!res.ok) throw new Error("Failed to load catalog");
        return res.json();
      })
      .then((data) => {
        if (Array.isArray(data)) {
          setAllGems(data);
        } else if (data && Array.isArray(data.gemstones)) {
          setAllGems(data.gemstones);
        }
      })
      .catch(() => {});
  }, []);

  const savedGems = allGems.filter((g) => wishlist.includes(g.id));

  return (
    <div className="bg-[#FAF8F5] min-h-screen py-12 lg:py-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Page Header */}
        <div className="border-b border-[#E8E4DC] pb-6 mb-8 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <span className="text-[11px] font-sans tracking-wide-luxury uppercase text-[#9A7B4F] block mb-1">
              Private Patron Curation
            </span>
            <h1 className="font-serif text-3xl sm:text-4xl text-[#18181D]">
              Saved Vault Specimens
            </h1>
            <p className="text-xs text-[#8C867D] font-sans mt-1">
              {savedGems.length} {savedGems.length === 1 ? "Specimen" : "Specimens"} bookmarked in your private collection
            </p>
          </div>

          <Link
            href="/shop"
            className="text-xs uppercase tracking-wider font-sans text-[#18181D] hover:text-[#9A7B4F] transition-colors inline-flex items-center gap-1.5"
          >
            <span>Explore Entire Catalog</span>
            <span>&rarr;</span>
          </Link>
        </div>

        {/* Sync Status Banner */}
        {!authLoading && !isAuthenticated && savedGems.length > 0 && (
          <div className="mb-8 p-4 bg-[#FAF8F5] border border-[#C5A880]/40 rounded-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm">
            <div className="flex items-center gap-2.5 text-xs text-[#554F47] font-sans">
              <SecurityLockIcon className="w-4 h-4 text-[#C5A880] shrink-0" />
              <span>
                These specimens are saved in your current browser. Sign in or register to preserve them permanently across all devices.
              </span>
            </div>
            <Link
              href="/login?from=/wishlist"
              className="shrink-0 px-4 py-2 bg-[#18181D] hover:bg-[#2A2A32] text-white text-[11px] uppercase tracking-wider font-sans text-center transition-colors shadow-sm"
            >
              Sign In to Sync &rarr;
            </Link>
          </div>
        )}

        {!authLoading && isAuthenticated && savedGems.length > 0 && (
          <div className="mb-8 p-3.5 bg-emerald-50/70 border border-emerald-200 text-xs font-sans text-emerald-900 rounded-sm flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-600 shrink-0" />
            <span>
              Synchronized with your Patron Vault ({user?.email || user?.name || "Verified Member"}).
            </span>
          </div>
        )}

        {/* Wishlist Content */}
        {savedGems.length === 0 ? (
          <div className="bg-white border border-[#E8E4DC] p-12 sm:p-16 text-center shadow-sm max-w-2xl mx-auto">
            <div className="w-16 h-16 rounded-full bg-[#FAF8F5] border border-[#E8E4DC] mx-auto flex items-center justify-center text-[#8C867D] mb-4">
              <HeartIcon className="w-8 h-8 text-[#C5A880]" />
            </div>
            <h2 className="font-serif text-2xl text-[#18181D]">Your Saved Vault is Empty</h2>
            <p className="mt-2 text-xs sm:text-sm text-[#6B655C] font-sans max-w-md mx-auto leading-relaxed">
              Bookmark rare unheated Ceylon sapphires, Colombian emeralds, and Burmese rubies by tapping the heart icon anywhere in our catalog.
            </p>
            <Link
              href="/shop"
              className="inline-block mt-6 px-7 py-3 bg-[#18181D] hover:bg-[#2A2A32] text-white text-xs uppercase tracking-luxury font-sans font-medium transition-all shadow-md active:scale-[0.99]"
            >
              Explore Certified Gemstones &rarr;
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:gap-6 lg:grid-cols-3">
            {savedGems.map((gem) => (
              <GemstoneCard key={gem.id} gemstone={gem} />
            ))}
          </div>
        )}

        {/* Assurance Footer */}
        <div className="mt-16 pt-8 border-t border-[#E8E4DC] grid grid-cols-1 sm:grid-cols-3 gap-6 text-center text-xs font-sans text-[#6B655C]">
          <div className="flex flex-col items-center gap-2">
            <ArmoredTruckIcon className="w-5 h-5 text-[#C5A880]" />
            <span className="font-medium text-[#18181D] uppercase text-[11px] tracking-wider">
              Armored Air Transit
            </span>
            <p className="text-[11px] text-[#8C867D]">
              Fully insured handover via Ferrari Logistics & Malca-Amit.
            </p>
          </div>

          <div className="flex flex-col items-center gap-2">
            <CertificateShieldIcon className="w-5 h-5 text-[#C5A880]" />
            <span className="font-medium text-[#18181D] uppercase text-[11px] tracking-wider">
              World-Leading Lab Dossiers
            </span>
            <p className="text-[11px] text-[#8C867D]">
              Certified by GIA, Gübelin, SSEF, or GRS laboratories.
            </p>
          </div>

          <div className="flex flex-col items-center gap-2">
            <AwardIcon className="w-5 h-5 text-[#C5A880]" />
            <span className="font-medium text-[#18181D] uppercase text-[11px] tracking-wider">
              Master Lapidary Sourcing
            </span>
            <p className="text-[11px] text-[#8C867D]">
              Natural, untreated specimens directly sourced and certified.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
