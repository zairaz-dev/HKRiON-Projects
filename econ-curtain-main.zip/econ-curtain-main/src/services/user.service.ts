import { db } from "@/core/db/client";
import { PasswordSecurity } from "@/core/auth/password";
import { SessionManager } from "@/core/auth/session";

export interface AuthResult {
  success: boolean;
  token?: string;
  error?: string;
  user?: {
    id: string;
    name: string;
    email: string;
    role: string;
  };
}

export class UserService {
  /**
   * Validates credentials, updates last login, and returns a session token
   */
  static async authenticate(emailInput: string, passwordInput: string): Promise<AuthResult> {
    const email = emailInput?.trim().toLowerCase();
    const password = passwordInput;

    if (!email || !password) {
      return { success: false, error: "Please enter both email and password." };
    }

    const user = await db.user.findUnique({
      where: { email },
    });

    if (!user) {
      return { success: false, error: "Invalid email or password." };
    }

    const isMatch = await PasswordSecurity.compare(password, user.passwordHash);
    if (!isMatch) {
      return { success: false, error: "Invalid email or password." };
    }

    // Update last login
    await db.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    const token = await SessionManager.createToken({
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
    });

    return {
      success: true,
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    };
  }

  static async getAll() {
    return db.user.findMany({
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        lastLoginAt: true,
        createdAt: true,
      },
      orderBy: { createdAt: "asc" },
    });
  }

  static async create(data: { name: string; email: string; password: string; role?: string }) {
    const passwordHash = await PasswordSecurity.hash(data.password);
    return db.user.create({
      data: {
        name: data.name,
        email: data.email.trim().toLowerCase(),
        passwordHash,
        role: data.role || "ADMIN",
      },
    });
  }

  static async changePassword(userId: string, currentPassword: string, newPassword: string): Promise<{ success: boolean; error?: string }> {
    if (!currentPassword || !newPassword) {
      return { success: false, error: "Please provide both current and new password." };
    }

    if (newPassword.length < 6) {
      return { success: false, error: "New password must be at least 6 characters long." };
    }

    const user = await db.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      return { success: false, error: "User not found." };
    }

    const isMatch = await PasswordSecurity.compare(currentPassword, user.passwordHash);
    if (!isMatch) {
      return { success: false, error: "Current password is incorrect." };
    }

    const newPasswordHash = await PasswordSecurity.hash(newPassword);
    await db.user.update({
      where: { id: userId },
      data: { passwordHash: newPasswordHash },
    });

    return { success: true };
  }

  static async resetPassword(emailInput: string, newPassword: string): Promise<{ success: boolean; error?: string }> {
    const email = emailInput?.trim().toLowerCase();
    if (!email || !newPassword) {
      return { success: false, error: "Please provide both email and new password." };
    }

    if (newPassword.length < 6) {
      return { success: false, error: "New password must be at least 6 characters long." };
    }

    const user = await db.user.findUnique({
      where: { email },
    });

    if (!user) {
      return { success: false, error: "No account found with this email address." };
    }

    const newPasswordHash = await PasswordSecurity.hash(newPassword);
    await db.user.update({
      where: { id: user.id },
      data: { passwordHash: newPasswordHash },
    });

    return { success: true };
  }

  static async getById(id: string) {
    return db.user.findUnique({
      where: { id },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        lastLoginAt: true,
        createdAt: true,
      },
    });
  }

  static async update(
    id: string,
    data: { name?: string; email?: string; role?: string; password?: string }
  ) {
    const updateData: { name?: string; email?: string; role?: string; passwordHash?: string } = {};

    if (data.name !== undefined) {
      updateData.name = data.name.trim();
    }
    if (data.email !== undefined) {
      updateData.email = data.email.trim().toLowerCase();
    }
    if (data.role !== undefined) {
      updateData.role = data.role;
    }
    if (data.password && data.password.trim().length >= 6) {
      updateData.passwordHash = await PasswordSecurity.hash(data.password.trim());
    }

    return db.user.update({
      where: { id },
      data: updateData,
    });
  }

  static async updatePassword(userId: string, newPassword: string): Promise<{ success: boolean; error?: string }> {
    if (!newPassword || newPassword.length < 6) {
      return { success: false, error: "Password must be at least 6 characters long." };
    }

    const user = await db.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      return { success: false, error: "User not found." };
    }

    const passwordHash = await PasswordSecurity.hash(newPassword);
    await db.user.update({
      where: { id: userId },
      data: { passwordHash },
    });

    return { success: true };
  }

  static async countAdmins(): Promise<number> {
    return db.user.count({
      where: { role: "ADMIN" },
    });
  }

  static async delete(id: string) {
    return db.user.delete({
      where: { id },
    });
  }
}

