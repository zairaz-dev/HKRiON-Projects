import React, { useState, useEffect, useRef } from "react";
import { Search, Package, Plus } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn, getFullAssetUrl } from "@/lib/utils";
import { ProductDialog } from "@/features/products";
import { useCurrency } from "@/hooks/use-currency";
import { usePermissions } from "@/hooks/use-permissions";

import { Dialog } from "@/components/ui/dialog";
import { imeiService, ProductImeiItem } from "@/services/imei-service";
import { Barcode, Smartphone, Loader2, Check } from "lucide-react";

interface POSProductGridProps {
  products: any[];
  isLoading: boolean;
  branchId: string;
  onAddToCart: (variant: any, imeiNumber?: string) => void;
  businessId: string;
  userId: string;
}

export function POSProductGrid({
  products,
  isLoading,
  branchId,
  onAddToCart,
  businessId,
  userId,
}: POSProductGridProps) {
  const { hasPermission } = usePermissions();
  const { symbol, format } = useCurrency(businessId);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [isProductCreateOpen, setIsProductCreateOpen] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // IMEI Selection Modal States
  const [imeiSelectVariant, setImeiSelectVariant] = useState<any | null>(null);
  const [availableImeis, setAvailableImeis] = useState<ProductImeiItem[]>([]);
  const [isLoadingImeis, setIsLoadingImeis] = useState(false);
  const [imeiFilterQuery, setImeiFilterQuery] = useState("");

  // IMEI Directory Modal State
  const [isImeiDirectoryOpen, setIsImeiDirectoryOpen] = useState(false);
  const [directoryImeis, setDirectoryImeis] = useState<ProductImeiItem[]>([]);
  const [isLoadingDirectory, setIsLoadingDirectory] = useState(false);
  const [directorySearchQuery, setDirectorySearchQuery] = useState("");

  const fetchBranchImeis = async (search?: string) => {
    setIsLoadingDirectory(true);
    try {
      const res = await imeiService.getImeis({
        businessId,
        branchId: branchId && branchId !== "all" ? branchId : undefined,
        status: "IN_STOCK",
        search: search || undefined,
        limit: 100,
      });
      setDirectoryImeis(res.items || []);
    } catch {
      setDirectoryImeis([]);
    } finally {
      setIsLoadingDirectory(false);
    }
  };

  // Extract unique categories (only for active, sellable products)
  const categories = React.useMemo(() => {
    const catsMap = new Map();
    products.forEach((p) => {
      if (p.isActive === false || p.notForSelling) return;
      if (p.category) {
        catsMap.set(p.category.id, p.category.name);
      }
    });
    return Array.from(catsMap.entries()).map(([id, name]) => ({ id, name }));
  }, [products]);

  // Focus search input on mount
  useEffect(() => {
    if (searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, []);

  // Compute stock for a variant
  const getStock = (variant: any) => {
    if (!variant.purchaseLines) return 0;
    return variant.purchaseLines
      .filter((line: any) => !branchId || line.branchId === branchId)
      .reduce((sum: number, line: any) => sum + (line.quantityRemaining || 0), 0);
  };

  // Filter products/variants list (only active and sellable)
  const filteredVariants = React.useMemo(() => {
    const list: any[] = [];
    products.forEach((prod) => {
      // Exclude inactive and not-for-selling products
      if (prod.isActive === false || prod.notForSelling) {
        return;
      }

      // Category filter
      if (selectedCategory !== "all" && prod.categoryId !== selectedCategory) {
        return;
      }

      prod.variants.forEach((v: any) => {
        const stock = getStock(v);
        const nameMatch = prod.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          v.name.toLowerCase().includes(searchQuery.toLowerCase());
        const skuMatch = v.sku.toLowerCase() === searchQuery.trim().toLowerCase();
        const barcodeMatch = v.barcode && v.barcode === searchQuery.trim();

        if (searchQuery === "" || nameMatch || skuMatch || barcodeMatch) {
          list.push({
            ...v,
            productName: prod.name,
            imageUrl: prod.imageUrl,
            enableStock: prod.enableStock,
            stock,
            isImei: !!(prod.isImei || prod.enableImei),
          });
        }
      });
    });
    return list;
  }, [products, searchQuery, selectedCategory, branchId]);

  // Handle clicking on a variant card
  const handleVariantClick = async (variant: any) => {
    if (variant.enableStock && variant.stock <= 0) return;
    if (variant.isImei) {
      setImeiSelectVariant(variant);
      setIsLoadingImeis(true);
      setImeiFilterQuery("");
      try {
        const imeis = await imeiService.getAvailableImeis(variant.id, branchId, businessId);
        setAvailableImeis(imeis);
      } catch (e) {
        setAvailableImeis([]);
      } finally {
        setIsLoadingImeis(false);
      }
    } else {
      onAddToCart(variant);
    }
  };

  // Handle Enter key for barcode scanner / SKU / IMEI exact match
  const handleSearchKeyDown = async (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const q = searchQuery.trim().toLowerCase();
      if (!q) return;

      // 1. Exact Barcode or SKU match
      const exactMatch = filteredVariants.find(
        (v) =>
          v.sku?.toLowerCase() === q ||
          (v.barcode && v.barcode.toLowerCase() === q)
      );

      if (exactMatch) {
        if (!exactMatch.enableStock || exactMatch.stock > 0) {
          if (exactMatch.isImei) {
            handleVariantClick(exactMatch);
          } else {
            onAddToCart(exactMatch);
          }
          setSearchQuery("");
        }
        return;
      }

      // 2. Check IMEI
      try {
        const imeiResults = await imeiService.searchImei(searchQuery.trim(), businessId);
        const availableImei = imeiResults.find(
          (i) => i.status === "IN_STOCK" && (!branchId || i.branchId === branchId)
        );
        if (availableImei && availableImei.variant) {
          const parentProd = products.find((p) => p.id === availableImei.productId);
          onAddToCart(
            {
              ...availableImei.variant,
              productName: parentProd?.name || availableImei.product?.name || "Product",
              imageUrl: parentProd?.imageUrl || availableImei.product?.imageUrl,
              isImei: true,
              stock: 1,
            },
            availableImei.imeiNumber
          );
          setSearchQuery("");
          return;
        }
      } catch {}

      // 3. If single match in grid
      if (filteredVariants.length === 1) {
        const singleItem = filteredVariants[0];
        if (!singleItem.enableStock || singleItem.stock > 0) {
          if (singleItem.isImei) {
            handleVariantClick(singleItem);
          } else {
            onAddToCart(singleItem);
          }
          setSearchQuery("");
        }
      }
    }
  };

  return (
    <div className="flex flex-col h-full gap-4">
      {/* Search and Category Bar */}
      <div className="flex flex-col sm:flex-row gap-2.5">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/60" />
          <Input
            ref={searchInputRef}
            type="text"
            placeholder="Search by name, SKU or scan barcode / IMEI (Press Enter to add)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={handleSearchKeyDown}
            className="pl-9 h-10 w-full bg-background/50 border border-input rounded-sm text-sm"
          />
        </div>

        {/* Dedicated IMEI Search / Directory Button */}
        <Button
          type="button"
          variant="outline"
          onClick={() => {
            setIsImeiDirectoryOpen(true);
            setDirectorySearchQuery("");
            fetchBranchImeis();
          }}
          className="h-10 px-3 flex items-center gap-1.5 rounded-sm border border-emerald-500/40 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 font-semibold text-xs transition shrink-0 cursor-pointer"
          title="Browse or Search All In-Stock IMEIs"
        >
          <Barcode className="h-4 w-4 text-emerald-400" />
          <span>IMEI List</span>
        </Button>
        
        {/* Add Product Button */}
        {hasPermission("pos:quick_add_product") && (
          <Button
            type="button"
            variant="secondary"
            onClick={() => setIsProductCreateOpen(true)}
            className="h-10 w-10 shrink-0 p-0 flex items-center justify-center bg-secondary hover:bg-secondary/80 border border-border"
            title="Add New Product"
          >
            <Plus className="h-4 w-4 text-foreground" />
          </Button>
        )}
      </div>

      {/* Sidebar + Products Grid Container */}
      <div className="flex-1 flex gap-3 min-h-0 overflow-hidden">
        {/* Left Category Sidebar */}
        <div className="w-40 flex flex-col gap-1.5 overflow-y-auto pr-1 shrink-0 scrollbar-none">
          <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-1 block px-1">
            Categories
          </span>
          <button
            type="button"
            onClick={() => setSelectedCategory("all")}
            className={cn(
              "w-full text-left py-2 px-3 text-xs font-semibold rounded transition-all border",
              selectedCategory === "all"
                ? "bg-primary text-black border-primary"
                : "bg-secondary/40 text-foreground border-border/30 hover:bg-secondary"
            )}
          >
            All
          </button>
          {categories.map((cat) => {
            const catColor = (cat as any).color || "#3B82F6";
            const isSelected = selectedCategory === cat.id;

            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                style={
                  isSelected
                    ? {
                        backgroundColor: catColor,
                        borderColor: catColor,
                        color: "#FFFFFF",
                        boxShadow: `0 2px 8px ${catColor}40`,
                      }
                    : {
                        borderLeftColor: catColor,
                        borderLeftWidth: "3px",
                      }
                }
                className={cn(
                  "w-full text-left py-2 px-2.5 text-xs font-semibold rounded transition-all border flex items-center gap-2 truncate",
                  !isSelected && "bg-secondary/40 text-foreground border-border/30 hover:bg-secondary"
                )}
                title={cat.name}
              >
                {!isSelected && (
                  <span
                    className="w-2 h-2 rounded-full shrink-0"
                    style={{ backgroundColor: catColor }}
                  />
                )}
                <span className="truncate">{cat.name}</span>
              </button>
            );
          })}
        </div>

        {/* Right Products Area */}
        <div className="flex-1 flex flex-col min-w-0 min-h-0">
          {/* Products Scroll Container */}
          <div className="flex-1 overflow-y-auto pr-1 min-h-[300px]">
            {isLoading ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 animate-pulse">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((i) => (
                  <div key={i} className="bg-muted/30 border border-border rounded-sm" style={{ aspectRatio: "1 / 1" }} />
                ))}
              </div>
            ) : filteredVariants.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-48 border border-dashed border-border rounded">
                <Package className="h-8 w-8 text-muted-foreground/50 mb-2" />
                <p className="text-xs text-muted-foreground">No products found</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                {filteredVariants.map((v) => {
                  const isOutOfStock = v.enableStock && v.stock <= 0;
                  return (
                    <Card
                      key={v.id}
                      onClick={() => !isOutOfStock && handleVariantClick(v)}
                      className={cn(
                        "group relative p-2 flex flex-col justify-between border cursor-pointer select-none transition-all duration-200 overflow-hidden bg-background/40 hover:bg-background/80 hover:border-primary/50",
                        isOutOfStock && "opacity-50 cursor-not-allowed border-destructive/20 hover:border-destructive/20 bg-muted/10"
                      )}
                    >
                      <div className="space-y-1">
                        {/* Image / Thumbnail placeholder */}
                        <div className="w-full rounded bg-muted/40 border border-border flex items-center justify-center overflow-hidden mb-1" style={{ aspectRatio: "1 / 1" }}>
                          {v.imageUrl ? (
                            <img src={getFullAssetUrl(v.imageUrl) || ""} alt={v.name} className="w-full h-full object-cover group-hover:scale-105 transition-all duration-300" />
                          ) : (
                            <Package className="h-8 w-8 text-muted-foreground/40" />
                          )}
                        </div>
                        
                        <div className="space-y-0.5">
                          <span className="text-xs font-bold text-foreground block line-clamp-1">
                            {v.productName}
                          </span>
                          {v.name !== v.productName && (
                            <span className="text-[10px] text-muted-foreground block line-clamp-1 font-semibold">
                              {v.name}
                            </span>
                          )}
                          <span className="text-[9px] font-mono text-muted-foreground block">
                            SKU: {v.sku}
                          </span>
                        </div>
                      </div>

                      <div className="flex flex-col gap-0.5 mt-1.5 pt-1.5 border-t border-border/40">
                        <span className="text-xs font-bold text-emerald-500">
                          {format(v.sellingPrice)}
                        </span>
                        <div className="flex items-center gap-1 flex-wrap">
                          <span
                            className={cn(
                              "text-[9px] px-1.5 py-0.5 rounded font-bold uppercase whitespace-nowrap",
                              isOutOfStock
                                ? "bg-destructive/10 text-destructive"
                                : v.enableStock
                                ? "bg-secondary text-secondary-foreground"
                                : "bg-blue-500/10 text-blue-500"
                            )}
                          >
                            {isOutOfStock ? "Out of Stock" : v.enableStock ? `${v.stock} left` : "Unlimited"}
                          </span>
                          {v.isImei && (
                            <span className="text-[9px] px-1 py-0.5 rounded font-bold uppercase bg-amber-500/15 text-amber-400 border border-amber-500/30 whitespace-nowrap flex items-center gap-0.5">
                              <Smartphone className="h-2.5 w-2.5" /> IMEI
                            </span>
                          )}
                        </div>
                      </div>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Select IMEI Modal for POS */}
      {imeiSelectVariant && (
        <Dialog
          isOpen={!!imeiSelectVariant}
          onClose={() => setImeiSelectVariant(null)}
          title={
            <div className="flex items-center gap-2">
              <Smartphone className="h-5 w-5 text-primary" />
              <span>Select IMEI / Serial Unit</span>
            </div>
          }
          size="md"
        >
          <div className="space-y-4 p-1">
            <div className="bg-muted/40 p-3 rounded-sm border border-border/70">
              <h4 className="font-bold text-sm text-foreground">{imeiSelectVariant.productName}</h4>
              <p className="text-xs text-muted-foreground font-mono">
                {imeiSelectVariant.name !== imeiSelectVariant.productName ? `${imeiSelectVariant.name} | ` : ""}
                SKU: {imeiSelectVariant.sku} | Price: {format(imeiSelectVariant.sellingPrice)}
              </p>
            </div>

            {/* Quick Filter or Scan within modal */}
            <div className="space-y-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/60" />
                <Input
                  type="text"
                  placeholder="Scan or type IMEI number (e.g. 888)..."
                  value={imeiFilterQuery}
                  onChange={(e) => setImeiFilterQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && imeiFilterQuery.trim()) {
                      e.preventDefault();
                      const trimmed = imeiFilterQuery.trim();
                      const exactMatch = availableImeis.find(
                        (i) => i.imeiNumber.toLowerCase() === trimmed.toLowerCase()
                      );
                      onAddToCart(imeiSelectVariant, exactMatch ? exactMatch.imeiNumber : trimmed);
                      setImeiSelectVariant(null);
                    }
                  }}
                  className="pl-9 h-10 text-xs font-mono"
                  autoFocus
                />
              </div>

              {/* Direct Use / Add button for typed or scanned IMEI */}
              {imeiFilterQuery.trim() && (
                <Button
                  type="button"
                  onClick={() => {
                    const trimmed = imeiFilterQuery.trim();
                    const exactMatch = availableImeis.find(
                      (i) => i.imeiNumber.toLowerCase() === trimmed.toLowerCase()
                    );
                    onAddToCart(imeiSelectVariant, exactMatch ? exactMatch.imeiNumber : trimmed);
                    setImeiSelectVariant(null);
                  }}
                  className="w-full h-9 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-sm rounded-sm cursor-pointer"
                >
                  <Plus className="h-4 w-4" />
                  <span>Use IMEI &quot;{imeiFilterQuery.trim()}&quot; and Add to Cart</span>
                </Button>
              )}
            </div>

            {/* IMEI List */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-semibold text-muted-foreground block">
                Available In-Stock Units ({availableImeis.length}):
              </span>
              <div className="min-h-[140px] max-h-[260px] overflow-y-auto p-2 border border-border/80 rounded-sm bg-background/50 space-y-1.5">
                {isLoadingImeis ? (
                  <div className="flex flex-col items-center justify-center py-8 text-xs text-muted-foreground gap-2">
                    <Loader2 className="h-5 w-5 animate-spin text-primary" />
                    <span>Loading in-stock IMEIs...</span>
                  </div>
                ) : availableImeis.length === 0 ? (
                  <div className="text-center py-6 px-3 text-xs text-muted-foreground space-y-2">
                    <p className="italic">No pre-registered IMEI units found in stock for this branch.</p>
                    <p className="text-[11px] text-amber-400 font-medium">
                      Type or scan your device IMEI above and click &quot;Use IMEI&quot; or press Enter to add.
                    </p>
                  </div>
                ) : (
                  availableImeis
                    .filter(
                      (i) =>
                        !imeiFilterQuery.trim() ||
                        i.imeiNumber.toLowerCase().includes(imeiFilterQuery.trim().toLowerCase())
                    )
                    .map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => {
                          onAddToCart(imeiSelectVariant, item.imeiNumber);
                          setImeiSelectVariant(null);
                        }}
                        className="w-full flex items-center justify-between p-2 rounded-sm border border-border/60 bg-card/60 hover:bg-primary/10 hover:border-primary/50 text-left transition-all group cursor-pointer"
                      >
                        <div className="flex items-center gap-2">
                          <Barcode className="h-4 w-4 text-primary group-hover:scale-110 transition-transform" />
                          <div>
                            <span className="font-mono text-xs font-bold text-foreground block">
                              {item.imeiNumber}
                            </span>
                          </div>
                        </div>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-semibold border border-emerald-500/30">
                          IN STOCK
                        </span>
                      </button>
                    ))
                )}
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-border/50">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => {
                  onAddToCart({ ...imeiSelectVariant, isImei: false });
                  setImeiSelectVariant(null);
                }}
                className="text-xs text-muted-foreground hover:text-foreground cursor-pointer"
              >
                Sell without IMEI
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setImeiSelectVariant(null)}
                className="text-xs cursor-pointer"
              >
                Cancel
              </Button>
            </div>
          </div>
        </Dialog>
      )}

      {/* Full IMEI Directory & Search Modal */}
      {isImeiDirectoryOpen && (
        <Dialog
          isOpen={isImeiDirectoryOpen}
          onClose={() => setIsImeiDirectoryOpen(false)}
          title={
            <div className="flex items-center gap-2">
              <Barcode className="h-5 w-5 text-emerald-400" />
              <span>In-Stock IMEI Inventory Directory</span>
            </div>
          }
          size="lg"
        >
          <div className="space-y-4 p-1">
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/60" />
                <Input
                  type="text"
                  placeholder="Search by IMEI number, device name, or SKU..."
                  value={directorySearchQuery}
                  onChange={(e) => {
                    setDirectorySearchQuery(e.target.value);
                    fetchBranchImeis(e.target.value);
                  }}
                  className="pl-9 h-10 text-xs font-mono"
                  autoFocus
                />
              </div>
              <Button
                type="button"
                variant="outline"
                onClick={() => fetchBranchImeis(directorySearchQuery)}
                className="h-10 text-xs px-3 cursor-pointer"
              >
                Refresh
              </Button>
            </div>

            {/* List of IMEIs */}
            <div className="min-h-[220px] max-h-[380px] overflow-y-auto border border-border/80 rounded-sm bg-background/50 divide-y divide-border/40">
              {isLoadingDirectory ? (
                <div className="flex flex-col items-center justify-center py-12 text-xs text-muted-foreground gap-2">
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  <span>Searching in-stock IMEIs...</span>
                </div>
              ) : directoryImeis.length === 0 ? (
                <div className="text-center py-12 text-xs text-muted-foreground space-y-1">
                  <Package className="h-8 w-8 text-muted-foreground/40 mx-auto mb-2" />
                  <p className="font-semibold text-foreground">No In-Stock IMEIs Found</p>
                  <p className="text-[11px] text-muted-foreground">
                    {directorySearchQuery
                      ? `No matching IMEIs for "${directorySearchQuery}"`
                      : "No serialized devices pre-registered in stock for this branch."}
                  </p>
                </div>
              ) : (
                directoryImeis.map((item) => {
                  const parentProd = products.find((p) => p.id === item.productId);
                  const variant = item.variant || parentProd?.variants?.find((v: any) => v.id === item.variantId);
                  const price = variant?.sellingPrice || 0;

                  return (
                    <div
                      key={item.id}
                      className="p-3 flex items-center justify-between hover:bg-muted/10 transition gap-3"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="h-10 w-10 rounded bg-muted/40 border border-border flex items-center justify-center shrink-0">
                          <Smartphone className="h-5 w-5 text-primary" />
                        </div>
                        <div className="min-w-0">
                          <span className="text-xs font-bold text-foreground block truncate">
                            {item.product?.name || parentProd?.name || "Product"}
                          </span>
                          <div className="flex items-center gap-2 flex-wrap text-[11px] text-muted-foreground">
                            <span className="font-mono text-emerald-400 font-bold bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/30">
                              IMEI: {item.imeiNumber}
                            </span>
                            <span className="font-mono">SKU: {variant?.sku || "N/A"}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 shrink-0">
                        <span className="text-xs font-bold text-foreground font-mono">
                          {format(price)}
                        </span>
                        <Button
                          type="button"
                          size="sm"
                          onClick={() => {
                            if (variant) {
                              onAddToCart(
                                {
                                  ...variant,
                                  productName: parentProd?.name || item.product?.name || "Product",
                                  imageUrl: parentProd?.imageUrl || item.product?.imageUrl,
                                  isImei: true,
                                  stock: 1,
                                },
                                item.imeiNumber
                              );
                              setIsImeiDirectoryOpen(false);
                            }
                          }}
                          className="h-8 px-3 text-xs bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-sm cursor-pointer"
                        >
                          <Plus className="h-3.5 w-3.5 mr-1" />
                          Add to Cart
                        </Button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="flex items-center justify-between text-xs text-muted-foreground pt-1 border-t border-border/40">
              <span>Total available: {directoryImeis.length} units</span>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setIsImeiDirectoryOpen(false)}
                className="text-xs cursor-pointer"
              >
                Close
              </Button>
            </div>
          </div>
        </Dialog>
      )}

      {isProductCreateOpen && (
        <ProductDialog
          isOpen={isProductCreateOpen}
          onClose={() => setIsProductCreateOpen(false)}
          product={null}
          businessId={businessId}
          userId={userId}
          onSuccessMessage={(msg) => {
            console.log(msg);
          }}
          onErrorMessage={(err) => {
            alert(err);
          }}
        />
      )}
    </div>
  );
}
