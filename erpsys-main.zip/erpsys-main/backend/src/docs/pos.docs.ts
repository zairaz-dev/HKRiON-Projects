export const CheckoutBodySchema = {
  type: 'object',
  properties: {
    invoiceNumber: { type: 'string', example: 'INV-2026-0001' },
    saleDate: { type: 'string', example: '2026-07-09T00:00:00.000Z' },
    customerId: { type: 'string', example: 'customer-uuid-123' },
    branchId: { type: 'string', example: 'branch-uuid-123' },
    businessId: { type: 'string', example: 'business-uuid-123' },
    discountType: { type: 'string', example: 'fixed' },
    discountAmount: { type: 'number', example: 5 },
    taxAmount: { type: 'number', example: 2.50 },
    grandTotal: { type: 'number', example: 47.50 },
    notes: { type: 'string', example: 'Store counter sale' },
    createdById: { type: 'string', example: 'user-uuid-123' },
    status: { type: 'string', enum: ['DRAFT', 'FINAL'], example: 'FINAL' },
    useAdvance: { type: 'boolean', example: false },
    saleLines: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          variantId: { type: 'string', example: 'variant-uuid-123' },
          quantity: { type: 'number', example: 2 },
          unitPrice: { type: 'number', example: 25.00 },
          discountAmount: { type: 'number', example: 0 },
          taxAmount: { type: 'number', example: 0 }
        },
        required: ['variantId', 'quantity', 'unitPrice']
      }
    },
    payments: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          amount: { type: 'number', example: 47.50 },
          paymentMethodId: { type: 'string', example: 'pm-cash-uuid' },
          transactionNo: { type: 'string', example: 'TXN-9988' },
          notes: { type: 'string', example: 'Paid cash' }
        },
        required: ['amount', 'paymentMethodId']
      }
    }
  },
  required: ['customerId', 'branchId', 'businessId', 'grandTotal', 'saleLines', 'payments']
};

export const CustomerAdvanceBodySchema = {
  type: 'object',
  properties: {
    customerId: { type: 'string', example: 'customer-uuid-123' },
    amount: { type: 'number', example: 500.00 },
    paymentMethodId: { type: 'string', example: 'pm-bank-uuid' },
    transactionNo: { type: 'string', example: 'TR-BANK-8822' },
    notes: { type: 'string', example: 'Advance payment for future order' },
    branchId: { type: 'string', example: 'branch-uuid-123' },
    businessId: { type: 'string', example: 'business-uuid-123' },
    createdById: { type: 'string', example: 'user-uuid-123' }
  },
  required: ['customerId', 'amount', 'paymentMethodId', 'branchId', 'businessId']
};

export const AddSalePaymentBodySchema = {
  type: 'object',
  properties: {
    amount: { type: 'number', example: 50.00 },
    paymentMethodId: { type: 'string', example: 'pm-cash-uuid' },
    transactionNo: { type: 'string', example: 'TX-PAY-1122' },
    notes: { type: 'string', example: 'Partial installment' },
    businessId: { type: 'string', example: 'business-uuid-123' },
    createdById: { type: 'string', example: 'user-uuid-123' }
  },
  required: ['amount', 'paymentMethodId', 'businessId']
};

export const PosResponseSchema = {
  type: 'object',
  properties: {
    id: { type: 'string', example: 'sale-uuid-123' },
    invoiceNumber: { type: 'string', example: 'INV-2026-0001' },
    grandTotal: { type: 'number', example: 47.50 },
    paymentStatus: { type: 'string', example: 'PAID' },
    status: { type: 'string', example: 'FINAL' },
    customerId: { type: 'string', example: 'customer-uuid-123' },
    businessId: { type: 'string', example: 'business-uuid-123' }
  }
};
