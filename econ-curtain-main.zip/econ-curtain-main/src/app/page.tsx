import { HomePageService } from "@/services/homepage.service";
import HomeClientView from "@/components/home/HomeClientView";

export const dynamic = "force-dynamic";

export default async function Home() {
  const content = await HomePageService.getContent();

  return <HomeClientView content={content} />;
}
