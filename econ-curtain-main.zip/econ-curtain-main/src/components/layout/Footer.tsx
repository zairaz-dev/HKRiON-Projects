import Link from "next/link";
import {
  Phone,
  Mail,
  MapPin,
  Clock,
  ArrowRight,
  ShieldCheck,
  Ruler,
  Cpu,
  Truck,
  Sparkles,
  ChevronRight,
  MessageCircle,
} from "lucide-react";
import Logo from "@/components/ui/Logo";
import { SettingsService, defaultSiteSettings } from "@/services/settings.service";
import { ContactService } from "@/services/contact.service";

// Platform SVG Icons
const FacebookIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>
);

const InstagramIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>
);

const LinkedInIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/>
    <rect width="4" height="12" x="2" y="9"/>
    <circle cx="4" cy="4" r="2"/>
  </svg>
);

const TikTokIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5"/>
  </svg>
);

const WhatsAppIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 21l1.65-3.8a9 9 0 1 1 3.4 2.9L3 21"/>
    <path d="M9 10a.5.5 0 0 0 1 0V9a.5.5 0 0 0-1 0v1a5 5 0 0 0 5 5h1a.5.5 0 0 0 0-1h-1a.5.5 0 0 0 0 1"/>
  </svg>
);

const YouTubeIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"/>
    <polygon points="10 15 15 12 10 9 10 15"/>
  </svg>
);

const TwitterIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path></svg>
);

const trustFeatures = [
  {
    icon: ShieldCheck,
    title: "Warranty Protected",
    desc: "Multi-year motor & textile warranty",
  },
  {
    icon: Ruler,
    title: "Millimeter Custom Fit",
    desc: "Laser precision site measurement",
  },
  {
    icon: Cpu,
    title: "Smart Motorization",
    desc: "Somfy & voice assistant automation",
  },
  {
    icon: Truck,
    title: "Islandwide Delivery",
    desc: "Professional turnkey installation",
  },
];

const interiorProducts = [
  { name: "Monsoon Blinds", cat: "Blinds" },
  { name: "Zebra Blinds", cat: "Blinds" },
  { name: "Roller Blinds", cat: "Blinds" },
  { name: "Roman Blinds", cat: "Blinds" },
  { name: "Luxury Curtains", cat: "Curtains" },
  { name: "Vertical Blinds", cat: "Blinds" },
  { name: "Timber Venetian", cat: "Blinds" },
];

const exteriorProducts = [
  { name: "Bioclimatic Pergolas", cat: "Outdoor Solutions" },
  { name: "Motorized Awnings", cat: "Outdoor Solutions" },
  { name: "Canopy Structures", cat: "Outdoor Solutions" },
  { name: "Outdoor Fabric", cat: "Outdoor Solutions" },
  { name: "Clear UV PVC", cat: "PVC Solutions" },
  { name: "Outdoor Teak Sunbed", cat: "Outdoor Living" },
];

const quickLinks = [
  { name: "Home", href: "/" },
  { name: "About Us", href: "/about" },
  { name: "Full Catalog", href: "/products" },
  { name: "Services", href: "/services" },
  { name: "Completed Projects", href: "/projects" },
  { name: "Contact & Consultation", href: "/contact" },
  { name: "Admin Portal", href: "/login" },
];

export default async function Footer() {
  let settings = defaultSiteSettings;
  let contact = await ContactService.getContent();
  
  try {
    settings = await SettingsService.getSettings();
  } catch (e) {
    console.error("Footer: Failed to load dynamic settings, using fallback:", e);
  }

  // Define active social channels dynamically
  const socialChannels = [
    {
      id: "instagram",
      label: "Instagram",
      href: settings.instagram?.trim(),
      icon: InstagramIcon,
      hoverClass: "hover:text-pink-400 hover:bg-pink-500/15 hover:border-pink-500/40",
    },
    {
      id: "facebook",
      label: "Facebook",
      href: settings.facebook?.trim(),
      icon: FacebookIcon,
      hoverClass: "hover:text-blue-400 hover:bg-blue-500/15 hover:border-blue-500/40",
    },
    {
      id: "linkedin",
      label: "LinkedIn",
      href: settings.linkedin?.trim(),
      icon: LinkedInIcon,
      hoverClass: "hover:text-sky-400 hover:bg-sky-500/15 hover:border-sky-500/40",
    },
    {
      id: "tiktok",
      label: "TikTok",
      href: settings.tiktok?.trim(),
      icon: TikTokIcon,
      hoverClass: "hover:text-white hover:bg-neutral-700/60 hover:border-neutral-500/50",
    },
    {
      id: "whatsapp",
      label: "WhatsApp",
      href: settings.whatsapp?.trim() ? SettingsService.formatWhatsAppUrl(settings.whatsapp) : "",
      icon: WhatsAppIcon,
      hoverClass: "hover:text-emerald-400 hover:bg-emerald-500/15 hover:border-emerald-500/40",
    },
    {
      id: "youtube",
      label: "YouTube",
      href: settings.youtube?.trim(),
      icon: YouTubeIcon,
      hoverClass: "hover:text-red-400 hover:bg-red-500/15 hover:border-red-500/40",
    },
    {
      id: "twitter",
      label: "Twitter",
      href: settings.twitter?.trim(),
      icon: TwitterIcon,
      hoverClass: "hover:text-amber-400 hover:bg-amber-400/20 hover:border-amber-400/50",
    },
  ].filter((item) => Boolean(item.href && item.href.length > 0));

  return (
    <footer className="bg-slate-950 text-slate-300 relative border-t border-slate-800/80 overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-amber-500/5 blur-3xl rounded-full pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-primary/5 blur-3xl rounded-full pointer-events-none" />

      {/* Top Trust Features Strip */}
      <div className="border-b border-slate-800/80 bg-slate-900/40 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
            {trustFeatures.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <div
                  key={i}
                  className="flex items-center gap-4 p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 hover:border-amber-400/30 transition-all duration-300 group"
                >
                  <div className="w-12 h-12 rounded-xl bg-amber-400/10 border border-amber-400/25 flex items-center justify-center shrink-0 text-amber-400 group-hover:scale-105 group-hover:bg-amber-400/20 transition-all">
                    <Icon size={22} />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white tracking-wide">
                      {feature.title}
                    </h4>
                    <p className="text-xs text-slate-400 font-light mt-0.5">
                      {feature.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 mb-14">
          
          {/* Column 1: Company Brand (Col Span 4) */}
          <div className="lg:col-span-4 space-y-5">
            <Link href="/" className="inline-block transition-transform active:scale-95 duration-200">
              <Logo className="h-10 sm:h-12 w-auto max-w-56" />
            </Link>
            
            <p className="text-sm leading-relaxed text-slate-400 font-light max-w-sm">
              Architectural window coverings, motorized smart shading, and heavy-duty exterior weather screens handcrafted with precision for villas, hotels, and luxury spaces.
            </p>

            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping shrink-0" />
              <span>Islandwide Site Measurement Available</span>
            </div>

            {/* Dynamic Social Links - Only visible if links are provided */}
            {socialChannels.length > 0 && (
              <div className="pt-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 block mb-3">
                  Connect With Us
                </span>
                <div className="flex flex-wrap items-center gap-2.5">
                  {socialChannels.map((channel) => {
                    const IconComponent = channel.icon;
                    return (
                      <a
                        key={channel.id}
                        href={channel.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        aria-label={channel.label}
                        title={channel.label}
                        className={`w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white active:scale-95 transition-all shadow-xs ${channel.hoverClass}`}
                      >
                        <IconComponent />
                      </a>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Column 2: Quick Links (Col Span 2) */}
          <div className="lg:col-span-2">
            <h3 className="text-white font-bold text-base uppercase tracking-wider mb-5 flex items-center gap-2">
              <span className="w-1.5 h-4 bg-amber-400 rounded-full" />
              <span>Explore</span>
            </h3>
            <ul className="space-y-2.5">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-slate-400 hover:text-amber-400 transition-all duration-200 text-sm flex items-center gap-2 group hover:translate-x-1"
                  >
                    <ChevronRight size={14} className="text-slate-600 group-hover:text-amber-400 transition-colors" />
                    <span>{link.name}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Products Catalog - Balanced 2-Column Subgrid (Col Span 3) */}
          <div className="lg:col-span-3">
            <h3 className="text-white font-bold text-base uppercase tracking-wider mb-5 flex items-center gap-2">
              <span className="w-1.5 h-4 bg-amber-400 rounded-full" />
              <span>Our Products</span>
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2">
              <div className="space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400/80 block pb-1 border-b border-slate-800">
                  Interior Systems
                </span>
                {interiorProducts.map((item) => (
                  <Link
                    key={item.name}
                    href={`/products?cat=${encodeURIComponent(item.cat)}`}
                    className="text-slate-400 hover:text-amber-400 transition-all duration-200 text-xs flex items-center gap-1.5 hover:translate-x-1 py-0.5"
                  >
                    <span className="w-1 h-1 rounded-full bg-slate-600" />
                    <span>{item.name}</span>
                  </Link>
                ))}
              </div>

              <div className="space-y-2 pt-4 sm:pt-0">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400/80 block pb-1 border-b border-slate-800">
                  Exterior & Patio
                </span>
                {exteriorProducts.map((item) => (
                  <Link
                    key={item.name}
                    href={`/products?cat=${encodeURIComponent(item.cat)}`}
                    className="text-slate-400 hover:text-amber-400 transition-all duration-200 text-xs flex items-center gap-1.5 hover:translate-x-1 py-0.5"
                  >
                    <span className="w-1 h-1 rounded-full bg-slate-600" />
                    <span>{item.name}</span>
                  </Link>
                ))}
              </div>
            </div>
          </div>

          {/* Column 4: Contact Cards & Consultation (Col Span 3) */}
          <div className="lg:col-span-3 space-y-4">
            <h3 className="text-white font-bold text-base uppercase tracking-wider mb-5 flex items-center gap-2">
              <span className="w-1.5 h-4 bg-amber-400 rounded-full" />
              <span>Contact Us</span>
            </h3>

            {/* Address Card */}
            <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 text-xs text-slate-300">
              <MapPin size={18} className="text-amber-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-white block mb-0.5">Showroom & Factory</span>
                <p className="text-slate-400 leading-relaxed font-light">
                  {contact.addressLine1}, {contact.addressLine2}
                </p>
              </div>
            </div>

            {/* Phone Card */}
            <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 text-xs text-slate-300">
              <Phone size={18} className="text-amber-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-white block mb-0.5">{contact.phoneSubtitle || "Direct Inquiry / Hotline"}</span>
                <a
                  href={`tel:${contact.phone.replace(/[^0-9+]/g, '')}`}
                  className="text-amber-400 font-bold hover:underline"
                >
                  {contact.phone}
                </a>
                <span className="text-[10px] text-slate-500 block mt-0.5">{contact.workingHoursLine1}</span>
              </div>
            </div>

            {/* Email Card */}
            <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 text-xs text-slate-300">
              <Mail size={18} className="text-amber-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-white block mb-0.5">{contact.emailSubtitle || "Email Support"}</span>
                <a
                  href={`mailto:${contact.email}`}
                  className="text-slate-300 hover:text-amber-400 transition-colors"
                >
                  {contact.email}
                </a>
              </div>
            </div>

            {/* Quick Action Quote Button */}
            <Link
              href="/contact"
              className="flex items-center justify-center gap-2 w-full bg-linear-to-r from-amber-400 via-yellow-400 to-amber-500 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs hover:brightness-110 active:scale-98 transition-all shadow-lg shadow-amber-500/20"
            >
              <Sparkles size={14} />
              <span>Request Free Site Quote</span>
              <ArrowRight size={14} />
            </Link>
          </div>

        </div>

        {/* Bottom Bar: Copyright & Legal (Centered) */}
        <div className="pt-8 border-t border-slate-800/80 flex flex-col justify-center items-center gap-4 text-xs text-slate-400 text-center">
          <div className="flex flex-wrap items-center justify-center gap-6 text-xs">
            <Link href="/about" className="hover:text-amber-400 transition-colors">
              About Us
            </Link>
            <Link href="/products" className="hover:text-amber-400 transition-colors">
              Catalog
            </Link>
            <Link href="/services" className="hover:text-amber-400 transition-colors">
              Services
            </Link>
            <Link href="/projects" className="hover:text-amber-400 transition-colors">
              Projects
            </Link>
            <Link href="/contact" className="hover:text-amber-400 transition-colors">
              Privacy &amp; Terms
            </Link>
          </div>

          <div className="space-y-1 text-center">
            <p>
              &copy; 2026 <span className="text-white font-semibold">SHADEIT BLINDS</span>. All Rights Reserved.
            </p>
            <p className="text-[11px] text-slate-400">
              Designed &amp; Developed by{" "}
              <a
                href="https://hkrion.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-amber-400 hover:text-amber-300 font-semibold hover:underline underline-offset-2 transition-colors"
              >
                HKRiON (PVT) LTD
              </a>
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}

