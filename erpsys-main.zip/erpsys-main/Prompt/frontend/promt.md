# AI Coding Assistant Prompts for HKR ERP

Use these prompts in future chat sessions to guide the AI assistant in refactoring existing pages or creating new pages according to the enterprise-grade architecture.

---

## 1. Prompt to Refactor an Existing Page

Copy and paste this prompt when you want to refactor an existing module (like `categories`, `units`, `products`, etc.):

```text
Please refactor the existing [page_name] module in `apps/web/src/app/[page_name]` into the new feature-based enterprise architecture.

Follow these steps:
1. Update `apps/web/src/lib/query-keys.ts` to add query keys for [page_name].
2. Create a new feature folder `apps/web/src/features/[page_name]`.
3. Inside the feature folder, create:
   - `types.ts`: Define all TypeScript interfaces for the feature.
   - `schema.ts`: Define the Zod validation schema for the form. Ensure input/output types match.
   - `hooks/use-[page_name].ts`: Create TanStack Query v5 hooks for fetching and mutations (with automatic cache invalidation).
   - `components/[page_name]-dialog.tsx`: Extract the create/edit modal using react-hook-form + Zod resolver.
   - `components/[page_name]-delete-dialog.tsx`: Extract the delete confirmation dialog.
   - `index.ts`: Export all types, hooks, and components.
4. Simplify `apps/web/src/app/[page_name]/page.tsx` to use these new hooks and components.
5. Implement URL Search Params for any active filters (like branchId).
6. Verify there are no TypeScript compile errors by running `pnpm tsc --noEmit`.
```

---

## 2. Prompt to Create a New Page from Scratch

Copy and paste this prompt when you want to create a completely new page or feature:

```text
Please create a new feature named [feature_name] in the `apps/web` project using the enterprise-grade feature-based architecture.

Follow this flow:
1. Add the query keys for the new feature in `apps/web/src/lib/query-keys.ts`.
2. Create a new feature folder `apps/web/src/features/[feature_name]` with:
   - `types.ts`: Define TypeScript interfaces.
   - `schema.ts`: Define Zod form validation schema.
   - `hooks/use-[feature_name].ts`: Define TanStack Query v5 hooks.
   - `components/[feature_name]-dialog.tsx`: Form dialog using react-hook-form + Zod resolver.
   - `components/[feature_name]-delete-dialog.tsx`: Delete confirmation dialog.
   - `index.ts`: Export everything.
3. Create the route page `apps/web/src/app/[feature_name]/page.tsx` that integrates:
   - Sidebar and Navbar layout.
   - DataTable with the columns.
   - Custom filters stored in URL search params.
   - The dialog components.
4. Ensure no TypeScript errors by running `pnpm tsc --noEmit`.
```
