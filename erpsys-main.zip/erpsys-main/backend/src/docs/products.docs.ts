export const CreateProductBodySchema = {
  type: 'object',
  properties: {
    name: { type: 'string', example: 'HKRION Wireless Mouse' },
    description: { type: 'string', example: 'Ergonomic 2.4GHz wireless mouse' },
    imageUrl: { type: 'string', example: '/uploads/products/mouse.png' },
    type: { type: 'string', enum: ['single', 'variable'], example: 'single' },
    isActive: { type: 'boolean', example: true },
    enableStock: { type: 'boolean', example: true },
    alertQuantity: { type: 'number', example: 5 },
    businessId: { type: 'string', example: 'business-uuid-123' },
    categoryId: { type: 'string', example: 'category-uuid-123' },
    brandId: { type: 'string', example: 'brand-uuid-123' },
    unitId: { type: 'string', example: 'unit-uuid-123' },
    warrantyId: { type: 'string', example: 'warranty-uuid-123' },
    branchIds: { type: 'array', items: { type: 'string' }, example: ['branch-uuid-1'] },
    sku: { type: 'string', example: 'MS-WRL-001' },
    purchasePrice: { type: 'number', example: 10.00 },
    sellingPrice: { type: 'number', example: 25.00 },
    openingStock: { type: 'number', example: 50 },
    openingStockBranchId: { type: 'string', example: 'branch-uuid-1' },
    createdById: { type: 'string', example: 'user-uuid-123' }
  },
  required: ['name', 'type', 'businessId']
};

export const UpdateProductBodySchema = {
  type: 'object',
  properties: {
    name: { type: 'string', example: 'HKRION Wireless Mouse v2' },
    description: { type: 'string', example: 'Updated description' },
    imageUrl: { type: 'string', example: '/uploads/products/mouse-v2.png' },
    isActive: { type: 'boolean', example: true },
    enableStock: { type: 'boolean', example: true },
    alertQuantity: { type: 'number', example: 10 },
    categoryId: { type: 'string', example: 'category-uuid-123', nullable: true },
    brandId: { type: 'string', example: 'brand-uuid-123', nullable: true },
    unitId: { type: 'string', example: 'unit-uuid-123', nullable: true },
    warrantyId: { type: 'string', example: 'warranty-uuid-123', nullable: true },
    branchIds: { type: 'array', items: { type: 'string' }, example: ['branch-uuid-1'] },
    sku: { type: 'string', example: 'MS-WRL-001' },
    purchasePrice: { type: 'number', example: 12.00 },
    sellingPrice: { type: 'number', example: 28.00 },
    businessId: { type: 'string', example: 'business-uuid-123' },
    updatedById: { type: 'string', example: 'user-uuid-123' }
  },
  required: ['businessId']
};

export const ProductResponseSchema = {
  type: 'object',
  properties: {
    id: { type: 'string', example: 'product-uuid-123' },
    name: { type: 'string', example: 'HKRION Wireless Mouse' },
    sku: { type: 'string', example: 'MS-WRL-001' },
    type: { type: 'string', example: 'single' },
    purchasePrice: { type: 'number', example: 10.00 },
    sellingPrice: { type: 'number', example: 25.00 },
    isActive: { type: 'boolean', example: true },
    businessId: { type: 'string', example: 'business-uuid-123' }
  }
};
