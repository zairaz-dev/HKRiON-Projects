export class UpdateCustomerGroupDto {
  name?: string;
  percentageDiscount?: number;
  sellingPriceGroupId?: string;
  isActive?: boolean;
  businessId?: string;
  branchIds?: string[];
  updatedById?: string;
}
