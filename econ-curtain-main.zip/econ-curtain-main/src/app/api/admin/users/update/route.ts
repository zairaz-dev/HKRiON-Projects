import { NextResponse } from "next/server";
import { UserService } from "@/services/user.service";
import { SessionManager } from "@/core/auth/session";
import { SafeHttp } from "@/core/http/redirect";
import { revalidatePath } from "next/cache";
import { db } from "@/core/db/client";

export async function POST(request: Request) {
  try {
    const session = await SessionManager.getCurrentSession();
    if (!session) {
      return SafeHttp.redirect("/login", request, 303);
    }

    const contentType = request.headers.get("content-type") || "";
    const isJson = contentType.includes("application/json");

    let id = "";
    let name = "";
    let email = "";
    let role = "ADMIN";

    if (isJson) {
      const body = await request.json();
      id = body.id || "";
      name = body.name || "";
      email = body.email || "";
      role = body.role || "ADMIN";
    } else {
      const formData = await request.formData();
      id = (formData.get("id") as string) || "";
      name = (formData.get("name") as string) || "";
      email = (formData.get("email") as string) || "";
      role = (formData.get("role") as string) || "ADMIN";
    }

    if (!id || !name || !email) {
      if (isJson) {
        return NextResponse.json({ success: false, error: "ID, Name, and Email are required." }, { status: 400 });
      }
      return SafeHttp.redirect("/admin/users?error=Name+and+Email+are+required", request, 303);
    }

    // Check if target user exists
    const existingUser = await UserService.getById(id);
    if (!existingUser) {
      if (isJson) {
        return NextResponse.json({ success: false, error: "User not found." }, { status: 404 });
      }
      return SafeHttp.redirect("/admin/users?error=User+not+found", request, 303);
    }

    // If email is changed, check if new email is already taken by another account
    const normalizedEmail = email.trim().toLowerCase();
    if (normalizedEmail !== existingUser.email) {
      const duplicateEmailUser = await db.user.findUnique({
        where: { email: normalizedEmail },
      });
      if (duplicateEmailUser && duplicateEmailUser.id !== id) {
        if (isJson) {
          return NextResponse.json({ success: false, error: "Email address is already in use by another account." }, { status: 400 });
        }
        return SafeHttp.redirect("/admin/users?error=Email+already+in+use", request, 303);
      }
    }

    // If changing role away from ADMIN, ensure there's at least one remaining ADMIN
    if (existingUser.role === "ADMIN" && role !== "ADMIN") {
      const adminCount = await UserService.countAdmins();
      if (adminCount <= 1) {
        if (isJson) {
          return NextResponse.json({ success: false, error: "Cannot demote the only remaining administrator." }, { status: 400 });
        }
        return SafeHttp.redirect("/admin/users?error=Cannot+demote+the+last+remaining+admin", request, 303);
      }
    }

    await UserService.update(id, {
      name,
      email: normalizedEmail,
      role,
    });

    revalidatePath("/admin/users");
    revalidatePath("/admin");

    if (isJson) {
      return NextResponse.json({ success: true, message: "User updated successfully" });
    }

    return SafeHttp.redirect(`/admin/users?success=User+updated+successfully`, request, 303);
  } catch (error: any) {
    console.error("Error updating user:", error);
    const contentType = request.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      return NextResponse.json({ success: false, error: error.message || "Failed to update user" }, { status: 500 });
    }
    return SafeHttp.redirect(`/admin/users?error=${encodeURIComponent(error.message || "Failed to update user")}`, request, 303);
  }
}
