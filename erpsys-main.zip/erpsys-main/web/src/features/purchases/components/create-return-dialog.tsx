import React, { useState, useEffect } from "react";
import { 
  X, 
  Loader2, 
  FileText, 
  Calendar, 
  RotateCcw,
  AlertCircle,
  Tag,
  Search,
  Check,
  CheckSquare,
  Square
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useCreatePurchaseReturnMutation, usePurchaseDetailQuery } from "../hooks/use-purchases";
import { useCurrency } from "@/hooks/use-currency";

interface CreatePurchaseReturnDialogProps {
  isOpen: boolean;
  onClose: () => void;
  purchase: any; // PurchaseItem
  businessId: string;
  userId: string;
  onSuccess: (msg: string) => void;
  onError: (msg: string) => void;
}

export function CreatePurchaseReturnDialog({
  isOpen,
  onClose,
  purchase,
  businessId,
  userId,
  onSuccess,
  onError
}: CreatePurchaseReturnDialogProps) {
  const { symbol, format } = useCurrency(businessId);
  const createMutation = useCreatePurchaseReturnMutation();

  // Fetch full purchase detail to always have productImeis populated
  const { data: fullPurchase, isLoading: isDetailLoading } = usePurchaseDetailQuery(
    purchase?.id,
    businessId
  );

  const activePurchase = fullPurchase || purchase;

  const [returnNumber, setReturnNumber] = useState("");
  const [returnDate, setReturnDate] = useState("");
  const [notes, setNotes] = useState("");
  const [returnQuantities, setReturnQuantities] = useState<Record<string, number>>({});
  const [selectedImeis, setSelectedImeis] = useState<Record<string, string[]>>({});

  // Sub-modal state for selecting IMEIs
  const [activeImeiLine, setActiveImeiLine] = useState<any | null>(null);
  const [imeiSearchQuery, setImeiSearchQuery] = useState("");

  // Reset fields on open/purchase change
  useEffect(() => {
    if (isOpen && activePurchase) {
      const rand = Math.floor(1000 + Math.random() * 9000);
      const dateStr = new Date().toISOString().split("T")[0].replace(/-/g, "").substring(2);
      setReturnNumber(`PR-${dateStr}-${rand}`);
      setReturnDate(new Date().toISOString().split("T")[0]);
      setNotes("");

      // Initialize all return quantities to 0
      const initialQuantities: Record<string, number> = {};
      const initialImeis: Record<string, string[]> = {};
      activePurchase.purchaseLines?.forEach((line: any) => {
        initialQuantities[line.id] = 0;
        initialImeis[line.id] = [];
      });
      setReturnQuantities(initialQuantities);
      setSelectedImeis(initialImeis);
    }
  }, [isOpen, activePurchase?.id]);

  if (!isOpen || !purchase) return null;

  const handleQtyChange = (lineId: string, maxQty: number, value: string) => {
    let num = parseFloat(value) || 0;
    if (num < 0) num = 0;
    if (num > maxQty) num = maxQty;
    
    setReturnQuantities(prev => ({
      ...prev,
      [lineId]: num
    }));
  };

  const toggleImeiSelection = (lineId: string, imeiNumber: string) => {
    setSelectedImeis(prev => {
      const current = prev[lineId] || [];
      let updated: string[];
      if (current.includes(imeiNumber)) {
        updated = current.filter(i => i !== imeiNumber);
      } else {
        updated = [...current, imeiNumber];
      }

      // Automatically sync return quantity with selected IMEI count
      setReturnQuantities(qPrev => ({
        ...qPrev,
        [lineId]: updated.length
      }));

      return {
        ...prev,
        [lineId]: updated
      };
    });
  };

  const selectAllAvailableImeis = (line: any) => {
    const available = (line.productImeis || [])
      .filter((pi: any) => pi.status === "IN_STOCK")
      .map((pi: any) => pi.imeiNumber);

    setSelectedImeis(prev => ({
      ...prev,
      [line.id]: available
    }));

    setReturnQuantities(qPrev => ({
      ...qPrev,
      [line.id]: available.length
    }));
  };

  const deselectAllImeis = (lineId: string) => {
    setSelectedImeis(prev => ({
      ...prev,
      [lineId]: []
    }));

    setReturnQuantities(qPrev => ({
      ...qPrev,
      [lineId]: 0
    }));
  };

  const removeSingleImei = (lineId: string, imeiToRemove: string) => {
    setSelectedImeis(prev => {
      const updated = (prev[lineId] || []).filter(i => i !== imeiToRemove);
      setReturnQuantities(qPrev => ({
        ...qPrev,
        [lineId]: updated.length
      }));
      return {
        ...prev,
        [lineId]: updated
      };
    });
  };

  // Grand total of items being returned
  const returnGrandTotal = activePurchase.purchaseLines?.reduce((sum: number, line: any) => {
    const qty = returnQuantities[line.id] || 0;
    return sum + qty * line.purchasePrice;
  }, 0) || 0;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validation: Check for serialized items without required IMEIs selected
    for (const line of activePurchase.purchaseLines || []) {
      const qty = returnQuantities[line.id] || 0;
      const hasImeis = line.productImeis && line.productImeis.length > 0;
      if (hasImeis && qty > 0) {
        const selected = selectedImeis[line.id] || [];
        if (selected.length !== qty) {
          onError(
            `Please select exactly ${qty} IMEI(s) for ${line.variant?.product?.name || "the serialized item"}. Currently selected: ${selected.length}.`
          );
          return;
        }
      }
    }

    const returnLines = activePurchase.purchaseLines
      ?.map((line: any) => ({
        purchaseLineId: line.id,
        quantityReturned: returnQuantities[line.id] || 0,
        imeis: (line.productImeis && line.productImeis.length > 0)
          ? (selectedImeis[line.id] || [])
          : undefined,
      }))
      .filter((line: any) => line.quantityReturned > 0) || [];

    if (returnLines.length === 0) {
      onError("Please select at least one item to return with a quantity greater than 0.");
      return;
    }

    const payload = {
      businessId,
      returnNumber: returnNumber.trim(),
      returnDate: returnDate ? new Date(returnDate).toISOString() : undefined,
      purchaseId: activePurchase.id,
      notes: notes.trim() || undefined,
      createdById: userId,
      returnLines
    };

    try {
      await createMutation.mutateAsync(payload);
      onSuccess(`Purchase return ${payload.returnNumber} created successfully!`);
      onClose();
    } catch (err: any) {
      onError(err.message || "Failed to submit purchase return.");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
      <div className="w-full max-w-4xl rounded-xl border border-border bg-card p-6 shadow-2xl animate-in zoom-in-95 duration-200 flex flex-col max-h-[92vh] overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border pb-3 mb-4 shrink-0">
          <div>
            <h3 className="text-lg font-bold flex items-center gap-2">
              <RotateCcw className="h-5 w-5 text-primary" />
              Create Purchase Return (Invoice #{activePurchase.purchaseNumber})
            </h3>
            <p className="text-xs text-muted-foreground mt-0.5">
              Supplier: <span className="font-semibold text-foreground">{activePurchase.supplier?.name}</span> | Branch: <span className="font-semibold text-foreground">{activePurchase.branch?.name}</span>
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="h-8 w-8 rounded-full"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto space-y-4 pr-1 pb-4">
            
            {/* Upper Details Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-muted/30 p-4 rounded-lg border border-border/40">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                  <FileText className="h-3.5 w-3.5 text-primary" /> Return Ref No
                </label>
                <Input
                  value={returnNumber}
                  onChange={(e) => setReturnNumber(e.target.value)}
                  className="h-9 text-xs"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                  <Calendar className="h-3.5 w-3.5 text-primary" /> Return Date
                </label>
                <Input
                  type="date"
                  value={returnDate}
                  onChange={(e) => setReturnDate(e.target.value)}
                  className="h-9 text-xs"
                  required
                />
              </div>
            </div>

            {/* Line Items returning */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider block">
                  Purchase Line Items & Stock Return
                </span>
                {isDetailLoading && (
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Loader2 className="h-3 w-3 animate-spin" /> Loading batch info...
                  </span>
                )}
              </div>
              
              <div className="border border-border/60 rounded-lg overflow-hidden">
                <table className="w-full text-xs text-left border-collapse">
                  <thead>
                    <tr className="bg-muted/40 border-b border-border/60">
                      <th className="p-3 font-semibold text-muted-foreground">Product</th>
                      <th className="p-3 font-semibold text-muted-foreground text-center">Purchased Qty</th>
                      <th className="p-3 font-semibold text-muted-foreground text-center">Remaining Stock</th>
                      <th className="p-3 font-semibold text-muted-foreground text-center">Return Qty</th>
                      <th className="p-3 font-semibold text-muted-foreground text-right">Unit Cost</th>
                      <th className="p-3 font-semibold text-muted-foreground text-right pr-4">Subtotal</th>
                    </tr>
                  </thead>
                  <tbody>
                    {activePurchase.purchaseLines?.map((line: any) => {
                      const qtyReturned = returnQuantities[line.id] || 0;
                      const subtotal = qtyReturned * line.purchasePrice;
                      const hasImeis = line.productImeis && line.productImeis.length > 0;
                      const lineSelectedImeis = selectedImeis[line.id] || [];
                      const inStockImeis = hasImeis
                        ? line.productImeis.filter((pi: any) => pi.status === "IN_STOCK")
                        : [];
                      const effectiveRemaining = hasImeis ? inStockImeis.length : line.quantityRemaining;

                      return (
                        <tr key={line.id} className="border-b border-border/40 hover:bg-muted/15 transition-colors">
                          <td className="p-3">
                            <span className="font-semibold text-foreground block">
                              {line.variant?.product?.name}
                            </span>
                            <span className="text-[10px] font-mono text-muted-foreground block">
                              SKU: {line.variant?.sku} {line.batchNumber ? `| Batch: ${line.batchNumber}` : ""}
                            </span>

                            {/* Serialized / IMEI controls */}
                            {hasImeis && (
                              <div className="mt-2 space-y-1.5">
                                <div className="flex items-center gap-2">
                                  <Button
                                    type="button"
                                    size="sm"
                                    variant="outline"
                                    onClick={() => {
                                      setActiveImeiLine(line);
                                      setImeiSearchQuery("");
                                    }}
                                    className={`h-6 text-[11px] gap-1 px-2 border-primary/40 font-semibold ${
                                      lineSelectedImeis.length > 0
                                        ? "bg-primary/15 text-primary border-primary"
                                        : "text-primary hover:bg-primary/10"
                                    }`}
                                  >
                                    <Tag className="h-3 w-3" />
                                    {lineSelectedImeis.length > 0
                                      ? `Selected IMEIs (${lineSelectedImeis.length})`
                                      : "Select IMEIs to Return"}
                                  </Button>

                                  {lineSelectedImeis.length > 0 && (
                                    <button
                                      type="button"
                                      onClick={() => deselectAllImeis(line.id)}
                                      className="text-[10px] text-muted-foreground hover:text-rose-500 underline"
                                    >
                                      Clear
                                    </button>
                                  )}
                                </div>

                                {/* Chips showing selected IMEIs */}
                                {lineSelectedImeis.length > 0 && (
                                  <div className="flex flex-wrap gap-1 max-w-sm">
                                    {lineSelectedImeis.slice(0, 4).map((imeiStr: string) => (
                                      <span
                                        key={imeiStr}
                                        className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/25 text-[10px] font-mono"
                                      >
                                        {imeiStr}
                                        <button
                                          type="button"
                                          onClick={() => removeSingleImei(line.id, imeiStr)}
                                          className="hover:text-rose-500 ml-0.5"
                                        >
                                          &times;
                                        </button>
                                      </span>
                                    ))}
                                    {lineSelectedImeis.length > 4 && (
                                      <span className="text-[10px] font-mono text-muted-foreground self-center">
                                        +{lineSelectedImeis.length - 4} more
                                      </span>
                                    )}
                                  </div>
                                )}
                              </div>
                            )}
                          </td>
                          <td className="p-3 text-center font-medium">
                            {line.quantityPurchased}
                          </td>
                          <td className="p-3 text-center">
                            <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold ${effectiveRemaining > 0 ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" : "bg-zinc-500/10 text-zinc-500"}`}>
                              {effectiveRemaining}
                            </span>
                          </td>
                          <td className="p-3 text-center w-32">
                            {hasImeis ? (
                              <div className="flex flex-col items-center">
                                <div className="h-8 px-2 w-20 flex items-center justify-center font-bold font-mono text-xs rounded border border-border bg-muted/40">
                                  {lineSelectedImeis.length}
                                </div>
                                <span className="text-[9px] text-muted-foreground mt-0.5">
                                  From IMEIs
                                </span>
                              </div>
                            ) : (
                              <Input
                                type="number"
                                min="0"
                                max={line.quantityRemaining}
                                step="any"
                                value={returnQuantities[line.id] === 0 ? "" : returnQuantities[line.id]}
                                placeholder="0"
                                disabled={line.quantityRemaining === 0}
                                onChange={(e) => handleQtyChange(line.id, line.quantityRemaining, e.target.value)}
                                className="h-8 text-center text-xs w-full"
                              />
                            )}
                          </td>
                          <td className="p-3 text-right font-mono">
                            {format(line.purchasePrice)}
                          </td>
                          <td className="p-3 text-right font-semibold font-mono pr-4">
                            {format(subtotal)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Notes */}
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-muted-foreground uppercase">
                Return Notes / Reason
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Reason for return (e.g. Defective items, wrong specification, damaged goods, etc.)"
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-xs shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring min-h-[60px]"
              />
            </div>
          </div>

          {/* Footer controls */}
          <div className="border-t border-border pt-4 shrink-0 flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-muted-foreground uppercase">Total Return Value</span>
              <span className="text-xl font-extrabold text-primary font-mono">
                {format(returnGrandTotal)}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="h-9 text-xs"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createMutation.isPending || returnGrandTotal === 0}
                className="h-9 text-xs gap-1.5 shadow-md shadow-primary/10"
              >
                {createMutation.isPending && <Loader2 className="h-3 w-3 animate-spin" />}
                Confirm Return
              </Button>
            </div>
          </div>
        </form>

        {/* Sub-Modal: IMEI Selection */}
        {activeImeiLine && (
          <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs animate-in fade-in duration-150">
            <div className="w-full max-w-lg rounded-xl border border-border bg-card p-5 shadow-2xl flex flex-col max-h-[85vh] overflow-hidden">
              <div className="flex items-center justify-between border-b border-border pb-3 mb-3">
                <div>
                  <h4 className="font-bold text-sm flex items-center gap-2">
                    <Tag className="h-4 w-4 text-primary" />
                    Select IMEIs to Return
                  </h4>
                  <p className="text-[11px] text-muted-foreground mt-0.5">
                    {activeImeiLine.variant?.product?.name} ({activeImeiLine.variant?.sku})
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setActiveImeiLine(null)}
                  className="h-7 w-7 rounded-full"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              {/* Search & Actions */}
              <div className="space-y-2 mb-3">
                <div className="relative">
                  <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
                  <Input
                    value={imeiSearchQuery}
                    onChange={(e) => setImeiSearchQuery(e.target.value)}
                    placeholder="Search or scan IMEI number..."
                    className="pl-8 text-xs h-8"
                  />
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="text-[11px] text-muted-foreground">
                    Selected: <strong className="text-primary font-mono font-bold">{(selectedImeis[activeImeiLine.id] || []).length}</strong> / {(activeImeiLine.productImeis || []).filter((i: any) => i.status === "IN_STOCK").length} available in-stock
                  </span>

                  <div className="flex gap-2">
                    <Button
                      type="button"
                      size="sm"
                      variant="ghost"
                      onClick={() => selectAllAvailableImeis(activeImeiLine)}
                      className="h-6 text-[10px] px-2 text-primary hover:bg-primary/10"
                    >
                      Select All In-Stock
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant="ghost"
                      onClick={() => deselectAllImeis(activeImeiLine.id)}
                      className="h-6 text-[10px] px-2 text-rose-500 hover:bg-rose-500/10"
                    >
                      Deselect All
                    </Button>
                  </div>
                </div>
              </div>

              {/* List of IMEIs */}
              <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 border border-border/60 rounded-lg p-2 bg-muted/20">
                {(() => {
                  const filtered = (activeImeiLine.productImeis || []).filter((pi: any) => {
                    if (!imeiSearchQuery) return true;
                    const q = imeiSearchQuery.toLowerCase();
                    return pi.imeiNumber.toLowerCase().includes(q);
                  });

                  if (filtered.length === 0) {
                    return (
                      <div className="p-6 text-center text-xs text-muted-foreground">
                        No IMEIs found matching your search.
                      </div>
                    );
                  }

                  const lineSelected = selectedImeis[activeImeiLine.id] || [];

                  return filtered.map((pi: any) => {
                    const isSelected = lineSelected.includes(pi.imeiNumber);
                    const isSold = pi.status === "SOLD";
                    const isAlreadyReturned = pi.status === "RETURNED";
                    const isAvailable = pi.status === "IN_STOCK";

                    return (
                      <div
                        key={pi.id}
                        onClick={() => {
                          if (isAvailable) {
                            toggleImeiSelection(activeImeiLine.id, pi.imeiNumber);
                          }
                        }}
                        className={`flex items-center justify-between p-2 rounded border text-xs transition-colors ${
                          isSelected
                            ? "border-primary bg-primary/10"
                            : isAvailable
                            ? "border-border hover:bg-muted/40 cursor-pointer"
                            : "border-border/40 opacity-60 bg-muted/10 cursor-not-allowed"
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          {isAvailable ? (
                            <div className={`w-4 h-4 rounded flex items-center justify-center border ${
                              isSelected ? "bg-primary border-primary text-black" : "border-muted-foreground"
                            }`}>
                              {isSelected && <Check className="h-3 w-3 stroke-[3]" />}
                            </div>
                          ) : (
                            <div className="w-4 h-4 rounded border border-muted-foreground/40 bg-muted flex items-center justify-center text-muted-foreground">
                              &times;
                            </div>
                          )}

                          <div>
                            <span className="font-mono font-bold text-foreground block">
                              {pi.imeiNumber}
                            </span>
                          </div>
                        </div>

                        <div>
                          {isSold && (
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-500/15 text-rose-500 border border-rose-500/30">
                              SOLD (LOCKED)
                            </span>
                          )}
                          {isAlreadyReturned && (
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-zinc-500/15 text-zinc-500 border border-zinc-500/30">
                              RETURNED
                            </span>
                          )}
                          {isAvailable && (
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/15 text-emerald-500 border border-emerald-500/30">
                              IN STOCK
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  });
                })()}
              </div>

              {/* Close Submodal Button */}
              <div className="pt-3 border-t border-border mt-3 flex justify-end">
                <Button
                  type="button"
                  size="sm"
                  onClick={() => setActiveImeiLine(null)}
                  className="h-8 text-xs font-semibold px-4"
                >
                  Done ({(selectedImeis[activeImeiLine.id] || []).length} Selected)
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
