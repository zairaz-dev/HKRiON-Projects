"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import {
  RotateCcw,
  Loader2,
  CheckCircle,
  AlertCircle,
  Building2,
  Calendar,
  Search,
  User as UserIcon,
  FileText,
  ArrowLeft,
  Plus
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { DataTable, ColumnDef } from "@/components/ui/table";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";
import {
  usePurchaseReturnsQuery,
  PurchaseReturnDetailDialog,
  SelectPurchaseDialog,
  CreatePurchaseReturnDialog
} from "@/features/purchases";
import { useCurrency } from "@/hooks/use-currency";
import { useSuppliersQuery, useBranchesQuery } from "@/features/suppliers/hooks/use-suppliers";



function PurchaseReturnsPageContent() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Success / Error notifications
  const [successMessage, setSuccessMessage] = useState("none");
  const [error, setError] = useState("");

  // URL Search Params for Filters
  const selectedBranchFilter = searchParams.get("branchId") || "all";
  const selectedSupplierFilter = searchParams.get("supplierId") || "all";
  const currentPage = Number(searchParams.get("page")) || 1;
  const searchQuery = searchParams.get("search") || "";
  const limit = Number(searchParams.get("limit")) || 10;

  const setSelectedBranchFilter = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1");
    if (value === "all") {
      params.delete("branchId");
    } else {
      params.set("branchId", value);
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  const setSelectedSupplierFilter = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1");
    if (value === "all") {
      params.delete("supplierId");
    } else {
      params.set("supplierId", value);
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  const handlePageChange = (newPage: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", String(newPage));
    router.push(`${pathname}?${params.toString()}`);
  };

  const handleSearchChange = (newSearch: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1");
    if (newSearch) {
      params.set("search", newSearch);
    } else {
      params.delete("search");
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  const handleLimitChange = (newLimit: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("limit", String(newLimit));
    params.set("page", "1");
    router.push(`${pathname}?${params.toString()}`);
  };

  // Auth check
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  const businessId = currentUser?.businessId || "";
  const { symbol, format } = useCurrency(businessId);

  // Queries
  const { data: returnsResponse, isLoading: returnsLoading } = usePurchaseReturnsQuery(
    businessId,
    {
      branchId: selectedBranchFilter !== "all" ? selectedBranchFilter : undefined,
      supplierId: selectedSupplierFilter !== "all" ? selectedSupplierFilter : undefined,
      page: currentPage,
      limit,
      search: searchQuery || undefined
    }
  );
  
  const returnsList = returnsResponse?.data || [];
  const meta = returnsResponse?.meta || { total: 0, totalPages: 1 };

  const { data: suppliersList = [] } = useSuppliersQuery(businessId);
  const { data: branchesList = [] } = useBranchesQuery(businessId, currentUser?.id);

  // Selected return for detail modal
  const [selectedReturn, setSelectedReturn] = useState<any | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  // States for creating new purchase return
  const [isSelectPurchaseOpen, setIsSelectPurchaseOpen] = useState(false);
  const [selectedPurchaseForReturn, setSelectedPurchaseForReturn] = useState<any | null>(null);
  const [isCreateReturnOpen, setIsCreateReturnOpen] = useState(false);


  // Columns definition
  const columns: ColumnDef<any>[] = [
    {
      header: "Return Ref #",
      render: (r) => (
        <span className="font-mono font-bold text-foreground block">
          {r.returnNumber}
        </span>
      ),
    },
    {
      header: "Return Date",
      render: (r) => (
        <span className="text-xs text-muted-foreground block">
          {new Date(r.returnDate).toLocaleDateString("en-IN", {
            day: "2-digit",
            month: "short",
            year: "numeric",
          })}
        </span>
      ),
    },
    {
      header: "Original Invoice #",
      render: (r) => (
        <span className="font-mono text-xs text-muted-foreground">
          {r.purchase?.purchaseNumber || "N/A"}
        </span>
      ),
    },
    {
      header: "Supplier",
      render: (r) => (
        <div className="flex flex-col gap-0.5">
          <span className="font-semibold text-foreground text-xs">{r.supplier?.name}</span>
          {r.supplier?.businessName && (
            <span className="text-[10px] text-muted-foreground uppercase font-medium">
              {r.supplier.businessName}
            </span>
          )}
        </div>
      ),
    },
    {
      header: "Branch",
      render: (r) => (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-secondary text-secondary-foreground border border-border text-[10px] font-bold">
          <Building2 className="h-3 w-3" /> {r.branch?.name}
        </span>
      ),
    },
    {
      header: "Items Returned",
      render: (r) => (
        <span className="text-xs">
          {r.returnLines?.length || 0} items
        </span>
      ),
    },
    {
      header: "Total Return Value",
      render: (r) => (
        <span className="font-extrabold text-rose-600 dark:text-rose-400 text-xs">
          {format(r.grandTotal)}
        </span>
      ),
    },
    {
      header: "Reason / Notes",
      render: (r) => (
        <span className="text-xs text-muted-foreground line-clamp-1 max-w-[150px]" title={r.notes || ""}>
          {r.notes || "—"}
        </span>
      ),
    },
    {
      header: "Actions",
      render: (r) => (
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            setSelectedReturn(r);
            setIsDetailOpen(true);
          }}
          className="h-7 text-[11px] gap-1 px-2 border-primary/30 hover:border-primary text-primary"
        >
          <FileText className="h-3 w-3" />
          Debit Note
        </Button>
      ),
    },
  ];

  // Custom filters popover content
  const customFilters = (
    <div className="space-y-3.5 min-w-[220px]">
      {/* Branch Filter */}
      <div className="space-y-1.5">
        <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
          <Building2 className="h-3 w-3" /> Branch Filter
        </label>
        <Select
          value={selectedBranchFilter}
          onValueChange={setSelectedBranchFilter}
          className="h-9 text-xs"
        >
          <option value="all">All Branches</option>
          {branchesList.map((b: any) => (
            <option key={b.id} value={b.id}>{b.name}</option>
          ))}
        </Select>
      </div>

      {/* Supplier Filter */}
      <div className="space-y-1.5">
        <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
          <UserIcon className="h-3 w-3" /> Supplier Filter
        </label>
        <Select
          value={selectedSupplierFilter}
          onValueChange={setSelectedSupplierFilter}
          className="h-9 text-xs"
        >
          <option value="all">All Suppliers</option>
          {suppliersList.map((s: any) => (
            <option key={s.id} value={s.id}>{s.name}</option>
          ))}
        </Select>
      </div>
    </div>
  );

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3 p-6 max-w-sm border border-border/40 rounded-xl bg-card/60 backdrop-blur-sm">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <h2 className="text-lg font-bold">Unauthorized Access</h2>
          <p className="text-sm text-muted-foreground">
            You need to be logged in to view this page. Redirecting to login...
          </p>
          <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/purchases" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Purchase Returns Ledger" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <RotateCcw className="h-7 w-7 text-primary" /> Purchase Returns
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Trace items returned to suppliers, record return values, and review auto-adjusted stock ledger logs.
              </p>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <Button
                onClick={() => setIsSelectPurchaseOpen(true)}
                className="gap-2 shadow-lg shadow-primary/20"
              >
                <Plus className="h-4 w-4" />
                Add Purchase Return
              </Button>
            </div>
          </div>

          {/* Banner Notifications */}
          {successMessage && successMessage !== "none" && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 animate-in fade-in slide-in-from-top-4 duration-300">
              <CheckCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive animate-in fade-in slide-in-from-top-4 duration-300">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          {/* Main Table Card */}
          {returnsLoading ? (
            <div className="flex h-64 items-center justify-center">
              <div className="text-center space-y-2">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
                <span className="text-sm text-muted-foreground block">Loading purchase returns...</span>
              </div>
            </div>
          ) : (
            <DataTable
              data={returnsList}
              columns={columns}
              searchPlaceholder="Search Return Ref #..."
              serverSide={true}
              totalItems={meta.total}
              totalPages={meta.totalPages}
              currentPage={currentPage}
              onPageChange={handlePageChange}
              searchQuery={searchQuery}
              onSearchQueryChange={handleSearchChange}
              onPageSizeChange={handleLimitChange}
              customFilters={customFilters}
              reportTitle="Purchase Returns Ledger Report"
            />
          )}

          {/* Select Purchase Dialog */}
          <SelectPurchaseDialog
            isOpen={isSelectPurchaseOpen}
            onClose={() => setIsSelectPurchaseOpen(false)}
            businessId={businessId}
            onSelectPurchase={(purchase) => {
              setSelectedPurchaseForReturn(purchase);
              setIsCreateReturnOpen(true);
            }}
          />

          {/* Create Purchase Return Dialog */}
          {selectedPurchaseForReturn && (
            <CreatePurchaseReturnDialog
              isOpen={isCreateReturnOpen}
              onClose={() => {
                setIsCreateReturnOpen(false);
                setSelectedPurchaseForReturn(null);
              }}
              purchase={selectedPurchaseForReturn}
              businessId={businessId}
              userId={currentUser?.id || ""}
              onSuccess={(msg) => {
                setSuccessMessage(msg);
                setTimeout(() => setSuccessMessage("none"), 5000);
              }}
              onError={(msg) => {
                setError(msg);
                setTimeout(() => setError(""), 5000);
              }}
            />
          )}

          {/* Return Detail Modal */}
          <PurchaseReturnDetailDialog
            isOpen={isDetailOpen}
            onClose={() => {
              setIsDetailOpen(false);
              setSelectedReturn(null);
            }}
            returnDetail={selectedReturn}
          />
        </main>
      </div>
    </div>
  );
}

export default function PurchaseReturnsPage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen w-screen items-center justify-center bg-[#121216]">
        <div className="flex flex-col items-center gap-2">
          <div className="w-8 h-8 border-4 border-zinc-700 border-t-emerald-500 rounded-full animate-spin" />
          <p className="text-sm text-zinc-400">Loading...</p>
        </div>
      </div>
    }>
      <PurchaseReturnsPageContent />
    </Suspense>
  );
}
