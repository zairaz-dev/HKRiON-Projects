import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { PhoneCode } from '../../types';

@Injectable()
export class PhoneCodeService {
  constructor(private readonly prisma: PrismaService) {}

  async findAll(): Promise<PhoneCode[]> {
    const phoneCodes = await this.prisma.phoneCode.findMany({
      where: { isActive: true },
      orderBy: { name: 'asc' },
    });
    return phoneCodes.map((p) => ({
      ...p,
      createdAt: p.createdAt.toISOString(),
    }));
  }
}
