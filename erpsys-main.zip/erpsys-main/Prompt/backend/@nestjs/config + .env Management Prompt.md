Act as a Senior NestJS Architect.

Implement a production-ready configuration system using @nestjs/config.

Requirements:

1. Install:
   - @nestjs/config

2. Configure ConfigModule globally.

Example:

ConfigModule.forRoot({
isGlobal: true,
envFilePath: '.env',
});

3. Create a .env.example file.

4. Move all hardcoded values into .env.

Examples:

PORT=
DATABASE_URL=
JWT_SECRET=
JWT_EXPIRES_IN=
REFRESH_TOKEN_SECRET=
REFRESH_TOKEN_EXPIRES_IN=
CORS_ORIGIN=

5. Replace every process.env access with ConfigService.

Example:

constructor(
private readonly configService: ConfigService,
){}

const jwtSecret =
this.configService.get<string>('JWT_SECRET');

6. Remove hardcoded secrets from the project.

7. Keep backward compatibility.

8. Do NOT modify business logic.

9. Configure AppModule properly.

10. Validate required environment variables during startup.

11. Generate:

- Updated AppModule
- Updated main.ts (if needed)
- Example .env
- .env.example
- Configuration Report

12. Follow NestJS official best practices.

Generate all modified files.
