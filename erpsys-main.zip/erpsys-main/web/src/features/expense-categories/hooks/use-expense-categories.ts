import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { expenseCategoryService } from "@/services/expense-category-service";
import { branchService } from "@/services/branch-service";
import { queryKeys } from "@/lib/query-keys";
import { ExpenseCategoryItem } from "../types";

export function useExpenseCategoriesQuery(businessId: string, branchId?: string) {
  return useQuery<ExpenseCategoryItem[]>({
    queryKey: queryKeys.expenseCategories.list(businessId, branchId),
    queryFn: () => expenseCategoryService.getExpenseCategories(businessId, branchId),
    enabled: !!businessId,
  });
}

export function useBranchesQuery(businessId: string, userId?: string) {
  return useQuery({
    queryKey: queryKeys.branches.list(businessId, userId),
    queryFn: () => branchService.getBranches(businessId, userId),
    enabled: !!businessId,
  });
}

export function useCreateExpenseCategoryMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: Parameters<typeof expenseCategoryService.createExpenseCategory>[0]) =>
      expenseCategoryService.createExpenseCategory(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.expenseCategories.all });
    },
  });
}

export function useUpdateExpenseCategoryMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Parameters<typeof expenseCategoryService.updateExpenseCategory>[1] }) =>
      expenseCategoryService.updateExpenseCategory(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.expenseCategories.all });
    },
  });
}

export function useDeleteExpenseCategoryMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, businessId }: { id: string; businessId: string }) =>
      expenseCategoryService.deleteExpenseCategory(id, businessId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.expenseCategories.all });
    },
  });
}
