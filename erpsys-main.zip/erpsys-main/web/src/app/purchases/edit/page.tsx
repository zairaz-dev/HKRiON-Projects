"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  FileText,
  X,
  Plus,
  Trash2,
  Calendar,
  Building2,
  User as UserIcon,
  Coins,
  Loader2,
  CheckCircle,
  AlertCircle,
  ArrowLeft,
  Search,
  Package,
  Barcode,
  Smartphone
} from "lucide-react";
import { getFullAssetUrl, cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Dialog } from "@/components/ui/dialog";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";

import {
  purchaseFormSchema,
  PurchaseFormValues,
  usePurchaseDetailQuery,
  useUpdatePurchaseMutation
} from "@/features/purchases";
import { useProductsQuery } from "@/features/products/hooks/use-products";
import { useSuppliersQuery, useBranchesQuery } from "@/features/suppliers/hooks/use-suppliers";
import { SupplierDialog } from "@/features/suppliers/components/supplier-dialog";
import { ProductDialog } from "@/features/products/components/product-dialog";
import { useCurrency } from "@/hooks/use-currency";

function EditPurchasePageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const id = searchParams.get("id") as string;

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    if (typeof window !== "undefined") return authService.getCurrentUser();
    return null;
  });
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(() => {
    if (typeof window !== "undefined") return authService.isAuthenticated();
    return null;
  });

  // Quick Add Dialogs
  const [isSupplierDialogOpen, setIsSupplierDialogOpen] = useState<boolean>(false);
  const [isProductDialogOpen, setIsProductDialogOpen] = useState<boolean>(false);

  // IMEI Management Modal State
  const [activeImeiLineIndex, setActiveImeiLineIndex] = useState<number | null>(null);
  const [imeiInputText, setImeiInputText] = useState("");
  const [soldImeiSet, setSoldImeiSet] = useState<Set<string>>(new Set());

  // Notifications
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Product Search State
  const [productSearchQuery, setProductSearchQuery] = useState("");
  const [showSearchResults, setShowSearchResults] = useState(false);
  const searchContainerRef = React.useRef<HTMLDivElement>(null);

  // Close search results when clicking outside
  useEffect(() => {
    const clickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setShowSearchResults(false);
      }
    };
    document.addEventListener("mousedown", clickOutside);
    return () => document.removeEventListener("mousedown", clickOutside);
  }, []);

  // Auth check
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  const businessId = currentUser?.businessId || "";
  const userId = currentUser?.id || "";
  const { symbol, format } = useCurrency(businessId);

  // Queries
  const { data: purchase, isLoading: purchaseLoading, error: loadError } = usePurchaseDetailQuery(id, businessId);
  const { data: productsList = [], refetch: refetchProducts } = useProductsQuery(businessId);
  const { data: suppliers = [], refetch: refetchSuppliers } = useSuppliersQuery(businessId);
  const { data: branches = [] } = useBranchesQuery(businessId, userId);

  // Mutation
  const updateMutation = useUpdatePurchaseMutation();

  // Flatten variants for item selection dropdown
  const allVariants = React.useMemo(() => {
    const list: {
      id: string;
      name: string;
      sku: string;
      purchasePrice: number;
      sellingPrice: number;
      currentStock: number;
      imageUrl?: string | null;
      isImei: boolean;
    }[] = [];
    productsList.forEach((p) => {
      const isSerialized = !!(p.isImei || (p as any).enableImei);
      p.variants.forEach((v) => {
        const totalStock = v.purchaseLines?.reduce((sum: number, line: any) => sum + (parseFloat(String(line.quantityRemaining)) || 0), 0) || 0;
        list.push({
          id: v.id!,
          name: p.type === "SINGLE" ? p.name : `${p.name} - ${v.name}`,
          sku: v.sku,
          purchasePrice: v.purchasePrice || 0,
          sellingPrice: v.sellingPrice || 0,
          currentStock: totalStock,
          imageUrl: p.imageUrl || null,
          isImei: isSerialized
        });
      });
    });
    return list;
  }, [productsList]);

  const filteredProductResults = React.useMemo(() => {
    if (!productSearchQuery.trim()) return [];
    const query = productSearchQuery.toLowerCase();
    return allVariants.filter(
      (v) => v.name.toLowerCase().includes(query) || v.sku.toLowerCase().includes(query)
    );
  }, [productSearchQuery, allVariants]);

  const handleSelectSearchedProduct = (variant: {
    id: string;
    name: string;
    sku: string;
    purchasePrice: number;
    sellingPrice: number;
    isImei?: boolean;
  }) => {
    append({
      variantId: variant.id,
      quantityPurchased: 1,
      purchasePrice: variant.purchasePrice,
      sellingPrice: variant.sellingPrice,
      batchNumber: "",
      expiryDate: "",
      imeis: []
    });
    setProductSearchQuery("");
    setShowSearchResults(false);
    if (variant.isImei) {
      setActiveImeiLineIndex(fields.length);
    }
  };

  // React Hook Form
  const {
    register,
    control,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors }
  } = useForm<PurchaseFormValues>({
    resolver: zodResolver(purchaseFormSchema) as any,
    defaultValues: {
      purchaseNumber: "",
      purchaseDate: "",
      supplierId: "",
      branchId: "",
      discountType: "FIXED",
      discountAmount: 0,
      shippingAmount: 0,
      taxAmount: 0,
      notes: "",
      purchaseLines: []
    }
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: "purchaseLines"
  });

  const watchPurchaseLines = watch("purchaseLines") || [];
  const watchSupplierId = watch("supplierId") || "";
  const watchBranchId = watch("branchId") || "";
  const watchDiscountType = watch("discountType") || "FIXED";
  const watchDiscountAmount = Number(watch("discountAmount") || 0);
  const watchShippingAmount = Number(watch("shippingAmount") || 0);
  const watchTaxAmount = Number(watch("taxAmount") || 0);

  // Populate form when purchase loads
  useEffect(() => {
    if (purchase) {
      const soldSet = new Set<string>();
      const initialLines = purchase.purchaseLines.map((line: any) => {
        const lineImeis: string[] = [];
        if (line.productImeis && Array.isArray(line.productImeis)) {
          line.productImeis.forEach((pi: any) => {
            if (pi.imeiNumber) {
              lineImeis.push(pi.imeiNumber);
              if (pi.status === "SOLD" || pi.saleLineId) {
                soldSet.add(pi.imeiNumber);
              }
            }
          });
        }
        return {
          variantId: line.variantId,
          quantityPurchased: line.quantityPurchased,
          purchasePrice: line.purchasePrice,
          sellingPrice: line.sellingPrice,
          batchNumber: line.batchNumber || "",
          expiryDate: line.expiryDate ? line.expiryDate.split("T")[0] : "",
          imeis: lineImeis
        };
      });

      setSoldImeiSet(soldSet);

      reset({
        purchaseNumber: purchase.purchaseNumber,
        purchaseDate: purchase.purchaseDate.split("T")[0],
        supplierId: purchase.supplierId,
        branchId: purchase.branchId,
        discountType: purchase.discountType || "FIXED",
        discountAmount: purchase.discountAmount || 0,
        shippingAmount: purchase.shippingAmount || 0,
        taxAmount: purchase.taxAmount || 0,
        notes: purchase.notes || "",
        purchaseLines: initialLines
      });
    }
  }, [purchase, reset]);

  // Track total sold units across purchase lines
  const totalSoldUnits = React.useMemo(() => {
    if (!purchase?.purchaseLines) return 0;
    return purchase.purchaseLines.reduce(
      (sum: number, l: any) => sum + Math.max(0, (parseFloat(String(l.quantityPurchased)) || 0) - (parseFloat(String(l.quantityRemaining)) || 0)),
      0
    );
  }, [purchase]);

  const isBranchLocked = totalSoldUnits > 0;

  // Track already paid amount
  const totalPaidAmount = React.useMemo(() => {
    if (!purchase) return 0;
    const paymentsSum = purchase.payments?.reduce(
      (sum: number, p: any) => sum + (parseFloat(String(p.amount)) || 0),
      0
    );
    return paymentsSum !== undefined && paymentsSum > 0 ? paymentsSum : (parseFloat(String(purchase.amountPaid)) || 0);
  }, [purchase]);

  // Calculate Subtotal and Grand Total
  const itemsSubtotal = watchPurchaseLines.reduce((acc, line) => {
    const qty = parseFloat(String(line.quantityPurchased)) || 0;
    const price = parseFloat(String(line.purchasePrice)) || 0;
    return acc + qty * price;
  }, 0);

  const calculatedDiscount = watchDiscountType === "PERCENTAGE"
    ? (itemsSubtotal * watchDiscountAmount) / 100
    : watchDiscountAmount;

  const grandTotal = Math.max(0, (itemsSubtotal - calculatedDiscount) + watchShippingAmount + watchTaxAmount);

  const onSubmit = async (data: PurchaseFormValues) => {
    if (data.purchaseLines.length === 0) {
      setError("Please add at least one line item.");
      return;
    }

    // 1. Destination branch lock validation
    if (isBranchLocked && data.branchId !== purchase?.branchId) {
      setError(`Cannot change destination branch because ${totalSoldUnits.toFixed(2)} unit(s) from this purchase have already been sold or used.`);
      return;
    }

    // 2. Financial adjustments validation
    if (watchDiscountAmount < 0 || watchShippingAmount < 0 || watchTaxAmount < 0) {
      setError("Discount, shipping, and tax amounts cannot be negative.");
      return;
    }
    if (calculatedDiscount > itemsSubtotal) {
      setError("Discount amount cannot exceed items subtotal.");
      return;
    }
    if (totalPaidAmount > 0 && grandTotal < totalPaidAmount - 0.01) {
      setError(`Grand Total (${format(grandTotal)}) cannot be less than already paid amount (${format(totalPaidAmount)}). Please adjust discount or item quantities.`);
      return;
    }

    // 3. Item Quantities & Price Validations
    for (let i = 0; i < data.purchaseLines.length; i++) {
      const line = data.purchaseLines[i];
      const matched = allVariants.find((v) => v.id === line.variantId);
      const lineQty = parseFloat(String(line.quantityPurchased)) || 0;
      const cost = parseFloat(String(line.purchasePrice)) || 0;
      const sell = parseFloat(String(line.sellingPrice)) || 0;

      if (lineQty <= 0) {
        setError(`Quantity for "${matched?.name || `Item #${i + 1}`}" must be greater than 0.`);
        return;
      }
      if (cost < 0 || sell < 0) {
        setError(`Prices for "${matched?.name || `Item #${i + 1}`}" cannot be negative.`);
        return;
      }

      // Check if this variant had sold units in the original purchase
      const oldLine = purchase?.purchaseLines?.find((ol: any) => ol.variantId === line.variantId);
      const soldQty = oldLine ? Math.max(0, (parseFloat(String(oldLine.quantityPurchased)) || 0) - (parseFloat(String(oldLine.quantityRemaining)) || 0)) : 0;
      if (soldQty > 0 && lineQty < soldQty) {
        setError(`Item "${matched?.name || 'Item'}" already has ${soldQty.toFixed(2)} unit(s) sold/used. Quantity cannot be less than ${soldQty.toFixed(2)}.`);
        return;
      }

      // Validate IMEI requirement for serialized products
      if (matched?.isImei) {
        const count = line.imeis?.length || 0;
        if (count !== lineQty) {
          setError(`Item "${matched.name}" requires exactly ${lineQty} IMEI/Serial number(s), but ${count} were entered. Please click the IMEI button to enter them.`);
          return;
        }
      }
    }

    // 4. Ensure old purchase lines with sold units haven't been removed
    if (purchase?.purchaseLines) {
      for (const oldLine of purchase.purchaseLines) {
        const soldQty = Math.max(0, (parseFloat(String(oldLine.quantityPurchased)) || 0) - (parseFloat(String(oldLine.quantityRemaining)) || 0));
        if (soldQty > 0) {
          const stillPresent = data.purchaseLines.some((l) => l.variantId === oldLine.variantId);
          if (!stillPresent) {
            const varName = allVariants.find((v) => v.id === oldLine.variantId)?.name || "Product";
            setError(`Cannot remove "${varName}" because ${soldQty.toFixed(2)} unit(s) have already been sold/used.`);
            return;
          }
        }
      }
    }

    // 5. Ensure sold IMEIs are not removed
    for (const soldImei of Array.from(soldImeiSet)) {
      const isPresent = data.purchaseLines.some((line) => line.imeis?.includes(soldImei));
      if (!isPresent) {
        setError(`Cannot remove IMEI "${soldImei}" because it has already been sold.`);
        return;
      }
    }

    // 6. Check for duplicate IMEIs across all purchase lines
    const allEnteredImeis = new Set<string>();
    for (const line of data.purchaseLines) {
      for (const imei of line.imeis || []) {
        const trimmed = imei.trim();
        if (allEnteredImeis.has(trimmed)) {
          setError(`Duplicate IMEI "${trimmed}" found in purchase items. Each IMEI must be unique.`);
          return;
        }
        allEnteredImeis.add(trimmed);
      }
    }

    const payload = {
      purchaseNumber: data.purchaseNumber.trim(),
      purchaseDate: data.purchaseDate ? new Date(data.purchaseDate).toISOString() : undefined,
      supplierId: data.supplierId,
      branchId: data.branchId,
      businessId,
      purchaseLines: data.purchaseLines.map((line) => ({
        variantId: line.variantId,
        quantityPurchased: parseFloat(String(line.quantityPurchased)),
        purchasePrice: parseFloat(String(line.purchasePrice)),
        sellingPrice: parseFloat(String(line.sellingPrice)),
        batchNumber: line.batchNumber || undefined,
        expiryDate: line.expiryDate ? new Date(line.expiryDate).toISOString() : undefined,
        imeis: line.imeis && line.imeis.length > 0 ? line.imeis : undefined
      })),
      discountType: data.discountType || "FIXED",
      discountAmount: Number(data.discountAmount || 0),
      shippingAmount: Number(data.shippingAmount || 0),
      taxAmount: Number(data.taxAmount || 0),
      grandTotal,
      notes: data.notes?.trim() || undefined
    };

    try {
      await updateMutation.mutateAsync({ id, data: payload });
      setSuccessMessage("Purchase record updated successfully! Redirecting...");
      setTimeout(() => {
        router.push("/purchases");
      }, 1500);
    } catch (err: any) {
      setError(err.message || "Failed to update purchase.");
    }
  };

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3 p-6 max-w-sm border border-border/40 rounded-xl bg-card/60 backdrop-blur-sm">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <h2 className="text-lg font-bold">Unauthorized Access</h2>
          <p className="text-sm text-muted-foreground">Redirecting to login...</p>
          <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
        </div>
      </div>
    );
  }

  if (purchaseLoading) {
    return (
      <div className="flex h-screen bg-background text-foreground overflow-hidden">
        <Sidebar activePath="/purchases" />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Navbar title="Edit Stock Purchase" />
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center space-y-2">
              <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
              <span className="text-sm text-muted-foreground">Loading purchase details...</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="flex h-screen bg-background text-foreground overflow-hidden">
        <Sidebar activePath="/purchases" />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Navbar title="Edit Stock Purchase" />
          <div className="flex-1 flex items-center justify-center p-6">
            <div className="text-center space-y-4 max-w-md p-6 border border-border rounded-sm bg-card">
              <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
              <h2 className="text-lg font-bold">Failed to load purchase</h2>
              <p className="text-sm text-muted-foreground">{(loadError as any).message || "An unexpected error occurred."}</p>
              <Button onClick={() => router.push("/purchases")} className="rounded-sm">Back to Purchases</Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/purchases" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Edit Stock Purchase" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">

          {/* Header */}
          <div className="flex items-center gap-3">
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={() => router.push("/purchases")}
              className="h-9 w-9 rounded-sm"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
              <h1 className="text-2xl font-extrabold tracking-tight flex items-center gap-2">
                <FileText className="h-6 w-6 text-primary" /> Edit Stock Purchase
              </h1>
              <p className="text-xs text-muted-foreground mt-0.5">
                Update invoice details, quantities, cost and batch prices for this purchase.
              </p>
            </div>
          </div>

          {/* Status Message Alerts */}
          {successMessage && (
            <div className="flex items-center gap-3 p-4 rounded-sm bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400">
              <CheckCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 p-4 rounded-sm bg-destructive/10 border border-destructive/25 text-destructive">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 w-full">
            {/* Section 1: Header Form details */}
            <Card className="border border-border/60 bg-card/40 backdrop-blur-sm shadow-xl relative z-30">
              <CardContent className="p-6 grid grid-cols-1 md:grid-cols-4 gap-6">

                {/* Purchase Number */}
                <div className="space-y-1.5">
                  <div className="h-5 flex items-center">
                    <label className="text-xs font-bold text-muted-foreground uppercase">
                      Invoice / Purchase # *
                    </label>
                  </div>
                  <Input
                    {...register("purchaseNumber")}
                    placeholder="e.g. PUR-0001"
                    disabled={updateMutation.isPending}
                    className="h-10 text-xs font-semibold"
                  />
                  {errors.purchaseNumber && (
                    <span className="text-xs text-rose-500">{errors.purchaseNumber.message}</span>
                  )}
                </div>

                {/* Purchase Date */}
                <div className="space-y-1.5">
                  <div className="h-5 flex items-center">
                    <label className="text-xs font-bold text-muted-foreground uppercase">
                      Purchase Date *
                    </label>
                  </div>
                  <Input
                    type="date"
                    icon={<Calendar className="h-4 w-4" />}
                    {...register("purchaseDate")}
                    disabled={updateMutation.isPending}
                    className="h-10 text-xs font-semibold cursor-pointer"
                  />
                  {errors.purchaseDate && (
                    <span className="text-xs text-rose-500">{errors.purchaseDate.message}</span>
                  )}
                </div>

                {/* Supplier Selection with Clean New Button */}
                <div className="space-y-1.5">
                  <div className="h-5 flex items-center justify-between">
                    <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1">
                      <UserIcon className="h-3 w-3" /> Supplier *
                    </label>
                    <button
                      type="button"
                      onClick={() => setIsSupplierDialogOpen(true)}
                      className="text-[11px] font-bold text-primary hover:underline flex items-center gap-0.5"
                    >
                      <Plus className="h-3 w-3" /> New
                    </button>
                  </div>
                  <Select
                    showSearch={true}
                    value={watchSupplierId}
                    onValueChange={(val) => setValue("supplierId", val, { shouldValidate: true })}
                    disabled={updateMutation.isPending}
                    className="h-10 text-xs font-semibold w-full"
                  >
                    <option value="" disabled>Select Supplier</option>
                    {suppliers.map((s: any) => (
                      <option key={s.id} value={s.id}>
                        {s.name.replace(/,\s*$/, "")} {s.businessName ? `(${s.businessName})` : ""}
                      </option>
                    ))}
                  </Select>
                  {errors.supplierId && (
                    <span className="text-xs text-rose-500">{errors.supplierId.message}</span>
                  )}
                </div>

                {/* Destination Branch */}
                <div className="space-y-1.5">
                  <div className="h-5 flex items-center">
                    <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1">
                      <Building2 className="h-3 w-3" /> Destination Branch *
                    </label>
                  </div>
                  <Select
                    showSearch={true}
                    value={watchBranchId}
                    onValueChange={(val) => setValue("branchId", val, { shouldValidate: true })}
                    disabled={updateMutation.isPending || isBranchLocked}
                    icon={<Building2 className="h-4 w-4" />}
                    className="h-10 text-xs font-semibold w-full"
                  >
                    <option value="" disabled>Select Branch</option>
                    {branches.map((b: any) => (
                      <option key={b.id} value={b.id}>{b.name}</option>
                    ))}
                  </Select>
                  {isBranchLocked && (
                    <span className="text-[10px] text-amber-500 font-medium block">
                      Branch locked: {totalSoldUnits.toFixed(2)} unit(s) from this purchase have already been sold.
                    </span>
                  )}
                  {errors.branchId && (
                    <span className="text-xs text-rose-500">{errors.branchId.message}</span>
                  )}
                </div>

              </CardContent>
            </Card>

            {/* Purchase Items & Description Card */}
            <Card className="border border-border/60 bg-card/40 backdrop-blur-sm shadow-xl relative z-20">
              <CardContent className="p-6 space-y-6">
                
                {/* Product Searching & Selection with Quick Add Button */}
                <div className="flex gap-2 items-center relative z-30">
                  <div className="relative flex-1" ref={searchContainerRef}>
                    <div className="flex items-center border border-border bg-card rounded-sm px-3 py-2 text-sm focus-within:ring-1 focus-within:ring-ring gap-2">
                      <Search className="h-4 w-4 text-muted-foreground shrink-0" />
                      <input
                        placeholder="Enter Product name / SKU / Scan barcode to add new item..."
                        value={productSearchQuery}
                        onChange={(e) => {
                          setProductSearchQuery(e.target.value);
                          setShowSearchResults(true);
                        }}
                        onFocus={() => setShowSearchResults(true)}
                        disabled={updateMutation.isPending}
                        className="w-full bg-transparent border-0 outline-none p-0 focus:ring-0 text-xs placeholder:text-muted-foreground/60 text-foreground"
                      />
                    </div>

                    {/* Autocomplete Search Dropdown */}
                    {showSearchResults && productSearchQuery.trim() && (
                      <div className="absolute top-full left-0 right-0 mt-2 max-h-60 overflow-y-auto border border-border bg-card rounded-sm p-2 shadow-2xl z-40 space-y-1">
                      {filteredProductResults.length > 0 ? (
                        <div className="space-y-1">
                          {filteredProductResults.map((v) => (
                            <div
                              key={v.id}
                              onClick={() => handleSelectSearchedProduct(v)}
                              className="flex items-center justify-between cursor-pointer select-none rounded-sm px-3 py-2 text-sm hover:bg-accent hover:text-foreground transition-colors group"
                            >
                              <div className="flex items-center gap-2.5">
                                {/* Product Thumbnail */}
                                <div className="h-8 w-8 rounded-sm border border-border/80 bg-muted/30 overflow-hidden flex items-center justify-center shrink-0">
                                  {v.imageUrl ? (
                                    <img
                                      src={getFullAssetUrl(v.imageUrl) || ""}
                                      alt={v.name}
                                      className="h-full w-full object-cover"
                                    />
                                  ) : (
                                    <Package className="h-4 w-4 text-muted-foreground/60" />
                                  )}
                                </div>

                                <div className="flex flex-col">
                                  <span className="font-semibold text-foreground group-hover:text-primary transition-colors">
                                    {v.name}
                                  </span>
                                  <span className="text-xs text-muted-foreground font-mono">
                                    SKU: {v.sku}
                                  </span>
                                </div>
                              </div>
                              <div className="text-xs text-right">
                                <div className="text-muted-foreground font-medium">Cost: {format(v.purchasePrice)}</div>
                                <div className="text-emerald-500 font-bold">Sell: {format(v.sellingPrice)}</div>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="py-4 text-center text-xs text-muted-foreground font-mono">
                          No matching products found
                        </div>
                      )}
                    </div>
                  )}
                  </div>

                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsProductDialogOpen(true)}
                    className="h-10 px-3 text-xs font-bold gap-1.5 shrink-0 border-border/80 hover:bg-accent rounded-sm"
                    title="Add New Product"
                  >
                    <Plus className="h-4 w-4 text-primary" /> New Product
                  </Button>
                </div>

                {/* Section 2: Items Table card */}
                <div className="border border-border/80 rounded-sm p-4 bg-secondary/5 space-y-4">
                  {fields.length === 0 ? (
                    <div className="text-center py-10 text-xs text-muted-foreground">
                      No items added yet. Search and select products above to add them.
                    </div>
                  ) : (
                    <div className="overflow-x-auto w-full">
                      <table className="w-full border-collapse">
                        <thead>
                          <tr className="border-b border-border/40 text-[10px] font-bold text-muted-foreground uppercase tracking-wider text-left">
                            <th className="pb-3 text-center w-[4%]">#</th>
                            <th className="pb-3 pr-4 w-[34%]">Product Name / Details</th>
                            <th className="pb-3 pr-4 w-[10%]">Purchase Quantity</th>
                            <th className="pb-3 pr-4 w-[12%]">Cost ({symbol})</th>
                            <th className="pb-3 pr-4 w-[12%]">Line Total ({symbol})</th>
                            <th className="pb-3 pr-4 w-[13%] text-emerald-500">Unit Selling Price ({symbol})</th>
                            <th className="pb-3 pr-4 w-[10%]">Batch #</th>
                            <th className="pb-3 pr-4 w-[10%]">Expiry</th>
                            <th className="pb-3 text-center w-[5%]"></th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-border/30">
                          {fields.map((field, idx) => {
                            const matchedVar = allVariants.find((v) => v.id === watchPurchaseLines[idx]?.variantId);
                            const qty = parseFloat(String(watchPurchaseLines[idx]?.quantityPurchased)) || 0;
                            const costPrice = parseFloat(String(watchPurchaseLines[idx]?.purchasePrice)) || 0;
                            const lineTotal = qty * costPrice;

                            return (
                              <tr key={field.id} className="group hover:bg-muted/5 transition-colors">
                                
                                {/* Row Number */}
                                <td className="py-3 text-center align-middle font-mono text-xs text-muted-foreground">
                                  {idx + 1}
                                </td>

                                {/* Product Description with Thumbnail */}
                                <td className="py-3 pr-4 align-middle">
                                  <div className="flex items-center gap-3">
                                    {/* Product Thumbnail */}
                                    <div className="h-10 w-10 rounded-sm border border-border/80 bg-muted/30 overflow-hidden flex items-center justify-center shrink-0">
                                      {matchedVar?.imageUrl ? (
                                        <img
                                          src={getFullAssetUrl(matchedVar.imageUrl) || ""}
                                          alt={matchedVar?.name || "Product"}
                                          className="h-full w-full object-cover"
                                        />
                                      ) : (
                                        <Package className="h-5 w-5 text-muted-foreground/60" />
                                      )}
                                    </div>

                                      <div className="flex flex-col">
                                        <span className="font-semibold text-sm text-foreground">{matchedVar?.name || "Unknown Product"}</span>
                                        <span className="text-[10px] text-muted-foreground font-mono">SKU: {matchedVar?.sku || "N/A"}</span>
                                        <span className="text-[10px] text-emerald-500/80 font-medium">
                                          Current stock: {matchedVar?.currentStock !== undefined ? `${matchedVar.currentStock.toFixed(2)} Pc(s)` : "0.00 Pc(s)"}
                                        </span>
                                        {matchedVar?.isImei && (
                                          <div className="mt-1.5 flex items-center gap-1.5">
                                            <Button
                                              type="button"
                                              size="sm"
                                              variant="outline"
                                              onClick={() => {
                                                setActiveImeiLineIndex(idx);
                                                setImeiInputText("");
                                              }}
                                              className={cn(
                                                "h-6 px-2 text-[10px] font-mono gap-1 rounded-sm border transition-colors",
                                                (watchPurchaseLines[idx]?.imeis?.length || 0) === qty && qty > 0
                                                  ? "border-emerald-500/50 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20"
                                                  : "border-amber-500/50 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20"
                                              )}
                                            >
                                              <Barcode className="h-3 w-3" />
                                              IMEIs ({watchPurchaseLines[idx]?.imeis?.length || 0}/{qty})
                                            </Button>
                                            {(watchPurchaseLines[idx]?.imeis?.length || 0) !== qty && (
                                              <span className="text-[10px] text-amber-400 font-medium">
                                                Required
                                              </span>
                                            )}
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  </td>

                                  {/* Quantity Input */}
                                  <td className="py-3 pr-4 align-middle">
                                    <Input
                                      type="number"
                                      step="any"
                                      required
                                      placeholder="1.00"
                                      {...register(`purchaseLines.${idx}.quantityPurchased` as const, { valueAsNumber: true })}
                                      disabled={updateMutation.isPending}
                                      className="h-9 text-xs"
                                    />
                                    {(() => {
                                      const oldLine = purchase?.purchaseLines?.find((ol: any) => ol.variantId === watchPurchaseLines[idx]?.variantId);
                                      const soldQty = oldLine ? Math.max(0, (parseFloat(String(oldLine.quantityPurchased)) || 0) - (parseFloat(String(oldLine.quantityRemaining)) || 0)) : 0;
                                      if (soldQty > 0) {
                                        return (
                                          <span className="text-[10px] text-amber-500 font-mono block mt-0.5" title="Units already sold cannot be reduced below this number">
                                            Min: {soldQty.toFixed(2)} sold
                                          </span>
                                        );
                                      }
                                      return null;
                                    })()}
                                  </td>

                                  {/* Purchase Cost Input */}
                                  <td className="py-3 pr-4 align-middle">
                                    <Input
                                      type="number"
                                      step="any"
                                      required
                                      placeholder="0.00"
                                      {...register(`purchaseLines.${idx}.purchasePrice` as const, { valueAsNumber: true })}
                                      disabled={updateMutation.isPending}
                                      className="h-9 text-xs"
                                    />
                                  </td>

                                  {/* Line Total (Display Only) */}
                                  <td className="py-3 pr-4 align-middle font-mono text-xs font-bold text-foreground">
                                    {format(lineTotal)}
                                  </td>

                                  {/* Unit Selling Price Input */}
                                  <td className="py-3 pr-4 align-middle">
                                    <Input
                                      type="number"
                                      step="any"
                                      required
                                      placeholder="0.00"
                                      {...register(`purchaseLines.${idx}.sellingPrice` as const, { valueAsNumber: true })}
                                      disabled={updateMutation.isPending}
                                      className="h-9 text-xs text-emerald-500 font-semibold"
                                    />
                                    {(() => {
                                      const sell = parseFloat(String(watchPurchaseLines[idx]?.sellingPrice)) || 0;
                                      if (costPrice > 0 && sell > 0 && sell < costPrice) {
                                        return (
                                          <span className="text-[10px] text-amber-500 font-medium block mt-0.5" title="Selling price is lower than cost price">
                                            Below cost!
                                          </span>
                                        );
                                      }
                                      return null;
                                    })()}
                                  </td>

                                  {/* Batch Number Input */}
                                  <td className="py-3 pr-4 align-middle">
                                    <Input
                                      placeholder="Optional"
                                      {...register(`purchaseLines.${idx}.batchNumber` as const)}
                                      disabled={updateMutation.isPending}
                                      className="h-9 text-xs"
                                    />
                                  </td>

                                  {/* Expiry Date Input */}
                                  <td className="py-3 pr-4 align-middle">
                                    <Input
                                      type="date"
                                      {...register(`purchaseLines.${idx}.expiryDate` as const)}
                                      disabled={updateMutation.isPending}
                                      className="h-9 text-xs"
                                    />
                                  </td>

                                  {/* Delete Action Button */}
                                  <td className="py-3 text-center align-middle">
                                    {(() => {
                                      const hasSoldImei = (watchPurchaseLines[idx]?.imeis || []).some((imei) => soldImeiSet.has(imei));
                                      const oldLine = purchase?.purchaseLines?.find((ol: any) => ol.variantId === watchPurchaseLines[idx]?.variantId);
                                      const soldQty = oldLine ? Math.max(0, (parseFloat(String(oldLine.quantityPurchased)) || 0) - (parseFloat(String(oldLine.quantityRemaining)) || 0)) : 0;
                                      const hasSoldUnits = hasSoldImei || soldQty > 0;

                                      return (
                                        <Button
                                          type="button"
                                          variant="ghost"
                                          size="icon"
                                          onClick={() => {
                                            if (hasSoldUnits) {
                                              setError(`Cannot remove this item because ${soldQty > 0 ? `${soldQty.toFixed(2)} unit(s)` : 'IMEIs'} have already been sold.`);
                                              return;
                                            }
                                            remove(idx);
                                          }}
                                          disabled={updateMutation.isPending || hasSoldUnits}
                                          title={hasSoldUnits ? `Cannot delete: ${soldQty > 0 ? `${soldQty.toFixed(2)} unit(s)` : 'IMEIs'} have already been sold` : "Remove item"}
                                          className={cn(
                                            "h-8 w-8 rounded-sm transition",
                                            hasSoldUnits
                                              ? "text-muted-foreground/40 cursor-not-allowed"
                                              : "text-destructive hover:bg-destructive/10 hover:text-destructive"
                                          )}
                                        >
                                          <X className="h-4 w-4" />
                                        </Button>
                                      );
                                    })()}
                                  </td>

                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                {/* Section 3: Financial Adjustments (Discount, Shipping, Tax) & Notes */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 pt-1">
                  {/* Notes */}
                  <div className="lg:col-span-7 flex flex-col justify-between space-y-1.5">
                    <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1.5">
                      <FileText className="h-3.5 w-3.5" /> Purchase Notes / Remarks
                    </label>
                    <textarea
                      placeholder="Details about payment terms, vehicle number, custom delivery info, etc."
                      {...register("notes")}
                      disabled={updateMutation.isPending}
                      rows={4}
                      className="w-full flex-1 min-h-[90px] rounded-sm border border-border/80 bg-background/50 px-3 py-2 text-xs shadow-xs focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-primary resize-none placeholder:text-muted-foreground/60"
                    />
                  </div>

                  {/* Bill Financial Adjustments - Compact Inline Table */}
                  <div className="lg:col-span-5 rounded-sm border border-border/80 bg-card/60 p-3.5 space-y-2 shadow-xs">
                    <div className="flex items-center justify-between border-b border-border/60 pb-1.5">
                      <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                        Bill Summary
                      </span>
                      <span className="text-[11px] text-muted-foreground font-mono font-medium">
                        {watchPurchaseLines.length} Item{watchPurchaseLines.length === 1 ? "" : "s"}
                      </span>
                    </div>

                    {/* Items Subtotal */}
                    <div className="flex items-center justify-between text-xs py-0.5">
                      <span className="text-muted-foreground font-medium">Items Subtotal:</span>
                      <span className="font-bold text-foreground font-mono">{format(itemsSubtotal)}</span>
                    </div>

                    {/* Discount Input with Fixed/Percentage Toggle - Compact Inline */}
                    <div className="flex items-center justify-between text-xs gap-2 py-0.5">
                      <div className="flex items-center gap-1.5">
                        <span className="text-muted-foreground font-medium">Discount:</span>
                        <div className="inline-flex rounded-sm border border-border/80 p-0.5 bg-background">
                          <button
                            type="button"
                            onClick={() => setValue("discountType", "FIXED")}
                            className={`px-1.5 py-0.5 rounded-sm text-[10px] font-bold transition-all ${watchDiscountType === "FIXED" ? "bg-primary text-black" : "text-muted-foreground hover:text-foreground"}`}
                          >
                            {symbol} Fixed
                          </button>
                          <button
                            type="button"
                            onClick={() => setValue("discountType", "PERCENTAGE")}
                            className={`px-1.5 py-0.5 rounded-sm text-[10px] font-bold transition-all ${watchDiscountType === "PERCENTAGE" ? "bg-primary text-black" : "text-muted-foreground hover:text-foreground"}`}
                          >
                            %
                          </button>
                        </div>
                        {watchDiscountType === "PERCENTAGE" && calculatedDiscount > 0 && (
                          <span className="text-[10px] text-rose-500 font-mono font-bold">
                            (-{format(calculatedDiscount)})
                          </span>
                        )}
                      </div>
                      <Input
                        type="number"
                        step="any"
                        min={0}
                        placeholder="0.00"
                        {...register("discountAmount", { valueAsNumber: true })}
                        className="h-7 w-28 text-right text-xs font-bold font-mono"
                      />
                    </div>

                    {/* Shipping / Freight Charges - Compact Inline */}
                    <div className="flex items-center justify-between text-xs gap-2 py-0.5">
                      <span className="text-muted-foreground font-medium">Shipping / Freight ({symbol}):</span>
                      <Input
                        type="number"
                        step="any"
                        min={0}
                        placeholder="0.00"
                        {...register("shippingAmount", { valueAsNumber: true })}
                        className="h-7 w-28 text-right text-xs font-mono"
                      />
                    </div>

                    {/* Tax Amount - Compact Inline */}
                    <div className="flex items-center justify-between text-xs gap-2 py-0.5">
                      <span className="text-muted-foreground font-medium">Tax Amount ({symbol}):</span>
                      <Input
                        type="number"
                        step="any"
                        min={0}
                        placeholder="0.00"
                        {...register("taxAmount", { valueAsNumber: true })}
                        className="h-7 w-28 text-right text-xs font-mono"
                      />
                    </div>

                    {/* Final Grand Total - Compact Highlighted */}
                    <div className="flex items-center justify-between pt-2 border-t border-border/60">
                      <span className="font-black text-xs uppercase tracking-wider text-foreground">Grand Total:</span>
                      <span className="font-black text-lg text-primary font-mono">{format(grandTotal)}</span>
                    </div>
                  </div>
                </div>

              </CardContent>
            </Card>

            {/* Bottom Actions Bar */}
            <div className="flex items-center justify-between p-4 rounded-sm border border-border/60 bg-card/60 backdrop-blur-sm shadow-lg relative z-0">
              <div className="flex items-center gap-8">
                <div className="flex flex-col">
                  <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Total Items</span>
                  <span className="text-lg font-extrabold text-foreground">
                    {watchPurchaseLines.length}.00
                  </span>
                </div>
                <div className="w-px h-8 bg-border/60" />
                <div className="flex flex-col">
                  <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Net Total Amount</span>
                  <span className="text-2xl font-black text-foreground flex items-center gap-1.5">
                    <Coins className="h-6 w-6 text-amber-500" /> {format(grandTotal)}
                  </span>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => router.push("/purchases")}
                  disabled={updateMutation.isPending}
                  className="h-10 px-5 text-xs font-bold rounded-sm"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={updateMutation.isPending}
                  className="h-10 px-5 text-xs font-bold rounded-sm flex items-center gap-1.5"
                >
                  {updateMutation.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
                  Save Purchase Updates
                </Button>
              </div>
            </div>
          </form>

        </main>
      </div>

      {/* Quick Add Supplier Dialog Modal */}
      {currentUser && isSupplierDialogOpen && (
        <SupplierDialog
          isOpen={isSupplierDialogOpen}
          onClose={() => setIsSupplierDialogOpen(false)}
          branches={branches}
          currentUser={currentUser}
          onSuccess={(msg) => {
            setSuccessMessage(msg);
            refetchSuppliers();
            setIsSupplierDialogOpen(false);
          }}
          onError={setError}
        />
      )}

      {/* Quick Add Product Dialog Modal */}
      {currentUser && isProductDialogOpen && (
        <ProductDialog
          isOpen={isProductDialogOpen}
          onClose={() => setIsProductDialogOpen(false)}
          product={null}
          businessId={businessId}
          userId={userId}
          onSuccessMessage={(msg) => {
            setSuccessMessage(msg);
            refetchProducts();
            setIsProductDialogOpen(false);
          }}
          onErrorMessage={setError}
        />
      )}

      {/* IMEI / Serial Numbers Entry Modal */}
      {activeImeiLineIndex !== null && (() => {
        const activeLine = watchPurchaseLines[activeImeiLineIndex];
        const activeVar = activeLine ? allVariants.find((v) => v.id === activeLine.variantId) : null;
        const currentImeis: string[] = activeLine?.imeis || [];
        const requiredQty = parseFloat(String(activeLine?.quantityPurchased)) || 0;

        const handleAddImeis = (text: string) => {
          if (!text.trim()) return;
          const tokens = text
            .split(/[\n,\s]+/)
            .map((s) => s.trim())
            .filter((s) => s.length > 0);
          if (tokens.length === 0) return;

          // Check if already used in other purchase lines
          const otherLinesImeis = new Set<string>();
          watchPurchaseLines.forEach((l, lIdx) => {
            if (lIdx !== activeImeiLineIndex) {
              (l.imeis || []).forEach((im) => otherLinesImeis.add(im.trim()));
            }
          });

          const next = [...currentImeis];
          for (const token of tokens) {
            if (otherLinesImeis.has(token)) {
              setError(`IMEI "${token}" is already entered in another item in this purchase.`);
              return;
            }
            if (!next.includes(token)) {
              next.push(token);
            }
          }
          setValue(`purchaseLines.${activeImeiLineIndex}.imeis`, next, { shouldDirty: true });
          setImeiInputText("");
        };

        const handleRemoveImei = (i: number) => {
          const targetImei = currentImeis[i];
          if (soldImeiSet.has(targetImei)) {
            setError(`Cannot remove IMEI "${targetImei}" because it has already been sold.`);
            return;
          }
          const next = currentImeis.filter((_, index) => index !== i);
          setValue(`purchaseLines.${activeImeiLineIndex}.imeis`, next, { shouldDirty: true });
        };

        const handleSyncQty = () => {
          if (currentImeis.length > 0) {
            setValue(`purchaseLines.${activeImeiLineIndex}.quantityPurchased`, currentImeis.length, { shouldDirty: true });
          }
        };

        const handleClearAll = () => {
          const preserved = currentImeis.filter((imei) => soldImeiSet.has(imei));
          if (preserved.length > 0 && preserved.length < currentImeis.length) {
            setError("Cleared in-stock IMEIs. Sold IMEIs were preserved.");
          }
          setValue(`purchaseLines.${activeImeiLineIndex}.imeis`, preserved, { shouldDirty: true });
        };

        return (
          <Dialog
            isOpen={activeImeiLineIndex !== null}
            onClose={() => setActiveImeiLineIndex(null)}
            title={
              <div className="flex items-center gap-2">
                <Smartphone className="h-5 w-5 text-primary" />
                <span>Enter IMEIs / Serial Numbers</span>
              </div>
            }
            size="lg"
          >
            <div className="space-y-4 p-1">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-muted/40 p-3 rounded-sm border border-border/70 gap-2">
                <div>
                  <h4 className="font-bold text-sm text-foreground">{activeVar?.name}</h4>
                  <p className="text-xs text-muted-foreground font-mono">SKU: {activeVar?.sku || "N/A"}</p>
                </div>
                <div className="flex items-center gap-2">
                  <div className={cn(
                    "text-xs px-2.5 py-1 rounded font-semibold font-mono",
                    currentImeis.length === requiredQty && requiredQty > 0
                      ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40"
                      : "bg-amber-500/20 text-amber-400 border border-amber-500/40"
                  )}>
                    {currentImeis.length} / {requiredQty} IMEIs
                  </div>
                  {currentImeis.length > 0 && currentImeis.length !== requiredQty && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={handleSyncQty}
                      className="h-7 text-xs border-dashed border-primary/50 text-primary hover:bg-primary/10"
                      title="Update purchase quantity to match number of IMEIs entered"
                    >
                      Sync Qty ({currentImeis.length})
                    </Button>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-semibold text-foreground flex items-center justify-between">
                  <span>Scan or Paste IMEI / Serial Numbers</span>
                  <span className="text-[11px] text-muted-foreground font-normal">
                    (Press Enter or separate by newline/comma)
                  </span>
                </label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Scan barcode or type IMEI..."
                    value={imeiInputText}
                    onChange={(e) => setImeiInputText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        handleAddImeis(imeiInputText);
                      }
                    }}
                    className="font-mono text-xs"
                    autoFocus
                  />
                  <Button
                    type="button"
                    onClick={() => handleAddImeis(imeiInputText)}
                    disabled={!imeiInputText.trim()}
                    className="shrink-0 text-xs px-4"
                  >
                    Add
                  </Button>
                </div>
              </div>

              {/* IMEIs list */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs text-muted-foreground font-medium">
                  <span>Entered IMEIs ({currentImeis.length})</span>
                  {currentImeis.length > 0 && (
                    <button
                      type="button"
                      onClick={handleClearAll}
                      className="text-destructive hover:underline text-[11px]"
                    >
                      Clear Unsold
                    </button>
                  )}
                </div>
                <div className="min-h-[120px] max-h-[220px] overflow-y-auto p-2 border border-border/80 rounded-sm bg-background/50 flex flex-wrap gap-1.5 content-start">
                  {currentImeis.length === 0 ? (
                    <div className="w-full h-full flex items-center justify-center text-xs text-muted-foreground/60 italic py-8">
                      No IMEIs entered yet. Scan or type above.
                    </div>
                  ) : (
                    currentImeis.map((imei, idx) => {
                      const isSold = soldImeiSet.has(imei);
                      return (
                        <span
                          key={idx}
                          className={cn(
                            "inline-flex items-center gap-1.5 px-2.5 py-1 rounded font-mono text-xs border group",
                            isSold
                              ? "bg-rose-500/10 text-rose-300 border-rose-500/30"
                              : "bg-secondary/80 text-foreground border-border"
                          )}
                        >
                          <span className="text-[10px] text-muted-foreground font-sans">#{idx + 1}</span>
                          {imei}
                          {isSold ? (
                            <span className="text-[9px] bg-rose-500/20 text-rose-400 font-bold px-1.5 py-0.5 rounded uppercase ml-1">
                              Sold
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleRemoveImei(idx)}
                              className="text-muted-foreground hover:text-destructive transition ml-0.5"
                              title="Remove"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          )}
                        </span>
                      );
                    })
                  )}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-border/50">
                <Button
                  type="button"
                  onClick={() => setActiveImeiLineIndex(null)}
                  className="px-5 text-xs"
                >
                  Done
                </Button>
              </div>
            </div>
          </Dialog>
        );
      })()}
    </div>
  );
}

export default function EditPurchasePage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen w-screen items-center justify-center bg-[#121216]">
        <div className="flex flex-col items-center gap-2">
          <div className="w-8 h-8 border-4 border-zinc-700 border-t-emerald-500 rounded-full animate-spin" />
          <p className="text-sm text-zinc-400">Loading...</p>
        </div>
      </div>
    }>
      <EditPurchasePageContent />
    </Suspense>
  );
}
