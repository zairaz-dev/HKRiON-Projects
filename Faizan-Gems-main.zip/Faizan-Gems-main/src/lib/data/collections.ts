import { Collection } from "@/types/gemstone";

export interface CMSCollectionCard {
  id: string;
  slug: string;
  name: string; // Name of the gem / collection
  image: string; // High-resolution image
  showOnHome: boolean; // Whether to display on homepage
  orderIndex?: number;
}

export const DEFAULT_COLLECTION_CARDS: CMSCollectionCard[] = [
  {
    id: "col-1789652413868",
    slug: "the-golden-monarch-ceylon-yellow-sapphire",
    name: "The Golden Monarch: Ceylon Yellow Sapphire",
    image: "/uploads/banners/hero-1789652484567-ksitkn.webp",
    showOnHome: true,
    orderIndex: 0,
  },
  {
    id: "col-1789652509357",
    slug: "the-royal-azure-ceylonese-blue-sapphire",
    name: "The Royal Azure: Ceylonese Blue Sapphire",
    image: "/uploads/banners/hero-1789652507558-3na0q0.webp",
    showOnHome: true,
    orderIndex: 1,
  },
  {
    id: "col-1789652518958",
    slug: "the-royal-azure-ceylonese-blue-sapphire",
    name: "The Royal Azure: Ceylonese Blue Sapphire",
    image: "/uploads/banners/hero-1789652518368-qf6d5j.webp",
    showOnHome: true,
    orderIndex: 2,
  },
  {
    id: "col-1789652535473",
    slug: "the-verdant-light-serendib-peridot",
    name: "The Verdant Light: Serendib Peridot",
    image: "/uploads/banners/hero-1789652532829-c60hao.webp",
    showOnHome: true,
    orderIndex: 3,
  },
];

/**
 * Safely parses the CMS JSON collection cards list.
 * Falls back to DEFAULT_COLLECTION_CARDS if invalid or unset.
 */
export function getParsedCollectionCards(rawJson?: string): CMSCollectionCard[] {
  if (rawJson === undefined || rawJson === null || (typeof rawJson === "string" && rawJson.trim() === "")) {
    return DEFAULT_COLLECTION_CARDS;
  }
  try {
    const parsed = typeof rawJson === "string" ? JSON.parse(rawJson) : rawJson;
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed.sort((a, b) => (a.orderIndex ?? 0) - (b.orderIndex ?? 0));
    }
  } catch (err) {
    console.warn("Failed to parse CMS collection cards JSON:", err);
  }
  return DEFAULT_COLLECTION_CARDS;
}

export const COLLECTIONS: Collection[] = [
  {
    id: "col-golden-monarch",
    slug: "the-golden-monarch-ceylon-yellow-sapphire",
    title: "The Golden Monarch: Ceylon Yellow Sapphire",
    tagline: "Radiant Solar Brilliance of Serendib",
    description: "An extraordinary portfolio of unheated, vivid yellow Ceylon sapphires showcasing exceptional clarity, noble golden hues, and artisanal precision faceting.",
    heroImage: "/uploads/banners/hero-1789652484567-ksitkn.webp",
    curatorQuote: "Unheated Ceylon yellow sapphires radiate with an inner brilliance that artificial enhancements could never emulate.",
  },
  {
    id: "col-royal-azure",
    slug: "the-royal-azure-ceylonese-blue-sapphire",
    title: "The Royal Azure: Ceylonese Blue Sapphire",
    tagline: "The Sovereign Velvet Cornflower Spectrum",
    description: "Centuries of royal crowns and sovereign jewels trace back to Sri Lanka's alluvial gravels. Saturated in velvet cornflower and deep royal blue, our Ceylon sapphires are preserved without heat treatment.",
    heroImage: "/uploads/banners/hero-1789652518368-qf6d5j.webp",
    curatorQuote: "A true unheated Ceylon sapphire possesses a crystalline luminosity that artificial heat can never replicate.",
  },
  {
    id: "col-verdant-light",
    slug: "the-verdant-light-serendib-peridot",
    title: "The Verdant Light: Serendib Peridot",
    tagline: "Luminous Chrysolite from Pristine Deposits",
    description: "Exquisite untreated peridots and rare green phenomenal specimens exhibiting electric olive-lime crystals and celestial dispersion.",
    heroImage: "/uploads/banners/hero-1789652532829-c60hao.webp",
    curatorQuote: "Ancient miners called it the gem of the sun for its uncanny ability to maintain vivid luster in dim twilight.",
  },
  {
    id: "col-ceylon-sapphires",
    slug: "ceylon-sapphires",
    title: "The Royal Ceylon Sapphires",
    tagline: "The Unrivaled Azure of Serendib",
    description: "Centuries of royal crowns and sovereign jewels trace back to Sri Lanka's alluvial gravels. Saturated in velvet cornflower and deep royal blue, our Ceylon sapphires are preserved without heat treatment.",
    heroImage: "/uploads/banners/hero-1789651834163-md9w3c.webp",
    curatorQuote: "A true unheated Ceylon sapphire possesses a crystalline luminosity that artificial heat can never replicate.",
  },
  {
    id: "col-rubies",
    slug: "rubies",
    title: "Burmese & Mozambique Rubies",
    tagline: "The Internal Fire of Kings",
    description: "From the legendary Mogok Valley of Burma to the pristine reserves of Montepuez, these untreated corundums exhibit the world-renowned 'Pigeon's Blood' red hue and intense UV fluorescence.",
    heroImage: "/uploads/banners/hero-1789651886835-6o989i.webp",
    curatorQuote: "In ancient Sanskrit, the ruby is 'Ratnaraj' — the king of precious stones.",
  },
  {
    id: "col-colombian-emeralds",
    slug: "colombian-emeralds",
    title: "Muzo & Chivor Emeralds",
    tagline: "The Green Fire of the Andes",
    description: "Unearthed high within the Colombian Andes, Muzo and Chivor emeralds are celebrated for their pure bluish-green crystal and organic botanical inclusions known as 'le jardin'.",
    heroImage: "/uploads/banners/hero-1789651917652-xw752j.webp",
    curatorQuote: "Colombian emeralds possess a distinct warmth born from hydrothermal sedimentary genesis.",
  },
  {
    id: "col-rare-gems",
    slug: "rare-gems",
    title: "Phenomenal & Rare Gems",
    tagline: "Alexandrite, Padparadscha & Paraíba",
    description: "Curated for the ultimate connoisseur: color-changing chrysoberyls, sunset-hued lotus sapphires, and copper-bearing neon electric tourmalines that defy ordinary mineralogy.",
    heroImage: "/uploads/banners/hero-1789652484567-ksitkn.webp",
    curatorQuote: "To hold an untreated 2-carat Padparadscha or Brazilian Alexandrite is to possess a geologic miracle.",
  },
  {
    id: "col-collectors-vault",
    slug: "collectors-vault",
    title: "The Collector's Vault",
    tagline: "Investment-Grade Unheated Masterpieces",
    description: "Exclusively comprising rare natural gemstones exceeding 95+ rarity scores. Suitable for family trusts and private acquisition.",
    heroImage: "/uploads/banners/hero-1789652507558-3na0q0.webp",
    curatorQuote: "Fine colored gemstones have historically outpaced traditional equities as tangible, portable stores of wealth.",
  },
];
