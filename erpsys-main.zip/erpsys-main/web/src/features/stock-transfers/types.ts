export type TransferStatus = 'PENDING' | 'COMPLETED' | 'CANCELLED';

export interface StockTransferItem {
  id: string;
  transferNumber: string;
  transferDate: string;
  status: TransferStatus;
  fromBranchId: string;
  fromBranch?: {
    id: string;
    name: string;
  };
  toBranchId: string;
  toBranch?: {
    id: string;
    name: string;
  };
  totalAmount: number;
  shippingCharges: number;
  notes?: string;
  createdById?: string;
  createdBy?: {
    id: string;
    name: string;
    email: string;
  };
  transferLines: Array<{
    id: string;
    variantId: string;
    quantity: number;
    unitPrice: number;
    subtotal: number;
    variant?: {
      id: string;
      name: string;
      sku: string;
      product?: {
        id: string;
        name: string;
      };
    };
  }>;
  createdAt: string;
  updatedAt: string;
}
