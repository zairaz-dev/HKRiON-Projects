"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Hash,
  ChevronLeft,
  Loader2,
  CheckCircle,
  Save,
  Info,
  Layers,
  ShoppingBag,
  RotateCcw,
  ArrowLeftRight,
  SlidersHorizontal,
  CreditCard,
  Receipt
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { authService } from "@/services/auth-service";
import {
  prefixSettingsService,
  DocumentPrefixData
} from "@/services/prefix-settings-service";

export default function PrefixesSettingsPage() {
  const router = useRouter();

  const [currentUser, setCurrentUser] = useState<any>(null);
  const [businessId, setBusinessId] = useState<string>("");

  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);

  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  const [prefixForm, setPrefixForm] = useState<DocumentPrefixData>({
    purchase: "PO-",
    purchaseReturn: "PR-",
    salesReturn: "RET-",
    stockTransfer: "ST-",
    stockAdjustment: "SA-",
    supplierPayment: "SPAY-",
    supplierAdvance: "SADV-",
    customerPayment: "CPAY-",
    customerAdvance: "CADV-",
    expense: "EXP-",
  });

  useEffect(() => {
    const user = authService.getCurrentUser();
    if (!user || !user.businessId) {
      router.push("/login");
      return;
    }
    setCurrentUser(user);
    setBusinessId(user.businessId);

    loadPrefixes(user.businessId);
  }, []);

  const loadPrefixes = async (bId: string) => {
    setLoading(true);
    setError("");
    try {
      const data = await prefixSettingsService.getPrefixes(bId);
      setPrefixForm(data);
    } catch (err: any) {
      setError(err.message || "Failed to load document prefixes.");
    } finally {
      setLoading(false);
    }
  };

  const showSuccess = (msg: string) => {
    setSuccessMessage(msg);
    setTimeout(() => setSuccessMessage(""), 4000);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      await prefixSettingsService.updatePrefixes({
        ...prefixForm,
        businessId,
      });
      showSuccess("Document prefix settings updated successfully!");
    } catch (err: any) {
      setError(err.message || "Failed to update prefix settings.");
    } finally {
      setSaving(false);
    }
  };

  const prefixFields = [
    {
      key: "salesReturn",
      label: "Sales Return Prefix",
      description: "Custom prefix for Sales Return credit notes",
      icon: RotateCcw,
      sample: (val: string) => `${val || ""}0001`,
    },
    {
      key: "purchase",
      label: "Purchase Order / Invoice Prefix",
      description: "Custom prefix for Purchase invoices",
      icon: ShoppingBag,
      sample: (val: string) => `${val || ""}0001`,
    },
    {
      key: "purchaseReturn",
      label: "Purchase Return Prefix",
      description: "Custom prefix for Purchase Return debit notes",
      icon: RotateCcw,
      sample: (val: string) => `${val || ""}0001`,
    },
    {
      key: "stockTransfer",
      label: "Stock Transfer Prefix",
      description: "Custom prefix for Branch Stock Transfers",
      icon: ArrowLeftRight,
      sample: (val: string) => `${val || ""}0001`,
    },
    {
      key: "stockAdjustment",
      label: "Stock Adjustment Prefix",
      description: "Custom prefix for Inventory Stock Adjustments",
      icon: SlidersHorizontal,
      sample: (val: string) => `${val || ""}0001`,
    },
    {
      key: "supplierAdvance",
      label: "Supplier Advance Prefix",
      description: "Custom prefix for Supplier Advance receipts",
      icon: CreditCard,
      sample: (val: string) => `${val || ""}0001`,
    },
    {
      key: "customerAdvance",
      label: "Customer Advance Prefix",
      description: "Custom prefix for Customer Advance receipts",
      icon: CreditCard,
      sample: (val: string) => `${val || ""}0001`,
    },
    {
      key: "supplierPayment",
      label: "Supplier Payment Prefix",
      description: "Custom prefix for Supplier Bill Payment records",
      icon: Receipt,
      sample: (val: string) => `${val || ""}0001`,
    },
    {
      key: "customerPayment",
      label: "Customer Payment Prefix",
      description: "Custom prefix for Customer Receipt records",
      icon: Receipt,
      sample: (val: string) => `${val || ""}0001`,
    },
    {
      key: "expense",
      label: "Expense Reference Prefix",
      description: "Custom prefix for Expense voucher numbers",
      icon: Layers,
      sample: (val: string) => `${val || ""}0001`,
    },
  ];

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/settings" />
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Glowing Orbs Background */}
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-primary/5 blur-[120px] pointer-events-none z-0" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[550px] h-[550px] rounded-full bg-primary/5 blur-[130px] pointer-events-none z-0" />

        <Navbar title="Document Prefixes" className="relative z-10" />

        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 relative z-10">
          <div className="max-w-4xl mx-auto space-y-6">

            {/* Top Bar Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <button
                  onClick={() => router.push("/settings")}
                  className="inline-flex items-center text-xs font-semibold text-muted-foreground hover:text-primary mb-2 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4 mr-1" /> Back to Settings
                </button>
                <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                  <Hash className="h-7 w-7 text-primary" /> Document Prefixes
                </h1>
                <p className="text-sm text-muted-foreground mt-1">
                  Customize document and transaction number prefixes for all ERP modules.
                </p>
              </div>
            </div>

            {/* Alert Messages */}
            {successMessage && (
              <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 p-3 rounded-lg text-sm flex items-center gap-2 animate-in fade-in">
                <CheckCircle className="w-4 h-4 shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}

            {error && (
              <div className="bg-destructive/10 border border-destructive/30 text-destructive p-3 rounded-lg text-sm flex items-center gap-2 animate-in fade-in">
                <Info className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {loading ? (
              <div className="flex items-center justify-center py-16 text-muted-foreground">
                <Loader2 className="w-6 h-6 animate-spin mr-2 text-primary" /> Loading prefix configurations...
              </div>
            ) : (
              <form onSubmit={handleSave} className="space-y-6 pb-12">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {prefixFields.map((field) => {
                    const Icon = field.icon;
                    const val = (prefixForm as any)[field.key] || "";
                    return (
                      <Card key={field.key} className="border border-border/50 bg-card/20 backdrop-blur-md">
                        <CardContent className="p-4 space-y-2">
                          <div className="flex items-center gap-2">
                            <div className="p-1.5 rounded-md bg-primary/10 text-primary">
                              <Icon className="w-4 h-4" />
                            </div>
                            <div>
                              <h3 className="text-xs font-bold text-foreground">{field.label}</h3>
                              <p className="text-[10px] text-muted-foreground">{field.description}</p>
                            </div>
                          </div>

                          <div className="pt-1">
                            <Input
                              type="text"
                              placeholder="e.g. RET-2026/"
                              value={val}
                              onChange={(e) =>
                                setPrefixForm({
                                  ...prefixForm,
                                  [field.key]: e.target.value,
                                })
                              }
                              className="font-mono text-sm h-10"
                            />
                          </div>

                          <div className="bg-background/80 px-2.5 py-1.5 rounded border border-border/40 flex items-center justify-between text-[11px]">
                            <span className="text-muted-foreground">Sample Number:</span>
                            <span className="font-mono font-bold text-primary">{field.sample(val)}</span>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>

                <div className="flex justify-end pt-4 border-t border-border/60">
                  <Button type="submit" disabled={saving} className="gap-2 min-w-[140px] shadow-md">
                    {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                    Save Prefixes
                  </Button>
                </div>
              </form>
            )}

          </div>
        </main>
      </div>
    </div>
  );
}
