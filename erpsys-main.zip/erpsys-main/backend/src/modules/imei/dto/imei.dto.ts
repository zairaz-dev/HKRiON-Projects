export class CreateImeiItemDto {
  imeiNumber: string;
  productId: string;
  variantId: string;
  branchId: string;
  purchaseLineId?: string;
  purchaseDate?: Date;
  notes?: string;
}

export class BulkAddImeiDto {
  businessId?: string;
  branchId: string;
  productId: string;
  variantId: string;
  imeis: {
    imeiNumber: string;
  }[];
  purchaseLineId?: string;
  notes?: string;
}

export class UpdateImeiStatusDto {
  businessId?: string;
  status: 'IN_STOCK' | 'SOLD' | 'RETURNED' | 'DEFECTIVE' | 'TRANSFERRED';
  saleLineId?: string;
  soldDate?: Date;
  warrantyExpires?: Date;
  notes?: string;
}

export class QueryImeiDto {
  businessId?: string;
  branchId?: string;
  productId?: string;
  variantId?: string;
  status?: string;
  search?: string;
  page?: number;
  limit?: number;
}
