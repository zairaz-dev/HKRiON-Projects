import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { businessService } from "@/services/business-service";
import { queryKeys } from "@/lib/query-keys";
import { BusinessDetails } from "../types";

export function useBusinessQuery(businessId: string) {
  return useQuery<BusinessDetails>({
    queryKey: queryKeys.business.detail(businessId),
    queryFn: () => businessService.getBusinessById(businessId),
    enabled: !!businessId,
  });
}

export function useUpdateBusinessMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Parameters<typeof businessService.updateBusiness>[1] }) =>
      businessService.updateBusiness(id, data),
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.business.detail(variables.id) });
    },
  });
}
