import { Controller, Post, Body, Get, Patch, Delete, Param, Query, UseGuards, Req } from '@nestjs/common';
import { InvoiceSettingsService } from './invoice-settings.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('invoice-settings')
export class InvoiceSettingsController {
  constructor(private readonly invoiceSettingsService: InvoiceSettingsService) {}

  // ==========================================
  // INVOICE SCHEMES
  // ==========================================

  @Get('schemes')
  async getSchemes(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
  ) {
    const user = req.user;
    const bId = user.role === 'super-admin' && businessId ? businessId : user.businessId;
    return this.invoiceSettingsService.getSchemes(bId, branchId);
  }

  @Get('schemes/:id')
  async getSchemeById(@Req() req: any, @Param('id') id: string, @Query('businessId') businessId?: string) {
    const user = req.user;
    const bId = user.role === 'super-admin' && businessId ? businessId : user.businessId;
    return this.invoiceSettingsService.getSchemeById(id, bId);
  }

  @Post('schemes')
  async createScheme(@Req() req: any, @Body() body: any) {
    const user = req.user;
    const bId = user.role === 'super-admin' && body.businessId ? body.businessId : user.businessId;
    return this.invoiceSettingsService.createScheme(bId, body);
  }

  @Patch('schemes/:id')
  async updateScheme(@Req() req: any, @Param('id') id: string, @Body() body: any) {
    const user = req.user;
    const bId = user.role === 'super-admin' && body.businessId ? body.businessId : user.businessId;
    return this.invoiceSettingsService.updateScheme(id, bId, body);
  }

  @Patch('schemes/:id/set-default')
  async setDefaultScheme(@Req() req: any, @Param('id') id: string, @Query('businessId') businessId?: string) {
    const user = req.user;
    const bId = user.role === 'super-admin' && businessId ? businessId : user.businessId;
    return this.invoiceSettingsService.setDefaultScheme(id, bId);
  }

  @Delete('schemes/:id')
  async deleteScheme(@Req() req: any, @Param('id') id: string, @Query('businessId') businessId?: string) {
    const user = req.user;
    const bId = user.role === 'super-admin' && businessId ? businessId : user.businessId;
    return this.invoiceSettingsService.deleteScheme(id, bId);
  }

  // ==========================================
  // INVOICE LAYOUTS
  // ==========================================

  @Get('layouts')
  async getLayouts(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
  ) {
    const user = req.user;
    const bId = user.role === 'super-admin' && businessId ? businessId : user.businessId;
    return this.invoiceSettingsService.getLayouts(bId, branchId);
  }

  @Get('layouts/:id')
  async getLayoutById(@Req() req: any, @Param('id') id: string, @Query('businessId') businessId?: string) {
    const user = req.user;
    const bId = user.role === 'super-admin' && businessId ? businessId : user.businessId;
    return this.invoiceSettingsService.getLayoutById(id, bId);
  }

  @Post('layouts')
  async createLayout(@Req() req: any, @Body() body: any) {
    const user = req.user;
    const bId = user.role === 'super-admin' && body.businessId ? body.businessId : user.businessId;
    return this.invoiceSettingsService.createLayout(bId, body);
  }

  @Patch('layouts/:id')
  async updateLayout(@Req() req: any, @Param('id') id: string, @Body() body: any) {
    const user = req.user;
    const bId = user.role === 'super-admin' && body.businessId ? body.businessId : user.businessId;
    return this.invoiceSettingsService.updateLayout(id, bId, body);
  }

  @Patch('layouts/:id/set-default')
  async setDefaultLayout(@Req() req: any, @Param('id') id: string, @Query('businessId') businessId?: string) {
    const user = req.user;
    const bId = user.role === 'super-admin' && businessId ? businessId : user.businessId;
    return this.invoiceSettingsService.setDefaultLayout(id, bId);
  }

  @Delete('layouts/:id')
  async deleteLayout(@Req() req: any, @Param('id') id: string, @Query('businessId') businessId?: string) {
    const user = req.user;
    const bId = user.role === 'super-admin' && businessId ? businessId : user.businessId;
    return this.invoiceSettingsService.deleteLayout(id, bId);
  }
}
