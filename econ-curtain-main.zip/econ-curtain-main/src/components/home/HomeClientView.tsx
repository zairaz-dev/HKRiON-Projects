"use client";

import { useEffect, useState, useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { motion, useScroll, useTransform, useInView } from "framer-motion";
import Preloader from "@/components/ui/Preloader";
import BeforeAfterSlider from "@/components/ui/BeforeAfterSlider";
import InteractiveSolutions from "@/components/ui/InteractiveSolutions";
import ScrollProcessTimeline from "@/components/ui/ScrollProcessTimeline";
import TestimonialsSlider from "@/components/ui/TestimonialsSlider";
import { HomePageContentData } from "@/services/homepage.service";
import {
  ArrowRight,
  PhoneCall,
  Sparkles,
  Layers,
  Sun,
  ShieldCheck,
  Wrench,
  Award,
} from "lucide-react";

function CountUpNumber({
  end,
  suffix = "",
  duration = 2000,
}: {
  end: number;
  suffix?: string;
  duration?: number;
}) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-40px" });

  useEffect(() => {
    if (!isInView) return;

    let startTime: number | null = null;
    let animationFrameId: number;

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Smooth easeOutExpo curve for realistic acceleration/deceleration
      const easeProgress = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      const currentVal = Math.floor(easeProgress * end);

      setCount(currentVal);

      if (progress < 1) {
        animationFrameId = requestAnimationFrame(animate);
      } else {
        setCount(end);
      }
    };

    animationFrameId = requestAnimationFrame(animate);

    return () => {
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, [isInView, end, duration]);

  return (
    <span ref={ref} className="tabular-nums">
      {count}
      {suffix}
    </span>
  );
}

interface HomeClientViewProps {
  content: HomePageContentData;
}

export default function HomeClientView({ content }: HomeClientViewProps) {
  const heroSlides = [
    {
      image: content.heroSlide1Image || "/hero_banner_1786018413238.png",
      title: content.heroSlide1Title || "Luxury Residential Shading",
      tag: content.heroSlide1Tag || "Villas & Living Spaces",
    },
    {
      image: content.heroSlide2Image || "/gallery_1.png",
      title: content.heroSlide2Title || "Automated Zebra & Blackout Drapery",
      tag: content.heroSlide2Tag || "Interior Precision",
    },
    {
      image: content.heroSlide3Image || "/gallery_2.png",
      title: content.heroSlide3Title || "Anti-Glare Solar Glass Facades",
      tag: content.heroSlide3Tag || "Corporate Offices",
    },
    {
      image: content.heroSlide4Image || "/gallery_3.png",
      title: content.heroSlide4Title || "Motorized Retractable Awnings & Clear PVC",
      tag: content.heroSlide4Tag || "Outdoor Terraces",
    },
  ];

  const [currentSlide, setCurrentSlide] = useState(0);
  const { scrollY } = useScroll();
  const heroY = useTransform(scrollY, [0, 800], [0, 140]);
  const heroOpacity = useTransform(scrollY, [0, 600], [1, 0.2]);

  // Automatic background crossfade slideshow every 5 seconds
  useEffect(() => {
    const slideTimer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 5000);
    return () => clearInterval(slideTimer);
  }, [heroSlides.length]);

  return (
    <div className="flex flex-col w-full overflow-x-hidden bg-slate-950 text-slate-100 selection:bg-amber-500 selection:text-slate-950">
      {/* 00. BRAND PRELOADER INTRO */}
      <Preloader />

      {/* 01. HERO SECTION */}
      <section className="relative min-h-[92vh] md:min-h-screen flex items-center justify-center pt-28 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Background Visual Slideshow with Crossfade Animation */}
        <motion.div
          initial={{ scale: 1.0 }}
          animate={{ scale: 1.0 }}
          transition={{ duration: 2.0, ease: [0.16, 1, 0.3, 1] }}
          style={{ y: heroY }}
          className="absolute inset-0 pointer-events-none"
        >
          {heroSlides.map((slide, index) => (
            <div
              key={index}
              className={`absolute inset-0 bg-cover bg-center bg-no-repeat transition-all duration-1000 ease-in-out ${
                index === currentSlide ? "opacity-100 scale-105" : "opacity-0 scale-100"
              }`}
              style={{ backgroundImage: `url('${slide.image}')` }}
            />
          ))}
        </motion.div>

        {/* Ambient Radial Spotlight Beams */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-150 h-87.5 bg-linear-to-tr from-amber-500/20 via-yellow-400/10 to-transparent blur-3xl pointer-events-none rounded-full" />

        {/* Dark Cinematic Gradient Overlays */}
        <div className="absolute inset-0 bg-linear-to-b from-slate-950/90 via-slate-950/75 to-slate-950 pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,var(--tw-gradient-stops))] from-transparent via-slate-950/60 to-slate-950 pointer-events-none" />

        {/* Hero Main Content */}
        <motion.div
          style={{ opacity: heroOpacity }}
          className="relative z-10 max-w-5xl mx-auto text-center flex flex-col items-center pt-12"
        >
          {/* Main Headline with Glowing Animated Gradient */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold text-white mb-6 leading-[1.1] tracking-tight drop-shadow-2xl max-w-4xl"
          >
            {content.heroTitlePrefix}{" "}
            <span className="text-transparent bg-clip-text bg-linear-to-r from-yellow-400 via-amber-300 to-yellow-500 animate-pulse">
              {content.heroTitleHighlight}
            </span>{" "}
            {content.heroTitleSuffix}
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.25, ease: [0.16, 1, 0.3, 1] }}
            className="text-base sm:text-xl md:text-2xl text-slate-300 mb-10 max-w-3xl leading-relaxed font-light drop-shadow-md"
          >
            {content.heroSubtitle}
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto mb-12"
          >
            <Link
              href={content.heroCtaPrimaryLink || "/contact"}
              className="px-9 py-4 bg-linear-to-r from-primary via-amber-500 to-yellow-500 text-slate-950 rounded-full font-extrabold text-lg hover:brightness-110 transition-all shadow-2xl hover:shadow-amber-500/30 flex items-center justify-center gap-2 group active:scale-95"
            >
              <span>{content.heroCtaPrimaryText || "Get Free Quote"}</span>
              <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link
              href={content.heroCtaSecondaryLink || "#solutions"}
              className="px-9 py-4 bg-slate-900/90 text-white border border-slate-700/80 rounded-full font-semibold text-lg hover:bg-slate-800 transition-colors backdrop-blur-md flex items-center justify-center active:scale-95 shadow-xl"
            >
              {content.heroCtaSecondaryText || "Explore Solutions"}
            </Link>
          </motion.div>

          {/* Interactive Slide Controllers & Counter */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.55, duration: 0.6 }}
            className="flex items-center gap-6 bg-slate-900/80 backdrop-blur-md border border-slate-800 px-5 py-2.5 rounded-full shadow-2xl"
          >
            <div className="flex items-center gap-2">
              {heroSlides.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentSlide(i)}
                  className={`h-2 rounded-full transition-all duration-500 ${
                    i === currentSlide ? "w-8 bg-amber-400" : "w-2 bg-slate-700 hover:bg-slate-500"
                  }`}
                  aria-label={`Slide ${i + 1}`}
                />
              ))}
            </div>

            <div className="text-xs font-black text-slate-300 uppercase tracking-widest flex items-center gap-2">
              <span className="text-amber-400">0{currentSlide + 1}</span>
              <span className="text-slate-600">/</span>
              <span>0{heroSlides.length}</span>
            </div>

            <a href="#solutions" className="text-xs font-bold text-amber-400 hover:underline flex items-center gap-1">
              <span>Scroll</span> ↓
            </a>
          </motion.div>
        </motion.div>
      </section>

      {/* 02. FLOATING BRAND STATEMENT */}
      <section className="py-24 md:py-32 bg-slate-950 px-4 sm:px-6 lg:px-8 border-y border-slate-900 text-center relative overflow-hidden">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-6"
          >
            <span className="text-amber-400 text-xs font-black uppercase tracking-widest block">
              {content.quoteBadge || "Editorial Philosophy"}
            </span>
            <h2 className="text-3xl sm:text-5xl md:text-6xl font-light text-white leading-tight tracking-tight">
              &quot;{content.quoteText}&quot;
            </h2>
            {content.quoteTags && (
              <div className="pt-4 flex justify-center items-center gap-4 text-slate-400 text-sm font-semibold tracking-wider uppercase">
                {content.quoteTags.split("•").map((tag, i, arr) => (
                  <span key={i} className="flex items-center gap-4">
                    <span>{tag.trim()}</span>
                    {i < arr.length - 1 && <span className="text-amber-500">•</span>}
                  </span>
                ))}
              </div>
            )}
          </motion.div>
        </div>
      </section>

      {/* 03. ABOUT SHADEIT */}
      <section className="py-24 md:py-32 bg-slate-900 border-b border-slate-800/80 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left: Featured Image */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="relative rounded-3xl overflow-hidden shadow-2xl border border-slate-700/80 group h-105 sm:h-125"
          >
            <Image
              src={content.aboutImageUrl || "/gallery_1.png"}
              alt={content.aboutTitle || "Designed for the way you live and work"}
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-cover group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-linear-to-t from-slate-950 via-transparent to-transparent opacity-85" />
            <div className="absolute bottom-6 left-6 right-6 p-5 rounded-2xl bg-slate-900/90 backdrop-blur-md border border-white/10 text-white">
              <span className="text-amber-400 text-xs font-bold uppercase tracking-wider block mb-1">
                Featured Architectural Project
              </span>
              <p className="font-semibold text-sm sm:text-base">
                {content.aboutProjectTitle || "Luxury Villa Automated Blackout & Sheer Combination"}
              </p>
            </div>
          </motion.div>

          {/* Right: Editorial Content */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-6"
          >
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-400 text-xs font-bold uppercase tracking-widest">
              <Award size={14} /> {content.aboutBadge || "ABOUT SHADEIT"}
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white leading-tight">
              {content.aboutTitle}
            </h2>
            <div className="w-20 h-1 bg-amber-400 rounded-full" />

            <div className="text-slate-300 text-base sm:text-lg leading-relaxed font-light space-y-4">
              <p>{content.aboutDescription}</p>
              <p>
                Our products add value to your establishment by meeting a wide range of functional needs and offering solutions specially designed for Sri Lanka’s climate. We serve residential, commercial, and corporate clients across the country. Our goal is to ensure the long-term success of our company by earning repeat business and referrals through customer satisfaction, timely completion, attention to detail, and a service-oriented approach.
              </p>
              <p>
                Simply schedule an appointment by phone or email, and our field representatives will visit your site, take the required measurements, and provide you with a quotation. They will also recommend the most suitable options from our wide selection of structures and materials. Our service continues even after installation—the TL Shades after-sales team is always available to assist you with maintenance, repairs, and replacements.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
                <ShieldCheck size={24} className="text-amber-400 shrink-0" />
                <span className="text-sm font-semibold text-slate-200">
                  {content.aboutFeature1 || "Custom Tailored to Fit"}
                </span>
              </div>
              <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
                <Wrench size={24} className="text-amber-400 shrink-0" />
                <span className="text-sm font-semibold text-slate-200">
                  {content.aboutFeature2 || "Professional Installation"}
                </span>
              </div>
            </div>

            <div className="pt-4">
              <Link
                href="/about"
                className="inline-flex items-center gap-2 text-amber-400 font-bold text-lg hover:underline group"
              >
                <span>Learn More About Our Experience</span>
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 04. OUR SOLUTIONS SHOWCASE */}
      <InteractiveSolutions />

      {/* 05. MINIMAL EDITORIAL METRICS STRIP */}
      <section className="py-16 bg-linear-to-r from-slate-900 via-slate-950 to-slate-900 border-y border-slate-800/80 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="grid grid-cols-1 sm:grid-cols-3 gap-8 text-center items-center"
          >
            <div className="space-y-1">
              <div className="text-4xl sm:text-5xl font-black text-transparent bg-clip-text bg-linear-to-r from-yellow-400 to-amber-500">
                <CountUpNumber end={content.stat1Value} suffix={content.stat1Suffix} />
              </div>
              <p className="text-sm font-bold uppercase tracking-wider text-slate-300">{content.stat1Label}</p>
              <p className="text-xs text-slate-500 font-light">{content.stat1Sub}</p>
            </div>

            <div className="space-y-1 sm:border-x sm:border-slate-800 px-4">
              <div className="text-4xl sm:text-5xl font-black text-transparent bg-clip-text bg-linear-to-r from-yellow-400 to-amber-500">
                <CountUpNumber end={content.stat2Value} suffix={content.stat2Suffix} />
              </div>
              <p className="text-sm font-bold uppercase tracking-wider text-slate-300">{content.stat2Label}</p>
              <p className="text-xs text-slate-500 font-light">{content.stat2Sub}</p>
            </div>

            <div className="space-y-1">
              <div className="text-4xl sm:text-5xl font-black text-transparent bg-clip-text bg-linear-to-r from-yellow-400 to-amber-500">
                <CountUpNumber end={content.stat3Value} suffix={content.stat3Suffix} />
              </div>
              <p className="text-sm font-bold uppercase tracking-wider text-slate-300">{content.stat3Label}</p>
              <p className="text-xs text-slate-500 font-light">{content.stat3Sub}</p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 06. BEFORE & AFTER TRANSFORMATION */}
      <section className="py-24 md:py-32 bg-slate-950 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="text-center mb-16"
          >
            <span className="text-amber-400 text-xs font-black uppercase tracking-widest block mb-2">
              See The Real Difference
            </span>
            <h2 className="text-3xl sm:text-5xl font-extrabold text-white mb-4">
              Before & After Transformation
            </h2>
            <div className="w-20 h-1 bg-amber-400 mx-auto rounded-full mb-6" />
            <p className="text-slate-400 max-w-2xl mx-auto text-base sm:text-lg font-light">
              From simple plain windows to beautifully finished, energy-efficient living spaces. Drag the interactive slider below.
            </p>
          </motion.div>

          <BeforeAfterSlider
            beforeImage="/hero_closeup_1786043315815.png"
            afterImage="/gallery_2.png"
            beforeLabel="Plain Window"
            afterLabel="With SHADEIT Blinds"
          />
        </div>
      </section>

      {/* 07. FEATURED PROJECTS */}
      <section className="py-24 md:py-32 bg-slate-900 px-4 sm:px-6 lg:px-8 border-t border-slate-800">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-16 gap-6">
            <div>
              <span className="text-amber-400 text-xs font-black uppercase tracking-widest block mb-2">
                Proven Track Record
              </span>
              <h2 className="text-3xl sm:text-5xl font-extrabold text-white mb-4">
                Featured Projects
              </h2>
              <div className="w-20 h-1 bg-amber-400 rounded-full" />
            </div>
            <Link
              href="/projects"
              className="px-7 py-3 bg-slate-800 text-white rounded-full border border-slate-700 hover:bg-slate-700 transition-colors font-medium text-sm flex items-center gap-2"
            >
              <span>View Full Gallery</span>
              <ArrowRight size={16} />
            </Link>
          </div>

          {/* Asymmetrical Grid */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
            {/* Main Featured Large Card */}
            <motion.div
              data-cursor="VIEW PROJECT"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.15 }}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="md:col-span-7 group relative h-105 sm:h-125 rounded-3xl overflow-hidden cursor-pointer border border-slate-800 shadow-2xl"
            >
              <Image
                src="/gallery_1.png"
                alt="Luxury Residential Villa"
                fill
                sizes="(max-width: 768px) 100vw, 60vw"
                className="object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-linear-to-t from-slate-950 via-slate-950/40 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-8">
                <span className="bg-amber-400/20 text-amber-400 border border-amber-400/40 text-xs font-bold px-3 py-1 rounded-full w-fit mb-3 block">
                  Residential
                </span>
                <h3 className="text-2xl sm:text-3xl font-bold text-white mb-2">
                  Luxury Residential Villa
                </h3>
                <p className="text-slate-300 text-sm font-light leading-relaxed">
                  Motorized zebra blinds and automated sheer drapery across master suites.
                </p>
              </div>
            </motion.div>

            {/* Offset Right Column (2 Stacked Cards) */}
            <div className="md:col-span-5 space-y-8">
              <motion.div
                data-cursor="VIEW PROJECT"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{ duration: 0.8, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
                className="group relative h-59 rounded-3xl overflow-hidden cursor-pointer border border-slate-800 shadow-xl"
              >
                <Image
                  src="/gallery_2.png"
                  alt="Corporate Office"
                  fill
                  sizes="(max-width: 768px) 100vw, 40vw"
                  className="object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-linear-to-t from-slate-950 via-slate-950/40 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <span className="bg-amber-400/20 text-amber-400 border border-amber-400/40 text-xs font-bold px-3 py-1 rounded-full w-fit mb-2 block">
                    Commercial
                  </span>
                  <h3 className="text-xl font-bold text-white mb-1">Corporate Office</h3>
                  <p className="text-slate-300 text-xs font-light">Anti-glare UV sunscreen roller blinds.</p>
                </div>
              </motion.div>

              <motion.div
                data-cursor="VIEW PROJECT"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{ duration: 0.8, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
                className="group relative h-59 rounded-3xl overflow-hidden cursor-pointer border border-slate-800 shadow-xl"
              >
                <Image
                  src="/icon_restaurant_1786043029527.png"
                  alt="Bistro Terrace"
                  fill
                  sizes="(max-width: 768px) 100vw, 40vw"
                  className="object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-linear-to-t from-slate-950 via-slate-950/40 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <span className="bg-amber-400/20 text-amber-400 border border-amber-400/40 text-xs font-bold px-3 py-1 rounded-full w-fit mb-2 block">
                    Hospitality
                  </span>
                  <h3 className="text-xl font-bold text-white mb-1">Bistro Terrace</h3>
                  <p className="text-slate-300 text-xs font-light">Retractable canopy awnings & clear PVC screens.</p>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* 08. INSTALLATION PROCESS */}
      <ScrollProcessTimeline />

      {/* 09. QUALITY MATERIALS STORY */}
      <section className="py-24 md:py-32 bg-linear-to-b from-slate-900 to-slate-950 px-4 sm:px-6 lg:px-8 border-t border-slate-800">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="text-center mb-16"
          >
            <span className="text-amber-400 text-xs font-black uppercase tracking-widest block mb-2">
              Quality You Can Feel
            </span>
            <h2 className="text-3xl sm:text-5xl font-extrabold text-white mb-4">
              Premium Materials & Smart Controls
            </h2>
            <div className="w-20 h-1 bg-amber-400 mx-auto rounded-full mb-6" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
          >
            <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 hover:border-amber-400/50 transition-all flex flex-col items-start shadow-xl">
              <div className="w-14 h-14 rounded-2xl bg-amber-400/10 border border-amber-400/30 flex items-center justify-center text-amber-400 mb-6">
                <Layers size={28} />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Premium Fabric Texture</h3>
              <p className="text-slate-400 text-sm leading-relaxed font-light">
                High-grade UV-resistant, flame-retardant, and easy-clean woven fabrics tested for extreme solar durability.
              </p>
            </div>

            <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 hover:border-amber-400/50 transition-all flex flex-col items-start shadow-xl">
              <div className="w-14 h-14 rounded-2xl bg-amber-400/10 border border-amber-400/30 flex items-center justify-center text-amber-400 mb-6">
                <Sparkles size={28} />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Smart Motorized Control</h3>
              <p className="text-slate-400 text-sm leading-relaxed font-light">
                Silent motor integration fully compatible with Somfy, Alexa, Google Assistant, and home automation hubs.
              </p>
            </div>

            <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 hover:border-amber-400/50 transition-all flex flex-col items-start shadow-xl">
              <div className="w-14 h-14 rounded-2xl bg-amber-400/10 border border-amber-400/30 flex items-center justify-center text-amber-400 mb-6">
                <Sun size={28} />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Weatherproof Outdoor Shield</h3>
              <p className="text-slate-400 text-sm leading-relaxed font-light">
                Heavy-duty architectural aluminum extrusions and marine-grade PVC engineered for tropical storm conditions.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 10. TESTIMONIALS SLIDER */}
      <TestimonialsSlider />

      {/* 11. FINAL HIGH-CONVERSION CINEMATIC CTA */}
      <section className="py-32 bg-linear-to-r from-slate-900 via-slate-950 to-slate-900 border-t border-slate-800 relative overflow-hidden px-4 text-center">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,var(--tw-gradient-stops))] from-amber-500/10 via-transparent to-transparent pointer-events-none" />

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="relative z-10 max-w-4xl mx-auto space-y-6"
        >
          <span className="text-amber-400 text-xs font-black uppercase tracking-widest block">
            {content.ctaBadge || "Elevate Your Living & Working Spaces"}
          </span>
          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white leading-tight tracking-tight">
            {content.ctaTitle}
          </h2>
          <p className="text-slate-300 text-lg sm:text-xl max-w-2xl mx-auto font-light leading-relaxed">
            {content.ctaSubtitle}
          </p>

          <div className="pt-6 flex justify-center">
            <Link
              href={content.ctaButtonLink || "/contact"}
              className="px-10 py-5 bg-linear-to-r from-primary via-amber-500 to-yellow-500 text-slate-950 font-extrabold rounded-full text-lg hover:brightness-110 transition-all shadow-2xl flex items-center justify-center gap-3 active:scale-95"
            >
              <PhoneCall size={22} />
              <span>{content.ctaButtonText || "Get Free Consultation"}</span>
              <ArrowRight size={20} />
            </Link>
          </div>
        </motion.div>
      </section>
    </div>
  );
}
