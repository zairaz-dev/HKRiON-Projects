'use client';
import { useState, useEffect } from 'react';
import { 
  Users, 
  UserPlus, 
  Search, 
  Download, 
  Upload, 
  MessageSquare, 
  Trash2, 
  Edit3, 
  CheckCircle2, 
  AlertCircle, 
  Plus, 
  X, 
  Tag, 
  Phone, 
  Mail, 
  FileText, 
  Sparkles,
  Layers,
  Loader2,
  ExternalLink
} from 'lucide-react';

export default function ContactsManager({ onNavigateToChat }) {
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [selectedTag, setSelectedTag] = useState('all');
  
  // Modals state
  const [showAddModal, setShowAddModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [editingContact, setEditingContact] = useState(null);
  
  // Form State
  const [formNumber, setFormNumber] = useState('');
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formTags, setFormTags] = useState('Customer');
  const [formNotes, setFormNotes] = useState('');
  const [saving, setSaving] = useState(false);
  
  // Import Form State
  const [rawNumbersText, setRawNumbersText] = useState('');
  const [importTag, setImportTag] = useState('Imported Lead');
  const [importing, setImporting] = useState(false);
  const [toast, setToast] = useState(null);

  const fetchContacts = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/contacts');
      if (res.ok) {
        const data = await res.json();
        if (data.contacts) setContacts(data.contacts);
      }
    } catch (err) {
      console.warn('Failed to fetch contacts:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchContacts();
  }, []);

  const showToast = (type, message) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 3500);
  };

  const handleOpenAddModal = (contact = null) => {
    if (contact) {
      setEditingContact(contact);
      setFormNumber(contact.phoneNumber || '');
      setFormName(contact.name || '');
      setFormEmail(contact.email || '');
      setFormTags(Array.isArray(contact.tags) ? contact.tags.join(', ') : 'Customer');
      setFormNotes(contact.notes || '');
    } else {
      setEditingContact(null);
      setFormNumber('');
      setFormName('');
      setFormEmail('');
      setFormTags('Customer');
      setFormNotes('');
    }
    setShowAddModal(true);
  };

  const handleSaveContact = async (e) => {
    e.preventDefault();
    if (!formNumber.trim()) return;

    setSaving(true);
    try {
      const res = await fetch('/api/contacts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phoneNumber: formNumber.trim(),
          name: formName.trim() || `+${formNumber.trim()}`,
          email: formEmail.trim(),
          tags: formTags.split(',').map(t => t.trim()).filter(Boolean),
          notes: formNotes.trim(),
          source: editingContact ? editingContact.source : 'Manual Entry',
        }),
      });

      if (res.ok) {
        showToast('success', editingContact ? 'Contact updated successfully!' : 'New contact saved!');
        setShowAddModal(false);
        await fetchContacts();
      } else {
        const data = await res.json();
        showToast('error', data.error || 'Failed to save contact');
      }
    } catch (err) {
      showToast('error', err.message || 'Error saving contact');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteContact = async (phoneNumber) => {
    if (!confirm(`Are you sure you want to delete contact +${phoneNumber}?`)) return;

    try {
      const res = await fetch('/api/contacts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'delete',
          phoneNumber,
        }),
      });

      if (res.ok) {
        showToast('success', 'Contact deleted');
        setContacts(prev => prev.filter(c => c.phoneNumber !== phoneNumber));
      }
    } catch (err) {
      showToast('error', 'Failed to delete contact');
    }
  };

  const handleBulkImport = async (e) => {
    e.preventDefault();
    if (!rawNumbersText.trim()) return;

    setImporting(true);
    try {
      const lines = rawNumbersText.split('\n');
      const parsedContacts = [];

      lines.forEach((line) => {
        const clean = line.trim();
        if (!clean) return;

        // Support formats like: "Name, 94775014217, email" or just "94775014217"
        if (clean.includes(',')) {
          const parts = clean.split(',').map(p => p.trim());
          if (parts[0] && parts[1]) {
            parsedContacts.push({
              name: parts[0],
              phoneNumber: parts[1].replace(/[^0-9]/g, ''),
              email: parts[2] || '',
              tags: [importTag],
              source: 'Bulk Import',
            });
          }
        } else {
          const num = clean.replace(/[^0-9]/g, '');
          if (num && num.length >= 7) {
            parsedContacts.push({
              name: `+${num}`,
              phoneNumber: num,
              tags: [importTag],
              source: 'Bulk Import',
            });
          }
        }
      });

      const res = await fetch('/api/contacts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'bulk_import',
          contacts: parsedContacts,
          source: 'Bulk List Import',
        }),
      });

      if (res.ok) {
        const data = await res.json();
        showToast('success', `Imported ${data.addedCount || parsedContacts.length} contacts successfully!`);
        setShowImportModal(false);
        setRawNumbersText('');
        await fetchContacts();
      }
    } catch (err) {
      showToast('error', 'Bulk import failed');
    } finally {
      setImporting(false);
    }
  };

  const exportContactsCsv = () => {
    if (contacts.length === 0) return;
    const csvRows = ['Name,Phone Number,Email,Tags,Source,Last Message'];
    contacts.forEach((c) => {
      const name = (c.name || '').replace(/"/g, '""');
      const num = c.phoneNumber || '';
      const email = c.email || '';
      const tags = Array.isArray(c.tags) ? c.tags.join('; ') : '';
      const source = c.source || '';
      const lastMsg = (c.lastMessage || '').replace(/"/g, '""');
      csvRows.push(`"${name}","+${num}","${email}","${tags}","${source}","${lastMsg}"`);
    });

    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `whatsapp_contacts_${Date.now()}.csv`;
    link.click();
  };

  // Filtered contacts
  const allTags = Array.from(new Set(contacts.flatMap(c => c.tags || [])));
  
  const filteredContacts = contacts.filter((c) => {
    const q = search.toLowerCase();
    const matchesSearch = 
      (c.name || '').toLowerCase().includes(q) ||
      (c.phoneNumber || '').includes(q) ||
      (c.email || '').toLowerCase().includes(q) ||
      (c.notes || '').toLowerCase().includes(q);

    if (!matchesSearch) return false;
    if (selectedTag !== 'all') {
      return (c.tags || []).includes(selectedTag);
    }
    return true;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Toast Notification */}
      {toast && (
        <div className={`fixed top-5 right-5 z-50 px-4 py-2.5 rounded-2xl text-xs font-semibold flex items-center gap-2 shadow-2xl backdrop-blur-md animate-fadeIn ${
          toast.type === 'success' ? 'bg-emerald-950/90 border border-emerald-600 text-emerald-300' : 'bg-rose-950/90 border border-rose-600 text-rose-300'
        }`}>
          {toast.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          {toast.message}
        </div>
      )}

      {/* Top Banner Header */}
      <div className="glass-card rounded-3xl p-6 border border-slate-800 bg-gradient-to-r from-emerald-950/40 via-slate-900 to-cyan-950/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 flex items-center justify-center font-bold shadow-lg shadow-emerald-500/20 shrink-0">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-2xl font-heading font-extrabold text-white flex items-center gap-2">
              WhatsApp Contacts Directory
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Manage all your customer WhatsApp numbers, leads, tags, and start instant conversations.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={exportContactsCsv}
            disabled={contacts.length === 0}
            className="bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-xs font-semibold px-3.5 py-2.5 rounded-xl flex items-center gap-1.5 transition-colors disabled:opacity-50"
          >
            <Download className="w-4 h-4" /> Export CSV
          </button>

          <button
            onClick={() => setShowImportModal(true)}
            className="bg-slate-900 hover:bg-slate-800 text-cyan-400 border border-cyan-800/60 text-xs font-semibold px-3.5 py-2.5 rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <Upload className="w-4 h-4" /> Bulk Import
          </button>

          <button
            onClick={() => handleOpenAddModal()}
            className="emerald-glow-btn text-slate-950 font-bold text-xs px-4 py-2.5 rounded-xl flex items-center gap-1.5 shadow-md shadow-emerald-950"
          >
            <UserPlus className="w-4 h-4 fill-slate-950" /> Add Contact
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="glass-card rounded-2xl p-4 border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-semibold">Total Contacts</span>
            <div className="text-xl font-bold text-white mt-1">{contacts.length}</div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-950/60 border border-emerald-800/50 flex items-center justify-center text-emerald-400">
            <Users className="w-5 h-5" />
          </div>
        </div>

        <div className="glass-card rounded-2xl p-4 border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-semibold">Active WhatsApp Chats</span>
            <div className="text-xl font-bold text-cyan-400 mt-1">
              {contacts.filter(c => c.hasActiveChat).length}
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-cyan-950/60 border border-cyan-800/50 flex items-center justify-center text-cyan-400">
            <MessageSquare className="w-5 h-5" />
          </div>
        </div>

        <div className="glass-card rounded-2xl p-4 border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-semibold">Lead Categories</span>
            <div className="text-xl font-bold text-purple-400 mt-1">{allTags.length || 1}</div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-purple-950/60 border border-purple-800/50 flex items-center justify-center text-purple-400">
            <Tag className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Search & Tags Bar */}
      <div className="glass-card rounded-2xl p-4 border border-slate-800 space-y-3">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative flex-1 w-full max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name, phone number, notes..."
              className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-200 outline-none transition-colors"
            />
          </div>

          <span className="text-xs text-slate-400 font-mono">
            {filteredContacts.length} Contacts Found
          </span>
        </div>

        {/* Tag Filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => setSelectedTag('all')}
            className={`px-3 py-1 rounded-lg font-medium transition-colors shrink-0 ${
              selectedTag === 'all'
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 bg-slate-900/60'
            }`}
          >
            All Contacts
          </button>
          {allTags.map((tag) => (
            <button
              key={tag}
              onClick={() => setSelectedTag(tag)}
              className={`px-3 py-1 rounded-lg font-medium transition-colors shrink-0 ${
                selectedTag === tag
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : 'text-slate-400 hover:text-slate-200 bg-slate-900/60'
              }`}
            >
              🏷️ {tag}
            </button>
          ))}
        </div>
      </div>

      {/* Contacts Table */}
      <div className="glass-card rounded-3xl border border-slate-800 overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-semibold border-b border-slate-800">
              <tr>
                <th className="px-5 py-3.5">Contact Name</th>
                <th className="px-5 py-3.5">WhatsApp Number</th>
                <th className="px-5 py-3.5">Tags & Category</th>
                <th className="px-5 py-3.5">Source</th>
                <th className="px-5 py-3.5">Last Message</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {filteredContacts.length === 0 ? (
                <tr>
                  <td colSpan="6" className="text-center py-12 text-slate-500 space-y-2">
                    <Users className="w-10 h-10 mx-auto text-slate-600 opacity-40 mb-2" />
                    <p className="font-semibold text-slate-400">No contacts found in directory.</p>
                    <p className="text-[11px] text-slate-600">Click &quot;Add Contact&quot; or &quot;Bulk Import&quot; to populate your customer database.</p>
                  </td>
                </tr>
              ) : (
                filteredContacts.map((contact) => (
                  <tr key={contact.id || contact.phoneNumber} className="hover:bg-slate-900/40 transition-colors">
                    {/* Name */}
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-slate-800 to-slate-700 border border-slate-700 flex items-center justify-center text-white font-bold text-xs shrink-0 shadow-inner">
                          {contact.name ? contact.name.charAt(0).toUpperCase() : '+'}
                        </div>
                        <div>
                          <div className="font-bold text-white">{contact.name || `+${contact.phoneNumber}`}</div>
                          {contact.email && (
                            <div className="text-[11px] text-slate-400">{contact.email}</div>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* Phone */}
                    <td className="px-5 py-4 font-mono text-emerald-400 font-semibold">
                      +{contact.phoneNumber}
                    </td>

                    {/* Tags */}
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {(contact.tags || ['Customer']).map((t, idx) => (
                          <span 
                            key={idx}
                            className="px-2 py-0.5 rounded-md bg-emerald-950/80 border border-emerald-800/50 text-emerald-400 text-[10px] font-medium"
                          >
                            {t}
                          </span>
                        ))}
                      </div>
                    </td>

                    {/* Source */}
                    <td className="px-5 py-4">
                      <span className="text-[11px] text-slate-400 bg-slate-900 px-2 py-1 rounded border border-slate-800">
                        {contact.source || 'Direct'}
                      </span>
                    </td>

                    {/* Last Message */}
                    <td className="px-5 py-4 max-w-[200px]">
                      <p className="text-[11px] text-slate-400 truncate">
                        {contact.lastMessage || <span className="text-slate-600 italic">No messages yet</span>}
                      </p>
                    </td>

                    {/* Actions */}
                    <td className="px-5 py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {onNavigateToChat && (
                          <button
                            onClick={() => onNavigateToChat(contact.phoneNumber)}
                            className="bg-emerald-950 hover:bg-emerald-900 text-emerald-400 border border-emerald-700/60 p-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
                            title="Chat in Live Inbox"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span className="hidden sm:inline">Chat</span>
                          </button>
                        )}

                        <button
                          onClick={() => handleOpenAddModal(contact)}
                          className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:text-white text-slate-400 transition-colors"
                          title="Edit Contact"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => handleDeleteContact(contact.phoneNumber)}
                          className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:text-rose-400 text-slate-500 transition-colors"
                          title="Delete Contact"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADD / EDIT CONTACT MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
          <div className="bg-[#0f171e] border border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl relative space-y-4">
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-900"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-950 border border-emerald-800 flex items-center justify-center text-emerald-400">
                <UserPlus className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">
                  {editingContact ? 'Edit Contact' : 'Add New Contact'}
                </h3>
                <p className="text-xs text-slate-400">Save WhatsApp customer details for your directory</p>
              </div>
            </div>

            <form onSubmit={handleSaveContact} className="space-y-3.5 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  WhatsApp Phone Number (with Country Code) *
                </label>
                <input
                  type="text"
                  value={formNumber}
                  onChange={(e) => setFormNumber(e.target.value)}
                  placeholder="e.g. 94775014217"
                  disabled={!!editingContact}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 font-mono outline-none disabled:opacity-60"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Full Name / Business Name
                </label>
                <input
                  type="text"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. Ilham Hkr or HKRiON Tech"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Email Address (Optional)
                </label>
                <input
                  type="email"
                  value={formEmail}
                  onChange={(e) => setFormEmail(e.target.value)}
                  placeholder="e.g. customer@example.com"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Tags / Category (Comma separated)
                </label>
                <input
                  type="text"
                  value={formTags}
                  onChange={(e) => setFormTags(e.target.value)}
                  placeholder="e.g. Customer, Website Lead, VIP"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Notes / Business Requirement
                </label>
                <textarea
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="Enter any notes about this customer..."
                  rows={2}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white bg-slate-900 border border-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="emerald-glow-btn text-slate-950 font-bold text-xs px-5 py-2 rounded-xl flex items-center gap-1.5"
                >
                  {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5 fill-slate-950" />}
                  <span>Save Contact</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* BULK IMPORT MODAL */}
      {showImportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
          <div className="bg-[#0f171e] border border-slate-800 rounded-3xl w-full max-w-lg p-6 shadow-2xl relative space-y-4">
            <button
              onClick={() => setShowImportModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-900"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400">
                <Upload className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Bulk Import WhatsApp Numbers</h3>
                <p className="text-xs text-slate-400">Paste phone numbers (one per line) or CSV format</p>
              </div>
            </div>

            <form onSubmit={handleBulkImport} className="space-y-3.5 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Tag for Imported Contacts
                </label>
                <input
                  type="text"
                  value={importTag}
                  onChange={(e) => setImportTag(e.target.value)}
                  placeholder="e.g. Scraped Leads, Marketing Campaign"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl px-3.5 py-2 text-xs text-slate-200 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Paste Numbers (One per line or &quot;Name, Number, Email&quot;)
                </label>
                <textarea
                  value={rawNumbersText}
                  onChange={(e) => setRawNumbersText(e.target.value)}
                  placeholder={`94775014217\n94756655555\nJohn Doe, 919876543210, john@example.com`}
                  rows={6}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 font-mono outline-none"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowImportModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white bg-slate-900 border border-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={importing}
                  className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs px-5 py-2 rounded-xl flex items-center gap-1.5 shadow-lg shadow-cyan-950 transition-colors"
                >
                  {importing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
                  <span>Import Numbers</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
