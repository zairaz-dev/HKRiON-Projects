import { Controller, Post, Body, Get, Param, Query, UseGuards, Req } from '@nestjs/common';
import { SalesReturnsService } from './sales-returns.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('sales-returns')
export class SalesReturnsController {
  constructor(private readonly salesReturnsService: SalesReturnsService) {}

  @Permissions(Permission.SALE_CREATE)
  @Post()
  async createSalesReturn(@Req() req: any, @Body() body: any) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }

    const {
      saleId,
      returnDate,
      businessId,
      refundType,
      reason,
      notes,
      createdById,
      returnLines,
    } = body;

    return this.salesReturnsService.createSalesReturn({
      saleId,
      returnDate: returnDate ? new Date(returnDate) : undefined,
      businessId,
      refundType,
      reason,
      notes,
      createdById: createdById || user.id,
      returnLines,
    });
  }

  @Permissions(Permission.SALE_VIEW)
  @Get()
  async getSalesReturns(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
    @Query('customerId') customerId?: string,
    @Query('search') search?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.salesReturnsService.getSalesReturns(bId, {
      branchId,
      customerId,
      search,
      page: page ? Number(page) : undefined,
      limit: limit ? Number(limit) : undefined,
    });
  }

  @Permissions(Permission.SALE_VIEW)
  @Get(':id')
  async getSalesReturnById(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.salesReturnsService.getSalesReturnById(id, bId);
  }
}

