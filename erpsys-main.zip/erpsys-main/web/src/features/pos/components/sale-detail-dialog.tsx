import React from "react";
import { Dialog } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useSaleByIdQuery } from "../hooks/use-pos";
import { Loader2 } from "lucide-react";
import { useCurrency } from "@/hooks/use-currency";

interface SaleDetailDialogProps {
  isOpen: boolean;
  onClose: () => void;
  saleId: string;
  businessId: string;
}

export function SaleDetailDialog({
  isOpen,
  onClose,
  saleId,
  businessId,
}: SaleDetailDialogProps) {
  const { data: sale, isLoading } = useSaleByIdQuery(saleId, businessId);
  const { symbol, format } = useCurrency(businessId);

  return (
    <Dialog isOpen={isOpen} onClose={onClose} title="Invoice Details" size="lg">
      {isLoading ? (
        <div className="py-12 flex flex-col items-center justify-center gap-2">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
          <p className="text-xs text-muted-foreground">Loading details...</p>
        </div>
      ) : !sale ? (
        <div className="py-8 text-center text-xs text-muted-foreground">
          Failed to load sale details
        </div>
      ) : (
        <div className="space-y-6 py-2">
          {/* Header Row */}
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <p className="text-muted-foreground font-semibold">Invoice No:</p>
              <p className="font-bold text-foreground">{sale.invoiceNumber}</p>
            </div>
            <div>
              <p className="text-muted-foreground font-semibold">Date:</p>
              <p className="font-bold text-foreground">
                {new Date(sale.saleDate).toLocaleString()}
              </p>
            </div>
            <div>
              <p className="text-muted-foreground font-semibold">Customer:</p>
              <p className="font-bold text-foreground">
                {sale.customer?.name || "Walk-in Customer"}
              </p>
            </div>
            <div>
              <p className="text-muted-foreground font-semibold">Branch:</p>
              <p className="font-bold text-foreground">{sale.branch?.name}</p>
            </div>
            {sale.createdBy?.name && (
              <div>
                <p className="text-muted-foreground font-semibold">By:</p>
                <p className="font-bold text-foreground">{sale.createdBy.name}</p>
              </div>
            )}
          </div>

          {/* Items Table */}
          <div className="border border-border/80 rounded bg-background/20 overflow-hidden">
            <table className="w-full text-xs text-left">
              <thead className="bg-muted/40 border-b border-border/60 text-muted-foreground">
                <tr>
                  <th className="p-3">Product</th>
                  <th className="p-3 text-right">Unit Price</th>
                  <th className="p-3 text-center">Qty</th>
                  <th className="p-3 text-right">Discount</th>
                  <th className="p-3 text-right">Tax</th>
                  <th className="p-3 text-right">Subtotal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/40 text-foreground">
                {sale.saleLines?.map((line: any) => (
                  <tr key={line.id}>
                    <td className="p-3 font-semibold">
                      {line.variant?.product?.name || line.variant?.name}
                    </td>
                    <td className="p-3 text-right">{format(line.unitPrice)}</td>
                    <td className="p-3 text-center">{line.quantity}</td>
                    <td className="p-3 text-right">{format(line.discountAmount)}</td>
                    <td className="p-3 text-right">{format(line.taxAmount)}</td>
                    <td className="p-3 text-right font-bold">{format(line.subtotal)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals Summary & Payments */}
          <div className="grid grid-cols-2 gap-6 text-xs border-t border-border pt-4">
            {/* Payments List */}
            <div className="space-y-2">
              <h4 className="font-bold uppercase tracking-wider text-[10px] text-muted-foreground">
                Payment History
              </h4>
              {sale.payments?.length === 0 ? (
                <p className="text-muted-foreground italic">No payments recorded</p>
              ) : (
                <div className="space-y-1.5">
                  {sale.payments?.map((pay: any) => (
                    <div
                      key={pay.id}
                      className="p-2 border border-border/40 rounded bg-background/50 flex justify-between"
                    >
                      <div>
                        <span className="font-semibold block">{pay.paymentMethod?.name}</span>
                        {pay.transactionNo && (
                          <span className="text-[10px] text-muted-foreground block">
                            Ref: {pay.transactionNo}
                          </span>
                        )}
                      </div>
                      <span className="font-bold text-emerald-500">{format(pay.amount)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Subtotal / Net Summary */}
            <div className="space-y-2 text-right">
              <div className="flex justify-between">
                <span className="text-muted-foreground font-semibold">Discount:</span>
                <span className="text-rose-500 font-bold">-{format(sale.discountAmount)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground font-semibold">Tax:</span>
                <span className="text-foreground">{format(sale.taxAmount)}</span>
              </div>
              <div className="flex justify-between font-bold text-sm border-t border-border/40 pt-2 text-foreground">
                <span>Grand Total:</span>
                <span className="text-primary font-black">{format(sale.grandTotal)}</span>
              </div>
              <div className="flex justify-between font-bold">
                <span className="text-muted-foreground">Paid:</span>
                <span className="text-emerald-500">{format(sale.amountPaid)}</span>
              </div>
              {sale.grandTotal - sale.amountPaid > 0 && (
                <div className="flex justify-between font-bold text-rose-500">
                  <span>Due Balance:</span>
                  <span>{format(sale.grandTotal - sale.amountPaid)}</span>
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-border">
            <Button type="button" onClick={onClose} className="h-10 text-sm">
              Close
            </Button>
          </div>
        </div>
      )}
    </Dialog>
  );
}
