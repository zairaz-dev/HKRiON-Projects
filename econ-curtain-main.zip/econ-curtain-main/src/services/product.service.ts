import { db } from "@/core/db/client";
import { products as initialProducts } from "@/data/products";

export interface UpdateProductInput {
  name: string;
  category: string;
  description: string;
  imageUrl: string;
  images?: string[];
  features: string[];
  isActive?: boolean;
}

export class ProductService {
  /**
   * Auto-seeds products if database is empty
   */
  static async ensureSeeded() {
    try {
      const count = await db.product.count();
      if (count === 0) {
        for (const item of initialProducts) {
          await db.product.create({
            data: {
              id: item.id,
              name: item.name,
              category: item.category,
              description: item.description,
              imageUrl: item.image,
              images: JSON.stringify([item.image]),
              features: JSON.stringify(item.features),
              isActive: true,
            },
          });
        }
      }
    } catch (e) {
      console.error("Failed to seed initial products:", e);
    }
  }

  /**
   * Retrieves active products (or all if includeInactive is true) sorted by creation time
   */
  static async getAll(includeInactive = false) {
    await this.ensureSeeded();
    return db.product.findMany({
      where: includeInactive ? undefined : { isActive: true },
      orderBy: { createdAt: "asc" },
    });
  }

  /**
   * Retrieves all products for admin dashboard
   */
  static async getAllForAdmin() {
    await this.ensureSeeded();
    return db.product.findMany({
      orderBy: { createdAt: "asc" },
    });
  }

  /**
   * Retrieves products by category
   */
  static async getByCategory(category: string) {
    await this.ensureSeeded();
    if (!category || category === "All") {
      return this.getAll();
    }
    return db.product.findMany({
      where: { category, isActive: true },
      orderBy: { createdAt: "asc" },
    });
  }

  /**
   * Retrieves a single product by ID
   */
  static async getById(id: string) {
    await this.ensureSeeded();
    return db.product.findUnique({
      where: { id },
    });
  }

  /**
   * Updates an existing product
   */
  static async update(id: string, data: Partial<UpdateProductInput>) {
    return db.product.update({
      where: { id },
      data: {
        ...(data.name && { name: data.name }),
        ...(data.category && { category: data.category }),
        ...(data.description && { description: data.description }),
        ...(data.imageUrl && { imageUrl: data.imageUrl }),
        ...(data.images && { images: JSON.stringify(data.images) }),
        ...(data.features && { features: JSON.stringify(data.features) }),
        ...(typeof data.isActive === "boolean" && { isActive: data.isActive }),
      },
    });
  }

  /**
   * Creates a new product
   */
  static async create(data: UpdateProductInput) {
    return db.product.create({
      data: {
        id: crypto.randomUUID(),
        name: data.name,
        category: data.category,
        description: data.description,
        imageUrl: data.imageUrl || "",
        images: JSON.stringify(data.images || []),
        features: JSON.stringify(data.features || []),
        isActive: data.isActive ?? true,
      },
    });
  }

  /**
   * Deletes a product by ID
   */
  static async delete(id: string) {
    return db.product.delete({
      where: { id },
    });
  }

  /**
   * Returns a distinct list of active categories
   */
  static async getCategories(): Promise<string[]> {
    await this.ensureSeeded();
    try {
      const { CategoryService } = await import("@/services/category.service");
      const categories = await CategoryService.getAll();
      if (categories.length > 0) {
        return categories.map((c) => c.name);
      }
    } catch (e) {
      console.error("Failed to load categories from CategoryService:", e);
    }
    const products = await db.product.findMany({
      select: { category: true },
      distinct: ["category"],
    });
    return products.map((p) => p.category);
  }
}

