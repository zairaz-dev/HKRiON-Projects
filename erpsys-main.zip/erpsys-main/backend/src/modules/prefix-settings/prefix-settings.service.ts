import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class PrefixSettingsService {
  constructor(private readonly prisma: PrismaService) {}

  async getPrefixes(businessId: string) {
    let prefixes = await this.prisma.documentPrefix.findUnique({
      where: { businessId },
    });

    if (!prefixes) {
      prefixes = await this.prisma.documentPrefix.create({
        data: { businessId },
      });
    }

    return prefixes;
  }

  async updatePrefixes(businessId: string, data: any) {
    const {
      purchase,
      purchaseReturn,
      salesReturn,
      stockTransfer,
      stockAdjustment,
      supplierPayment,
      supplierAdvance,
      customerPayment,
      customerAdvance,
      expense,
    } = data;

    return this.prisma.documentPrefix.upsert({
      where: { businessId },
      create: {
        businessId,
        ...(purchase !== undefined && { purchase }),
        ...(purchaseReturn !== undefined && { purchaseReturn }),
        ...(salesReturn !== undefined && { salesReturn }),
        ...(stockTransfer !== undefined && { stockTransfer }),
        ...(stockAdjustment !== undefined && { stockAdjustment }),
        ...(supplierPayment !== undefined && { supplierPayment }),
        ...(supplierAdvance !== undefined && { supplierAdvance }),
        ...(customerPayment !== undefined && { customerPayment }),
        ...(customerAdvance !== undefined && { customerAdvance }),
        ...(expense !== undefined && { expense }),
      },
      update: {
        ...(purchase !== undefined && { purchase }),
        ...(purchaseReturn !== undefined && { purchaseReturn }),
        ...(salesReturn !== undefined && { salesReturn }),
        ...(stockTransfer !== undefined && { stockTransfer }),
        ...(stockAdjustment !== undefined && { stockAdjustment }),
        ...(supplierPayment !== undefined && { supplierPayment }),
        ...(supplierAdvance !== undefined && { supplierAdvance }),
        ...(customerPayment !== undefined && { customerPayment }),
        ...(customerAdvance !== undefined && { customerAdvance }),
        ...(expense !== undefined && { expense }),
      },
    });
  }
}
