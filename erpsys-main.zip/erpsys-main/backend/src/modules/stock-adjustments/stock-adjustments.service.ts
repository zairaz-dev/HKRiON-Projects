import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AdjustmentType } from '@prisma/client';

interface StockAdjustmentLineInput {
  variantId: string;
  quantity: number;
  unitPrice: number;
}

@Injectable()
export class StockAdjustmentsService {
  constructor(private readonly prisma: PrismaService) {}

  async createStockAdjustment(data: {
    adjustmentDate?: Date;
    type: AdjustmentType;
    reason: string;
    branchId: string;
    businessId: string;
    notes?: string;
    createdById?: string;
    adjustmentLines: StockAdjustmentLineInput[];
  }) {
    const {
      adjustmentDate,
      type,
      reason,
      branchId,
      businessId,
      notes,
      createdById,
      adjustmentLines,
    } = data;

    if (!adjustmentLines || adjustmentLines.length === 0) {
      throw new BadRequestException('Stock adjustment must contain at least one item line.');
    }

    if (!reason || !reason.trim()) {
      throw new BadRequestException('Reason for stock adjustment is required.');
    }

    // Verify branch
    const branch = await this.prisma.branch.findFirst({
      where: { id: branchId, businessId },
    });
    if (!branch) {
      throw new NotFoundException('Branch not found.');
    }

    // Generate adjustment number using configured document prefix
    const docPrefix = await this.prisma.documentPrefix.findUnique({
      where: { businessId },
    });
    const prefix = docPrefix?.stockAdjustment || 'SA-';

    const count = await this.prisma.stockAdjustment.count({ where: { businessId } });
    const adjustmentNumber = `${prefix}${String(count + 1).padStart(4, '0')}`;

    return this.prisma.$transaction(async (tx) => {
      let totalAmount = 0;
      const linesToCreate: {
        variantId: string;
        quantity: number;
        unitPrice: number;
        subtotal: number;
      }[] = [];

      for (const line of adjustmentLines) {
        if (line.quantity <= 0) {
          throw new BadRequestException('Adjustment quantity must be greater than zero.');
        }

        // Verify product variant
        const variant = await tx.productVariant.findFirst({
          where: { id: line.variantId, product: { businessId } },
        });

        if (!variant) {
          throw new BadRequestException(`Product variant ID ${line.variantId} not found.`);
        }

        const unitPrice = line.unitPrice > 0 ? line.unitPrice : variant.purchasePrice;
        const subtotal = line.quantity * unitPrice;
        totalAmount += subtotal;

        if (type === AdjustmentType.SUBTRACTION) {
          // FIFO Stock Deduction from available PurchaseLines in branch
          const batches = await tx.purchaseLine.findMany({
            where: {
              variantId: line.variantId,
              branchId,
              quantityRemaining: { gt: 0 },
            },
            orderBy: { createdAt: 'asc' }, // FIFO
          });

          let remainingToDeduct = line.quantity;

          for (const batch of batches) {
            if (remainingToDeduct <= 0) break;

            if (batch.quantityRemaining >= remainingToDeduct) {
              await tx.purchaseLine.update({
                where: { id: batch.id },
                data: {
                  quantityRemaining: { decrement: remainingToDeduct },
                },
              });
              remainingToDeduct = 0;
            } else {
              remainingToDeduct -= batch.quantityRemaining;
              await tx.purchaseLine.update({
                where: { id: batch.id },
                data: { quantityRemaining: 0 },
              });
            }
          }

          if (remainingToDeduct > 0) {
            throw new BadRequestException(
              `Insufficient stock for variant "${variant.name}". Available stock in branch is less than required adjustment quantity ${line.quantity}.`,
            );
          }
        } else if (type === AdjustmentType.ADDITION) {
          // Stock Addition: Create a new inventory batch in PurchaseLine
          const rand = Math.floor(1000 + Math.random() * 9000);
          await tx.purchaseLine.create({
            data: {
              variantId: line.variantId,
              branchId,
              businessId,
              batchNumber: `ADJ-BATCH-${rand}`,
              quantityPurchased: line.quantity,
              quantityRemaining: line.quantity,
              purchasePrice: unitPrice,
              sellingPrice: variant.sellingPrice,
            },
          });
        }

        linesToCreate.push({
          variantId: line.variantId,
          quantity: line.quantity,
          unitPrice,
          subtotal,
        });
      }

      // Create StockAdjustment header
      const stockAdjustment = await tx.stockAdjustment.create({
        data: {
          adjustmentNumber,
          adjustmentDate: adjustmentDate ? new Date(adjustmentDate) : new Date(),
          type,
          reason: reason.trim(),
          totalAmount,
          notes: notes?.trim() || null,
          branchId,
          businessId,
          createdById: createdById || null,
        },
      });

      // Create StockAdjustmentLine entries
      for (const l of linesToCreate) {
        await tx.stockAdjustmentLine.create({
          data: {
            stockAdjustmentId: stockAdjustment.id,
            variantId: l.variantId,
            quantity: l.quantity,
            unitPrice: l.unitPrice,
            subtotal: l.subtotal,
            branchId,
            businessId,
          },
        });
      }

      return stockAdjustment;
    });
  }

  async getStockAdjustments(
    businessId: string,
    filters: {
      branchId?: string;
      type?: AdjustmentType;
      search?: string;
      page?: number;
      limit?: number;
    },
  ) {
    const { branchId, type, search, page = 1, limit = 10 } = filters;
    const skip = (page - 1) * limit;

    const whereClause: any = { businessId };

    if (branchId) {
      whereClause.branchId = branchId;
    }

    if (type) {
      whereClause.type = type;
    }

    if (search) {
      whereClause.OR = [
        { adjustmentNumber: { contains: search, mode: 'insensitive' } },
        { reason: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [total, data] = await Promise.all([
      this.prisma.stockAdjustment.count({ where: whereClause }),
      this.prisma.stockAdjustment.findMany({
        where: whereClause,
        include: {
          branch: {
            select: { id: true, name: true },
          },
          createdBy: {
            select: { id: true, name: true, email: true },
          },
          adjustmentLines: {
            include: {
              variant: {
                select: {
                  id: true,
                  name: true,
                  sku: true,
                  product: {
                    select: { id: true, name: true },
                  },
                },
              },
            },
          },
        },
        orderBy: { adjustmentDate: 'desc' },
        skip,
        take: limit,
      }),
    ]);

    return {
      data,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getStockAdjustmentById(id: string, businessId: string) {
    const adjustment = await this.prisma.stockAdjustment.findFirst({
      where: { id, businessId },
      include: {
        branch: true,
        createdBy: {
          select: { id: true, name: true, email: true },
        },
        adjustmentLines: {
          include: {
            variant: {
              include: {
                product: true,
              },
            },
          },
        },
      },
    });

    if (!adjustment) {
      throw new NotFoundException('Stock adjustment not found.');
    }

    return adjustment;
  }
}
