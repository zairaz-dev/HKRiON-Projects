"use strict";
"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { cmsService, CmsPage } from "@/services/cms-service";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  RotateCcw,
  ShieldCheck,
  Clock,
  ArrowLeft,
  Printer,
  Search,
  CreditCard,
  Building,
  CheckCircle2,
  AlertTriangle,
  Mail,
  Loader2,
  FileText,
  Landmark,
  Sparkles,
  Zap,
} from "lucide-react";

/**
 * Lightweight formatting helper for Markdown content
 */
function MarkdownRenderer({
  content,
  searchFilter = "",
}: {
  content: string;
  searchFilter?: string;
}) {
  const lines = content.split("\n");

  const formatInline = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*|`.*?`)/g);
    return parts.map((part, i) => {
      if (part.startsWith("**") && part.endsWith("**")) {
        return (
          <strong key={i} className="font-bold text-foreground">
            {part.slice(2, -2)}
          </strong>
        );
      }
      if (part.startsWith("`") && part.endsWith("`")) {
        return (
          <code
            key={i}
            className="px-1.5 py-0.5 rounded bg-secondary/80 text-primary font-mono text-[11px]"
          >
            {part.slice(1, -1)}
          </code>
        );
      }
      return part;
    });
  };

  const elements: React.ReactNode[] = [];
  let inList = false;
  let listItems: React.ReactNode[] = [];

  const flushList = () => {
    if (inList && listItems.length > 0) {
      elements.push(
        <ul
          key={`list-${elements.length}`}
          className="space-y-2 my-3 pl-5 list-disc text-xs md:text-sm text-muted-foreground"
        >
          {listItems}
        </ul>
      );
      listItems = [];
      inList = false;
    }
  };

  lines.forEach((line, index) => {
    const trimmed = line.trim();

    if (searchFilter && !trimmed.toLowerCase().includes(searchFilter.toLowerCase())) {
      if (!trimmed.startsWith("#") && trimmed !== "---") return;
    }

    if (trimmed.startsWith("### ")) {
      flushList();
      elements.push(
        <h3
          key={index}
          className="text-sm md:text-base font-bold text-primary mt-6 mb-2 font-mono flex items-center gap-1.5"
        >
          {formatInline(trimmed.replace("### ", ""))}
        </h3>
      );
    } else if (trimmed.startsWith("## ")) {
      flushList();
      const headingText = trimmed.replace("## ", "");
      const anchorId = headingText
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "");

      elements.push(
        <h2
          id={anchorId}
          key={index}
          className="text-base md:text-lg font-bold text-foreground mt-8 mb-3 border-b border-border/50 pb-2 font-mono scroll-mt-24 flex items-center gap-2"
        >
          {formatInline(headingText)}
        </h2>
      );
    } else if (trimmed.startsWith("# ")) {
      flushList();
      elements.push(
        <h1
          key={index}
          className="text-xl md:text-3xl font-extrabold text-foreground mt-4 mb-4 tracking-tight"
        >
          {formatInline(trimmed.replace("# ", ""))}
        </h1>
      );
    } else if (trimmed === "---" || trimmed === "***") {
      flushList();
      elements.push(<hr key={index} className="my-6 border-border/50" />);
    } else if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
      inList = true;
      listItems.push(
        <li key={index} className="leading-relaxed">
          {formatInline(trimmed.slice(2))}
        </li>
      );
    } else if (trimmed.length > 0) {
      flushList();
      elements.push(
        <p
          key={index}
          className="text-xs md:text-sm text-muted-foreground/90 leading-relaxed my-2.5"
        >
          {formatInline(trimmed)}
        </p>
      );
    } else {
      flushList();
    }
  });

  flushList();

  return <div className="space-y-1">{elements}</div>;
}

export default function RefundPolicyPage() {
  const [page, setPage] = useState<CmsPage | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  const fallbackRefundContent = `# Subscription Refund & Cancellation Policy

**Effective Date:** August 31, 2026  
**Operating Entity:** HKRION SYSTEMS (PVT) LTD ("HKRION", "We", "Our", "Us")  
**Product Scope:** HKRION ERP Multi-Tenant SaaS Platform  
**Payment Gateways Covered:** PayHere.lk (Online Gateway) & Direct SaaS Bank Transfer  

---

## 1. 14-Day Risk-Free Free Trial
To ensure complete transparency and satisfaction, **HKRION ERP** offers a **14-day full feature Free Trial** on all newly registered business accounts.
- **No Credit Card Required:** Tenants can explore all POS, IMEI tracking, inventory, multi-branch, and accounting modules without entering payment details.
- **Evaluation Period:** We strongly encourage business owners to test barcode scanners, receipt printers, and multi-branch syncing during this trial period before making any subscription commitment.

---

## 2. Subscription Cancellation & Auto-Renewal Policy
- **Cancel Anytime:** Tenants may cancel their recurring subscription renewal at any time directly through the **Tenant Subscription Portal (\`/settings/subscription\`)**.
- **Active Service Guarantee:** Upon cancellation, your ERP workspace remains **100% active and fully operational** until the conclusion of your current prepaid billing cycle (Monthly or Yearly).
- **No Early Cancellation Penalty:** There are no cancellation fees, penalty charges, or lock-in contracts.

---

## 3. Refund Eligibility & Qualification Criteria
Refunds are evaluated objectively on a case-by-case basis. You are eligible for a **100% full refund** under the following qualifying circumstances:

### A. Accidental Duplicate / Multiple Billing
If a technical timeout or network glitch results in duplicate charges for the same subscription period via PayHere.lk or bank transfer, the duplicate amount will be refunded immediately.

### B. Severe Technical Service Outage (>24h SLA Breach)
If our cloud servers experience an unannounced service disruption exceeding **24 consecutive hours** that prevents your business from executing core POS or inventory operations, you are eligible for a full refund for that billing month.

### C. Incorrect Subscription Tier Charges
If you are billed for an incorrect plan tier or tax rate due to an automated billing discrepancy, we will refund the difference or the full transaction upon request.

### D. Dispute Submission Window
Refund requests must be submitted within **7 calendar days** from the transaction date.

---

## 4. Non-Refundable Scenarios
Refunds cannot be granted in the following scenarios:
- **Change of Mind Beyond 7 Days:** Requests submitted after 7 days of active platform utilization.
- **Account Suspension for Abuse:** If an account is suspended or terminated due to fraudulent activity or violation of our Terms of Service.
- **Third-Party Hardware Incompatibilities:** Unwillingness to use supported POS thermal ESC/POS printers or barcode scanners that meet industry standards.

---

## 5. Refund Processing Timelines & Disbursement Channels
Approved refund claims will be disbursed strictly to the original source of payment:

- 💳 **PayHere.lk Online Payments (Visa, Mastercard, FriMi, Genie, eZ Cash):**  
  Refunds are processed through the PayHere Merchant Gateway and credited back to your original bank card or digital wallet within **5 to 7 business days** (subject to your issuing bank's settlement cycle).

- 🏦 **Direct Bank Transfer Deposits:**  
  Refunds are transferred via direct SLIPS/CEFT deposit to the tenant's verified company bank account within **3 to 5 business days** following validation of the original deposit slip.

---

## 6. Plan Upgrades & Prorated Billing Adjustments
- **Upgrades:** When upgrading to a higher plan mid-cycle, your remaining prepaid days on the lower tier are automatically converted into a monetary credit and deducted from the upgrade fee.
- **Downgrades:** Plan downgrades take effect automatically at the start of your subsequent billing period without forfeiting your active higher-tier quotas prematurely.

---

## 7. How to Submit a Refund Request
To initiate a refund request, please email our Billing & Finance Support Team with the following details:

- 📧 **Billing Support Email:** billing@hkrion.com
- 🏢 **Registered Business Name:** (e.g. Apex Mobile, Colombo)
- 🧾 **Invoice / Receipt Number:** (e.g. INV-2026-0089)
- 💳 **Payment Reference:** PayHere Order ID or Bank Deposit Slip copy
- 📝 **Reason for Refund Request:** Brief description of the issue encountered

---

## 8. Billing Inquiries & Dispute Resolution Contact
For any questions regarding billing statements, invoice copies, or payment confirmations, contact our dedicated billing support desk:

- 📧 **Email:** billing@hkrion.com
- 🛠️ **Customer Care Hotline:** +94 77 123 4567
- 🏢 **Operating Entity:** HKRION SYSTEMS (PVT) LTD
- 📍 **Headquarters:** Colombo, Sri Lanka`;

  useEffect(() => {
    loadRefundContent();
  }, []);

  const loadRefundContent = async () => {
    setIsLoading(true);
    try {
      const data = await cmsService.getPublicPage("refund");
      if (data) setPage(data);
    } catch {
      // Use fallback
    } finally {
      setIsLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const contentToRender = page?.content || fallbackRefundContent;

  const quickNav = [
    { title: "1. 14-Day Free Trial", id: "1-14-day-risk-free-free-trial" },
    { title: "2. Cancellation & Auto-Renewal", id: "2-subscription-cancellation-auto-renewal-policy" },
    { title: "3. Refund Eligibility Criteria", id: "3-refund-eligibility-qualification-criteria" },
    { title: "4. Non-Refundable Scenarios", id: "4-non-refundable-scenarios" },
    { title: "5. Refund Timelines & Channels", id: "5-refund-processing-timelines-disbursement-channels" },
    { title: "6. Upgrades & Prorations", id: "6-plan-upgrades-prorated-billing-adjustments" },
    { title: "7. Submit a Refund Request", id: "7-how-to-submit-a-refund-request" },
    { title: "8. Billing Dispute Support", id: "8-billing-inquiries-dispute-resolution-contact" },
  ];

  return (
    <div className="bg-transparent text-foreground flex flex-col justify-between selection:bg-emerald-500/30 selection:text-emerald-400">
      {/* Main Container */}
      <main className="max-w-7xl w-full mx-auto px-4 sm:px-6 py-4 relative z-10">
        {/* Breadcrumb / Top Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-border/60">
          <div className="flex items-center gap-2">
            <Link
              href="/"
              className="text-xs font-mono font-bold text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"
            >
              <ArrowLeft className="w-4 h-4 text-primary" /> Home
            </Link>
            <span className="text-muted-foreground/40 font-mono">/</span>
            <span className="text-xs font-mono text-primary font-bold">Refund Policy</span>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrint}
              className="text-xs h-8 gap-1.5 font-mono border-border"
            >
              <Printer className="w-3.5 h-3.5 text-primary" /> Print / Save PDF
            </Button>
          </div>
        </div>

        {/* Hero Banner Card */}
        <div className="pt-8 pb-6">
          <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border border-primary/20 rounded-sm p-6 md:p-8 space-y-3 relative overflow-hidden">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 text-[11px] font-mono text-primary font-bold bg-primary/15 border border-primary/30 px-3 py-1 rounded-sm">
                <RotateCcw className="w-3.5 h-3.5" /> Official Billing & Refund Policy
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] font-mono text-muted-foreground bg-secondary/80 px-2.5 py-1 rounded-sm">
                <Sparkles className="w-3 h-3 text-amber-400" /> 14-Day Free Trial Protection
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] font-mono text-primary bg-primary/10 border border-primary/20 px-2.5 py-1 rounded-sm">
                <CreditCard className="w-3 h-3 text-primary" /> PayHere & Bank Transfer Covered
              </span>
            </div>

            <h1 className="text-2xl md:text-4xl font-extrabold text-foreground tracking-tight">
              Subscription Refund & Cancellation Policy
            </h1>
            <p className="text-xs md:text-sm text-muted-foreground max-w-3xl leading-relaxed">
              We stand behind our platform with a risk-free 14-day evaluation, transparent cancellations with zero penalties, and verified automated dispute resolution for all subscription checkouts.
            </p>

            <div className="flex flex-wrap items-center gap-4 text-[11px] font-mono text-muted-foreground/80 pt-2">
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-400" /> Effective Date: August 31, 2026
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Building className="w-3.5 h-3.5 text-primary" /> Operating Entity: HKRION SYSTEMS (PVT) LTD
              </span>
            </div>
          </div>
        </div>

        {/* Layout: Sticky Quick Nav (Left) + Content (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pt-4 items-start">
          {/* Left Column: Quick-Jump Table of Contents & Keyword Search */}
          <aside className="lg:col-span-4 lg:sticky lg:top-24 space-y-4">
            {/* Search Input */}
            <Card className="bg-card/40 backdrop-blur-md border-border/60 rounded-sm">
              <CardContent className="p-4 space-y-2">
                <label className="text-[10px] font-mono font-bold uppercase text-muted-foreground">
                  Search Refund Terms
                </label>
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-muted-foreground" />
                  <Input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="e.g. 7 Days, PayHere, Bank..."
                    className="pl-8 h-8 text-xs font-mono rounded-sm"
                  />
                </div>
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery("")}
                    className="text-[10px] text-primary hover:underline font-mono"
                  >
                    Clear Filter
                  </button>
                )}
              </CardContent>
            </Card>

            {/* Quick Jump Links */}
            <Card className="bg-card/40 backdrop-blur-md border-border/60 rounded-sm">
              <CardContent className="p-5 space-y-3">
                <div className="text-xs font-bold font-mono text-foreground uppercase tracking-wider flex items-center gap-1.5 border-b border-border/50 pb-2">
                  <FileText className="w-3.5 h-3.5 text-primary" /> Quick Navigation
                </div>

                <nav className="space-y-1 text-xs font-mono">
                  {quickNav.map((item, idx) => (
                    <a
                      key={idx}
                      href={`#${item.id}`}
                      className="block py-1.5 px-2 rounded-sm hover:bg-secondary/60 text-muted-foreground hover:text-primary transition-colors text-[11px]"
                    >
                      {item.title}
                    </a>
                  ))}
                </nav>
              </CardContent>
            </Card>

            {/* Guarantee Summary Widget */}
            <Card className="bg-card/30 border-border/50 p-4 space-y-2.5 text-xs rounded-sm">
              <div className="text-[10px] font-mono font-bold uppercase text-muted-foreground">
                Billing Highlights
              </div>
              <div className="space-y-2 text-[11px] text-muted-foreground">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0" />
                  <span>14-Day Free Trial (No Card Needed)</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0" />
                  <span>Cancel Anytime With 0 Penalties</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0" />
                  <span>Full Duplicate Payment Refund</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0" />
                  <span>PayHere Card & Bank SLIPS Refunds</span>
                </div>
              </div>
            </Card>
          </aside>

          {/* Right Column: Refund Policy Body */}
          <section className="lg:col-span-8">
            <Card className="bg-card/40 backdrop-blur-md border-border/60 shadow-xl overflow-hidden rounded-sm">
              <CardContent className="p-6 md:p-10">
                {isLoading ? (
                  <div className="p-12 text-center text-muted-foreground">
                    <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-primary" />
                    <p className="text-xs font-mono">Loading verified refund terms...</p>
                  </div>
                ) : (
                  <div className="prose prose-invert max-w-none text-xs md:text-sm leading-relaxed text-foreground/90 font-sans">
                    <MarkdownRenderer
                      content={contentToRender}
                      searchFilter={searchQuery}
                    />
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Billing Dispute Callout */}
            <div className="mt-6 p-6 rounded-sm bg-secondary/30 border border-border/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h4 className="text-sm font-bold text-foreground">Need Assistance with a Billing Invoice?</h4>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Our Billing & Financial Dispute team responds within 24 hours.
                </p>
              </div>
              <a href="mailto:billing@hkrion.com">
                <Button size="sm" className="text-xs h-8 font-bold font-mono gap-1.5 rounded-sm">
                  <Mail className="w-3.5 h-3.5" /> Submit Billing Inquiry
                </Button>
              </a>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
