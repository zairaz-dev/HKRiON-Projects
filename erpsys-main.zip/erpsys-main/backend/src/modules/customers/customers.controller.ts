import {
  Controller,
  Get,
  Post,
  Body,
  Put,
  Param,
  Delete,
  Query,
  UseInterceptors,
  UploadedFile,
  BadRequestException,
  UseGuards,
  Req,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { getImageUploadOptions } from '../../common/utils/upload.util';
import { CustomersService } from './customers.service';
import { CreateCustomerDto } from './dto/create-customer.dto';
import { UpdateCustomerDto } from './dto/update-customer.dto';
import {
  ApiTags,
  ApiOperation,
  ApiBody,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiQuery,
} from '@nestjs/swagger';
import {
  CreateCustomerBodySchema,
  UpdateCustomerBodySchema,
  CustomerResponseSchema,
} from '../../docs/customers.docs';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';

@ApiTags('Customers')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('customers')
export class CustomersController {
  constructor(private readonly customersService: CustomersService) {}

  @Permissions(Permission.CUSTOMER_CREATE)
  @Post('upload-image')
  @UseInterceptors(FileInterceptor('image', getImageUploadOptions('customers')))
  async uploadImage(@UploadedFile() file: any) {
    if (!file) {
      throw new BadRequestException('No image file provided');
    }
    const imageUrl = `/uploads/customers/${file.filename}`;
    return { imageUrl };
  }

  @Permissions(Permission.USER_MANAGE)
  @Post(':id/upload-image')
  @UseInterceptors(FileInterceptor('image', getImageUploadOptions('customers')))
  async uploadCustomerImageForId(
    @Param('id') id: string,
    @UploadedFile() file: any,
  ) {
    if (!file) {
      throw new BadRequestException('No image file provided');
    }
    const imageUrl = `/uploads/customers/${file.filename}`;
    await this.customersService.update(id, { image: imageUrl });
    return { imageUrl };
  }

  @Permissions(Permission.CUSTOMER_CREATE)
  @Post()
  @ApiOperation({ summary: 'Create new customer' })
  @ApiBody({ schema: CreateCustomerBodySchema })
  @ApiResponse({
    status: 201,
    description: 'Customer created successfully',
    schema: CustomerResponseSchema,
  })
  create(@Req() req: any, @Body() createDto: CreateCustomerDto) {
    const user = req.user;
    if (user && (user.role !== 'super-admin' || !createDto.businessId)) {
      createDto.businessId = user.businessId;
    }
    if (user && !createDto.createdById) {
      createDto.createdById = user.id;
    }
    return this.customersService.create(createDto);
  }

  @Permissions(Permission.CUSTOMER_VIEW)
  @Get()
  @ApiOperation({ summary: 'Get list of customers' })
  @ApiQuery({ name: 'businessId', required: true, type: String })
  @ApiQuery({ name: 'branchId', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Customers retrieved successfully' })
  findAll(
    @Req() req: any,
    @Query('businessId') businessId: string,
    @Query('branchId') branchId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user && user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.customersService.findAll(bId, branchId);
  }

  @Permissions(Permission.CUSTOMER_VIEW)
  @Get(':id')
  @ApiOperation({ summary: 'Get customer details by ID' })
  @ApiParam({ name: 'id', description: 'Customer UUID' })
  @ApiQuery({ name: 'businessId', required: true, type: String })
  @ApiResponse({
    status: 200,
    description: 'Customer retrieved successfully',
    schema: CustomerResponseSchema,
  })
  findOne(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user && user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.customersService.findOne(id, bId);
  }

  @Permissions(Permission.USER_MANAGE)
  @Put(':id')
  @ApiOperation({ summary: 'Update customer details' })
  @ApiParam({ name: 'id', description: 'Customer UUID' })
  @ApiBody({ schema: UpdateCustomerBodySchema })
  @ApiResponse({
    status: 200,
    description: 'Customer updated successfully',
    schema: CustomerResponseSchema,
  })
  update(
    @Req() req: any,
    @Param('id') id: string,
    @Body() updateDto: UpdateCustomerDto,
  ) {
    const user = req.user;
    if (user && (user.role !== 'super-admin' || !updateDto.businessId)) {
      updateDto.businessId = user.businessId;
    }
    if (user && !updateDto.updatedById) {
      updateDto.updatedById = user.id;
    }
    return this.customersService.update(id, updateDto);
  }

  @Permissions(Permission.USER_MANAGE)
  @Delete(':id')
  @ApiOperation({ summary: 'Delete customer' })
  @ApiParam({ name: 'id', description: 'Customer UUID' })
  @ApiQuery({ name: 'businessId', required: true, type: String })
  @ApiResponse({ status: 200, description: 'Customer deleted successfully' })
  remove(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user && user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.customersService.remove(id, bId);
  }
}
