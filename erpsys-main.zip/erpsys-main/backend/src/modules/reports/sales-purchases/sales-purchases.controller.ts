import { Controller, Get, Query, UseGuards, Req } from '@nestjs/common';
import { SalesPurchasesService } from './sales-purchases.service';
import { JwtAuthGuard } from '../../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { PermissionsGuard } from '../../../common/guards/permissions.guard';
import { Permissions } from '../../../common/decorators/permissions.decorator';
import { Permission } from '../../../common/enums/permission.enum';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('reports/sales-purchases')
export class SalesPurchasesController {
  constructor(private readonly salesPurchasesService: SalesPurchasesService) {}

  @Permissions(Permission.REPORT_VIEW)
  @Get()
  async getSalesPurchaseSummary(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
    @Query('branchId') branchId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.salesPurchasesService.getSalesPurchaseSummary(bId, {
      startDate: startDate ? new Date(startDate) : undefined,
      endDate: endDate ? new Date(endDate) : undefined,
      branchId,
    });
  }
}

