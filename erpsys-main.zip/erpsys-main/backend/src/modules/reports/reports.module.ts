import { Module } from '@nestjs/common';
import { ProfitLossModule } from './profit-loss/profit-loss.module';
import { StockValuationModule } from './stock-valuation/stock-valuation.module';
import { SalesPurchasesModule } from './sales-purchases/sales-purchases.module';
import { ContactBalancesModule } from './contact-balances/contact-balances.module';

@Module({
  imports: [
    ProfitLossModule,
    StockValuationModule,
    SalesPurchasesModule,
    ContactBalancesModule,
  ],
  exports: [
    ProfitLossModule,
    StockValuationModule,
    SalesPurchasesModule,
    ContactBalancesModule,
  ],
})
export class ReportsModule {}
