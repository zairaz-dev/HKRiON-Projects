import type { Metadata, Viewport } from "next";
import "@/styles/globals.css";
import { CurrencyProvider } from "@/features/currency/context/CurrencyContext";
import { CartProvider } from "@/features/cart/context/CartContext";
import { WishlistProvider } from "@/features/wishlist/context/WishlistContext";
import { AuthProvider } from "@/features/auth/context/AuthContext";
import { ToastProvider } from "@/components/ui/LuxuryToast";
import PwaRegister from "@/components/ui/PwaRegister";
import PwaInstallPrompt from "@/components/ui/PwaInstallPrompt";
import { getCMSData } from "@/lib/cms/server";
import { CMSProvider } from "@/features/cms/useCMS";

export const viewport: Viewport = {
  themeColor: "#000000",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export const metadata: Metadata = {
  title: "Faizan Gems | Haute Gemmologie • Rare Natural Certified Gemstones",
  description: "Curator of extraordinary unheated Ceylon sapphires, Burmese rubies, Muzo Colombian emeralds, and rare phenomenal gems. Certified by GIA, Gübelin, SSEF, and GRS with armored insured delivery worldwide.",
  keywords: [
    "Faizan Gems",
    "Natural Ceylon Sapphire",
    "Unheated Blue Sapphire",
    "Burmese Pigeon Blood Ruby",
    "Colombian Muzo Emerald",
    "Padparadscha Sapphire",
    "Natural Gemstones",
    "Ceylon Sapphires",
    "Natural Rubies",
    "Haute Joaillerie",
    "Rare Natural Gemstones"
  ],
  openGraph: {
    title: "Faizan Gems | Haute Gemmologie",
    description: "Extraordinary unheated natural colored gemstones directly sourced from premier mines.",
    url: "https://faizangems.com",
    siteName: "Faizan Gems",
    locale: "en_US",
    type: "website",
  },
  icons: {
    icon: [
      { url: "/favicon/favicon.ico" },
      { url: "/favicon/favicon-16x16.png", sizes: "16x16", type: "image/png" },
      { url: "/favicon/favicon-32x32.png", sizes: "32x32", type: "image/png" },
    ],
    shortcut: ["/favicon/favicon.ico"],
    apple: [
      { url: "/favicon/apple-touch-icon.png", sizes: "180x180", type: "image/png" },
    ],
  },
  manifest: "/favicon/site.webmanifest",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "Faizan Gems",
  },
  formatDetection: {
    telephone: false,
  },
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const cmsData = await getCMSData();

  return (
    <html lang="en" className="h-full antialiased bg-black text-[#18181D]">
      <body className="min-h-full flex flex-col font-sans selection:bg-[#C5A880] selection:text-[#0D0D11]">
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600;700&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Outfit:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,400..800;1,400..800&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap"
          rel="stylesheet"
          precedence="default"
        />
        <AuthProvider>
          <ToastProvider>
            <CurrencyProvider>
              <CartProvider>
                <WishlistProvider>
                  <CMSProvider initialData={cmsData}>
                    {children}
                    <PwaInstallPrompt />
                    <PwaRegister />
                  </CMSProvider>
                </WishlistProvider>
              </CartProvider>
            </CurrencyProvider>
          </ToastProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
