import { NextResponse } from "next/server";
import { HomePageService } from "@/services/homepage.service";
import { SessionManager } from "@/core/auth/session";
import { SafeHttp } from "@/core/http/redirect";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  try {
    const session = await SessionManager.getCurrentSession();
    if (!session) {
      return SafeHttp.redirect("/login", request, 303);
    }

    const contentType = request.headers.get("content-type") || "";
    const isJson = contentType.includes("application/json");

    let payload: Record<string, string | number> = {};

    if (isJson) {
      payload = await request.json();
    } else {
      const formData = await request.formData();
      formData.forEach((value, key) => {
        if (key.startsWith("stat") && key.endsWith("Value")) {
          payload[key] = parseInt(value as string, 10) || 0;
        } else {
          payload[key] = value.toString();
        }
      });
    }

    await HomePageService.updateContent(payload);

    // Revalidate paths so updates are visible instantly
    revalidatePath("/");
    revalidatePath("/admin/homepage");
    revalidatePath("/admin");

    if (isJson) {
      return NextResponse.json({ success: true, message: "Home page content updated successfully!" });
    }

    return SafeHttp.redirect(
      `/admin/homepage?success=${encodeURIComponent("Home page content updated successfully!")}`,
      request,
      303
    );
  } catch (error: unknown) {
    console.error("Failed to update home page content:", error);
    return SafeHttp.redirect(
      `/admin/homepage?error=${encodeURIComponent("Failed to update home page content")}`,
      request,
      303
    );
  }
}
