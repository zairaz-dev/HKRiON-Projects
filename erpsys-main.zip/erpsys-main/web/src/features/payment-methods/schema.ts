import { z } from 'zod';

export const paymentMethodFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  code: z
    .string()
    .min(2, "Code must be at least 2 characters")
    .toLowerCase()
    .regex(/^[a-z0-9_]+$/, "Code must be lowercase and alphanumeric (underscores allowed)"),
  description: z.string(),
  sortOrder: z.number(),
  branchIds: z.array(z.string()),
});

export type PaymentMethodFormData = z.infer<typeof paymentMethodFormSchema>;
