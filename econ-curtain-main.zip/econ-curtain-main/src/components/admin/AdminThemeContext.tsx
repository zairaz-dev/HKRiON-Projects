"use client";

import React, { createContext, useContext, useEffect, useState, useTransition } from "react";

type Theme = "dark" | "light";

interface AdminThemeContextType {
  theme: Theme;
  toggleTheme: () => void;
  setTheme: (theme: Theme) => void;
  mounted: boolean;
}

const AdminThemeContext = createContext<AdminThemeContextType>({
  theme: "dark",
  toggleTheme: () => {},
  setTheme: () => {},
  mounted: false,
});

export function AdminThemeProvider({ children }: { children: React.ReactNode }) {
  // Default to dark mode as required
  const [theme, setThemeState] = useState<Theme>("dark");
  const [mounted, setMounted] = useState(false);
  const [, startTransition] = useTransition();

  useEffect(() => {
    try {
      const savedTheme = localStorage.getItem("shadeit_admin_theme") as Theme | null;
      if (savedTheme === "light" || savedTheme === "dark") {
        setThemeState(savedTheme);
      } else {
        // Default to dark mode
        setThemeState("dark");
        localStorage.setItem("shadeit_admin_theme", "dark");
      }
    } catch {
      // fallback
    }
    setMounted(true);
  }, []);

  const setTheme = (newTheme: Theme) => {
    startTransition(() => {
      setThemeState(newTheme);
      try {
        localStorage.setItem("shadeit_admin_theme", newTheme);
        document.cookie = `shadeit_admin_theme=${newTheme}; path=/; max-age=31536000; SameSite=Lax`;
      } catch {
        // ignore
      }
    });
  };

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  return (
    <AdminThemeContext.Provider value={{ theme, toggleTheme, setTheme, mounted }}>
      <div
        id="admin-theme-root"
        className={theme === "dark" ? "dark admin-dark" : "light admin-light"}
        data-admin-theme={theme}
      >
        {children}
      </div>
    </AdminThemeContext.Provider>
  );
}

export function useAdminTheme() {
  return useContext(AdminThemeContext);
}
