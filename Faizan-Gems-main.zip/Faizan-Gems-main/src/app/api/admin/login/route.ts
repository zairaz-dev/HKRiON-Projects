import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import {
  createSessionToken,
  SESSION_COOKIE_NAME,
  verifyPassword,
  timingSafeCompare,
} from "@/lib/auth";
import { pool } from "@/lib/db";
import { RowDataPacket } from "mysql2";

import { getClientIp } from "@/lib/request-ip";

// Brute-force & Rate Guard Store
interface LoginAttemptRecord {
  failures: number;
  lockedUntil: number;
}
const loginAttempts = new Map<string, LoginAttemptRecord>();

const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 5 * 60 * 1000; // 5 minutes

function getClientIdentifier(request: Request, email: string): string {
  const ip = getClientIp(request);
  return `${ip}::${email.trim().toLowerCase()}`;
}

function pruneLoginAttempts(now: number): void {
  if (loginAttempts.size > 1000) {
    for (const [key, record] of loginAttempts.entries()) {
      if (record.lockedUntil <= now) {
        loginAttempts.delete(key);
      }
    }
  }
}

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json();

    if (!email || typeof email !== "string" || !password || typeof password !== "string") {
      return NextResponse.json(
        { error: "Email and password are required" },
        { status: 400 }
      );
    }

    const normalizedEmail = email.trim().toLowerCase();
    const clientKey = getClientIdentifier(request, normalizedEmail);
    const now = Date.now();
    pruneLoginAttempts(now);

    // 1. Check Rate-Limiting Lockout
    const attemptRecord = loginAttempts.get(clientKey);
    if (attemptRecord && attemptRecord.lockedUntil > now) {
      const waitSeconds = Math.ceil((attemptRecord.lockedUntil - now) / 1000);
      return NextResponse.json(
        {
          error: `Vault access locked due to consecutive failed attempts. Please wait ${waitSeconds} seconds.`,
          locked: true,
          retryAfter: waitSeconds,
        },
        { status: 429, headers: { "Retry-After": waitSeconds.toString() } }
      );
    }

    const adminEmail = process.env.ADMIN_EMAIL ? process.env.ADMIN_EMAIL.trim().toLowerCase() : null;

    let isValid = false;
    let userName = "Admin";

    // 2. Check MySQL users table — bcrypt verify only
    try {
      const [rows] = await pool.query<RowDataPacket[]>(
        "SELECT name, email, password_hash, role FROM users WHERE email = ? AND role = 'ADMIN' LIMIT 1",
        [normalizedEmail]
      );
      if (rows && rows.length > 0) {
        const user = rows[0];
        // Only bcrypt comparison — no plain text or env bypass
        const passwordMatch = await verifyPassword(password, user.password_hash);
        if (passwordMatch) {
          isValid = true;
          userName = user.name || "Admin";
        }
      }
    } catch (dbErr) {
      console.error("Database user check error:", dbErr);
    }

    // 3. Fallback: only if DB check didn't match and env fallback is configured
    if (!isValid && adminEmail && timingSafeCompare(normalizedEmail, adminEmail)) {
      const adminPasswordHash = process.env.ADMIN_PASSWORD_HASH;
      if (adminPasswordHash) {
        const match = await verifyPassword(password, adminPasswordHash);
        if (match) {
          isValid = true;
          userName = process.env.ADMIN_NAME || "Admin";
        }
      }
    }

    // 4. Handle Failed Attempt (Rate Limiting)
    if (!isValid) {
      const current = loginAttempts.get(clientKey) || { failures: 0, lockedUntil: 0 };
      const newFailures = current.failures + 1;
      const willLock = newFailures >= MAX_FAILED_ATTEMPTS;

      loginAttempts.set(clientKey, {
        failures: newFailures,
        lockedUntil: willLock ? now + LOCKOUT_DURATION_MS : 0,
      });

      const remaining = Math.max(0, MAX_FAILED_ATTEMPTS - newFailures);
      return NextResponse.json(
        {
          error: willLock
            ? "Too many failed attempts. Vault locked for 5 minutes."
            : `Invalid vault authorization credentials. ${remaining} attempt(s) remaining.`,
          remainingAttempts: remaining,
        },
        { status: 401 }
      );
    }

    // 5. Success — Reset rate limiter for this client
    loginAttempts.delete(clientKey);

    // 6. Issue cryptographically signed token
    const token = createSessionToken({
      email: normalizedEmail,
      name: userName,
    });

    // 7. Store in HTTP-only SameSite=Strict cookie
    const cookieStore = await cookies();
    cookieStore.set(SESSION_COOKIE_NAME, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict", // upgraded from "lax" — CSRF protection
      path: "/",
      maxAge: 7 * 24 * 60 * 60, // 7 days
    });

    return NextResponse.json({
      success: true,
      user: {
        email: normalizedEmail,
        name: userName,
        role: "ADMIN",
      },
    });
  } catch (error) {
    console.error("Authentication service exception:", error);
    return NextResponse.json(
      { error: "Vault authorization service unavailable" },
      { status: 500 }
    );
  }
}
