import { db } from "@/core/db/client";
import { randomUUID } from "crypto";

export interface CategoryItem {
  id: string;
  name: string;
  slug: string;
  description?: string | null;
  imageUrl?: string | null;
  order: number;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
  products?: {
    id: string;
    name: string;
    isActive: boolean;
  }[];
}

export interface CreateCategoryInput {
  name: string;
  slug?: string;
  description?: string;
  imageUrl?: string;
  order?: number;
  isActive?: boolean;
}

export interface UpdateCategoryInput {
  name: string;
  slug?: string;
  description?: string;
  imageUrl?: string;
  order?: number;
  isActive?: boolean;
}

const defaultCategories = [
  {
    name: "Blinds",
    slug: "blinds",
    description: "Architectural motorized and manual window coverings including roller, zebra, roman and venetian blinds.",
    imageUrl: "/icon_blinds_1786042796413.png",
    order: 1,
  },
  {
    name: "Curtains",
    slug: "curtains",
    description: "Luxury custom sheer and blackout draperies tailored for villas, residential suites and hotels.",
    imageUrl: "/icon_curtains_1786042819663.png",
    order: 2,
  },
  {
    name: "Outdoor Solutions",
    slug: "outdoor-solutions",
    description: "Motorized retractable awnings, architectural canopies, and bioclimatic louvered pergolas.",
    imageUrl: "/icon_outdoor_1786042845349.png",
    order: 3,
  },
  {
    name: "Outdoor Living",
    slug: "outdoor-living",
    description: "Handcrafted Grade-A natural teak sun loungers, outdoor daybeds, and solution-dyed acrylic fabrics.",
    imageUrl: "/outdoor_teak_sunbed.jpg",
    order: 4,
  },
  {
    name: "PVC Solutions",
    slug: "pvc-solutions",
    description: "Optical-grade heavy-duty transparent PVC weather screens for torrential rain and wind protection.",
    imageUrl: "/outdoor_uv_clear_pvc.jpg",
    order: 5,
  },
];

interface CategorySqlRow {
  id: string;
  name: string;
  slug: string;
  description?: string | null;
  imageUrl?: string | null;
  order: number | string;
  isActive: number | boolean;
  createdAt: string | Date;
  updatedAt: string | Date;
  productCount?: number | string;
}

export class CategoryService {
  /**
   * Initializes the categories table in SQLite and seeds default categories if empty
   */
  static async ensureSeeded(): Promise<void> {
    try {
      // Ensure SQLite table exists
      await db.$executeRawUnsafe(`
        CREATE TABLE IF NOT EXISTS "categories" (
          "id" TEXT NOT NULL PRIMARY KEY,
          "name" TEXT NOT NULL UNIQUE,
          "slug" TEXT NOT NULL UNIQUE,
          "description" TEXT,
          "imageUrl" TEXT,
          "order" INTEGER NOT NULL DEFAULT 0,
          "isActive" BOOLEAN NOT NULL DEFAULT 1,
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
      `);

      const countResult = await db.$queryRawUnsafe<{ count: number }[]>(
        `SELECT COUNT(*) as count FROM "categories"`
      );
      const count = Number(countResult[0]?.count || 0);

      if (count === 0) {
        for (const cat of defaultCategories) {
          const id = randomUUID();
          await db.$executeRawUnsafe(
            `INSERT INTO "categories" ("id", "name", "slug", "description", "imageUrl", "order", "isActive", "createdAt", "updatedAt")
             VALUES (?, ?, ?, ?, ?, ?, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`,
            id,
            cat.name,
            cat.slug,
            cat.description,
            cat.imageUrl,
            cat.order
          );
        }
      }
    } catch (e) {
      console.error("Failed to seed initial categories:", e);
    }
  }

  /**
   * Retrieves all active categories ordered by `order` ASC
   */
  static async getAll(): Promise<CategoryItem[]> {
    await this.ensureSeeded();
    try {
      const rows = await db.$queryRawUnsafe<CategorySqlRow[]>(`
        SELECT 
          c."id", c."name", c."slug", c."description", c."imageUrl", 
          c."order", c."isActive", c."createdAt", c."updatedAt",
          (SELECT COUNT(*) FROM "products" p WHERE p."category" = c."name" AND p."isActive" = 1) as productCount
        FROM "categories" c
        WHERE c."isActive" = 1
        ORDER BY c."order" ASC
      `);

      return rows.map((r) => ({
        id: r.id,
        name: r.name,
        slug: r.slug,
        description: r.description,
        imageUrl: r.imageUrl,
        order: Number(r.order),
        isActive: Boolean(r.isActive),
        createdAt: new Date(r.createdAt),
        updatedAt: new Date(r.updatedAt),
        products: Array.from({ length: Number(r.productCount || 0) }, (_, i) => ({
          id: `p-${i}`,
          name: "",
          isActive: true,
        })),
      }));
    } catch (e) {
      console.error("Failed to fetch active categories:", e);
      return [];
    }
  }

  /**
   * Retrieves all categories for admin management
   */
  static async getAllForAdmin(): Promise<CategoryItem[]> {
    await this.ensureSeeded();
    try {
      const rows = await db.$queryRawUnsafe<CategorySqlRow[]>(`
        SELECT 
          c."id", c."name", c."slug", c."description", c."imageUrl", 
          c."order", c."isActive", c."createdAt", c."updatedAt",
          (SELECT COUNT(*) FROM "products" p WHERE p."category" = c."name") as productCount
        FROM "categories" c
        ORDER BY c."order" ASC
      `);

      return rows.map((r) => ({
        id: r.id,
        name: r.name,
        slug: r.slug,
        description: r.description,
        imageUrl: r.imageUrl,
        order: Number(r.order),
        isActive: Boolean(r.isActive),
        createdAt: new Date(r.createdAt),
        updatedAt: new Date(r.updatedAt),
        products: Array.from({ length: Number(r.productCount || 0) }, (_, i) => ({
          id: `p-${i}`,
          name: "",
          isActive: true,
        })),
      }));
    } catch (e) {
      console.error("Failed to fetch admin categories:", e);
      return [];
    }
  }

  /**
   * Retrieves a single category by ID
   */
  static async getById(id: string): Promise<CategoryItem | null> {
    await this.ensureSeeded();
    try {
      const rows = await db.$queryRawUnsafe<CategorySqlRow[]>(
        `SELECT "id", "name", "slug", "description", "imageUrl", "order", "isActive", "createdAt", "updatedAt"
         FROM "categories" WHERE "id" = ? LIMIT 1`,
        id
      );

      if (!rows.length) return null;
      const r = rows[0];
      return {
        id: r.id,
        name: r.name,
        slug: r.slug,
        description: r.description,
        imageUrl: r.imageUrl,
        order: Number(r.order),
        isActive: Boolean(r.isActive),
        createdAt: new Date(r.createdAt),
        updatedAt: new Date(r.updatedAt),
      };
    } catch (e) {
      console.error("Failed to get category by ID:", e);
      return null;
    }
  }

  /**
   * Creates a new category
   */
  static async create(data: CreateCategoryInput): Promise<CategoryItem> {
    await this.ensureSeeded();
    const id = randomUUID();
    const slug = data.slug || data.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    const order = Number(data.order) || 0;
    const isActive = data.isActive !== false ? 1 : 0;

    await db.$executeRawUnsafe(
      `INSERT INTO "categories" ("id", "name", "slug", "description", "imageUrl", "order", "isActive", "createdAt", "updatedAt")
       VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`,
      id,
      data.name.trim(),
      slug,
      data.description || "",
      data.imageUrl || "",
      order,
      isActive
    );

    return {
      id,
      name: data.name.trim(),
      slug,
      description: data.description || "",
      imageUrl: data.imageUrl || "",
      order,
      isActive: Boolean(isActive),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
  }

  /**
   * Updates an existing category
   */
  static async update(id: string, data: Partial<UpdateCategoryInput>): Promise<void> {
    await this.ensureSeeded();
    const current = await this.getById(id);
    if (!current) throw new Error("Category not found");

    const name = data.name !== undefined ? data.name.trim() : current.name;
    const slug = data.slug || name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    const description = data.description !== undefined ? data.description : (current.description || "");
    const imageUrl = data.imageUrl !== undefined ? data.imageUrl : (current.imageUrl || "");
    const order = data.order !== undefined ? Number(data.order) : current.order;
    const isActive = data.isActive !== undefined ? (data.isActive ? 1 : 0) : (current.isActive ? 1 : 0);

    await db.$executeRawUnsafe(
      `UPDATE "categories" 
       SET "name" = ?, "slug" = ?, "description" = ?, "imageUrl" = ?, "order" = ?, "isActive" = ?, "updatedAt" = CURRENT_TIMESTAMP
       WHERE "id" = ?`,
      name,
      slug,
      description,
      imageUrl,
      order,
      isActive,
      id
    );
  }

  /**
   * Deletes a category by ID
   */
  static async delete(id: string): Promise<void> {
    await this.ensureSeeded();
    await db.$executeRawUnsafe(`DELETE FROM "categories" WHERE "id" = ?`, id);
  }
}
