import Navbar from '@/components/Navbar';
import BlogSection from '@/components/BlogSection';
import Footer from '@/components/Footer';
import FloatingWidgets from '@/components/FloatingWidgets';

export const metadata = {
  title: 'Blog & Tech Insights | HKRION (Pvt) Ltd',
  description: 'Read the latest technical articles on Enterprise ERPs, IoT Telemetry Systems, Next.js 16 Web Development, and MySQL Database Security by HKRION experts.',
  keywords: ['HKRION Blog', 'ERP Systems Guide', 'IoT Telemetry Articles', 'Next.js 16 Tutorial', 'Database Security Sri Lanka'],
};

export default function BlogPage() {
  return (
    <div className="min-h-screen bg-black text-neutral-100 flex flex-col font-sans selection:bg-[#1ABE56] selection:text-black">
      <Navbar />
      <main className="grow pt-20">
        <BlogSection />
      </main>
      <Footer />
      <FloatingWidgets />
    </div>
  );
}
