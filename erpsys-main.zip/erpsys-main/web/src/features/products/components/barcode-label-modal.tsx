"use client";

import React, { useState, useRef } from "react";
import { X, Printer, Barcode } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ProductItem, ProductVariantItem } from "../types";

interface BarcodeLabelModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: ProductItem;
  currencySymbol?: string;
  formatPrice?: (amount: number) => string;
}

// Generate simple Code 128 / Barcode pattern as clean SVG lines
function SvgBarcode({ value }: { value: string }) {
  const text = value || "00000000";
  const bars: boolean[] = [];
  
  // Start pattern
  bars.push(true, false, true, false);
  
  for (let i = 0; i < text.length; i++) {
    const charCode = text.charCodeAt(i);
    const pattern = [(charCode & 1) === 1, (charCode & 2) === 2, (charCode & 4) === 4, (charCode & 8) === 8, (charCode & 16) === 16];
    pattern.forEach((p) => {
      bars.push(p);
      bars.push(!p);
    });
  }
  
  // Stop pattern
  bars.push(true, true, false, true, false, true, true);

  return (
    <div className="flex flex-col items-center">
      <svg
        className="w-full h-10 max-w-[190px]"
        viewBox={`0 0 ${bars.length * 2.2} 40`}
        preserveAspectRatio="none"
      >
        {bars.map((isBar, idx) =>
          isBar ? (
            <rect
              key={idx}
              x={idx * 2.2}
              y="0"
              width="1.8"
              height="40"
              fill="#000000"
            />
          ) : null
        )}
      </svg>
      <span className="text-[10px] font-mono tracking-widest text-black mt-0.5 select-all font-bold">
        {value}
      </span>
    </div>
  );
}

export function BarcodeLabelModal({
  isOpen,
  onClose,
  product,
  currencySymbol = "Rs",
  formatPrice = (p) => `${currencySymbol} ${p.toFixed(2)}`,
}: BarcodeLabelModalProps) {
  const [selectedVariantId, setSelectedVariantId] = useState<string>(
    product.variants[0]?.id || ""
  );
  const [quantity, setQuantity] = useState<number>(4);
  const [showBusinessName, setShowBusinessName] = useState(true);
  const [showProductName, setShowProductName] = useState(true);
  const [showPrice, setShowPrice] = useState(true);
  const [showBarcodeText, setShowBarcodeText] = useState(true);
  const [businessTitle, setBusinessTitle] = useState("HKRION STORE");

  const printAreaRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const currentVariant =
    product.variants.find((v) => v.id === selectedVariantId) ||
    product.variants[0] ||
    ({
      name: product.name,
      sku: "SKU-" + product.id.slice(0, 8),
      sellingPrice: 0,
      barcode: null,
    } as ProductVariantItem);

  const barcodeValue = currentVariant.barcode || currentVariant.sku || product.name;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto">
      {/* Printable styles isolated for label paper */}
      <style jsx global>{`
        @media print {
          body * {
            visibility: hidden !important;
          }
          #printable-labels-container,
          #printable-labels-container * {
            visibility: visible !important;
          }
          #printable-labels-container {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            background: white !important;
            padding: 10px !important;
            margin: 0 !important;
            display: flex !important;
            flex-wrap: wrap !important;
            gap: 12px !important;
          }
          .barcode-sticker {
            page-break-inside: avoid;
            border: 1px dashed #ccc !important;
          }
        }
      `}</style>

      <div className="relative w-full max-w-2xl bg-card border border-border rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border/50 bg-secondary/10">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-primary/10 text-primary">
              <Barcode className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-foreground">
                Print Barcode & Price Labels
              </h2>
              <p className="text-xs text-muted-foreground">
                Customize label sticker layout and print barcodes for POS scanning
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground p-1.5 rounded-lg hover:bg-secondary/40 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Controls */}
          <div className="space-y-4">
            {/* Variant selector if multiple */}
            {product.variants.length > 1 && (
              <div className="space-y-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                  Select Product Variant
                </label>
                <select
                  value={selectedVariantId}
                  onChange={(e) => setSelectedVariantId(e.target.value)}
                  className="w-full bg-background border border-border rounded-lg px-3 py-2 text-xs font-medium text-foreground focus:ring-1 focus:ring-primary outline-none"
                >
                  {product.variants.map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.name} (SKU: {v.sku})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Copies */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                Number of Label Copies
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-24 bg-background border border-border rounded-lg px-3 py-2 text-sm font-semibold text-foreground focus:ring-1 focus:ring-primary outline-none"
                />
                <div className="flex gap-1.5">
                  {[1, 4, 8, 16].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setQuantity(num)}
                      className={`px-2.5 py-1 text-xs rounded border transition ${
                        quantity === num
                          ? "bg-primary text-primary-foreground border-primary font-bold"
                          : "bg-secondary/20 border-border text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      {num}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Business Header Input */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                Header / Business Name
              </label>
              <input
                type="text"
                value={businessTitle}
                onChange={(e) => setBusinessTitle(e.target.value)}
                placeholder="Business Name"
                className="w-full bg-background border border-border rounded-lg px-3 py-2 text-xs font-medium text-foreground focus:ring-1 focus:ring-primary outline-none"
              />
            </div>

            {/* Visibility options */}
            <div className="space-y-2 pt-2 border-t border-border/40">
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block">
                Sticker Elements to Show
              </label>
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={showBusinessName}
                    onChange={(e) => setShowBusinessName(e.target.checked)}
                    className="rounded border-border accent-primary h-4 w-4"
                  />
                  <span>Show Store / Business Name</span>
                </label>
                <label className="flex items-center gap-2 text-xs cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={showProductName}
                    onChange={(e) => setShowProductName(e.target.checked)}
                    className="rounded border-border accent-primary h-4 w-4"
                  />
                  <span>Show Product / Variant Name</span>
                </label>
                <label className="flex items-center gap-2 text-xs cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={showPrice}
                    onChange={(e) => setShowPrice(e.target.checked)}
                    className="rounded border-border accent-primary h-4 w-4"
                  />
                  <span>Show Selling Price</span>
                </label>
                <label className="flex items-center gap-2 text-xs cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={showBarcodeText}
                    onChange={(e) => setShowBarcodeText(e.target.checked)}
                    className="rounded border-border accent-primary h-4 w-4"
                  />
                  <span>Show Barcode / SKU Code Text</span>
                </label>
              </div>
            </div>
          </div>

          {/* Sticker Live Preview */}
          <div className="flex flex-col items-center justify-center p-4 bg-secondary/15 rounded-xl border border-border/40">
            <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-3">
              Sticker Live Preview (50mm × 30mm)
            </span>

            {/* Single Preview Sticker */}
            <div className="w-[210px] bg-white text-black p-3.5 rounded-md shadow-md border border-neutral-300 flex flex-col items-center text-center select-none">
              {showBusinessName && (
                <div className="text-[9px] font-extrabold uppercase tracking-tight text-neutral-800 line-clamp-1">
                  {businessTitle}
                </div>
              )}
              {showProductName && (
                <div className="text-[10px] font-bold text-neutral-900 mt-0.5 line-clamp-1">
                  {currentVariant.name || product.name}
                </div>
              )}
              {showPrice && (
                <div className="text-xs font-black text-black mt-1">
                  {formatPrice(currentVariant.sellingPrice)}
                </div>
              )}

              <div className="my-1.5 w-full flex justify-center">
                {showBarcodeText ? (
                  <SvgBarcode value={barcodeValue} />
                ) : (
                  <svg
                    className="w-full h-8 max-w-[170px]"
                    viewBox="0 0 100 30"
                    preserveAspectRatio="none"
                  >
                    {[...Array(25)].map((_, i) => (
                      <rect
                        key={i}
                        x={i * 4}
                        y="0"
                        width={i % 2 === 0 ? "2.5" : "1"}
                        height="30"
                        fill="#000"
                      />
                    ))}
                  </svg>
                )}
              </div>
            </div>

            <p className="text-[11px] text-muted-foreground mt-4 text-center">
              Total <span className="font-bold text-foreground">{quantity}</span> label
              {quantity > 1 ? "s" : ""} will be sent to printer.
            </p>
          </div>
        </div>

        {/* Hidden Printable Container for Window.print() */}
        <div id="printable-labels-container" ref={printAreaRef} className="hidden">
          {[...Array(quantity)].map((_, i) => (
            <div
              key={i}
              className="barcode-sticker w-[190px] h-[110px] p-2 text-black bg-white flex flex-col items-center justify-between text-center box-border"
            >
              {showBusinessName && (
                <div className="text-[9px] font-bold uppercase tracking-tight text-black line-clamp-1">
                  {businessTitle}
                </div>
              )}
              {showProductName && (
                <div className="text-[10px] font-bold text-black line-clamp-1">
                  {currentVariant.name || product.name}
                </div>
              )}
              {showPrice && (
                <div className="text-[11px] font-black text-black">
                  {formatPrice(currentVariant.sellingPrice)}
                </div>
              )}
              <div className="w-full flex justify-center my-0.5">
                <SvgBarcode value={barcodeValue} />
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-border/50 bg-secondary/10">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button
            onClick={handlePrint}
            className="flex items-center gap-2 bg-primary text-primary-foreground font-bold shadow-md"
          >
            <Printer className="h-4 w-4" /> Print {quantity} Label{quantity > 1 ? "s" : ""}
          </Button>
        </div>
      </div>
    </div>
  );
}
