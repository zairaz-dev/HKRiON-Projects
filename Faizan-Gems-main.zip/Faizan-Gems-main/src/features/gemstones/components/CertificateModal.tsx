"use client";

import React from "react";
import { Gemstone } from "@/types/gemstone";
import {
  CloseIcon,
  CertificateShieldIcon,
  CheckIcon,
  ExternalLinkIcon
} from "@/components/ui/LuxuryIcons";

interface CertificateModalProps {
  gemstone: Gemstone;
  onClose: () => void;
}

export function CertificateModal({ gemstone, onClose }: CertificateModalProps) {
  const { certification } = gemstone;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/60 backdrop-blur-sm animate-luxury-backdrop"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-2xl bg-white border border-[#C5A880] shadow-2xl p-6 sm:p-10 max-h-[90vh] overflow-y-auto animate-luxury-modal"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close certificate modal"
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-[#FAF8F5] text-[#18181D] hover:bg-[#18181D] hover:text-white flex items-center justify-center transition-colors border border-[#E8E4DC]"
        >
          <CloseIcon className="w-4 h-4" />
        </button>

        {/* Certificate Frame Header */}
        <div className="text-center pb-6 border-b border-[#E8E4DC]">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#FAF8F5] border border-[#C5A880] text-[#C5A880] mb-3">
            <CertificateShieldIcon className="w-6 h-6" />
          </div>
          <span className="text-[11px] font-sans tracking-wide-luxury uppercase text-[#9A7B4F] block">
            Independent Gemological Laboratory Dossier
          </span>
          <h2 className="font-serif text-2xl sm:text-3xl text-[#18181D] mt-1 font-medium">
            {certification.lab} Gemstone Report
          </h2>
          <p className="text-xs font-mono text-[#8C867D] mt-1">
            Report Number: {certification.reportNumber}
          </p>
        </div>

        {/* Verified Security Hologram Badge */}
        <div className="my-6 p-4 bg-[#FAF8F5] border border-[#E8E4DC] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-6 h-6 rounded-full bg-[#18181D] text-[#C5A880] flex items-center justify-center flex-shrink-0">
              <CheckIcon className="w-3.5 h-3.5" />
            </div>
            <div>
              <span className="text-xs font-serif font-medium text-[#18181D] block">
                Digital Cryptographic & Hologram Seal Verified
              </span>
              <span className="text-[11px] font-sans text-[#8C867D]">
                Registered in {certification.lab} global archive on {certification.issueDate}
              </span>
            </div>
          </div>
          <span className="hidden sm:inline-block px-2.5 py-1 bg-white border border-[#C5A880] text-[#9A7B4F] text-[10px] font-mono tracking-widest uppercase">
            VERIFIED
          </span>
        </div>

        {/* Analytical Findings Table */}
        <div className="space-y-4">
          <h3 className="font-serif text-lg text-[#18181D] border-b border-[#F2EFE9] pb-2">
            Analytical Laboratory Findings
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-3.5 gap-x-6 text-xs font-sans">
            <div className="border-b border-[#F2EFE9] pb-2">
              <span className="text-[#8C867D] block uppercase tracking-wider text-[10px]">Mineral Species</span>
              <span className="text-[#18181D] font-medium text-sm">{gemstone.species}</span>
            </div>
            <div className="border-b border-[#F2EFE9] pb-2">
              <span className="text-[#8C867D] block uppercase tracking-wider text-[10px]">Variety</span>
              <span className="text-[#18181D] font-medium text-sm">{gemstone.variety}</span>
            </div>
            <div className="border-b border-[#F2EFE9] pb-2">
              <span className="text-[#8C867D] block uppercase tracking-wider text-[10px]">Weight (Carats)</span>
              <span className="text-[#18181D] font-medium text-sm">{gemstone.carat.toFixed(2)} ct</span>
            </div>
            {gemstone.dimensions && (Number(gemstone.dimensions.length || 0) > 0 || Number(gemstone.dimensions.width || 0) > 0) && (
              <div className="border-b border-[#F2EFE9] pb-2">
                <span className="text-[#8C867D] block uppercase tracking-wider text-[10px]">Measurements</span>
                <span className="text-[#18181D] font-medium text-sm">
                  {gemstone.dimensions.length} × {gemstone.dimensions.width} × {gemstone.dimensions.depth} mm
                </span>
              </div>
            )}
            <div className="border-b border-[#F2EFE9] pb-2">
              <span className="text-[#8C867D] block uppercase tracking-wider text-[10px]">Shape & Cutting Style</span>
              <span className="text-[#18181D] font-medium text-sm">{gemstone.cutDetail}</span>
            </div>
            <div className="border-b border-[#F2EFE9] pb-2">
              <span className="text-[#8C867D] block uppercase tracking-wider text-[10px]">Color Determination</span>
              <span className="text-[#18181D] font-medium text-sm">{gemstone.colorGrade}</span>
            </div>
            <div className="border-b border-[#F2EFE9] pb-2 sm:col-span-2">
              <span className="text-[#8C867D] block uppercase tracking-wider text-[10px]">Geographic Origin Determination</span>
              <span className="text-[#18181D] font-medium text-sm">
                {gemstone.origin} (Confirmed by microscopic inclusion fingerprinting & EDXRF spectroscopy)
              </span>
            </div>
            <div className="border-b border-[#F2EFE9] pb-2 sm:col-span-2">
              <span className="text-[#8C867D] block uppercase tracking-wider text-[10px]">Treatment / Enhancement Conclusions</span>
              <span className="text-[#18181D] font-medium text-sm text-[#9A7B4F]">
                {certification.treatmentConfirmed} ({gemstone.treatment})
              </span>
            </div>
          </div>

          {/* Official Comments */}
          <div className="mt-4 p-4 bg-[#FAF8F5] border border-[#E8E4DC] text-xs font-sans text-[#554F47]">
            <span className="text-[#8C867D] uppercase tracking-wider text-[10px] block mb-1">
              Official Laboratory Notation:
            </span>
            <p className="italic">
              &ldquo;{certification.comments}&rdquo;
            </p>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="mt-8 pt-6 border-t border-[#E8E4DC] flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-[#8C867D] font-sans">
            Faizan Gems issues original physical laminated dossiers upon courier delivery.
          </div>
          <div className="flex gap-3 w-full sm:w-auto">
            {certification.verificationUrl && (
              <a
                href={certification.verificationUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 sm:flex-none px-4 py-2.5 bg-[#18181D] hover:bg-[#2A2A32] text-white text-xs font-sans uppercase tracking-wider flex items-center justify-center gap-2 transition-colors"
              >
                <span>Verify at {certification.lab}</span>
                <ExternalLinkIcon className="w-3.5 h-3.5 text-[#C5A880]" />
              </a>
            )}
            <button
              onClick={() => window.print()}
              className="px-4 py-2.5 border border-[#E8E4DC] hover:border-[#18181D] text-[#18181D] text-xs font-sans uppercase tracking-wider transition-colors"
            >
              Print Report
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
