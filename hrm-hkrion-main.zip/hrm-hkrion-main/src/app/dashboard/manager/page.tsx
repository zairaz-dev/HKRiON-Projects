import React from "react";
import { Users, Calendar, ClipboardCheck } from "lucide-react";
import { getSession } from "@/lib/session";
import { redirect } from "next/navigation";
import { format } from "date-fns";
import { PageHeader } from "@/components/ui/page-header";
import { prisma } from "@/lib/db";
import ManagerLeavesTable from "./manager-leaves-table";
import Link from "next/link";

export default async function ManagerDashboardPage() {
  const session = await getSession();

  if (!session) {
    redirect("/login");
  }

  // Double check if they are authorized to see this page.
  // Either an ADMIN/SUPER_ADMIN, or a regular employee who actually has subordinates.
  let isManager = false;
  if (session.role === "MANAGER" || session.role === "SUPER_ADMIN") {
    isManager = true;
  } else {
    const subsCount = await prisma.user.count({
      where: { managerId: session.userId }
    });
    if (subsCount > 0) isManager = true;
  }

  if (!isManager) {
    // If not a manager, redirect back to their own dashboard
    redirect("/dashboard");
  }

  // Fetch subordinates
  const subordinates = await prisma.user.findMany({
    where: { managerId: session.userId },
    select: { id: true }
  });
  const subordinateIds = subordinates.map(s => s.id);
  const teamSize = subordinateIds.length;

  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);
  
  const todayEnd = new Date();
  todayEnd.setHours(23, 59, 59, 999);

  // Fetch team attendance today
  const teamPresent = await prisma.attendance.count({
    where: {
      userId: { in: subordinateIds },
      date: { gte: todayStart, lte: todayEnd },
      clockIn: { not: null }
    }
  });

  // Fetch pending leaves
  const pendingLeaves = await prisma.leaveRequest.findMany({
    where: {
      userId: { in: subordinateIds },
      status: "PENDING"
    },
    include: {
      user: {
        select: { firstName: true, lastName: true, email: true }
      }
    },
    orderBy: { createdAt: 'desc' }
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Page Header */}
      <PageHeader 
        title="Manager Dashboard"
        description="Overview of your team's performance, attendance, and leave requests."
      />

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Pending Leaves Card */}
        <div className="bg-surface border border-border rounded-xl p-6 shadow-sm flex items-center justify-between">
          <div>
            <h3 className="text-sm font-medium text-text-secondary">Pending Leaves</h3>
            <p className="text-3xl font-semibold text-text-primary mt-1">{pendingLeaves.length}</p>
            <p className="text-xs font-medium text-warning mt-1">Awaiting your approval</p>
          </div>
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-warning-light text-warning">
            <ClipboardCheck size={24} />
          </div>
        </div>

        {/* Team Attendance Card */}
        <div className="bg-surface border border-border rounded-xl p-6 shadow-sm flex items-center justify-between">
          <div>
            <h3 className="text-sm font-medium text-text-secondary">Team Present</h3>
            <p className="text-3xl font-semibold text-text-primary mt-1">{teamPresent} <span className="text-lg text-text-muted font-normal">/ {teamSize}</span></p>
            <p className="text-xs font-medium text-success mt-1">Today's attendance</p>
          </div>
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-success-light text-success">
            <Calendar size={24} />
          </div>
        </div>

        {/* Total Team Members */}
        <div className="bg-surface border border-border rounded-xl p-6 shadow-sm flex items-center justify-between">
          <div>
            <h3 className="text-sm font-medium text-text-secondary">Team Size</h3>
            <p className="text-3xl font-semibold text-text-primary mt-1">{teamSize}</p>
            <p className="text-xs font-medium text-info mt-1">Active members</p>
          </div>
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-info-light text-info">
            <Users size={24} />
          </div>
        </div>

      </div>

      {/* Main Content Area - Interactive Table */}
      <div className="bg-surface border border-border rounded-xl shadow-sm mt-8 overflow-hidden">
        <div className="p-5 border-b border-border flex justify-between items-center">
          <h2 className="font-semibold text-text-primary">Recent Leave Requests</h2>
          <Link href="/dashboard/leaves" className="text-sm text-primary-600 hover:text-primary-700 font-semibold">View All</Link>
        </div>
        <div className="p-0">
          <ManagerLeavesTable leaves={pendingLeaves} />
        </div>
      </div>
    </div>
  );
}
