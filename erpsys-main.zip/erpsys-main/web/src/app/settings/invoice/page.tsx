"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Hash,
  ChevronLeft,
  Loader2,
  Plus,
  Edit2,
  Trash2,
  CheckCircle,
  FileText,
  Star,
  Printer,
  Building2,
  Info,
  Eye
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { authService } from "@/services/auth-service";
import { branchService } from "@/services/branch-service";
import {
  invoiceSettingsService,
  InvoiceScheme,
  InvoiceLayout
} from "@/services/invoice-settings-service";
import { InvoiceRenderer } from "@/components/templates/invoice";

export default function InvoiceSettingsPage() {
  const router = useRouter();

  // User state
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [businessId, setBusinessId] = useState<string>("");

  // Tabs: "schemes" | "layouts"
  const [activeTab, setActiveTab] = useState<"schemes" | "layouts">("schemes");

  // Data states
  const [schemes, setSchemes] = useState<InvoiceScheme[]>([]);
  const [layouts, setLayouts] = useState<InvoiceLayout[]>([]);
  const [branches, setBranches] = useState<any[]>([]);

  // Loading states
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);

  // Message states
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Modals state
  const [schemeModalOpen, setSchemeModalOpen] = useState<boolean>(false);
  const [editingScheme, setEditingScheme] = useState<InvoiceScheme | null>(null);

  const [layoutModalOpen, setLayoutModalOpen] = useState<boolean>(false);
  const [editingLayout, setEditingLayout] = useState<InvoiceLayout | null>(null);

  const [deleteModalOpen, setDeleteModalOpen] = useState<boolean>(false);
  const [deleteItem, setDeleteItem] = useState<{ id: string; name: string; type: "scheme" | "layout" } | null>(null);

  // Form states for Scheme
  const [schemeForm, setSchemeForm] = useState({
    name: "",
    schemeType: "FORMATTED",
    prefix: "INV-2026/",
    startNumber: 1001,
    numberOfDigits: 4,
    isDefault: false,
    branchId: "",
  });

  // Form states for Layout
  const [layoutForm, setLayoutForm] = useState({
    name: "",
    headerText: "Tax Invoice",
    subHeading: "Original Copy",
    showLogo: true,
    showTaxDetails: true,
    showCustomerDetails: true,
    showSku: true,
    showDescription: true,
    showDiscount: true,
    showTax: true,
    footerText: "Thank you for your business!",
    termsConditions: "1. Goods once sold cannot be taken back.\n2. Subject to local jurisdiction.",
    bankDetails: "",
    paperSize: "A4",
    isDefault: false,
    branchId: "",
  });

  // Load User and initial data
  useEffect(() => {
    const user = authService.getCurrentUser();
    if (!user || !user.businessId) {
      router.push("/login");
      return;
    }
    setCurrentUser(user);
    setBusinessId(user.businessId);

    loadAllData(user.businessId);
  }, []);

  const loadAllData = async (bId: string) => {
    setLoading(true);
    setError("");
    try {
      const [fetchedSchemes, fetchedLayouts, fetchedBranches] = await Promise.all([
        invoiceSettingsService.getSchemes(bId),
        invoiceSettingsService.getLayouts(bId),
        branchService.getBranches(bId),
      ]);
      setSchemes(fetchedSchemes);
      setLayouts(fetchedLayouts);
      setBranches(fetchedBranches);
    } catch (err: any) {
      setError(err.message || "Failed to load invoice settings.");
    } finally {
      setLoading(false);
    }
  };

  const showSuccess = (msg: string) => {
    setSuccessMessage(msg);
    setTimeout(() => setSuccessMessage(""), 4000);
  };

  // ================= SCHEME HANDLERS =================
  const openNewSchemeModal = () => {
    setEditingScheme(null);
    setSchemeForm({
      name: "",
      schemeType: "FORMATTED",
      prefix: "INV-2026/",
      startNumber: 1001,
      numberOfDigits: 4,
      isDefault: schemes.length === 0,
      branchId: "",
    });
    setSchemeModalOpen(true);
  };

  const openEditSchemeModal = (scheme: InvoiceScheme) => {
    setEditingScheme(scheme);
    setSchemeForm({
      name: scheme.name,
      schemeType: scheme.schemeType || "FORMATTED",
      prefix: scheme.prefix || "",
      startNumber: scheme.startNumber,
      numberOfDigits: scheme.numberOfDigits,
      isDefault: scheme.isDefault,
      branchId: scheme.branchId || "",
    });
    setSchemeModalOpen(true);
  };

  const handleSaveScheme = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      if (editingScheme) {
        await invoiceSettingsService.updateScheme(editingScheme.id, {
          ...schemeForm,
          businessId,
        });
        showSuccess("Invoice scheme updated successfully!");
      } else {
        await invoiceSettingsService.createScheme({
          ...schemeForm,
          businessId,
        });
        showSuccess("Invoice scheme created successfully!");
      }
      setSchemeModalOpen(false);
      loadAllData(businessId);
    } catch (err: any) {
      setError(err.message || "Failed to save invoice scheme");
    } finally {
      setSaving(false);
    }
  };

  const handleSetDefaultScheme = async (id: string) => {
    try {
      await invoiceSettingsService.setDefaultScheme(id, businessId);
      showSuccess("Default invoice scheme updated!");
      loadAllData(businessId);
    } catch (err: any) {
      setError(err.message || "Failed to set default scheme");
    }
  };

  // ================= LAYOUT HANDLERS =================
  const openNewLayoutModal = () => {
    setEditingLayout(null);
    setLayoutForm({
      name: "",
      headerText: "Tax Invoice",
      subHeading: "Original Copy",
      showLogo: true,
      showTaxDetails: true,
      showCustomerDetails: true,
      showSku: true,
      showDescription: true,
      showDiscount: true,
      showTax: true,
      footerText: "Thank you for your business!",
      termsConditions: "1. Goods once sold cannot be taken back.\n2. Subject to local jurisdiction.",
      bankDetails: "",
      paperSize: "A4",
      isDefault: layouts.length === 0,
      branchId: "",
    });
    setLayoutModalOpen(true);
  };

  const openEditLayoutModal = (layout: InvoiceLayout) => {
    setEditingLayout(layout);
    setLayoutForm({
      name: layout.name,
      headerText: layout.headerText || "",
      subHeading: layout.subHeading || "",
      showLogo: layout.showLogo,
      showTaxDetails: layout.showTaxDetails,
      showCustomerDetails: layout.showCustomerDetails,
      showSku: layout.showSku,
      showDescription: layout.showDescription,
      showDiscount: layout.showDiscount,
      showTax: layout.showTax,
      footerText: layout.footerText || "",
      termsConditions: layout.termsConditions || "",
      bankDetails: layout.bankDetails || "",
      paperSize: layout.paperSize || "A4",
      isDefault: layout.isDefault,
      branchId: layout.branchId || "",
    });
    setLayoutModalOpen(true);
  };

  const handleSaveLayout = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      if (editingLayout) {
        await invoiceSettingsService.updateLayout(editingLayout.id, {
          ...layoutForm,
          businessId,
        });
        showSuccess("Invoice layout updated successfully!");
      } else {
        await invoiceSettingsService.createLayout({
          ...layoutForm,
          businessId,
        });
        showSuccess("Invoice layout created successfully!");
      }
      setLayoutModalOpen(false);
      loadAllData(businessId);
    } catch (err: any) {
      setError(err.message || "Failed to save invoice layout");
    } finally {
      setSaving(false);
    }
  };

  const handleSetDefaultLayout = async (id: string) => {
    try {
      await invoiceSettingsService.setDefaultLayout(id, businessId);
      showSuccess("Default invoice layout updated!");
      loadAllData(businessId);
    } catch (err: any) {
      setError(err.message || "Failed to set default layout");
    }
  };

  // ================= DELETE HANDLERS =================
  const confirmDelete = async () => {
    if (!deleteItem) return;
    setSaving(true);
    setError("");
    try {
      if (deleteItem.type === "scheme") {
        await invoiceSettingsService.deleteScheme(deleteItem.id, businessId);
        showSuccess("Invoice scheme deleted.");
      } else {
        await invoiceSettingsService.deleteLayout(deleteItem.id, businessId);
        showSuccess("Invoice layout deleted.");
      }
      setDeleteModalOpen(false);
      setDeleteItem(null);
      loadAllData(businessId);
    } catch (err: any) {
      setError(err.message || "Failed to delete item.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/settings" />
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Background Glowing Orbs */}
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-primary/5 blur-[120px] pointer-events-none z-0" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[550px] h-[550px] rounded-full bg-primary/5 blur-[130px] pointer-events-none z-0" />

        <Navbar title="Invoice Settings" className="relative z-10" />

        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 relative z-10">
          <div className="max-w-6xl mx-auto space-y-6">

            {/* Header section with back button */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <button
                  onClick={() => router.push("/settings")}
                  className="inline-flex items-center text-xs font-semibold text-muted-foreground hover:text-primary mb-2 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4 mr-1" /> Back to Settings
                </button>
                <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                  <Hash className="h-7 w-7 text-primary" /> Invoice Settings
                </h1>
                <p className="text-sm text-muted-foreground mt-1">
                  Manage invoice number schemes, paper layouts, logo display, terms, and branch defaults.
                </p>
              </div>

              <div>
                {activeTab === "schemes" ? (
                  <Button onClick={openNewSchemeModal} className="gap-2 shadow-md">
                    <Plus className="w-4 h-4" /> Add Invoice Scheme
                  </Button>
                ) : (
                  <Button onClick={openNewLayoutModal} className="gap-2 shadow-md">
                    <Plus className="w-4 h-4" /> Add Invoice Layout
                  </Button>
                )}
              </div>
            </div>

            {/* Alert Messages */}
            {successMessage && (
              <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 p-3 rounded-lg text-sm flex items-center gap-2 animate-in fade-in">
                <CheckCircle className="w-4 h-4 shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}

            {error && (
              <div className="bg-destructive/10 border border-destructive/30 text-destructive p-3 rounded-lg text-sm flex items-center gap-2 animate-in fade-in">
                <Info className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Navigation Tabs */}
            <div className="flex border-b border-border/60">
              <button
                onClick={() => setActiveTab("schemes")}
                className={`pb-3 px-4 text-sm font-semibold transition-all border-b-2 flex items-center gap-2 ${
                  activeTab === "schemes"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <Hash className="w-4 h-4" /> Invoice Schemes ({schemes.length})
              </button>
              <button
                onClick={() => setActiveTab("layouts")}
                className={`pb-3 px-4 text-sm font-semibold transition-all border-b-2 flex items-center gap-2 ${
                  activeTab === "layouts"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <Printer className="w-4 h-4" /> Invoice Layouts ({layouts.length})
              </button>
            </div>

            {/* Main Content Area */}
            {loading ? (
              <div className="flex items-center justify-center py-16 text-muted-foreground">
                <Loader2 className="w-6 h-6 animate-spin mr-2 text-primary" /> Loading settings...
              </div>
            ) : activeTab === "schemes" ? (
              /* SCHEMES TAB */
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {schemes.length === 0 ? (
                  <div className="col-span-full text-center py-12 text-muted-foreground border border-dashed border-border/60 rounded-xl bg-card/10">
                    No invoice schemes created yet. Click "Add Invoice Scheme" to get started.
                  </div>
                ) : (
                  schemes.map((scheme) => (
                    <Card
                      key={scheme.id}
                      className={`relative border transition-all ${
                        scheme.isDefault
                          ? "border-primary/60 bg-primary/5 shadow-md"
                          : "border-border/50 bg-card/30 hover:border-primary/30"
                      }`}
                    >
                      <CardContent className="p-5 space-y-3">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-bold text-base text-foreground flex items-center gap-2">
                              {scheme.name}
                              {scheme.isDefault && (
                                <span className="bg-primary/20 text-primary text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                                  <Star className="w-3 h-3 fill-current" /> Default
                                </span>
                              )}
                            </h3>
                            <p className="text-xs text-muted-foreground mt-0.5">
                              {scheme.branch ? `Branch: ${scheme.branch.name}` : "Business Wide (All Branches)"}
                            </p>
                          </div>
                        </div>

                        {/* Format Preview */}
                        <div className="bg-background/80 p-3 rounded-lg border border-border/40 space-y-1">
                          <span className="text-[11px] text-muted-foreground block font-medium">Sample Invoice Number:</span>
                          <span className="font-mono text-sm font-bold text-primary">
                            {(scheme.prefix || "") + String(scheme.startNumber).padStart(scheme.numberOfDigits, "0")}
                          </span>
                        </div>

                        <div className="text-xs text-muted-foreground space-y-1 pt-1">
                          <div>Prefix: <span className="font-mono text-foreground font-semibold">{scheme.prefix || "None"}</span></div>
                          <div>Start Number: <span className="font-semibold text-foreground">{scheme.startNumber}</span></div>
                          <div>Zero Padding: <span className="font-semibold text-foreground">{scheme.numberOfDigits} digits</span></div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center justify-between pt-3 border-t border-border/40 text-xs">
                          {!scheme.isDefault && (
                            <button
                              onClick={() => handleSetDefaultScheme(scheme.id)}
                              className="text-primary hover:underline font-semibold flex items-center gap-1"
                            >
                              <Star className="w-3.5 h-3.5" /> Make Default
                            </button>
                          )}
                          <div className="flex items-center gap-2 ml-auto">
                            <button
                              onClick={() => openEditSchemeModal(scheme)}
                              className="p-1.5 rounded text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
                              title="Edit"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            {!scheme.isDefault && (
                              <button
                                onClick={() => {
                                  setDeleteItem({ id: scheme.id, name: scheme.name, type: "scheme" });
                                  setDeleteModalOpen(true);
                                }}
                                className="p-1.5 rounded text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
                                title="Delete"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            ) : (
              /* LAYOUTS TAB */
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {layouts.length === 0 ? (
                  <div className="col-span-full text-center py-12 text-muted-foreground border border-dashed border-border/60 rounded-xl bg-card/10">
                    No invoice layouts created yet. Click "Add Invoice Layout" to get started.
                  </div>
                ) : (
                  layouts.map((layout) => (
                    <Card
                      key={layout.id}
                      className={`relative border transition-all ${
                        layout.isDefault
                          ? "border-primary/60 bg-primary/5 shadow-md"
                          : "border-border/50 bg-card/30 hover:border-primary/30"
                      }`}
                    >
                      <CardContent className="p-5 space-y-3">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-bold text-base text-foreground flex items-center gap-2">
                              {layout.name}
                              {layout.isDefault && (
                                <span className="bg-primary/20 text-primary text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                                  <Star className="w-3 h-3 fill-current" /> Default
                                </span>
                              )}
                            </h3>
                            <p className="text-xs text-muted-foreground mt-0.5">
                              Paper Size: <span className="font-bold text-foreground">{layout.paperSize}</span>
                            </p>
                          </div>
                        </div>

                        {/* Layout features summary */}
                        <div className="text-xs space-y-1.5 bg-background/80 p-3 rounded-lg border border-border/40">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Header Title:</span>
                            <span className="font-semibold text-foreground">{layout.headerText || "N/A"}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Branch Scope:</span>
                            <span className="font-semibold text-foreground">{layout.branch ? layout.branch.name : "All Branches"}</span>
                          </div>
                          <div className="flex gap-2 flex-wrap pt-1">
                            {layout.showLogo && <span className="bg-primary/10 text-primary text-[10px] px-1.5 py-0.5 rounded">Logo</span>}
                            {layout.showTaxDetails && <span className="bg-primary/10 text-primary text-[10px] px-1.5 py-0.5 rounded">Tax</span>}
                            {layout.showSku && <span className="bg-primary/10 text-primary text-[10px] px-1.5 py-0.5 rounded">SKU</span>}
                            {layout.showDiscount && <span className="bg-primary/10 text-primary text-[10px] px-1.5 py-0.5 rounded">Discount</span>}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center justify-between pt-3 border-t border-border/40 text-xs">
                          {!layout.isDefault && (
                            <button
                              onClick={() => handleSetDefaultLayout(layout.id)}
                              className="text-primary hover:underline font-semibold flex items-center gap-1"
                            >
                              <Star className="w-3.5 h-3.5" /> Make Default
                            </button>
                          )}
                          <div className="flex items-center gap-2 ml-auto">
                            <button
                              onClick={() => openEditLayoutModal(layout)}
                              className="p-1.5 rounded text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
                              title="Edit"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            {!layout.isDefault && (
                              <button
                                onClick={() => {
                                  setDeleteItem({ id: layout.id, name: layout.name, type: "layout" });
                                  setDeleteModalOpen(true);
                                }}
                                className="p-1.5 rounded text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
                                title="Delete"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            )}

          </div>
        </main>
      </div>

      {/* ================= SCHEME MODAL ================= */}
      {schemeModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-card border border-border/80 rounded-xl shadow-xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-5 border-b border-border/60 flex justify-between items-center bg-muted/20">
              <h2 className="font-bold text-lg text-foreground flex items-center gap-2">
                <Hash className="w-5 h-5 text-primary" />
                {editingScheme ? "Edit Invoice Scheme" : "Add Invoice Scheme"}
              </h2>
              <button
                onClick={() => setSchemeModalOpen(false)}
                className="text-muted-foreground hover:text-foreground text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveScheme} className="p-5 space-y-4 text-sm">
              <div>
                <label className="block text-xs font-semibold text-muted-foreground mb-1">Scheme Name *</label>
                <Input
                  type="text"
                  required
                  placeholder="e.g. Default POS Scheme"
                  value={schemeForm.name}
                  onChange={(e) => setSchemeForm({ ...schemeForm, name: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground mb-1">Prefix</label>
                  <Input
                    type="text"
                    placeholder="e.g. INV-2026/"
                    value={schemeForm.prefix}
                    onChange={(e) => setSchemeForm({ ...schemeForm, prefix: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground mb-1">Start Number *</label>
                  <Input
                    type="number"
                    required
                    min={1}
                    value={schemeForm.startNumber}
                    onChange={(e) => setSchemeForm({ ...schemeForm, startNumber: Number(e.target.value) })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground mb-1">Zero Padding Digits</label>
                  <Input
                    type="number"
                    min={1}
                    max={10}
                    value={schemeForm.numberOfDigits}
                    onChange={(e) => setSchemeForm({ ...schemeForm, numberOfDigits: Number(e.target.value) })}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground mb-1">Target Branch</label>
                  <select
                    value={schemeForm.branchId}
                    onChange={(e) => setSchemeForm({ ...schemeForm, branchId: e.target.value })}
                    className="w-full h-10 px-3 rounded-md bg-background border border-border/60 text-sm"
                  >
                    <option value="">All Branches (Business Wide)</option>
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>{b.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Sample Output preview */}
              <div className="bg-muted/40 p-3 rounded-lg border border-border/40 text-xs">
                <span className="text-muted-foreground">Generated Format Preview: </span>
                <span className="font-mono font-bold text-primary ml-1">
                  {(schemeForm.prefix || "") + String(schemeForm.startNumber).padStart(schemeForm.numberOfDigits, "0")}
                </span>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="schemeDefault"
                  checked={schemeForm.isDefault}
                  onChange={(e) => setSchemeForm({ ...schemeForm, isDefault: e.target.checked })}
                  className="rounded border-border/60 text-primary"
                />
                <label htmlFor="schemeDefault" className="text-xs font-medium cursor-pointer">
                  Set as Default Invoice Scheme for Business
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-border/60">
                <Button type="button" variant="outline" onClick={() => setSchemeModalOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={saving}>
                  {saving ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : null} Save Scheme
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= LAYOUT MODAL ================= */}
      {layoutModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-card border border-border/80 rounded-xl shadow-xl w-full max-w-5xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 border-b border-border/60 flex justify-between items-center bg-muted/20">
              <h2 className="font-bold text-lg text-foreground flex items-center gap-2">
                <Printer className="w-5 h-5 text-primary" />
                {editingLayout ? "Edit Invoice Layout" : "Add Invoice Layout"}
              </h2>
              <button
                onClick={() => setLayoutModalOpen(false)}
                className="text-muted-foreground hover:text-foreground text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-0 max-h-[82vh]">
              {/* Form Controls Column */}
              <form onSubmit={handleSaveLayout} className="lg:col-span-6 p-5 space-y-4 text-sm overflow-y-auto max-h-[82vh] border-r border-border/60">

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground mb-1">Layout Name *</label>
                  <Input
                    type="text"
                    required
                    placeholder="e.g. Standard A4 Bill"
                    value={layoutForm.name}
                    onChange={(e) => setLayoutForm({ ...layoutForm, name: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground mb-1">Paper Size *</label>
                  <select
                    value={layoutForm.paperSize}
                    onChange={(e) => setLayoutForm({ ...layoutForm, paperSize: e.target.value })}
                    className="w-full h-10 px-3 rounded-md bg-background border border-border/60 text-sm"
                  >
                    <option value="A4">A4 Sheet</option>
                    <option value="A5">A5 Sheet</option>
                    <option value="THERMAL_80MM">Thermal Receipt (80mm)</option>
                    <option value="THERMAL_58MM">Thermal Receipt (58mm)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground mb-1">Header Title</label>
                  <Input
                    type="text"
                    placeholder="e.g. Tax Invoice"
                    value={layoutForm.headerText}
                    onChange={(e) => setLayoutForm({ ...layoutForm, headerText: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground mb-1">Sub Heading</label>
                  <Input
                    type="text"
                    placeholder="e.g. Original Copy"
                    value={layoutForm.subHeading}
                    onChange={(e) => setLayoutForm({ ...layoutForm, subHeading: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-muted-foreground mb-1">Target Branch</label>
                <select
                  value={layoutForm.branchId}
                  onChange={(e) => setLayoutForm({ ...layoutForm, branchId: e.target.value })}
                  className="w-full h-10 px-3 rounded-md bg-background border border-border/60 text-sm"
                >
                  <option value="">All Branches (Business Wide)</option>
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>
              </div>

              {/* Toggles */}
              <div className="space-y-2 pt-2 border-t border-border/40">
                <span className="text-xs font-bold text-foreground block">Display Toggles & Fields</span>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={layoutForm.showLogo}
                      onChange={(e) => setLayoutForm({ ...layoutForm, showLogo: e.target.checked })}
                      className="rounded border-border/60 text-primary"
                    /> Show Logo
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={layoutForm.showTaxDetails}
                      onChange={(e) => setLayoutForm({ ...layoutForm, showTaxDetails: e.target.checked })}
                      className="rounded border-border/60 text-primary"
                    /> Show Tax Details
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={layoutForm.showCustomerDetails}
                      onChange={(e) => setLayoutForm({ ...layoutForm, showCustomerDetails: e.target.checked })}
                      className="rounded border-border/60 text-primary"
                    /> Show Customer Info
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={layoutForm.showSku}
                      onChange={(e) => setLayoutForm({ ...layoutForm, showSku: e.target.checked })}
                      className="rounded border-border/60 text-primary"
                    /> Show SKU
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={layoutForm.showDiscount}
                      onChange={(e) => setLayoutForm({ ...layoutForm, showDiscount: e.target.checked })}
                      className="rounded border-border/60 text-primary"
                    /> Show Discount
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={layoutForm.showTax}
                      onChange={(e) => setLayoutForm({ ...layoutForm, showTax: e.target.checked })}
                      className="rounded border-border/60 text-primary"
                    /> Show Tax Column
                  </label>
                </div>
              </div>

              {/* Text Areas */}
              <div className="space-y-3 pt-2">
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground mb-1">Footer Message</label>
                  <Input
                    type="text"
                    placeholder="e.g. Thank you for your business!"
                    value={layoutForm.footerText}
                    onChange={(e) => setLayoutForm({ ...layoutForm, footerText: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground mb-1">Terms & Conditions</label>
                  <textarea
                    rows={3}
                    placeholder="Enter terms and conditions to be printed at bottom of bill..."
                    value={layoutForm.termsConditions}
                    onChange={(e) => setLayoutForm({ ...layoutForm, termsConditions: e.target.value })}
                    className="w-full p-2.5 rounded-md bg-background border border-border/60 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground mb-1">Bank Account Details (For Payments)</label>
                  <textarea
                    rows={2}
                    placeholder="Bank Name, Account No, IFSC Code, UPI ID..."
                    value={layoutForm.bankDetails}
                    onChange={(e) => setLayoutForm({ ...layoutForm, bankDetails: e.target.value })}
                    className="w-full p-2.5 rounded-md bg-background border border-border/60 text-xs font-mono"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="layoutDefault"
                  checked={layoutForm.isDefault}
                  onChange={(e) => setLayoutForm({ ...layoutForm, isDefault: e.target.checked })}
                  className="rounded border-border/60 text-primary"
                />
                <label htmlFor="layoutDefault" className="text-xs font-medium cursor-pointer">
                  Set as Default Invoice Layout for Business
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-border/60">
                <Button type="button" variant="outline" onClick={() => setLayoutModalOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={saving}>
                  {saving ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : null} Save Layout
                </Button>
              </div>
            </form>

            {/* Live Template Preview Column */}
            <div className="lg:col-span-6 p-5 bg-muted/10 overflow-y-auto max-h-[82vh] flex flex-col items-center justify-start border-t lg:border-t-0 border-border/60">
              <div className="w-full flex items-center justify-between mb-3 border-b border-border/40 pb-2">
                <span className="font-bold text-xs uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                  <Eye className="w-3.5 h-3.5 text-primary" /> Live Template Preview
                </span>
                <span className="text-[10px] bg-primary/10 text-primary font-bold px-2 py-0.5 rounded">
                  {layoutForm.paperSize}
                </span>
              </div>

              <InvoiceRenderer
                sale={{
                  id: "demo_01",
                  invoiceNumber: "INV-2026/0001",
                  saleDate: new Date(),
                  discountAmount: 50,
                  taxAmount: 36,
                  grandTotal: 486,
                  amountPaid: 486,
                  customer: {
                    name: "Sample Customer",
                    phone: "+91 9876543210",
                    address: "123 Business Street, City, India",
                    taxNumber: "33AAAAA0000A1Z5",
                  },
                  branch: {
                    name: "Main Branch",
                    address: "Branch Address Road",
                    phone: "+91 44 23456789",
                  },
                  saleLines: [
                    {
                      id: "l1",
                      quantity: 2,
                      unitPrice: 200,
                      discountAmount: 20,
                      taxAmount: 18,
                      subtotal: 398,
                      variant: {
                        name: "Sample Product - Standard",
                        sku: "PROD-SKU-01",
                        product: { name: "Sample Product" },
                      },
                    },
                    {
                      id: "l2",
                      quantity: 1,
                      unitPrice: 100,
                      discountAmount: 30,
                      taxAmount: 18,
                      subtotal: 88,
                      variant: {
                        name: "Accessory Item",
                        sku: "ACC-SKU-02",
                        product: { name: "Accessory Item" },
                      },
                    },
                  ],
                }}
                layout={{
                  id: "preview",
                  name: layoutForm.name,
                  headerText: layoutForm.headerText,
                  subHeading: layoutForm.subHeading,
                  showLogo: layoutForm.showLogo,
                  showTaxDetails: layoutForm.showTaxDetails,
                  showCustomerDetails: layoutForm.showCustomerDetails,
                  showSku: layoutForm.showSku,
                  showDescription: layoutForm.showDescription,
                  showDiscount: layoutForm.showDiscount,
                  showTax: layoutForm.showTax,
                  footerText: layoutForm.footerText,
                  termsConditions: layoutForm.termsConditions,
                  bankDetails: layoutForm.bankDetails,
                  paperSize: layoutForm.paperSize,
                  isDefault: layoutForm.isDefault,
                  businessId,
                }}
                businessName={currentUser?.business?.name || "HKR ERP Store"}
              />
            </div>
          </div>
        </div>
      </div>
      )}

      {/* ================= DELETE CONFIRM MODAL ================= */}
      {deleteModalOpen && deleteItem && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-card border border-border/80 rounded-xl shadow-xl w-full max-w-sm p-5 space-y-4">
            <h3 className="font-bold text-base text-foreground">Confirm Deletion</h3>
            <p className="text-xs text-muted-foreground">
              Are you sure you want to delete <span className="font-bold text-foreground">{deleteItem.name}</span>?
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" size="sm" onClick={() => setDeleteModalOpen(false)}>
                Cancel
              </Button>
              <Button variant="destructive" size="sm" onClick={confirmDelete} disabled={saving}>
                {saving ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : null} Delete
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
