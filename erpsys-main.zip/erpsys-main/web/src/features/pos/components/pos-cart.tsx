import React, { useState } from "react";
import { Trash2, Plus, Minus, CreditCard, RefreshCw, FolderPlus, Package, Lock, FileText, Check, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { CustomerSelect } from "./customer-select";
import { CartItem } from "../types";
import { User } from "@hkr/types";
import { BranchItem } from "@/features/customers";
import { getFullAssetUrl, cn } from "@/lib/utils";
import { useCurrency } from "@/hooks/use-currency";
import { usePermissions } from "@/hooks/use-permissions";

interface POSCartProps {
  cartItems: CartItem[];
  onUpdateQty: (variantId: string, quantity: number, imeiNumber?: string) => void;
  onRemoveItem: (variantId: string, imeiNumber?: string) => void;
  onClearCart: () => void;
  selectedCustomerId: string;
  onCustomerChange: (id: string) => void;
  discountType: "FIXED" | "PERCENTAGE";
  onDiscountTypeChange: (val: "FIXED" | "PERCENTAGE") => void;
  discountAmount: number;
  onDiscountAmountChange: (val: number) => void;
  businessId: string;
  branchId: string;
  branches: BranchItem[];
  onOpenPayment: () => void;
  onHold: () => void;
  onQuotation: () => void;
  isPending?: boolean;
  currentUser?: User | null;
  editingInvoiceNumber?: string | null;
  onCancelEdit?: () => void;
  checkoutShortcut?: string;
  holdShortcut?: string;
}

export function POSCart({
  cartItems,
  onUpdateQty,
  onRemoveItem,
  onClearCart,
  selectedCustomerId,
  onCustomerChange,
  discountType,
  onDiscountTypeChange,
  discountAmount,
  onDiscountAmountChange,
  businessId,
  branchId,
  branches,
  onOpenPayment,
  onHold,
  onQuotation,
  isPending = false,
  currentUser,
  editingInvoiceNumber,
  onCancelEdit,
  checkoutShortcut = "F2",
  holdShortcut = "F6",
}: POSCartProps) {
  const { hasPermission } = usePermissions();
  const canApplyDiscount = hasPermission("pos:apply_discount");
  const canHoldSale = hasPermission("pos:hold_sale") || hasPermission("pos:draft_sale");
  const canCreateQuotation = hasPermission("quotations:create");
  const { symbol, format } = useCurrency(businessId);
  const subtotal = cartItems.reduce((sum, item) => sum + item.subtotal, 0);

  const discountVal = React.useMemo(() => {
    if (discountType === "PERCENTAGE") {
      return (subtotal * discountAmount) / 100;
    }
    return discountAmount;
  }, [subtotal, discountType, discountAmount]);

  const grandTotal = Math.max(0, subtotal - discountVal);

  return (
    <div className="flex flex-col h-full bg-background/30 border border-border p-4 rounded-sm gap-4">
      {/* Editing Sale Banner */}
      {editingInvoiceNumber && (
        <div className="bg-amber-500/15 border border-amber-500/30 text-amber-500 px-3 py-1.5 rounded-sm flex items-center justify-between text-xs font-bold shrink-0">
          <span className="flex items-center gap-1.5 truncate">
            <AlertTriangle className="h-3.5 w-3.5 shrink-0 animate-pulse text-amber-400" />
            Editing Invoice: <strong className="font-mono text-foreground">{editingInvoiceNumber}</strong>
          </span>
          {onCancelEdit && (
            <button
              type="button"
              onClick={onCancelEdit}
              className="text-[11px] text-muted-foreground hover:text-foreground underline whitespace-nowrap ml-2 cursor-pointer"
            >
              Cancel Edit
            </button>
          )}
        </div>
      )}

      {/* Customer Selection Row */}
      <div className="space-y-1">
        <CustomerSelect
          selectedCustomerId={selectedCustomerId}
          onCustomerChange={onCustomerChange}
          businessId={businessId}
          branchId={branchId}
          branches={branches}
          currentUser={currentUser}
        />
      </div>

      {/* Cart Items List */}
      <div className="flex-1 overflow-y-auto min-h-[220px] border border-border/60 rounded bg-background/20 p-2">
        {cartItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-muted-foreground/60 py-8 select-none">
            {/* World Map Animation */}
            <div className="mb-3 animate-map-float flex items-center justify-center w-full">
              <svg width="220" height="130" viewBox="0 0 240 140" fill="none" xmlns="http://www.w3.org/2000/svg" className="opacity-40 hover:opacity-75 transition-opacity duration-500">
                <style>
                  {`
                    @keyframes mapDash {
                      to {
                        stroke-dashoffset: -20;
                      }
                    }
                    @keyframes mapRipple {
                      0% {
                        r: 2px;
                        opacity: 0.8;
                      }
                      100% {
                        r: 14px;
                        opacity: 0;
                      }
                    }
                    @keyframes mapFloat {
                      0%, 100% {
                        transform: translateY(0px);
                      }
                      50% {
                        transform: translateY(-8px);
                      }
                    }
                    .animate-map-dash {
                      stroke-dasharray: 4, 4;
                      animation: mapDash 1.5s linear infinite;
                    }
                    .animate-map-ripple {
                      animation: mapRipple 2.5s cubic-bezier(0.16, 1, 0.3, 1) infinite;
                      transform-origin: center;
                    }
                    .animate-map-float {
                      animation: mapFloat 4s ease-in-out infinite;
                    }
                  `}
                </style>

                {/* World Map Abstract grid pattern */}
                <g className="text-muted-foreground/20" stroke="currentColor" strokeWidth="0.5">
                  <line x1="10" y1="20" x2="230" y2="20" strokeDasharray="1 5" />
                  <line x1="10" y1="45" x2="230" y2="45" strokeDasharray="1 5" />
                  <line x1="10" y1="70" x2="230" y2="70" strokeDasharray="1 5" />
                  <line x1="10" y1="95" x2="230" y2="95" strokeDasharray="1 5" />
                  <line x1="10" y1="120" x2="230" y2="120" strokeDasharray="1 5" />

                  <line x1="30" y1="10" x2="30" y2="130" strokeDasharray="1 5" />
                  <line x1="70" y1="10" x2="70" y2="130" strokeDasharray="1 5" />
                  <line x1="110" y1="10" x2="110" y2="130" strokeDasharray="1 5" />
                  <line x1="150" y1="10" x2="150" y2="130" strokeDasharray="1 5" />
                  <line x1="190" y1="10" x2="190" y2="130" strokeDasharray="1 5" />
                </g>

                {/* Map Connections */}
                <path d="M35 40 Q 65 25, 95 30" stroke="currentColor" strokeWidth="1" className="text-muted-foreground/10" />
                <path d="M35 40 Q 65 25, 95 30" stroke="hsl(var(--primary))" strokeWidth="1" className="animate-map-dash" opacity="0.45" />

                <path d="M35 40 Q 40 65, 55 90" stroke="currentColor" strokeWidth="1" className="text-muted-foreground/10" />
                <path d="M35 40 Q 40 65, 55 90" stroke="hsl(var(--primary))" strokeWidth="1" className="animate-map-dash" opacity="0.45" />

                <path d="M95 30 Q 105 55, 110 80" stroke="currentColor" strokeWidth="1" className="text-muted-foreground/10" />
                <path d="M95 30 Q 105 55, 110 80" stroke="hsl(var(--primary))" strokeWidth="1" className="animate-map-dash" opacity="0.45" />

                <path d="M95 30 Q 125 25, 160 40" stroke="currentColor" strokeWidth="1" className="text-muted-foreground/10" />
                <path d="M95 30 Q 125 25, 160 40" stroke="hsl(var(--primary))" strokeWidth="1" className="animate-map-dash" opacity="0.45" />

                <path d="M160 40 Q 185 70, 200 100" stroke="currentColor" strokeWidth="1" className="text-muted-foreground/10" />
                <path d="M160 40 Q 185 70, 200 100" stroke="hsl(var(--primary))" strokeWidth="1" className="animate-map-dash" opacity="0.45" />

                <path d="M160 40 Q 135 60, 110 80" stroke="currentColor" strokeWidth="1" className="text-muted-foreground/10" />
                <path d="M160 40 Q 135 60, 110 80" stroke="hsl(var(--primary))" strokeWidth="1" className="animate-map-dash" opacity="0.45" />

                <path d="M55 90 Q 82 85, 110 80" stroke="currentColor" strokeWidth="1" className="text-muted-foreground/10" />
                <path d="M55 90 Q 82 85, 110 80" stroke="hsl(var(--primary))" strokeWidth="1" className="animate-map-dash" opacity="0.45" />

                {/* Pulsing Nodes */}
                {/* Node 1: North America */}
                <g>
                  <circle cx="35" cy="40" r="2" fill="hsl(var(--primary))" className="animate-map-ripple" style={{ animationDelay: '0s' }} />
                  <circle cx="35" cy="40" r="3.5" fill="hsl(var(--primary))" className="transition-all hover:scale-150" />
                </g>

                {/* Node 2: South America */}
                <g>
                  <circle cx="55" cy="90" r="2" fill="hsl(var(--primary))" className="animate-map-ripple" style={{ animationDelay: '0.5s' }} />
                  <circle cx="55" cy="90" r="3.5" fill="hsl(var(--primary))" className="transition-all hover:scale-150" />
                </g>

                {/* Node 3: Europe */}
                <g>
                  <circle cx="95" cy="30" r="2" fill="hsl(var(--primary))" className="animate-map-ripple" style={{ animationDelay: '1s' }} />
                  <circle cx="95" cy="30" r="3.5" fill="hsl(var(--primary))" className="transition-all hover:scale-150" />
                </g>

                {/* Node 4: Africa */}
                <g>
                  <circle cx="110" cy="80" r="2" fill="hsl(var(--primary))" className="animate-map-ripple" style={{ animationDelay: '1.5s' }} />
                  <circle cx="110" cy="80" r="3.5" fill="hsl(var(--primary))" className="transition-all hover:scale-150" />
                </g>

                {/* Node 5: Asia */}
                <g>
                  <circle cx="160" cy="40" r="2" fill="hsl(var(--primary))" className="animate-map-ripple" style={{ animationDelay: '2s' }} />
                  <circle cx="160" cy="40" r="3.5" fill="hsl(var(--primary))" className="transition-all hover:scale-150" />
                </g>

                {/* Node 6: Australia */}
                <g>
                  <circle cx="200" cy="100" r="2" fill="hsl(var(--primary))" className="animate-map-ripple" style={{ animationDelay: '2.5s' }} />
                  <circle cx="200" cy="100" r="3.5" fill="hsl(var(--primary))" className="transition-all hover:scale-150" />
                </g>
              </svg>
            </div>
            <span className="text-xs font-semibold">Your billing cart is empty</span>
            <span className="text-[10px] italic mt-1">Select items or scan barcode to begin</span>
          </div>
        ) : (
          <div className="space-y-2">
            {cartItems.map((item) => (
              <div
                key={item.imeiNumber ? `${item.variantId}_${item.imeiNumber}` : item.variantId}
                className="flex items-center justify-between p-2.5 bg-background/60 border border-border/40 rounded-sm hover:border-border transition-all gap-3"
              >
                {/* Item Image */}
                <div className="h-14 w-14 rounded bg-muted/40 border border-border flex items-center justify-center overflow-hidden shrink-0" style={{ aspectRatio: "1 / 1" }}>
                  {item.imageUrl ? (
                    <img src={getFullAssetUrl(item.imageUrl) || ""} alt={item.productName} className="w-full h-full object-cover" />
                  ) : (
                    <Package className="h-7 w-7 text-muted-foreground/40" />
                  )}
                </div>

                {/* Item Info */}
                <div className="flex-1 min-w-0 pr-2">
                  <span className="text-xs font-bold text-foreground block truncate">
                    {item.productName}
                  </span>
                  <span className="text-[10px] text-muted-foreground block truncate font-mono">
                    {item.variantName !== item.productName ? `${item.variantName} | ` : ""}SKU: {item.sku}
                  </span>
                  {item.imeiNumber && (
                    <div className="flex items-center gap-1 mt-0.5">
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/15 text-amber-400 font-mono font-bold border border-amber-500/30 truncate max-w-full">
                        IMEI: {item.imeiNumber}
                      </span>
                    </div>
                  )}
                  <span className="text-[10px] font-bold text-primary mt-0.5 block">
                    {format(item.unitPrice)}
                  </span>
                </div>

                {/* Quantity Controls */}
                <div className="flex items-center gap-1.5 shrink-0 px-2">
                  {item.isImei || item.imeiNumber ? (
                    <span className="text-[11px] font-mono font-bold text-muted-foreground bg-secondary/50 px-2 py-0.5 rounded border border-border">
                      1 Unit
                    </span>
                  ) : (
                    <>
                      <button
                        type="button"
                        onClick={() => onUpdateQty(item.variantId, item.quantity - 1)}
                        className="h-6 w-6 rounded-full border border-input flex items-center justify-center hover:bg-secondary transition-all"
                      >
                        <Minus className="h-3 w-3 text-foreground" />
                      </button>
                      <span className="text-xs font-bold w-6 text-center text-foreground">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => onUpdateQty(item.variantId, item.quantity + 1)}
                        className="h-6 w-6 rounded-full border border-input flex items-center justify-center hover:bg-secondary transition-all"
                      >
                        <Plus className="h-3 w-3 text-foreground" />
                      </button>
                    </>
                  )}
                </div>

                {/* Subtotal & Delete */}
                <div className="flex items-center gap-3 shrink-0 text-right">
                  <span className="text-xs font-bold text-foreground w-16 block">
                    {format(item.subtotal)}
                  </span>
                  <button
                    type="button"
                    onClick={() => onRemoveItem(item.variantId, item.imeiNumber)}
                    className="h-7 w-7 text-destructive hover:bg-destructive/10 rounded flex items-center justify-center transition-all"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Summary / Total Section */}
      <div className="border-t border-border/80 pt-4 space-y-3">
        {/* Discount Fields */}
        <div className="grid grid-cols-3 gap-2">
          <div className="col-span-1 space-y-1">
            <label className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1">
              Disc. Type {!canApplyDiscount && <Lock className="h-2.5 w-2.5 text-muted-foreground/60" />}
            </label>
            <Select
              value={discountType}
              disabled={!canApplyDiscount}
              onValueChange={(val: any) => onDiscountTypeChange(val)}
              className="h-9 text-xs bg-background/50 border border-input rounded-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <option value="FIXED">{symbol} (Fixed)</option>
              <option value="PERCENTAGE">% (Percent)</option>
            </Select>
          </div>
          <div className="col-span-2 space-y-1">
            <label className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1">
              Discount Amount {!canApplyDiscount && <span className="text-[8px] text-muted-foreground/70 normal-case">(Locked)</span>}
            </label>
            <Input
              type="number"
              min={0}
              placeholder={canApplyDiscount ? "0.00" : "Permission required"}
              disabled={!canApplyDiscount}
              value={discountAmount === 0 ? "" : discountAmount}
              onChange={(e) => {
                const val = parseFloat(e.target.value);
                onDiscountAmountChange(isNaN(val) ? 0 : val);
              }}
              className="h-9 text-xs bg-background/50 border border-input rounded-sm disabled:opacity-50 disabled:cursor-not-allowed"
            />
          </div>
        </div>

        {/* Computations list */}
        <div className="space-y-1.5 text-xs text-muted-foreground font-semibold">
          <div className="flex justify-between">
            <span>Subtotal:</span>
            <span className="text-foreground">{format(subtotal)}</span>
          </div>
          {discountVal > 0 && (
            <div className="flex justify-between text-rose-500 font-bold">
              <span>Discount:</span>
              <span>-{format(discountVal)}</span>
            </div>
          )}
          <div className="flex justify-between text-sm font-extrabold text-foreground border-t border-border/60 pt-2.5">
            <span>Grand Total:</span>
            <span className="text-primary text-base font-black">{format(grandTotal)}</span>
          </div>
        </div>
      </div>

      {/* Bottom Cart Actions */}
      <div className="grid grid-cols-4 gap-1.5 border-t border-border pt-3">
        <Button
          type="button"
          variant="outline"
          onClick={onClearCart}
          disabled={cartItems.length === 0}
          className="h-10 text-xs border-border hover:bg-destructive/10 hover:text-destructive hover:border-destructive/20 rounded-sm"
        >
          <RefreshCw className="h-3.5 w-3.5 mr-1" />
          Clear
        </Button>
        <Button
          type="button"
          variant="secondary"
          onClick={onHold}
          disabled={cartItems.length === 0 || isPending || !canHoldSale}
          className="h-10 text-xs bg-secondary border border-border hover:bg-secondary/80 text-foreground disabled:opacity-50 disabled:cursor-not-allowed rounded-sm"
          title={!canHoldSale ? "Permission required to hold bills (pos:hold_sale)" : "Hold Current Bill"}
        >
          <FolderPlus className="h-3.5 w-3.5 mr-1" />
          Hold ({holdShortcut})
        </Button>
        <Button
          type="button"
          variant="secondary"
          onClick={onQuotation}
          disabled={cartItems.length === 0 || isPending || !canCreateQuotation}
          className="h-10 text-xs bg-secondary border border-border hover:bg-secondary/80 text-foreground disabled:opacity-50 disabled:cursor-not-allowed rounded-sm"
          title={!canCreateQuotation ? "Permission required to create quotation (quotations:create)" : "Save Cart as Price Quotation"}
        >
          <FileText className="h-3.5 w-3.5 mr-1 text-primary" />
          Quote
        </Button>
        <Button
          type="button"
          onClick={onOpenPayment}
          disabled={cartItems.length === 0 || isPending}
          className={cn(
            "h-10 text-xs font-bold flex items-center justify-center gap-1 rounded-sm shadow-sm transition-all",
            editingInvoiceNumber
              ? "bg-amber-500 text-black hover:bg-amber-400"
              : "bg-primary text-black hover:bg-primary/90"
          )}
        >
          {editingInvoiceNumber ? (
            <>
              <Check className="h-3.5 w-3.5" />
              Update ({checkoutShortcut})
            </>
          ) : (
            <>
              <CreditCard className="h-3.5 w-3.5" />
              Pay ({checkoutShortcut})
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
