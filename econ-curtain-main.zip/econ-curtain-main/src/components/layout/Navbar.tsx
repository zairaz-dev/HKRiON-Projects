"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Menu,
  X,
  MessageSquare,
  Sparkles,
  ChevronRight,
  Home,
  Info,
  Layers,
  Wrench,
  FolderKanban,
  PhoneCall,
} from "lucide-react";
import Logo from "@/components/ui/Logo";

const navLinks = [
  { name: "Home", href: "/", icon: Home },
  { name: "About Us", href: "/about", icon: Info },
  { name: "Products", href: "/products", icon: Layers },
  { name: "Services", href: "/services", icon: Wrench },
  { name: "Projects", href: "/projects", icon: FolderKanban },
  { name: "Contact", href: "/contact", icon: PhoneCall },
];

interface NavbarProps {
  whatsappNumber?: string;
}

export default function Navbar({ whatsappNumber }: NavbarProps = {}) {
  const cleanNumber = whatsappNumber ? whatsappNumber.replace(/[^0-9]/g, '') : "94758079921";
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const pathname = usePathname();

  // Close mobile menu on route change
  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  // Lock background body scroll when mobile menu is open
  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  // Handle scroll effect for navbar styling
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      {/* Main Fixed Navbar Header */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ease-in-out bg-slate-950/95 backdrop-blur-xl border-b ${
          scrolled
            ? "border-amber-500/20 shadow-2xl py-2.5 sm:py-3 shadow-black/60"
            : "border-slate-800/60 shadow-lg py-3 sm:py-3.5 shadow-black/40"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-12 sm:h-14">
            {/* Brand Logo */}
            <Link
              href="/"
              className="flex items-center shrink-0 min-w-0 transition-transform active:scale-95 duration-200"
              onClick={() => setMobileOpen(false)}
              aria-label="Shadeit Blinds Home"
            >
              <Logo className="h-9 sm:h-11 md:h-12 w-auto max-w-44 sm:max-w-64 md:max-w-76" />
            </Link>

            {/* Desktop Navigation Links */}
            <nav className="hidden md:flex items-center space-x-1 lg:space-x-2 bg-slate-900/60 p-1.5 rounded-full border border-slate-800/80 backdrop-blur-xl shadow-inner shadow-black/30">
              {navLinks.map((link) => {
                const isActive = pathname === link.href;
                return (
                  <Link
                    key={link.name}
                    href={link.href}
                    className={`relative px-3.5 py-1.5 rounded-full text-xs lg:text-sm font-medium transition-all duration-200 flex items-center gap-1.5 ${
                      isActive
                        ? "text-slate-950 bg-linear-to-r from-amber-400 via-yellow-300 to-amber-500 font-bold shadow-md shadow-amber-500/20"
                        : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                    }`}
                  >
                    <span>{link.name}</span>
                    {isActive && (
                      <span className="w-1.5 h-1.5 rounded-full bg-slate-950 animate-ping shrink-0" />
                    )}
                  </Link>
                );
              })}
            </nav>

            {/* Desktop Actions (Quote CTA) */}
            <div className="hidden md:flex items-center gap-3">
              <Link
                href="/contact"
                className="group relative inline-flex items-center gap-2 bg-linear-to-r from-amber-400 via-yellow-400 to-amber-500 text-slate-950 px-4.5 py-2 rounded-full text-xs lg:text-sm font-bold shadow-lg shadow-amber-500/25 hover:shadow-amber-500/40 hover:brightness-110 active:scale-95 transition-all duration-200"
              >
                <Sparkles size={14} className="group-hover:rotate-12 transition-transform duration-300" />
                <span>Get a Quote</span>
              </Link>
            </div>

            {/* Mobile Menu Button Trigger - Pure Standard Button (Instant Touch & Click) */}
            <div className="md:hidden flex items-center shrink-0 ml-2">
              <button
                type="button"
                onClick={() => setMobileOpen((prev) => !prev)}
                className="relative z-50 p-2.5 rounded-xl text-white bg-slate-900 border border-slate-700 active:bg-slate-800 active:scale-95 transition-all cursor-pointer shadow-lg flex items-center justify-center w-11 h-11 select-none hover:border-amber-400/50"
                aria-label={mobileOpen ? "Close navigation menu" : "Open navigation menu"}
                aria-expanded={mobileOpen}
              >
                {mobileOpen ? (
                  <X size={24} className="text-amber-400 transition-transform rotate-90 duration-200" />
                ) : (
                  <Menu size={24} className="text-amber-400 transition-transform duration-200" />
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Backdrop Dark Blur Overlay */}
      <div
        onClick={() => setMobileOpen(false)}
        className={`fixed inset-0 bg-black/60 backdrop-blur-xs z-40 md:hidden transition-opacity duration-300 ${
          mobileOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
        aria-hidden="true"
      />

      {/* Mobile Floating Glassmorphism Menu Card */}
      <aside
        className={`fixed top-18 right-3 z-50 w-[86vw] max-w-[280px] bg-slate-950/95 backdrop-blur-2xl border border-amber-400/30 shadow-[0_20px_50px_rgba(0,0,0,0.9),0_0_25px_rgba(245,158,11,0.15)] ring-1 ring-white/10 rounded-3xl p-3 md:hidden transition-all duration-300 ease-out origin-top-right overflow-hidden ${
          mobileOpen
            ? "opacity-100 scale-100 translate-y-0 pointer-events-auto"
            : "opacity-0 scale-95 -translate-y-2 pointer-events-none"
        }`}
        aria-label="Mobile Navigation Menu"
      >
        {/* Subtle Ambient Radial Glow inside Glass Card */}
        <div className="absolute -top-12 -right-12 w-28 h-28 rounded-full bg-amber-500/20 blur-2xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 w-28 h-28 rounded-full bg-amber-400/10 blur-2xl pointer-events-none" />

        {/* Compact Navigation Links */}
        <div className="space-y-1 relative z-10">
          {navLinks.map((link) => {
            const isActive = pathname === link.href;
            const Icon = link.icon;
            return (
              <Link
                key={link.name}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className={`flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 active:scale-[0.98] ${
                  isActive
                    ? "bg-amber-400/20 text-amber-300 border border-amber-400/50 font-bold shadow-xs shadow-amber-500/10"
                    : "text-slate-300 hover:bg-slate-900/80 hover:text-white border border-transparent"
                }`}
              >
                <span className="flex items-center gap-2.5">
                  <Icon size={15} className={isActive ? "text-amber-400" : "text-slate-400"} />
                  <span>{link.name}</span>
                </span>
                <ChevronRight size={13} className={isActive ? "text-amber-400" : "text-slate-600"} />
              </Link>
            );
          })}
        </div>

        {/* Subtle Golden Glowing Divider */}
        <div className="h-px bg-linear-to-r from-transparent via-amber-400/30 to-transparent my-2 relative z-10" />

        {/* Compact Action CTAs */}
        <div className="space-y-1.5 relative z-10">
          <Link
            href="/contact"
            onClick={() => setMobileOpen(false)}
            className="flex items-center justify-center gap-1.5 w-full bg-linear-to-r from-amber-400 via-yellow-400 to-amber-500 text-slate-950 px-3 py-2.5 rounded-xl font-bold hover:brightness-110 active:scale-98 transition-all shadow-md shadow-amber-500/20 text-xs"
          >
            <Sparkles size={13} />
            <span>Get a Free Quote</span>
          </Link>
          <a
            href={`https://wa.me/${cleanNumber}`}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => setMobileOpen(false)}
            className="flex items-center justify-center gap-1.5 w-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-3 py-2 rounded-xl font-semibold hover:bg-emerald-500/25 active:scale-98 transition-all text-[11px]"
          >
            <MessageSquare size={13} />
            <span>WhatsApp Inquiry</span>
          </a>
          <p className="text-[8.5px] text-slate-500 text-center font-mono tracking-widest pt-0.5">
            SHADEIT BLINDS © 2026
          </p>
        </div>
      </aside>
    </>
  );
}
