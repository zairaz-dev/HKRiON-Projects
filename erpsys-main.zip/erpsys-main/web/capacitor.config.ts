import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.hkr.ionerp',
  appName: 'HKR ION ERP',
  webDir: 'out',
  server: {
    androidScheme: 'https'
  }
};

export default config;
