import { db } from "@/core/db/client";

export interface AboutPageContentData {
  id: string;

  // Hero Section
  heroBadge: string;
  heroTitleLine1: string;
  heroTitleHighlight: string;
  heroSubtitle: string;

  // Big Brand Statement
  statementPrefix: string;
  statementHighlight: string;
  statementDescription: string;

  // Our Story
  storyBadge: string;
  storyTitle: string;
  storyPara1: string;
  storyPara2: string;
  storyImageUrl: string;
  storyCardTag: string;
  storyCardTitle: string;
  storyCardYears: string;
  storyStat1Value: number;
  storyStat1Label: string;
  storyStat2Value: number;
  storyStat2Label: string;

  // Mission & Vision
  missionTitle: string;
  missionDescription: string;
  visionTitle: string;
  visionDescription: string;

  // Why ShadeIt
  whyBadge: string;
  whyTitle: string;
  whyPoints: string;

  // Closing CTA
  ctaBadge: string;
  ctaTitle: string;
  ctaSubtitle: string;
  ctaButtonText: string;
  ctaButtonLink: string;

  updatedAt?: Date;
}

export const defaultAboutPageContent: AboutPageContentData = {
  id: "about_default",

  // Hero Section
  heroBadge: "ABOUT SHADEIT BLINDS",
  heroTitleLine1: "We Shape Light.",
  heroTitleHighlight: "We Create Comfort.",
  heroSubtitle: "Premium window covering and outdoor shade solutions designed for modern residential homes and architectural commercial spaces.",

  // Big Brand Statement
  statementPrefix: "More Than Blinds.",
  statementHighlight: "We Transform Spaces.",
  statementDescription: "From elegant interiors to functional outdoor spaces, SHADEIT BLINDS delivers customized solutions that balance design aesthetics, thermal comfort, and privacy performance.",

  // Our Story
  storyBadge: "OUR STORY",
  storyTitle: "Designed Around The Way You Live.",
  storyPara1: "SHADEIT BLINDS was built with a simple philosophy — beautiful interior and exterior spaces should also be supremely comfortable and functional.",
  storyPara2: "From residential villas needing automated quiet motorization to commercial office skyscrapers requiring solar heat glare reduction, we engineer customized window coverings and outdoor shade architectures built to last.",
  storyImageUrl: "/gallery_1.png",
  storyCardTag: "Established Excellence",
  storyCardTitle: "Custom Automated Window Systems",
  storyCardYears: "10+ Yrs",
  storyStat1Value: 10,
  storyStat1Label: "Years Experience",
  storyStat2Value: 500,
  storyStat2Label: "Projects Completed",

  // Mission & Vision
  missionTitle: "Creating spaces that feel beautiful, comfortable, and complete.",
  missionDescription: "To transform residential and commercial properties with innovative, high-quality window coverings and outdoor shade systems that balance design aesthetics with solar performance.",
  visionTitle: "To become the most trusted brand in architectural shade solutions.",
  visionDescription: "To continuously innovate our shading products, smart motorization hubs, and weather-resistant textiles while maintaining uncompromising craftsmanship.",

  // Why ShadeIt
  whyBadge: "WHY SHADEIT",
  whyTitle: "Thoughtfully Designed. Professionally Installed. Built to Last.",
  whyPoints: "Custom Fit, Premium Fabrics, Professional Fitting, Residential & Commercial, Outdoor Expertise",

  // Closing CTA
  ctaBadge: "Elevate Your Space",
  ctaTitle: "Ready to Transform Your Space?",
  ctaSubtitle: "Let's create something beautiful together. Book a free site measurement and personalized design consultation with our shading experts today.",
  ctaButtonText: "Get Free Consultation",
  ctaButtonLink: "/contact",
};

export class AboutService {
  /**
   * Retrieves the about page content from SQLite or creates default if not exists
   */
  static async getContent(): Promise<AboutPageContentData> {
    try {
      const content = await db.aboutPageContent.findUnique({
        where: { id: "about_default" },
      });

      if (!content) {
        return await db.aboutPageContent.create({
          data: {
            ...defaultAboutPageContent,
          },
        });
      }

      return content;
    } catch (e) {
      console.error("Failed to load about page content from DB, returning defaults:", e);
      return defaultAboutPageContent;
    }
  }

  /**
   * Updates about page content
   */
  static async updateContent(data: Partial<AboutPageContentData>): Promise<AboutPageContentData> {
    try {
      const updated = await db.aboutPageContent.upsert({
        where: { id: "about_default" },
        update: {
          ...data,
          updatedAt: new Date(),
        },
        create: {
          ...defaultAboutPageContent,
          ...data,
        },
      });

      return updated;
    } catch (e) {
      console.error("Failed to update about page content:", e);
      throw e;
    }
  }
}
