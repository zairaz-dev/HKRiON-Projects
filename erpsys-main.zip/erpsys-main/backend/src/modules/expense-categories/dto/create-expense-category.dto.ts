export class CreateExpenseCategoryDto {
  name: string;
  code?: string;
  description?: string;
  parentId?: string;
  businessId: string;
  branchIds?: string[];
  createdById?: string;
}
