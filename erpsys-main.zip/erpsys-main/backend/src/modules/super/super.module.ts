import { Module } from '@nestjs/common';
import { SuperController } from './super.controller';
import { SuperAnalyticsService } from './super-analytics.service';
import { AuthModule } from '../auth/auth.module';
import { BusinessModule } from '../business/business.module';
import { PrismaModule } from '../prisma/prisma.module';

@Module({
  imports: [AuthModule, BusinessModule, PrismaModule],
  controllers: [SuperController],
  providers: [SuperAnalyticsService],
  exports: [SuperAnalyticsService],
})
export class SuperModule {}
