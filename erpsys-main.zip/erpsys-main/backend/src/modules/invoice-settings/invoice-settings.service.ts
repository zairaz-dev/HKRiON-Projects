import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class InvoiceSettingsService {
  constructor(private readonly prisma: PrismaService) {}

  // ==========================================
  // INVOICE SCHEMES
  // ==========================================

  async getSchemes(businessId: string, branchId?: string) {
    const where: any = { businessId };
    if (branchId) {
      where.OR = [{ branchId: null }, { branchId }];
    }
    return this.prisma.invoiceScheme.findMany({
      where,
      include: {
        branch: {
          select: { id: true, name: true }
        }
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getSchemeById(id: string, businessId: string) {
    const scheme = await this.prisma.invoiceScheme.findFirst({
      where: { id, businessId },
      include: {
        branch: { select: { id: true, name: true } }
      }
    });
    if (!scheme) throw new NotFoundException('Invoice scheme not found');
    return scheme;
  }

  async createScheme(businessId: string, data: any) {
    const { name, schemeType, prefix, startNumber, numberOfDigits, isDefault, branchId } = data;

    if (isDefault) {
      await this.prisma.invoiceScheme.updateMany({
        where: { businessId, isDefault: true },
        data: { isDefault: false }
      });
    }

    return this.prisma.invoiceScheme.create({
      data: {
        name,
        schemeType: schemeType || 'FORMATTED',
        prefix,
        startNumber: startNumber ? Number(startNumber) : 1001,
        numberOfDigits: numberOfDigits ? Number(numberOfDigits) : 4,
        isDefault: Boolean(isDefault),
        branchId: branchId || null,
        businessId,
      },
      include: { branch: { select: { id: true, name: true } } }
    });
  }

  async updateScheme(id: string, businessId: string, data: any) {
    await this.getSchemeById(id, businessId);

    const { name, schemeType, prefix, startNumber, numberOfDigits, isDefault, branchId } = data;

    if (isDefault) {
      await this.prisma.invoiceScheme.updateMany({
        where: { businessId, isDefault: true, NOT: { id } },
        data: { isDefault: false }
      });
    }

    return this.prisma.invoiceScheme.update({
      where: { id },
      data: {
        ...(name !== undefined && { name }),
        ...(schemeType !== undefined && { schemeType }),
        ...(prefix !== undefined && { prefix }),
        ...(startNumber !== undefined && { startNumber: Number(startNumber) }),
        ...(numberOfDigits !== undefined && { numberOfDigits: Number(numberOfDigits) }),
        ...(isDefault !== undefined && { isDefault: Boolean(isDefault) }),
        ...(branchId !== undefined && { branchId: branchId || null }),
      },
      include: { branch: { select: { id: true, name: true } } }
    });
  }

  async setDefaultScheme(id: string, businessId: string) {
    await this.getSchemeById(id, businessId);

    await this.prisma.invoiceScheme.updateMany({
      where: { businessId, isDefault: true },
      data: { isDefault: false }
    });

    return this.prisma.invoiceScheme.update({
      where: { id },
      data: { isDefault: true }
    });
  }

  async deleteScheme(id: string, businessId: string) {
    const scheme = await this.getSchemeById(id, businessId);
    if (scheme.isDefault) {
      throw new BadRequestException('Cannot delete default invoice scheme');
    }
    return this.prisma.invoiceScheme.delete({ where: { id } });
  }

  // ==========================================
  // INVOICE LAYOUTS
  // ==========================================

  async getLayouts(businessId: string, branchId?: string) {
    const where: any = { businessId };
    if (branchId) {
      where.OR = [{ branchId: null }, { branchId }];
    }
    return this.prisma.invoiceLayout.findMany({
      where,
      include: {
        branch: {
          select: { id: true, name: true }
        }
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getLayoutById(id: string, businessId: string) {
    const layout = await this.prisma.invoiceLayout.findFirst({
      where: { id, businessId },
      include: {
        branch: { select: { id: true, name: true } }
      }
    });
    if (!layout) throw new NotFoundException('Invoice layout not found');
    return layout;
  }

  async createLayout(businessId: string, data: any) {
    const {
      name, headerText, subHeading, showLogo, showTaxDetails, showCustomerDetails,
      showSku, showDescription, showDiscount, showTax, footerText, termsConditions,
      bankDetails, paperSize, isDefault, branchId
    } = data;

    if (isDefault) {
      await this.prisma.invoiceLayout.updateMany({
        where: { businessId, isDefault: true },
        data: { isDefault: false }
      });
    }

    return this.prisma.invoiceLayout.create({
      data: {
        name,
        headerText,
        subHeading,
        showLogo: showLogo ?? true,
        showTaxDetails: showTaxDetails ?? true,
        showCustomerDetails: showCustomerDetails ?? true,
        showSku: showSku ?? true,
        showDescription: showDescription ?? true,
        showDiscount: showDiscount ?? true,
        showTax: showTax ?? true,
        footerText,
        termsConditions,
        bankDetails,
        paperSize: paperSize || 'A4',
        isDefault: Boolean(isDefault),
        branchId: branchId || null,
        businessId,
      },
      include: { branch: { select: { id: true, name: true } } }
    });
  }

  async updateLayout(id: string, businessId: string, data: any) {
    await this.getLayoutById(id, businessId);

    const {
      name, headerText, subHeading, showLogo, showTaxDetails, showCustomerDetails,
      showSku, showDescription, showDiscount, showTax, footerText, termsConditions,
      bankDetails, paperSize, isDefault, branchId
    } = data;

    if (isDefault) {
      await this.prisma.invoiceLayout.updateMany({
        where: { businessId, isDefault: true, NOT: { id } },
        data: { isDefault: false }
      });
    }

    return this.prisma.invoiceLayout.update({
      where: { id },
      data: {
        ...(name !== undefined && { name }),
        ...(headerText !== undefined && { headerText }),
        ...(subHeading !== undefined && { subHeading }),
        ...(showLogo !== undefined && { showLogo: Boolean(showLogo) }),
        ...(showTaxDetails !== undefined && { showTaxDetails: Boolean(showTaxDetails) }),
        ...(showCustomerDetails !== undefined && { showCustomerDetails: Boolean(showCustomerDetails) }),
        ...(showSku !== undefined && { showSku: Boolean(showSku) }),
        ...(showDescription !== undefined && { showDescription: Boolean(showDescription) }),
        ...(showDiscount !== undefined && { showDiscount: Boolean(showDiscount) }),
        ...(showTax !== undefined && { showTax: Boolean(showTax) }),
        ...(footerText !== undefined && { footerText }),
        ...(termsConditions !== undefined && { termsConditions }),
        ...(bankDetails !== undefined && { bankDetails }),
        ...(paperSize !== undefined && { paperSize }),
        ...(isDefault !== undefined && { isDefault: Boolean(isDefault) }),
        ...(branchId !== undefined && { branchId: branchId || null }),
      },
      include: { branch: { select: { id: true, name: true } } }
    });
  }

  async setDefaultLayout(id: string, businessId: string) {
    await this.getLayoutById(id, businessId);

    await this.prisma.invoiceLayout.updateMany({
      where: { businessId, isDefault: true },
      data: { isDefault: false }
    });

    return this.prisma.invoiceLayout.update({
      where: { id },
      data: { isDefault: true }
    });
  }

  async deleteLayout(id: string, businessId: string) {
    const layout = await this.getLayoutById(id, businessId);
    if (layout.isDefault) {
      throw new BadRequestException('Cannot delete default invoice layout');
    }
    return this.prisma.invoiceLayout.delete({ where: { id } });
  }
}
