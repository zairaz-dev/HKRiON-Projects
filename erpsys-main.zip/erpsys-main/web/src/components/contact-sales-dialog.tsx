"use strict";
"use client";

import React, { useState, useEffect } from "react";
import {
  X,
  Building2,
  Phone,
  User,
  MessageSquare,
  CheckCircle2,
  ArrowRight,
  Shield,
  Layers,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { superSettingsService } from "@/services/super-settings-service";

interface ContactSalesDialogProps {
  isOpen: boolean;
  onClose: () => void;
  defaultPlanName?: string;
}

export function ContactSalesDialog({
  isOpen,
  onClose,
  defaultPlanName = "Enterprise Plan",
}: ContactSalesDialogProps) {
  const [name, setName] = useState("");
  const [businessName, setBusinessName] = useState("");
  const [phone, setPhone] = useState("");
  const [branches, setBranches] = useState("10+ Branches");
  const [notes, setNotes] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [platformInfo, setPlatformInfo] = useState<any>(null);

  useEffect(() => {
    if (isOpen) {
      superSettingsService.getPublicPlatformInfo().then((info) => {
        if (info) setPlatformInfo(info);
      }).catch(() => {});
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const whatsappNumber = (platformInfo?.supportWhatsapp || platformInfo?.supportPhone || "+94771234567")
    .replace(/[^0-9]/g, "");

  const handleWhatsAppRedirect = () => {
    const text = encodeURIComponent(
      `Hello HKRION Team, I am interested in a Custom Quote for the ${defaultPlanName}.\n` +
      `Business: ${businessName || "My Retail Company"}\n` +
      `Name: ${name || "Business Owner"}\n` +
      `Estimated Branches: ${branches}\n` +
      (notes ? `Requirements: ${notes}` : "")
    );
    window.open(`https://wa.me/${whatsappNumber}?text=${text}`, "_blank");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-lg bg-card border border-border rounded-sm shadow-2xl overflow-hidden flex flex-col relative">
        {/* Header */}
        <div className="p-5 border-b border-border bg-background/50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-sm bg-primary/10 border border-primary/20 text-primary flex items-center justify-center">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-foreground font-heading">
                Contact Enterprise Sales
              </h3>
              <p className="text-[11px] text-muted-foreground font-mono">
                Custom pricing, unlimited branches & dedicated SLA
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground p-1 rounded-sm transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {isSubmitted ? (
            <div className="text-center py-6 space-y-4 animate-fadeIn">
              <div className="w-12 h-12 rounded-sm bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h4 className="text-base font-bold text-foreground">Inquiry Received!</h4>
                <p className="text-xs text-muted-foreground max-w-sm mx-auto leading-relaxed">
                  Thank you, <strong>{name}</strong>. Our enterprise solutions specialist will contact your team at <strong>{phone}</strong> within 2 business hours.
                </p>
              </div>

              <div className="pt-2">
                <Button
                  type="button"
                  onClick={handleWhatsAppRedirect}
                  className="bg-[#25D366] hover:bg-[#20bd5a] text-black font-bold text-xs h-9 px-5 flex items-center gap-2 mx-auto rounded-sm"
                >
                  <MessageSquare className="w-3.5 h-3.5" /> Connect Now via WhatsApp
                </Button>
              </div>

              <div className="pt-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClose}
                  className="text-xs h-8 rounded-sm"
                >
                  Close Window
                </Button>
              </div>
            </div>
          ) : (
            <>
              {/* Quick WhatsApp CTA Banner */}
              <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-sm p-3 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-sm bg-[#25D366]/20 text-[#25D366] flex items-center justify-center shrink-0">
                    <MessageSquare className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-foreground">Need an immediate quote?</div>
                    <div className="text-[10px] text-muted-foreground">Talk directly to our Solutions Architect on WhatsApp</div>
                  </div>
                </div>
                <Button
                  type="button"
                  onClick={handleWhatsAppRedirect}
                  className="bg-[#25D366] hover:bg-[#20bd5a] text-black font-bold text-xs h-8 px-3 shrink-0 flex items-center gap-1.5 rounded-sm"
                >
                  <MessageSquare className="w-3.5 h-3.5" /> WhatsApp
                </Button>
              </div>

              <div className="relative flex py-1 items-center">
                <div className="flex-grow border-t border-border"></div>
                <span className="flex-shrink mx-3 text-[10px] font-mono text-muted-foreground uppercase">
                  Or request a callback
                </span>
                <div className="flex-grow border-t border-border"></div>
              </div>

              {/* Inquiry Form */}
              <form onSubmit={handleSubmit} className="space-y-3.5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono flex items-center gap-1">
                      <User className="w-3 h-3 text-primary" /> Full Name *
                    </label>
                    <Input
                      required
                      placeholder="e.g. John Doe"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="h-8 text-xs font-mono"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono flex items-center gap-1">
                      <Building2 className="w-3 h-3 text-primary" /> Company / Business *
                    </label>
                    <Input
                      required
                      placeholder="e.g. Metro Supermarkets"
                      value={businessName}
                      onChange={(e) => setBusinessName(e.target.value)}
                      className="h-8 text-xs font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono flex items-center gap-1">
                      <Phone className="w-3 h-3 text-primary" /> Phone / WhatsApp *
                    </label>
                    <Input
                      required
                      type="tel"
                      placeholder="e.g. 077 123 4567"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="h-8 text-xs font-mono"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono flex items-center gap-1">
                      <Layers className="w-3 h-3 text-primary" /> Expected Outlets
                    </label>
                    <select
                      value={branches}
                      onChange={(e) => setBranches(e.target.value)}
                      className="w-full h-8 px-2.5 text-xs rounded-sm bg-secondary/50 border border-border text-foreground font-mono"
                    >
                      <option value="5 - 10 Branches">5 - 10 Outlets</option>
                      <option value="10 - 25 Branches">10 - 25 Outlets</option>
                      <option value="25 - 50 Branches">25 - 50 Outlets</option>
                      <option value="50+ Outlets / Franchise">50+ Outlets / Franchise</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono">
                    Special Requirements (Optional)
                  </label>
                  <Input
                    placeholder="e.g. Custom ERP integration, existing data migration..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="h-8 text-xs rounded-sm"
                  />
                </div>

                <div className="pt-2 flex items-center justify-end gap-2 border-t border-border">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={onClose}
                    className="text-xs h-8 rounded-sm"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="text-xs h-8 px-4 font-bold bg-primary hover:bg-primary/90 text-primary-foreground rounded-sm"
                  >
                    Submit Request
                  </Button>
                </div>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
