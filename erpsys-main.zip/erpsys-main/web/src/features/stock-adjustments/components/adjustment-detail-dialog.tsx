import React from "react";
import {
  X,
  Printer,
  SlidersHorizontal,
  Building2,
  Calendar,
  User as UserIcon,
  FileText,
  DollarSign,
  Tag
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCurrency } from "@/hooks/use-currency";

interface AdjustmentDetailDialogProps {
  isOpen: boolean;
  onClose: () => void;
  adjustment: any;
}

export function AdjustmentDetailDialog({
  isOpen,
  onClose,
  adjustment,
}: AdjustmentDetailDialogProps) {
  const { symbol } = useCurrency(adjustment?.businessId);

  if (!isOpen || !adjustment) return null;

  const handlePrint = () => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) return;

    const dateStr = new Date(adjustment.adjustmentDate).toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "long",
      year: "numeric",
    });

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Stock Adjustment Slip - ${adjustment.adjustmentNumber}</title>
          <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 30px; color: #111; }
            .header { display: flex; justify-content: space-between; align-items: flex-start; border-b: 2px solid #333; pb: 15px; margin-bottom: 20px; }
            .title { font-size: 24px; font-weight: bold; color: #111; margin: 0; }
            .sub-title { font-size: 12px; color: #666; margin-top: 4px; }
            .grid { display: flex; justify-content: space-between; margin-bottom: 20px; font-size: 13px; }
            .box { background: #f9fafb; padding: 12px; border-radius: 6px; border: 1px solid #e5e7eb; width: 48%; }
            table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 12px; }
            th { background: #f3f4f6; text-align: left; padding: 8px; border-bottom: 2px solid #d1d5db; font-weight: 600; }
            td { padding: 8px; border-bottom: 1px solid #e5e7eb; }
            .text-right { text-align: right; }
            .text-center { text-align: center; }
            .total-row { font-weight: bold; font-size: 14px; background: #f3f4f6; }
            .footer { margin-top: 40px; display: flex; justify-content: space-between; font-size: 12px; color: #555; }
            .signature { border-top: 1px dashed #999; width: 180px; text-align: center; padding-top: 5px; }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <h1 class="title">STOCK ADJUSTMENT VOUCHER</h1>
              <p class="sub-title">Inventory Adjustment Record</p>
            </div>
            <div style="text-align: right;">
              <p style="font-weight: bold; margin:0;">Ref #: ${adjustment.adjustmentNumber}</p>
              <p style="margin:4px 0 0 0; font-size:12px; color:#555;">Date: ${dateStr}</p>
              <p style="margin:2px 0 0 0; font-size:12px; color:#555;">Type: ${adjustment.type}</p>
            </div>
          </div>

          <div class="grid">
            <div class="box">
              <strong style="display:block; margin-bottom:4px; text-transform:uppercase; font-size:11px; color:#666;">Adjustment Info</strong>
              <p style="margin:0; font-weight:bold; font-size:13px;">Reason: ${adjustment.reason}</p>
              <p style="margin:2px 0 0 0; font-size:12px; color:#555;">Created By: ${adjustment.createdBy?.name || "System"}</p>
            </div>

            <div class="box">
              <strong style="display:block; margin-bottom:4px; text-transform:uppercase; font-size:11px; color:#666;">Branch Information</strong>
              <p style="margin:0; font-weight:bold; font-size:13px;">${adjustment.branch?.name || "N/A"}</p>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Item / Description</th>
                <th class="text-center">Adjusted Qty</th>
                <th class="text-right">Unit Cost</th>
                <th class="text-right">Total Subtotal</th>
              </tr>
            </thead>
            <tbody>
              ${adjustment.adjustmentLines?.map((line: any, idx: number) => `
                <tr>
                  <td>${idx + 1}</td>
                  <td>
                    <strong>${line.variant?.product?.name || line.variant?.name || "Item"}</strong>
                    <br/><span style="font-size:10px; color:#666;">SKU: ${line.variant?.sku || "N/A"}</span>
                  </td>
                  <td class="text-center">${line.quantity}</td>
                  <td class="text-right">${symbol}${line.unitPrice.toFixed(2)}</td>
                  <td class="text-right">${symbol}${line.subtotal.toFixed(2)}</td>
                </tr>
              `).join("")}
              <tr class="total-row">
                <td colspan="4" class="text-right" style="padding: 10px;">Total Adjustment Value:</td>
                <td class="text-right" style="padding: 10px;">${symbol}${adjustment.totalAmount.toFixed(2)}</td>
              </tr>
            </tbody>
          </table>

          ${adjustment.notes ? `
            <div style="margin-top: 20px; font-size: 12px; background: #f9fafb; padding: 10px; border-radius: 4px;">
              <strong>Audit Remarks / Notes:</strong> ${adjustment.notes}
            </div>
          ` : ""}

          <div class="footer">
            <div class="signature">Inventory Auditor</div>
            <div class="signature">Manager Approval</div>
          </div>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 250);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-card border border-border rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border bg-muted/30">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-500">
              <SlidersHorizontal className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-foreground">
                Stock Adjustment #{adjustment.adjustmentNumber}
              </h2>
              <span className="text-xs text-muted-foreground font-mono">
                Reason: {adjustment.reason}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrint}
              className="gap-1.5 text-xs h-8"
            >
              <Printer className="h-3.5 w-3.5" /> Print Audit Voucher
            </Button>

            <button
              onClick={onClose}
              className="text-muted-foreground hover:text-foreground p-1 rounded-md transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-5">
          
          {/* Status & Summary Header Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-muted/40 p-3 rounded-lg border border-border/50">
              <span className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                <Calendar className="h-3 w-3 text-primary" /> Adjustment Date
              </span>
              <p className="text-xs font-semibold mt-1 text-foreground">
                {new Date(adjustment.createdAt).toLocaleDateString("en-US", {
                  year: "numeric",
                  month: "short",
                  day: "numeric",
                })}
              </p>
            </div>

            <div className="bg-muted/40 p-3 rounded-lg border border-border/50">
              <span className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                <Tag className="h-3 w-3 text-primary" /> Adjustment Type
              </span>
              <p className="text-xs font-bold uppercase mt-1 text-foreground">
                {adjustment.type}
              </p>
            </div>

            <div className="bg-muted/40 p-3 rounded-lg border border-border/50">
              <span className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                <DollarSign className="h-3 w-3 text-primary" /> Total Adjusted Value
              </span>
              <p className="text-lg font-extrabold text-primary mt-0.5 font-mono">
                {symbol}{adjustment.totalAmount?.toFixed(2)}
              </p>
            </div>
          </div>

          {/* Branch & User Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-muted/20 p-3.5 rounded-lg border border-border/40 text-xs">
            <div className="space-y-1">
              <span className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                <Building2 className="h-3 w-3 text-primary" /> Branch
              </span>
              <p className="font-bold text-foreground text-sm">{adjustment.branch?.name}</p>
            </div>

            <div className="space-y-1">
              <span className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                <UserIcon className="h-3 w-3 text-primary" /> Created By
              </span>
              <p className="font-bold text-foreground text-sm">{adjustment.createdBy?.name || "System"}</p>
            </div>
          </div>

          {/* Table of Line items */}
          <div className="space-y-2">
            <span className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider block">
              Adjusted Product Breakdown
            </span>
            <div className="border border-border/60 rounded-lg overflow-hidden">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="bg-muted/40 border-b border-border/60">
                    <th className="p-3 font-semibold text-muted-foreground">Product</th>
                    <th className="p-3 font-semibold text-muted-foreground text-center">Adjusted Qty</th>
                    <th className="p-3 font-semibold text-muted-foreground text-right">Unit Cost ({symbol})</th>
                    <th className="p-3 font-semibold text-muted-foreground text-right pr-4">Subtotal ({symbol})</th>
                  </tr>
                </thead>
                <tbody>
                  {adjustment.adjustmentLines?.map((line: any) => (
                    <tr key={line.id} className="border-b border-border/40 hover:bg-muted/15 transition-colors">
                      <td className="p-3">
                        <span className="font-semibold text-foreground block">
                          {line.variant?.product?.name || line.variant?.name || "Product Item"}
                        </span>
                        <span className="text-[10px] font-mono text-muted-foreground block">
                          SKU: {line.variant?.sku}
                        </span>
                      </td>
                      <td className="p-3 text-center font-bold">
                        {line.quantity}
                      </td>
                      <td className="p-3 text-right font-mono">
                        {symbol}{line.unitPrice.toFixed(2)}
                      </td>
                      <td className="p-3 text-right font-semibold font-mono pr-4 text-foreground">
                        {symbol}{line.subtotal.toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Notes */}
          {adjustment.notes && (
            <div className="space-y-1 bg-muted/30 p-3 rounded-lg border border-border/40">
              <span className="text-[10px] font-bold text-muted-foreground uppercase">
                Audit Remarks / Notes
              </span>
              <p className="text-xs text-foreground italic">{adjustment.notes}</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-border pt-3 shrink-0 flex justify-end">
          <Button variant="outline" size="sm" onClick={onClose} className="h-8 text-xs">
            Close
          </Button>
        </div>
      </div>
    </div>
  );
}
