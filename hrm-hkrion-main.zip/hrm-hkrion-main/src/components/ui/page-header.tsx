import React from "react";
import { cn } from "@/lib/utils";

interface PageHeaderProps {
  title: string;
  description?: React.ReactNode;
  badge?: React.ReactNode;
  actions?: React.ReactNode;
  className?: string;
}

export function PageHeader({ title, description, badge, actions, className }: PageHeaderProps) {
  return (
    <div className={cn("flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-border pb-5", className)}>
      <div className="space-y-1">
        <div className="flex items-center gap-3 pt-1">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-text-primary">
            {title}
          </h1>
          {badge && <div>{badge}</div>}
        </div>
        {description && (
          <div className="text-sm text-text-secondary">
            {description}
          </div>
        )}
      </div>
      
      {actions && (
        <div className="flex items-center gap-2.5 self-start md:self-auto shrink-0">
          {actions}
        </div>
      )}
    </div>
  );
}
