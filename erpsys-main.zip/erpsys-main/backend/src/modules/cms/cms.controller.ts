import {
  Controller,
  Get,
  Put,
  Post,
  Delete,
  Body,
  Param,
  UseGuards,
} from '@nestjs/common';
import { CmsService } from './cms.service';
import { UpdateCmsHeroDto } from './dto/update-hero.dto';
import { CreateCmsFeatureDto, UpdateCmsFeatureDto } from './dto/create-feature.dto';
import { CreateCmsFaqDto, UpdateCmsFaqDto } from './dto/create-faq.dto';
import { CreateCmsTestimonialDto, UpdateCmsTestimonialDto } from './dto/create-testimonial.dto';
import { CreateCmsPageDto, UpdateCmsPageDto } from './dto/create-page.dto';
import { CreateCmsPostDto, UpdateCmsPostDto } from './dto/create-post.dto';
import { CreateCmsSpotlightDto, UpdateCmsSpotlightDto } from './dto/create-spotlight.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';
import { Public } from '../../common/decorators/public.decorator';

@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('cms')
export class CmsController {
  constructor(private readonly cmsService: CmsService) {}

  // --- Public Read Endpoints ---

  @Public()
  @Get('public-content')
  async getPublicContent() {
    return this.cmsService.getPublicLandingContent();
  }

  @Public()
  @Get('pages/public/:slug')
  async getPublicPage(@Param('slug') slug: string) {
    return this.cmsService.getPageBySlug(slug);
  }

  @Public()
  @Get('posts/public')
  async getPublicPosts() {
    return this.cmsService.getPosts(false);
  }

  @Public()
  @Get('posts/public/:slug')
  async getPublicPost(@Param('slug') slug: string) {
    return this.cmsService.getPostBySlug(slug);
  }

  // --- Super Admin CMS Endpoints ---

  // Hero Section
  @Roles(Role.SUPER_ADMIN)
  @Get('hero')
  async getHero() {
    return this.cmsService.getHero();
  }

  @Roles(Role.SUPER_ADMIN)
  @Put('hero')
  async updateHero(@Body() dto: UpdateCmsHeroDto) {
    return this.cmsService.updateHero(dto);
  }

  // Features
  @Roles(Role.SUPER_ADMIN)
  @Get('features/all')
  async getAllFeatures() {
    return this.cmsService.getFeatures(true);
  }

  @Roles(Role.SUPER_ADMIN)
  @Post('features')
  async createFeature(@Body() dto: CreateCmsFeatureDto) {
    return this.cmsService.createFeature(dto);
  }

  @Roles(Role.SUPER_ADMIN)
  @Put('features/:id')
  async updateFeature(@Param('id') id: string, @Body() dto: UpdateCmsFeatureDto) {
    return this.cmsService.updateFeature(id, dto);
  }

  @Roles(Role.SUPER_ADMIN)
  @Delete('features/:id')
  async deleteFeature(@Param('id') id: string) {
    return this.cmsService.deleteFeature(id);
  }

  // FAQs
  @Roles(Role.SUPER_ADMIN)
  @Get('faqs/all')
  async getAllFaqs() {
    return this.cmsService.getFaqs(true);
  }

  @Roles(Role.SUPER_ADMIN)
  @Post('faqs')
  async createFaq(@Body() dto: CreateCmsFaqDto) {
    return this.cmsService.createFaq(dto);
  }

  @Roles(Role.SUPER_ADMIN)
  @Put('faqs/:id')
  async updateFaq(@Param('id') id: string, @Body() dto: UpdateCmsFaqDto) {
    return this.cmsService.updateFaq(id, dto);
  }

  @Roles(Role.SUPER_ADMIN)
  @Delete('faqs/:id')
  async deleteFaq(@Param('id') id: string) {
    return this.cmsService.deleteFaq(id);
  }

  // Testimonials
  @Roles(Role.SUPER_ADMIN)
  @Get('testimonials/all')
  async getAllTestimonials() {
    return this.cmsService.getTestimonials(true);
  }

  @Roles(Role.SUPER_ADMIN)
  @Post('testimonials')
  async createTestimonial(@Body() dto: CreateCmsTestimonialDto) {
    return this.cmsService.createTestimonial(dto);
  }

  @Roles(Role.SUPER_ADMIN)
  @Put('testimonials/:id')
  async updateTestimonial(
    @Param('id') id: string,
    @Body() dto: UpdateCmsTestimonialDto,
  ) {
    return this.cmsService.updateTestimonial(id, dto);
  }

  @Roles(Role.SUPER_ADMIN)
  @Delete('testimonials/:id')
  async deleteTestimonial(@Param('id') id: string) {
    return this.cmsService.deleteTestimonial(id);
  }

  // Legal / Dynamic Pages
  @Roles(Role.SUPER_ADMIN)
  @Get('pages/all')
  async getAllPages() {
    return this.cmsService.getPages();
  }

  @Roles(Role.SUPER_ADMIN)
  @Post('pages')
  async createPage(@Body() dto: CreateCmsPageDto) {
    return this.cmsService.createPage(dto);
  }

  @Roles(Role.SUPER_ADMIN)
  @Put('pages/:id')
  async updatePage(@Param('id') id: string, @Body() dto: UpdateCmsPageDto) {
    return this.cmsService.updatePage(id, dto);
  }

  @Roles(Role.SUPER_ADMIN)
  @Delete('pages/:id')
  async deletePage(@Param('id') id: string) {
    return this.cmsService.deletePage(id);
  }

  // Blog & Changelog Posts
  @Roles(Role.SUPER_ADMIN)
  @Get('posts/all')
  async getAllPosts() {
    return this.cmsService.getPosts(true);
  }

  @Roles(Role.SUPER_ADMIN)
  @Post('posts')
  async createPost(@Body() dto: CreateCmsPostDto) {
    return this.cmsService.createPost(dto);
  }

  @Roles(Role.SUPER_ADMIN)
  @Put('posts/:id')
  async updatePost(@Param('id') id: string, @Body() dto: UpdateCmsPostDto) {
    return this.cmsService.updatePost(id, dto);
  }

  @Roles(Role.SUPER_ADMIN)
  @Delete('posts/:id')
  async deletePost(@Param('id') id: string) {
    return this.cmsService.deletePost(id);
  }

  // Interactive Product Spotlights
  @Roles(Role.SUPER_ADMIN)
  @Get('spotlights/all')
  async getAllSpotlights() {
    return this.cmsService.getSpotlights(true);
  }

  @Roles(Role.SUPER_ADMIN)
  @Post('spotlights')
  async createSpotlight(@Body() dto: CreateCmsSpotlightDto) {
    return this.cmsService.createSpotlight(dto);
  }

  @Roles(Role.SUPER_ADMIN)
  @Put('spotlights/:id')
  async updateSpotlight(
    @Param('id') id: string,
    @Body() dto: UpdateCmsSpotlightDto,
  ) {
    return this.cmsService.updateSpotlight(id, dto);
  }

  @Roles(Role.SUPER_ADMIN)
  @Delete('spotlights/:id')
  async deleteSpotlight(@Param('id') id: string) {
    return this.cmsService.deleteSpotlight(id);
  }
}
