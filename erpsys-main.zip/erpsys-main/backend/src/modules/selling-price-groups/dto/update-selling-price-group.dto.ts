import {
  IsString,
  IsOptional,
  Length,
} from 'class-validator';

export class UpdateSellingPriceGroupDto {
  @IsOptional()
  @IsString()
  @Length(2, 100, { message: 'Group name must be between 2 and 100 characters' })
  name?: string;

  @IsOptional()
  @IsString()
  @Length(0, 500, { message: 'Description cannot exceed 500 characters' })
  description?: string;

  @IsOptional()
  isActive?: boolean | string;

  @IsOptional()
  @IsString()
  businessId?: string;

  @IsOptional()
  branchIds?: string[] | string;

  @IsOptional()
  @IsString()
  updatedById?: string;
}
