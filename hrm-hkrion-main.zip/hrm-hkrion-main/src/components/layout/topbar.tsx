"use client";

import { logout } from "@/actions/logout";
import { useTheme } from "@/components/theme-provider";
import { 
  Moon, 
  Sun, 
  LogOut, 
  User as UserIcon, 
  Bell, 
  Check, 
  Settings, 
  Shield, 
  ChevronDown,
  Plus,
  Menu,
  LayoutDashboard,
  ClipboardCheck,
  Users,
  Briefcase,
  CalendarClock,
  CalendarOff,
  BarChart3,
  UserPlus,
} from "lucide-react";
import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { markNotificationRead, markAllNotificationsRead } from "@/actions/notifications";
import { formatDistanceToNow } from "date-fns";
import { 
  DropdownMenu, 
  DropdownMenuTrigger, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator 
} from "@/components/ui/dropdown-menu";
import { Tooltip } from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CommandPalette } from "./command-palette";
import { cn } from "@/lib/utils";

interface TopbarProps {
  userName: string;
  initials: string;
  role: string;
  profileImage?: string | null;
  initialNotifications?: any[];
  userEmail?: string | null;
}

const roleLabels: Record<string, string> = {
  SUPER_ADMIN: "Super Admin",
  MANAGER: "Manager",
  EMPLOYEE: "Employee",
};

const routeTitles: Record<string, { title: string; icon: any }> = {
  "/dashboard": { title: "Dashboard Overview", icon: LayoutDashboard },
  "/dashboard/tasks/create": { title: "Create New Task", icon: Plus },
  "/dashboard/tasks": { title: "Task Workspace", icon: ClipboardCheck },
  "/dashboard/employees/create": { title: "Add New Employee", icon: UserPlus },
  "/dashboard/employees": { title: "Employees Directory", icon: Users },
  "/dashboard/positions": { title: "Positions & Hierarchy", icon: Briefcase },
  "/dashboard/attendance": { title: "Attendance Tracking", icon: CalendarClock },
  "/dashboard/leaves": { title: "Leaves & Time Off", icon: CalendarOff },
  "/dashboard/manager": { title: "Manager Analytics", icon: BarChart3 },
  "/dashboard/settings": { title: "Account & Settings", icon: Settings },
};

export default function Topbar({ 
  userName, 
  initials, 
  role, 
  profileImage, 
  initialNotifications = [], 
  userEmail 
}: TopbarProps) {
  const pathname = usePathname();
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  const [isCommandOpen, setIsCommandOpen] = useState(false);
  const displayRole = roleLabels[role] || role;

  const unreadCount = initialNotifications.filter((n) => !n.isRead).length;

  useEffect(() => {
    setMounted(true);
  }, []);

  const isDark =
    theme === "dark" ||
    (theme === "system" &&
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-color-scheme: dark)").matches);

  const toggleMobileSidebar = () => {
    window.dispatchEvent(new Event("toggle-mobile-sidebar"));
  };

  // Resolve current route info
  const matchedRoute = Object.entries(routeTitles).find(([route]) => {
    if (route === "/dashboard") return pathname === "/dashboard";
    return pathname.startsWith(route);
  });

  const currentRouteInfo = matchedRoute 
    ? matchedRoute[1] 
    : { title: "Workspace", icon: LayoutDashboard };

  const RouteIcon = currentRouteInfo.icon;

  return (
    <>
      <header className="flex h-16 shrink-0 items-center justify-between border-b border-border bg-surface/90 backdrop-blur-md px-4 sm:px-6 sticky top-0 z-40">
        
        {/* 1. LEFT: Mobile Toggle & Breadcrumb */}
        <div className="flex items-center gap-3 sm:gap-4 min-w-0">
          {/* Mobile Sidebar Hamburger Toggle */}
          <button
            type="button"
            onClick={toggleMobileSidebar}
            className="md:hidden p-2.5 rounded-xl text-text-secondary hover:text-text-primary hover:bg-surface-secondary transition-colors cursor-pointer"
            aria-label="Toggle mobile menu"
          >
            <Menu className="h-5.5 w-5.5" />
          </button>

          {/* Current Page Indicator / Breadcrumb */}
          <div className="flex items-center gap-2.5 text-sm font-bold text-text-primary min-w-0">
            <div className="p-2 rounded-xl bg-primary-soft text-primary">
              <RouteIcon className="h-4.5 w-4.5" />
            </div>
            <span className="truncate text-sm sm:text-base font-bold">{currentRouteInfo.title}</span>
          </div>
        </div>

        {/* 2. RIGHT: Online Pill, Notifications, Theme, User Dropdown */}
        <div className="flex items-center gap-2.5 sm:gap-3.5">
          
          {/* Live Online Badge (Desktop) */}
          <div className="hidden xl:flex items-center gap-2 px-3 py-1.5 rounded-full bg-success-bg border border-success-border/50 text-xs font-semibold text-success">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-success"></span>
            </span>
            <span>Online</span>
          </div>

          {/* Notifications Dropdown Popover */}
          <DropdownMenu>
            <Tooltip content="Notifications" side="bottom">
              <DropdownMenuTrigger className="relative p-2.5 rounded-xl text-text-secondary hover:bg-surface-secondary hover:text-text-primary transition-colors cursor-pointer">
                <Bell className="h-5 w-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-1.5 right-1.5 flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                  </span>
                )}
              </DropdownMenuTrigger>
            </Tooltip>
            
            <DropdownMenuContent align="end" width={340} className="p-0 overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3.5 border-b border-border bg-surface-secondary/40">
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-sm text-text-primary">Notifications</h3>
                  {unreadCount > 0 && (
                    <Badge variant="default" className="text-xs px-2 py-0.5">
                      {unreadCount} new
                    </Badge>
                  )}
                </div>
                {unreadCount > 0 && (
                  <button
                    type="button"
                    onClick={() => markAllNotificationsRead()}
                    className="text-xs font-semibold text-primary hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Check className="h-3.5 w-3.5" /> Mark all read
                  </button>
                )}
              </div>

              <div className="max-h-80 overflow-y-auto custom-scrollbar divide-y divide-border">
                {initialNotifications.length === 0 ? (
                  <div className="px-4 py-8 text-center text-xs text-text-muted space-y-1">
                    <div className="w-9 h-9 rounded-full bg-surface-secondary mx-auto flex items-center justify-center text-text-muted mb-2">
                      <Bell className="h-5 w-5" />
                    </div>
                    <p className="font-semibold text-text-secondary text-sm">No notifications yet</p>
                    <p className="text-xs">You will be notified when tasks or leaves update.</p>
                  </div>
                ) : (
                  initialNotifications.map((n) => (
                    <div
                      key={n.id}
                      className={cn(
                        "p-3.5 hover:bg-surface-secondary/60 transition-colors flex flex-col gap-1 cursor-pointer",
                        !n.isRead && "bg-primary-soft/15"
                      )}
                      onClick={async () => {
                        if (!n.isRead) await markNotificationRead(n.id);
                        if (n.link) window.location.href = n.link;
                      }}
                    >
                      <div className="flex justify-between items-start gap-2">
                        <p className={cn("text-xs leading-snug", !n.isRead ? "font-semibold text-text-primary" : "text-text-secondary")}>
                          {n.title}
                        </p>
                        {!n.isRead && <span className="h-2 w-2 rounded-full bg-primary mt-1 shrink-0" />}
                      </div>
                      <p className="text-xs text-text-muted line-clamp-2 leading-relaxed">
                        {n.message}
                      </p>
                      <p suppressHydrationWarning className="text-[11px] text-text-disabled font-mono mt-0.5">
                        {formatDistanceToNow(new Date(n.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Quick Theme Toggle Icon */}
          {mounted && (
            <Tooltip content={isDark ? "Switch to Light Mode" : "Switch to Dark Mode"} side="bottom">
              <button
                type="button"
                onClick={() => setTheme(isDark ? "light" : "dark")}
                className="relative p-2.5 rounded-xl text-text-secondary hover:bg-surface-secondary hover:text-text-primary transition-all duration-200 active:scale-90 cursor-pointer overflow-hidden"
                title="Toggle theme"
              >
                <div className="relative h-5 w-5 flex items-center justify-center">
                  <Sun 
                    className={`h-5 w-5 text-warning transition-all duration-500 transform ${
                      isDark 
                        ? "rotate-0 scale-100 opacity-100" 
                        : "rotate-90 scale-0 opacity-0 absolute"
                    }`} 
                  />
                  <Moon 
                    className={`h-5 w-5 text-text-secondary transition-all duration-500 transform ${
                      isDark 
                        ? "-rotate-90 scale-0 opacity-0 absolute" 
                        : "rotate-0 scale-100 opacity-100"
                    }`} 
                  />
                </div>
              </button>
            </Tooltip>
          )}

          <div className="h-6 w-px bg-border hidden sm:block mx-0.5" />

          {/* Modern User Profile Dropdown Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center gap-2.5 p-1 rounded-xl hover:bg-surface-secondary transition-all cursor-pointer group">
              <div className="relative flex h-9 w-9 items-center justify-center rounded-full bg-primary-soft text-primary text-xs font-bold overflow-hidden border border-border shrink-0 shadow-2xs">
                {profileImage ? (
                  <Image
                    src={profileImage}
                    alt={`${userName}'s profile picture`}
                    fill
                    className="object-cover"
                  />
                ) : (
                  initials
                )}
              </div>
              <div className="hidden lg:block text-left pr-1">
                <p className="text-sm font-semibold leading-none text-text-primary group-hover:text-primary transition-colors truncate max-w-[130px]">
                  {userName}
                </p>
                <p className="mt-1 text-xs text-text-muted">{displayRole}</p>
              </div>
              <ChevronDown className="h-4 w-4 text-text-muted group-hover:text-text-primary transition-transform duration-150 shrink-0 hidden sm:block" />
            </DropdownMenuTrigger>

            <DropdownMenuContent align="end" width={240} className="p-1.5">
              {/* Header user card in menu */}
              <div className="px-3 py-2.5 mb-1 border-b border-border">
                <p className="text-sm font-bold text-text-primary truncate">{userName}</p>
                <p className="text-xs text-text-muted truncate mt-0.5">{userEmail || displayRole}</p>
              </div>

              <DropdownMenuLabel className="text-xs">Account & Workspace</DropdownMenuLabel>
              
              <Link href="/dashboard/settings?tab=profile" className="block w-full">
                <DropdownMenuItem icon={<UserIcon className="h-4 w-4" />}>
                  Profile Settings
                </DropdownMenuItem>
              </Link>

              <Link href="/dashboard/settings?tab=security" className="block w-full">
                <DropdownMenuItem icon={<Shield className="h-4 w-4" />}>
                  Security & Password
                </DropdownMenuItem>
              </Link>

              <DropdownMenuSeparator />

              {/* Theme switcher inside dropdown */}
              <DropdownMenuLabel className="text-xs">Appearance</DropdownMenuLabel>
              <DropdownMenuItem 
                icon={isDark ? <Sun className="h-4 w-4 text-warning" /> : <Moon className="h-4 w-4 text-text-secondary" />}
                onClick={() => setTheme(isDark ? "light" : "dark")}
              >
                {isDark ? "Light Mode" : "Dark Mode"}
              </DropdownMenuItem>

              <DropdownMenuSeparator />

              {/* Sign Out Action */}
              <form action={logout} className="w-full">
                <DropdownMenuItem 
                  type="submit"
                  variant="destructive"
                  icon={<LogOut className="h-4 w-4" />}
                >
                  Sign Out
                </DropdownMenuItem>
              </form>
            </DropdownMenuContent>
          </DropdownMenu>

        </div>
      </header>

      {/* Fast Command & Search Palette (Cmd+K / Ctrl+K) */}
      <CommandPalette 
        isOpen={isCommandOpen} 
        onClose={() => setIsCommandOpen(false)} 
      />
    </>
  );
}
