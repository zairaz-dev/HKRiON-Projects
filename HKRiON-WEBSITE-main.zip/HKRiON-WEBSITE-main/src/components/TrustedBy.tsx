'use client';

import { useState, useEffect, useRef } from 'react';
import { ShieldCheck, CheckCircle, Cloud, Cpu, Database, Lock, Server, Shield, Zap, Award } from 'lucide-react';

interface StatItem {
  target?: number;
  suffix?: string;
  decimals?: number;
  staticVal?: string;
  label: string;
  sub: string;
}

const stats: StatItem[] = [
  { target: 50, suffix: '+', decimals: 0, label: 'Active Enterprise Clients', sub: 'Across Sri Lanka & Global' },
  { target: 100, suffix: '+', decimals: 0, label: 'Projects Successfully Delivered', sub: 'ERP, Web & IoT Systems' },
  { target: 99.9, suffix: '%', decimals: 1, label: 'Uptime & System Reliability', sub: 'Bank-Grade Security' },
  { staticVal: '24/7', label: 'Dedicated Technical Support', sub: 'Rapid Incident Response' },
];

const clients = [
  'Lanka Retail Hub',
  'Ceylon Logistics Ltd',
  'Apex Health Care',
  'Horizon Supermarkets',
  'Meridian Apparel',
  'Lanka Agri Tech',
];

const enterpriseBadges = [
  {
    icon: Cloud,
    title: 'AWS Cloud Powered',
    subtitle: 'High-Speed Scalable Cloud Infrastructure',
    badge: 'Infrastructure',
  },
  {
    icon: Cpu,
    title: 'Next.js 16 Turbo Stack',
    subtitle: 'Serverless SSR & Lightning Fast UX',
    badge: 'Engine',
  },
  {
    icon: Database,
    title: 'MySQL Enterprise Ready',
    subtitle: 'ACID-Compliant Relational Data Vault',
    badge: 'Database',
  },
  {
    icon: Lock,
    title: 'Bank-Grade Encryption',
    subtitle: 'End-to-End TLS/SSL & Data Hardening',
    badge: 'Security',
  },
  {
    icon: Shield,
    title: 'RBAC Security Standard',
    subtitle: 'Role-Based Granular Access Control',
    badge: 'Access Control',
  },
  {
    icon: Server,
    title: '99.9% Uptime SLA',
    subtitle: 'Redundant Architecture & Auto-Failover',
    badge: 'Reliability',
  },
  {
    icon: Zap,
    title: 'Global CDN Accelerated',
    subtitle: 'Low Latency Edge Delivery System',
    badge: 'Performance',
  },
  {
    icon: Award,
    title: 'ISO-Grade Code Quality',
    subtitle: 'Strict TypeScript Type-Checking & Clean Code',
    badge: 'Standards',
  },
];

function AnimatedNumber({ target, suffix = '', decimals = 0, staticVal }: { target?: number; suffix?: string; decimals?: number; staticVal?: string }) {
  const [count, setCount] = useState(0);
  const [hasAnimated, setHasAnimated] = useState(false);
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    if (staticVal) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasAnimated) {
          setHasAnimated(true);
          const duration = 2000; // 2 seconds
          const startTime = performance.now();

          const animate = (currentTime: number) => {
            const elapsedTime = currentTime - startTime;
            const progress = Math.min(elapsedTime / duration, 1);
            // Cubic ease out formula
            const easedProgress = 1 - Math.pow(1 - progress, 3);
            const currentVal = (target || 0) * easedProgress;

            setCount(currentVal);

            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              setCount(target || 0);
            }
          };

          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.3 }
    );

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) observer.unobserve(currentRef);
    };
  }, [target, hasAnimated, staticVal]);

  if (staticVal) {
    return <span ref={ref}>{staticVal}</span>;
  }

  return (
    <span ref={ref}>
      {count.toFixed(decimals)}{suffix}
    </span>
  );
}

export default function TrustedBy() {
  return (
    <section className="py-16 bg-linear-to-b from-black via-neutral-950/90 to-black border-b border-[#1ABE56]/30 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center mb-8">
          <p className="text-xs font-mono font-semibold uppercase tracking-widest text-[#1ABE56] mb-2 flex items-center justify-center gap-2 animate-pulse">
            <ShieldCheck className="w-4 h-4 text-[#1ABE56]" />
            TRUSTED BY LEADING BUSINESSES ACROSS SRI LANKA & GLOBALLY
          </p>
        </div>

        {/* Infinite Marquee Ticker */}
        <div className="overflow-hidden whitespace-nowrap mb-16 relative py-4">
          <div className="absolute left-0 top-0 bottom-0 w-24 bg-linear-to-r from-black via-black/80 to-transparent z-10 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-24 bg-linear-to-l from-black via-black/80 to-transparent z-10 pointer-events-none" />

          <div className="animate-marquee flex items-center justify-around gap-12">
            {[...clients, ...clients, ...clients].map((client, idx) => (
              <div key={idx} className="flex items-center gap-2.5 text-neutral-300 font-mono text-sm sm:text-base font-bold tracking-wider hover:text-[#1ABE56] transition-colors cursor-default shrink-0 glass-card px-5 py-2.5 rounded-xl border border-[#1ABE56]/30 hover:scale-105">
                <CheckCircle className="w-4 h-4 text-[#1ABE56] animate-pulse" />
                <span>{client}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Live Metrics Grid with Scroll Count-Up Animation */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="glass-card p-6 sm:p-8 rounded-2xl border border-[#1ABE56]/30 bg-black/80 hover:border-[#1ABE56] hover:scale-105 transition-all group text-center hover:shadow-xl hover:shadow-[#1ABE56]/20 relative overflow-hidden"
            >
              <div className="absolute -inset-1 bg-linear-to-r from-[#1ABE56]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity blur-lg" />
              <p className="text-3xl sm:text-5xl font-extrabold text-white gradient-text font-mono mb-2 group-hover:scale-110 transition-transform">
                <AnimatedNumber
                  target={stat.target}
                  suffix={stat.suffix}
                  decimals={stat.decimals}
                  staticVal={stat.staticVal}
                />
              </p>
              <p className="text-sm font-bold text-white mb-1">{stat.label}</p>
              <p className="text-xs text-neutral-400 font-mono">{stat.sub}</p>
            </div>
          ))}
        </div>

        {/* Enterprise Infrastructure & Security Standards Badges - Infinite Marquee Ticker */}
        <div className="pt-8 border-t border-neutral-900">
          <div className="text-center mb-8 space-y-2">
            <span className="text-xs font-mono font-bold uppercase tracking-widest text-[#1ABE56] bg-[#1ABE56]/10 px-3.5 py-1.5 rounded-full border border-[#1ABE56]/30 inline-block animate-pulse">
              ENTERPRISE STANDARDS & INFRASTRUCTURE
            </span>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white">
              Built On Modern <span className="gradient-text">Cloud & Security Frameworks</span>
            </h3>
            <p className="text-xs sm:text-sm text-neutral-400 max-w-xl mx-auto">
              Our products are engineered with production-ready cloud stacks, bank-grade encryption, and strict software standards.
            </p>
          </div>

          {/* Running Marquee Ticker Row 1 */}
          <div className="overflow-hidden whitespace-nowrap relative py-4 mb-4">
            <div className="absolute left-0 top-0 bottom-0 w-24 bg-linear-to-r from-black via-black/90 to-transparent z-10 pointer-events-none" />
            <div className="absolute right-0 top-0 bottom-0 w-24 bg-linear-to-l from-black via-black/90 to-transparent z-10 pointer-events-none" />

            <div className="animate-marquee-slow flex items-center gap-6">
              {[...enterpriseBadges, ...enterpriseBadges, ...enterpriseBadges].map((badge, idx) => {
                const IconComp = badge.icon;
                return (
                  <div
                    key={idx}
                    className="glass-card p-4 px-6 rounded-2xl border border-[#1ABE56]/30 bg-neutral-950/90 hover:border-[#1ABE56] hover:bg-black transition-all group shrink-0 inline-flex items-center gap-4 hover:scale-105 cursor-pointer shadow-lg"
                  >
                    <div className="w-10 h-10 rounded-xl bg-[#1ABE56]/15 border border-[#1ABE56]/30 flex items-center justify-center shrink-0 group-hover:bg-[#1ABE56] group-hover:text-black transition-all">
                      <IconComp className="w-5 h-5 text-[#1ABE56] group-hover:text-black transition-colors" />
                    </div>
                    <div className="text-left whitespace-normal max-w-xs">
                      <div className="flex items-center gap-2 mb-0.5">
                        <h4 className="text-sm font-bold text-white group-hover:text-[#1ABE56] transition-colors">
                          {badge.title}
                        </h4>
                        <span className="text-[9px] font-mono text-[#1ABE56] bg-[#1ABE56]/10 px-2 py-0.5 rounded-md border border-[#1ABE56]/20 font-semibold shrink-0">
                          {badge.badge}
                        </span>
                      </div>
                      <p className="text-xs text-neutral-400 font-mono leading-tight">
                        {badge.subtitle}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Running Marquee Ticker Row 2 (Reverse Direction) */}
          <div className="overflow-hidden whitespace-nowrap relative py-2">
            <div className="absolute left-0 top-0 bottom-0 w-24 bg-linear-to-r from-black via-black/90 to-transparent z-10 pointer-events-none" />
            <div className="absolute right-0 top-0 bottom-0 w-24 bg-linear-to-l from-black via-black/90 to-transparent z-10 pointer-events-none" />

            <div className="animate-marquee-reverse flex items-center gap-6">
              {[...enterpriseBadges.slice().reverse(), ...enterpriseBadges.slice().reverse(), ...enterpriseBadges.slice().reverse()].map((badge, idx) => {
                const IconComp = badge.icon;
                return (
                  <div
                    key={idx}
                    className="glass-card p-4 px-6 rounded-2xl border border-[#1ABE56]/30 bg-neutral-950/90 hover:border-[#1ABE56] hover:bg-black transition-all group shrink-0 inline-flex items-center gap-4 hover:scale-105 cursor-pointer shadow-lg"
                  >
                    <div className="w-10 h-10 rounded-xl bg-[#1ABE56]/15 border border-[#1ABE56]/30 flex items-center justify-center shrink-0 group-hover:bg-[#1ABE56] group-hover:text-black transition-all">
                      <IconComp className="w-5 h-5 text-[#1ABE56] group-hover:text-black transition-colors" />
                    </div>
                    <div className="text-left whitespace-normal max-w-xs">
                      <div className="flex items-center gap-2 mb-0.5">
                        <h4 className="text-sm font-bold text-white group-hover:text-[#1ABE56] transition-colors">
                          {badge.title}
                        </h4>
                        <span className="text-[9px] font-mono text-[#1ABE56] bg-[#1ABE56]/10 px-2 py-0.5 rounded-md border border-[#1ABE56]/20 font-semibold shrink-0">
                          {badge.badge}
                        </span>
                      </div>
                      <p className="text-xs text-neutral-400 font-mono leading-tight">
                        {badge.subtitle}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}

