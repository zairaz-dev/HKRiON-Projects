import { Controller, Post, Body, Get, Delete, Param, Query, UseGuards, Req } from '@nestjs/common';
import { CustomerPaymentsService } from './customer-payments.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('customer-payments')
export class CustomerPaymentsController {
  constructor(private readonly customerPaymentsService: CustomerPaymentsService) {}

  @Permissions(Permission.SALE_CREATE)
  @Post()
  async createPayment(@Req() req: any, @Body() body: any) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }

    const {
      amount,
      paymentDate,
      saleId,
      customerId,
      paymentMethodId,
      branchId,
      businessId,
      transactionNo,
      notes,
      createdById,
    } = body;

    return this.customerPaymentsService.createPayment({
      amount: Number(amount),
      paymentDate: paymentDate ? new Date(paymentDate) : undefined,
      saleId,
      customerId,
      paymentMethodId,
      branchId,
      businessId,
      transactionNo,
      notes,
      createdById: createdById || user.id,
    });
  }

  @Permissions(Permission.SALE_VIEW)
  @Get()
  async getPayments(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
    @Query('customerId') customerId?: string,
    @Query('saleId') saleId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.customerPaymentsService.getPayments(bId, {
      branchId,
      customerId,
      saleId,
    });
  }

  @Permissions(Permission.SALE_CREATE)
  @Delete(':id')
  async deletePayment(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.customerPaymentsService.deletePayment(id, bId);
  }

  @Permissions(Permission.SALE_CREATE)
  @Post('refund-advance')
  async refundAdvance(@Req() req: any, @Body() body: any) {
    const user = req.user;
    const businessId = user.role === 'super-admin' ? body.businessId : user.businessId;

    return this.customerPaymentsService.refundAdvance({
      customerId: body.customerId,
      amount: Number(body.amount),
      paymentMethodId: body.paymentMethodId,
      branchId: body.branchId,
      businessId,
      notes: body.notes,
      createdById: user.id,
    });
  }
}

