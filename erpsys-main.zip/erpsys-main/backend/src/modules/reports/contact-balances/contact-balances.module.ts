import { Module } from '@nestjs/common';
import { ContactBalancesController } from './contact-balances.controller';
import { ContactBalancesService } from './contact-balances.service';
import { PrismaModule } from '../../prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [ContactBalancesController],
  providers: [ContactBalancesService],
  exports: [ContactBalancesService],
})
export class ContactBalancesModule {}
