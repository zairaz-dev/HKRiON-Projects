"use strict";
"use client";

import React, { useEffect, useState } from "react";
import {
  TrendingUp,
  TrendingDown,
  Building2,
  Calendar,
  Utensils,
  Users,
  PieChart,
  Tag,
  XCircle,
  Banknote,
  CheckCircle2,
  ChevronDown,
  Loader2,
  Package,
  AlertTriangle,
  Truck,
  ArrowDownLeft,
  ArrowUpRight
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { authService } from "@/services/auth-service";
import { LoadingSession } from "@/components/ui/loading-session";
import { User } from "@hkr/types";
import { useCurrency } from "@/hooks/use-currency";
import { useDashboardSummaryQuery } from "@/features/dashboard/hooks/use-dashboard";
import { useBranchesQuery } from "@/features/suppliers/hooks/use-suppliers";
import { useCategoriesQuery } from "@/features/categories/hooks/use-categories";
import { Select } from "@/components/ui/select";

// ==========================================
// ANIMATED NUMBER COUNT-UP COMPONENT
// ==========================================
function AnimatedNumber({
  value,
  prefix = "",
  suffix = "",
  decimals = 0,
  duration = 1400
}: {
  value: number;
  prefix?: string;
  suffix?: string;
  decimals?: number;
  duration?: number;
}) {
  const [currentVal, setCurrentVal] = useState(0);

  useEffect(() => {
    let startTimestamp: number | null = null;
    let animFrame: number;

    const step = (timestamp: number) => {
      if (!startTimestamp) startTimestamp = timestamp;
      const progress = Math.min((timestamp - startTimestamp) / duration, 1);
      // Smooth ease-out cubic
      const ease = 1 - Math.pow(1 - progress, 3);
      setCurrentVal(ease * value);

      if (progress < 1) {
        animFrame = requestAnimationFrame(step);
      } else {
        setCurrentVal(value);
      }
    };

    animFrame = requestAnimationFrame(step);
    return () => cancelAnimationFrame(animFrame);
  }, [value, duration]);

  const formatted =
    decimals > 0
      ? currentVal.toLocaleString("en-US", {
          minimumFractionDigits: decimals,
          maximumFractionDigits: decimals
        })
      : Math.round(currentVal).toLocaleString("en-US");

  return (
    <span>
      {prefix}
      {formatted}
      {suffix}
    </span>
  );
}

// ==========================================
// MOCK DUMMY DATA (ALIGNED WITH HKRION ERP THEME)
// ==========================================
const MOCK_DATA = {
  header: {
    selectedDate: "23 May 2025"
  },
  topKpis: [
    {
      id: "total_sales",
      label: "TOTAL SALES",
      numericValue: 24560,
      prefix: "$",
      suffix: "",
      decimals: 0,
      subLabel: "vs Yesterday",
      change: "+12.45%",
      isPositive: true,
      color: "#22c55e",
      sparkline: [20, 35, 25, 45, 30, 55, 48, 65, 58, 80, 72, 95]
    },
    {
      id: "net_profit",
      label: "NET PROFIT",
      numericValue: 7820,
      prefix: "$",
      suffix: "",
      decimals: 0,
      subLabel: "Margin",
      change: "31.88%",
      isPositive: true,
      color: "#10b981",
      sparkline: [18, 22, 35, 30, 40, 32, 55, 48, 62, 58, 75, 85]
    },
    {
      id: "invoice_due",
      label: "INVOICE DUE",
      numericValue: 3450,
      prefix: "$",
      suffix: "",
      decimals: 0,
      subLabel: "Unpaid Invoices",
      change: "12 Invoices",
      isPositive: false,
      color: "#f59e0b",
      sparkline: [45, 50, 42, 60, 55, 48, 52, 40, 38, 42, 36, 30]
    },
    {
      id: "total_purchase",
      label: "TOTAL PURCHASE",
      numericValue: 14820,
      prefix: "$",
      suffix: "",
      decimals: 0,
      subLabel: "This Month",
      change: "+5.40%",
      isPositive: true,
      color: "#06b6d4",
      sparkline: [25, 30, 38, 45, 40, 52, 48, 65, 58, 70, 68, 80]
    },
    {
      id: "purchase_due",
      label: "PURCHASE DUE",
      numericValue: 4280,
      prefix: "$",
      suffix: "",
      decimals: 0,
      subLabel: "To Suppliers",
      change: "5 Bills Due",
      isPositive: false,
      color: "#f43f5e",
      sparkline: [30, 35, 28, 40, 38, 45, 50, 42, 48, 38, 42, 35]
    },
    {
      id: "total_expense",
      label: "EXPENSE",
      numericValue: 2350,
      prefix: "$",
      suffix: "",
      decimals: 0,
      subLabel: "This Month",
      change: "-2.15%",
      isPositive: true,
      color: "#a855f7",
      sparkline: [38, 42, 35, 48, 40, 45, 38, 42, 35, 32, 28, 25]
    }
  ],
  salesOverview: {
    yLabels: ["$30K", "$25K", "$20K", "$15K", "$10K", "$5K", "$0"],
    xLabels: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
    thisWeekPoints: [
      { x: 30, y: 145 },
      { x: 110, y: 130 },
      { x: 190, y: 115 },
      { x: 275, y: 92 },
      { x: 360, y: 98 },
      { x: 445, y: 55 },
      { x: 520, y: 40 }
    ],
    lastWeekPoints: [
      { x: 30, y: 155 },
      { x: 110, y: 140 },
      { x: 190, y: 135 },
      { x: 275, y: 120 },
      { x: 360, y: 110 },
      { x: 445, y: 95 },
      { x: 520, y: 80 }
    ]
  },
  salesByChannel: {
    total: 24560,
    segments: [
      { name: "Dine In", amount: 9850, percentage: 40.1, color: "#22c55e" },
      { name: "Take Away", amount: 5620, percentage: 22.9, color: "#06b6d4" },
      { name: "Home Delivery", amount: 6340, percentage: 25.8, color: "#f59e0b" },
      { name: "Drive Thru", amount: 2750, percentage: 11.2, color: "#a855f7" }
    ]
  },
  topSellingCategories: [
    { name: "Burgers", amount: 6250, percentage: "25.5%", width: 85 },
    { name: "Pizza", amount: 5420, percentage: "22.1%", width: 74 },
    { name: "Chicken", amount: 4310, percentage: "17.6%", width: 59 },
    { name: "Drinks", amount: 3210, percentage: "13.1%", width: 44 },
    { name: "Desserts", amount: 2180, percentage: "8.9%", width: 30 },
    { name: "Pasta & Noodles", amount: 1850, percentage: "7.5%", width: 25 }
  ],
  operationalKpis: [
    {
      title: "FOOD COST",
      amount: 6980,
      pct: "28.45%",
      pctColor: "text-rose-400",
      icon: Utensils,
      iconColor: "text-emerald-400",
      iconBg: "bg-emerald-500/10 border-emerald-500/20"
    },
    {
      title: "LABOR COST",
      amount: 4320,
      pct: "17.61%",
      pctColor: "text-amber-400",
      icon: Users,
      iconColor: "text-amber-400",
      iconBg: "bg-amber-500/10 border-amber-500/20"
    },
    {
      title: "PRIME COST",
      amount: 11300,
      pct: "46.06%",
      pctColor: "text-purple-400",
      icon: PieChart,
      iconColor: "text-purple-400",
      iconBg: "bg-purple-500/10 border-purple-500/20"
    },
    {
      title: "DISCOUNTS",
      amount: 850,
      pct: "3.46%",
      pctColor: "text-emerald-400",
      icon: Tag,
      iconColor: "text-emerald-400",
      iconBg: "bg-emerald-500/10 border-emerald-500/20"
    },
    {
      title: "VOIDS",
      amount: 320,
      pct: "1.30%",
      pctColor: "text-rose-500",
      icon: XCircle,
      iconColor: "text-rose-500",
      iconBg: "bg-rose-500/10 border-rose-500/20"
    },
    {
      title: "CASH VARIANCE",
      amount: 180,
      pct: "0.73%",
      pctColor: "text-emerald-400",
      icon: Banknote,
      iconColor: "text-teal-400",
      iconBg: "bg-teal-500/10 border-teal-500/20"
    }
  ],
  dailySalesHeatmap: {
    days: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    timeSlots: ["12 AM", "4 AM", "8 AM", "12 PM", "4 PM", "8 PM", "12 AM"],
    matrix: [
      [0, 0, 0, 1, 1, 2, 1, 0],
      [0, 0, 0, 2, 2, 3, 2, 0],
      [0, 0, 0, 1, 3, 3, 2, 1],
      [0, 0, 0, 2, 3, 4, 3, 1],
      [0, 0, 1, 3, 4, 4, 4, 2],
      [0, 0, 1, 4, 4, 4, 4, 3],
      [0, 0, 0, 3, 4, 3, 2, 1]
    ]
  },
  paymentMethods: {
    total: 24560,
    segments: [
      { name: "Cash", amount: 8450, percentage: 34.4, color: "#22c55e" },
      { name: "Card", amount: 11250, percentage: 45.8, color: "#10b981" },
      { name: "Online", amount: 4860, percentage: 19.8, color: "#f59e0b" }
    ]
  },
  ytdSummary: {
    sales: 1245680,
    salesGrowth: "+15.32%",
    grossProfit: 892350,
    grossMargin: "71.67%",
    netProfit: 356780,
    netMargin: "28.67%"
  }
};

// ==========================================
// COMPONENT: SVG MINI SPARKLINES (ANIMATED)
// ==========================================
function MiniSparkline({
  points,
  color,
  gradientId,
  isLoaded
}: {
  points: number[];
  color: string;
  gradientId: string;
  isLoaded: boolean;
}) {
  const width = 160;
  const height = 24;
  const min = Math.min(...points);
  const max = Math.max(...points) || 1;
  const step = width / (points.length - 1);

  const coords = points.map((p, i) => {
    const x = i * step;
    const y = height - ((p - min) / (max - min || 1)) * (height - 6) - 3;
    return { x, y };
  });

  let d = `M ${coords[0].x},${coords[0].y}`;
  for (let i = 0; i < coords.length - 1; i++) {
    const p0 = coords[i];
    const p1 = coords[i + 1];
    const cp1x = p0.x + (p1.x - p0.x) / 2;
    const cp2x = cp1x;
    d += ` C ${cp1x},${p0.y} ${cp2x},${p1.y} ${p1.x},${p1.y}`;
  }

  const areaD = `${d} L ${width},${height} L 0,${height} Z`;

  return (
    <div className="w-full h-6 overflow-hidden mt-1">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-full overflow-visible"
        preserveAspectRatio="none"
      >
        <defs>
          <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.32" />
            <stop offset="100%" stopColor={color} stopOpacity="0.0" />
          </linearGradient>
        </defs>
        <path
          d={areaD}
          fill={`url(#${gradientId})`}
          className="transition-opacity duration-1000 ease-out"
          style={{ opacity: isLoaded ? 1 : 0 }}
        />
        <path
          d={d}
          fill="none"
          stroke={color}
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
          pathLength={1}
          strokeDasharray={1}
          strokeDashoffset={isLoaded ? 0 : 1}
          style={{
            transition: "stroke-dashoffset 1.2s cubic-bezier(0.16, 1, 0.3, 1)"
          }}
        />
      </svg>
    </div>
  );
}

// ==========================================
// COMPONENT: DONUT CHART (ANIMATED)
// ==========================================
function SvgDonutChart({
  segments,
  centerValue,
  centerSub,
  isLoaded,
  prefix = "$"
}: {
  segments: Array<{ name: string; percentage: number; color: string }>;
  centerValue: number;
  centerSub: string;
  isLoaded: boolean;
  prefix?: string;
}) {
  const size = 150;
  const strokeWidth = 26;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;

  let cumulativePercentage = 0;

  return (
    <div className="relative flex items-center justify-center">
      <svg width={size} height={size} className="-rotate-90 transform">
        {segments.map((seg, idx) => {
          const strokeDashoffset = -((cumulativePercentage / 100) * circumference);
          const segLength = (seg.percentage / 100) * circumference;
          cumulativePercentage += seg.percentage;

          return (
            <circle
              key={idx}
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="transparent"
              stroke={seg.color}
              strokeWidth={strokeWidth}
              strokeDasharray={
                isLoaded
                  ? `${segLength} ${circumference}`
                  : `0 ${circumference}`
              }
              strokeDashoffset={isLoaded ? strokeDashoffset : 0}
              style={{
                transition:
                  "stroke-dasharray 1.2s cubic-bezier(0.16, 1, 0.3, 1), stroke-dashoffset 1.2s cubic-bezier(0.16, 1, 0.3, 1)"
              }}
            />
          );
        })}
      </svg>

      {/* Center Text Cutout */}
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
        <span className="text-sm font-black text-foreground tracking-tight leading-tight">
          <AnimatedNumber value={centerValue} prefix={prefix} duration={1400} />
        </span>
        <span className="text-[10px] font-medium text-muted-foreground mt-0.5">
          {centerSub}
        </span>
      </div>
    </div>
  );
}

// ==========================================
// MAIN DASHBOARD COMPONENT
// ==========================================
export default function DashboardPage() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [selectedBranchId, setSelectedBranchId] = useState<string>("all");
  const [selectedDateRange, setSelectedDateRange] = useState<string>("today");
  const [customStartDate, setCustomStartDate] = useState<string>(() => {
    const d = new Date();
    return d.toISOString().split("T")[0];
  });
  const [customEndDate, setCustomEndDate] = useState<string>(() => {
    const d = new Date();
    return d.toISOString().split("T")[0];
  });
  const [isLoaded, setIsLoaded] = useState(false);
  const [hoveredHourTile, setHoveredHourTile] = useState<{
    day: string;
    hour: number;
    amount: number;
    count: number;
  } | null>(null);
  const [hoveredPurchaseDay, setHoveredPurchaseDay] = useState<{
    day: string;
    amount: number;
  } | null>(null);

  useEffect(() => {
    setCurrentUser(authService.getCurrentUser());
    setIsAuthenticated(authService.isAuthenticated());

    if (!authService.isAuthenticated()) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }

    // Trigger entrance animation on initial mount
    const timer = setTimeout(() => {
      setIsLoaded(true);
    }, 60);

    return () => clearTimeout(timer);
  }, []);

  const businessId = currentUser?.businessId || "";
  const { symbol } = useCurrency(businessId);
  const { data: branches = [] } = useBranchesQuery(businessId, currentUser?.id || "");
  const { data: dashboardData, isFetching: isDashboardFetching } = useDashboardSummaryQuery(
    businessId,
    selectedBranchId,
    selectedDateRange,
    selectedDateRange === "custom" ? customStartDate : undefined,
    selectedDateRange === "custom" ? customEndDate : undefined
  );
  const { data: categoriesResponse } = useCategoriesQuery(businessId, { limit: 6 });
  const realCategories = categoriesResponse?.data || [];

  const topCategories =
    realCategories.length > 0
      ? realCategories.slice(0, 6).map((cat: any, idx: number) => {
          const fallback = MOCK_DATA.topSellingCategories[idx] || {
            name: cat.name,
            amount: 1500,
            percentage: "6.0%",
            width: 25
          };
          return {
            name: cat.name || fallback.name,
            amount: fallback.amount,
            percentage: fallback.percentage,
            width: fallback.width
          };
        })
      : MOCK_DATA.topSellingCategories;

  // Live Top 6 ERP KPIs from Database
  const hasData = Boolean(dashboardData);
  const salesTodayVal = hasData ? (dashboardData?.totalSalesToday ?? 0) : 24560;
  const salesGrowth =
    dashboardData?.salesGrowthPct !== undefined
      ? (dashboardData.salesGrowthPct >= 0 ? `+${dashboardData.salesGrowthPct}%` : `${dashboardData.salesGrowthPct}%`)
      : (hasData ? "+0.00%" : "+12.45%");

  const netProfitVal = hasData ? (dashboardData?.netProfitMonth ?? 0) : 7820;
  const netProfitMargin =
    dashboardData?.netProfitMargin !== undefined
      ? `${dashboardData.netProfitMargin}%`
      : (hasData ? "0.00%" : "31.88%");

  const invoiceDueVal = hasData ? (dashboardData?.invoiceDue ?? 0) : 3450;
  const unpaidCount =
    dashboardData?.unpaidInvoicesCount !== undefined
      ? `${dashboardData.unpaidInvoicesCount} Invoices`
      : (hasData ? "0 Invoices" : "12 Invoices");

  const purchaseVal = hasData ? (dashboardData?.totalPurchaseMonth ?? 0) : 14820;
  const purchaseGrowth =
    dashboardData?.purchaseGrowthPct !== undefined
      ? (dashboardData.purchaseGrowthPct >= 0 ? `+${dashboardData.purchaseGrowthPct}%` : `${dashboardData.purchaseGrowthPct}%`)
      : (hasData ? "+0.00%" : "+5.40%");

  const purchaseDueVal = hasData ? (dashboardData?.purchaseDue ?? 0) : 4280;
  const dueBillsCount =
    dashboardData?.dueBillsCount !== undefined
      ? `${dashboardData.dueBillsCount} Bills Due`
      : (hasData ? "0 Bills Due" : "5 Bills Due");

  const expenseVal = hasData ? (dashboardData?.totalExpenseMonth ?? 0) : 2350;
  const expenseChange =
    dashboardData?.expenseChangePct !== undefined
      ? (dashboardData.expenseChangePct >= 0 ? `+${dashboardData.expenseChangePct}%` : `${dashboardData.expenseChangePct}%`)
      : (hasData ? "0.00%" : "-2.15%");

  const salesSparkline = dashboardData?.weeklySalesChart?.length
    ? dashboardData.weeklySalesChart.map((d) => Math.max(d.amount, 10))
    : [20, 35, 25, 45, 30, 55, 48, 65, 58, 80, 72, 95];

  const purchaseSparkline = dashboardData?.weeklySalesChart?.length
    ? dashboardData.weeklySalesChart.map((d) => Math.max(d.purchaseAmount || d.amount * 0.6, 10))
    : [25, 30, 38, 45, 40, 52, 48, 65, 58, 70, 68, 80];

  const periodDisplayLabel =
    dashboardData?.periodLabel ||
    (selectedDateRange === "today"
      ? "vs Yesterday"
      : selectedDateRange === "yesterday"
      ? "vs Prev Day"
      : selectedDateRange === "this_week"
      ? "vs Last Week"
      : selectedDateRange === "this_year"
      ? "vs Last Year"
      : selectedDateRange === "custom"
      ? "Selected Period"
      : "vs Last Month");

  const currentPeriodName =
    selectedDateRange === "today"
      ? "Today"
      : selectedDateRange === "yesterday"
      ? "Yesterday"
      : selectedDateRange === "this_week"
      ? "This Week"
      : selectedDateRange === "this_year"
      ? "This Year"
      : selectedDateRange === "custom"
      ? "Period"
      : "This Month";

  const liveTopKpis = [
    {
      id: "total_sales",
      label: "TOTAL SALES",
      numericValue: salesTodayVal,
      prefix: symbol || "$",
      suffix: "",
      decimals: 0,
      subLabel: periodDisplayLabel,
      change: salesGrowth,
      isPositive: !salesGrowth.startsWith("-"),
      color: "#22c55e",
      sparkline: salesSparkline,
    },
    {
      id: "net_profit",
      label: "NET PROFIT",
      numericValue: netProfitVal,
      prefix: symbol || "$",
      suffix: "",
      decimals: 0,
      subLabel: "Margin",
      change: netProfitMargin,
      isPositive: true,
      color: "#10b981",
      sparkline: [18, 22, 35, 30, 40, 32, 55, 48, 62, 58, 75, 85],
    },
    {
      id: "invoice_due",
      label: "INVOICE DUE",
      numericValue: invoiceDueVal,
      prefix: symbol || "$",
      suffix: "",
      decimals: 0,
      subLabel: "Unpaid Invoices",
      change: unpaidCount,
      isPositive: false,
      color: "#f59e0b",
      sparkline: [45, 50, 42, 60, 55, 48, 52, 40, 38, 42, 36, 30],
    },
    {
      id: "total_purchase",
      label: "TOTAL PURCHASE",
      numericValue: purchaseVal,
      prefix: symbol || "$",
      suffix: "",
      decimals: 0,
      subLabel: currentPeriodName,
      change: purchaseGrowth,
      isPositive: true,
      color: "#06b6d4",
      sparkline: purchaseSparkline,
    },
    {
      id: "purchase_due",
      label: "PURCHASE DUE",
      numericValue: purchaseDueVal,
      prefix: symbol || "$",
      suffix: "",
      decimals: 0,
      subLabel: "To Suppliers",
      change: dueBillsCount,
      isPositive: false,
      color: "#f43f5e",
      sparkline: [30, 35, 28, 40, 38, 45, 50, 42, 48, 38, 42, 35],
    },
    {
      id: "total_expense",
      label: "EXPENSE",
      numericValue: expenseVal,
      prefix: symbol || "$",
      suffix: "",
      decimals: 0,
      subLabel: currentPeriodName,
      change: expenseChange,
      isPositive: expenseChange.startsWith("-"),
      color: "#a855f7",
      sparkline: [38, 42, 35, 48, 40, 45, 38, 42, 35, 32, 28, 25],
    },
  ];

  // Live Payment Methods Breakdown with Top 3 + "Others" aggregation
  // Cash always uses the ERP theme primary color: hsl(var(--primary))
  const PRIMARY_COLOR = "hsl(var(--primary))";
  const nonCashPalette = [
    "#3b82f6", // Electric Blue
    "#f59e0b", // Amber Gold
    "#06b6d4", // Cyan
    "#ec4899", // Pink
  ];
  const OTHERS_COLOR = "#a855f7"; // Purple for aggregated Others

  const rawPaymentShares = dashboardData?.paymentShares || [];
  const activePayments = [...rawPaymentShares]
    .filter((p) => p.amount > 0)
    .sort((a, b) => b.amount - a.amount);

  const livePaymentTotal = activePayments.reduce((acc, curr) => acc + curr.amount, 0);

  let livePaymentSegments: Array<{ name: string; amount: number; percentage: number; color: string }> = [];

  if (activePayments.length > 3) {
    const top3 = activePayments.slice(0, 3);
    const others = activePayments.slice(3);
    const othersAmount = others.reduce((acc, curr) => acc + curr.amount, 0);

    let nonCashIdx = 0;
    const top3Segments = top3.map((p) => {
      const pct = livePaymentTotal > 0 ? Math.round((p.amount / livePaymentTotal) * 100) : 0;
      const isCash = p.method.toLowerCase() === "cash";
      const color = isCash ? PRIMARY_COLOR : nonCashPalette[nonCashIdx++ % nonCashPalette.length];
      return {
        name: p.method,
        amount: p.amount,
        percentage: pct,
        color,
      };
    });

    const top3Sum = top3Segments.reduce((acc, c) => acc + c.percentage, 0);
    const othersPct = livePaymentTotal > 0 ? Math.max(0, 100 - top3Sum) : 0;

    livePaymentSegments = [
      ...top3Segments,
      {
        name: "Others",
        amount: othersAmount,
        percentage: othersPct,
        color: OTHERS_COLOR,
      },
    ];
  } else if (activePayments.length > 0) {
    let nonCashIdx = 0;
    livePaymentSegments = activePayments.map((p) => {
      const pct = livePaymentTotal > 0 ? Math.round((p.amount / livePaymentTotal) * 100) : 0;
      const isCash = p.method.toLowerCase() === "cash";
      const color = isCash ? PRIMARY_COLOR : nonCashPalette[nonCashIdx++ % nonCashPalette.length];
      return {
        name: p.method,
        amount: p.amount,
        percentage: pct,
        color,
      };
    });
  } else {
    livePaymentSegments = [
      { name: "Cash", amount: 0, percentage: 100, color: PRIMARY_COLOR },
    ];
  }

  // 6 Live Operational ERP KPIs:
  // 1. Total Products
  // 2. Low Stock Products
  // 3. Total Customers
  // 4. Total Suppliers
  // 5. Customer Total Due
  // 6. Supplier Total Due
  const liveOperationalKpis = [
    {
      title: "TOTAL PRODUCTS",
      amount: dashboardData?.totalProducts ?? 0,
      isCurrency: false,
      badge: "Active Catalog",
      badgeColor: "text-blue-400",
      icon: Package,
      iconColor: "text-blue-400",
      iconBg: "bg-blue-500/10 border-blue-500/20",
    },
    {
      title: "LOW STOCK ITEMS",
      amount: dashboardData?.lowStockCount ?? 0,
      isCurrency: false,
      badge: (dashboardData?.lowStockCount ?? 0) > 0 ? "Alert - Reorder" : "Stock Healthy",
      badgeColor: (dashboardData?.lowStockCount ?? 0) > 0 ? "text-rose-400" : "text-emerald-400",
      icon: AlertTriangle,
      iconColor: (dashboardData?.lowStockCount ?? 0) > 0 ? "text-rose-400" : "text-amber-400",
      iconBg: (dashboardData?.lowStockCount ?? 0) > 0 ? "bg-rose-500/10 border-rose-500/20" : "bg-amber-500/10 border-amber-500/20",
    },
    {
      title: "TOTAL CUSTOMERS",
      amount: dashboardData?.totalCustomers ?? 0,
      isCurrency: false,
      badge: "Active Clients",
      badgeColor: "text-emerald-400",
      icon: Users,
      iconColor: "text-emerald-400",
      iconBg: "bg-emerald-500/10 border-emerald-500/20",
    },
    {
      title: "TOTAL SUPPLIERS",
      amount: dashboardData?.totalSuppliers ?? 0,
      isCurrency: false,
      badge: "Active Vendors",
      badgeColor: "text-purple-400",
      icon: Truck,
      iconColor: "text-purple-400",
      iconBg: "bg-purple-500/10 border-purple-500/20",
    },
    {
      title: "CUSTOMER DUE",
      amount: dashboardData?.customerTotalDue ?? dashboardData?.invoiceDue ?? 0,
      isCurrency: true,
      badge: `${dashboardData?.unpaidInvoicesCount ?? 0} Invoices Due`,
      badgeColor: (dashboardData?.customerTotalDue ?? dashboardData?.invoiceDue ?? 0) > 0 ? "text-rose-400" : "text-emerald-400",
      icon: ArrowDownLeft,
      iconColor: "text-rose-400",
      iconBg: "bg-rose-500/10 border-rose-500/20",
    },
    {
      title: "SUPPLIER DUE",
      amount: dashboardData?.supplierTotalDue ?? dashboardData?.purchaseDue ?? 0,
      isCurrency: true,
      badge: `${dashboardData?.dueBillsCount ?? 0} Bills Payable`,
      badgeColor: (dashboardData?.supplierTotalDue ?? dashboardData?.purchaseDue ?? 0) > 0 ? "text-amber-400" : "text-emerald-400",
      icon: ArrowUpRight,
      iconColor: "text-teal-400",
      iconBg: "bg-teal-500/10 border-teal-500/20",
    },
  ];

  // Helper for 12-hour AM/PM formatting
  const formatHourAmPm = (hr: number) => {
    const ampm = hr >= 12 ? "PM" : "AM";
    const h12 = hr % 12 === 0 ? 12 : hr % 12;
    return `${h12} ${ampm}`;
  };

  // 24-Hour Peak Sales Heatmap Data (Live + Fallback)
  const defaultHeatmapDays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const liveHeatmap = dashboardData?.hourlySalesHeatmap;
  const heatmapDays = liveHeatmap?.days && liveHeatmap.days.length === 7 ? liveHeatmap.days : defaultHeatmapDays;

  const fallback24hMatrix: number[][] = [
    [0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 2, 2, 2, 2, 3, 3, 4, 3, 2, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 2, 1, 2, 2, 3, 4, 4, 3, 2, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 3, 3, 3, 2, 2, 2, 3, 3, 4, 3, 3, 2, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 2, 2, 3, 3, 4, 4, 4, 3, 2, 1, 0],
    [0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 3, 4, 4, 3, 3, 3, 3, 4, 4, 4, 4, 3, 2, 1],
    [0, 0, 0, 0, 0, 0, 1, 1, 2, 3, 3, 4, 4, 4, 3, 3, 4, 4, 4, 4, 4, 3, 2, 1],
    [0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 3, 4, 4, 4, 3, 3, 3, 4, 4, 3, 2, 2, 1, 0],
  ];

  const heatmapMatrix =
    liveHeatmap?.matrix && liveHeatmap.matrix.length === 7
      ? liveHeatmap.matrix
      : fallback24hMatrix;

  const heatmapPeakInfo = liveHeatmap?.peakInfo || "Fri 8 PM";

  if (isAuthenticated === null) {
    return <LoadingSession />;
  }

  if (isAuthenticated === false) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-4 text-center p-4">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
        <h2 className="text-lg font-bold text-foreground">Redirecting to Login...</h2>
        <p className="text-xs text-muted-foreground">
          You must be signed in to access the dashboard.
        </p>
      </div>
    );
  }

  // Smooth curve paths for Sales Overview Chart
  const createSmoothPath = (pts: Array<{ x: number; y: number }>) => {
    if (!pts || pts.length === 0) return "";
    let d = `M ${pts[0].x},${pts[0].y}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i];
      const p1 = pts[i + 1];
      const cp1x = p0.x + (p1.x - p0.x) / 2;
      const cp2x = cp1x;
      d += ` C ${cp1x},${p0.y} ${cp2x},${p1.y} ${p1.x},${p1.y}`;
    }
    return d;
  };

  // Dynamic Live Sales Overview Chart Calculation
  const liveWeeklyChart =
    dashboardData?.weeklySalesChart && dashboardData.weeklySalesChart.length > 0
      ? dashboardData.weeklySalesChart
      : [
          { day: "Sun", date: "", amount: 0, prevAmount: 0 },
          { day: "Mon", date: "", amount: 0, prevAmount: 0 },
          { day: "Tue", date: "", amount: 0, prevAmount: 0 },
          { day: "Wed", date: "", amount: 0, prevAmount: 0 },
          { day: "Thu", date: "", amount: 0, prevAmount: 0 },
          { day: "Fri", date: "", amount: 0, prevAmount: 0 },
          { day: "Sat", date: "", amount: 0, prevAmount: 0 },
        ];

  const chartAmounts = liveWeeklyChart.map((d) => d.amount);
  const chartPrevAmounts = liveWeeklyChart.map((d) => d.prevAmount ?? 0);
  const rawMaxVal = Math.max(...chartAmounts, ...chartPrevAmounts, 0);

  // Determine a clean Y-axis ceiling
  const chartCeiling =
    rawMaxVal <= 0
      ? 1000
      : rawMaxVal <= 1000
      ? Math.ceil(rawMaxVal / 200) * 200
      : rawMaxVal <= 5000
      ? Math.ceil(rawMaxVal / 500) * 500
      : rawMaxVal <= 25000
      ? Math.ceil(rawMaxVal / 2500) * 2500
      : Math.ceil(rawMaxVal / 10000) * 10000;

  const formatAxisVal = (val: number) => {
    if (val <= 0) return `${symbol || "$"}0`;
    if (val >= 1000000) return `${symbol || "$"}${(val / 1000000).toFixed(1)}M`;
    if (val >= 1000) return `${symbol || "$"}${Math.round(val / 1000)}K`;
    return `${symbol || "$"}${Math.round(val)}`;
  };

  const chartYAxisLabels = [
    formatAxisVal(chartCeiling),
    formatAxisVal(chartCeiling * 0.66),
    formatAxisVal(chartCeiling * 0.33),
    formatAxisVal(0),
  ];

  const chartPointCount = liveWeeklyChart.length;
  const chartXStep = chartPointCount > 1 ? (510 - 30) / (chartPointCount - 1) : 0;
  const chartBaseY = 150;
  const chartUsableH = 120;

  const liveThisWeekPoints = liveWeeklyChart.map((d, i) => {
    const x = 30 + i * chartXStep;
    const y = chartBaseY - (d.amount / chartCeiling) * chartUsableH;
    return { x, y, amount: d.amount, day: d.day };
  });

  const liveLastWeekPoints = liveWeeklyChart.map((d, i) => {
    const x = 30 + i * chartXStep;
    const y = chartBaseY - ((d.prevAmount ?? 0) / chartCeiling) * chartUsableH;
    return { x, y, amount: d.prevAmount ?? 0 };
  });

  const liveThisWeekLinePath = createSmoothPath(liveThisWeekPoints);
  const liveLastWeekLinePath = createSmoothPath(liveLastWeekPoints);
  const liveThisWeekAreaPath = `${liveThisWeekLinePath} L ${liveThisWeekPoints[liveThisWeekPoints.length - 1]?.x || 510},${chartBaseY + 10} L ${liveThisWeekPoints[0]?.x || 30},${chartBaseY + 10} Z`;

  // Dynamic peak badge positioned right above highest sales day
  const peakPoint = liveThisWeekPoints.reduce(
    (max, pt) => (pt.amount > max.amount ? pt : max),
    liveThisWeekPoints[liveThisWeekPoints.length - 1] || { x: 485, y: 30, amount: 0 }
  );

  const peakBadgeX = Math.min(Math.max(peakPoint.x - 30, 8), 465);
  const peakBadgeY = Math.max(peakPoint.y - 28, 4);

  // Purchases Trend Chart Calculation for Row 4 Card 3
  const purchaseAmounts = liveWeeklyChart.map((d) => d.purchaseAmount ?? 0);
  const rawMaxPurchase = Math.max(...purchaseAmounts, 0);
  const purchaseCeiling =
    rawMaxPurchase <= 0
      ? 5000
      : rawMaxPurchase <= 1000
      ? Math.ceil(rawMaxPurchase / 200) * 200
      : rawMaxPurchase <= 10000
      ? Math.ceil(rawMaxPurchase / 1000) * 1000
      : Math.ceil(rawMaxPurchase / 5000) * 5000;

  const purchaseChartW = 380;
  const purchaseChartH = 92;
  const purchaseBaseY = 64;
  const purchaseUsableH = 46;
  const purchaseXStep = chartPointCount > 1 ? (purchaseChartW - 36) / (chartPointCount - 1) : 0;

  const livePurchasePoints = liveWeeklyChart.map((d, i) => {
    const x = 18 + i * purchaseXStep;
    const val = d.purchaseAmount ?? 0;
    const y = purchaseBaseY - (val / purchaseCeiling) * purchaseUsableH;
    return { x, y, amount: val, day: d.day };
  });

  const livePurchaseLinePath = createSmoothPath(livePurchasePoints);
  const livePurchaseAreaPath = `${livePurchaseLinePath} L ${livePurchasePoints[livePurchasePoints.length - 1]?.x || purchaseChartW - 18},${purchaseBaseY + 4} L ${livePurchasePoints[0]?.x || 18},${purchaseBaseY + 4} Z`;

  // Expense Breakdown Data (Donut Chart)
  const expenseData = dashboardData?.expenseBreakdown;
  const liveExpenseSegments = expenseData?.segments && expenseData.segments.length > 0
    ? expenseData.segments
    : [
        { name: "Shop & Rent", amount: 12500, percentage: 45.0, color: "#ef4444" },
        { name: "Staff Salary", amount: 8200, percentage: 29.5, color: "#a855f7" },
        { name: "Utilities & Bills", amount: 4300, percentage: 15.5, color: "#f59e0b" },
        { name: "Supplies & Misc", amount: 2800, percentage: 10.0, color: "#06b6d4" }
      ];
  const liveExpenseTotal = expenseData?.total ?? liveExpenseSegments.reduce((a, b) => a + b.amount, 0);

  return (
    <div className="h-screen bg-background text-foreground flex overflow-hidden font-sans antialiased">
      {/* Sidebar */}
      <Sidebar activePath="/dashboard" />

      {/* Main Container */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        <Navbar title="Dashboard" subtitle="Enterprise Executive Summary" />

        {/* Dashboard Scrollable Body */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-5 relative z-10 bg-background">
          <div className="w-full space-y-5 pb-10">

            {/* TOP HEADER & CONTROLS */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h1 className="text-xl md:text-2xl font-black text-foreground tracking-wider">
                  Dashboard
                </h1>
                <p className="text-xs md:text-sm text-muted-foreground font-medium">
                  Overview of Restaurant Performance
                </p>
              </div>

              {/* Filters / Selectors */}
              <div className="flex flex-wrap items-center gap-3">
                {/* Branch Selector */}
                <div className="flex flex-col min-w-[155px]">
                  <span className="text-[10px] text-muted-foreground font-semibold mb-0.5 ml-1">
                    Select Branch
                  </span>
                  <Select
                    value={selectedBranchId}
                    onValueChange={setSelectedBranchId}
                    icon={<Building2 className="w-3.5 h-3.5 text-muted-foreground" />}
                    className="h-8 py-1.5 pl-9 pr-2.5 text-xs bg-card border-border/80 hover:border-border font-semibold shadow-sm"
                  >
                    <option value="all">All Branches</option>
                    {branches.map((b: any) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </Select>
                </div>

                {/* Date Filter Selector */}
                <div className="flex flex-col min-w-[155px]">
                  <span className="text-[10px] text-muted-foreground font-semibold mb-0.5 ml-1">
                    Date Period
                  </span>
                  <Select
                    value={selectedDateRange}
                    onValueChange={setSelectedDateRange}
                    icon={<Calendar className="w-3.5 h-3.5 text-emerald-500" />}
                    className="h-8 py-1.5 pl-9 pr-2.5 text-xs bg-card border-border/80 hover:border-border font-semibold shadow-sm"
                  >
                    <option value="today">Today</option>
                    <option value="yesterday">Yesterday</option>
                    <option value="this_week">This Week</option>
                    <option value="this_month">This Month</option>
                    <option value="this_year">This Year</option>
                    <option value="custom">Custom Range</option>
                  </Select>
                </div>

                {/* Custom Date Pickers (Active when 'custom' is selected) */}
                {selectedDateRange === "custom" && (
                  <div className="flex items-center gap-2">
                    <div className="flex flex-col">
                      <span className="text-[10px] text-muted-foreground font-semibold mb-0.5 ml-1">
                        From
                      </span>
                      <input
                        type="date"
                        value={customStartDate}
                        onChange={(e) => setCustomStartDate(e.target.value)}
                        className="bg-card border border-border/80 hover:border-border text-foreground text-xs px-2.5 h-8 rounded-sm focus:outline-none focus:border-primary transition-colors shadow-sm cursor-pointer"
                      />
                    </div>
                    <div className="flex flex-col">
                      <span className="text-[10px] text-muted-foreground font-semibold mb-0.5 ml-1">
                        To
                      </span>
                      <input
                        type="date"
                        value={customEndDate}
                        onChange={(e) => setCustomEndDate(e.target.value)}
                        className="bg-card border border-border/80 hover:border-border text-foreground text-xs px-2.5 h-8 rounded-sm focus:outline-none focus:border-primary transition-colors shadow-sm cursor-pointer"
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* ROW 1: TOP 6 KPI CARDS (ANIMATED COUNT & SPARKLINES - LIVE DATA) */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {liveTopKpis.map((kpi, idx) => (
                <div
                  key={kpi.id}
                  className="bg-card border border-border/80 rounded-sm px-3 py-2 flex flex-col justify-between shadow-sm hover:border-border transition-all duration-500 group"
                  style={{
                    opacity: isLoaded ? 1 : 0,
                    transform: isLoaded ? "translateY(0)" : "translateY(8px)",
                    transition: `all 0.5s cubic-bezier(0.16, 1, 0.3, 1) ${idx * 60}ms`
                  }}
                >
                  <div>
                    <span className="text-[9.5px] font-bold tracking-wider text-muted-foreground uppercase block mb-0.5">
                      {kpi.label}
                    </span>
                    <div
                      className="text-lg md:text-xl font-black font-mono tracking-tight leading-tight"
                      style={{ color: kpi.color }}
                    >
                      <AnimatedNumber
                        value={kpi.numericValue}
                        prefix={kpi.prefix}
                        suffix={kpi.suffix}
                        decimals={kpi.decimals}
                        duration={1200}
                      />
                    </div>
                    <div className="flex items-center gap-1 mt-0.5 text-[10px]">
                      <span className="text-muted-foreground">{kpi.subLabel}</span>
                      <span
                        className={`font-semibold flex items-center ${
                          kpi.isPositive ? "text-emerald-400" : "text-rose-400"
                        }`}
                      >
                        {kpi.change.startsWith("+") ? (
                          <TrendingUp className="w-2.5 h-2.5 mr-0.5 inline" />
                        ) : kpi.change.startsWith("-") ? (
                          <TrendingDown className="w-2.5 h-2.5 mr-0.5 inline" />
                        ) : null}
                        {kpi.change}
                      </span>
                    </div>
                  </div>

                  {/* Animated Sparkline curve */}
                  <MiniSparkline
                    points={kpi.sparkline}
                    color={kpi.color}
                    gradientId={`spark-${kpi.id}`}
                    isLoaded={isLoaded}
                  />
                </div>
              ))}
            </div>

            {/* ROW 2: 3 MAJOR ANALYTICS CARDS */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">

              {/* CARD 1: SALES OVERVIEW (ANIMATED DUAL LINE CHART) */}
              <div
                className="lg:col-span-5 bg-card border border-border/80 rounded-sm p-4 flex flex-col justify-between shadow-md transition-all duration-700"
                style={{
                  opacity: isLoaded ? 1 : 0,
                  transform: isLoaded ? "translateY(0)" : "translateY(10px)"
                }}
              >
                <div className="flex items-center justify-between mb-2">
                  <h2 className="text-xs font-bold text-foreground tracking-wider uppercase">
                    SALES OVERVIEW
                  </h2>
                  <div className="flex items-center gap-4 text-[11px]">
                    <div className="flex items-center gap-1.5">
                      <span className="w-3 h-0.5 bg-emerald-500 rounded-full inline-block"></span>
                      <span className="text-foreground font-medium">This Week</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-3 h-0.5 border-b border-dashed border-muted-foreground inline-block"></span>
                      <span className="text-muted-foreground font-medium">Last Week</span>
                    </div>
                  </div>
                </div>

                {/* Dual Line SVG Chart with Smooth Line Drawing */}
                <div className="relative w-full flex flex-col mt-2">
                  <div className="relative w-full h-[165px]">
                    <svg
                      viewBox="0 0 540 180"
                      className="w-full h-full overflow-visible"
                      preserveAspectRatio="none"
                    >
                      <defs>
                        <linearGradient id="thisWeekGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#22c55e" stopOpacity="0.28" />
                          <stop offset="100%" stopColor="#22c55e" stopOpacity="0.0" />
                        </linearGradient>
                      </defs>

                      {/* Horizontal Gridlines */}
                      {[20, 55, 90, 125, 160].map((yVal, idx) => (
                        <g key={idx}>
                          <line
                            x1="30"
                            y1={yVal}
                            x2="520"
                            y2={yVal}
                            stroke="currentColor"
                            className="text-border/40"
                            strokeWidth="1"
                            strokeDasharray="4 4"
                          />
                        </g>
                      ))}

                      {/* Area fill for This Week (Fades In) */}
                      <path
                        d={liveThisWeekAreaPath}
                        fill="url(#thisWeekGrad)"
                        className="transition-opacity duration-1000 ease-out"
                        style={{ opacity: isLoaded ? 1 : 0 }}
                      />

                      {/* Last Week Dashed Line */}
                      <path
                        d={liveLastWeekLinePath}
                        fill="none"
                        stroke="#71717a"
                        strokeWidth="2"
                        strokeDasharray="4 4"
                        strokeLinecap="round"
                        className="transition-opacity duration-700"
                        style={{ opacity: isLoaded ? 0.75 : 0 }}
                      />

                      {/* This Week Solid Line (Draws from left to right) */}
                      <path
                        d={liveThisWeekLinePath}
                        fill="none"
                        stroke="#22c55e"
                        strokeWidth="2.8"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        pathLength={1}
                        strokeDasharray={1}
                        strokeDashoffset={isLoaded ? 0 : 1}
                        style={{
                          transition:
                            "stroke-dashoffset 1.4s cubic-bezier(0.16, 1, 0.3, 1)"
                        }}
                      />

                      {/* Data Points on This Week */}
                      {liveThisWeekPoints.map((pt, i) => (
                        <circle
                          key={i}
                          cx={pt.x}
                          cy={pt.y}
                          r="3.5"
                          fill="#22c55e"
                          stroke="#18181b"
                          strokeWidth="2"
                          className="transition-transform duration-500"
                          style={{
                            transform: isLoaded ? "scale(1)" : "scale(0)",
                            transformOrigin: `${pt.x}px ${pt.y}px`,
                            transitionDelay: `${400 + i * 100}ms`
                          }}
                        />
                      ))}

                      {/* Peak Sales Value Pill Badge */}
                      <g
                        transform={`translate(${peakBadgeX}, ${peakBadgeY})`}
                        style={{
                          opacity: isLoaded ? 1 : 0,
                          transform: isLoaded
                            ? `translate(${peakBadgeX}px, ${peakBadgeY}px) scale(1)`
                            : `translate(${peakBadgeX}px, ${peakBadgeY + 4}px) scale(0.9)`,
                          transformOrigin: "center",
                          transition:
                            "all 0.6s cubic-bezier(0.16, 1, 0.3, 1) 1.2s"
                        }}
                      >
                        <rect
                          width="68"
                          height="20"
                          rx="2"
                          fill="#16a34a"
                          className="shadow-md"
                        />
                        <text
                          x="34"
                          y="14"
                          fill="#ffffff"
                          fontSize="10"
                          fontWeight="bold"
                          textAnchor="middle"
                          fontFamily="monospace"
                        >
                          {symbol || "$"}{peakPoint.amount.toLocaleString()}
                        </text>
                      </g>
                    </svg>

                    {/* Y-axis Labels on Left */}
                    <div className="absolute top-1 left-0 bottom-2 flex flex-col justify-between text-[10px] text-muted-foreground font-mono pointer-events-none">
                      {chartYAxisLabels.map((lbl, idx) => (
                        <span key={idx}>{lbl}</span>
                      ))}
                    </div>
                  </div>

                  {/* X-axis Labels at Bottom (Clean spacing inside card) */}
                  <div className="flex justify-between text-[10px] text-muted-foreground font-medium px-4 pt-2.5 pb-1">
                    {liveWeeklyChart.map((d, idx) => (
                      <span key={idx}>{d.day}</span>
                    ))}
                  </div>
                </div>
              </div>

              {/* CARD 2: PAYMENT METHODS (ANIMATED DONUT - LIVE DATA) */}
              <div
                className="lg:col-span-3 bg-card border border-border/80 rounded-sm p-4 flex flex-col justify-between shadow-md transition-all duration-700 delay-100"
                style={{
                  opacity: isLoaded ? 1 : 0,
                  transform: isLoaded ? "translateY(0)" : "translateY(10px)"
                }}
              >
                <div className="flex items-center justify-between mb-2">
                  <h2 className="text-xs font-bold text-foreground tracking-wider uppercase">
                    PAYMENT METHODS
                  </h2>
                  <span className="text-[10px] text-muted-foreground font-medium">Live Share</span>
                </div>

                <div className="flex flex-col items-center justify-center my-auto py-2">
                  <SvgDonutChart
                    segments={livePaymentSegments}
                    centerValue={livePaymentTotal}
                    centerSub="Total Paid"
                    prefix={symbol || "$"}
                    isLoaded={isLoaded}
                  />
                </div>

                {/* Legend & Percentages */}
                <div className="grid grid-cols-2 gap-y-2 gap-x-3 text-[11px] pt-2 border-t border-border/80">
                  {livePaymentSegments.map((seg, idx) => (
                    <div key={idx} className="flex items-start gap-1.5">
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0 mt-0.5"
                        style={{ backgroundColor: seg.color }}
                      ></span>
                      <div className="leading-tight min-w-0">
                        <span className="text-foreground font-semibold block truncate">
                          {seg.name}
                        </span>
                        <span className="text-muted-foreground text-[10px] whitespace-nowrap">
                          {symbol || "$"}<AnimatedNumber value={seg.amount} duration={1200} /> ({seg.percentage}%)
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* CARD 3: TOP 6 SELLING CATEGORIES (ANIMATED PROGRESS BARS) */}
              <div
                className="lg:col-span-4 bg-card border border-border/80 rounded-sm p-4 flex flex-col justify-between shadow-md transition-all duration-700 delay-150"
                style={{
                  opacity: isLoaded ? 1 : 0,
                  transform: isLoaded ? "translateY(0)" : "translateY(10px)"
                }}
              >
                <h2 className="text-xs font-bold text-foreground tracking-wider uppercase mb-3">
                  TOP 6 SELLING CATEGORIES
                </h2>

                <div className="space-y-3.5 my-auto">
                  {topCategories.map((cat, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex items-center justify-between text-xs font-medium">
                        <span className="text-foreground">{cat.name}</span>
                        <span className="text-muted-foreground font-mono text-[11px]">
                          <strong className="text-foreground">
                            $<AnimatedNumber value={cat.amount} duration={1200} />
                          </strong>{" "}
                          ({cat.percentage})
                        </span>
                      </div>
                      <div className="w-full bg-muted/60 h-2.5 rounded-sm overflow-hidden">
                        <div
                          className="h-full rounded-sm bg-gradient-to-r from-emerald-500 to-amber-500"
                          style={{
                            width: isLoaded ? `${cat.width}%` : "0%",
                            transition: `width 1.2s cubic-bezier(0.16, 1, 0.3, 1) ${
                              200 + idx * 80
                            }ms`
                          }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* ROW 3: 6 OPERATIONAL METRIC CARDS (ANIMATED NUMBERS - LIVE DATA) */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {liveOperationalKpis.map((kpi, idx) => {
                const Icon = kpi.icon;
                return (
                  <div
                    key={idx}
                    className="bg-card border border-border/80 rounded-sm px-3 py-2.5 flex items-center gap-2.5 shadow-sm hover:border-border transition-all"
                    style={{
                      opacity: isLoaded ? 1 : 0,
                      transform: isLoaded ? "translateY(0)" : "translateY(8px)",
                      transition: `all 0.5s cubic-bezier(0.16, 1, 0.3, 1) ${
                        300 + idx * 60
                      }ms`
                    }}
                  >
                    <div className={`p-2 rounded-full border ${kpi.iconBg} shrink-0`}>
                      <Icon className={`w-3.5 h-3.5 ${kpi.iconColor}`} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <span className="text-[9px] font-bold text-muted-foreground tracking-wider uppercase block truncate">
                        {kpi.title}
                      </span>
                      <div className="text-sm md:text-base font-black text-foreground font-mono leading-tight">
                        <AnimatedNumber
                          value={kpi.amount}
                          prefix={kpi.isCurrency ? (symbol || "$") : ""}
                          duration={1200}
                        />
                      </div>
                      <div className={`text-[10px] font-semibold truncate ${kpi.badgeColor}`}>
                        {kpi.badge}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* ROW 4: BOTTOM 3 ANALYTICS WIDGETS */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">

              {/* CARD 1: 24-HOUR PEAK SALES HEATMAP */}
              <div
                className="lg:col-span-4 bg-card border border-border/80 rounded-sm p-4 flex flex-col justify-between shadow-md transition-all duration-700 delay-200"
                style={{
                  opacity: isLoaded ? 1 : 0,
                  transform: isLoaded ? "translateY(0)" : "translateY(10px)"
                }}
              >
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h2 className="text-xs font-bold text-foreground tracking-wider uppercase">
                      24H PEAK SALES HEATMAP
                    </h2>
                    <div className="text-[10.5px] text-muted-foreground font-medium h-4 mt-0.5 flex items-center">
                      {hoveredHourTile ? (
                        <span className="text-emerald-400 font-semibold animate-fadeIn">
                          {hoveredHourTile.day} {formatHourAmPm(hoveredHourTile.hour)}: {symbol || "$"}{hoveredHourTile.amount.toLocaleString()} ({hoveredHourTile.count} {hoveredHourTile.count === 1 ? "Sale" : "Sales"})
                        </span>
                      ) : (
                        <span>Peak: <strong className="text-emerald-400 font-semibold">{heatmapPeakInfo}</strong> (24h Distribution)</span>
                      )}
                    </div>
                  </div>
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-muted/60 text-muted-foreground border border-border/60 self-start">
                    24 Hours
                  </span>
                </div>

                {/* 24-Hour Matrix Grid */}
                <div className="my-auto py-1">
                  {/* Time slot markers above the 24 columns (Vertical Alignment) */}
                  <div className="flex items-end gap-1.5 mb-1.5 h-7">
                    <span className="w-6 shrink-0 text-[10px]"></span>
                    <div className="grid grid-cols-[repeat(24,minmax(0,1fr))] gap-[2px] flex-1 h-full items-end">
                      {Array.from({ length: 24 }).map((_, h) => {
                        const showLabel =
                          h === 0 ? "12A" :
                          h === 4 ? "4A" :
                          h === 8 ? "8A" :
                          h === 12 ? "12P" :
                          h === 16 ? "4P" :
                          h === 20 ? "8P" :
                          h === 23 ? "11P" : null;
                        return (
                          <div key={h} className="col-span-1 flex items-end justify-center pb-0.5">
                            {showLabel && (
                              <span
                                style={{
                                  writingMode: "vertical-rl",
                                  transform: "rotate(180deg)",
                                }}
                                className="text-[8.5px] font-mono font-medium text-muted-foreground whitespace-nowrap leading-none select-none tracking-tighter"
                              >
                                {showLabel}
                              </span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Day rows with 24 sleek hour cells */}
                  <div className="space-y-1">
                    {heatmapDays.map((day, rowIdx) => (
                      <div key={rowIdx} className="flex items-center gap-1.5">
                        <span className="w-6 text-[10px] text-muted-foreground font-medium shrink-0">
                          {day}
                        </span>
                        <div className="grid grid-cols-[repeat(24,minmax(0,1fr))] gap-[2px] flex-1">
                          {heatmapMatrix[rowIdx].map((intensity, colIdx) => {
                            const detail = liveHeatmap?.details?.[rowIdx]?.[colIdx] || {
                              amount: intensity * 2450,
                              count: intensity > 0 ? intensity * 3 : 0
                            };

                            const heatmapBgColors = [
                              "bg-muted/30 hover:bg-muted/60 border border-transparent",
                              "bg-emerald-950/70 hover:bg-emerald-900 border border-emerald-900/40",
                              "bg-emerald-800/80 hover:bg-emerald-700 border border-emerald-700/50",
                              "bg-emerald-600 hover:bg-emerald-500 shadow-sm shadow-emerald-600/30",
                              "bg-emerald-400 hover:bg-emerald-300 shadow-[0_0_10px_rgba(52,211,153,0.7)] ring-1 ring-emerald-300/60"
                            ];

                            return (
                              <div
                                key={colIdx}
                                onMouseEnter={() =>
                                  setHoveredHourTile({
                                    day,
                                    hour: colIdx,
                                    amount: detail.amount,
                                    count: detail.count
                                  })
                                }
                                onMouseLeave={() => setHoveredHourTile(null)}
                                className={`h-3.5 sm:h-4 rounded-[2px] cursor-pointer transition-all hover:scale-110 ${heatmapBgColors[intensity]}`}
                                title={`${day} ${formatHourAmPm(colIdx)}: ${symbol || "$"}${detail.amount.toLocaleString()} (${detail.count} sales)`}
                                style={{
                                  opacity: isLoaded ? 1 : 0,
                                  transform: isLoaded ? "scale(1)" : "scale(0.8)",
                                  transition: `all 0.3s cubic-bezier(0.16, 1, 0.3, 1) ${
                                    200 + (rowIdx * 24 + colIdx) * 3
                                  }ms`
                                }}
                              ></div>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Heatmap intensity bar legend */}
                <div className="flex items-center justify-between text-[10px] text-muted-foreground pt-3 border-t border-border/80 mt-2">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-[1px] bg-muted/40 border border-border/60"></span>
                    <span>Low / 0</span>
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[9px] text-muted-foreground">Intensity:</span>
                    <div className="w-24 h-1.5 rounded-sm bg-gradient-to-r from-muted via-emerald-800 to-emerald-400"></div>
                  </div>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-[1px] bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.8)]"></span>
                    <span className="text-emerald-400 font-semibold">Peak Rush</span>
                  </span>
                </div>
              </div>

              {/* CARD 2: EXPENSES BREAKDOWN (ANIMATED DONUT) */}
              <div
                className="lg:col-span-4 bg-card border border-border/80 rounded-sm p-4 flex flex-col justify-between shadow-md transition-all duration-700 delay-300"
                style={{
                  opacity: isLoaded ? 1 : 0,
                  transform: isLoaded ? "translateY(0)" : "translateY(10px)"
                }}
              >
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h2 className="text-xs font-bold text-foreground tracking-wider uppercase">
                      EXPENSES BREAKDOWN
                    </h2>
                    <p className="text-[10px] text-muted-foreground font-medium mt-0.5">
                      Operational Outflow
                    </p>
                  </div>
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/20 self-start">
                    Category Share
                  </span>
                </div>

                <div className="flex flex-col items-center justify-center my-auto py-2">
                  <SvgDonutChart
                    segments={liveExpenseSegments}
                    centerValue={liveExpenseTotal}
                    centerSub="Total Expenses"
                    prefix={symbol || "$"}
                    isLoaded={isLoaded}
                  />
                </div>

                {/* Category Breakdown list */}
                <div className="grid grid-cols-2 gap-y-2 gap-x-3 text-[11px] pt-2 border-t border-border/80">
                  {liveExpenseSegments.map((seg, idx) => (
                    <div key={idx} className="flex items-start gap-1.5">
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0 mt-0.5"
                        style={{ backgroundColor: seg.color }}
                      ></span>
                      <div className="leading-tight min-w-0">
                        <span className="text-foreground font-semibold block truncate">{seg.name}</span>
                        <span className="text-muted-foreground font-mono text-[10px] whitespace-nowrap">
                          {symbol || "$"}<AnimatedNumber value={seg.amount} duration={1200} /> ({seg.percentage}%)
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* CARD 3: PURCHASES OVERVIEW (ANIMATED MODERN AREA & BAR CHART) */}
              <div
                className="lg:col-span-4 bg-card border border-border/80 rounded-sm p-4 flex flex-col justify-between shadow-md relative overflow-hidden transition-all duration-700 delay-350"
                style={{
                  opacity: isLoaded ? 1 : 0,
                  transform: isLoaded ? "translateY(0)" : "translateY(10px)"
                }}
              >
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h2 className="text-xs font-bold text-foreground tracking-wider uppercase">
                      PURCHASES OVERVIEW
                    </h2>
                    <div className="text-[10px] text-muted-foreground font-medium h-3.5 mt-0.5">
                      {hoveredPurchaseDay ? (
                        <span className="text-cyan-400 font-semibold animate-fadeIn">
                          {hoveredPurchaseDay.day}: {symbol || "$"}{hoveredPurchaseDay.amount.toLocaleString()}
                        </span>
                      ) : (
                        <span>Weekly Flow: <strong className="text-cyan-400">{symbol || "$"}{purchaseAmounts.reduce((a, b) => a + b, 0).toLocaleString()}</strong></span>
                      )}
                    </div>
                  </div>
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 self-start">
                    7 Days Live
                  </span>
                </div>

                {/* 3 Metric Columns with count-up */}
                <div className="grid grid-cols-3 gap-2 my-auto pt-1 pb-3">
                  <div>
                    <span className="text-[9.5px] font-bold text-muted-foreground uppercase tracking-wider block mb-0.5">
                      TOTAL PURCHASES
                    </span>
                    <div className="text-sm md:text-base font-black text-foreground font-mono leading-tight">
                      {symbol || "$"}<AnimatedNumber value={dashboardData?.totalPurchaseMonth ?? 0} duration={1400} />
                    </div>
                    <span className="text-[9.5px] text-cyan-400 font-semibold block mt-0.5">
                      Current Period
                    </span>
                  </div>

                  <div>
                    <span className="text-[9.5px] font-bold text-muted-foreground uppercase tracking-wider block mb-0.5">
                      SUPPLIER DUE
                    </span>
                    <div className="text-sm md:text-base font-black text-foreground font-mono leading-tight">
                      {symbol || "$"}<AnimatedNumber value={dashboardData?.supplierTotalDue ?? dashboardData?.purchaseDue ?? 0} duration={1400} />
                    </div>
                    <span className="text-[9.5px] text-amber-400 font-semibold block mt-0.5">
                      {dashboardData?.dueBillsCount ?? 0} Bills Payable
                    </span>
                  </div>

                  <div>
                    <span className="text-[9.5px] font-bold text-muted-foreground uppercase tracking-wider block mb-0.5">
                      DAILY RUN-RATE
                    </span>
                    <div className="text-sm md:text-base font-black text-foreground font-mono leading-tight">
                      {symbol || "$"}<AnimatedNumber value={Math.round(purchaseAmounts.reduce((a, b) => a + b, 0) / 7)} duration={1400} />
                    </div>
                    <span className="text-[9.5px] text-muted-foreground block mt-0.5">
                      Avg / Day
                    </span>
                  </div>
                </div>

                {/* Modern Interactive SVG Area & Nodes Chart */}
                <div className="relative w-full h-[90px] mt-1 mb-2 overflow-visible">
                  <svg
                    viewBox={`0 0 ${purchaseChartW} ${purchaseChartH}`}
                    className="w-full h-full overflow-visible"
                    preserveAspectRatio="none"
                  >
                    <defs>
                      <linearGradient id="purchaseCyanGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.36" />
                        <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
                      </linearGradient>
                    </defs>

                    {/* Horizontal faint guideline */}
                    <line
                      x1="18"
                      y1={purchaseBaseY}
                      x2={purchaseChartW - 18}
                      y2={purchaseBaseY}
                      stroke="currentColor"
                      className="text-border/40"
                      strokeWidth="1"
                      strokeDasharray="3 3"
                    />

                    {/* Area fill */}
                    <path
                      d={livePurchaseAreaPath}
                      fill="url(#purchaseCyanGrad)"
                      className="transition-opacity duration-1000 ease-out"
                      style={{ opacity: isLoaded ? 1 : 0 }}
                    />

                    {/* Glowing Cyan Line Path */}
                    <path
                      d={livePurchaseLinePath}
                      fill="none"
                      stroke="#06b6d4"
                      strokeWidth="2.4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      pathLength={1}
                      strokeDasharray={1}
                      strokeDashoffset={isLoaded ? 0 : 1}
                      style={{
                        transition: "stroke-dashoffset 1.3s cubic-bezier(0.16, 1, 0.3, 1)"
                      }}
                    />

                    {/* Interactive Data Points on line and Day Labels */}
                    {livePurchasePoints.map((pt, i) => (
                      <g key={i} className="cursor-pointer">
                        <circle
                          cx={pt.x}
                          cy={pt.y}
                          r="3"
                          fill="#06b6d4"
                          stroke="#18181b"
                          strokeWidth="1.75"
                          className="transition-transform duration-300 hover:scale-150"
                          style={{
                            transform: isLoaded ? "scale(1)" : "scale(0)",
                            transformOrigin: `${pt.x}px ${pt.y}px`,
                            transitionDelay: `${300 + i * 80}ms`
                          }}
                          onMouseEnter={() => setHoveredPurchaseDay({ day: pt.day, amount: pt.amount })}
                          onMouseLeave={() => setHoveredPurchaseDay(null)}
                        />
                        {/* Day label aligned directly under each node and elevated with proper bottom padding */}
                        <text
                          x={pt.x}
                          y={purchaseBaseY + 19}
                          textAnchor="middle"
                          fontSize="9.5"
                          fontWeight="500"
                          className="fill-muted-foreground font-mono select-none hover:fill-cyan-400 transition-colors"
                          onMouseEnter={() => setHoveredPurchaseDay({ day: pt.day, amount: pt.amount })}
                          onMouseLeave={() => setHoveredPurchaseDay(null)}
                        >
                          {pt.day}
                        </text>
                      </g>
                    ))}
                  </svg>
                </div>
              </div>

            </div>

            {/* FOOTER VERIFIED NOTE */}
            <div className="flex items-center justify-center gap-1.5 text-muted-foreground text-xs pt-3">
              <CheckCircle2 className="w-3.5 h-3.5 text-muted-foreground" />
              <span>All numbers are automatically calculated</span>
            </div>

          </div>
        </main>
      </div>
    </div>
  );
}
