import { Controller, Post, Body, Get, Put, Delete, Param, Query, ForbiddenException, UseInterceptors, UploadedFile, BadRequestException } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { getImageUploadOptions } from '../../common/utils/upload.util';
import { BranchesService } from './branches.service';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';
import { ApiBody, ApiResponse } from '@nestjs/swagger';
import { CreateBranchBodySchema, UpdateBranchBodySchema, AssignUserBranchBodySchema, BranchResponseSchema } from '../../docs/branches.docs';

@Controller('branches')
export class BranchesController {
  constructor(private readonly branchesService: BranchesService) {}

  @Permissions(Permission.USER_MANAGE)
  @Post('upload-logo')
  @UseInterceptors(FileInterceptor('logo', getImageUploadOptions('branches')))
  async uploadBranchLogo(
    @UploadedFile() file: any,
  ) {
    if (!file) {
      throw new BadRequestException('No logo file provided');
    }
    const logoUrl = `/uploads/branches/${file.filename}`;
    return { logoUrl };
  }

  @Permissions(Permission.USER_MANAGE)
  @Post(':id/upload-logo')
  @UseInterceptors(FileInterceptor('logo', getImageUploadOptions('branches')))
  async uploadBranchLogoForId(
    @Param('id') id: string,
    @UploadedFile() file: any,
  ) {
    if (!file) {
      throw new BadRequestException('No logo file provided');
    }
    const logoUrl = `/uploads/branches/${file.filename}`;
    await this.branchesService.updateBranchLogo(id, logoUrl);
    return { logoUrl };
  }

  @Permissions(Permission.USER_MANAGE)
  @Post()
  @ApiBody({ schema: CreateBranchBodySchema })
  @ApiResponse({ status: 201, description: 'Branch created successfully', schema: BranchResponseSchema })
  async createBranch(
    @Body() body: {
      name: string;
      code?: string;
      logo?: string;
      type?: string;
      isMainBranch?: boolean;
      managerName?: string;
      phone?: string;
      alternatePhone?: string;
      email?: string;
      address?: string;
      city?: string;
      state?: string;
      postalCode?: string;
      taxNumber?: string;
      allowPosSales?: boolean;
      businessId: string;
      createdById?: string;
    },
  ) {
    return this.branchesService.createBranch(body);
  }

  @Get()
  async getBranches(
    @Query('businessId') businessId?: string,
    @Query('userId') userId?: string,
  ) {
    if (!businessId) {
      return [];
    }
    if (userId) {
      return this.branchesService.getUserBranches(userId, businessId);
    }
    return this.branchesService.getBranches(businessId);
  }

  @Get('users/:userId')
  async getUserBranches(
    @Param('userId') userId: string,
    @Query('businessId') businessId?: string,
  ) {
    if (!businessId) {
      return [];
    }
    return this.branchesService.getUserBranches(userId, businessId);
  }

  @Get(':id')
  async getBranchById(
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    if (!businessId) {
      throw new ForbiddenException('Business ID is required.');
    }
    return this.branchesService.getBranchById(id, businessId);
  }

  @Permissions(Permission.USER_MANAGE)
  @Put(':id')
  @ApiBody({ schema: UpdateBranchBodySchema })
  @ApiResponse({ status: 200, description: 'Branch updated successfully', schema: BranchResponseSchema })
  async updateBranch(
    @Param('id') id: string,
    @Body() body: {
      name?: string;
      code?: string;
      logo?: string;
      type?: string;
      isMainBranch?: boolean;
      managerName?: string;
      phone?: string;
      alternatePhone?: string;
      email?: string;
      address?: string;
      city?: string;
      state?: string;
      postalCode?: string;
      taxNumber?: string;
      allowPosSales?: boolean;
      isActive?: boolean;
      businessId: string;
      updatedById?: string;
    },
  ) {
    const { businessId, ...data } = body;
    return this.branchesService.updateBranch(id, businessId, data);
  }

  @Permissions(Permission.USER_MANAGE)
  @Delete(':id')
  async deleteBranch(
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    if (!businessId) {
      throw new ForbiddenException('Business ID is required.');
    }
    return this.branchesService.deleteBranch(id, businessId);
  }

  @Permissions(Permission.USER_MANAGE)
  @Post('users')
  @ApiBody({ schema: AssignUserBranchBodySchema })
  @ApiResponse({ status: 201, description: 'User assigned to branch successfully' })
  async assignUserToBranch(
    @Body() body: { userId: string; branchId: string; businessId: string },
  ) {
    return this.branchesService.assignUserToBranch(body.userId, body.branchId, body.businessId);
  }

  @Permissions(Permission.USER_MANAGE)
  @Delete('users/:userId/:branchId')
  async removeUserFromBranch(
    @Param('userId') userId: string,
    @Param('branchId') branchId: string,
    @Query('businessId') businessId?: string,
  ) {
    if (!businessId) {
      throw new ForbiddenException('Business ID is required.');
    }
    return this.branchesService.removeUserFromBranch(userId, branchId, businessId);
  }
}

