import { useQuery, useMutation, useQueryClient, keepPreviousData } from "@tanstack/react-query";
import { brandService } from "@/services/brand-service";
import { branchService } from "@/services/branch-service";
import { queryKeys } from "@/lib/query-keys";
import { BrandItem } from "../types";

export function useBrandsQuery(
  businessId: string,
  options: {
    branchId?: string;
    page?: number;
    limit?: number;
    search?: string;
  } = {}
) {
  return useQuery({
    queryKey: queryKeys.brands.list(
      businessId,
      options.branchId,
      options.page,
      options.limit,
      options.search
    ),
    queryFn: () => brandService.getBrands(businessId, options),
    enabled: !!businessId,
    placeholderData: keepPreviousData,
  });
}

export function useBranchesQuery(businessId: string, userId?: string) {
  return useQuery({
    queryKey: queryKeys.branches.list(businessId, userId),
    queryFn: () => branchService.getBranches(businessId, userId),
    enabled: !!businessId,
  });
}

export function useCreateBrandMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (brandData: Parameters<typeof brandService.createBrand>[0]) =>
      brandService.createBrand(brandData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.brands.all });
    },
  });
}

export function useUpdateBrandMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, brandData }: { id: string; brandData: Parameters<typeof brandService.updateBrand>[1] }) =>
      brandService.updateBrand(id, brandData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.brands.all });
    },
  });
}

export function useDeleteBrandMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, businessId }: { id: string; businessId: string }) =>
      brandService.deleteBrand(id, businessId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.brands.all });
    },
  });
}
