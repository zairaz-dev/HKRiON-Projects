"use client";

import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";
import { useState, useEffect } from "react";
import { 
  LayoutDashboard, 
  Users, 
  Briefcase, 
  CalendarClock, 
  CalendarOff, 
  ChevronLeft, 
  ChevronRight, 
  ClipboardCheck, 
  Menu, 
  X, 
  BarChart3, 
  Settings, 
  ChevronDown, 
  User, 
  KeyRound,
  Sparkles,
  Plus,
  Building2,
  Shield,
  Clock,
  LogOut,
  Banknote
} from "lucide-react";
import { Tooltip } from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export type NavItem = {
  label: string;
  href: string;
  icon: React.ReactNode;
  badge?: string | number;
  badgeVariant?: "default" | "secondary" | "success" | "warning" | "error";
  subItems?: { label: string; href: string; icon: React.ReactNode; }[];
};

export type NavSection = {
  title: string;
  items: NavItem[];
};

const navSections: NavSection[] = [
  {
    title: "Workspace",
    items: [
      { 
        label: "Dashboard", 
        href: "/dashboard", 
        icon: <LayoutDashboard className="h-5 w-5" /> 
      },
      { 
        label: "Tasks", 
        href: "/dashboard/tasks", 
        icon: <ClipboardCheck className="h-5 w-5" />
      },
      { 
        label: "Manager View", 
        href: "/dashboard/manager", 
        icon: <BarChart3 className="h-5 w-5" />
      },
      { 
        label: "My Salary", 
        href: "/dashboard/my-salary", 
        icon: <Banknote className="h-5 w-5" />
      },
    ]
  },
  {
    title: "Organization",
    items: [
      { 
        label: "Employees", 
        href: "/dashboard/employees", 
        icon: <Users className="h-5 w-5" /> 
      },
      { 
        label: "Positions", 
        href: "/dashboard/positions", 
        icon: <Briefcase className="h-5 w-5" /> 
      },
      { 
        label: "Payroll", 
        href: "/dashboard/payroll", 
        icon: <Banknote className="h-5 w-5" /> 
      },
    ]
  },
  {
    title: "Time & Schedule",
    items: [
      { 
        label: "Attendance", 
        href: "/dashboard/attendance", 
        icon: <CalendarClock className="h-5 w-5" /> 
      },
      { 
        label: "Leaves & Time Off", 
        href: "/dashboard/leaves", 
        icon: <CalendarOff className="h-5 w-5" /> 
      },
    ]
  }
];

interface SidebarProps {
  role?: string;
}

export default function Sidebar({ role }: SidebarProps) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [expandedMenus, setExpandedMenus] = useState<Record<string, boolean>>({});

  const toggleMenu = (label: string) => {
    setExpandedMenus(prev => ({
      ...prev,
      [label]: !prev[label]
    }));
  };

  // Close mobile sidebar on route change
  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  // Listen for mobile sidebar toggle event from Topbar
  useEffect(() => {
    const handleToggle = () => setMobileOpen(prev => !prev);
    window.addEventListener("toggle-mobile-sidebar", handleToggle);
    return () => window.removeEventListener("toggle-mobile-sidebar", handleToggle);
  }, []);

  // Filter sections based on user role
  const filteredSections = navSections.map(section => ({
    ...section,
    items: section.items.filter(item => {
      if (role === "EMPLOYEE" && ["Employees", "Positions", "Manager View", "Payroll"].includes(item.label)) {
        return false;
      }
      return true;
    }).map(item => {
      if (item.href === "/dashboard/tasks") {
        return {
          ...item,
          label: role === "EMPLOYEE" ? "My Tasks" : "Task Management"
        };
      }
      return item;
    })
  })).filter(section => section.items.length > 0);

  return (
    <>
      {/* Mobile Drawer Overlay */}
      {mobileOpen && (
        <div 
          className="md:hidden fixed inset-0 z-50 bg-black/60 backdrop-blur-xs transition-opacity duration-300"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={cn(
          "fixed md:relative inset-y-0 left-0 z-50 flex flex-col border-r border-border bg-surface select-none transition-all duration-300 ease-in-out shadow-xs",
          collapsed ? "md:w-[76px]" : "md:w-[270px]",
          mobileOpen ? "translate-x-0 w-[280px]" : "-translate-x-full md:translate-x-0"
        )}
      >
        {/* Brand Header */}
        <div className="flex h-16 shrink-0 items-center justify-between border-b border-border px-4.5">
          <Link 
            href="/dashboard" 
            className="flex items-center gap-3.5 group min-w-0"
          >
            {/* Sleek App Icon */}
            <div className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary text-white shadow-md shadow-primary/25 group-hover:scale-105 transition-transform">
              <span className="font-extrabold text-base tracking-wider">H</span>
            </div>

            {/* Brand Title */}
            <div className={cn(
              "flex flex-col min-w-0 transition-opacity duration-200",
              collapsed ? "md:hidden" : "block"
            )}>
              <div className="flex items-center gap-2">
                <span className="text-base font-extrabold tracking-tight text-text-primary">
                  HKRiON
                </span>
                <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-primary-soft text-primary">
                  HRM
                </span>
              </div>
              <span className="text-xs text-text-muted font-medium truncate">
                Enterprise Cloud
              </span>
            </div>
          </Link>

          {/* Close button on mobile */}
          <button 
            onClick={() => setMobileOpen(false)}
            className="md:hidden p-2 rounded-lg text-text-secondary hover:text-text-primary hover:bg-surface-secondary transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Navigation Sections */}
        <nav className="flex-1 overflow-y-auto py-5 px-3.5 space-y-6 custom-scrollbar">
          {filteredSections.map((section, idx) => (
            <div key={idx} className="space-y-1.5">
              
              {/* Section Header */}
              {!collapsed && (
                <div className="px-3 mb-2 text-xs font-bold uppercase tracking-wider text-text-muted">
                  {section.title}
                </div>
              )}
              {collapsed && (
                <div className="h-px w-8 bg-border mx-auto my-3 opacity-60" />
              )}

              {/* Items in Section */}
              {section.items.map((item) => {
                const isActive =
                  item.href === "/dashboard"
                    ? pathname === "/dashboard"
                    : pathname.startsWith(item.href);
                
                const hasSubItems = item.subItems && item.subItems.length > 0;
                const isExpanded = expandedMenus[item.label];

                const navElement = hasSubItems ? (
                  <button
                    type="button"
                    onClick={() => {
                      if (collapsed) setCollapsed(false);
                      toggleMenu(item.label);
                    }}
                    className={cn(
                      "w-full group relative flex items-center justify-between rounded-xl px-3 py-2.5 text-sm font-medium transition-all duration-150 cursor-pointer",
                      isActive && !isExpanded
                        ? "bg-primary-soft text-primary font-semibold shadow-2xs"
                        : "text-text-secondary hover:bg-surface-secondary hover:text-text-primary"
                    )}
                  >
                    <div className="flex items-center gap-3.5 min-w-0">
                      <span className={cn(
                        "shrink-0 transition-colors",
                        isActive ? "text-primary" : "text-text-secondary group-hover:text-text-primary"
                      )}>
                        {item.icon}
                      </span>
                      <span className={cn(
                        "truncate whitespace-nowrap text-sm transition-opacity duration-200",
                        collapsed ? "md:hidden" : "block"
                      )}>
                        {item.label}
                      </span>
                    </div>

                    <div className={cn(
                      "transition-opacity duration-200 shrink-0",
                      collapsed ? "md:hidden" : "block"
                    )}>
                      <ChevronDown className={cn(
                        "h-4 w-4 text-text-muted transition-transform duration-200",
                        isExpanded ? "rotate-180 text-text-primary" : ""
                      )} />
                    </div>
                  </button>
                ) : (
                  <Link
                    href={item.href}
                    className={cn(
                      "group relative flex items-center justify-between rounded-xl px-3 py-2.5 text-sm font-medium transition-all duration-150",
                      isActive
                        ? "bg-primary-soft text-primary font-semibold shadow-2xs before:absolute before:left-0 before:top-2 before:bottom-2 before:w-1 before:rounded-r before:bg-primary"
                        : "text-text-secondary hover:bg-surface-secondary hover:text-text-primary"
                    )}
                  >
                    <div className="flex items-center gap-3.5 min-w-0">
                      <span className={cn(
                        "shrink-0 transition-colors",
                        isActive ? "text-primary" : "text-text-secondary group-hover:text-text-primary"
                      )}>
                        {item.icon}
                      </span>

                      <span className={cn(
                        "truncate whitespace-nowrap text-sm transition-opacity duration-200",
                        collapsed ? "md:hidden" : "block"
                      )}>
                        {item.label}
                      </span>
                    </div>

                    {item.badge && !collapsed && (
                      <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-primary text-white shrink-0">
                        {item.badge}
                      </span>
                    )}
                  </Link>
                );

                return (
                  <div key={item.href} className="space-y-1">
                    {collapsed ? (
                      <Tooltip content={item.label} side="right" className="z-50 font-semibold text-xs">
                        {navElement}
                      </Tooltip>
                    ) : (
                      navElement
                    )}

                    {/* Submenu Accordion */}
                    {hasSubItems && isExpanded && !collapsed && (
                      <div className="pl-7 pr-1 space-y-1.5 mt-1.5 border-l-2 border-border/80 ml-5 animate-in slide-in-from-top-1 fade-in duration-150">
                        {item.subItems?.map((sub) => {
                          const currentTab = searchParams.get("tab") || "profile";
                          const isSubActive = sub.href.includes("?") 
                            ? pathname === sub.href.split("?")[0] && sub.href.includes(`tab=${currentTab}`)
                            : pathname === sub.href;

                          return (
                            <Link
                              key={sub.href}
                              href={sub.href}
                              className={cn(
                                "group flex items-center gap-3 rounded-lg px-3 py-2 text-xs font-medium transition-colors",
                                isSubActive
                                  ? "bg-primary-soft text-primary font-semibold"
                                  : "text-text-secondary hover:bg-surface-secondary hover:text-text-primary"
                              )}
                            >
                              <span className={cn(
                                "shrink-0",
                                isSubActive ? "text-primary" : "text-text-muted group-hover:text-text-primary"
                              )}>
                                {sub.icon}
                              </span>
                              <span className="truncate">{sub.label}</span>
                            </Link>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </nav>

        {/* Sidebar Footer: Collapse Toggle */}
        <div className="border-t border-border p-3.5 bg-surface hidden md:block">
          {collapsed ? (
            <Tooltip content="Expand Sidebar" side="right">
              <button
                type="button"
                onClick={() => setCollapsed(false)}
                className="flex w-full items-center justify-center p-2 rounded-xl text-text-secondary hover:bg-surface-secondary hover:text-text-primary transition-colors cursor-pointer"
              >
                <ChevronRight className="h-5 w-5 shrink-0" />
              </button>
            </Tooltip>
          ) : (
            <button
              type="button"
              onClick={() => setCollapsed(true)}
              className="flex w-full items-center justify-between px-3 py-2 rounded-xl text-xs font-medium text-text-secondary hover:bg-surface-secondary hover:text-text-primary transition-colors cursor-pointer"
            >
              <span className="text-xs font-semibold">Collapse Sidebar</span>
              <ChevronLeft className="h-4.5 w-4.5 shrink-0" />
            </button>
          )}
        </div>

      </aside>
    </>
  );
}
