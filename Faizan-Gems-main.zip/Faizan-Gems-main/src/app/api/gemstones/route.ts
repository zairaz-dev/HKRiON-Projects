import { NextResponse } from "next/server";
import { getGemstones, createGemstone } from "@/lib/data/gemstones-db";
import { requireAdmin } from "@/lib/require-admin";

export const dynamic = "force-dynamic";
export const revalidate = 0;

// GET /api/gemstones — Public (storefront product listing)
export async function GET() {
  try {
    const gemstones = await getGemstones();
    return NextResponse.json(gemstones);
  } catch {
    return NextResponse.json({ error: "Failed to fetch gemstones" }, { status: 500 });
  }
}

// POST /api/gemstones — Admin only
export async function POST(request: Request) {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const body = await request.json();
    const success = await createGemstone(body);
    if (!success) {
      return NextResponse.json({ error: "Failed to create gemstone" }, { status: 500 });
    }
    return NextResponse.json({ success: true }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  }
}
