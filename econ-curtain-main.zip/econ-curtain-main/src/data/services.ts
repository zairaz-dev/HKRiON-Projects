import { Ruler, PenTool, Wrench, ShieldCheck } from "lucide-react";

export const services = [
  {
    id: "s1",
    title: "Site Measurement",
    description: "Our experts visit your location to take precise measurements, ensuring a perfect fit for every window covering and outdoor solution.",
    icon: "Ruler"
  },
  {
    id: "s2",
    title: "Custom Design",
    description: "We work closely with you to select the perfect fabrics, colors, and mechanisms that complement your interior or exterior design.",
    icon: "PenTool"
  },
  {
    id: "s3",
    title: "Professional Installation",
    description: "Our certified technicians ensure your products are installed safely, securely, and functioning perfectly with minimal disruption to your space.",
    icon: "Wrench"
  },
  {
    id: "s4",
    title: "Maintenance Support",
    description: "We offer comprehensive after-sales support, including cleaning advice, repairs, and preventative maintenance for long-lasting performance.",
    icon: "ShieldCheck"
  }
];
