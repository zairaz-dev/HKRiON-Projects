"use client";

import React from "react";
import Link from "next/link";
import Image from "next/image";
import { useCMS } from "@/features/cms/useCMS";
import { SITE_CONFIG } from "@/lib/constants/site";
import {
  CertificateShieldIcon,
  ArmoredTruckIcon,
  AwardIcon
} from "@/components/ui/LuxuryIcons";

export function Footer() {
  const { getBlock } = useCMS();

  const footerLogo = getBlock("branding.footer_logo", SITE_CONFIG.branding.footerLogo);
  const showroomAddress = getBlock("contact.address", SITE_CONFIG.showroom.address);
  const contactEmail = getBlock("contact.email", SITE_CONFIG.contact.email);
  const contactPhone = getBlock("contact.phone", SITE_CONFIG.contact.phone);
  const contactSecondaryPhone = getBlock("contact.secondary_phone", SITE_CONFIG.contact.secondaryPhone) || getBlock("contact.landline", SITE_CONFIG.contact.landline);
  const showroomCountry = getBlock("contact.country", SITE_CONFIG.showroom.country);

  return (
    <footer className="bg-black text-[#E7E2D7] border-t border-white/10 font-sans">
      {/* Trust Credentials Bar */}
      <div className="border-b border-white/10 py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-white/[0.04] border border-[#C5A880]/30 text-[#C5A880] flex items-center justify-center flex-shrink-0">
              <CertificateShieldIcon className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-serif text-sm uppercase tracking-wider text-white">100% Certified Natural</h4>
              <p className="text-xs text-[#8C867D] mt-1 leading-relaxed">
                Every stone is tested and verified 100% genuine by top gem labs.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-white/[0.04] border border-[#C5A880]/30 text-[#C5A880] flex items-center justify-center flex-shrink-0">
              <ArmoredTruckIcon className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-serif text-sm uppercase tracking-wider text-white">Safe &amp; Insured Delivery</h4>
              <p className="text-xs text-[#8C867D] mt-1 leading-relaxed">
                Delivered safely to your door with full insurance on every shipment.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-white/[0.04] border border-[#C5A880]/30 text-[#C5A880] flex items-center justify-center flex-shrink-0">
              <AwardIcon className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-serif text-sm uppercase tracking-wider text-white">Expert Gemstone Advice</h4>
              <p className="text-xs text-[#8C867D] mt-1 leading-relaxed">
                Talk to our friendly gem experts anytime to help you choose the right stone.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links & Editorial Story */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <Link href="/" className="inline-block transition-opacity hover:opacity-85">
              <Image
                src={footerLogo}
                alt="Faizan Gems - Shine With Elegance"
                width={220}
                height={55}
                className="h-11 w-auto object-contain"
                unoptimized
              />
            </Link>
            <span className="text-[10px] font-sans tracking-wide-luxury uppercase text-[#C5A880] block">
              Natural Gemstones • Ethically Sourced
            </span>
            <p className="text-xs text-[#8C867D] leading-relaxed max-w-sm">
              We source, certify, and deliver the world&apos;s finest natural gemstones. From the gem mines of Sri Lanka to you — 100% natural and untreated.
            </p>
          </div>

          {/* Nav Col 1 */}
          <div>
            <h5 className="font-serif text-sm uppercase tracking-wider text-white mb-4">Shop Gemstones</h5>
            <ul className="space-y-2.5 text-xs text-[#8C867D]">
              <li><Link href="/shop" className="hover:text-[#C5A880] transition-colors">All Rare Gemstones</Link></li>
              <li><Link href="/shop?type=Sapphire" className="hover:text-[#C5A880] transition-colors">Ceylon Sapphires</Link></li>
              <li><Link href="/shop?type=Ruby" className="hover:text-[#C5A880] transition-colors">Burmese & African Rubies</Link></li>
              <li><Link href="/shop?type=Emerald" className="hover:text-[#C5A880] transition-colors">Muzo Colombian Emeralds</Link></li>
              <li><Link href="/shop?type=Padparadscha" className="hover:text-[#C5A880] transition-colors">Padparadscha Sapphires</Link></li>
              <li><Link href="/shop?type=Alexandrite" className="hover:text-[#C5A880] transition-colors">Color-Change Alexandrite</Link></li>
              <li><Link href="/collections" className="text-[#C5A880] hover:underline">Premium Collection &rarr;</Link></li>
            </ul>
          </div>

          {/* Nav Col 2 */}
          <div>
            <h5 className="font-serif text-sm uppercase tracking-wider text-white mb-4">About &amp; Services</h5>
            <ul className="space-y-2.5 text-xs text-[#8C867D]">
              <li><Link href="/" className="hover:text-[#C5A880] transition-colors">Home</Link></li>
              <li><Link href="/about" className="hover:text-[#C5A880] transition-colors">Our Story &amp; Heritage</Link></li>
              <li><Link href="/collections" className="hover:text-[#C5A880] transition-colors">Featured Collections</Link></li>
              <li><Link href="/shipping-returns" className="hover:text-[#C5A880] transition-colors">Insured Global Delivery</Link></li>
              <li><Link href="/faq" className="hover:text-[#C5A880] transition-colors">Client FAQ &amp; Security</Link></li>
            </ul>
          </div>

          {/* Nav Col 3: Showroom & Contact */}
          <div>
            <h5 className="font-serif text-sm uppercase tracking-wider text-white mb-4">Showroom & Contact</h5>
            <div className="space-y-3 text-xs text-[#8C867D]">
              {showroomAddress && (
                <div>
                  <span className="text-white block font-medium">Trincomalee Showroom</span>
                  <span className="text-[11px] block">{showroomAddress}</span>
                  {showroomCountry && <span className="text-[11px] block text-[#8C867D]">{showroomCountry}</span>}
                </div>
              )}
              {contactEmail && (
                <div>
                  <span className="text-white block font-medium">Contact Us</span>
                  <a href={`mailto:${contactEmail}`} className="text-[11px] hover:text-[#C5A880] transition-colors">
                    {contactEmail}
                  </a>
                </div>
              )}
              {(contactPhone || contactSecondaryPhone) && (
                <div>
                  <span className="text-white block font-medium">Phone Number &amp; WhatsApp</span>
                  {contactPhone && (
                    <a href={`tel:${contactPhone.replace(/\s+/g, "")}`} className="text-[11px] hover:text-[#C5A880] transition-colors block">
                      {contactPhone}
                    </a>
                  )}
                  {contactSecondaryPhone && (
                    <a href={`tel:${contactSecondaryPhone.replace(/\s+/g, "")}`} className="text-[11px] hover:text-[#C5A880] transition-colors block mt-0.5">
                      {contactSecondaryPhone}
                    </a>
                  )}
                </div>
              )}
              <div className="pt-2">
                <Link
                  href="/contact"
                  className="inline-block text-[11px] font-sans uppercase tracking-widest text-[#C5A880] border-b border-[#C5A880] pb-0.5"
                >
                  Contact Us &rarr;
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-16 pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-[#8C867D]">
          <div className="text-center md:text-left">
            &copy; {new Date().getFullYear()} Faizan Gems (Pvt) Ltd. All rights reserved.
          </div>

          {/* Agency Attribution */}
          <div className="text-[11px] font-sans tracking-wide text-[#8C867D] text-center">
            Design &amp; Technology by{" "}
            <a
              href="https://hkrion.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#D3CBBF] hover:text-[#C5A880] transition-colors font-medium underline underline-offset-4 decoration-[#C5A880]/30 hover:decoration-[#C5A880]"
            >
              HKRiON
            </a>
          </div>

          <div className="flex flex-wrap items-center justify-center md:justify-end gap-6 text-[11px]">
            <Link href="/faq" className="hover:text-white transition-colors">Security & FAQ</Link>
            <Link href="/shipping-returns" className="hover:text-white transition-colors">Insured Shipping & Returns</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
