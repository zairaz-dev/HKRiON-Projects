"use client";

import { format } from "date-fns";
import { Banknote, FileText, Download, CalendarClock } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/ui/page-header";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";


type Compensation = {
  baseSalary: any;
  currency: string;
  effectiveDate: Date;
} | null;

type Payslip = {
  id: number;
  month: number;
  year: number;
  basicPay: number;
  allowances: number;
  deductions: number;
  netPay: number;
  status: string;
  paidAt: Date | null;
};

type MySalaryClientProps = {
  compensation: Compensation;
  payslips: Payslip[];
};

const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export default function MySalaryClient({ compensation, payslips }: MySalaryClientProps) {
  
  const formattedSalary = compensation 
    ? new Intl.NumberFormat('en-LK', { style: 'currency', currency: compensation.currency }).format(Number(compensation.baseSalary))
    : "Not Set";

  const handleDownloadPdf = (payslip: Payslip) => {
    const currency = compensation?.currency || "LKR";
    const formatter = new Intl.NumberFormat('en-LK', { style: 'currency', currency });
    
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Payslip - ${monthNames[payslip.month - 1]} ${payslip.year}</title>
          <style>
            body { font-family: system-ui, -apple-system, sans-serif; padding: 40px; color: #333; max-width: 800px; margin: 0 auto; }
            .header { text-align: center; margin-bottom: 40px; border-bottom: 2px solid #eee; padding-bottom: 20px; }
            h1 { margin: 0 0 10px 0; color: #111; }
            .details { display: flex; justify-content: space-between; margin-bottom: 40px; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
            th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
            th { background-color: #f9f9f9; font-weight: 600; color: #555; }
            .amount { text-align: right; }
            .total-row { font-weight: bold; font-size: 1.1em; background-color: #f5f5f5; }
            .footer { text-align: center; margin-top: 50px; font-size: 0.9em; color: #777; border-top: 1px solid #eee; padding-top: 20px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Payslip</h1>
            <div>${monthNames[payslip.month - 1]} ${payslip.year}</div>
          </div>
          
          <div class="details">
            <div>
              <strong>Status:</strong> ${payslip.status}<br>
              <strong>Paid Date:</strong> ${payslip.paidAt ? format(new Date(payslip.paidAt), "MMM dd, yyyy") : "N/A"}
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>Description</th>
                <th class="amount">Amount</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Basic Pay</td>
                <td class="amount">${formatter.format(payslip.basicPay)}</td>
              </tr>
              <tr>
                <td>Allowances</td>
                <td class="amount">${formatter.format(payslip.allowances)}</td>
              </tr>
              <tr>
                <td>Deductions</td>
                <td class="amount">-${formatter.format(payslip.deductions)}</td>
              </tr>
              <tr class="total-row">
                <td>Net Pay</td>
                <td class="amount">${formatter.format(payslip.netPay)}</td>
              </tr>
            </tbody>
          </table>
          
          <div class="footer">
            Generated on ${format(new Date(), "MMM dd, yyyy HH:mm")}
          </div>
          
          <script>
            window.onload = function() { window.print(); window.close(); }
          </script>
        </body>
      </html>
    `;
    
    printWindow.document.open();
    printWindow.document.write(html);
    printWindow.document.close();
  };


  return (
    <div className="space-y-6">
      <PageHeader 
        title="My Salary & Payslips"
        description="View your current compensation and download monthly payslips."
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Current Compensation Card */}
        <Card className="p-6 border-border bg-surface shadow-xs">
          <h3 className="text-sm font-semibold text-text-secondary uppercase tracking-wider mb-2">Current Base Salary</h3>
          <div className="text-4xl font-bold font-mono tracking-tight text-text-primary">
            {formattedSalary}
            {compensation && <span className="text-sm font-sans font-normal text-text-muted ml-1">/mo</span>}
          </div>
          {compensation && (
            <p className="text-xs text-text-muted mt-3">
              Effective since {format(new Date(compensation.effectiveDate), "MMMM dd, yyyy")}
            </p>
          )}
        </Card>
      </div>

      <div>
        <h3 className="text-lg font-bold text-text-primary mb-4 flex items-center gap-2">
          <FileText className="h-5 w-5 text-text-muted" />
          Payslip History
        </h3>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Pay Period</TableHead>
              <TableHead>Net Pay</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Paid At</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
                {payslips.length ? (
                  payslips.map((payslip) => (
                    <TableRow key={payslip.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <CalendarClock className="h-4 w-4 text-text-muted" />
                          <span className="font-semibold text-sm text-text-primary">
                            {monthNames[payslip.month - 1]} {payslip.year}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="font-mono font-medium text-text-primary">
                          {compensation ? new Intl.NumberFormat('en-LK', { style: 'currency', currency: compensation.currency }).format(Number(payslip.netPay)) : payslip.netPay.toString()}
                        </span>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant={payslip.status === "PAID" ? "default" : payslip.status === "DRAFT" ? "outline" : "warning"}
                          className="text-xs"
                        >
                          {payslip.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <span className="text-xs text-text-secondary">
                          {payslip.paidAt ? format(new Date(payslip.paidAt), "MMM dd, yyyy") : "—"}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end">
                          <button 
                            onClick={() => handleDownloadPdf(payslip)}
                            className="flex items-center gap-1.5 text-xs font-semibold text-primary hover:text-primary-dark transition-all duration-300 cursor-pointer p-2 rounded hover:bg-surface border border-transparent hover:border-primary/50 shadow-none hover:shadow-sm"
                          >
                            <Download className="h-3.5 w-3.5" />
                            <span>Download PDF</span>
                          </button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="h-24 text-center">
                      No payslips found.
                    </TableCell>
                  </TableRow>
                )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
