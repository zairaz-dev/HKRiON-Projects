import {
  Controller,
  Post,
  Body,
  Get,
  Put,
  Delete,
  Param,
  Query,
  UseGuards,
  Req,
} from '@nestjs/common';
import { UnitsService } from './units.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';
import {
  ApiTags,
  ApiOperation,
  ApiBody,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiQuery,
} from '@nestjs/swagger';
import { CreateUnitDto } from './dto/create-unit.dto';
import { UpdateUnitDto } from './dto/update-unit.dto';

@ApiTags('Units')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('units')
export class UnitsController {
  constructor(private readonly unitsService: UnitsService) {}

  @Permissions(Permission.PRODUCT_CREATE)
  @Post()
  @ApiOperation({ summary: 'Create measurement unit' })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        name: { type: 'string', minLength: 2, maxLength: 100, example: 'Box' },
        code: { type: 'string', minLength: 1, maxLength: 20, example: 'BOX' },
        description: { type: 'string', maxLength: 500, example: 'Standard packaging box' },
        isActive: { type: 'boolean', example: true },
        businessId: { type: 'string', example: 'biz_123' },
        branchIds: { type: 'array', items: { type: 'string' }, example: ['branch_01'] },
        parentId: { type: 'string', nullable: true, example: null },
        conversionFactor: { type: 'number', nullable: true, example: 10 },
      },
      required: ['name', 'code', 'businessId'],
    },
  })
  @ApiResponse({ status: 201, description: 'Unit created successfully' })
  async createUnit(
    @Req() req: any,
    @Body() body: CreateUnitDto,
  ) {
    const user = req.user;
    if (user.role !== 'super-admin' || !body.businessId) {
      body.businessId = user.businessId;
    }
    if (!body.createdById) {
      body.createdById = user.id;
    }
    return this.unitsService.createUnit(body as any);
  }

  @Permissions(Permission.PRODUCT_VIEW)
  @Get()
  @ApiOperation({ summary: 'Get list of units' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiQuery({ name: 'branchId', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Units retrieved successfully' })
  async getUnits(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.unitsService.getUnits(bId, branchId);
  }

  @Permissions(Permission.PRODUCT_VIEW)
  @Get(':id')
  @ApiOperation({ summary: 'Get unit details by ID' })
  @ApiParam({ name: 'id', description: 'Unit UUID' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Unit details retrieved successfully' })
  async getUnitById(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.unitsService.getUnitById(id, bId);
  }

  @Permissions(Permission.PRODUCT_UPDATE)
  @Put(':id')
  @ApiOperation({ summary: 'Update measurement unit' })
  @ApiParam({ name: 'id', description: 'Unit UUID' })
  @ApiResponse({ status: 200, description: 'Unit updated successfully' })
  async updateUnit(
    @Req() req: any,
    @Param('id') id: string,
    @Body() body: UpdateUnitDto,
  ) {
    const user = req.user;
    let bId = body.businessId;
    if (user.role !== 'super-admin' || !bId) {
      bId = user.businessId;
    }
    if (!body.updatedById) {
      body.updatedById = user.id;
    }
    const { businessId, ...data } = body;
    return this.unitsService.updateUnit(id, bId, data as any);
  }

  @Permissions(Permission.PRODUCT_DELETE)
  @Delete(':id')
  @ApiOperation({ summary: 'Delete unit' })
  @ApiParam({ name: 'id', description: 'Unit UUID' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Unit deleted successfully' })
  async deleteUnit(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.unitsService.deleteUnit(id, bId);
  }
}
