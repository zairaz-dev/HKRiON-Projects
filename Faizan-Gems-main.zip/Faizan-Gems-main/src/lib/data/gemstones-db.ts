import {
  Gemstone,
  GemstoneType,
  GemstoneCut,
  CertificationLab,
  TreatmentType,
  GemstoneVariant,
  Order,
  extractCountryFromOrigin,
  getSpeciesForType
} from "@/types/gemstone";
import { pool } from "@/lib/db";
import { RowDataPacket, ResultSetHeader } from "mysql2";
import { saveCustomerAddress } from "@/lib/data/addresses-db";

interface GemstoneRow extends RowDataPacket {
  id: string;
  sku: string;
  name: string;
  type: string;
  variety: string;
  species: string;
  carat: string | number;
  price: string | number;
  dimensions_length: string | number;
  dimensions_width: string | number;
  dimensions_depth: string | number;
  cut: string;
  cut_detail: string;
  color: string;
  color_grade: string;
  clarity: string;
  origin: string;
  origin_country: string;
  treatment: string;
  is_unheated: number | boolean;
  cert_lab: string;
  cert_report_number: string;
  cert_issue_date: string;
  cert_verification_url: string;
  cert_comments: string;
  images: unknown;
  angles360: unknown;
  variants?: unknown;
  daylight_image: string | null;
  incandescent_image: string | null;
  video: string | null;
  in_stock: number | boolean;
  featured: number | boolean;
  investment_grade: number | boolean;
  rarity_score: number;
  description: string;
  story: string;
  gemologist_notes: string;
}

function parseJson<T>(val: unknown, fallback: T): T {
  if (!val) return fallback;
  if (typeof val === "object") return val as T;
  if (typeof val === "string") {
    try {
      return JSON.parse(val) as T;
    } catch {
      return fallback;
    }
  }
  return fallback;
}

function rowToGemstone(row: GemstoneRow): Gemstone {
  return {
    id: row.id,
    sku: row.sku,
    name: row.name,
    type: row.type as GemstoneType,
    variety: row.variety,
    species: row.species || "Natural Corundum",
    carat: Number(row.carat),
    price: Number(row.price),
    dimensions: (Number(row.dimensions_length || 0) > 0 || Number(row.dimensions_width || 0) > 0)
      ? {
          length: Number(row.dimensions_length || 0),
          width: Number(row.dimensions_width || 0),
          depth: Number(row.dimensions_depth || 0),
        }
      : undefined,
    cut: row.cut as GemstoneCut,
    cutDetail: row.cut_detail || "",
    color: row.color,
    colorGrade: row.color_grade || "",
    clarity: row.clarity,
    origin: row.origin,
    originCountry: row.origin_country || "",
    treatment: row.treatment as TreatmentType,
    isUnheated: Boolean(row.is_unheated),
    certification: {
      lab: (row.cert_lab || "GRS") as CertificationLab,
      reportNumber: row.cert_report_number || "",
      issueDate: row.cert_issue_date || "",
      verificationUrl: row.cert_verification_url || "",
      comments: row.cert_comments || "",
      originConfirmed: true,
      treatmentConfirmed: row.is_unheated ? "Unheated" : "Treated",
      hologramVerified: true,
    },
    images: parseJson<string[]>(row.images, []),
    angles360: parseJson<string[]>(row.angles360, []),
    variants: parseJson<GemstoneVariant[]>(row.variants, []),
    daylightImage: row.daylight_image || undefined,
    incandescentImage: row.incandescent_image || undefined,
    video: row.video || undefined,
    inStock: (() => {
      const parsedVariants = parseJson<GemstoneVariant[]>(row.variants, []);
      const hasVariantStock = parsedVariants.length > 0 && parsedVariants.some((v) => (Number(v.stock) || 0) > 0);
      return Boolean(row.in_stock) || hasVariantStock;
    })(),
    featured: Boolean(row.featured),
    investmentGrade: Boolean(row.investment_grade),
    rarityScore: Number(row.rarity_score) || 90,
    description: row.description || "",
    story: row.story || "",
    gemologistNotes: row.gemologist_notes || "",
  };
}


/**
 * Fetch all gemstones from MySQL
 */
export async function getGemstones(): Promise<Gemstone[]> {
  try {
    const [rows] = await pool.query<GemstoneRow[]>(
      "SELECT * FROM gemstones ORDER BY featured DESC, created_at DESC"
    );

    if (rows && rows.length > 0) {
      return rows.map(rowToGemstone);
    }

    return [];
  } catch (error) {
    console.warn("Failed to fetch gemstones from MySQL:", error);
    return [];
  }
}

/**
 * Fetch single gemstone by ID
 */
export async function getGemstoneById(id: string): Promise<Gemstone | undefined> {
  try {
    const [rows] = await pool.query<GemstoneRow[]>(
      "SELECT * FROM gemstones WHERE id = ? LIMIT 1",
      [id]
    );
    if (rows && rows.length > 0) {
      return rowToGemstone(rows[0]);
    }
    return undefined;
  } catch (error) {
    console.warn(`Failed to fetch gemstone ${id} from MySQL:`, error);
    return undefined;
  }
}

/**
 * Create a new gemstone in MySQL
 */
export async function createGemstone(gem: Partial<Gemstone>): Promise<boolean> {
  try {
    const id = gem.id || `gem-vault-${Date.now()}`;
    const sku = gem.sku || `GEM-VAULT-${Math.floor(1000 + Math.random() * 9000)}`;

    const parsedVariants = gem.variants && Array.isArray(gem.variants) ? gem.variants : [];
    const hasVariantStock = parsedVariants.length > 0 && parsedVariants.some((v) => (Number(v.stock) || 0) > 0);
    const resolvedInStock = gem.inStock !== undefined ? Boolean(gem.inStock) : (hasVariantStock || parsedVariants.length === 0);

    await pool.query(
      `INSERT INTO gemstones (
        id, sku, name, type, variety, species, carat, price,
        dimensions_length, dimensions_width, dimensions_depth,
        cut, cut_detail, color, color_grade, clarity, origin, origin_country,
        treatment, is_unheated, cert_lab, cert_report_number, cert_issue_date,
        cert_verification_url, cert_comments, images, angles360, variants,
        daylight_image, incandescent_image, video, in_stock, featured, investment_grade,
        rarity_score, description, story, gemologist_notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        sku,
        gem.name || "Faizan Gems Curated Specimen",
        gem.type || "Sapphire",
        gem.variety || "Natural Corundum",
        gem.species || getSpeciesForType(gem.type),
        gem.carat || 1.0,
        gem.price || 5000,
        gem.dimensions?.length || 0,
        gem.dimensions?.width || 0,
        gem.dimensions?.depth || 0,
        gem.cut || "Cushion",
        gem.cutDetail || "",
        gem.color || "Blue",
        gem.colorGrade || "",
        gem.clarity || "Eye Clean",
        gem.origin || "Sri Lanka",
        gem.originCountry || extractCountryFromOrigin(gem.origin) || "Sri Lanka",
        gem.treatment || "Unheated / Untreated",
        gem.isUnheated ? 1 : 0,
        gem.certification?.lab || "GRS",
        gem.certification?.reportNumber || "",
        gem.certification?.issueDate || "",
        gem.certification?.verificationUrl || "",
        gem.certification?.comments || "",
        JSON.stringify(gem.images || []),
        JSON.stringify(gem.angles360 || []),
        JSON.stringify(gem.variants || []),
        gem.daylightImage || null,
        gem.incandescentImage || null,
        gem.video || null,
        resolvedInStock ? 1 : 0,
        gem.featured ? 1 : 0,
        gem.investmentGrade ? 1 : 0,
        gem.rarityScore || 90,
        gem.description || "",
        gem.story || "",
        gem.gemologistNotes || "",
      ]
    );
    return true;
  } catch (error) {
    console.error("Error creating gemstone in MySQL:", error);
    return false;
  }
}

/**
 * Update an existing gemstone in MySQL
 */
export async function updateGemstone(id: string, gem: Partial<Gemstone>): Promise<boolean> {
  try {
    const existing = await getGemstoneById(id);
    if (!existing) {
      return false;
    }

    const updatedVariants = gem.variants !== undefined ? gem.variants : existing.variants;
    let resolvedInStock = existing.inStock;
    if (gem.inStock !== undefined) {
      resolvedInStock = Boolean(gem.inStock);
    }
    if (Array.isArray(updatedVariants) && updatedVariants.length > 0) {
      const hasStock = updatedVariants.some((v) => (Number(v.stock) || 0) > 0);
      resolvedInStock = hasStock;
    }

    const updated: Gemstone = {
      ...existing,
      ...gem,
      inStock: resolvedInStock,
      certification: {
        ...existing.certification,
        ...(gem.certification || {}),
      },
      dimensions: gem.dimensions !== undefined ? gem.dimensions : existing.dimensions,
      images: gem.images !== undefined ? gem.images : existing.images,
      angles360: gem.angles360 !== undefined ? gem.angles360 : existing.angles360,
      variants: updatedVariants,
    };

    const [result] = await pool.query<ResultSetHeader>(
      `UPDATE gemstones SET
        name = ?,
        type = ?,
        variety = ?,
        species = ?,
        carat = ?,
        price = ?,
        dimensions_length = ?,
        dimensions_width = ?,
        dimensions_depth = ?,
        cut = ?,
        cut_detail = ?,
        color = ?,
        color_grade = ?,
        clarity = ?,
        origin = ?,
        origin_country = ?,
        treatment = ?,
        is_unheated = ?,
        cert_lab = ?,
        cert_report_number = ?,
        cert_issue_date = ?,
        cert_verification_url = ?,
        cert_comments = ?,
        images = ?,
        angles360 = ?,
        variants = ?,
        daylight_image = ?,
        incandescent_image = ?,
        video = ?,
        in_stock = ?,
        featured = ?,
        investment_grade = ?,
        rarity_score = ?,
        description = ?,
        story = ?,
        gemologist_notes = ?
      WHERE id = ?`,
      [
        updated.name,
        updated.type,
        updated.variety,
        updated.species || getSpeciesForType(updated.type),
        updated.carat,
        updated.price,
        updated.dimensions?.length || 0,
        updated.dimensions?.width || 0,
        updated.dimensions?.depth || 0,
        updated.cut,
        updated.cutDetail || "",
        updated.color,
        updated.colorGrade || "",
        updated.clarity,
        updated.origin,
        updated.originCountry || extractCountryFromOrigin(updated.origin) || "",
        updated.treatment,
        updated.isUnheated ? 1 : 0,
        updated.certification?.lab || "GRS",
        updated.certification?.reportNumber || "",
        updated.certification?.issueDate || "",
        updated.certification?.verificationUrl || "",
        updated.certification?.comments || "",
        JSON.stringify(updated.images || []),
        JSON.stringify(updated.angles360 || []),
        JSON.stringify(updated.variants || []),
        updated.daylightImage || null,
        updated.incandescentImage || null,
        updated.video !== undefined ? (updated.video || null) : (existing.video || null),
        updated.inStock ? 1 : 0,
        updated.featured ? 1 : 0,
        updated.investmentGrade ? 1 : 0,
        updated.rarityScore || 90,
        updated.description || "",
        updated.story || "",
        updated.gemologistNotes || "",
        id,
      ]
    );

    return result.affectedRows > 0;
  } catch (error) {
    console.error("Error updating gemstone in MySQL:", error);
    return false;
  }
}

/**
 * Delete a gemstone from MySQL
 */
export async function deleteGemstone(id: string): Promise<boolean> {
  try {
    const [result] = await pool.query<ResultSetHeader>("DELETE FROM gemstones WHERE id = ?", [id]);
    return result.affectedRows > 0;
  } catch (error) {
    console.error("Error deleting gemstone from MySQL:", error);
    return false;
  }
}

/**
 * Fetch orders from MySQL
 */
export async function getOrders(): Promise<RowDataPacket[]> {
  try {
    const [rows] = await pool.query<RowDataPacket[]>(
      "SELECT * FROM orders ORDER BY created_at DESC"
    );
    return rows;
  } catch (error) {
    console.warn("Failed to fetch orders from MySQL:", error);
    return [];
  }
}

export interface CreateOrderResult {
  success: boolean;
  error?: string;
  orderId?: string;
}

/**
 * Save new order into MySQL with an atomic transaction and pessimistic row locking
 */
export async function createOrder(order: Partial<Order>): Promise<CreateOrderResult> {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const items = order.items && Array.isArray(order.items) ? order.items : [];
    if (items.length === 0) {
      await connection.rollback();
      return { success: false, error: "Shopping bag is empty." };
    }

    // 1. Aggregate requested deductions by gemId + variantId to prevent intra-order double count
    const aggregated = new Map<string, { gemId: string; variantId?: string; totalQty: number; name: string }>();
    for (const item of items as any[]) {
      const gemId = item.gemstone?.id || item.id;
      if (!gemId) continue;
      const variantId = item.selectedVariant?.id || "default";
      const key = `${gemId}::${variantId}`;
      const qty = Math.max(1, Number(item.quantity) || 1);
      const existing = aggregated.get(key);
      if (existing) {
        existing.totalQty += qty;
      } else {
        aggregated.set(key, {
          gemId,
          variantId: item.selectedVariant?.id,
          totalQty: qty,
          name: item.gemstone?.name || item.name || "Gemstone",
        });
      }
    }

    // 2. Lock and verify stock for each item, then decrement in the same transaction
    for (const entry of aggregated.values()) {
      const [rows] = await connection.query<RowDataPacket[]>(
        "SELECT id, name, in_stock, variants FROM gemstones WHERE id = ? FOR UPDATE",
        [entry.gemId]
      );

      if (!rows || rows.length === 0) {
        await connection.rollback();
        return { success: false, error: `Specimen "${entry.name}" is no longer available in the vault.` };
      }

      const row = rows[0];
      const variants = parseJson<GemstoneVariant[]>(row.variants, []);

      if (variants && variants.length > 0) {
        let targetIndex = entry.variantId
          ? variants.findIndex((v) => v.id === entry.variantId)
          : 0;
        if (targetIndex === -1) targetIndex = 0;

        const currentStock = Math.max(0, Number(variants[targetIndex].stock) || 0);
        if (currentStock < entry.totalQty) {
          await connection.rollback();
          return {
            success: false,
            error: `Insufficient stock for "${entry.name}". Requested ${entry.totalQty}, but only ${currentStock} available.`,
          };
        }

        variants[targetIndex].stock = currentStock - entry.totalQty;
        const hasStockLeft = variants.some((v) => (Number(v.stock) || 0) > 0);
        const newInStock = hasStockLeft ? 1 : 0;

        await connection.query(
          "UPDATE gemstones SET variants = ?, in_stock = ?, updated_at = NOW(3) WHERE id = ?",
          [JSON.stringify(variants), newInStock, entry.gemId]
        );
      } else {
        // Unique single natural specimen (1-of-1)
        if (!row.in_stock) {
          await connection.rollback();
          return {
            success: false,
            error: `Unique natural specimen "${entry.name}" was just reserved by another collector.`,
          };
        }

        await connection.query(
          "UPDATE gemstones SET in_stock = 0, updated_at = NOW(3) WHERE id = ?",
          [entry.gemId]
        );
      }
    }

    // 3. Insert the order into orders table within the transaction
    const id = order.id || `ORD-MA-${Math.floor(100000 + Math.random() * 900000)}`;
    await connection.query(
      `INSERT INTO orders (
        id, order_number, client_name, client_email, client_phone, client_id,
        shipping_address, city, state, postal_code, country, courier,
        items, subtotal, total, currency,
        payment_method, status, tracking_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        order.orderNumber || id,
        order.client?.fullName || "Valued Client",
        order.client?.email || "",
        order.client?.phone || "",
        order.client?.clientId || null,
        order.shippingAddress?.address || "",
        order.shippingAddress?.city || "",
        order.shippingAddress?.state || "",
        order.shippingAddress?.postalCode || "",
        order.shippingAddress?.country || "Sri Lanka",
        order.courier || "Armored Air Courier",
        JSON.stringify(order.items || []),
        order.subtotal || 0,
        order.total || 0,
        order.currency || "USD",
        order.paymentMethod || "wire",
        order.status || "pending_verification",
        order.trackingNumber || null,
      ]
    );

    await connection.commit();

    // 4. Automatically save customer address if provided (post-commit)
    if (order.client?.email && order.shippingAddress?.address) {
      try {
        await saveCustomerAddress({
          userId: order.client?.clientId || order.client.email,
          userEmail: order.client.email,
          fullName: order.client?.fullName || "",
          phone: order.client?.phone || "",
          address: order.shippingAddress.address,
          city: order.shippingAddress.city || "",
          district: order.shippingAddress.state || "",
          postalCode: order.shippingAddress.postalCode || "",
          country: order.shippingAddress.country || "Sri Lanka",
        });
      } catch (err) {
        console.error("Non-fatal: failed to auto-save customer address:", err);
      }
    }

    return { success: true, orderId: id };
  } catch (error: any) {
    await connection.rollback();
    console.error("Error creating order in MySQL transaction:", error);
    return { success: false, error: error?.message || "Failed to persist order in database." };
  } finally {
    connection.release();
  }
}

/**
 * Validate that all ordered items exist and have sufficient stock
 */
export async function validateOrderStock(
  items: any[]
): Promise<{ valid: boolean; error?: string }> {
  if (!items || !Array.isArray(items) || items.length === 0) {
    return { valid: false, error: "Your shopping bag is empty." };
  }

  try {
    // 1. Pre-aggregate requested quantities by specimen and variant to prevent multi-item oversell
    const demands = new Map<
      string,
      { gemId: string; variantId?: string; totalQuantity: number; name: string }
    >();

    for (const item of items) {
      const gemId = item.gemstone?.id || item.id;
      if (!gemId) continue;
      const variantId = item.selectedVariant?.id || "default";
      const key = `${gemId}::${variantId}`;
      const qty = Math.max(1, Number(item.quantity) || 1);

      const existing = demands.get(key);
      if (existing) {
        existing.totalQuantity += qty;
      } else {
        demands.set(key, {
          gemId,
          variantId: item.selectedVariant?.id,
          totalQuantity: qty,
          name: item.gemstone?.name || item.name || gemId,
        });
      }
    }

    // 2. Validate each aggregated demand against authoritative database stock
    for (const demand of demands.values()) {
      const [rows] = await pool.query<RowDataPacket[]>(
        "SELECT id, name, in_stock, variants FROM gemstones WHERE id = ? LIMIT 1",
        [demand.gemId]
      );

      if (!rows || rows.length === 0) {
        return {
          valid: false,
          error: `Specimen "${demand.name}" is not available in our vault.`,
        };
      }

      const row = rows[0];
      const inStock = Boolean(row.in_stock);
      if (!inStock) {
        return {
          valid: false,
          error: `"${row.name}" is currently out of stock.`,
        };
      }

      const variants = parseJson<GemstoneVariant[]>(row.variants, []);

      if (variants && variants.length > 0) {
        const matchedVariant = demand.variantId
          ? variants.find((v) => v.id === demand.variantId) || variants[0]
          : variants[0];
        const availableStock = Number(matchedVariant.stock) || 0;

        if (availableStock <= 0) {
          return {
            valid: false,
            error: `The selected specimen "${row.name}" (${matchedVariant.weight}ct) is sold out.`,
          };
        }

        if (demand.totalQuantity > availableStock) {
          return {
            valid: false,
            error: `Insufficient vault stock for "${row.name}". Only ${availableStock} available (total requested: ${demand.totalQuantity}).`,
          };
        }
      } else {
        // Unique 1-of-1 specimen (no variants)
        if (demand.totalQuantity > 1) {
          return {
            valid: false,
            error: `Specimen "${row.name}" is a unique single natural gemstone. Only 1 is available.`,
          };
        }
      }
    }

    return { valid: true };
  } catch (err) {
    console.error("Error during stock validation:", err);
    return { valid: true }; // Don't block if temporary DB error
  }
}

export interface PriceValidationResult {
  valid: boolean;
  error?: string;
  calculatedSubtotal: number;
  calculatedTotal: number;
  sanitizedItems: any[];
}

/**
 * Authoritatively calculates subtotal and total against the database catalog.
 * Prevents client-side price tampering and verifies currency and math.
 */
export async function validateAndCalculateOrderPricing(
  items: any[],
  clientSubtotal?: number,
  clientTotal?: number
): Promise<PriceValidationResult> {
  if (!items || !Array.isArray(items) || items.length === 0) {
    return {
      valid: false,
      error: "Your shopping bag is empty.",
      calculatedSubtotal: 0,
      calculatedTotal: 0,
      sanitizedItems: [],
    };
  }

  let calculatedSubtotal = 0;
  const sanitizedItems: any[] = [];

  for (const item of items) {
    const gemId = item.gemstone?.id || item.id;
    if (!gemId) {
      return {
        valid: false,
        error: "Cart contains an invalid or unidentified specimen.",
        calculatedSubtotal: 0,
        calculatedTotal: 0,
        sanitizedItems: [],
      };
    }

    const [rows] = await pool.query<RowDataPacket[]>(
      "SELECT id, name, price, variants, in_stock FROM gemstones WHERE id = ? LIMIT 1",
      [gemId]
    );

    if (!rows || rows.length === 0) {
      return {
        valid: false,
        error: `Specimen "${item.gemstone?.name || gemId}" does not exist in our catalog.`,
        calculatedSubtotal: 0,
        calculatedTotal: 0,
        sanitizedItems: [],
      };
    }

    const row = rows[0];
    const qty = Math.max(1, Number(item.quantity) || 1);
    let authoritativeUnitPrice = Number(row.price) || 0;

    const variants = parseJson<GemstoneVariant[]>(row.variants, []);
    let matchedVariant: GemstoneVariant | undefined = undefined;

    if (variants && variants.length > 0) {
      const variantId = item.selectedVariant?.id;
      matchedVariant = variants.find((v) => v.id === variantId) || variants[0];
      if (matchedVariant && matchedVariant.price !== undefined) {
        authoritativeUnitPrice = Number(matchedVariant.price) || 0;
      }
    }

    calculatedSubtotal += authoritativeUnitPrice * qty;

    sanitizedItems.push({
      ...item,
      selectedPrice: authoritativeUnitPrice,
      gemstone: {
        ...(item.gemstone || {}),
        id: row.id,
        name: row.name,
        price: Number(row.price) || authoritativeUnitPrice,
      },
      selectedVariant: matchedVariant || item.selectedVariant,
      quantity: qty,
    });
  }

  calculatedSubtotal = Math.round(calculatedSubtotal * 100) / 100;
  const calculatedTotal = calculatedSubtotal;

  if (clientSubtotal !== undefined && clientSubtotal !== null) {
    const diff = Math.abs(Number(clientSubtotal) - calculatedSubtotal);
    if (diff > 0.05) {
      return {
        valid: false,
        error: `Pricing verification failed. Catalog subtotal ($${calculatedSubtotal}) differs from submitted amount ($${clientSubtotal}).`,
        calculatedSubtotal,
        calculatedTotal,
        sanitizedItems,
      };
    }
  }

  if (clientTotal !== undefined && clientTotal !== null) {
    const diff = Math.abs(Number(clientTotal) - calculatedTotal);
    if (diff > 0.05) {
      return {
        valid: false,
        error: `Pricing verification failed. Total calculated amount ($${calculatedTotal}) differs from submitted total ($${clientTotal}).`,
        calculatedSubtotal,
        calculatedTotal,
        sanitizedItems,
      };
    }
  }

  return {
    valid: true,
    calculatedSubtotal,
    calculatedTotal,
    sanitizedItems,
  };
}

/**
 * Helper to determine if an order status corresponds to a confirmed / paid transaction
 */
export function isPaidStatus(status?: string | null): boolean {
  if (!status) return false;
  return ["accepted", "vault_packed", "in_transit", "delivered"].includes(status);
}

/**
 * Deduct stock from gemstones in MySQL in real-time
 */
export async function deductGemstoneStock(items: any[]): Promise<boolean> {
  try {
    if (!items || !Array.isArray(items)) return true;

    // Aggregate deductions by gemId + variantId to prevent double-decrement races
    const aggregated = new Map<string, { gemId: string; variantId?: string; totalQty: number }>();
    for (const item of items) {
      const gemId = item.gemstone?.id || item.id;
      if (!gemId) continue;
      const variantId = item.selectedVariant?.id || "default";
      const key = `${gemId}::${variantId}`;
      const qty = Math.max(1, Number(item.quantity) || 1);
      const existing = aggregated.get(key);
      if (existing) {
        existing.totalQty += qty;
      } else {
        aggregated.set(key, { gemId, variantId: item.selectedVariant?.id, totalQty: qty });
      }
    }

    for (const entry of aggregated.values()) {
      const [rows] = await pool.query<RowDataPacket[]>(
        "SELECT id, in_stock, variants FROM gemstones WHERE id = ? LIMIT 1",
        [entry.gemId]
      );
      if (!rows || rows.length === 0) continue;

      const row = rows[0];
      const variants = parseJson<GemstoneVariant[]>(row.variants, []);

      if (variants && variants.length > 0) {
        let targetIndex = entry.variantId
          ? variants.findIndex((v) => v.id === entry.variantId)
          : 0;
        if (targetIndex === -1) {
          targetIndex = 0;
        }

        const currentStock = Math.max(0, Number(variants[targetIndex].stock) || 0);
        variants[targetIndex].stock = Math.max(0, currentStock - entry.totalQty);

        // Update in_stock status if any variant still has stock > 0
        const hasStockLeft = variants.some((v) => (Number(v.stock) || 0) > 0);
        const newInStock = hasStockLeft ? 1 : 0;

        await pool.query(
          "UPDATE gemstones SET variants = ?, in_stock = ?, updated_at = NOW(3) WHERE id = ?",
          [JSON.stringify(variants), newInStock, entry.gemId]
        );
      } else {
        // Unique single natural specimen (no variants) -> once ordered, it is 100% sold out!
        await pool.query(
          "UPDATE gemstones SET in_stock = 0, updated_at = NOW(3) WHERE id = ?",
          [entry.gemId]
        );
      }
    }
    return true;
  } catch (error) {
    console.error("Error deducting gemstone stock in real-time:", error);
    return false;
  }
}

/**
 * Restore stock to gemstones in MySQL when an order is reverted to pending or cancelled
 */
export async function restoreGemstoneStock(items: any[]): Promise<boolean> {
  try {
    if (!items || !Array.isArray(items)) return true;

    // Aggregate restorations by gemId + variantId
    const aggregated = new Map<string, { gemId: string; variantId?: string; totalQty: number }>();
    for (const item of items) {
      const gemId = item.gemstone?.id || item.id;
      if (!gemId) continue;
      const variantId = item.selectedVariant?.id || "default";
      const key = `${gemId}::${variantId}`;
      const qty = Math.max(1, Number(item.quantity) || 1);
      const existing = aggregated.get(key);
      if (existing) {
        existing.totalQty += qty;
      } else {
        aggregated.set(key, { gemId, variantId: item.selectedVariant?.id, totalQty: qty });
      }
    }

    for (const entry of aggregated.values()) {
      const [rows] = await pool.query<RowDataPacket[]>(
        "SELECT id, in_stock, variants FROM gemstones WHERE id = ? LIMIT 1",
        [entry.gemId]
      );
      if (!rows || rows.length === 0) continue;

      const row = rows[0];
      const variants = parseJson<GemstoneVariant[]>(row.variants, []);

      if (variants && variants.length > 0) {
        let targetIndex = entry.variantId
          ? variants.findIndex((v) => v.id === entry.variantId)
          : 0;
        if (targetIndex === -1) {
          targetIndex = 0;
        }

        const currentStock = Math.max(0, Number(variants[targetIndex].stock) || 0);
        variants[targetIndex].stock = currentStock + entry.totalQty;

        // Gemstone is back in stock
        await pool.query(
          "UPDATE gemstones SET variants = ?, in_stock = 1, updated_at = NOW(3) WHERE id = ?",
          [JSON.stringify(variants), entry.gemId]
        );
      } else {
        // Unique single natural specimen (no variants) -> restore to in_stock = 1
        await pool.query(
          "UPDATE gemstones SET in_stock = 1, updated_at = NOW(3) WHERE id = ?",
          [entry.gemId]
        );
      }
    }
    return true;
  } catch (error) {
    console.error("Error restoring gemstone stock:", error);
    return false;
  }
}

/**
 * Fetch a single order by ID or order_number from MySQL
 */
export async function getOrderById(idOrNumber: string): Promise<RowDataPacket | null> {
  try {
    const [rows] = await pool.query<RowDataPacket[]>(
      "SELECT * FROM orders WHERE id = ? OR order_number = ? LIMIT 1",
      [idOrNumber, idOrNumber]
    );
    if (rows && rows.length > 0) {
      return rows[0];
    }
    return null;
  } catch (error) {
    console.error("Error fetching order by ID from MySQL:", error);
    return null;
  }
}

/**
 * Helper to determine if an order status represents a cancelled, rejected, or refunded order
 */
export function isCancelledStatus(status?: string | null): boolean {
  if (!status) return false;
  const normalized = status.toLowerCase();
  return ["cancelled", "canceled", "rejected", "refunded", "failed"].includes(normalized);
}

/**
 * Update order status in MySQL and manage real-time inventory stock transitions
 */
export async function updateOrderStatus(idOrNumber: string, status: string): Promise<boolean> {
  try {
    const existingOrder = await getOrderById(idOrNumber);
    if (existingOrder) {
      const oldStatus = existingOrder.status || "pending_verification";
      let items: any[] = [];
      try {
        items =
          typeof existingOrder.items === "string"
            ? JSON.parse(existingOrder.items)
            : (existingOrder.items || []);
      } catch {
        items = [];
      }

      const wasCancelled = isCancelledStatus(oldStatus);
      const isNowCancelled = isCancelledStatus(status);

      if (!wasCancelled && isNowCancelled) {
        // Order was active and is now cancelled or rejected -> restore stock back to catalog
        await restoreGemstoneStock(items);
      } else if (wasCancelled && !isNowCancelled) {
        // Order was cancelled and is now reactivated -> re-deduct stock from catalog
        await deductGemstoneStock(items);
      }
    }

    await pool.query(
      "UPDATE orders SET status = ?, updated_at = NOW() WHERE id = ? OR order_number = ?",
      [status, idOrNumber, idOrNumber]
    );
    return true;
  } catch (error) {
    console.error("Error updating order status in MySQL:", error);
    return false;
  }
}

/**
 * Update order delivery address in MySQL
 */
export async function updateOrderAddress(
  idOrNumber: string,
  addressData: {
    shippingAddress?: string;
    city?: string;
    state?: string;
    postalCode?: string;
    country?: string;
  }
): Promise<boolean> {
  try {
    const fields: string[] = [];
    const values: (string | number | boolean | null)[] = [];

    if (addressData.shippingAddress !== undefined) {
      fields.push("shipping_address = ?");
      values.push(addressData.shippingAddress.trim());
    }
    if (addressData.city !== undefined) {
      fields.push("city = ?");
      values.push(addressData.city.trim());
    }
    if (addressData.state !== undefined) {
      fields.push("state = ?");
      values.push(addressData.state.trim());
    }
    if (addressData.postalCode !== undefined) {
      fields.push("postal_code = ?");
      values.push(addressData.postalCode.trim());
    }
    if (addressData.country !== undefined) {
      fields.push("country = ?");
      values.push(addressData.country.trim());
    }

    if (fields.length === 0) return false;

    fields.push("updated_at = NOW()");
    values.push(idOrNumber, idOrNumber);

    await pool.query(
      `UPDATE orders SET ${fields.join(", ")} WHERE id = ? OR order_number = ?`,
      values
    );
    return true;
  } catch (error) {
    console.error("Error updating order address in MySQL:", error);
    return false;
  }
}

