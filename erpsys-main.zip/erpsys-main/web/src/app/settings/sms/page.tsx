"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  MessageSquare,
  ChevronLeft,
  Loader2,
  CheckCircle,
  Save,
  Info,
  Send,
  Globe,
  Key,
  ShieldCheck,
  RotateCcw,
  Sparkles,
  ShoppingBag,
  CreditCard,
  Hash,
  Copy,
  Check,
  Smartphone,
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { authService } from "@/services/auth-service";
import {
  smsSettingsService,
  SmsSettingsData,
} from "@/services/sms-settings-service";

export default function SmsSettingsPage() {
  const router = useRouter();

  const [currentUser, setCurrentUser] = useState<any>(null);
  const [businessId, setBusinessId] = useState<string>("");

  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [testingSms, setTestingSms] = useState<boolean>(false);

  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Test SMS State
  const [testMobile, setTestMobile] = useState<string>("");
  const [testResult, setTestResult] = useState<{
    success: boolean;
    status?: number;
    response?: string;
    error?: string;
  } | null>(null);

  const defaultFormState: SmsSettingsData = {
    enableSms: false,
    gatewayUrl: "",
    httpMethod: "POST",
    apiKey: "",
    apiSecret: "",
    senderId: "",
    mobileParamName: "mobile",
    messageParamName: "message",
    customHeaders: "",
    sendOnSale: true,
    saleTemplate:
      "Dear {customer_name}, thank you for your purchase of {grand_total} at {business_name}. Invoice: {invoice_no}",
    sendOnPayment: true,
    paymentTemplate:
      "Dear {customer_name}, we received payment of {paid_amount} for Invoice {invoice_no}. Thank you, {business_name}",
  };

  const [smsForm, setSmsForm] = useState<SmsSettingsData>(defaultFormState);

  useEffect(() => {
    const user = authService.getCurrentUser();
    if (!user || !user.businessId) {
      router.push("/login");
      return;
    }
    setCurrentUser(user);
    setBusinessId(user.businessId);

    loadSmsSettings(user.businessId);
  }, []);

  const loadSmsSettings = async (bId: string) => {
    setLoading(true);
    setError("");
    try {
      const data = await smsSettingsService.getSettings(bId);
      setSmsForm({
        ...defaultFormState,
        ...data,
        gatewayUrl: data.gatewayUrl || "",
        apiKey: data.apiKey || "",
        apiSecret: data.apiSecret || "",
        senderId: data.senderId || "",
        customHeaders: data.customHeaders || "",
      });
    } catch (err: any) {
      setError(err.message || "Failed to load SMS settings.");
    } finally {
      setLoading(false);
    }
  };

  const showSuccess = (msg: string) => {
    setSuccessMessage(msg);
    setTimeout(() => setSuccessMessage(""), 4000);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      await smsSettingsService.updateSettings({
        ...smsForm,
        businessId,
      });
      showSuccess("SMS Gateway and notification settings saved successfully!");
    } catch (err: any) {
      setError(err.message || "Failed to save SMS settings.");
    } finally {
      setSaving(false);
    }
  };

  const handleSendTestSms = async () => {
    if (!testMobile) {
      setError("Please enter a valid mobile number to test.");
      return;
    }
    setTestingSms(true);
    setTestResult(null);
    setError("");
    try {
      const res = await smsSettingsService.sendTestSms({
        businessId,
        mobileNumber: testMobile,
      });
      setTestResult(res);
      if (res.success) {
        showSuccess("Test SMS request dispatched successfully!");
      }
    } catch (err: any) {
      setTestResult({
        success: false,
        error: err.message || "Failed to send test SMS.",
      });
    } finally {
      setTestingSms(false);
    }
  };

  const insertTag = (field: "saleTemplate" | "paymentTemplate", tag: string) => {
    setSmsForm((prev) => ({
      ...prev,
      [field]: prev[field] + " " + tag,
    }));
  };

  const handleResetDefaults = () => {
    setSmsForm(defaultFormState);
    showSuccess("Reset to default settings.");
  };

  const saleTags = [
    "{customer_name}",
    "{invoice_no}",
    "{grand_total}",
    "{paid_amount}",
    "{due_amount}",
    "{business_name}",
  ];

  const paymentTags = [
    "{customer_name}",
    "{invoice_no}",
    "{paid_amount}",
    "{payment_ref}",
    "{business_name}",
  ];

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/settings" />
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Ambient Glowing Orbs */}
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-primary/5 blur-[120px] pointer-events-none z-0" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[550px] h-[550px] rounded-full bg-primary/5 blur-[130px] pointer-events-none z-0" />

        <Navbar title="SMS Settings" className="relative z-10" />

        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 relative z-10">
          <div className="max-w-4xl mx-auto space-y-6">

            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <button
                  onClick={() => router.push("/settings")}
                  className="inline-flex items-center text-xs font-semibold text-muted-foreground hover:text-primary mb-2 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4 mr-1" /> Back to Settings
                </button>
                <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                  <MessageSquare className="h-7 w-7 text-primary" /> SMS Settings
                </h1>
                <p className="text-sm text-muted-foreground mt-1">
                  Configure SMS Gateway API, sender identification, and automated customer notifications.
                </p>
              </div>

              {/* Master SMS Toggle Badge */}
              <div className="flex items-center gap-3 bg-card/60 border border-border/60 p-2 px-3.5 rounded-xl backdrop-blur-md shadow-sm">
                <div className="flex flex-col">
                  <span className="text-xs font-bold text-foreground">
                    SMS Service: {smsForm.enableSms ? "Active" : "Disabled"}
                  </span>
                  <span className="text-[10px] text-muted-foreground">
                    Master sending switch
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={smsForm.enableSms}
                  onChange={(e) =>
                    setSmsForm({ ...smsForm, enableSms: e.target.checked })
                  }
                  className="w-5 h-5 text-primary rounded accent-primary cursor-pointer"
                />
              </div>
            </div>

            {/* Notifications */}
            {successMessage && (
              <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 p-3 rounded-lg text-sm flex items-center gap-2 animate-in fade-in">
                <CheckCircle className="w-4 h-4 shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}

            {error && (
              <div className="bg-destructive/10 border border-destructive/30 text-destructive p-3 rounded-lg text-sm flex items-center gap-2 animate-in fade-in">
                <Info className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {loading ? (
              <div className="flex items-center justify-center py-16 text-muted-foreground">
                <Loader2 className="w-6 h-6 animate-spin mr-2 text-primary" /> Loading SMS configurations...
              </div>
            ) : (
              <form onSubmit={handleSave} className="space-y-6 pb-16">

                {/* Section 1: Gateway Configuration */}
                <Card className="border border-border/50 bg-card/30 backdrop-blur-md">
                  <CardContent className="p-5 space-y-4">
                    <div className="flex items-center gap-2 border-b border-border/40 pb-3">
                      <div className="p-1.5 rounded-lg bg-primary/10 text-primary">
                        <Globe className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-sm font-bold text-foreground">SMS Gateway HTTP Configuration</h2>
                        <p className="text-xs text-muted-foreground">
                          Connect any SMS provider API (Fast2SMS, MSG91, Twilio, Textlocal, or Custom API).
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
                      {/* Gateway URL */}
                      <div className="space-y-1.5 md:col-span-2">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <Globe className="w-3.5 h-3.5 text-primary" /> Gateway API URL
                        </label>
                        <Input
                          type="text"
                          value={smsForm.gatewayUrl || ""}
                          onChange={(e) =>
                            setSmsForm({ ...smsForm, gatewayUrl: e.target.value })
                          }
                          className="font-mono text-xs h-10"
                          placeholder="https://api.your-sms-provider.com/v1/send"
                        />
                        <p className="text-[10px] text-muted-foreground">
                          HTTP endpoint to which the SMS request will be dispatched.
                        </p>
                      </div>

                      {/* HTTP Method */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <Hash className="w-3.5 h-3.5 text-primary" /> HTTP Method
                        </label>
                        <select
                          value={smsForm.httpMethod}
                          onChange={(e) =>
                            setSmsForm({ ...smsForm, httpMethod: e.target.value })
                          }
                          className="w-full h-10 px-3 rounded-md bg-background/80 border border-border/60 text-xs font-mono font-bold focus:ring-1 focus:ring-primary focus:outline-none"
                        >
                          <option value="POST">POST (JSON Body)</option>
                          <option value="GET">GET (URL Query Params)</option>
                        </select>
                        <p className="text-[10px] text-muted-foreground">
                          Request method supported by provider.
                        </p>
                      </div>

                      {/* API Key */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <Key className="w-3.5 h-3.5 text-primary" /> API Key / Auth Token
                        </label>
                        <Input
                          type="password"
                          value={smsForm.apiKey || ""}
                          onChange={(e) =>
                            setSmsForm({ ...smsForm, apiKey: e.target.value })
                          }
                          className="font-mono text-xs h-10"
                          placeholder="Enter your API key or bearer token"
                        />
                      </div>

                      {/* Sender ID */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <Smartphone className="w-3.5 h-3.5 text-primary" /> Sender ID / Header
                        </label>
                        <Input
                          type="text"
                          value={smsForm.senderId || ""}
                          onChange={(e) =>
                            setSmsForm({ ...smsForm, senderId: e.target.value })
                          }
                          className="font-mono text-xs h-10 uppercase"
                          placeholder="e.g. HKRION"
                        />
                        <p className="text-[10px] text-muted-foreground">Approved 6-char sender name.</p>
                      </div>

                      {/* Mobile Param Name */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <Hash className="w-3.5 h-3.5 text-primary" /> Mobile Param Key
                        </label>
                        <Input
                          type="text"
                          value={smsForm.mobileParamName}
                          onChange={(e) =>
                            setSmsForm({ ...smsForm, mobileParamName: e.target.value })
                          }
                          className="font-mono text-xs h-10"
                          placeholder="mobile (or to, phone)"
                        />
                      </div>

                      {/* Message Param Name */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <Hash className="w-3.5 h-3.5 text-primary" /> Message Param Key
                        </label>
                        <Input
                          type="text"
                          value={smsForm.messageParamName}
                          onChange={(e) =>
                            setSmsForm({ ...smsForm, messageParamName: e.target.value })
                          }
                          className="font-mono text-xs h-10"
                          placeholder="message (or text, msg)"
                        />
                      </div>

                      {/* Custom Headers (Optional JSON) */}
                      <div className="space-y-1.5 md:col-span-2">
                        <label className="text-xs font-semibold flex items-center gap-1.5">
                          <Key className="w-3.5 h-3.5 text-muted-foreground" /> Custom Headers (Optional JSON)
                        </label>
                        <Input
                          type="text"
                          value={smsForm.customHeaders || ""}
                          onChange={(e) =>
                            setSmsForm({ ...smsForm, customHeaders: e.target.value })
                          }
                          className="font-mono text-xs h-10"
                          placeholder='{"Content-Type": "application/json"}'
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Section 2: Automated Notification Templates */}
                <Card className="border border-border/50 bg-card/30 backdrop-blur-md">
                  <CardContent className="p-5 space-y-5">
                    <div className="flex items-center gap-2 border-b border-border/40 pb-3">
                      <div className="p-1.5 rounded-lg bg-primary/10 text-primary">
                        <Send className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-sm font-bold text-foreground">Automated Notification Templates</h2>
                        <p className="text-xs text-muted-foreground">
                          Customize message bodies sent automatically when events occur.
                        </p>
                      </div>
                    </div>

                    {/* Sale Completed Template */}
                    <div className="space-y-2.5 p-4 rounded-xl border border-border/40 bg-background/50">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <ShoppingBag className="w-4 h-4 text-emerald-500" />
                          <span className="text-xs font-bold">Sale Completed SMS</span>
                        </div>
                        <label className="flex items-center gap-2 text-xs cursor-pointer font-medium">
                          <span>Auto Send</span>
                          <input
                            type="checkbox"
                            checked={smsForm.sendOnSale}
                            onChange={(e) =>
                              setSmsForm({ ...smsForm, sendOnSale: e.target.checked })
                            }
                            className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                          />
                        </label>
                      </div>

                      <textarea
                        rows={3}
                        value={smsForm.saleTemplate}
                        onChange={(e) =>
                          setSmsForm({ ...smsForm, saleTemplate: e.target.value })
                        }
                        className="w-full p-2.5 rounded-md bg-background/80 border border-border/60 text-xs font-sans focus:ring-1 focus:ring-primary focus:outline-none"
                        placeholder="Enter sale confirmation SMS template..."
                      />

                      {/* Tag Pills */}
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-[10px] text-muted-foreground mr-1">Insert Tags:</span>
                        {saleTags.map((t) => (
                          <button
                            key={t}
                            type="button"
                            onClick={() => insertTag("saleTemplate", t)}
                            className="px-2 py-0.5 rounded-full bg-primary/10 hover:bg-primary/20 text-primary text-[10px] font-mono transition-colors"
                          >
                            + {t}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Payment Received Template */}
                    <div className="space-y-2.5 p-4 rounded-xl border border-border/40 bg-background/50">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <CreditCard className="w-4 h-4 text-indigo-400" />
                          <span className="text-xs font-bold">Payment Received SMS</span>
                        </div>
                        <label className="flex items-center gap-2 text-xs cursor-pointer font-medium">
                          <span>Auto Send</span>
                          <input
                            type="checkbox"
                            checked={smsForm.sendOnPayment}
                            onChange={(e) =>
                              setSmsForm({ ...smsForm, sendOnPayment: e.target.checked })
                            }
                            className="w-4 h-4 text-primary rounded accent-primary cursor-pointer"
                          />
                        </label>
                      </div>

                      <textarea
                        rows={3}
                        value={smsForm.paymentTemplate}
                        onChange={(e) =>
                          setSmsForm({ ...smsForm, paymentTemplate: e.target.value })
                        }
                        className="w-full p-2.5 rounded-md bg-background/80 border border-border/60 text-xs font-sans focus:ring-1 focus:ring-primary focus:outline-none"
                        placeholder="Enter payment receipt SMS template..."
                      />

                      {/* Tag Pills */}
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-[10px] text-muted-foreground mr-1">Insert Tags:</span>
                        {paymentTags.map((t) => (
                          <button
                            key={t}
                            type="button"
                            onClick={() => insertTag("paymentTemplate", t)}
                            className="px-2 py-0.5 rounded-full bg-primary/10 hover:bg-primary/20 text-primary text-[10px] font-mono transition-colors"
                          >
                            + {t}
                          </button>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Section 3: Live SMS Tester */}
                <Card className="border border-border/50 bg-card/30 backdrop-blur-md">
                  <CardContent className="p-5 space-y-4">
                    <div className="flex items-center gap-2 border-b border-border/40 pb-3">
                      <div className="p-1.5 rounded-lg bg-primary/10 text-primary">
                        <Smartphone className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-sm font-bold text-foreground">Live SMS Gateway Tester</h2>
                        <p className="text-xs text-muted-foreground">
                          Verify gateway connectivity by sending a direct test SMS message.
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row items-end gap-3 pt-1">
                      <div className="space-y-1.5 flex-1 w-full">
                        <label className="text-xs font-semibold">Test Mobile Number</label>
                        <Input
                          type="tel"
                          value={testMobile}
                          onChange={(e) => setTestMobile(e.target.value)}
                          placeholder="e.g. +91 9876543210"
                          className="h-10 text-xs font-mono"
                        />
                      </div>
                      <Button
                        type="button"
                        onClick={handleSendTestSms}
                        disabled={testingSms}
                        className="h-10 gap-2 min-w-[140px]"
                      >
                        {testingSms ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Send className="w-4 h-4" />
                        )}
                        Send Test SMS
                      </Button>
                    </div>

                    {/* Test Result Display */}
                    {testResult && (
                      <div
                        className={`p-3 rounded-lg border text-xs font-mono mt-2 space-y-1 ${
                          testResult.success
                            ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-500"
                            : "bg-destructive/10 border-destructive/30 text-destructive"
                        }`}
                      >
                        <div className="font-bold flex items-center gap-1.5">
                          {testResult.success ? (
                            <CheckCircle className="w-4 h-4" />
                          ) : (
                            <Info className="w-4 h-4" />
                          )}
                          Status: {testResult.success ? "Success" : "Failed"} (HTTP {testResult.status || 0})
                        </div>
                        {testResult.response && (
                          <div className="text-[11px] text-foreground/80 break-all bg-background/50 p-2 rounded">
                            {testResult.response}
                          </div>
                        )}
                        {testResult.error && (
                          <div className="text-[11px] text-destructive break-all">
                            {testResult.error}
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Bottom Actions */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-border/60">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleResetDefaults}
                    className="text-xs text-muted-foreground hover:text-foreground gap-1.5"
                  >
                    <RotateCcw className="w-3.5 h-3.5" /> Reset Defaults
                  </Button>

                  <Button
                    type="submit"
                    disabled={saving}
                    className="gap-2 min-w-[170px] shadow-md shadow-primary/10"
                  >
                    {saving ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Save className="w-4 h-4" />
                    )}
                    Save SMS Settings
                  </Button>
                </div>

              </form>
            )}

          </div>
        </main>
      </div>
    </div>
  );
}
