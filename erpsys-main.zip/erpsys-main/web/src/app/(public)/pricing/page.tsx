"use strict";
"use client";

import React, { useState, useEffect, useMemo } from "react";
import {
  Check,
  Zap,
  Building,
  Rocket,
  Shield,
  ShieldCheck,
  CreditCard,
  Sparkles,
  ChevronDown,
  Loader2,
  ArrowRight,
  MessageSquare,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { subscriptionService } from "@/services/subscription-service";
import { cmsService } from "@/services/cms-service";
import { Plan } from "@/features/subscriptions/types";
import { useUserCountry } from "@/hooks/use-user-country";
import { ContactSalesDialog } from "@/components/contact-sales-dialog";

export default function PricingPage() {
  const [billingPeriod, setBillingPeriod] = useState<"monthly" | "yearly">("monthly");
  const [plans, setPlans] = useState<Plan[]>([]);
  const [faqs, setFaqs] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);
  const [isContactSalesOpen, setIsContactSalesOpen] = useState(false);
  const { isSriLanka } = useUserCountry();
  const currency: "LKR" | "USD" = isSriLanka ? "LKR" : "USD";

  // Dynamically calculate savings percentage based on active plans
  const maxSavingsPercent = useMemo(() => {
    let maxPercent = 0;
    plans.forEach((plan) => {
      const monthly = currency === "USD" ? (plan.priceMonthlyUsd || 0) : plan.priceMonthly;
      const yearly = currency === "USD" ? (plan.priceYearlyUsd || 0) : plan.priceYearly;
      if (monthly > 0 && yearly > 0) {
        const fullYear = monthly * 12;
        if (fullYear > yearly) {
          const percent = Math.round(((fullYear - yearly) / fullYear) * 100);
          if (percent > maxPercent) {
            maxPercent = percent;
          }
        }
      }
    });
    return maxPercent > 0 ? maxPercent : 17;
  }, [plans, currency]);

  useEffect(() => {
    loadPricingData();
  }, []);

  const loadPricingData = async () => {
    setIsLoading(true);
    try {
      const [plansData, cmsData] = await Promise.all([
        subscriptionService.getPlans().catch(() => []),
        cmsService.getPublicContent().catch(() => null),
      ]);

      if (plansData) {
        setPlans(plansData.filter((p) => p.isActive !== false));
      }
      if (cmsData?.faqs) {
        setFaqs(cmsData.faqs);
      }
    } catch (e) {
      console.error("Failed to load pricing data", e);
    } finally {
      setIsLoading(false);
    }
  };

  const defaultFaqs = [
    {
      question: "Can I test HKRION ERP before paying?",
      answer: "Yes! Every newly registered business account starts with a 14-day full feature Free Trial without requiring credit card or bank details.",
    },
    {
      question: "What payment options are supported for subscriptions?",
      answer: "We support instant online checkout via PayHere.lk (Visa, Mastercard, FriMi, Genie, eZ Cash, mCash, Internet Banking) and Direct SaaS Bank Transfer with slip upload verification.",
    },
    {
      question: "Can I upgrade, downgrade, or cancel anytime?",
      answer: "Yes! You can manage your subscription directly from the Tenant Billing portal. Upgrades are prorated immediately, and cancellations have zero lock-in penalties.",
    },
    {
      question: "Does HKRION ERP support barcode scanners and thermal printers?",
      answer: "Absolutely! Our Point of Sale system works out-of-the-box with standard USB/Bluetooth barcode scanners, 80mm/58mm ESC/POS thermal printers, and cash drawers.",
    },
  ];

  const displayedFaqs = faqs.length > 0 ? faqs : defaultFaqs;

  return (
    <div className="bg-transparent text-foreground flex flex-col items-center justify-center p-4 sm:p-6 relative selection:bg-emerald-500/30 selection:text-emerald-400">
      <div className="w-full max-w-7xl mt-4 relative z-10 space-y-16 pb-20">
        {/* Header Section */}
        <div className="text-center space-y-3 max-w-2xl mx-auto pt-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-sm bg-primary/10 border border-primary/20 text-primary text-[10px] font-bold tracking-wider uppercase font-mono">
            <Zap className="w-3.5 h-3.5" /> Simple, Scalable & Transparent Pricing
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold text-foreground tracking-tight leading-tight font-sans">
            Flexible Plans Built For <br />
            <span className="bg-gradient-to-r from-primary via-primary/80 to-primary/60 bg-clip-text text-transparent">
              {isSriLanka ? "Modern Sri Lankan Businesses" : "Modern Global Businesses"}
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
            {isSriLanka
              ? "Start with our 14-day free trial. Upgrade, downgrade, or cancel anytime with automated PayHere.lk or direct bank transfer."
              : "Start with our 14-day free trial. Upgrade, downgrade, or cancel anytime with secure international checkout."}
          </p>
        </div>

        {/* Billing Period Toggle (Centered) */}
        <div className="flex items-center justify-center pt-2">
          <div className="bg-card/70 p-1 rounded-sm border border-border/80 backdrop-blur-md flex items-center gap-1 shadow-md">
            <button
              onClick={() => setBillingPeriod("monthly")}
              className={cn(
                "text-xs font-mono font-bold px-4 py-1.5 rounded-sm transition-all",
                billingPeriod === "monthly"
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              Monthly Billing
            </button>
            <button
              onClick={() => setBillingPeriod("yearly")}
              className={cn(
                "text-xs font-mono font-bold px-4 py-1.5 rounded-sm transition-all flex items-center gap-2",
                billingPeriod === "yearly"
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              Yearly Billing
              <span
                className={cn(
                  "px-1.5 py-0.5 rounded-sm text-[9px] font-extrabold font-mono transition-colors border",
                  billingPeriod === "yearly"
                    ? "bg-black/25 text-black border-black/30 shadow-sm"
                    : "bg-primary/20 text-primary border-primary/30"
                )}
              >
                SAVE {maxSavingsPercent}%
              </span>
            </button>
          </div>
        </div>

        {/* Pricing Cards Grid (Dynamic from Database) */}
        {isLoading ? (
          <div className="p-16 text-center text-muted-foreground">
            <Loader2 className="w-8 h-8 animate-spin mx-auto mb-3 text-primary" />
            <p className="text-xs font-mono">Fetching published SaaS subscription plans...</p>
          </div>
        ) : plans.length === 0 ? (
          <div className="p-10 text-center text-xs text-muted-foreground border border-dashed border-border rounded-sm max-w-md mx-auto font-mono">
            No active subscription plans published yet. Please check back shortly.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 items-stretch">
            {plans.map((plan, idx) => {
              const isPopular = plan.isPopular;
              const price = currency === "USD"
                ? (billingPeriod === "yearly"
                    ? (plan.priceYearlyUsd || (plan.priceMonthlyUsd || 0) * 10)
                    : (plan.priceMonthlyUsd || 0))
                : (billingPeriod === "yearly"
                    ? plan.priceYearly || plan.priceMonthly * 10
                    : plan.priceMonthly);
              const currencyPrefix = currency === "USD" ? "$" : "Rs.";

              return (
                <Card
                  key={plan.id}
                  className={cn(
                    "backdrop-blur-md p-5 sm:p-6 flex flex-col justify-between h-full relative transition-all duration-300 rounded-sm",
                    isPopular
                      ? "border-2 border-primary bg-card/70 shadow-2xl shadow-primary/10 relative lg:-translate-y-2"
                      : "border border-border/70 bg-card/40 hover:border-border"
                  )}
                >
                  {/* Popular Badge */}
                  {isPopular && (
                    <span className="absolute top-0 right-1/2 translate-x-1/2 -translate-y-1/2 bg-primary text-primary-foreground text-[9px] font-extrabold font-mono tracking-wider uppercase px-3 py-1 rounded-sm border border-primary/30 shadow-md">
                      MOST POPULAR
                    </span>
                  )}

                  <div className="space-y-5">
                    {/* Icon & Title */}
                    <div className="flex items-center justify-between">
                      <div
                        className={cn(
                          "w-9 h-9 rounded-sm border flex items-center justify-center",
                          isPopular
                            ? "bg-primary/15 text-primary border-primary/30"
                            : "bg-secondary text-primary border-border"
                        )}
                      >
                        {idx === 0 && <Building className="w-4 h-4" />}
                        {idx === 1 && <Rocket className="w-4 h-4" />}
                        {idx === 2 && <Zap className="w-4 h-4" />}
                        {idx >= 3 && <Shield className="w-4 h-4" />}
                      </div>
                      <span className="text-[10px] font-mono font-bold text-primary uppercase bg-primary/10 px-2 py-0.5 rounded-sm border border-primary/20">
                        {plan.trialDays || 14}-DAY TRIAL
                      </span>
                    </div>

                    <div>
                      <h3 className="text-base sm:text-lg font-bold text-foreground tracking-tight">{plan.name}</h3>
                      <p className="text-xs text-muted-foreground mt-1 leading-relaxed min-h-[36px] line-clamp-2">
                        {plan.description || "Comprehensive enterprise cloud ERP features."}
                      </p>
                    </div>

                    {/* Price */}
                    <div className="pt-1">
                      {plan.slug === "enterprise" ? (
                        <div>
                          <div className="text-2xl sm:text-3xl font-extrabold font-mono text-foreground tracking-tight">
                            Custom
                          </div>
                          <p className="text-[10px] text-muted-foreground font-mono mt-0.5">
                            Tailored quote for your scale
                          </p>
                        </div>
                      ) : (
                        <div>
                          {currency === "USD" && !Number.isInteger(price) ? (
                            <div className="flex items-start font-mono tracking-tight">
                              <span className="text-4xl sm:text-5xl font-black text-foreground leading-none">
                                {Math.floor(price)}
                              </span>
                              <div className="flex flex-col justify-between self-stretch ml-0.5 py-0.5 select-none font-mono">
                                <span className="text-lg sm:text-xl font-black text-foreground leading-none">
                                  .{Number((price % 1).toFixed(2)).toFixed(2).split(".")[1]}
                                </span>
                                <span className="text-[10px] sm:text-[11px] font-bold text-muted-foreground leading-none mt-1">
                                  $/ {billingPeriod === "yearly" ? "year" : "month"}
                                </span>
                              </div>
                            </div>
                          ) : (
                            <div className="flex items-baseline gap-1 font-mono">
                              <span className="text-xs font-bold text-muted-foreground">
                                {currencyPrefix}
                              </span>
                              <span className="text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight">
                                {price.toLocaleString(undefined, { minimumFractionDigits: currency === 'USD' && !Number.isInteger(price) ? 2 : 0, maximumFractionDigits: 2 })}
                              </span>
                              <span className="text-xs text-muted-foreground font-mono">
                                /{billingPeriod === "yearly" ? "year" : "mo"}
                              </span>
                            </div>
                          )}
                          {billingPeriod === "yearly" && (
                            <p className="text-[10px] text-primary font-mono mt-0.5">
                              Billed annually (2 months free)
                            </p>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Features List */}
                    <div className="border-t border-border/60 pt-6 space-y-3">
                      <div className="flex items-center gap-2.5 text-xs text-muted-foreground">
                        <Check className="w-4 h-4 text-primary shrink-0" />
                        <span>
                          <strong>{plan.maxBranches <= 0 ? "Unlimited" : plan.maxBranches}</strong> Store Locations & Branches
                        </span>
                      </div>
                      <div className="flex items-center gap-2.5 text-xs text-muted-foreground">
                        <Check className="w-4 h-4 text-primary shrink-0" />
                        <span>
                          <strong>{plan.maxUsers <= 0 ? "Unlimited" : plan.maxUsers}</strong> Staff & Cashier User Accounts
                        </span>
                      </div>
                      <div className="flex items-center gap-2.5 text-xs text-muted-foreground">
                        <Check className="w-4 h-4 text-primary shrink-0" />
                        <span>
                          <strong>{plan.maxProducts <= 0 ? "Unlimited" : plan.maxProducts.toLocaleString()}</strong> Inventory SKUs
                        </span>
                      </div>
                      <div className="flex items-center gap-2.5 text-xs text-muted-foreground">
                        <Check className="w-4 h-4 text-primary shrink-0" />
                        <span>
                          <strong>{plan.maxInvoicesMonthly <= 0 ? "Unlimited" : plan.maxInvoicesMonthly.toLocaleString()}</strong> Monthly Invoices
                        </span>
                      </div>
                      <div className="flex items-center gap-2.5 text-xs text-muted-foreground">
                        <Check className="w-4 h-4 text-primary shrink-0" />
                        <span>IMEI & Barcode Tracking</span>
                      </div>
                      <div className="flex items-center gap-2.5 text-xs text-muted-foreground">
                        <Check className="w-4 h-4 text-primary shrink-0" />
                        <span>PayHere & Bank Slip Upload Checkout</span>
                      </div>
                    </div>
                  </div>

                  {/* CTA Button */}
                  <div className="pt-8">
                    {plan.slug === "enterprise" ? (
                      <Button
                        type="button"
                        onClick={() => setIsContactSalesOpen(true)}
                        className="w-full text-xs h-10 rounded-sm font-bold font-mono transition-all border border-primary/40 bg-primary/10 hover:bg-primary text-foreground hover:text-primary-foreground shadow-sm flex items-center justify-center gap-1.5"
                      >
                        <span>Contact Sales</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </Button>
                    ) : (
                      <Link href={`/register?plan=${plan.id}`} className="w-full">
                        <Button
                          className={cn(
                            "w-full text-xs h-10 rounded-sm font-bold font-mono transition-all",
                            isPopular
                              ? "bg-primary hover:bg-primary/90 text-primary-foreground shadow-md shadow-primary/20"
                              : "bg-secondary hover:bg-secondary/80 text-foreground border border-border"
                          )}
                        >
                          {plan.slug === "trial" ? "Get Started" : "Start a Free Trial"}
                        </Button>
                      </Link>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
        )}

        {/* Feature Comparison Matrix Banner */}
        <div className="bg-card/40 border border-border/70 rounded-sm p-6 sm:p-8 backdrop-blur-md">
          <div className="text-center space-y-2 mb-6">
            <span className="text-[10px] font-mono font-bold uppercase text-primary tracking-widest">
              WHAT&apos;S INCLUDED
            </span>
            <h3 className="text-xl sm:text-2xl font-bold text-foreground">
              Every HKRION ERP Plan Includes
            </h3>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
            <div className="p-4 rounded-sm bg-secondary/30 border border-border/50 flex flex-col gap-2">
              <ShieldCheck className="w-5 h-5 text-primary" />
              <span className="font-bold text-foreground">100% Tenant Isolation</span>
              <p className="text-[11px] text-muted-foreground">Private database partition for your store.</p>
            </div>
            <div className="p-4 rounded-sm bg-secondary/30 border border-border/50 flex flex-col gap-2">
              <CreditCard className="w-5 h-5 text-primary" />
              <span className="font-bold text-foreground">Sri Lankan Tax Ready</span>
              <p className="text-[11px] text-muted-foreground">18% VAT/GST automated invoicing.</p>
            </div>
            <div className="p-4 rounded-sm bg-secondary/30 border border-border/50 flex flex-col gap-2">
              <Zap className="w-5 h-5 text-primary" />
              <span className="font-bold text-foreground">Hardware Compatible</span>
              <p className="text-[11px] text-muted-foreground">ESC/POS thermal printers & barcode scanners.</p>
            </div>
            <div className="p-4 rounded-sm bg-secondary/30 border border-border/50 flex flex-col gap-2">
              <Sparkles className="w-5 h-5 text-primary" />
              <span className="font-bold text-foreground">Daily Cloud Backups</span>
              <p className="text-[11px] text-muted-foreground">Automated encrypted disaster recovery.</p>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="space-y-6 border-t border-border/60 pt-16 max-w-4xl mx-auto">
          <div className="text-center space-y-2">
            <span className="text-[10px] font-mono font-bold uppercase text-primary tracking-widest">
              FREQUENTLY ASKED QUESTIONS
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight">
              Got Billing Questions?
            </h2>
            <p className="text-xs text-muted-foreground">
              Everything you need to know about our pricing, subscriptions, and payment methods.
            </p>
          </div>

          <div className="space-y-3 pt-4">
            {displayedFaqs.map((faq, idx) => {
              const isOpen = openFaqIndex === idx;
              return (
                <div
                  key={idx}
                  className="border border-border/70 bg-card/40 backdrop-blur-md rounded-sm overflow-hidden transition-colors"
                >
                  <button
                    onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                    className="w-full p-4 text-left flex items-center justify-between text-xs sm:text-sm font-bold text-foreground hover:text-primary transition-colors"
                  >
                    <span>{faq.question}</span>
                    <ChevronDown
                      className={cn(
                        "w-4 h-4 text-muted-foreground transition-transform duration-200",
                        isOpen && "rotate-180 text-primary"
                      )}
                    />
                  </button>
                  {isOpen && (
                    <div className="px-4 pb-4 text-xs text-muted-foreground leading-relaxed animate-fadeIn">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Custom Enterprise Quotation Callout */}
        <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border border-primary/30 p-6 sm:p-8 rounded-sm max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="text-left space-y-1">
            <span className="text-[10px] font-bold text-primary uppercase font-mono tracking-wider">
              ENTERPRISE & MULTI-BRANCH CHAINS
            </span>
            <h4 className="text-base font-bold text-foreground">Need a Custom Dedicated Plan?</h4>
            <p className="text-xs text-muted-foreground max-w-lg">
              Contact our solutions architecture team for custom integrations, on-premise deployments, or volume enterprise licensing.
            </p>
          </div>
          <Button
            type="button"
            onClick={() => setIsContactSalesOpen(true)}
            className="bg-primary hover:bg-primary/90 text-primary-foreground text-xs h-10 px-5 rounded-sm font-bold font-mono transition-all gap-1.5 shadow-md shadow-primary/20 whitespace-nowrap"
          >
            <MessageSquare className="w-4 h-4" /> Get Custom Quote <ArrowRight className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      <ContactSalesDialog
        isOpen={isContactSalesOpen}
        onClose={() => setIsContactSalesOpen(false)}
        defaultPlanName="Enterprise Plan"
      />
    </div>
  );
}
