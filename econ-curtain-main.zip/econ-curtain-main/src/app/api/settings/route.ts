import { NextResponse } from "next/server";
import { SettingsService } from "@/services/settings.service";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const settings = await SettingsService.getSettings();
    return NextResponse.json(settings, {
      headers: {
        "Cache-Control": "public, s-maxage=60, stale-while-revalidate=300",
      },
    });
  } catch (error) {
    console.error("Error loading public site settings:", error);
    return NextResponse.json({ error: "Failed to load settings" }, { status: 500 });
  }
}
