import { IsEmail, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class TestEmailDto {
  @IsNotEmpty()
  @IsEmail()
  toEmail: string;

  @IsOptional()
  @IsString()
  subject?: string;

  @IsOptional()
  @IsString()
  message?: string;
}
