# Authentication Module

This module handles backend security, user authentication, and authorization:
- JWT token generation and validation
- Password hashing and encryption
- Role-based access control (RBAC) guards (e.g., Admin, Cashier)
- User session management

## Files to create
- `auth.controller.ts`: Handles login/register API endpoints.
- `auth.service.ts`: Handles business logic for authentication.
- `auth.module.ts`: NestJS module declaration.
- `jwt.strategy.ts`: JWT verification strategy.
