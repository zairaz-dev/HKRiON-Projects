import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

interface SalesReturnLineInput {
  saleLineId?: string;
  variantId: string;
  quantityReturned: number;
  unitPrice: number;
  taxAmount?: number;
}

@Injectable()
export class SalesReturnsService {
  constructor(private readonly prisma: PrismaService) {}

  async createSalesReturn(data: {
    saleId: string;
    returnDate?: Date;
    businessId: string;
    refundType?: 'CREDIT_NOTE' | 'CASH_REFUND';
    reason?: string;
    notes?: string;
    createdById?: string;
    returnLines: SalesReturnLineInput[];
  }) {
    const {
      saleId,
      returnDate,
      businessId,
      refundType = 'CREDIT_NOTE',
      reason,
      notes,
      createdById,
      returnLines,
    } = data;

    if (!returnLines || returnLines.length === 0) {
      throw new BadRequestException('Sales return must contain at least one returned item line.');
    }

    const sale = await this.prisma.sale.findFirst({
      where: { id: saleId, businessId },
      include: {
        saleLines: true,
        salesReturns: {
          include: {
            returnLines: true,
          },
        },
      },
    });

    if (!sale) {
      throw new NotFoundException('Original sale invoice not found.');
    }

    // Generate return number using configured document prefix
    const docPrefix = await this.prisma.documentPrefix.findUnique({
      where: { businessId },
    });
    const prefix = docPrefix?.salesReturn || 'RET-';

    const count = await this.prisma.salesReturn.count({ where: { businessId } });
    const returnNumber = `${prefix}${String(count + 1).padStart(4, '0')}`;

    return this.prisma.$transaction(async (tx) => {
      let subtotal = 0;
      let taxTotal = 0;
      let grandTotal = 0;

      const linesToCreate: {
        saleLineId?: string;
        variantId: string;
        quantityReturned: number;
        unitPrice: number;
        taxAmount: number;
        subtotal: number;
      }[] = [];

      for (const inputLine of returnLines) {
        if (inputLine.quantityReturned <= 0) {
          throw new BadRequestException('Returned quantity must be greater than zero.');
        }

        const saleLine = sale.saleLines.find(
          (sl) => sl.id === inputLine.saleLineId || sl.variantId === inputLine.variantId,
        );

        if (!saleLine) {
          throw new BadRequestException(`Item line for variant ID ${inputLine.variantId} not found in sale invoice.`);
        }

        // Calculate already returned quantity for this line
        let totalAlreadyReturned = 0;
        for (const prevReturn of sale.salesReturns) {
          for (const prevLine of prevReturn.returnLines) {
            if (prevLine.variantId === inputLine.variantId) {
              totalAlreadyReturned += prevLine.quantityReturned;
            }
          }
        }

        const maxReturnable = saleLine.quantity - totalAlreadyReturned;
        if (inputLine.quantityReturned > maxReturnable) {
          throw new BadRequestException(
            `Cannot return ${inputLine.quantityReturned} units. Maximum returnable quantity for this item is ${maxReturnable}.`,
          );
        }

        const unitPrice = inputLine.unitPrice > 0 ? inputLine.unitPrice : saleLine.unitPrice;
        const lineTax = inputLine.taxAmount || 0;
        const lineSubtotal = inputLine.quantityReturned * unitPrice + lineTax;

        subtotal += inputLine.quantityReturned * unitPrice;
        taxTotal += lineTax;
        grandTotal += lineSubtotal;

        linesToCreate.push({
          saleLineId: saleLine.id,
          variantId: inputLine.variantId,
          quantityReturned: inputLine.quantityReturned,
          unitPrice,
          taxAmount: lineTax,
          subtotal: lineSubtotal,
        });

        // 1. Stock Restoration: Create new inventory batch in PurchaseLine
        const variant = await tx.productVariant.findUnique({
          where: { id: inputLine.variantId },
        });

        const rand = Math.floor(1000 + Math.random() * 9000);
        await tx.purchaseLine.create({
          data: {
            variantId: inputLine.variantId,
            branchId: sale.branchId,
            businessId,
            batchNumber: `SR-BATCH-${rand}`,
            quantityPurchased: inputLine.quantityReturned,
            quantityRemaining: inputLine.quantityReturned,
            purchasePrice: variant?.purchasePrice || unitPrice,
            sellingPrice: variant?.sellingPrice || unitPrice,
          },
        });
      }

      // 2. Financial Ledger Adjustments
      let refundAmount = 0;
      let creditNoteAmount = 0;

      const saleDue = sale.grandTotal - sale.amountPaid;

      if (saleDue > 0) {
        // Reduce sale grandTotal or unpaid balance
        if (grandTotal <= saleDue) {
          await tx.sale.update({
            where: { id: sale.id },
            data: {
              grandTotal: { decrement: grandTotal },
            },
          });
        } else {
          const excess = grandTotal - saleDue;
          await tx.sale.update({
            where: { id: sale.id },
            data: {
              grandTotal: sale.amountPaid,
              paymentStatus: 'PAID',
            },
          });

          if (refundType === 'CREDIT_NOTE') {
            creditNoteAmount = excess;
          } else {
            refundAmount = excess;
          }
        }
      } else {
        // Invoice was fully paid
        if (refundType === 'CREDIT_NOTE') {
          creditNoteAmount = grandTotal;
        } else {
          refundAmount = grandTotal;
        }
      }

      // 3. Create CustomerAdvance Credit Note if creditNoteAmount > 0
      if (creditNoteAmount > 0) {
        const advYear = new Date().getFullYear();
        const lastAdv = await tx.customerAdvance.findFirst({
          where: { businessId, advanceNumber: { startsWith: `CADV-${advYear}-` } },
          orderBy: { advanceNumber: 'desc' },
        });

        let advSeq = 1;
        if (lastAdv) {
          const parts = lastAdv.advanceNumber.split('-');
          const lastSeq = parseInt(parts[parts.length - 1], 10);
          if (!isNaN(lastSeq)) advSeq = lastSeq + 1;
        }
        const advanceNumber = `CADV-${advYear}-${String(advSeq).padStart(4, '0')}`;

        const defaultPm = await tx.paymentMethod.findFirst({ where: { businessId } });
        if (defaultPm) {
          await tx.customerAdvance.create({
            data: {
              advanceNumber,
              advanceDate: returnDate ? new Date(returnDate) : new Date(),
              customerId: sale.customerId,
              paymentMethodId: defaultPm.id,
              branchId: sale.branchId,
              businessId,
              amount: creditNoteAmount,
              amountRemaining: creditNoteAmount,
              notes: `Credit note generated from Sales Return ${returnNumber}`,
              createdById: createdById || null,
            },
          });
        }
      }

      // 4. Create SalesReturn & SalesReturnLine
      const salesReturn = await tx.salesReturn.create({
        data: {
          returnNumber,
          returnDate: returnDate ? new Date(returnDate) : new Date(),
          saleId: sale.id,
          customerId: sale.customerId,
          branchId: sale.branchId,
          businessId,
          subtotal,
          taxTotal,
          grandTotal,
          refundAmount,
          creditNoteAmount,
          reason: reason?.trim() || null,
          notes: notes?.trim() || null,
          createdById: createdById || null,
        },
      });

      for (const line of linesToCreate) {
        await tx.salesReturnLine.create({
          data: {
            salesReturnId: salesReturn.id,
            saleLineId: line.saleLineId || null,
            variantId: line.variantId,
            quantityReturned: line.quantityReturned,
            unitPrice: line.unitPrice,
            taxAmount: line.taxAmount,
            subtotal: line.subtotal,
            branchId: sale.branchId,
            businessId,
          },
        });
      }

      return salesReturn;
    });
  }

  async getSalesReturns(
    businessId: string,
    filters: {
      branchId?: string;
      customerId?: string;
      search?: string;
      page?: number;
      limit?: number;
    },
  ) {
    const { branchId, customerId, search, page = 1, limit = 10 } = filters;
    const skip = (page - 1) * limit;

    const whereClause: any = { businessId };

    if (branchId) {
      whereClause.branchId = branchId;
    }

    if (customerId) {
      whereClause.customerId = customerId;
    }

    if (search) {
      whereClause.OR = [
        { returnNumber: { contains: search, mode: 'insensitive' } },
        { sale: { invoiceNumber: { contains: search, mode: 'insensitive' } } },
        { customer: { name: { contains: search, mode: 'insensitive' } } },
      ];
    }

    const [total, data] = await Promise.all([
      this.prisma.salesReturn.count({ where: whereClause }),
      this.prisma.salesReturn.findMany({
        where: whereClause,
        include: {
          sale: {
            select: { id: true, invoiceNumber: true, grandTotal: true },
          },
          customer: {
            select: { id: true, name: true, phone: true },
          },
          branch: {
            select: { id: true, name: true },
          },
          createdBy: {
            select: { id: true, name: true, email: true },
          },
          returnLines: {
            include: {
              variant: {
                select: {
                  id: true,
                  name: true,
                  sku: true,
                  product: {
                    select: { id: true, name: true },
                  },
                },
              },
            },
          },
        },
        orderBy: { returnDate: 'desc' },
        skip,
        take: limit,
      }),
    ]);

    return {
      data,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getSalesReturnById(id: string, businessId: string) {
    const returnItem = await this.prisma.salesReturn.findFirst({
      where: { id, businessId },
      include: {
        sale: {
          include: {
            saleLines: {
              include: {
                variant: true,
              },
            },
          },
        },
        customer: true,
        branch: true,
        createdBy: {
          select: { id: true, name: true, email: true },
        },
        returnLines: {
          include: {
            variant: {
              include: {
                product: true,
              },
            },
          },
        },
      },
    });

    if (!returnItem) {
      throw new NotFoundException('Sales return record not found.');
    }

    return returnItem;
  }
}
