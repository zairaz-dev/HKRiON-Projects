import React from "react";
import {
  ShoppingBag,
  Package,
  Printer,
  TrendingUp,
  TrendingDown,
  DollarSign,
  FileText
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSalesPurchasesQuery } from "../hooks/use-sales-purchases";
import { useCurrency } from "@/hooks/use-currency";

interface SalesPurchasesViewProps {
  businessId: string;
  startDate?: string;
  endDate?: string;
  branchId?: string;
}

export function SalesPurchasesView({
  businessId,
  startDate,
  endDate,
  branchId,
}: SalesPurchasesViewProps) {
  const { symbol } = useCurrency(businessId);
  const { data, isLoading } = useSalesPurchasesQuery(businessId, {
    startDate,
    endDate,
    branchId,
  });

  const handlePrint = () => {
    window.print();
  };

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="text-center space-y-2">
          <div className="w-8 h-8 border-4 border-zinc-700 border-t-emerald-500 rounded-full animate-spin mx-auto" />
          <span className="text-sm text-muted-foreground block">Computing Sales vs Purchases Analytics...</span>
        </div>
      </div>
    );
  }

  const { sales = {}, purchases = {}, netSalesOverPurchases = 0 } = data || {};

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Action Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-extrabold tracking-tight flex items-center gap-2">
            <ShoppingBag className="h-5 w-5 text-primary" /> Sales & Purchases Comparative Analytics
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Total sales vs total purchases comparison, invoice counts, fully paid vs outstanding dues.
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handlePrint}
          className="gap-1.5 text-xs h-8"
        >
          <Printer className="h-3.5 w-3.5" /> Print Summary
        </Button>
      </div>

      {/* Net Comparison Highlight */}
      <div className={`p-5 rounded-sm border ${netSalesOverPurchases >= 0 ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400" : "bg-rose-500/10 border-rose-500/30 text-rose-600 dark:text-rose-400"} flex items-center justify-between`}>
        <div className="space-y-0.5">
          <span className="text-[11px] font-bold uppercase tracking-wider block opacity-80">
            Net Sales Over Purchases Margin
          </span>
          <p className="text-2xl font-black font-mono">
            {symbol}{Math.abs(netSalesOverPurchases).toFixed(2)}
          </p>
        </div>
        <div className="flex items-center gap-1.5 font-bold text-xs">
          {netSalesOverPurchases >= 0 ? (
            <>
              <TrendingUp className="h-5 w-5 text-emerald-500" />
              <span>Positive Cash Flow Margin</span>
            </>
          ) : (
            <>
              <TrendingDown className="h-5 w-5 text-rose-500" />
              <span>Purchases Exceeded Sales</span>
            </>
          )}
        </div>
      </div>

      {/* Comparative Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Sales Summary Side */}
        <div className="bg-card border border-border/60 rounded-sm p-5 space-y-4 shadow-sm">
          <div className="flex items-center justify-between border-b border-border pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-sm bg-emerald-500/10 text-emerald-500 flex items-center justify-center font-bold">
                <ShoppingBag className="h-4 w-4" />
              </div>
              <div>
                <h3 className="font-bold text-foreground text-sm">Sales Summary</h3>
                <span className="text-[10px] text-muted-foreground">{sales.totalInvoices || 0} Invoices Issued</span>
              </div>
            </div>
            <span className="text-xl font-black font-mono text-emerald-500">
              {symbol}{sales.totalAmount?.toFixed(2) || "0.00"}
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex justify-between items-center bg-muted/20 p-2.5 rounded-sm border border-border/40">
              <span className="text-muted-foreground">Fully Paid Amount:</span>
              <span className="font-mono font-bold text-emerald-500">{symbol}{sales.fullyPaidAmount?.toFixed(2) || "0.00"}</span>
            </div>

            <div className="flex justify-between items-center bg-muted/20 p-2.5 rounded-sm border border-border/40">
              <span className="text-muted-foreground">Outstanding Customer Dues:</span>
              <span className="font-mono font-bold text-amber-500">{symbol}{sales.outstandingDue?.toFixed(2) || "0.00"}</span>
            </div>
          </div>
        </div>

        {/* Purchases Summary Side */}
        <div className="bg-card border border-border/60 rounded-sm p-5 space-y-4 shadow-sm">
          <div className="flex items-center justify-between border-b border-border pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-sm bg-indigo-500/10 text-indigo-500 flex items-center justify-center font-bold">
                <Package className="h-4 w-4" />
              </div>
              <div>
                <h3 className="font-bold text-foreground text-sm">Purchases Summary</h3>
                <span className="text-[10px] text-muted-foreground">{purchases.totalInvoices || 0} Invoices Received</span>
              </div>
            </div>
            <span className="text-xl font-black font-mono text-indigo-500">
              {symbol}{purchases.totalAmount?.toFixed(2) || "0.00"}
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex justify-between items-center bg-muted/20 p-2.5 rounded-sm border border-border/40">
              <span className="text-muted-foreground">Fully Paid Amount:</span>
              <span className="font-mono font-bold text-indigo-500">{symbol}{purchases.fullyPaidAmount?.toFixed(2) || "0.00"}</span>
            </div>

            <div className="flex justify-between items-center bg-muted/20 p-2.5 rounded-sm border border-border/40">
              <span className="text-muted-foreground">Outstanding Supplier Dues:</span>
              <span className="font-mono font-bold text-rose-500">{symbol}{purchases.outstandingDue?.toFixed(2) || "0.00"}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
