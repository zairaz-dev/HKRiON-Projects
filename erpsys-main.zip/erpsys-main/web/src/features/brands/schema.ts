import * as z from "zod";

export const brandFormSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, "Brand name must be at least 2 characters")
    .max(100, "Brand name must be under 100 characters"),
  description: z
    .string()
    .max(500, "Description cannot exceed 500 characters")
    .optional()
    .or(z.literal("")),
  branchIds: z.array(z.string()),
  logoUrl: z
    .string()
    .url("Must be a valid URL")
    .or(z.literal("")),
  logoFile: z.any().nullable().optional(),
  isActive: z.boolean(),
  logoUploadType: z.enum(["url", "file"]),
});

export type BrandFormSchema = z.infer<typeof brandFormSchema>;
