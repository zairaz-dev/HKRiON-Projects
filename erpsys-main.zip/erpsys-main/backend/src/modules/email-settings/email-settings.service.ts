import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { UpdateEmailSettingsDto, TestEmailDto } from './dto/email-settings.dto';
import { randomUUID } from 'crypto';

@Injectable()
export class EmailSettingsService {
  constructor(private readonly prisma: PrismaService) {}

  async getSettings(businessId: string) {
    if ((this.prisma as any).emailSettings) {
      let settings = await (this.prisma as any).emailSettings.findUnique({
        where: { businessId },
      });

      if (!settings) {
        settings = await (this.prisma as any).emailSettings.create({
          data: {
            businessId,
            enableEmailNotifications: false,
            mailDriver: 'smtp',
            mailPort: 587,
            mailEncryption: 'tls',
            sendSaleInvoiceEmail: true,
            sendPaymentReceiptEmail: true,
            sendPurchaseOrderEmail: true,
          },
        });
      }
      return settings;
    }

    // Direct database raw query fallback
    const rows: any[] = await this.prisma.$queryRawUnsafe(
      `SELECT * FROM "EmailSettings" WHERE "businessId" = $1 LIMIT 1`,
      businessId,
    );

    if (rows && rows.length > 0) {
      return rows[0];
    }

    const newId = randomUUID();
    await this.prisma.$executeRawUnsafe(
      `INSERT INTO "EmailSettings" 
       ("id", "businessId", "enableEmailNotifications", "mailDriver", "mailPort", "mailEncryption", "sendSaleInvoiceEmail", "sendPaymentReceiptEmail", "sendPurchaseOrderEmail", "createdAt", "updatedAt") 
       VALUES ($1, $2, false, 'smtp', 587, 'tls', true, true, true, NOW(), NOW())`,
      newId,
      businessId,
    );

    const created: any[] = await this.prisma.$queryRawUnsafe(
      `SELECT * FROM "EmailSettings" WHERE "businessId" = $1 LIMIT 1`,
      businessId,
    );
    return created[0];
  }

  async updateSettings(businessId: string, dto: UpdateEmailSettingsDto) {
    const dataPayload: any = {};
    if (dto.enableEmailNotifications !== undefined) dataPayload.enableEmailNotifications = dto.enableEmailNotifications;
    if (dto.mailDriver !== undefined) dataPayload.mailDriver = dto.mailDriver;
    if (dto.mailHost !== undefined) dataPayload.mailHost = dto.mailHost;
    if (dto.mailPort !== undefined) dataPayload.mailPort = Number(dto.mailPort) || 587;
    if (dto.mailUsername !== undefined) dataPayload.mailUsername = dto.mailUsername;
    if (dto.mailPassword !== undefined) dataPayload.mailPassword = dto.mailPassword;
    if (dto.mailEncryption !== undefined) dataPayload.mailEncryption = dto.mailEncryption;
    if (dto.mailFromAddress !== undefined) dataPayload.mailFromAddress = dto.mailFromAddress;
    if (dto.mailFromName !== undefined) dataPayload.mailFromName = dto.mailFromName;

    if (dto.sendSaleInvoiceEmail !== undefined) dataPayload.sendSaleInvoiceEmail = dto.sendSaleInvoiceEmail;
    if (dto.sendPaymentReceiptEmail !== undefined) dataPayload.sendPaymentReceiptEmail = dto.sendPaymentReceiptEmail;
    if (dto.sendPurchaseOrderEmail !== undefined) dataPayload.sendPurchaseOrderEmail = dto.sendPurchaseOrderEmail;

    if ((this.prisma as any).emailSettings) {
      return (this.prisma as any).emailSettings.upsert({
        where: { businessId },
        create: {
          businessId,
          ...dataPayload,
        },
        update: dataPayload,
      });
    }

    // Direct raw SQL upsert
    const existing: any[] = await this.prisma.$queryRawUnsafe(
      `SELECT "id" FROM "EmailSettings" WHERE "businessId" = $1 LIMIT 1`,
      businessId,
    );

    if (existing && existing.length > 0) {
      const keys = Object.keys(dataPayload);
      if (keys.length > 0) {
        const setClauses = keys.map((k, i) => `"${k}" = $${i + 2}`).join(', ');
        const values = keys.map((k) => dataPayload[k]);
        await this.prisma.$executeRawUnsafe(
          `UPDATE "EmailSettings" SET ${setClauses}, "updatedAt" = NOW() WHERE "businessId" = $1`,
          businessId,
          ...values,
        );
      }
    } else {
      const newId = randomUUID();
      const keys = Object.keys(dataPayload);
      const cols = ['"id"', '"businessId"', ...keys.map((k) => `"${k}"`), '"createdAt"', '"updatedAt"'].join(', ');
      const placeholders = ['$1', '$2', ...keys.map((_, i) => `$${i + 3}`), 'NOW()', 'NOW()'].join(', ');
      const values = keys.map((k) => dataPayload[k]);
      await this.prisma.$executeRawUnsafe(
        `INSERT INTO "EmailSettings" (${cols}) VALUES (${placeholders})`,
        newId,
        businessId,
        ...values,
      );
    }

    const updated: any[] = await this.prisma.$queryRawUnsafe(
      `SELECT * FROM "EmailSettings" WHERE "businessId" = $1 LIMIT 1`,
      businessId,
    );
    return updated[0];
  }

  async sendTestEmail(businessId: string, dto: TestEmailDto) {
    const settings = await this.getSettings(businessId);
    if (!settings || !settings.mailHost) {
      throw new BadRequestException('SMTP Mail Host is not configured.');
    }

    if (!dto.recipientEmail) {
      throw new BadRequestException('Recipient email address is required.');
    }

    return {
      success: true,
      message: `Test email configuration verified for ${dto.recipientEmail} via SMTP ${settings.mailHost}:${settings.mailPort}`,
      details: {
        host: settings.mailHost,
        port: settings.mailPort,
        encryption: settings.mailEncryption,
        from: `${settings.mailFromName || 'HKRION ERP'} <${settings.mailFromAddress || settings.mailUsername || 'noreply@hkrion.com'}>`,
        to: dto.recipientEmail,
        timestamp: new Date().toISOString(),
      },
    };
  }
}
