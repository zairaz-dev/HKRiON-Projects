import React, { useState } from "react";
import {
  X,
  Search,
  FileText,
  Building2,
  Calendar,
  User as UserIcon,
  Loader2,
  ArrowRight
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { usePurchasesQuery, usePurchaseDetailQuery } from "../hooks/use-purchases";
import { useCurrency } from "@/hooks/use-currency";

interface SelectPurchaseDialogProps {
  isOpen: boolean;
  onClose: () => void;
  businessId: string;
  onSelectPurchase: (purchase: any) => void;
}

export function SelectPurchaseDialog({
  isOpen,
  onClose,
  businessId,
  onSelectPurchase,
}: SelectPurchaseDialogProps) {
  const { symbol } = useCurrency(businessId);
  const [searchQuery, setSearchQuery] = useState("");
  const [loadingPurchaseId, setLoadingPurchaseId] = useState<string | null>(null);

  const { data: purchasesResponse, isLoading } = usePurchasesQuery(businessId, {
    page: 1,
    limit: 20,
    search: searchQuery || undefined,
  });

  const purchasesList = purchasesResponse?.data || [];

  if (!isOpen) return null;

  const handleSelect = async (p: any) => {
    setLoadingPurchaseId(p.id);
    try {
      // If purchase doesn't have full line items attached, fetch detail
      if (!p.purchaseLines || p.purchaseLines.length === 0) {
        const fullDetail = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/purchases/${p.id}?businessId=${businessId}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`
          }
        }).then(r => r.json());
        onSelectPurchase(fullDetail);
      } else {
        onSelectPurchase(p);
      }
      onClose();
    } catch (err) {
      console.error("Failed to load purchase details", err);
      onSelectPurchase(p);
      onClose();
    } finally {
      setLoadingPurchaseId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
      <div className="w-full max-w-2xl rounded-xl border border-border bg-card p-6 shadow-2xl animate-in zoom-in-95 duration-200 flex flex-col max-h-[85vh] overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border pb-3 mb-4 shrink-0">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-bold">Select Purchase Invoice to Return</h3>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="h-8 w-8 rounded-full"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Search */}
        <div className="relative mb-4 shrink-0">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by Purchase Invoice # or Supplier..."
            className="pl-9 text-xs h-9"
          />
        </div>

        {/* List of Purchase Invoices */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1">
          {isLoading ? (
            <div className="flex h-40 items-center justify-center">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          ) : purchasesList.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground text-xs">
              No purchase invoices found matching "{searchQuery}"
            </div>
          ) : (
            purchasesList.map((p: any) => (
              <div
                key={p.id}
                className="flex items-center justify-between p-3.5 rounded-lg border border-border/60 bg-muted/20 hover:bg-muted/40 transition-colors"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-sm text-foreground">
                      #{p.purchaseNumber}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-secondary text-secondary-foreground font-semibold">
                      {new Date(p.purchaseDate).toLocaleDateString("en-IN", {
                        day: "2-digit",
                        month: "short",
                        year: "numeric"
                      })}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1 font-medium text-foreground">
                      <UserIcon className="h-3 w-3 text-primary" /> {p.supplier?.name}
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Building2 className="h-3 w-3" /> {p.branch?.name}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[10px] text-muted-foreground block uppercase font-bold">Total Amount</span>
                    <span className="font-bold font-mono text-sm text-foreground">
                      {symbol}{p.grandTotal?.toFixed(2)}
                    </span>
                  </div>

                  <Button
                    size="sm"
                    disabled={loadingPurchaseId === p.id}
                    onClick={() => handleSelect(p)}
                    className="h-8 text-xs gap-1"
                  >
                    {loadingPurchaseId === p.id ? (
                      <Loader2 className="h-3 w-3 animate-spin" />
                    ) : (
                      <>
                        Select <ArrowRight className="h-3 w-3" />
                      </>
                    )}
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-border pt-3 mt-3 shrink-0 flex justify-end">
          <Button variant="outline" size="sm" onClick={onClose} className="h-8 text-xs">
            Cancel
          </Button>
        </div>
      </div>
    </div>
  );
}
