import { Module } from '@nestjs/common';
import { PhoneCodeService } from './phone-code.service';
import { PhoneCodeController } from './phone-code.controller';

@Module({
  controllers: [PhoneCodeController],
  providers: [PhoneCodeService],
  exports: [PhoneCodeService],
})
export class PhoneCodeModule {}
