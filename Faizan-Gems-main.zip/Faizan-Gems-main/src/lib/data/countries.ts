import {
  getCountries,
  getCountryCallingCode,
  getExampleNumber,
  type CountryCode,
  validatePhoneNumberLength,
} from "libphonenumber-js";
import examples from "libphonenumber-js/mobile/examples";

// ---------------------------------------------------------------------------
// Core: Dynamic country list generated from libphonenumber-js metadata
// ---------------------------------------------------------------------------

export interface CountryItem {
  code: string;
  name: string;
  flag: string;
  phoneCode?: string;
}

/** Convert an ISO 3166-1 alpha-2 code to its flag emoji (e.g. "US" → 🇺🇸) */
function codeToFlag(code: string): string {
  return String.fromCodePoint(
    ...[...code.toUpperCase()].map((c) => 0x1f1e6 + c.charCodeAt(0) - 65)
  );
}

/** Resolve a human-readable country name from an ISO code using Intl API */
const displayNames = new Intl.DisplayNames(["en"], { type: "region" });
function codeToName(code: string): string {
  try {
    return displayNames.of(code) || code;
  } catch {
    return code;
  }
}

/** Top luxury & gemstone market codes — pinned to the top of dropdowns */
const PINNED_CODES: string[] = [
  "US", "GB", "AE", "JP", "LK", "SG", "CH", "AU", "CA",
  "DE", "FR", "IT", "IN", "HK", "QA", "SA", "KW", "BH", "OM",
];

/** Build the full country list dynamically from libphonenumber-js metadata */
function buildCountries(): CountryItem[] {
  const allCodes = getCountries(); // ~245 ISO country codes
  const pinnedSet = new Set(PINNED_CODES);

  const toItem = (code: string): CountryItem => {
    let phoneCode: string | undefined;
    try {
      phoneCode = `+${getCountryCallingCode(code as CountryCode)}`;
    } catch {
      // Some codes (e.g. AC) may not have a calling code
    }
    return {
      code,
      name: codeToName(code),
      flag: codeToFlag(code),
      phoneCode,
    };
  };

  const pinned = PINNED_CODES.filter((c) => allCodes.includes(c as CountryCode)).map(toItem);
  const rest = allCodes
    .filter((c) => !pinnedSet.has(c))
    .map(toItem)
    .sort((a, b) => a.name.localeCompare(b.name));

  return [...pinned, ...rest];
}

export const COUNTRIES: CountryItem[] = buildCountries();

// ---------------------------------------------------------------------------
// Derived options for dropdowns
// ---------------------------------------------------------------------------

export const COUNTRY_OPTIONS = COUNTRIES.map((c) => ({
  value: c.name,
  label: c.name,
}));

export const PHONE_CODE_OPTIONS = COUNTRIES
  .filter((c) => c.phoneCode)
  .map((c) => ({
    value: c.code,
    label: `${c.flag} ${c.phoneCode}`,
    sublabel: c.name,
  }));

// ---------------------------------------------------------------------------
// Phone code helpers
// ---------------------------------------------------------------------------

export function getPhoneCodeByCountryCode(countryCode: string): string {
  try {
    return `+${getCountryCallingCode(countryCode as CountryCode)}`;
  } catch {
    return "+1";
  }
}

// ---------------------------------------------------------------------------
// Phone format: dynamic placeholder & validation via libphonenumber-js
// ---------------------------------------------------------------------------

export interface PhoneFormat {
  placeholder: string;
  validate: (digits: string) => boolean;
}

export function getPhoneFormat(countryCode: string): PhoneFormat {
  const cc = countryCode as CountryCode;
  let placeholder = "123 456 7890";
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const example = getExampleNumber(cc, examples as any);
    if (example) {
      // Format as national number, then strip trunk prefix (leading 0)
      // so user sees "71 234 5678" instead of "071 234 5678"
      const national = example.formatNational();
      placeholder = national.replace(/^0+\s*/, "").replace(/[()]/g, "").replace(/-/g, " ") || placeholder;
    }
  } catch {
    // Fallback for unrecognized country codes
  }

  return {
    placeholder,
    validate: (digits: string) => {
      if (digits.length < 4 || digits.length > 15) return false;
      const result = validatePhoneNumberLength(digits, cc);
      // undefined means valid, anything else is an error
      return result === undefined;
    },
  };
}

// ---------------------------------------------------------------------------
// Utility helpers
// ---------------------------------------------------------------------------

export function isSriLanka(countryNameOrCode?: string | null): boolean {
  if (!countryNameOrCode) return false;
  const normalized = countryNameOrCode.trim().toLowerCase();
  return (
    normalized === "sri lanka" ||
    normalized === "lk" ||
    normalized === "ceylon" ||
    normalized.includes("sri lanka")
  );
}

export function getCountryFlag(countryNameOrCode?: string | null): string {
  if (!countryNameOrCode) return "";
  const normalized = countryNameOrCode.trim().toLowerCase();
  const match = COUNTRIES.find(
    (c) =>
      c.name.toLowerCase() === normalized ||
      c.code.toLowerCase() === normalized ||
      normalized.includes(c.name.toLowerCase())
  );
  return match ? match.flag : "";
}

export function normalizeCountryName(countryNameOrCode?: string | null): string {
  if (!countryNameOrCode) return "United States";
  const normalized = countryNameOrCode.trim().toLowerCase();
  const match = COUNTRIES.find(
    (c) =>
      c.name.toLowerCase() === normalized ||
      c.code.toLowerCase() === normalized
  );
  return match ? match.name : countryNameOrCode.trim();
}
