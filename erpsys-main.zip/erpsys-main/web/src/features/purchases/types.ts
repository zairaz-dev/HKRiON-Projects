export interface PurchaseLineInputItem {
  variantId: string;
  quantityPurchased: number;
  purchasePrice: number;
  sellingPrice: number;
  batchNumber?: string;
  expiryDate?: string;
  // For frontend UI tracking
  variantName?: string;
  sku?: string;
}

export interface PurchaseItem {
  id: string;
  purchaseNumber: string;
  purchaseDate: string;
  status: "ORDERED" | "PENDING" | "RECEIVED";
  supplierId: string;
  supplier?: {
    id: string;
    name: string;
    businessName: string | null;
  };
  branchId: string;
  branch?: {
    id: string;
    name: string;
  };
  grandTotal: number;
  amountPaid: number;
  discountType?: "FIXED" | "PERCENTAGE" | null;
  discountAmount?: number;
  shippingAmount?: number;
  taxAmount?: number;
  paymentStatus: "DUE" | "PARTIAL" | "PAID";
  notes: string | null;
  payments?: {
    id: string;
    paymentNumber: string;
    paymentDate: string;
    amount: number;
    transactionNo: string | null;
    notes: string | null;
    paymentMethod: {
      id: string;
      name: string;
      code: string;
    };
  }[];
  purchaseLines: {
    id: string;
    variantId: string;
    variant: {
      id: string;
      name: string;
      sku: string;
      product: {
        id: string;
        name: string;
      };
    };
    quantityPurchased: number;
    quantityRemaining: number;
    purchasePrice: number;
    sellingPrice: number;
    batchNumber: string | null;
    expiryDate: string | null;
  }[];
}
