import { Module } from '@nestjs/common';
import { SuperSettingsController } from './super-settings.controller';
import { SuperSettingsService } from './super-settings.service';
import { PrismaService } from '../prisma/prisma.service';

@Module({
  controllers: [SuperSettingsController],
  providers: [SuperSettingsService, PrismaService],
  exports: [SuperSettingsService],
})
export class SuperSettingsModule {}
