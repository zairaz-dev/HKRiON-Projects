"use client";

import React, { useEffect, useState, Suspense, useRef } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Building2,
  ChevronLeft,
  Loader2,
  CheckCircle,
  AlertCircle,
  Save,
  Upload,
  Image as ImageIcon,
  X,
  MapPin,
  FileText,
  Sliders,
  DollarSign,
  Percent,
  Calendar,
  Clock,
  Globe,
  Phone,
  Mail,
  ShieldCheck,
  Hash,
  Briefcase,
  CheckCircle2,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { authService } from "@/services/auth-service";
import { lookupService } from "@/services/lookup-service";
import { businessService } from "@/services/business-service";
import { User, Country, Currency, PhoneCode } from "@hkr/types";
import { cn, getFullAssetUrl } from "@/lib/utils";

import {
  businessSettingsSchema,
  BusinessSettingsFormData,
  useBusinessQuery,
  useUpdateBusinessMutation
} from "@/features/business";

type SettingsTab = "general" | "contact" | "tax" | "financial";

function BusinessSettingsPageContent() {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [activeTab, setActiveTab] = useState<SettingsTab>("general");
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Geographic lookups state
  const [countries, setCountries] = useState<Country[]>([]);
  const [currencies, setCurrencies] = useState<Currency[]>([]);
  const [phoneCodes, setPhoneCodes] = useState<PhoneCode[]>([]);

  // Notifications
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Logo upload state
  const [logoPreview, setLogoPreview] = useState<string>("");
  const [isUploadingLogo, setIsUploadingLogo] = useState<boolean>(false);

  // Authenticate & Load Lookups
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
      return;
    }

    const loadGeographicData = async () => {
      try {
        const [cList, curList, pList] = await Promise.all([
          lookupService.getCountries(),
          lookupService.getCurrencies(),
          lookupService.getPhoneCodes(),
        ]);
        setCountries(cList);
        setCurrencies(curList);
        setPhoneCodes(pList);
      } catch (err: any) {
        console.error("Failed to load geographic options", err);
      }
    };

    loadGeographicData();
  }, []);

  const businessId = currentUser?.businessId || "";

  // Fetch Business details via Query
  const { data: businessData, isLoading: isQueryLoading, refetch } = useBusinessQuery(businessId);
  const updateBusinessMutation = useUpdateBusinessMutation();

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    watch,
    formState: { errors },
  } = useForm<BusinessSettingsFormData>({
    resolver: zodResolver(businessSettingsSchema) as any,
    defaultValues: {
      name: "",
      industry: "",
      phone: "",
      phoneCodeId: "",
      countryId: "",
      currencyId: "",
      logo: "",
      registrationNumber: "",
      email: "",
      website: "",
      alternatePhone: "",
      address: "",
      city: "",
      state: "",
      postalCode: "",
      taxNumber: "",
      taxName: "",
      isTaxEnabled: true,
      financialYearStartMonth: 1,
      stockAccountingMethod: "FIFO",
      timezone: "Asia/Colombo",
      dateFormat: "DD/MM/YYYY",
      currencySymbolPlacement: "before",
      decimalPrecision: 2,
    },
  });

  const isTaxEnabled = watch("isTaxEnabled");

  // Reset form once business details load
  useEffect(() => {
    if (businessData) {
      reset({
        name: businessData.name || "",
        industry: businessData.industry || "",
        phone: businessData.phone || "",
        phoneCodeId: businessData.phoneCodeId || "",
        countryId: businessData.countryId || "",
        currencyId: businessData.currencyId || "",
        logo: businessData.logo || "",
        registrationNumber: businessData.registrationNumber || "",
        email: businessData.email || "",
        website: businessData.website || "",
        alternatePhone: businessData.alternatePhone || "",
        address: businessData.address || "",
        city: businessData.city || "",
        state: businessData.state || "",
        postalCode: businessData.postalCode || "",
        taxNumber: businessData.taxNumber || "",
        taxName: businessData.taxName || "",
        isTaxEnabled: businessData.isTaxEnabled !== false,
        financialYearStartMonth: businessData.financialYearStartMonth || 1,
        stockAccountingMethod: businessData.stockAccountingMethod || "FIFO",
        timezone: businessData.timezone || "Asia/Colombo",
        dateFormat: businessData.dateFormat || "DD/MM/YYYY",
        currencySymbolPlacement: businessData.currencySymbolPlacement || "before",
        decimalPrecision: businessData.decimalPrecision ?? 2,
      });

      if (businessData.logo) {
        setLogoPreview(getFullAssetUrl(businessData.logo) || businessData.logo);
      }
    }
  }, [businessData, reset]);

  // Auto-dismiss notifications
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  // Handle Logo Upload
  const handleLogoFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !businessId) return;

    // Show local preview immediately
    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      setLogoPreview(uploadEvent.target?.result as string);
    };
    reader.readAsDataURL(file);

    try {
      setIsUploadingLogo(true);
      const res = await businessService.uploadLogo(businessId, file);
      setValue("logo", res.logoUrl);
      setSuccessMessage("Business logo uploaded successfully!");
      refetch();
    } catch (err: any) {
      setError(err.message || "Failed to upload logo.");
    } finally {
      setIsUploadingLogo(false);
    }
  };

  const handleRemoveLogo = () => {
    setLogoPreview("");
    setValue("logo", "");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const onSubmit = async (data: BusinessSettingsFormData) => {
    if (!businessId || !currentUser) return;

    try {
      await updateBusinessMutation.mutateAsync({
        id: businessId,
        data: {
          name: data.name.trim(),
          industry: data.industry.trim(),
          phone: data.phone.trim(),
          phoneCodeId: data.phoneCodeId,
          countryId: data.countryId,
          currencyId: data.currencyId,
          logo: data.logo || null,
          registrationNumber: data.registrationNumber?.trim() || null,
          email: data.email?.trim() || null,
          website: data.website?.trim() || null,
          alternatePhone: data.alternatePhone?.trim() || null,
          address: data.address?.trim() || null,
          city: data.city?.trim() || null,
          state: data.state?.trim() || null,
          postalCode: data.postalCode?.trim() || null,
          taxNumber: data.taxNumber?.trim() || null,
          taxName: data.taxName?.trim() || null,
          isTaxEnabled: data.isTaxEnabled,
          financialYearStartMonth: data.financialYearStartMonth ? Number(data.financialYearStartMonth) : 1,
          stockAccountingMethod: data.stockAccountingMethod || "FIFO",
          timezone: data.timezone || "Asia/Colombo",
          dateFormat: data.dateFormat || "DD/MM/YYYY",
          currencySymbolPlacement: data.currencySymbolPlacement || "before",
          decimalPrecision: data.decimalPrecision !== undefined && data.decimalPrecision !== null ? Number(data.decimalPrecision) : 2,
          updatedById: currentUser.id,
        },
      });
      setSuccessMessage("Business settings updated successfully!");
    } catch (err: any) {
      setError(err.message || "Failed to update business settings.");
    }
  };

  const isFormLoading = isQueryLoading || updateBusinessMutation.isPending;

  if (isAuthenticated === null || !currentUser) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const months = [
    { value: 1, label: "January" },
    { value: 2, label: "February" },
    { value: 3, label: "March" },
    { value: 4, label: "April" },
    { value: 5, label: "May" },
    { value: 6, label: "June" },
    { value: 7, label: "July" },
    { value: 8, label: "August" },
    { value: 9, label: "September" },
    { value: 10, label: "October" },
    { value: 11, label: "November" },
    { value: 12, label: "December" },
  ];

  const timezones = [
    { value: "Asia/Colombo", label: "Asia/Colombo (Sri Lanka Time, GMT+5:30)" },
    { value: "Asia/Kolkata", label: "Asia/Kolkata (India Standard Time, GMT+5:30)" },
    { value: "Asia/Dubai", label: "Asia/Dubai (Gulf Standard Time, GMT+4:00)" },
    { value: "Asia/Singapore", label: "Asia/Singapore (Singapore Time, GMT+8:00)" },
    { value: "Europe/London", label: "Europe/London (GMT/BST)" },
    { value: "America/New_York", label: "America/New_York (Eastern Time, GMT-5:00)" },
    { value: "UTC", label: "UTC (Coordinated Universal Time)" },
  ];

  const dateFormats = [
    { value: "DD/MM/YYYY", label: "DD/MM/YYYY (e.g. 01/09/2026)" },
    { value: "MM/DD/YYYY", label: "MM/DD/YYYY (e.g. 09/01/2026)" },
    { value: "YYYY-MM-DD", label: "YYYY-MM-DD (e.g. 2026-09-01)" },
    { value: "DD-MMM-YYYY", label: "DD-MMM-YYYY (e.g. 01-Sep-2026)" },
  ];

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/settings" />
      <div className="flex-1 flex flex-col overflow-hidden relative">
        <Navbar title="Business Settings" />

        {/* Full Width Main Container matching User Profile Page */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Notifications */}
          {successMessage && (
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 rounded-sm text-xs flex items-center gap-2 animate-in fade-in-50">
              <CheckCircle className="w-4 h-4 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}
          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 text-rose-500 rounded-sm text-xs flex items-center gap-2 animate-in fade-in-50">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Navigation / Header Actions (Exact User Profile Page Style) */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border pb-4">
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => router.push("/settings")}
                className="h-8 px-2.5 rounded-sm border-border hover:bg-secondary/40 text-xs font-mono"
              >
                <ChevronLeft className="w-3.5 h-3.5 mr-1" /> Back to Settings
              </Button>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-base sm:text-lg font-bold uppercase tracking-wider font-mono text-foreground flex items-center gap-2">
                    <Building2 className="h-5 w-5 text-primary" /> Business Settings
                  </h1>
                  {businessData?.id && (
                    <span className="text-[10px] text-muted-foreground font-mono">
                      #{businessData.id.substring(0, 8)}
                    </span>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  Configure enterprise credentials, branding, tax profile, addresses, and system preferences.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button
                onClick={handleSubmit(onSubmit)}
                disabled={isFormLoading}
                className="h-8 px-4 rounded-sm bg-primary text-primary-foreground hover:bg-primary/90 text-xs font-mono font-bold uppercase tracking-wider gap-1.5 shadow-sm cursor-pointer"
              >
                {isFormLoading ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Save className="w-3.5 h-3.5" />
                )}
                Save All Changes
              </Button>
            </div>
          </div>

          {/* Main Business Hero Banner Card (Exact User Profile Hero Style) */}
          <Card className="border border-border/70 bg-gradient-to-r from-card to-background/50 overflow-hidden shadow-sm">
            <CardContent className="p-5 sm:p-6">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                <div className="flex items-center gap-4 sm:gap-5">
                  {/* Circle Logo Container */}
                  <div className="relative shrink-0">
                    <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full border-2 border-primary/30 bg-secondary/40 overflow-hidden flex items-center justify-center shadow-md">
                      {logoPreview ? (
                        <img
                          src={logoPreview}
                          alt={businessData?.name || "Business Logo"}
                          className="w-full h-full object-contain p-2.5"
                          onError={() => setLogoPreview("")}
                        />
                      ) : (
                        <div className="text-2xl sm:text-3xl font-black text-primary uppercase font-mono">
                          {(businessData?.name || "BS").substring(0, 2)}
                        </div>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="absolute bottom-0.5 right-0.5 w-6 h-6 rounded-full bg-primary text-primary-foreground hover:bg-primary/90 flex items-center justify-center shadow-md cursor-pointer transition-transform hover:scale-110"
                      title="Upload Logo"
                    >
                      <Upload className="w-3 h-3" />
                    </button>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="text-lg sm:text-xl font-bold text-foreground font-mono">
                        {businessData?.name || "HKR System Business"}
                      </h2>
                      {businessData?.industry && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-sm border uppercase font-mono tracking-wider bg-primary/10 text-primary border-primary/25">
                          {businessData.industry}
                        </span>
                      )}
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-sm border uppercase font-mono tracking-wider bg-emerald-500/10 text-emerald-400 border-emerald-500/30">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Active System
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-y-1 gap-x-4 text-xs text-muted-foreground font-mono">
                      {businessData?.email && (
                        <div className="flex items-center gap-1.5">
                          <Mail className="w-3.5 h-3.5 text-primary/70" />
                          <span>{businessData.email}</span>
                        </div>
                      )}
                      {businessData?.phone && (
                        <div className="flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-primary/70" />
                          <span>{businessData.phone}</span>
                        </div>
                      )}
                      {businessData?.country && (
                        <div className="flex items-center gap-1.5">
                          <Globe className="w-3.5 h-3.5 text-primary/70" />
                          <span>{businessData.country.name}</span>
                        </div>
                      )}
                      {businessData?.currency && (
                        <div className="flex items-center gap-1.5">
                          <DollarSign className="w-3.5 h-3.5 text-primary/70" />
                          <span>{businessData.currency.code} ({businessData.currency.symbol})</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex md:flex-col items-end gap-1.5 text-right w-full md:w-auto pt-3 md:pt-0 border-t md:border-t-0 border-border">
                  <span className="text-[10px] text-muted-foreground font-mono uppercase tracking-wider">
                    Registration No
                  </span>
                  <span className="text-xs font-mono font-semibold text-foreground">
                    {businessData?.registrationNumber || "Not Specified"}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Full Width Navigation Tabs */}
          <div className="flex items-center gap-2 border-b border-border overflow-x-auto scrollbar-none pb-px w-full">
            <button
              type="button"
              onClick={() => setActiveTab("general")}
              className={cn(
                "flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-bold uppercase tracking-wider rounded-t-sm border-b-2 transition-all cursor-pointer whitespace-nowrap",
                activeTab === "general"
                  ? "border-primary text-primary bg-primary/5"
                  : "border-transparent text-muted-foreground hover:text-foreground hover:bg-card/40"
              )}
            >
              <Building2 className="w-4 h-4" />
              <span>General & Branding</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("contact")}
              className={cn(
                "flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-bold uppercase tracking-wider rounded-t-sm border-b-2 transition-all cursor-pointer whitespace-nowrap",
                activeTab === "contact"
                  ? "border-primary text-primary bg-primary/5"
                  : "border-transparent text-muted-foreground hover:text-foreground hover:bg-card/40"
              )}
            >
              <MapPin className="w-4 h-4" />
              <span>Contact & Location</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("tax")}
              className={cn(
                "flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-bold uppercase tracking-wider rounded-t-sm border-b-2 transition-all cursor-pointer whitespace-nowrap",
                activeTab === "tax"
                  ? "border-primary text-primary bg-primary/5"
                  : "border-transparent text-muted-foreground hover:text-foreground hover:bg-card/40"
              )}
            >
              <Percent className="w-4 h-4" />
              <span>Tax & Legal</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("financial")}
              className={cn(
                "flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-bold uppercase tracking-wider rounded-t-sm border-b-2 transition-all cursor-pointer whitespace-nowrap",
                activeTab === "financial"
                  ? "border-primary text-primary bg-primary/5"
                  : "border-transparent text-muted-foreground hover:text-foreground hover:bg-card/40"
              )}
            >
              <DollarSign className="w-4 h-4" />
              <span>Financial Preferences</span>
            </button>
          </div>

          {/* Settings Form Card (Spans Full Width w-full) */}
          <Card className="border border-border bg-card/60 w-full shadow-sm">
            <CardContent className="p-5 sm:p-6">
              {isQueryLoading ? (
                <div className="py-20 flex flex-col items-center justify-center text-muted-foreground">
                  <Loader2 className="h-8 w-8 animate-spin text-primary mb-3" />
                  <p className="text-sm font-mono">Loading business configuration...</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                  {/* ========================================================= */}
                  {/* TAB 1: GENERAL & BRANDING */}
                  {/* ========================================================= */}
                  {activeTab === "general" && (
                    <div className="space-y-6 animate-in fade-in duration-150">
                      <div>
                        <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-foreground flex items-center gap-2">
                          <Building2 className="w-4 h-4 text-primary" /> Business Identification & Logo
                        </h3>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          Set your official business trade name, industry sector, company logo, and registration ID.
                        </p>
                      </div>

                      {/* Business Logo Card */}
                      <div className="p-4 rounded-sm border border-border bg-card/40 flex flex-col sm:flex-row sm:items-center gap-5">
                        <div className="relative w-24 h-24 rounded-sm border-2 border-dashed border-border flex items-center justify-center bg-secondary/30 shrink-0 overflow-hidden group">
                          {logoPreview ? (
                            <>
                              <img
                                src={logoPreview}
                                alt="Business Logo"
                                className="w-full h-full object-contain p-1"
                                onError={() => setLogoPreview("")}
                              />
                              <button
                                type="button"
                                onClick={handleRemoveLogo}
                                className="absolute top-1 right-1 bg-black/70 hover:bg-rose-600 text-white rounded-full p-1 transition-colors cursor-pointer"
                                title="Remove Logo"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </>
                          ) : (
                            <div className="text-center p-2">
                              <ImageIcon className="w-7 h-7 text-muted-foreground mx-auto mb-1 opacity-60" />
                              <span className="text-[10px] text-muted-foreground block font-mono">No Logo</span>
                            </div>
                          )}

                          {isUploadingLogo && (
                            <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
                              <Loader2 className="w-6 h-6 animate-spin text-primary" />
                            </div>
                          )}
                        </div>

                        <div className="space-y-2 flex-1">
                          <h4 className="text-xs font-bold text-foreground font-mono uppercase">Business Logo Image</h4>
                          <p className="text-xs text-muted-foreground">
                            This logo will appear on your POS checkout receipts, purchase orders, sales invoices, and customer receipts. Recommended size: 300x300px (PNG or SVG).
                          </p>
                          <div className="flex items-center gap-2 pt-1">
                            <input
                              ref={fileInputRef}
                              type="file"
                              accept="image/png, image/jpeg, image/webp, image/svg+xml"
                              onChange={handleLogoFileChange}
                              className="hidden"
                              id="logo-file-upload"
                            />
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => fileInputRef.current?.click()}
                              disabled={isUploadingLogo}
                              className="h-8 text-xs font-mono font-semibold gap-1.5 rounded-sm border-border cursor-pointer"
                            >
                              <Upload className="w-3.5 h-3.5" />
                              {logoPreview ? "Change Logo" : "Upload Logo"}
                            </Button>
                            {logoPreview && (
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={handleRemoveLogo}
                                className="h-8 text-xs font-mono text-rose-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-sm cursor-pointer"
                              >
                                Remove
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* 3-Column Grid on Wide Screens */}
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                        {/* Business Name */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider">
                            Business Name *
                          </label>
                          <Input
                            {...register("name")}
                            placeholder="e.g. HKR System Business"
                            className="h-9 rounded-sm text-xs font-medium"
                          />
                          {errors.name && (
                            <span className="text-xs text-rose-500">{errors.name.message}</span>
                          )}
                        </div>

                        {/* Industry */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider">
                            Industry Sector *
                          </label>
                          <Input
                            {...register("industry")}
                            placeholder="e.g. Retail, Wholesale, IT Solutions, Supermarket"
                            className="h-9 rounded-sm text-xs font-medium"
                          />
                          {errors.industry && (
                            <span className="text-xs text-rose-500">{errors.industry.message}</span>
                          )}
                        </div>

                        {/* Business Registration Number (BRN) */}
                        <div className="space-y-1.5 md:col-span-2 lg:col-span-1">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider flex items-center gap-1.5">
                            <Hash className="w-3.5 h-3.5 text-primary" />
                            Registration Number (BR No)
                          </label>
                          <Input
                            {...register("registrationNumber")}
                            placeholder="e.g. PV-123456 or BR-987654"
                            className="h-9 rounded-sm text-xs font-mono"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* ========================================================= */}
                  {/* TAB 2: CONTACT & LOCATION */}
                  {/* ========================================================= */}
                  {activeTab === "contact" && (
                    <div className="space-y-6 animate-in fade-in duration-150">
                      <div>
                        <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-foreground flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-primary" /> Official Contact & Registered Address
                        </h3>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          Contact numbers, email address, website, and physical headquarters location.
                        </p>
                      </div>

                      {/* Phone Numbers: 3 Columns */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                        {/* Phone Code */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider">
                            Primary Phone Code *
                          </label>
                          <select
                            {...register("phoneCodeId")}
                            className="w-full h-9 px-3 bg-background border border-input text-foreground rounded-sm text-xs focus:outline-none focus:border-primary transition-all focus:ring-1 focus:ring-primary font-mono"
                          >
                            <option value="">Select Phone Code</option>
                            {phoneCodes.map((code) => (
                              <option key={code.id} value={code.id}>
                                {code.name.includes(code.code) ? code.name : `${code.name} (${code.code})`}
                              </option>
                            ))}
                          </select>
                          {errors.phoneCodeId && (
                            <span className="text-xs text-rose-500">{errors.phoneCodeId.message}</span>
                          )}
                        </div>

                        {/* Primary Phone */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider flex items-center gap-1.5">
                            <Phone className="w-3.5 h-3.5 text-primary" /> Primary Phone Number *
                          </label>
                          <Input
                            {...register("phone")}
                            placeholder="e.g. 0754566789"
                            className="h-9 rounded-sm text-xs font-mono"
                          />
                          {errors.phone && (
                            <span className="text-xs text-rose-500">{errors.phone.message}</span>
                          )}
                        </div>

                        {/* Alternate / WhatsApp Phone */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider">
                            Alternate / WhatsApp Contact
                          </label>
                          <Input
                            {...register("alternatePhone")}
                            placeholder="e.g. +94 77 123 4567"
                            className="h-9 rounded-sm text-xs font-mono"
                          />
                        </div>
                      </div>

                      {/* Online Channels: 2 Columns */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                        {/* Official Email */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider flex items-center gap-1.5">
                            <Mail className="w-3.5 h-3.5 text-primary" /> Official Business Email
                          </label>
                          <Input
                            type="email"
                            {...register("email")}
                            placeholder="e.g. info@hkrsystems.com"
                            className="h-9 rounded-sm text-xs font-mono"
                          />
                          {errors.email && (
                            <span className="text-xs text-rose-500">{errors.email.message}</span>
                          )}
                        </div>

                        {/* Website */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider flex items-center gap-1.5">
                            <Globe className="w-3.5 h-3.5 text-primary" /> Company Website URL
                          </label>
                          <Input
                            {...register("website")}
                            placeholder="e.g. https://www.hkrsystems.com"
                            className="h-9 rounded-sm text-xs font-mono"
                          />
                        </div>
                      </div>

                      {/* Full-width Address Line */}
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider">
                          Street Address / Building Premise
                        </label>
                        <Input
                          {...register("address")}
                          placeholder="e.g. No. 124, Galle Road, Main Commercial Tower"
                          className="h-9 rounded-sm text-xs"
                        />
                      </div>

                      {/* Location 4-Column Grid on Wide Screens */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                        {/* City */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider">
                            City / Town
                          </label>
                          <Input
                            {...register("city")}
                            placeholder="e.g. Colombo"
                            className="h-9 rounded-sm text-xs"
                          />
                        </div>

                        {/* State / Province */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider">
                            State / Province
                          </label>
                          <Input
                            {...register("state")}
                            placeholder="e.g. Western Province"
                            className="h-9 rounded-sm text-xs"
                          />
                        </div>

                        {/* Postal Code */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider">
                            Postal / Zip Code
                          </label>
                          <Input
                            {...register("postalCode")}
                            placeholder="e.g. 00300"
                            className="h-9 rounded-sm text-xs font-mono"
                          />
                        </div>

                        {/* Country */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider">
                            Country *
                          </label>
                          <select
                            {...register("countryId")}
                            className="w-full h-9 px-3 bg-background border border-input text-foreground rounded-sm text-xs focus:outline-none focus:border-primary transition-all focus:ring-1 focus:ring-primary"
                          >
                            <option value="">Select Country</option>
                            {countries.map((country) => (
                              <option key={country.id} value={country.id}>
                                {country.name}
                              </option>
                            ))}
                          </select>
                          {errors.countryId && (
                            <span className="text-xs text-rose-500">{errors.countryId.message}</span>
                          )}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* ========================================================= */}
                  {/* TAB 3: TAX & LEGAL */}
                  {/* ========================================================= */}
                  {activeTab === "tax" && (
                    <div className="space-y-6 animate-in fade-in duration-150">
                      <div>
                        <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-foreground flex items-center gap-2">
                          <Percent className="w-4 h-4 text-primary" /> Tax Identification & Calculation
                        </h3>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          Configure tax registration details (VAT / GST / TIN) and global tax calculation settings.
                        </p>
                      </div>

                      {/* Enable Tax Toggle Card */}
                      <div className="p-4 rounded-sm border border-border bg-card/40 flex items-center justify-between gap-4">
                        <div className="space-y-1">
                          <p className="text-xs font-bold font-mono uppercase text-foreground flex items-center gap-2">
                            <ShieldCheck className="w-4 h-4 text-primary" /> Enable System Tax Calculations
                          </p>
                          <p className="text-xs text-muted-foreground">
                            When enabled, configured tax rates and groups will be computed automatically across POS sales and purchases.
                          </p>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            {...register("isTaxEnabled")}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-secondary peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                        </label>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                        {/* Tax Name */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider">
                            Tax Label / Tax Name
                          </label>
                          <Input
                            {...register("taxName")}
                            placeholder="e.g. VAT, GST, Sales Tax"
                            className="h-9 rounded-sm text-xs"
                          />
                          <p className="text-[11px] text-muted-foreground">
                            The label displayed alongside tax totals on customer invoice receipts (e.g. VAT 18%).
                          </p>
                        </div>

                        {/* Tax Identification Number */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider flex items-center gap-1.5">
                            <Hash className="w-3.5 h-3.5 text-primary" /> Tax / VAT / TIN Number
                          </label>
                          <Input
                            {...register("taxNumber")}
                            placeholder="e.g. 10928374-7000 or GSTIN29ABCDE"
                            className="h-9 rounded-sm text-xs font-mono uppercase"
                          />
                          <p className="text-[11px] text-muted-foreground">
                            Your official registered tax ID number printed in the invoice header.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* ========================================================= */}
                  {/* TAB 4: FINANCIAL PREFERENCES */}
                  {/* ========================================================= */}
                  {activeTab === "financial" && (
                    <div className="space-y-6 animate-in fade-in duration-150">
                      <div>
                        <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-foreground flex items-center gap-2">
                          <DollarSign className="w-4 h-4 text-primary" /> Financial & System Preferences
                        </h3>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          Currency conventions, financial year start, valuation methods, timezone, and date format.
                        </p>
                      </div>

                      {/* 3-Column Currency & Precision Row */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                        {/* Currency */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider">
                            Operating Currency *
                          </label>
                          <select
                            {...register("currencyId")}
                            className="w-full h-9 px-3 bg-background border border-input text-foreground rounded-sm text-xs focus:outline-none focus:border-primary transition-all focus:ring-1 focus:ring-primary font-mono"
                          >
                            <option value="">Select Currency</option>
                            {currencies.map((currency) => (
                              <option key={currency.id} value={currency.id}>
                                {currency.name} ({currency.symbol} - {currency.code})
                              </option>
                            ))}
                          </select>
                          {errors.currencyId && (
                            <span className="text-xs text-rose-500">{errors.currencyId.message}</span>
                          )}
                        </div>

                        {/* Currency Symbol Placement */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider">
                            Currency Symbol Placement
                          </label>
                          <select
                            {...register("currencySymbolPlacement")}
                            className="w-full h-9 px-3 bg-background border border-input text-foreground rounded-sm text-xs focus:outline-none focus:border-primary transition-all focus:ring-1 focus:ring-primary"
                          >
                            <option value="before">Before Amount (e.g. Rs 1,500.00)</option>
                            <option value="after">After Amount (e.g. 1,500.00 Rs)</option>
                          </select>
                        </div>

                        {/* Decimal Precision */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider">
                            Decimal Precision
                          </label>
                          <select
                            {...register("decimalPrecision", { valueAsNumber: true })}
                            className="w-full h-9 px-3 bg-background border border-input text-foreground rounded-sm text-xs focus:outline-none focus:border-primary transition-all focus:ring-1 focus:ring-primary"
                          >
                            <option value={2}>2 Decimals (0.00 - Standard)</option>
                            <option value={3}>3 Decimals (0.000 - Precision)</option>
                            <option value={0}>0 Decimals (Rounded Integer)</option>
                          </select>
                        </div>
                      </div>

                      {/* 3-Column Accounting & Timezone Row */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                        {/* Financial Year Start Month */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-primary" /> Financial Year Start Month
                          </label>
                          <select
                            {...register("financialYearStartMonth", { valueAsNumber: true })}
                            className="w-full h-9 px-3 bg-background border border-input text-foreground rounded-sm text-xs focus:outline-none focus:border-primary transition-all focus:ring-1 focus:ring-primary"
                          >
                            {months.map((m) => (
                              <option key={m.value} value={m.value}>
                                {m.label}
                              </option>
                            ))}
                          </select>
                          <p className="text-[11px] text-muted-foreground">
                            Used for annual accounting books and P&L financial year reports.
                          </p>
                        </div>

                        {/* Stock Accounting Valuation Method */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider flex items-center gap-1.5">
                            <Sliders className="w-3.5 h-3.5 text-primary" /> Stock Accounting Method
                          </label>
                          <select
                            {...register("stockAccountingMethod")}
                            className="w-full h-9 px-3 bg-background border border-input text-foreground rounded-sm text-xs focus:outline-none focus:border-primary transition-all focus:ring-1 focus:ring-primary"
                          >
                            <option value="FIFO">FIFO (First In First Out - Recommended)</option>
                            <option value="LIFO">LIFO (Last In First Out)</option>
                            <option value="AVG">Weighted Average Cost (AVCO)</option>
                          </select>
                          <p className="text-[11px] text-muted-foreground">
                            Determines how Cost of Goods Sold (COGS) is evaluated on sales.
                          </p>
                        </div>

                        {/* Timezone */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-primary" /> System Timezone
                          </label>
                          <select
                            {...register("timezone")}
                            className="w-full h-9 px-3 bg-background border border-input text-foreground rounded-sm text-xs focus:outline-none focus:border-primary transition-all focus:ring-1 focus:ring-primary"
                          >
                            {timezones.map((tz) => (
                              <option key={tz.value} value={tz.value}>
                                {tz.label}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      {/* Date Format */}
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono tracking-wider">
                          System Date Format
                        </label>
                        <select
                          {...register("dateFormat")}
                          className="w-full h-9 px-3 bg-background border border-input text-foreground rounded-sm text-xs focus:outline-none focus:border-primary transition-all focus:ring-1 focus:ring-primary"
                        >
                          {dateFormats.map((df) => (
                            <option key={df.value} value={df.value}>
                              {df.label}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  )}

                  {/* Bottom Action Footer (Spans Full Width) */}
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-5 border-t border-border">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground font-mono">
                      <ShieldCheck className="w-4 h-4 text-primary" />
                      <span>All configurations apply enterprise-wide across all branch terminals.</span>
                    </div>

                    <Button
                      type="submit"
                      disabled={isFormLoading}
                      className="w-full sm:w-auto text-xs px-6 py-2 gap-2 h-9 font-mono font-bold uppercase tracking-wider rounded-sm shadow-sm cursor-pointer"
                    >
                      {isFormLoading ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Save className="h-4 w-4" />
                      )}
                      Save All Changes
                    </Button>
                  </div>
                </form>
              )}
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}

export default function BusinessSettingsPage() {
  return (
    <Suspense
      fallback={
        <div className="flex h-screen items-center justify-center bg-background">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      }
    >
      <BusinessSettingsPageContent />
    </Suspense>
  );
}
