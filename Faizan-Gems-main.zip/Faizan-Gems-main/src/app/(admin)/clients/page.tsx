import AdminDashboard from "@/features/admin/AdminDashboard";

export default function ClientsPage() {
  return <AdminDashboard initialTab="clients" />;
}
