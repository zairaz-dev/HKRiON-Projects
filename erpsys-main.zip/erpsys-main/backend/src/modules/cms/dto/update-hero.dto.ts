import { IsBoolean, IsOptional, IsString } from 'class-validator';

export class UpdateCmsHeroDto {
  @IsOptional()
  @IsString()
  announcementText?: string;

  @IsOptional()
  @IsString()
  announcementLink?: string;

  @IsOptional()
  @IsBoolean()
  announcementActive?: boolean;

  @IsOptional()
  @IsString()
  badgeText?: string;

  @IsOptional()
  @IsString()
  heroTitle?: string;

  @IsOptional()
  @IsString()
  heroSubtitle?: string;

  @IsOptional()
  @IsString()
  primaryCtaText?: string;

  @IsOptional()
  @IsString()
  primaryCtaLink?: string;

  @IsOptional()
  @IsString()
  secondaryCtaText?: string;

  @IsOptional()
  @IsString()
  secondaryCtaLink?: string;

  @IsOptional()
  @IsString()
  heroMockupUrl?: string;

  @IsOptional()
  @IsString()
  statsJson?: string;
}
