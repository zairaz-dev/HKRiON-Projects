import { ProductService } from "@/services/product.service";
import AdminProductTable from "@/components/admin/AdminProductTable";
import { Package, ExternalLink, Plus } from "lucide-react";
import Link from "next/link";

export const dynamic = "force-dynamic";

interface AdminProductsPageProps {
  searchParams?: Promise<{ success?: string; error?: string; edit?: string }>;
}

export default async function AdminProductsPage({ searchParams }: AdminProductsPageProps) {
  const params = await searchParams;
  const editingProductId = params?.edit;

  const [products, categories] = await Promise.all([
    ProductService.getAllForAdmin(),
    ProductService.getCategories(),
  ]);

  return (
    <div className="space-y-6 w-full pb-16">
      {/* Header Banner */}
      <div className="bg-white dark:bg-black p-6 sm:p-7 rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 px-2.5 py-0.5 rounded-none">
              CATALOG MANAGEMENT
            </span>
            <span className="text-xs text-neutral-400 dark:text-neutral-500">• 13 Core Solutions</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white tracking-tight">
            Products & Solutions Catalog
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Manage your architectural blinds, custom curtains, awnings, and outdoor PVC shades.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/admin/products?edit=new"
            className="inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold px-4 py-2 rounded-none text-xs border border-amber-600 transition-all shadow-xs active:scale-95"
          >
            <Plus size={14} />
            <span>Add Product</span>
          </Link>
          <Link
            href="/products"
            target="_blank"
            className="inline-flex items-center gap-2 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-900 dark:hover:bg-neutral-850 text-neutral-800 dark:text-neutral-200 font-bold px-4 py-2 rounded-none text-xs border border-[#E5E5E0] dark:border-neutral-800 transition-all active:scale-95"
          >
            <span>View Live Catalog</span>
            <ExternalLink size={12} className="text-neutral-500 dark:text-neutral-400" />
          </Link>
        </div>
      </div>

      {/* Visual Product Grid */}
      <AdminProductTable
        products={products}
        categories={categories}
        editingProductId={editingProductId}
      />
    </div>
  );
}

