import { UserService } from "@/services/user.service";
import { SessionManager } from "@/core/auth/session";
import {
  Users,
  UserPlus,
  ShieldCheck,
  Clock,
  Sparkles,
  Mail,
  User,
  Lock,
  Shield,
  Edit3,
  Trash2,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  X,
  AlertTriangle,
} from "lucide-react";
import Link from "next/link";

export const dynamic = "force-dynamic";

interface AdminUsersPageProps {
  searchParams?: Promise<{
    success?: string;
    error?: string;
    create?: string;
    edit?: string;
    password?: string;
    delete?: string;
  }>;
}

export default async function AdminUsersPage({ searchParams }: AdminUsersPageProps) {
  const session = await SessionManager.getCurrentSession();
  const params = await searchParams;
  const isCreateModalOpen = params?.create === "true";
  const editUserId = params?.edit;
  const passwordUserId = params?.password;
  const deleteUserId = params?.delete;
  const successMsg = params?.success;
  const errorMsg = params?.error;

  const users = await UserService.getAll();

  const editingUser = editUserId ? users.find((u) => u.id === editUserId) || null : null;
  const passwordUser = passwordUserId ? users.find((u) => u.id === passwordUserId) || null : null;
  const deletingUser = deleteUserId ? users.find((u) => u.id === deleteUserId) || null : null;

  const totalUsers = users.length;
  const adminCount = users.filter((u) => u.role === "ADMIN").length;

  return (
    <div className="space-y-6 w-full">
      {/* Flash Messages */}
      {successMsg && (
        <div className="flex items-center justify-between gap-3 p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-sm font-semibold rounded-none animate-in fade-in">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 size={18} className="text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>{decodeURIComponent(successMsg)}</span>
          </div>
          <Link
            href="/admin/users"
            scroll={false}
            className="p-1 rounded-none hover:bg-emerald-200/50 dark:hover:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300 transition-colors"
            aria-label="Dismiss alert"
          >
            <X size={16} />
          </Link>
        </div>
      )}

      {errorMsg && (
        <div className="flex items-center justify-between gap-3 p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 text-sm font-semibold rounded-none animate-in fade-in">
          <div className="flex items-center gap-2.5">
            <AlertCircle size={18} className="text-rose-600 dark:text-rose-400 shrink-0" />
            <span>{decodeURIComponent(errorMsg)}</span>
          </div>
          <Link
            href="/admin/users"
            scroll={false}
            className="p-1 rounded-none hover:bg-rose-200/50 dark:hover:bg-rose-900/50 text-rose-700 dark:text-rose-300 transition-colors"
            aria-label="Dismiss alert"
          >
            <X size={16} />
          </Link>
        </div>
      )}

      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-black p-6 sm:p-8 rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-none bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 text-amber-700 dark:text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
            <Sparkles size={14} /> User Control Center
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white tracking-tight">
            Admin & User Management
          </h1>
          <p className="text-neutral-500 dark:text-neutral-400 text-xs sm:text-sm mt-1">
            Manage authenticated administrators, update roles, change passwords, and manage accounts.
          </p>
        </div>

        <Link
          href="/admin/users?create=true"
          scroll={false}
          className="inline-flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-5 py-2.5 rounded-none text-xs sm:text-sm shadow-xs transition-all active:scale-95 shrink-0 cursor-pointer"
        >
          <UserPlus size={16} />
          <span>Add New Admin User</span>
        </Link>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
        <div className="p-6 rounded-none bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-none bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 flex items-center justify-center text-amber-700 dark:text-amber-400">
            <Users size={24} />
          </div>
          <div>
            <p className="text-xs uppercase tracking-wider text-neutral-400 dark:text-neutral-500 font-bold">Total Accounts</p>
            <h3 className="text-2xl font-black text-neutral-900 dark:text-white">{totalUsers}</h3>
          </div>
        </div>

        <div className="p-6 rounded-none bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-none bg-emerald-50 dark:bg-emerald-400/10 border border-emerald-200 dark:border-emerald-400/30 flex items-center justify-center text-emerald-700 dark:text-emerald-400">
            <ShieldCheck size={24} />
          </div>
          <div>
            <p className="text-xs uppercase tracking-wider text-neutral-400 dark:text-neutral-500 font-bold">Active Administrators</p>
            <h3 className="text-2xl font-black text-neutral-900 dark:text-white">{adminCount}</h3>
          </div>
        </div>

        <div className="p-6 rounded-none bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-none bg-blue-50 dark:bg-blue-400/10 border border-blue-200 dark:border-blue-400/30 flex items-center justify-center text-blue-700 dark:text-blue-400">
            <Clock size={24} />
          </div>
          <div>
            <p className="text-xs uppercase tracking-wider text-neutral-400 dark:text-neutral-500 font-bold">Current Session</p>
            <h3 className="text-sm font-bold text-neutral-900 dark:text-white truncate max-w-40">{session?.email}</h3>
          </div>
        </div>
      </div>

      {/* Users Database Table */}
      <div className="bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none overflow-hidden shadow-xs">
        <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-neutral-900 dark:text-white flex items-center gap-2">
              <span>Database Users List</span>
              <span className="text-xs bg-amber-50 dark:bg-amber-400/10 text-amber-800 dark:text-amber-400 border border-amber-200 dark:border-amber-400/30 px-2.5 py-0.5 rounded-none font-bold">
                users table
              </span>
            </h2>
            <p className="text-neutral-500 dark:text-neutral-400 text-xs mt-0.5">
              Securely stored accounts with bcrypt encrypted password hashes and granular role permissions.
            </p>
          </div>
          <span className="text-xs bg-neutral-100 dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300 px-3.5 py-1.5 rounded-none border border-[#E5E5E0] dark:border-neutral-800 font-medium self-start sm:self-auto">
            {users.length} Users Registered
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-neutral-700 dark:text-neutral-300">
            <thead className="bg-neutral-50 dark:bg-neutral-950 text-xs uppercase font-bold text-neutral-500 dark:text-neutral-400 border-b border-neutral-100 dark:border-neutral-800">
              <tr>
                <th className="py-4 px-6">User Profile</th>
                <th className="py-4 px-6">Email Address</th>
                <th className="py-4 px-6">Role</th>
                <th className="py-4 px-6">Last Login</th>
                <th className="py-4 px-6">Account Created</th>
                <th className="py-4 px-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
              {users.map((u) => {
                const isCurrentUser = u.email === session?.email || u.id === session?.userId;
                return (
                  <tr key={u.id} className="hover:bg-neutral-50/80 dark:hover:bg-neutral-900/60 transition-colors">
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-3.5">
                        <div className="w-11 h-11 rounded-none bg-amber-50 dark:bg-amber-400/20 border border-amber-200 dark:border-amber-400/40 flex items-center justify-center text-amber-700 dark:text-amber-400 font-black text-base shrink-0">
                          {u.name ? u.name.charAt(0).toUpperCase() : "U"}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-bold text-neutral-900 dark:text-white text-sm">{u.name}</p>
                            {isCurrentUser && (
                              <span className="text-[10px] bg-emerald-50 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/30 px-2 py-0.5 rounded-none font-bold">
                                You
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-neutral-400 dark:text-neutral-500 font-mono">id: {u.id.substring(0, 8)}...</p>
                        </div>
                      </div>
                    </td>

                    <td className="py-4 px-6 font-mono text-xs text-neutral-700 dark:text-neutral-300">
                      {u.email}
                    </td>

                    <td className="py-4 px-6">
                      <span
                        className={`inline-flex items-center gap-1 text-xs px-3 py-1 rounded-none font-bold uppercase tracking-wider ${
                          u.role === "ADMIN"
                            ? "bg-amber-50 dark:bg-amber-400/10 text-amber-800 dark:text-amber-400 border border-amber-200 dark:border-amber-400/30"
                            : "bg-neutral-100 dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300 border border-neutral-200 dark:border-neutral-800"
                        }`}
                      >
                        <Shield size={12} />
                        {u.role}
                      </span>
                    </td>

                    <td className="py-4 px-6 text-xs text-neutral-500 dark:text-neutral-400">
                      {u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleString() : "Never logged in"}
                    </td>

                    <td className="py-4 px-6 text-xs text-neutral-400 dark:text-neutral-500">
                      {new Date(u.createdAt).toLocaleDateString()}
                    </td>

                    <td className="py-4 px-6 text-right">
                      <div className="inline-flex items-center justify-end gap-1.5 sm:gap-2">
                        {/* Edit Button */}
                        <Link
                          href={`/admin/users?edit=${encodeURIComponent(u.id)}`}
                          scroll={false}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-none bg-amber-50 dark:bg-amber-400/10 hover:bg-amber-100 dark:hover:bg-amber-400/20 text-amber-800 dark:text-amber-400 border border-amber-200 dark:border-amber-400/30 text-xs font-bold transition-all active:scale-95 cursor-pointer"
                          title="Edit User Details"
                        >
                          <Edit3 size={13} />
                          <span className="hidden sm:inline">Edit</span>
                        </Link>

                        {/* Change Password Button */}
                        <Link
                          href={`/admin/users?password=${encodeURIComponent(u.id)}`}
                          scroll={false}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-none bg-blue-50 dark:bg-blue-400/10 hover:bg-blue-100 dark:hover:bg-blue-400/20 text-blue-800 dark:text-blue-400 border border-blue-200 dark:border-blue-400/30 text-xs font-bold transition-all active:scale-95 cursor-pointer"
                          title="Change / Reset Password"
                        >
                          <KeyRound size={13} />
                          <span className="hidden sm:inline">Password</span>
                        </Link>

                        {/* Delete Button */}
                        {isCurrentUser ? (
                          <span
                            className="p-1.5 rounded-none bg-neutral-100 dark:bg-neutral-900 text-neutral-400 dark:text-neutral-600 border border-neutral-200 dark:border-neutral-800 cursor-not-allowed opacity-50"
                            title="Cannot delete your active session account"
                          >
                            <Trash2 size={14} />
                          </span>
                        ) : (
                          <Link
                            href={`/admin/users?delete=${encodeURIComponent(u.id)}`}
                            scroll={false}
                            className="p-1.5 rounded-none bg-rose-50 dark:bg-rose-500/10 hover:bg-rose-100 dark:hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-500/30 transition-all cursor-pointer active:scale-95"
                            title="Delete User"
                            aria-label="Delete User"
                          >
                            <Trash2 size={14} />
                          </Link>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 1. ADD NEW USER MODAL */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
          <Link
            href="/admin/users"
            scroll={false}
            className="fixed inset-0 cursor-default"
            aria-label="Close modal"
          />

          <div className="bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none p-6 sm:p-8 max-w-lg w-full shadow-2xl relative z-10 my-8">
            <div className="flex items-center justify-between pb-6 border-b border-neutral-100 dark:border-neutral-800">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-none bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 text-amber-700 dark:text-amber-400 text-[10px] font-black uppercase tracking-widest mb-1.5">
                  <UserPlus size={12} />
                  <span>Create Account</span>
                </div>
                <h3 className="text-xl font-extrabold text-neutral-900 dark:text-white">Add New User</h3>
              </div>
              <Link
                href="/admin/users"
                scroll={false}
                className="p-2 rounded-none bg-neutral-100 dark:bg-neutral-900 text-neutral-500 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white transition-colors"
                aria-label="Close"
              >
                <X size={18} />
              </Link>
            </div>

            <form method="POST" action="/api/admin/users/create" className="space-y-4 pt-6">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Full Name *
                </label>
                <div className="relative">
                  <User size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-500 pointer-events-none" />
                  <input
                    type="text"
                    name="name"
                    required
                    placeholder="e.g. John Doe"
                    className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none py-2.5 pl-10 pr-4 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Email Address *
                </label>
                <div className="relative">
                  <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-500 pointer-events-none" />
                  <input
                    type="email"
                    name="email"
                    required
                    placeholder="admin@shadeitblinds.com"
                    className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none py-2.5 pl-10 pr-4 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Password *
                </label>
                <div className="relative">
                  <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-500 pointer-events-none" />
                  <input
                    type="password"
                    name="password"
                    required
                    minLength={6}
                    placeholder="Minimum 6 characters"
                    className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none py-2.5 pl-10 pr-4 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  User Role *
                </label>
                <select
                  name="role"
                  defaultValue="ADMIN"
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400"
                >
                  <option value="ADMIN">ADMIN (Full Dashboard Access)</option>
                  <option value="CUSTOMER">CUSTOMER</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-6 border-t border-neutral-100 dark:border-neutral-800">
                <Link
                  href="/admin/users"
                  scroll={false}
                  className="px-5 py-2.5 rounded-none bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-900 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 text-xs font-bold transition-all"
                >
                  Cancel
                </Link>
                <button
                  type="submit"
                  className="inline-flex items-center gap-2 px-6 py-2.5 rounded-none bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95"
                >
                  <UserPlus size={15} />
                  <span>Create User</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 2. EDIT USER MODAL */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
          <Link
            href="/admin/users"
            scroll={false}
            className="fixed inset-0 cursor-default"
            aria-label="Close modal"
          />

          <div className="bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none p-6 sm:p-8 max-w-lg w-full shadow-2xl relative z-10 my-8">
            <div className="flex items-center justify-between pb-6 border-b border-neutral-100 dark:border-neutral-800">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-none bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 text-amber-700 dark:text-amber-400 text-[10px] font-black uppercase tracking-widest mb-1.5">
                  <Edit3 size={12} />
                  <span>Update Profile</span>
                </div>
                <h3 className="text-xl font-extrabold text-neutral-900 dark:text-white">Edit User Account</h3>
              </div>
              <Link
                href="/admin/users"
                scroll={false}
                className="p-2 rounded-none bg-neutral-100 dark:bg-neutral-900 text-neutral-500 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white transition-colors"
                aria-label="Close"
              >
                <X size={18} />
              </Link>
            </div>

            <form method="POST" action="/api/admin/users/update" className="space-y-4 pt-6">
              <input type="hidden" name="id" value={editingUser.id} />

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Full Name *
                </label>
                <div className="relative">
                  <User size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-500 pointer-events-none" />
                  <input
                    type="text"
                    name="name"
                    required
                    defaultValue={editingUser.name}
                    placeholder="e.g. John Doe"
                    className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none py-2.5 pl-10 pr-4 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Email Address *
                </label>
                <div className="relative">
                  <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-500 pointer-events-none" />
                  <input
                    type="email"
                    name="email"
                    required
                    defaultValue={editingUser.email}
                    placeholder="admin@shadeitblinds.com"
                    className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none py-2.5 pl-10 pr-4 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  User Role *
                </label>
                <select
                  name="role"
                  defaultValue={editingUser.role}
                  className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none px-4 py-2.5 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400"
                >
                  <option value="ADMIN">ADMIN (Full Dashboard Access)</option>
                  <option value="CUSTOMER">CUSTOMER</option>
                </select>
                {editingUser.role === "ADMIN" && adminCount <= 1 && (
                  <p className="text-[11px] text-amber-600 dark:text-amber-400 mt-1">
                    Note: This is currently the only administrator account.
                  </p>
                )}
              </div>

              <div className="flex items-center justify-between pt-6 border-t border-neutral-100 dark:border-neutral-800">
                <Link
                  href={`/admin/users?password=${encodeURIComponent(editingUser.id)}`}
                  scroll={false}
                  className="inline-flex items-center gap-1.5 text-xs text-blue-600 dark:text-blue-400 hover:underline font-semibold"
                >
                  <KeyRound size={13} />
                  <span>Change Password</span>
                </Link>

                <div className="flex items-center gap-3">
                  <Link
                    href="/admin/users"
                    scroll={false}
                    className="px-5 py-2.5 rounded-none bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-900 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 text-xs font-bold transition-all"
                  >
                    Cancel
                  </Link>
                  <button
                    type="submit"
                    className="inline-flex items-center gap-2 px-6 py-2.5 rounded-none bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95"
                  >
                    <Edit3 size={15} />
                    <span>Save Changes</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3. CHANGE PASSWORD MODAL */}
      {passwordUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
          <Link
            href="/admin/users"
            scroll={false}
            className="fixed inset-0 cursor-default"
            aria-label="Close modal"
          />

          <div className="bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 rounded-none p-6 sm:p-8 max-w-lg w-full shadow-2xl relative z-10 my-8">
            <div className="flex items-center justify-between pb-6 border-b border-neutral-100 dark:border-neutral-800">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-none bg-blue-50 dark:bg-blue-400/10 border border-blue-200 dark:border-blue-400/30 text-blue-700 dark:text-blue-400 text-[10px] font-black uppercase tracking-widest mb-1.5">
                  <KeyRound size={12} />
                  <span>Security</span>
                </div>
                <h3 className="text-xl font-extrabold text-neutral-900 dark:text-white">Change User Password</h3>
              </div>
              <Link
                href="/admin/users"
                scroll={false}
                className="p-2 rounded-none bg-neutral-100 dark:bg-neutral-900 text-neutral-500 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white transition-colors"
                aria-label="Close"
              >
                <X size={18} />
              </Link>
            </div>

            <div className="bg-neutral-50 dark:bg-neutral-950 p-4 border border-[#E5E5E0] dark:border-neutral-800 my-4 text-xs">
              <p className="text-neutral-500 dark:text-neutral-400">Updating credentials for:</p>
              <p className="font-bold text-neutral-900 dark:text-white text-sm mt-0.5">{passwordUser.name}</p>
              <p className="font-mono text-neutral-600 dark:text-neutral-400 text-xs">{passwordUser.email}</p>
            </div>

            <form method="POST" action="/api/admin/users/change-password" className="space-y-4">
              <input type="hidden" name="id" value={passwordUser.id} />

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  New Password *
                </label>
                <div className="relative">
                  <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-500 pointer-events-none" />
                  <input
                    type="password"
                    name="newPassword"
                    required
                    minLength={6}
                    placeholder="Minimum 6 characters"
                    className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none py-2.5 pl-10 pr-4 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Confirm New Password *
                </label>
                <div className="relative">
                  <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-500 pointer-events-none" />
                  <input
                    type="password"
                    name="confirmPassword"
                    required
                    minLength={6}
                    placeholder="Repeat new password"
                    className="w-full bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-400 rounded-none py-2.5 pl-10 pr-4 text-neutral-900 dark:text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-6 border-t border-neutral-100 dark:border-neutral-800">
                <Link
                  href="/admin/users"
                  scroll={false}
                  className="px-5 py-2.5 rounded-none bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-900 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 text-xs font-bold transition-all"
                >
                  Cancel
                </Link>
                <button
                  type="submit"
                  className="inline-flex items-center gap-2 px-6 py-2.5 rounded-none bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95"
                >
                  <KeyRound size={15} />
                  <span>Update Password</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 4. DELETE USER MODAL */}
      {deletingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
          <Link
            href="/admin/users"
            scroll={false}
            className="fixed inset-0 cursor-default"
            aria-label="Close modal"
          />

          <div className="bg-white dark:bg-black border border-rose-200 dark:border-rose-900/50 rounded-none p-6 sm:p-8 max-w-md w-full shadow-2xl relative z-10 my-8">
            <div className="flex items-center gap-3 pb-4 border-b border-neutral-100 dark:border-neutral-800">
              <div className="w-10 h-10 rounded-none bg-rose-50 dark:bg-rose-500/20 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                <AlertTriangle size={20} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-neutral-900 dark:text-white">Delete User Account?</h3>
                <p className="text-xs text-neutral-500 dark:text-neutral-400">This action is irreversible.</p>
              </div>
            </div>

            <div className="py-4 space-y-2 text-sm text-neutral-700 dark:text-neutral-300">
              <p>Are you sure you want to permanently remove this user account from the database?</p>
              <div className="p-3 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 font-mono text-xs">
                <p className="font-bold text-neutral-900 dark:text-white font-sans">{deletingUser.name}</p>
                <p className="text-neutral-500 dark:text-neutral-400">{deletingUser.email}</p>
                <p className="text-neutral-400 dark:text-neutral-500 mt-1">Role: {deletingUser.role}</p>
              </div>
            </div>

            <form method="POST" action="/api/admin/users/delete" className="flex items-center justify-end gap-3 pt-4 border-t border-neutral-100 dark:border-neutral-800">
              <input type="hidden" name="id" value={deletingUser.id} />
              <Link
                href="/admin/users"
                scroll={false}
                className="px-5 py-2.5 rounded-none bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-900 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 text-xs font-bold transition-all"
              >
                Cancel
              </Link>
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-none bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95"
              >
                <Trash2 size={15} />
                <span>Confirm Delete</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
