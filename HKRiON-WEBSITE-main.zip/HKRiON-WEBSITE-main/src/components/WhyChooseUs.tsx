'use client';

import { 
  ShieldCheck, 
  Zap, 
  Maximize2, 
  Headphones, 
  Cloud, 
  DollarSign 
} from 'lucide-react';

const reasons = [
  {
    icon: ShieldCheck,
    title: 'Enterprise Grade Security',
    desc: 'Bank-grade encryption, MySQL RBAC data security, automated backups, and strict security audit compliance.'
  },
  {
    icon: Zap,
    title: 'Modern Tech Stack',
    desc: 'Powered by Next.js, React, Node.js, Prisma ORM, and cloud-native serverless architectures.'
  },
  {
    icon: Maximize2,
    title: 'Scalable Architecture',
    desc: 'Microservices and containerized infrastructure designed to handle high transaction volumes effortlessly.'
  },
  {
    icon: Headphones,
    title: '24/7 Dedicated Support',
    desc: 'Direct technical support team with rapid incident response and ongoing system maintenance.'
  },
  {
    icon: Cloud,
    title: 'Cloud Ready & Hybrid Deploy',
    desc: 'Seamless deployment across AWS, Azure, Docker containers, or high-performance on-premise servers.'
  },
  {
    icon: DollarSign,
    title: 'Affordable Enterprise Pricing',
    desc: 'Transparent pricing models tailored for growing Sri Lankan startups to large enterprise corporations.'
  }
];

export default function WhyChooseUs() {
  return (
    <section className="py-24 bg-neutral-950 relative overflow-hidden border-y border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <h2 className="text-xs font-semibold uppercase tracking-widest text-[#1ABE56] font-mono">
            WHY CHOOSE HKRION
          </h2>
          <p className="text-3xl sm:text-5xl font-semibold text-white tracking-tight">
            Engineered for <span className="gradient-text">Excellence & Growth</span>
          </p>
          <p className="text-neutral-400 text-base sm:text-lg">
            We combine cutting-edge technology with deep industry experience to build software that scales with your ambition.
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reasons.map((reason, idx) => {
            const Icon = reason.icon;
            return (
              <div
                key={idx}
                className="glass-card p-8 rounded-3xl border border-[#1ABE56]/30 bg-black/90 hover:border-[#1ABE56] transition-all duration-300 group hover:-translate-y-1.5"
              >
                <div className="w-14 h-14 rounded-2xl bg-[#1ABE56]/10 border border-[#1ABE56]/30 flex items-center justify-center mb-6 group-hover:bg-[#1ABE56] transition-colors">
                  <Icon className="w-7 h-7 text-[#1ABE56] group-hover:text-black transition-colors" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2 group-hover:text-[#1ABE56] transition-colors">
                  {reason.title}
                </h3>
                <p className="text-neutral-400 text-sm leading-relaxed">
                  {reason.desc}
                </p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
