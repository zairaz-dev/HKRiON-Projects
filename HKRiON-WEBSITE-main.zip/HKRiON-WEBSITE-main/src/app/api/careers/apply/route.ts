import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { writeFile, mkdir } from 'fs/promises';
import path from 'path';

export async function POST(request: Request) {
  try {
    const formData = await request.formData();

    const jobId = formData.get('jobId') as string;
    const jobTitle = formData.get('jobTitle') as string;
    const fullName = formData.get('fullName') as string;
    const email = formData.get('email') as string;
    const phone = formData.get('phone') as string;
    const experience = formData.get('experience') as string || '1-3 Years';
    const portfolioUrl = formData.get('portfolioUrl') as string || '';
    const coverNote = formData.get('coverNote') as string || '';
    const resumeFile = formData.get('resume') as File | null;

    if (!jobId || !jobTitle || !fullName || !email || !phone) {
      return NextResponse.json(
        { error: 'Job ID, Job Title, Full Name, Email, and Phone are required.' },
        { status: 400 }
      );
    }

    if (!resumeFile) {
      return NextResponse.json(
        { error: 'Resume file is required.' },
        { status: 400 }
      );
    }

    // Validate resume file extension / mime type
    const validExtensions = ['.pdf', '.doc', '.docx'];
    const fileExt = path.extname(resumeFile.name).toLowerCase();
    if (!validExtensions.includes(fileExt)) {
      return NextResponse.json(
        { error: 'Invalid resume file format. Only PDF, DOC, and DOCX are allowed.' },
        { status: 400 }
      );
    }

    // Validate size (max 10MB)
    const MAX_SIZE = 10 * 1024 * 1024;
    if (resumeFile.size > MAX_SIZE) {
      return NextResponse.json(
        { error: 'Resume file size exceeds maximum limit of 10MB.' },
        { status: 400 }
      );
    }

    // Save resume to disk
    const bytes = await resumeFile.arrayBuffer();
    const buffer = Buffer.from(bytes);

    const uploadsDir = path.join(process.cwd(), 'public', 'uploads', 'resumes');
    await mkdir(uploadsDir, { recursive: true });

    const sanitizeName = fullName.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
    const fileName = `resume-${Date.now()}-${sanitizeName}${fileExt}`;
    const filePath = path.join(uploadsDir, fileName);

    await writeFile(filePath, buffer);

    const resumeUrl = `/uploads/resumes/${fileName}`;

    // Create JobApplication in database via raw SQL / prisma to bypass client schema locks
    const applicationId = `app-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const cleanEmail = email.trim().toLowerCase();

    await prisma.$executeRaw`
      INSERT INTO JobApplication (id, jobId, jobTitle, fullName, email, phone, experience, portfolioUrl, resumeUrl, coverNote, status, createdAt, updatedAt)
      VALUES (${applicationId}, ${jobId}, ${jobTitle}, ${fullName}, ${cleanEmail}, ${phone}, ${experience}, ${portfolioUrl}, ${resumeUrl}, ${coverNote}, 'PENDING', NOW(), NOW())
    `;

    return NextResponse.json({
      success: true,
      message: 'Application submitted successfully!',
      applicationId,
    });
  } catch (error) {
    console.error('Career Application Error:', error);
    return NextResponse.json(
      { error: 'An error occurred while submitting your application. Please try again.' },
      { status: 500 }
    );
  }
}
