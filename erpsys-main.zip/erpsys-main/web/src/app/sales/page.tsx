"use client";

import React, { useEffect, useState, useMemo, Suspense } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import {
  AlertCircle,
  CheckCircle,
  Building2,
  Calendar,
  User as UserIcon,
  Printer,
  Eye,
  DollarSign,
  FileText,
  Plus,
  Loader2,
  Pencil,
  Trash2,
} from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { DataTable, ColumnDef } from "@/components/ui/table";
import { ActionsDropdown } from "@/components/ui/actions-dropdown";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";

import {
  SaleItem,
  useSalesQuery,
  SaleDetailDialog,
  ReceiptPreview,
  SalePaymentDialog,
  useDeleteSaleMutation,
} from "@/features/pos";
import { useCustomersQuery, useBranchesQuery } from "@/features/customers/hooks/use-customers";
import { useCurrency } from "@/hooks/use-currency";

function SalesPageContent() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Dialogs state
  const [selectedSaleIdForDetail, setSelectedSaleIdForDetail] = useState<string | null>(null);
  const [selectedSaleForReceipt, setSelectedSaleForReceipt] = useState<any | null>(null);
  const [selectedSaleForPayment, setSelectedSaleForPayment] = useState<any | null>(null);

  // Notifications
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (errorMessage) {
      const timer = setTimeout(() => setErrorMessage(""), 5000);
      return () => clearTimeout(timer);
    }
  }, [errorMessage]);

  // URL Search Params for Filters
  const selectedBranchFilter = searchParams.get("branchId") || "all";
  const selectedCustomerFilter = searchParams.get("customerId") || "all";
  const currentPage = Number(searchParams.get("page")) || 1;
  const searchQuery = searchParams.get("search") || "";
  const limit = Number(searchParams.get("limit")) || 10;

  const setSelectedBranchFilter = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1");
    if (value === "all") {
      params.delete("branchId");
    } else {
      params.set("branchId", value);
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  const setSelectedCustomerFilter = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1");
    if (value === "all") {
      params.delete("customerId");
    } else {
      params.set("customerId", value);
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  const handlePageChange = (newPage: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", String(newPage));
    router.push(`${pathname}?${params.toString()}`);
  };

  const handleSearchChange = (newSearch: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1");
    if (newSearch) {
      params.set("search", newSearch);
    } else {
      params.delete("search");
    }
    router.push(`${pathname}?${params.toString()}`);
  };

  const handleLimitChange = (newLimit: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("limit", String(newLimit));
    params.set("page", "1");
    router.push(`${pathname}?${params.toString()}`);
  };

  // Auth check
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  const businessId = currentUser?.businessId || "";
  const { symbol, format } = useCurrency(businessId);

  const { data: customersList = [] } = useCustomersQuery(businessId);
  const { data: branchesList = [] } = useBranchesQuery(businessId, currentUser?.id);
  const deleteSaleMutation = useDeleteSaleMutation();

  const isSuperOrAdmin = currentUser?.role === "admin" || currentUser?.role === "super-admin";
  const effectiveBranchFilter = useMemo(() => {
    if (selectedBranchFilter && selectedBranchFilter !== "all") {
      return selectedBranchFilter;
    }
    if (!isSuperOrAdmin && branchesList.length > 0) {
      return branchesList[0].id;
    }
    return selectedBranchFilter;
  }, [selectedBranchFilter, isSuperOrAdmin, branchesList]);

  // Queries
  const { data: salesResponse, isLoading: salesLoading } = useSalesQuery(
    businessId,
    {
      branchId: effectiveBranchFilter !== "all" ? effectiveBranchFilter : undefined,
      customerId: selectedCustomerFilter !== "all" ? selectedCustomerFilter : undefined,
      status: "FINAL",
      page: currentPage,
      limit,
      search: searchQuery || undefined,
    }
  );

  const salesList = salesResponse?.data || [];
  const meta = salesResponse?.meta || { total: 0, totalPages: 1 };

  const handleDeleteSale = (sale: any) => {
    if (
      confirm(
        `Are you sure you want to delete invoice "${sale.invoiceNumber}"?\n\nThis will restore all items back into inventory stock and permanently remove the invoice record.`
      )
    ) {
      deleteSaleMutation.mutate(
        { id: sale.id, businessId },
        {
          onSuccess: (res: any) => {
            setSuccessMessage(res?.message || `Invoice ${sale.invoiceNumber} deleted and stock restored successfully.`);
          },
          onError: (err: any) => {
            setErrorMessage(err.message || "Failed to delete sale invoice.");
          },
        }
      );
    }
  };

  // Columns definition
  const columns: ColumnDef<SaleItem>[] = [
    {
      header: "Invoice No",
      searchable: true,
      render: (s) => (
        <span className="font-mono font-bold text-foreground text-xs">
          {s.invoiceNumber}
        </span>
      ),
    },
    {
      header: "Date",
      render: (s) => {
        const dateObj = new Date(s.saleDate);
        return (
          <div className="flex flex-col gap-0.5 text-xs font-medium text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <Calendar className="h-3.5 w-3.5" />
              {dateObj.toLocaleDateString()}
            </span>
            <span className="text-[10px] text-muted-foreground/75 pl-5">
              {dateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        );
      },
    },
    {
      header: "Customer",
      render: (s) => (
        <span className="text-xs font-semibold text-foreground">
          {s.customer?.name || "Walk-in Customer"}
        </span>
      ),
    },
    {
      header: "Branch",
      render: (s) => (
        <div className="flex flex-col gap-0.5">
          <span className="text-xs font-semibold text-foreground flex items-center gap-1.5">
            <Building2 className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
            {s.branch?.name || "N/A"}
          </span>
          {s.createdBy?.name && (
            <span className="text-[10px] text-muted-foreground flex items-center gap-1 pl-5">
              <span className="text-muted-foreground/70 font-medium">By:</span>
              <span className="font-semibold text-foreground/90">{s.createdBy.name}</span>
            </span>
          )}
        </div>
      ),
    },
    {
      header: "Grand Total",
      render: (s) => (
        <span className="font-extrabold text-foreground text-xs">
          {format(s.grandTotal)}
        </span>
      ),
    },
    {
      header: "Paid Amount",
      render: (s) => (
        <span className="font-semibold text-emerald-500 text-xs">
          {format(s.amountPaid || 0)}
        </span>
      ),
    },
    {
      header: "Payment Status",
      render: (s) => {
        const status = s.paymentStatus || "DUE";
        let badgeClass = "bg-rose-500/10 border-rose-500/25 text-rose-600 dark:text-rose-400";
        if (status === "PAID") {
          badgeClass = "bg-emerald-500/10 border-emerald-500/25 text-emerald-600 dark:text-emerald-400";
        } else if (status === "PARTIAL") {
          badgeClass = "bg-amber-500/10 border-amber-500/25 text-amber-600 dark:text-amber-400";
        }
        return (
          <span className={`inline-flex items-center px-2 py-0.5 rounded border text-[10px] font-extrabold tracking-wide uppercase ${badgeClass}`}>
            {status}
          </span>
        );
      },
    },
    {
      header: "Actions",
      render: (s) => {
        const actionItems = [];
        
        if (s.paymentStatus !== "PAID") {
          actionItems.push({
            label: "Pay",
            onClick: () => setSelectedSaleForPayment(s),
            icon: <DollarSign className="h-3.5 w-3.5" />,
          });
        }
        
        actionItems.push(
          {
            label: "Edit",
            onClick: () => router.push(`/pos?editSaleId=${s.id}`),
            icon: <Pencil className="h-3.5 w-3.5 text-amber-500" />,
          },
          {
            label: "View",
            onClick: () => setSelectedSaleIdForDetail(s.id),
            icon: <Eye className="h-3.5 w-3.5" />,
          },
          {
            label: "Print",
            onClick: () => setSelectedSaleForReceipt(s),
            icon: <Printer className="h-3.5 w-3.5" />,
          },
          {
            label: "Delete",
            onClick: () => handleDeleteSale(s),
            icon: <Trash2 className="h-3.5 w-3.5 text-rose-500" />,
          }
        );

        return <ActionsDropdown actions={actionItems} />;
      },
    },
  ];

  // Custom filters popover content
  const customFilters = (
    <div className="space-y-3.5 min-w-[220px]">
      {/* Branch Filter */}
      <div className="space-y-1.5">
        <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
          <Building2 className="h-3 w-3" /> Branch Filter
        </label>
        <Select
          value={effectiveBranchFilter}
          onValueChange={setSelectedBranchFilter}
          className="h-9 text-xs"
        >
          {isSuperOrAdmin && <option value="all">All Branches</option>}
          {branchesList.map((b: any) => (
            <option key={b.id} value={b.id}>{b.name}</option>
          ))}
        </Select>
      </div>

      {/* Customer Filter */}
      <div className="space-y-1.5">
        <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
          <UserIcon className="h-3 w-3" /> Customer Filter
        </label>
        <Select
          value={selectedCustomerFilter}
          onValueChange={setSelectedCustomerFilter}
          className="h-9 text-xs"
        >
          <option value="all">All Customers</option>
          {customersList.map((c: any) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </Select>
      </div>
    </div>
  );

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3 p-6 max-w-sm border border-border/40 rounded-xl bg-card/60 backdrop-blur-sm">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <h2 className="text-lg font-bold">Unauthorized Access</h2>
          <p className="text-sm text-muted-foreground">
            You need to be logged in to view this page. Redirecting to login...
          </p>
          <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/sales" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Sales & Invoices Registry" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <FileText className="h-7 w-7 text-primary" /> Sales Registry
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                View sales invoice history, track transaction payments, and print thermal 80mm receipts.
              </p>
            </div>
          </div>

          {/* Banner Notifications */}
          {successMessage && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 animate-in fade-in slide-in-from-top-4 duration-300">
              <CheckCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {errorMessage && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive animate-in fade-in slide-in-from-top-4 duration-300">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{errorMessage}</span>
            </div>
          )}

          {/* Main Table Card */}
          {salesLoading ? (
            <div className="flex h-64 items-center justify-center">
              <div className="text-center space-y-2">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
                <span className="text-sm text-muted-foreground block">Loading sales registry...</span>
              </div>
            </div>
          ) : (
            <DataTable
              data={salesList}
              columns={columns}
              searchPlaceholder="Search Invoice No..."
              serverSide={true}
              totalItems={meta.total}
              totalPages={meta.totalPages}
              currentPage={currentPage}
              onPageChange={handlePageChange}
              searchQuery={searchQuery}
              onSearchQueryChange={handleSearchChange}
              onPageSizeChange={handleLimitChange}
              actionButton={{
                label: "POS Terminal",
                onClick: () => router.push("/pos"),
                icon: <Plus className="h-4 w-4" />
              }}
              customFilters={customFilters}
              reportTitle="Sales Ledger Report"
            />
          )}
        </main>
      </div>

      {/* Sale detail & Receipt modals */}
      {selectedSaleIdForDetail && (
        <SaleDetailDialog
          isOpen={!!selectedSaleIdForDetail}
          onClose={() => setSelectedSaleIdForDetail(null)}
          saleId={selectedSaleIdForDetail}
          businessId={businessId}
        />
      )}

      {selectedSaleForReceipt && (
        <ReceiptPreview
          isOpen={!!selectedSaleForReceipt}
          onClose={() => setSelectedSaleForReceipt(null)}
          sale={selectedSaleForReceipt}
          businessName={currentUser?.business?.name || "HKR ERP Store"}
        />
      )}

      {selectedSaleForPayment && (
        <SalePaymentDialog
          isOpen={!!selectedSaleForPayment}
          onClose={() => setSelectedSaleForPayment(null)}
          sale={selectedSaleForPayment}
          businessId={businessId}
          createdById={currentUser?.id}
          onSuccess={(msg) => setSuccessMessage(msg)}
          onError={(msg) => setErrorMessage(msg)}
        />
      )}
    </div>
  );
}

export default function SalesPage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen w-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
          <p className="text-sm text-muted-foreground">Loading...</p>
        </div>
      </div>
    }>
      <SalesPageContent />
    </Suspense>
  );
}
