export interface BranchItem {
  id: string;
  name: string;
}

export interface ExpenseCategoryBranchItem {
  branchId: string;
  branch: BranchItem;
}

export interface ExpenseCategoryItem {
  id: string;
  name: string;
  code: string | null;
  description: string | null;
  parentId: string | null;
  parent?: {
    id: string;
    name: string;
  } | null;
  isActive: boolean;
  businessId: string;
  createdAt: string;
  updatedAt: string;
  branches?: ExpenseCategoryBranchItem[];
}
