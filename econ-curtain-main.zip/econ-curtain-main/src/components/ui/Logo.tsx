import React, { useId } from "react";

interface LogoProps {
  className?: string;
  animated?: boolean;
  iconOnly?: boolean;
}

export default function Logo({
  className = "w-full max-w-70 sm:max-w-80 md:max-w-95 h-auto",
  animated = false,
  iconOnly = false,
}: LogoProps) {
  const id = useId();
  const goldGradId = `gold-grad-${id.replace(/:/g, "")}`;
  const greenGradId = `green-grad-${id.replace(/:/g, "")}`;

  if (iconOnly) {
    return (
      <svg
        viewBox="-60 -60 120 120"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`${className} overflow-visible`}
      >
        <defs>
          <linearGradient id={greenGradId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#4ade80" />
            <stop offset="100%" stopColor="#22c55e" />
          </linearGradient>
        </defs>

        {/* Centered Dotted Radial Aperture Starburst with Origin at (0, 0) */}
        <g className={animated ? "animate-aperture" : ""}>
          {/* Outer Ring */}
          <g className={animated ? "animate-dot-outer" : ""}>
            <circle cx="-35" cy="0" r="5.5" fill={`url(#${greenGradId})`} />
            <circle cx="-25" cy="-25" r="4.8" fill={`url(#${greenGradId})`} />
            <circle cx="0" cy="-35" r="5.8" fill={`url(#${greenGradId})`} />
            <circle cx="25" cy="-25" r="4.5" fill={`url(#${greenGradId})`} />
            <circle cx="35" cy="0" r="6.2" fill={`url(#${greenGradId})`} />
            <circle cx="25" cy="25" r="4.8" fill={`url(#${greenGradId})`} />
            <circle cx="0" cy="35" r="5.5" fill={`url(#${greenGradId})`} />
            <circle cx="-25" cy="25" r="4.5" fill={`url(#${greenGradId})`} />
          </g>

          {/* Inner Ring */}
          <g className={animated ? "animate-dot-inner" : ""}>
            <circle cx="-20" cy="0" r="3.2" fill="#86efac" />
            <circle cx="-14" cy="-14" r="3.8" fill="#86efac" />
            <circle cx="0" cy="-20" r="4.2" fill="#86efac" />
            <circle cx="14" cy="-14" r="3.2" fill="#86efac" />
            <circle cx="20" cy="0" r="3.8" fill="#86efac" />
            <circle cx="14" cy="14" r="3.2" fill="#86efac" />
            <circle cx="0" cy="20" r="4.2" fill="#86efac" />
            <circle cx="-14" cy="14" r="3.2" fill="#86efac" />
          </g>
        </g>
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 400 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <defs>
        <linearGradient id={goldGradId} x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#d4af37" />
          <stop offset="50%" stopColor="#fef08a" />
          <stop offset="100%" stopColor="#d4af37" />
        </linearGradient>
        <linearGradient id={greenGradId} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#4ade80" />
          <stop offset="100%" stopColor="#22c55e" />
        </linearGradient>
      </defs>

      {/* Dotted Radial Aperture Circle (Left Side) */}
      <g transform="translate(60, 60)" className={animated ? "animate-aperture" : ""}>
        {/* Outer Ring */}
        <g className={animated ? "animate-dot-outer" : ""}>
          <circle cx="-35" cy="0" r="5" fill={`url(#${greenGradId})`} />
          <circle cx="-25" cy="-25" r="4.5" fill={`url(#${greenGradId})`} />
          <circle cx="0" cy="-35" r="5.5" fill={`url(#${greenGradId})`} />
          <circle cx="25" cy="-25" r="4" fill={`url(#${greenGradId})`} />
          <circle cx="35" cy="0" r="6" fill={`url(#${greenGradId})`} />
          <circle cx="25" cy="25" r="4.5" fill={`url(#${greenGradId})`} />
          <circle cx="0" cy="35" r="5" fill={`url(#${greenGradId})`} />
          <circle cx="-25" cy="25" r="4" fill={`url(#${greenGradId})`} />
        </g>

        {/* Inner Ring */}
        <g className={animated ? "animate-dot-inner" : ""}>
          <circle cx="-20" cy="0" r="3" fill="#86efac" />
          <circle cx="-14" cy="-14" r="3.5" fill="#86efac" />
          <circle cx="0" cy="-20" r="4" fill="#86efac" />
          <circle cx="14" cy="-14" r="3" fill="#86efac" />
          <circle cx="20" cy="0" r="3.5" fill="#86efac" />
          <circle cx="14" cy="14" r="3" fill="#86efac" />
          <circle cx="0" cy="20" r="4" fill="#86efac" />
          <circle cx="-14" cy="14" r="3" fill="#86efac" />
        </g>
      </g>

      {/* Vertical Line */}
      <rect x="120" y="25" width="4" height="70" fill={`url(#${goldGradId})`} rx="2" />

      {/* Text: SHADEIT */}
      <text
        x="135"
        y="65"
        fontFamily="system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"
        fontWeight="900"
        fontSize="44"
        fill={`url(#${goldGradId})`}
        letterSpacing="2"
      >
        SHADEIT
      </text>

      {/* Text: BLINDS */}
      <text
        x="138"
        y="95"
        fontFamily="system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"
        fontWeight="600"
        fontSize="22"
        fill={`url(#${goldGradId})`}
        letterSpacing="8"
      >
        BLINDS
      </text>
    </svg>
  );
}
