import { getSession } from "@/lib/session";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { Role } from "@prisma/client";
import TasksDashboardClient from "./tasks-dashboard-client";

export default async function TasksPage() {
  const session = await getSession();

  if (!session) {
    redirect("/login");
  }

  // Fetch tasks with all metadata
  const tasks = await prisma.task.findMany({
    where: session.role === Role.EMPLOYEE 
      ? { assignees: { some: { id: session.userId } } }
      : undefined,
    include: {
      assignees: { 
        select: { 
          id: true, 
          firstName: true, 
          lastName: true, 
          email: true,
          profileImage: true,
          role: true,
          position: { select: { title: true } },
        } 
      },
      assigner: { 
        select: { 
          id: true, 
          firstName: true, 
          lastName: true, 
          email: true,
          profileImage: true,
          role: true,
          position: { select: { title: true } },
        } 
      },
      milestones: {
        select: { id: true, completed: true, title: true },
      },
      updates: { 
        orderBy: { createdAt: "desc" }, 
        take: 1, 
        include: { 
          author: { select: { firstName: true, lastName: true, profileImage: true } } 
        } 
      },
    },
    orderBy: { createdAt: "desc" },
  });

  // Fetch all staff employees for filters & workload analytics if manager/admin
  const employees = session.role !== Role.EMPLOYEE 
    ? await prisma.user.findMany({
        select: {
          id: true,
          firstName: true,
          lastName: true,
          email: true,
          profileImage: true,
          role: true,
          position: { select: { title: true } },
        },
        orderBy: { firstName: "asc" },
      })
    : [];

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-20">
      <TasksDashboardClient 
        tasks={tasks} 
        employees={employees}
        currentUserRole={session.role as Role}
        currentUserId={session.userId}
      />
    </div>
  );
}
