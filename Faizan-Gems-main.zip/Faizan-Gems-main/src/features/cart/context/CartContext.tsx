"use client";

import React, { createContext, useContext, useState, useEffect } from "react";
import { CartItem, Gemstone, SettingOption, GemstoneVariant } from "@/types/gemstone";
import { STORAGE_KEYS } from "@/lib/constants/storage";

interface CartContextType {
  items: CartItem[];
  addToCart: (
    gemstone: Gemstone,
    setting?: SettingOption,
    ringSize?: string,
    selectedVariant?: GemstoneVariant,
    quantity?: number
  ) => void;
  removeFromCart: (gemstoneId: string, variantId?: string) => void;
  updateSetting: (gemstoneId: string, setting: SettingOption, ringSize?: string, variantId?: string) => void;
  updateQuantity: (gemstoneId: string, quantity: number, variantId?: string) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  toggleCart: () => void;
  subtotal: number;
  itemCount: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        const saved =
          localStorage.getItem(STORAGE_KEYS.cart) ||
          localStorage.getItem(STORAGE_KEYS.legacyCart);
        if (saved) {
          setItems(JSON.parse(saved));
        }
      } catch {
        // ignore
      }
      setIsInitialized(true);
    }, 0);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (isInitialized) {
      localStorage.setItem(STORAGE_KEYS.cart, JSON.stringify(items));
    }
  }, [items, isInitialized]);

  const addToCart = (
    gemstone: Gemstone,
    setting: SettingOption = "loose",
    ringSize?: string,
    selectedVariant?: GemstoneVariant,
    quantity: number = 1
  ) => {
    const variantWeight = selectedVariant?.weight ?? gemstone.carat;
    const variantPrice = selectedVariant?.price ?? gemstone.price;
    const hasDims = Boolean(
      gemstone.dimensions &&
      (Number(gemstone.dimensions.length || 0) > 0 ||
       Number(gemstone.dimensions.width || 0) > 0 ||
       Number(gemstone.dimensions.depth || 0) > 0)
    );
    const variantSize =
      selectedVariant?.size?.trim() ||
      (hasDims
        ? `${gemstone.dimensions!.length} × ${gemstone.dimensions!.width}${gemstone.dimensions!.depth ? ` × ${gemstone.dimensions!.depth}` : ""}mm`
        : undefined);
    const addedQty = Math.max(1, quantity || 1);

    setItems((prev) => {
      const matchIndex = prev.findIndex(
        (i) =>
          i.gemstone.id === gemstone.id &&
          (i.selectedVariant?.id || "default") === (selectedVariant?.id || "default")
      );

      if (matchIndex > -1) {
        const updated = [...prev];
        const existingItem = updated[matchIndex];
        const maxStock = selectedVariant?.stock ?? 99;
        const newQty = Math.min((existingItem.quantity || 1) + addedQty, maxStock);
        updated[matchIndex] = {
          ...existingItem,
          quantity: newQty,
          selectedPrice: variantPrice,
          selectedWeight: variantWeight,
          selectedSize: variantSize,
        };
        return updated;
      }

      return [
        ...prev,
        {
          gemstone,
          setting,
          ringSize,
          giftBox: true,
          tamperSealInspected: true,
          selectedVariant,
          selectedWeight: variantWeight,
          selectedPrice: variantPrice,
          selectedSize: variantSize,
          quantity: addedQty,
        },
      ];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (gemstoneId: string, variantId?: string) => {
    setItems((prev) =>
      prev.filter((i) => {
        if (i.gemstone.id !== gemstoneId) return true;
        if (variantId !== undefined) {
          return (i.selectedVariant?.id || "default") !== variantId;
        }
        return false;
      })
    );
  };

  const updateSetting = (
    gemstoneId: string,
    setting: SettingOption,
    ringSize?: string,
    variantId?: string
  ) => {
    setItems((prev) =>
      prev.map((item) => {
        const matchesId = item.gemstone.id === gemstoneId;
        const matchesVariant =
          variantId === undefined || (item.selectedVariant?.id || "default") === variantId;
        return matchesId && matchesVariant ? { ...item, setting, ringSize } : item;
      })
    );
  };

  const updateQuantity = (gemstoneId: string, quantity: number, variantId?: string) => {
    if (quantity <= 0) {
      removeFromCart(gemstoneId, variantId);
      return;
    }

    setItems((prev) =>
      prev.map((item) => {
        const matchesId = item.gemstone.id === gemstoneId;
        const matchesVariant =
          variantId === undefined || (item.selectedVariant?.id || "default") === variantId;
        if (matchesId && matchesVariant) {
          const maxStock = item.selectedVariant?.stock ?? 99;
          return {
            ...item,
            quantity: Math.min(quantity, maxStock),
          };
        }
        return item;
      })
    );
  };

  const clearCart = () => {
    setItems([]);
  };

  const subtotal = items.reduce((acc, item) => {
    const unitPrice = item.selectedPrice ?? item.gemstone.price;
    const qty = item.quantity ?? 1;
    return acc + unitPrice * qty;
  }, 0);

  const itemCount = items.reduce((acc, item) => acc + (item.quantity ?? 1), 0);

  return (
    <CartContext.Provider
      value={{
        items,
        addToCart,
        removeFromCart,
        updateSetting,
        updateQuantity,
        clearCart,
        isCartOpen,
        openCart: () => setIsCartOpen(true),
        closeCart: () => setIsCartOpen(false),
        toggleCart: () => setIsCartOpen((prev) => !prev),
        subtotal,
        itemCount,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
