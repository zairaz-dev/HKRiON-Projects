import { NextResponse } from "next/server";
import { UserService } from "@/services/user.service";
import { SessionManager } from "@/core/auth/session";
import { SafeHttp } from "@/core/http/redirect";
import { RateLimiter } from "@/core/security/rateLimiter";

export async function POST(request: Request) {
  try {
    const clientIp = RateLimiter.getClientIp(request);
    const rateLimitKey = `login_${clientIp}`;
    
    // Check rate limit: 5 attempts per 60 seconds
    const rateCheck = RateLimiter.check(rateLimitKey, 5, 60 * 1000);
    const contentType = request.headers.get("content-type") || "";
    const isJson = contentType.includes("application/json");

    if (!rateCheck.allowed) {
      const errorMsg = `Too many failed login attempts. Please try again in ${rateCheck.retryAfterSeconds} seconds.`;
      if (isJson) {
        return NextResponse.json(
          { success: false, error: errorMsg },
          {
            status: 429,
            headers: { "Retry-After": rateCheck.retryAfterSeconds.toString() },
          }
        );
      }
      return SafeHttp.redirect(`/login?error=${encodeURIComponent(errorMsg)}`, request, 303);
    }

    let email = "";
    let password = "";
    let callbackUrl = "/admin";

    if (isJson) {
      const body = await request.json();
      email = body.email || "";
      password = body.password || "";
      callbackUrl = body.callbackUrl || "/admin";
    } else {
      const formData = await request.formData();
      email = (formData.get("email") as string) || "";
      password = (formData.get("password") as string) || "";
      callbackUrl = (formData.get("callbackUrl") as string) || "/admin";
    }

    const authResult = await UserService.authenticate(email, password);

    if (!authResult.success || !authResult.token) {
      if (isJson) {
        return NextResponse.json(
          { success: false, error: authResult.error || "Authentication failed." },
          { status: 401 }
        );
      }
      return SafeHttp.redirect(`/login?error=${encodeURIComponent(authResult.error || "Authentication failed.")}`, request, 303);
    }

    // Reset rate limiter on successful authentication
    RateLimiter.reset(rateLimitKey);

    // JSON response
    if (isJson) {
      const response = NextResponse.json({
        success: true,
        token: authResult.token,
        user: authResult.user,
      });
      SessionManager.attachCookieToResponse(response, authResult.token);
      return response;
    }

    // Native HTML Form POST response
    const targetPath = callbackUrl.startsWith("/") ? callbackUrl : "/admin";
    const response = SafeHttp.redirect(targetPath, request, 303);
    SessionManager.attachCookieToResponse(response, authResult.token);
    return response;
  } catch (error) {
    console.error("API login error:", error);
    return SafeHttp.redirect(`/login?error=${encodeURIComponent("An error occurred during sign in.")}`, request, 303);
  }
}
