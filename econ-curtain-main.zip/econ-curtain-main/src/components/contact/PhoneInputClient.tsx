"use client";

import { useState } from "react";
import IntlTelInput from "@intl-tel-input/react/with-utils";
import "intl-tel-input/styles";

export default function PhoneInputClient() {
  const [fullPhone, setFullPhone] = useState("");

  return (
    <div className="w-full relative intl-tel-input-wrapper">
      <input type="hidden" name="phone" value={fullPhone} />
      <input type="hidden" name="countryCode" value="" />
      
      <IntlTelInput
        initialCountry="lk"
        strictMode={true}
        separateDialCode={true}
        onChangeNumber={(number: string) => setFullPhone(number)}
        inputProps={{
          required: true,
          className:
            "w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all bg-slate-50 focus:bg-white text-slate-900 pl-[90px]",
          placeholder: "Phone number",
        }}
      />
      <style jsx global>{`
        .intl-tel-input-wrapper .iti {
          width: 100%;
        }
        .intl-tel-input-wrapper .iti__flag-container {
          padding: 2px;
        }
        .intl-tel-input-wrapper .iti__country-list {
          color: black;
        }
        .intl-tel-input-wrapper .iti__selected-dial-code {
          color: black;
        }
        .intl-tel-input-wrapper input {
          color: black;
        }
      `}</style>
    </div>
  );
}
