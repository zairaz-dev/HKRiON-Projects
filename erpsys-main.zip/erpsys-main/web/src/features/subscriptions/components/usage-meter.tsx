"use strict";
"use client";

import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Building2, Users, Package, FileText, AlertTriangle } from 'lucide-react';
import { SubscriptionUsage } from '../types';

interface UsageMeterProps {
  usage: SubscriptionUsage;
}

export function UsageMeter({ usage }: UsageMeterProps) {
  const getProgressColor = (percentage: number) => {
    if (percentage >= 90) return 'bg-rose-500 text-rose-500';
    if (percentage >= 75) return 'bg-amber-500 text-amber-500';
    return 'bg-primary text-primary';
  };

  const metrics = [
    {
      title: 'Branch Outlets',
      used: usage.branches.used,
      max: usage.branches.max,
      percentage: usage.branches.percentage,
      icon: Building2,
      unit: 'branches',
    },
    {
      title: 'Staff Users',
      used: usage.users.used,
      max: usage.users.max,
      percentage: usage.users.percentage,
      icon: Users,
      unit: 'users',
    },
    {
      title: 'Product Catalog',
      used: usage.products.used,
      max: usage.products.max,
      percentage: usage.products.percentage,
      icon: Package,
      unit: 'products',
    },
    {
      title: 'Monthly Invoices',
      used: usage.invoices.used,
      max: usage.invoices.max,
      percentage: usage.invoices.percentage,
      icon: FileText,
      unit: 'sales/mo',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {metrics.map((metric, index) => {
        const Icon = metric.icon;
        const isUnlimited = metric.max === -1;
        const colorClass = getProgressColor(metric.percentage);
        const isHigh = !isUnlimited && metric.percentage >= 90;

        return (
          <Card key={index} className="bg-card/40 backdrop-blur-md border-border/60 shadow-sm relative overflow-hidden">
            {isHigh && (
              <div className="absolute top-2 right-2 flex items-center gap-1 text-[10px] font-semibold text-rose-400 bg-rose-500/10 border border-rose-500/20 px-1.5 py-0.5 rounded-sm">
                <AlertTriangle className="w-3 h-3" /> Near Limit
              </div>
            )}
            <CardContent className="p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-sm bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-foreground tracking-tight">{metric.title}</h4>
                    <p className="text-[10px] text-muted-foreground uppercase font-mono tracking-wider">
                      {isUnlimited ? 'Unlimited Quota' : `${metric.percentage}% Used`}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex items-baseline justify-between pt-1">
                <div className="text-2xl font-bold font-mono tracking-tight text-foreground">
                  {metric.used}
                  <span className="text-xs font-normal text-muted-foreground ml-1">
                    / {isUnlimited ? '∞' : metric.max}
                  </span>
                </div>
                <span className="text-[11px] text-muted-foreground font-mono">{metric.unit}</span>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-secondary/60 h-1.5 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-500 rounded-full ${
                    isUnlimited ? 'bg-primary w-1/4' : colorClass.split(' ')[0]
                  }`}
                  style={{ width: isUnlimited ? '25%' : `${Math.min(100, metric.percentage)}%` }}
                />
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
