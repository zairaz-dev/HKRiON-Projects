"use client";

import React, { useState, useEffect, use, useMemo } from "react";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Gemstone, GemstoneVariant } from "@/types/gemstone";
import { useCurrency } from "@/features/currency/context/CurrencyContext";
import { useCart } from "@/features/cart/context/CartContext";
import { useWishlist } from "@/features/wishlist/context/WishlistContext";
import { LoupeZoom } from "@/features/gemstones/components/LoupeZoom";
import { ConsultationModal } from "@/features/gemstones/components/ConsultationModal";
import { GemstoneCard } from "@/features/gemstones/components/GemstoneCard";
import { GemstoneDetailSkeleton } from "@/features/gemstones/components/GemstoneDetailSkeleton";
import {
  GemIcon,
  SparklesIcon,
  CertificateShieldIcon,
  ArmoredTruckIcon,
  SecurityLockIcon,
  HeartIcon,
  BagIcon,
  ShareIcon,
  BoxIcon,
  AwardIcon,
  CheckIcon,
  ChevronRightIcon
} from "@/components/ui/LuxuryIcons";
import { LuxuryPrice } from "@/components/ui/LuxuryPrice";

export default function GemstoneDetailsPage({ params }: { params: Promise<{ id: string }> }) {
  const resolvedParams = use(params);
  const [gem, setGem] = useState<Gemstone | null | undefined>(undefined);
  const [allGems, setAllGems] = useState<Gemstone[]>([]);

  // Context Hooks - must always be called unconditionally at the top
  const { formatPrice } = useCurrency();
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();

  // Component UI States
  const [activeMediaTab, setActiveMediaTab] = useState<"loupe" | "gallery" | "video">("loupe");
  const [selectedGalleryImg, setSelectedGalleryImg] = useState(0);
  const [isConsultModalOpen, setIsConsultModalOpen] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [addedAnimation, setAddedAnimation] = useState(false);
  const [selectedVariantIndex, setSelectedVariantIndex] = useState<number>(0);
  const [quantity, setQuantity] = useState<number>(1);

  // Derived variants
  const variants = useMemo<GemstoneVariant[]>(() => {
    if (gem?.variants && Array.isArray(gem.variants) && gem.variants.length > 0) {
      return gem.variants;
    }
    if (!gem) return [];
    return [
      {
        id: `var-${gem.id}-default`,
        weight: gem.carat,
        price: gem.price,
        stock: gem.inStock ? 5 : 0,
        size: gem.dimensions && (gem.dimensions.length > 0 || gem.dimensions.width > 0)
          ? `${gem.dimensions.length} × ${gem.dimensions.width}${gem.dimensions.depth ? ` × ${gem.dimensions.depth}` : ""} mm`
          : undefined
      }
    ];
  }, [gem]);

  const activeVariant = variants[selectedVariantIndex] || variants[0];
  const currentStock = activeVariant ? (activeVariant.stock ?? 0) : (gem?.inStock ? 5 : 0);
  const isOutOfStock = gem?.inStock === false || currentStock <= 0;
  const maxStock = Math.max(1, currentStock);

  useEffect(() => {
    let isMounted = true;
    fetch(`/api/gemstones/${resolvedParams.id}`)
      .then((res) => {
        if (!res.ok) {
          if (res.status === 404 && isMounted) {
            setGem(null);
          }
          return null;
        }
        return res.json();
      })
      .then((data) => {
        if (isMounted && data && data.id) {
          setGem(data);
        }
      })
      .catch(() => {});

    fetch("/api/gemstones")
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (isMounted && Array.isArray(data)) {
          setAllGems(data);
        }
      })
      .catch(() => {});

    return () => {
      isMounted = false;
    };
  }, [resolvedParams.id]);

  if (gem === null) {
    notFound();
  }

  if (!gem) {
    return <GemstoneDetailSkeleton />;
  }

  const isFavorited = isInWishlist(gem.id);

  const basePrice = activeVariant ? activeVariant.price : gem.price;
  const totalItemPrice = basePrice * quantity;
  const displayWeight = activeVariant ? Number(activeVariant.weight) : gem.carat;
  const hasDimensions = Boolean(
    gem.dimensions &&
    (Number(gem.dimensions.length || 0) > 0 ||
     Number(gem.dimensions.width || 0) > 0 ||
     Number(gem.dimensions.depth || 0) > 0)
  );
  const dimsString = hasDimensions
    ? `${gem.dimensions!.length} × ${gem.dimensions!.width}${gem.dimensions!.depth ? ` × ${gem.dimensions!.depth}` : ""} mm`
    : "";
  const displaySize = activeVariant?.size?.trim() || dimsString || "";

  const handleAddToCart = () => {
    if (isOutOfStock) return;
    addToCart(gem, "loose", undefined, activeVariant, quantity);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 2000);
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const currentDisplayImage = gem.images[selectedGalleryImg] || gem.images[0];

  const relatedGems = allGems.filter((g) => g.id !== gem.id && (g.type === gem.type || g.isUnheated)).slice(0, 3);

  return (
    <div className="bg-[#FAF8F5] min-h-screen py-8 lg:py-14">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb Navigation */}
        <nav className="flex items-center space-x-2 text-xs font-sans text-[#8C867D] mb-8 uppercase tracking-wider">
          <Link href="/" className="hover:text-[#18181D]">Home</Link>
          <span>/</span>
          <Link href="/shop" className="hover:text-[#18181D]">Gemstones</Link>
          <span>/</span>
          <Link href={`/shop?type=${gem.type}`} className="hover:text-[#18181D]">{gem.type}</Link>
          <span>/</span>
          <span className="text-[#18181D] truncate max-w-[200px] sm:max-w-none">{gem.name}</span>
        </nav>

        {/* Product Master Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          {/* Left Column: Interactive Media & Loupe Studio (7 Cols) */}
          <div className="lg:col-span-7 space-y-6">
            {/* Media Selector Tabs */}
            <div className="flex items-center justify-between border-b border-[#E8E4DC] pb-2 text-xs font-sans">
              <div className="flex space-x-4 sm:space-x-6">
                <button
                  onClick={() => setActiveMediaTab("loupe")}
                  className={`py-1 uppercase tracking-luxury transition-colors relative ${
                    activeMediaTab === "loupe"
                      ? "text-[#18181D] font-medium after:absolute after:bottom-[-9px] after:inset-x-0 after:h-[2px] after:bg-[#C5A880]"
                      : "text-[#8C867D] hover:text-[#18181D]"
                  }`}
                >
                  10x Loupe Magnifier
                </button>
                <button
                  onClick={() => setActiveMediaTab("gallery")}
                  className={`py-1 uppercase tracking-luxury transition-colors relative ${
                    activeMediaTab === "gallery"
                      ? "text-[#18181D] font-medium after:absolute after:bottom-[-9px] after:inset-x-0 after:h-[2px] after:bg-[#C5A880]"
                      : "text-[#8C867D] hover:text-[#18181D]"
                  }`}
                >
                  Gallery Views
                </button>
                {gem.video && (
                  <button
                    onClick={() => setActiveMediaTab("video")}
                    className={`py-1 uppercase tracking-luxury transition-colors relative flex items-center gap-1.5 ${
                      activeMediaTab === "video"
                        ? "text-[#18181D] font-medium after:absolute after:bottom-[-9px] after:inset-x-0 after:h-[2px] after:bg-[#C5A880]"
                        : "text-[#8C867D] hover:text-[#18181D]"
                    }`}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-[#C5A880]" />
                    <span>8s Video View</span>
                  </button>
                )}
              </div>

            </div>

            {/* Interactive Stage */}
            <div className="bg-white border border-[#E8E4DC] p-4 sm:p-6 shadow-sm">
              {activeMediaTab === "loupe" && (
                <LoupeZoom src={currentDisplayImage} alt={gem.name} />
              )}

              {activeMediaTab === "gallery" && (
                <div className="space-y-4">
                  <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#121216] border border-[#E8E4DC]">
                    <Image
                      src={gem.images[selectedGalleryImg] || gem.images[0] || "/uploads/gemstones/gem-1789652077476-hwzsqu.webp"}
                      alt={`${gem.name} View ${selectedGalleryImg + 1}`}
                      fill
                      priority
                      unoptimized={Boolean((gem.images[selectedGalleryImg] || gem.images[0])?.startsWith("/uploads"))}
                      className="object-cover w-full h-full"
                    />
                    {gem.video && (
                      <button
                        onClick={() => setActiveMediaTab("video")}
                        className="absolute bottom-3 right-3 bg-black/80 hover:bg-black text-[#C5A880] text-[11px] font-mono uppercase tracking-wider px-3 py-1.5 rounded border border-[#C5A880]/40 backdrop-blur-sm flex items-center gap-2 transition-all hover:scale-105 shadow-md"
                      >
                        <span className="text-xs">▶</span>
                        <span>Watch 8s Video</span>
                      </button>
                    )}
                  </div>
                  <div className="grid grid-cols-4 sm:grid-cols-5 gap-3">
                    {gem.images.map((img, idx) => (
                      <button
                        key={idx}
                        onClick={() => setSelectedGalleryImg(idx)}
                        className={`relative aspect-square border overflow-hidden transition-all ${
                          selectedGalleryImg === idx
                            ? "border-[#C5A880] ring-1 ring-[#C5A880]"
                            : "border-[#E8E4DC] opacity-70 hover:opacity-100"
                        }`}
                      >
                        <Image src={img} alt={`Thumbnail ${idx + 1}`} fill unoptimized={img.startsWith("/uploads")} className="object-cover" />
                      </button>
                    ))}
                    {gem.video && (
                      <button
                        onClick={() => setActiveMediaTab("video")}
                        className="relative aspect-square border border-[#C5A880]/50 bg-black/90 overflow-hidden transition-all flex flex-col items-center justify-center text-center p-2 group hover:border-[#C5A880] hover:scale-[1.02]"
                        title="Watch 8s Showcase Video"
                      >
                        <div className="w-7 h-7 rounded-full bg-[#C5A880] text-black flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
                          <span className="text-[11px] ml-0.5 font-bold">▶</span>
                        </div>
                        <span className="text-[9px] uppercase font-mono text-[#C5A880] font-bold tracking-wider">
                          8s Video
                        </span>
                      </button>
                    )}
                  </div>
                </div>
              )}

              {activeMediaTab === "video" && gem.video && (
                <div className="space-y-4">
                  <div className="relative aspect-[4/3] w-full overflow-hidden bg-black border border-[#E8E4DC] flex items-center justify-center">
                    <video
                      key={gem.video}
                      autoPlay
                      loop
                      muted
                      playsInline
                      controls
                      preload="auto"
                      className="w-full h-full object-contain"
                    >
                      <source src={gem.video} type={gem.video.endsWith(".webm") ? "video/webm" : "video/mp4"} />
                      Your browser does not support the video tag.
                    </video>
                    <div className="absolute top-3 left-3 bg-black/80 backdrop-blur-md px-3 py-1 text-[10px] font-mono text-[#C5A880] border border-[#C5A880]/40 flex items-center gap-2 pointer-events-none">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#C5A880]" />
                      <span>8s Ultra-HD Showcase</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-xs font-sans text-[#8C867D] px-1">
                    <span>Authentic 8-second motion preview showing natural optical fire and brilliance.</span>
                    <button
                      onClick={() => setActiveMediaTab("gallery")}
                      className="text-[#C5A880] hover:underline font-medium uppercase tracking-wider text-[11px]"
                    >
                      &larr; Back to Photo Gallery
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Packaging & Presentation Note */}
            <div className="p-5 bg-white border border-[#E8E4DC] flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-[#FAF8F5] border border-[#C5A880]/30 text-[#C5A880] flex items-center justify-center flex-shrink-0">
                <BoxIcon className="w-5 h-5" />
              </div>
              <div className="text-xs font-sans text-[#554F47]">
                <h4 className="font-serif text-sm font-medium text-[#18181D]">
                  Faizan Gems Haute Joaillerie Presentation
                </h4>
                <p className="mt-1 text-[#8C867D] leading-relaxed">
                  Delivered inside a handcrafted lacquered macassar ebony presentation box, with an embossed leather dossier containing specimen documentation and an authorized gemological loupe.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Gemological Dossier & Acquisition (5 Cols) */}
          <div className="lg:col-span-5 space-y-6">
            {/* Header / Badges */}
            <div>
              <div className="flex items-center justify-between gap-2 mb-3">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 bg-white border border-[#C5A880] text-[#9A7B4F] text-[11px] font-sans font-medium uppercase tracking-wider flex items-center gap-1.5">
                    <CertificateShieldIcon className="w-3.5 h-3.5" />
                    Authentic Natural Specimen
                  </span>
                </div>
                <span className="text-xs font-mono text-[#8C867D]">
                  {gem.sku}
                </span>
              </div>

              <h1 className="font-serif text-3xl sm:text-4xl text-[#18181D] font-normal leading-tight">
                {gem.name}
              </h1>

              {/* Multiple Carat Weight Selector */}
              {variants.length > 0 && (
                <div className="mt-5 p-4 bg-white border border-[#E8E4DC] space-y-2.5 shadow-sm">
                  <div className="flex items-center justify-between text-xs font-sans">
                    <span className="text-[11px] uppercase tracking-wider text-[#9A7B4F] font-semibold">
                      Select Carat Weight &amp; Size:
                    </span>
                    <span className="text-[#8C867D] text-[11px]">
                      {variants.length} option{variants.length > 1 ? "s" : ""} available
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {variants.map((variant, idx) => {
                      const isSelected = selectedVariantIndex === idx;
                      const isVarOut = (variant.stock ?? 0) <= 0;
                      return (
                        <button
                          key={variant.id || idx}
                          type="button"
                          disabled={isVarOut}
                          onClick={() => {
                            setSelectedVariantIndex(idx);
                            setQuantity(1);
                          }}
                          className={`px-3.5 py-2 rounded border text-xs font-sans transition-all flex flex-col items-center gap-0.5 ${
                            isSelected
                              ? "border-[#C5A880] bg-[#18181D] text-white ring-2 ring-[#C5A880]/40 shadow-sm"
                              : isVarOut
                              ? "border-[#E8E4DC] bg-[#F5F3EF] text-[#B0A99F] cursor-not-allowed opacity-60"
                              : "border-[#E8E4DC] bg-white text-[#18181D] hover:border-[#C5A880]"
                          }`}
                        >
                          <span className="font-semibold text-xs">{Number(variant.weight).toFixed(2)} Carat</span>
                          <span className={`text-[10px] ${isSelected ? "text-[#E0CFA9]" : "text-[#8C867D]"}`}>
                            <LuxuryPrice amount={variant.price} size="xs" color={isSelected ? "gold" : "charcoal"} />
                          </span>
                          {isVarOut && (
                            <span className="text-[9px] text-[#A63A3A] font-semibold">Out of Stock</span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Luxury Acquisition Investment Suite */}
              <div className="mt-5 relative overflow-hidden rounded-xl bg-gradient-to-br from-[#1A1A22] via-[#141419] to-[#0A0A0D] border border-[#C5A880]/35 shadow-[0_12px_36px_rgba(0,0,0,0.22)] p-5 sm:p-6 transition-all duration-300 hover:border-[#C5A880]/50 group">
                {/* 24K Gold Hairline & Radiant Radial Glow */}
                <div className="absolute inset-x-0 top-0 h-[1.5px] bg-gradient-to-r from-transparent via-[#E0CFA9] to-transparent opacity-85" />
                <div className="pointer-events-none absolute -top-16 -right-16 w-48 h-48 rounded-full bg-[#C5A880]/10 blur-3xl group-hover:bg-[#C5A880]/15 transition-all duration-500" />
                
                {/* Subtle Watermark Gem Facet Emblem in Background */}
                <div className="pointer-events-none absolute -bottom-7 -right-7 text-[#C5A880] opacity-[0.04] select-none transition-transform duration-700 group-hover:scale-105">
                  <GemIcon className="w-40 h-40" strokeWidth={0.75} />
                </div>

                {/* Top Dossier Bar: Provenance */}
                <div className="relative z-10 flex flex-wrap items-center gap-2.5 pb-3.5 border-b border-[#C5A880]/15">
                  <div className="flex items-center gap-1.5 text-[#C5A880]">
                    <GemIcon className="w-3.5 h-3.5 text-[#C5A880]" />
                    <span className="text-[10px] font-sans font-semibold tracking-wide-luxury uppercase text-[#E0CFA9]">
                      Acquisition Investment
                    </span>
                  </div>
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#C5A880]/15 border border-[#C5A880]/35 text-[#F5EADB] text-[9.5px] uppercase tracking-widest font-sans font-medium">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#C5A880]" />
                    Direct Mine Source
                  </span>
                </div>

                {/* Main Price & Valuation Row */}
                <div className="relative z-10 pt-4">
                  <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-2">
                    <div className="flex items-baseline gap-3">
                      <LuxuryPrice amount={totalItemPrice} size="3xl" weight="bold" color="white" />
                      {quantity > 1 && (
                        <span className="text-xs text-[#A89E90] font-sans">
                          (<LuxuryPrice amount={basePrice} size="xs" color="gold" /> × {quantity})
                        </span>
                      )}
                    </div>

                    {/* Stock Status Pill */}
                    {!isOutOfStock ? (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-[#1F3D2B]/80 text-[#8CE4A8] border border-[#2D5A3C]">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#34D399]" />
                        ✓ In Stock ({currentStock} available)
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-[#3D1F1F]/80 text-[#FCA5A5] border border-[#5A2D2D]">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#EF4444]" />
                        ✕ Out of Stock
                      </span>
                    )}
                  </div>

                  <p className="mt-2.5 text-[11px] text-[#A89E90] font-sans flex items-center gap-1.5 leading-relaxed">
                    <SparklesIcon className="w-3.5 h-3.5 text-[#C5A880] shrink-0" />
                    <span>Direct ethical extraction from {gem.originCountry || gem.origin} with zero intermediary markup.</span>
                  </p>
                </div>

                {/* Bottom Assurance Strip: Vault Dispatch, Sealed Dossier & Integrity */}
                <div className="relative z-10 mt-4 pt-3.5 border-t border-[#C5A880]/15 grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-[11px] font-sans text-[#B3ACA0]">
                  <div className="flex items-center gap-2">
                    <ArmoredTruckIcon className="w-3.5 h-3.5 text-[#C5A880] shrink-0" />
                    <span className="truncate">Insured Armored Transit</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CertificateShieldIcon className="w-3.5 h-3.5 text-[#C5A880] shrink-0" />
                    <span className="truncate">Certified Natural Specimen</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <SecurityLockIcon className="w-3.5 h-3.5 text-[#C5A880] shrink-0" />
                    <span className="truncate">Tamper-Proof Vault Seal</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Description / Story */}
            <p className="text-xs sm:text-sm text-[#554F47] font-sans leading-relaxed">
              {gem.description}
            </p>

            {/* Quantity Selector */}
            {!isOutOfStock && (
              <div className="flex items-center justify-between p-3.5 bg-white border border-[#E8E4DC]">
                <div className="text-xs font-sans">
                  <span className="text-[#18181D] font-medium block">Quantity</span>
                  <span className="text-[10px] text-[#8C867D]">Available in vault: {currentStock}</span>
                </div>
                <div className="flex items-center border border-[#E8E4DC] rounded bg-[#FAF8F5]">
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    disabled={quantity <= 1}
                    className="w-8 h-8 flex items-center justify-center text-sm font-semibold text-[#18181D] hover:bg-white disabled:opacity-40 disabled:hover:bg-transparent transition-colors"
                  >
                    −
                  </button>
                  <span className="w-10 text-center font-mono text-xs font-medium text-[#18181D]">
                    {quantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.min(maxStock, q + 1))}
                    disabled={quantity >= maxStock}
                    className="w-8 h-8 flex items-center justify-center text-sm font-semibold text-[#18181D] hover:bg-white disabled:opacity-40 disabled:hover:bg-transparent transition-colors"
                  >
                    +
                  </button>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="space-y-3 pt-2">
              <div className="flex gap-3">
                <button
                  onClick={handleAddToCart}
                  disabled={isOutOfStock}
                  className={`flex-1 py-4 text-xs uppercase tracking-luxury font-sans font-medium flex items-center justify-center gap-2 transition-all shadow-xl active:scale-95 ${
                    isOutOfStock
                      ? "bg-[#8C867D] text-white cursor-not-allowed opacity-60"
                      : "bg-[#18181D] hover:bg-[#2A2A32] text-white"
                  }`}
                >
                  <BagIcon className="w-4 h-4 text-[#C5A880]" />
                  <span>
                    {isOutOfStock
                      ? "Unavailable (Out of Stock)"
                      : addedAnimation
                      ? "Secured to Acquisition Bag"
                      : "Add to Acquisition Bag"}
                  </span>
                </button>

                <button
                  onClick={() => toggleWishlist(gem.id)}
                  aria-label="Save to Vault"
                  className={`w-14 h-14 border flex items-center justify-center transition-colors ${
                    isFavorited
                      ? "border-[#18181D] bg-[#18181D] text-[#C5A880]"
                      : "border-[#E8E4DC] hover:border-[#18181D] text-[#18181D] bg-white"
                  }`}
                >
                  <HeartIcon className="w-5 h-5" filled={isFavorited} />
                </button>

                <button
                  onClick={handleShare}
                  aria-label="Share Specimen Dossier"
                  className="w-14 h-14 border border-[#E8E4DC] hover:border-[#18181D] text-[#18181D] bg-white flex items-center justify-center transition-colors relative"
                >
                  <ShareIcon className="w-5 h-5" />
                  {copiedLink && (
                    <span className="absolute -top-8 px-2 py-1 bg-black text-white text-[10px] whitespace-nowrap rounded font-mono">
                      Link Copied
                    </span>
                  )}
                </button>
              </div>

              <div>
                <button
                  onClick={() => setIsConsultModalOpen(true)}
                  className="w-full py-3.5 px-4 bg-white border border-[#E8E4DC] hover:border-[#C5A880] text-[#18181D] hover:bg-[#FAF8F5] text-xs font-sans uppercase tracking-wider flex items-center justify-center gap-2 transition-colors shadow-sm"
                >
                  <AwardIcon className="w-4 h-4 text-[#C5A880]" />
                  <span>Arrange Private Gemologist Consultation</span>
                </button>
              </div>
            </div>

            {/* Comprehensive 7-Point Gemological Specifications Table */}
            <div className="bg-white border border-[#E8E4DC] p-5 space-y-4">
              <h3 className="font-serif text-base text-[#18181D] border-b border-[#F2EFE9] pb-2 font-medium">
                Gemological Laboratory Specifications
              </h3>

              <div className="grid grid-cols-2 gap-y-3 gap-x-4 text-xs font-sans">
                <div>
                  <span className="text-[#8C867D] block uppercase tracking-wider text-[10px]">Gem type</span>
                  <span className="text-[#18181D] font-medium">{gem.species || gem.name}</span>
                </div>
                <div>
                  <span className="text-[#8C867D] block uppercase tracking-wider text-[10px]">Weight</span>
                  <span className="text-[#18181D] font-medium">{displayWeight.toFixed(2)} carat</span>
                </div>
                <div>
                  <span className="text-[#8C867D] block uppercase tracking-wider text-[10px]">Clarity</span>
                  <span className="text-[#18181D] font-medium">{gem.clarity}</span>
                </div>
                {displaySize ? (
                  <div>
                    <span className="text-[#8C867D] block uppercase tracking-wider text-[10px]">Size</span>
                    <span className="text-[#18181D] font-medium">{displaySize}</span>
                  </div>
                ) : null}
                <div>
                  <span className="text-[#8C867D] block uppercase tracking-wider text-[10px]">Colour</span>
                  <span className="text-[#18181D] font-medium">{gem.color}</span>
                </div>
                <div>
                  <span className="text-[#8C867D] block uppercase tracking-wider text-[10px]">Shape &amp; Cut</span>
                  <span className="text-[#18181D] font-medium">{gem.cutDetail || gem.cut}</span>
                </div>
                <div>
                  <span className="text-[#8C867D] block uppercase tracking-wider text-[10px]">Treatment</span>
                  <span className="text-[#18181D] font-medium">{gem.treatment || (gem.isUnheated ? "Unheated" : "Standard Traditional")}</span>
                </div>
                <div>
                  <span className="text-[#8C867D] block uppercase tracking-wider text-[10px]">Provenance</span>
                  <span className="text-[#18181D] font-medium">{gem.origin}</span>
                </div>
              </div>
            </div>

            {/* Senior Gemologist Curator's Note */}
            <div className="p-4 bg-[#FAF8F5] border border-[#E8E4DC] text-xs font-sans space-y-1">
              <span className="text-[10px] uppercase tracking-wider text-[#9A7B4F] font-medium block">
                Graduate Gemologist Appraisal Notes:
              </span>
              <p className="italic text-[#554F47]">
                &ldquo;{gem.gemologistNotes}&rdquo;
              </p>
            </div>
          </div>
        </div>

        {/* Story of the Stone */}
        <div className="mt-16 pt-12 border-t border-[#E8E4DC] max-w-4xl mx-auto text-center space-y-4">
          <span className="text-xs font-sans tracking-wide-luxury uppercase text-[#9A7B4F] block">
            The Geological Odyssey
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl text-[#18181D] font-light">
            The Provenance of {gem.name}
          </h2>
          <p className="text-xs sm:text-sm text-[#554F47] font-sans leading-relaxed">
            {gem.story}
          </p>
        </div>

        {/* Similar Curated Gemstones Carousel */}
        {relatedGems.length > 0 && (
          <div className="mt-20 pt-12 border-t border-[#E8E4DC]">
            <div className="flex items-center justify-between mb-8">
              <div>
                <span className="text-[11px] font-sans uppercase tracking-wider text-[#9A7B4F] block">
                  Curated Companions
                </span>
                <h3 className="font-serif text-2xl sm:text-3xl text-[#18181D]">
                  Complementary Vault Acquisitions
                </h3>
              </div>
              <Link href="/shop" className="text-xs uppercase tracking-luxury text-[#18181D] hover:text-[#9A7B4F] font-sans border-b border-[#18181D] pb-0.5">
                View Entire Vault &rarr;
              </Link>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6">
              {relatedGems.map((related) => (
                <GemstoneCard key={related.id} gemstone={related} />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      {isConsultModalOpen && (
        <ConsultationModal gemstone={gem} onClose={() => setIsConsultModalOpen(false)} />
      )}
    </div>
  );
}
