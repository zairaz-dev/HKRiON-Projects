import React, { useState } from "react";
import { UserPlus, Loader2 } from "lucide-react";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { User } from "@hkr/types";
import { BranchItem, CustomerDialog } from "@/features/customers";
import { useCustomersQuery } from "@/features/customers/hooks/use-customers";

import { usePermissions } from "@/hooks/use-permissions";

interface CustomerSelectProps {
  selectedCustomerId: string;
  onCustomerChange: (id: string) => void;
  businessId: string;
  branchId?: string;
  branches: BranchItem[];
  currentUser?: User | null;
}

export function CustomerSelect({
  selectedCustomerId,
  onCustomerChange,
  businessId,
  branchId,
  branches,
  currentUser,
}: CustomerSelectProps) {
  const { hasPermission } = usePermissions();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [error, setError] = useState("");

  const { data: customers = [], isLoading } = useCustomersQuery(businessId, branchId);
  const activeCustomers = React.useMemo(() => {
    const list = customers.filter((c: any) => c.isActive !== false);
    return list.sort((a: any, b: any) => {
      const aWalk = a.isDefault || a.name?.toLowerCase() === "walk-in customer";
      const bWalk = b.isDefault || b.name?.toLowerCase() === "walk-in customer";
      if (aWalk && !bWalk) return -1;
      if (!aWalk && bWalk) return 1;
      return (a.name || "").localeCompare(b.name || "");
    });
  }, [customers]);

  // Auto-select Walk-in Customer if none selected
  React.useEffect(() => {
    if (!selectedCustomerId && activeCustomers.length > 0) {
      const walkIn = activeCustomers.find(
        (c: any) => c.isDefault || c.name?.toLowerCase() === "walk-in customer"
      ) || activeCustomers[0];
      if (walkIn) {
        onCustomerChange(walkIn.id);
      }
    }
  }, [selectedCustomerId, activeCustomers, onCustomerChange]);

  return (
    <div className="flex items-center gap-2 w-full">
      <div className="flex-1">
        {isLoading ? (
          <div className="h-10 px-3 flex items-center border rounded border-input bg-muted/30">
            <Loader2 className="h-4 w-4 animate-spin text-muted-foreground/60 mr-2" />
            <span className="text-xs text-muted-foreground">Loading customers...</span>
          </div>
        ) : (
          <Select
            value={selectedCustomerId}
            onValueChange={onCustomerChange}
            showSearch={true}
            className="w-full h-10 text-sm bg-background border border-input rounded-sm"
          >
            {activeCustomers.map((c) => {
              const isWalkIn = c.isDefault || c.name?.toLowerCase() === "walk-in customer";
              return (
                <option key={c.id} value={c.id}>
                  {isWalkIn ? `🛒 ${c.name} (Default)` : `${c.name}${c.phone ? ` (${c.phone})` : ""}`}
                </option>
              );
            })}
          </Select>
        )}
      </div>

      {hasPermission("contacts:create") && (
        <Button
          type="button"
          variant="secondary"
          onClick={() => setIsCreateOpen(true)}
          className="h-10 w-10 shrink-0 p-0 flex items-center justify-center bg-secondary hover:bg-secondary/80 border border-border"
          title="Add New Customer"
        >
          <UserPlus className="h-4 w-4 text-foreground" />
        </Button>
      )}

      {currentUser && (
        <CustomerDialog
          isOpen={isCreateOpen}
          onClose={() => setIsCreateOpen(false)}
          branches={branches}
          currentUser={currentUser}
          onSuccess={(msg) => {
            console.log(msg);
          }}
          onError={(err) => {
            setError(err);
            alert(err);
          }}
          onSaveSuccess={(newCustomer) => {
            onCustomerChange(newCustomer.id);
          }}
        />
      )}
    </div>
  );
}
