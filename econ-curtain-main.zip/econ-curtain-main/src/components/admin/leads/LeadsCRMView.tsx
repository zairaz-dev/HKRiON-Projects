"use client";

import { useState } from "react";
import {
  MessageSquare,
  Phone,
  Mail,
  Calendar,
  Send,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  User,
  Package,
  ExternalLink,
  ChevronRight,
} from "lucide-react";

interface InquiryItem {
  id: string;
  customerName: string;
  email: string | null;
  phone: string;
  productName: string | null;
  message: string | null;
  status: string;
  createdAt: Date | string;
}

interface LeadsCRMViewProps {
  initialInquiries: InquiryItem[];
}

export default function LeadsCRMView({ initialInquiries }: LeadsCRMViewProps) {
  const [inquiries, setInquiries] = useState<InquiryItem[]>(initialInquiries);
  const [activeStatusTab, setActiveStatusTab] = useState<string>("ALL");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedLead, setSelectedLead] = useState<InquiryItem | null>(
    initialInquiries[0] || null
  );

  const statusTabs = [
    { id: "ALL", label: "All Inquiries", count: inquiries.length },
    {
      id: "PENDING",
      label: "New Leads",
      count: inquiries.filter((i) => i.status === "PENDING").length,
      badgeColor: "bg-emerald-50 text-emerald-700 border-emerald-200",
    },
    {
      id: "CONTACTED",
      label: "Contacted",
      count: inquiries.filter((i) => i.status === "CONTACTED").length,
      badgeColor: "bg-blue-50 text-blue-700 border-blue-200",
    },
    {
      id: "COMPLETED",
      label: "Closed / Won",
      count: inquiries.filter((i) => i.status === "COMPLETED").length,
      badgeColor: "bg-neutral-100 text-neutral-600 border-neutral-200",
    },
  ];

  // Filter inquiries
  const filteredInquiries = inquiries.filter((inq) => {
    const matchesStatus =
      activeStatusTab === "ALL" || inq.status === activeStatusTab;
    const matchesSearch =
      inq.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inq.phone.includes(searchQuery) ||
      (inq.productName &&
        inq.productName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (inq.email && inq.email.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-6 w-full pb-16">
      {/* Header */}
      <div className="bg-white dark:bg-black p-6 sm:p-7 rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 px-2.5 py-0.5 rounded-none">
              LEADS & CRM
            </span>
            <span className="text-xs text-neutral-400 dark:text-neutral-500">• Customer Communications Hub</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white tracking-tight">
            Customer Inquiries & Leads
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Track inquiries, update contact statuses, and chat directly via 1-click WhatsApp.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="text-right hidden sm:block">
            <div className="text-xl font-black text-neutral-900 dark:text-white">{inquiries.length}</div>
            <div className="text-[11px] text-neutral-400 dark:text-neutral-500 uppercase font-bold">Total Inquiries</div>
          </div>
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="bg-white dark:bg-black p-4 rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Status Filter Buttons */}
        <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 scrollbar-none">
          {statusTabs.map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveStatusTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-none text-xs font-bold transition-all whitespace-nowrap cursor-pointer border ${
                activeStatusTab === tab.id
                  ? "bg-amber-500 text-slate-950 border-amber-600 shadow-xs"
                  : "bg-neutral-50 dark:bg-neutral-950 hover:bg-neutral-100 dark:hover:bg-neutral-900 text-neutral-600 dark:text-neutral-300 border-[#E5E5E0] dark:border-neutral-800"
              }`}
            >
              <span>{tab.label}</span>
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded-none font-extrabold ${
                  activeStatusTab === tab.id
                    ? "bg-slate-950/20 text-slate-950"
                    : tab.badgeColor || "bg-neutral-200/60 dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300"
                }`}
              >
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        {/* Search Bar */}
        <div className="relative w-full md:w-72">
          <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-500 pointer-events-none" />
          <input
            type="text"
            placeholder="Search by name, phone, product..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 dark:placeholder:text-neutral-500 outline-hidden font-medium"
          />
        </div>
      </div>

      {/* Main CRM Grid: Left List (7 cols) + Right Lead Details Card (5 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Lead List */}
        <div className="lg:col-span-7 bg-white dark:bg-black rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">
            <span>Inquiry Records ({filteredInquiries.length})</span>
            <span>Date Received</span>
          </div>

          {filteredInquiries.length === 0 ? (
            <div className="p-12 text-center text-neutral-400 dark:text-neutral-500 text-sm">
              <MessageSquare size={36} className="mx-auto mb-2 opacity-30" />
              <p className="font-bold text-neutral-700 dark:text-neutral-300">No matching inquiries found</p>
              <p className="text-xs text-neutral-400 dark:text-neutral-500 mt-0.5">Try changing your search or status filter.</p>
            </div>
          ) : (
            <div className="divide-y divide-neutral-100 dark:divide-neutral-800">
              {filteredInquiries.map((inq) => {
                const isSelected = selectedLead?.id === inq.id;
                const cleanPhone = inq.phone.replace(/[^0-9+]/g, "");
                const whatsappUrl = `https://wa.me/${cleanPhone.replace("+", "")}?text=${encodeURIComponent(
                  `Hello ${inq.customerName}, thank you for contacting SHADEIT BLINDS regarding ${inq.productName || "our shading solutions"}.`
                )}`;

                return (
                  <div
                    key={inq.id}
                    onClick={() => setSelectedLead(inq)}
                    className={`p-4 sm:p-5 flex items-start justify-between gap-4 cursor-pointer transition-colors ${
                      isSelected
                        ? "bg-amber-500/5 dark:bg-amber-400/10 border-l-4 border-l-amber-500"
                        : "hover:bg-neutral-50/80 dark:hover:bg-neutral-900/50"
                    }`}
                  >
                    <div className="min-w-0 space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-neutral-900 dark:text-white">{inq.customerName}</span>
                        <span
                          className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-none border ${
                            inq.status === "COMPLETED"
                              ? "bg-neutral-100 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-400 border-neutral-200 dark:border-neutral-800"
                              : inq.status === "CONTACTED"
                              ? "bg-blue-50 dark:bg-blue-400/10 text-blue-700 dark:text-blue-400 border-blue-200 dark:border-blue-400/30"
                              : "bg-emerald-50 dark:bg-emerald-400/10 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-400/30"
                          }`}
                        >
                          {inq.status === "COMPLETED" ? "Closed" : inq.status === "CONTACTED" ? "Contacted" : "New Lead"}
                        </span>
                      </div>

                      <div className="text-xs text-neutral-500 dark:text-neutral-400 font-medium">
                        Interested in: <span className="font-bold text-neutral-800 dark:text-neutral-200">{inq.productName || "General Consultation"}</span>
                      </div>

                      {inq.message && (
                        <p className="text-xs text-neutral-600 dark:text-neutral-300 line-clamp-1 italic">
                          &quot;{inq.message}&quot;
                        </p>
                      )}

                      <div className="flex items-center gap-3 text-[11px] text-neutral-400 dark:text-neutral-500 pt-1">
                        <span className="font-mono">{inq.phone}</span>
                        {inq.email && <span>• {inq.email}</span>}
                      </div>
                    </div>

                    {/* Quick WhatsApp Action */}
                    <div className="flex items-center gap-2 shrink-0">
                      <a
                        href={whatsappUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-none bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs shadow-2xs transition-colors"
                        title="Chat on WhatsApp"
                      >
                        <Send size={11} />
                        <span className="hidden sm:inline">WhatsApp</span>
                      </a>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right: Selected Lead Inspection & Status Card */}
        <div className="lg:col-span-5">
          {selectedLead ? (
            <div className="bg-white dark:bg-black rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs p-6 space-y-6 sticky top-24">
              <div className="flex items-center justify-between pb-4 border-b border-neutral-100 dark:border-neutral-800">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
                    Lead Details
                  </span>
                  <h3 className="text-lg font-bold text-neutral-900 dark:text-white mt-0.5">
                    {selectedLead.customerName}
                  </h3>
                </div>
                <div className="w-10 h-10 rounded-none bg-amber-100 dark:bg-amber-400/20 text-amber-900 dark:text-amber-400 font-bold flex items-center justify-center text-sm border border-amber-300/40">
                  {selectedLead.customerName.charAt(0).toUpperCase()}
                </div>
              </div>

              {/* Direct Communication Buttons */}
              <div className="grid grid-cols-2 gap-3">
                <a
                  href={`https://wa.me/${selectedLead.phone.replace(/[^0-9]/g, "")}?text=${encodeURIComponent(
                    `Hello ${selectedLead.customerName}, this is SHADEIT BLINDS reaching out regarding your inquiry for ${selectedLead.productName || "window coverings"}!`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-none bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs shadow-xs transition-colors"
                >
                  <Send size={13} />
                  <span>Chat on WhatsApp</span>
                </a>

                <a
                  href={`tel:${selectedLead.phone.replace(/[^0-9+]/g, "")}`}
                  className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-none bg-neutral-100 dark:bg-neutral-900 hover:bg-neutral-200 dark:hover:bg-neutral-800 text-neutral-800 dark:text-neutral-200 font-bold text-xs border border-[#E5E5E0] dark:border-neutral-800 transition-colors"
                >
                  <Phone size={13} />
                  <span>Call Customer</span>
                </a>
              </div>

              {/* Information Fields */}
              <div className="space-y-3.5 text-xs bg-neutral-50 dark:bg-neutral-950 p-4 rounded-none border border-[#E5E5E0] dark:border-neutral-800">
                <div>
                  <span className="text-neutral-400 dark:text-neutral-500 font-medium block mb-0.5">Phone Number:</span>
                  <span className="font-bold text-neutral-900 dark:text-white font-mono text-sm">{selectedLead.phone}</span>
                </div>

                {selectedLead.email && (
                  <div>
                    <span className="text-neutral-400 dark:text-neutral-500 font-medium block mb-0.5">Email Address:</span>
                    <span className="font-bold text-neutral-900 dark:text-white">{selectedLead.email}</span>
                  </div>
                )}

                <div>
                  <span className="text-neutral-400 dark:text-neutral-500 font-medium block mb-0.5">Product of Interest:</span>
                  <span className="font-bold text-amber-800 dark:text-amber-300 bg-amber-100/60 dark:bg-amber-400/10 px-2 py-0.5 rounded-none border border-amber-200 dark:border-amber-400/30 inline-block">
                    {selectedLead.productName || "General Inquiries"}
                  </span>
                </div>

                {selectedLead.message && (
                  <div>
                    <span className="text-neutral-400 dark:text-neutral-500 font-medium block mb-0.5">Customer Message:</span>
                    <p className="text-neutral-700 dark:text-neutral-300 bg-white dark:bg-black p-3 rounded-none border border-[#E5E5E0] dark:border-neutral-800 leading-relaxed">
                      {selectedLead.message}
                    </p>
                  </div>
                )}

                <div>
                  <span className="text-neutral-400 dark:text-neutral-500 font-medium block mb-0.5">Date Received:</span>
                  <span className="font-medium text-neutral-600 dark:text-neutral-400">
                    {new Date(selectedLead.createdAt).toLocaleString()}
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white dark:bg-black rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs p-8 text-center text-neutral-400 dark:text-neutral-500 text-xs">
              Select a lead from the list to view full customer communication details.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
