'use client';
import { useState, useEffect, useRef } from 'react';
import { 
  Bot, 
  Sparkles, 
  Key, 
  Send, 
  CheckCircle2, 
  AlertCircle, 
  Loader2, 
  Settings2, 
  Copy, 
  Check, 
  Zap, 
  MessageCircle,
  BrainCircuit,
  Mic,
  Volume2,
  Radio,
  Play,
  Square,
  ExternalLink,
  Gift
} from 'lucide-react';
import { getStoredAiConfig, setStoredAiConfig, generateAiReply, fetchServerAiConfig } from '@/lib/openRouterApi';

export default function AiBotManager() {
  const [apiKey, setApiKey] = useState(() => getStoredAiConfig().apiKey || '');
  const [model, setModel] = useState(() => getStoredAiConfig().model || 'meta-llama/llama-3.3-70b-instruct');
  const [systemPrompt, setSystemPrompt] = useState(() => getStoredAiConfig().systemPrompt || '');
  const [enabled, setEnabled] = useState(() => getStoredAiConfig().enabled !== false);

  // Voice AI states
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [voiceReplyMode, setVoiceReplyMode] = useState('match_incoming');
  const [sttProvider, setSttProvider] = useState('openrouter_gemini');
  const [ttsProvider, setTtsProvider] = useState('free_google');
  const [ttsVoice, setTtsVoice] = useState('nova');
  const [geminiApiKey, setGeminiApiKey] = useState('');
  const [groqApiKey, setGroqApiKey] = useState('');
  const [openAiApiKey, setOpenAiApiKey] = useState('');

  // Voice test preview state
  const [testingVoice, setTestingVoice] = useState(false);
  const [testAudioUrl, setTestAudioUrl] = useState(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [audioElement, setAudioElement] = useState(null);

  useEffect(() => {
    fetchServerAiConfig().then((cfg) => {
      if (cfg) {
        if (cfg.apiKey) setApiKey(cfg.apiKey);
        if (cfg.model) setModel(cfg.model);
        if (cfg.systemPrompt) setSystemPrompt(cfg.systemPrompt);
        if (cfg.enabled !== undefined) setEnabled(cfg.enabled);
        if (cfg.voiceEnabled !== undefined) setVoiceEnabled(cfg.voiceEnabled);
        if (cfg.voiceReplyMode) setVoiceReplyMode(cfg.voiceReplyMode);
        if (cfg.sttProvider) setSttProvider(cfg.sttProvider);
        if (cfg.ttsProvider) setTtsProvider(cfg.ttsProvider);
        if (cfg.ttsVoice) setTtsVoice(cfg.ttsVoice);
        if (cfg.geminiApiKey) setGeminiApiKey(cfg.geminiApiKey);
        if (cfg.groqApiKey) setGroqApiKey(cfg.groqApiKey);
        if (cfg.openAiApiKey) setOpenAiApiKey(cfg.openAiApiKey);
      }
    });
  }, []);

  // Playground & UI state
  const [testInput, setTestInput] = useState('வணக்கம்! உங்களுடைய services என்னென்ன?');
  const [testReply, setTestReply] = useState('');
  const [testing, setTesting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [error, setError] = useState('');

  const webhookUrl = typeof window !== 'undefined' ? `${window.location.origin}/api/webhook/whatsapp` : 'http://localhost:3000/api/webhook/whatsapp';

  const handleSaveSettings = () => {
    setStoredAiConfig({
      apiKey: apiKey.trim(),
      model,
      systemPrompt: systemPrompt.trim(),
      enabled,
      voiceEnabled,
      voiceReplyMode,
      sttProvider,
      ttsProvider,
      ttsVoice,
      geminiApiKey: geminiApiKey.trim(),
      groqApiKey: groqApiKey.trim(),
      openAiApiKey: openAiApiKey.trim(),
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleTestAi = async (e) => {
    e.preventDefault();
    if (!testInput) return;

    setTesting(true);
    setTestReply('');
    setError('');
    setTestAudioUrl(null);

    try {
      const reply = await generateAiReply(testInput, systemPrompt, apiKey, model);
      setTestReply(reply);
    } catch (err) {
      setError(err.message || 'Failed to generate AI response');
    } finally {
      setTesting(false);
    }
  };

  const audioRef = useRef(null);

  const handleTestVoiceAudio = async () => {
    const textToSpeak = testReply || 'வணக்கம்! HKRiON AI WhatsApp Voice Assistant உங்களுக்கு உதவ தயாராக உள்ளது.';
    
    if (ttsProvider === 'openai' && !openAiApiKey) {
      setError('Please provide an OpenAI API Key or switch Voice TTS to "Microsoft Neural AI Voice (100% Free)"');
      return;
    }

    setTestingVoice(true);
    setError('');

    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: textToSpeak,
          apiKey: openAiApiKey,
          voice: ttsVoice,
          provider: ttsProvider,
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to generate voice audio');
      }

      setTestAudioUrl(data.audio);
      if (audioRef.current) {
        audioRef.current.pause();
      }
      const audio = new Audio(data.audio);
      audioRef.current = audio;
      audio.onended = () => setIsPlayingAudio(false);
      audio.play();
      setIsPlayingAudio(true);
    } catch (err) {
      setError(err.message || 'Voice generation failed');
    } finally {
      setTestingVoice(false);
    }
  };

  const toggleAudioPlayback = () => {
    if (!audioRef.current) return;
    if (isPlayingAudio) {
      audioRef.current.pause();
      setIsPlayingAudio(false);
    } else {
      audioRef.current.play();
      setIsPlayingAudio(true);
    }
  };

  const copyWebhook = () => {
    navigator.clipboard.writeText(webhookUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const models = [
    { id: 'meta-llama/llama-3.3-70b-instruct', name: 'Llama 3.3 70B (Recommended - Fast & Powerful)' },
    { id: 'openai/gpt-4o-mini', name: 'OpenAI GPT-4o Mini (Smart & Concise)' },
    { id: 'google/gemini-flash-1.5', name: 'Google Gemini Flash 1.5 (Lightning Speed)' },
    { id: 'google/gemini-2.0-flash-lite-001', name: 'Google Gemini 2.0 Flash Lite (Fast & Lite)' },
    { id: 'anthropic/claude-3.5-haiku', name: 'Claude 3.5 Haiku (High Accuracy)' },
  ];

  const voiceOptions = [
    // 🇱🇰 Sri Lanka Tamil Voices
    { id: 'ta-LK-SaranyaNeural', name: '🇱🇰 👩 சரண்யா - Saranya (Sri Lanka Tamil Female - இலங்கைத் தமிழ்)' },
    { id: 'ta-LK-KumarNeural', name: '🇱🇰 👨 குமார் - Kumar (Sri Lanka Tamil Male - இலங்கைத் தமிழ் ஆண்)' },
    
    // 🇮🇳 India Tamil Voices
    { id: 'ta-IN-PallaviNeural', name: '🇮🇳 👩 பல்லவி - Pallavi (India Tamil Female - மென்மையான குரல்)' },
    { id: 'ta-IN-ValluvarNeural', name: '🇮🇳 👨 வள்ளுவர் - Valluvar (India Tamil Male - கம்பீரமான குரல்)' },
    
    // 🇸🇬 & 🇲🇾 International Tamil Voices
    { id: 'ta-SG-VenbaNeural', name: '🇸🇬 👩 வெண்பா - Venba (Singapore Tamil Female)' },
    { id: 'ta-SG-AnbuNeural', name: '🇸🇬 👨 அன்பு - Anbu (Singapore Tamil Male)' },
    { id: 'ta-MY-KaniNeural', name: '🇲🇾 👩 கனி - Kani (Malaysia Tamil Female)' },
    { id: 'ta-MY-SuryaNeural', name: '🇲🇾 👨 சூர்யா - Surya (Malaysia Tamil Male)' },
    
    // 🔤 Tanglish & Indian English Voices (Best for mixed Tamil + English)
    { id: 'en-IN-NeerjaExpressiveNeural', name: '🔤 👩 Neerja Expressive (Tanglish & Indian English - Best for Mixed Lang)' },
    { id: 'en-IN-NeerjaNeural', name: '🔤 👩 Neerja (Tanglish & Indian English Friendly Female)' },
    { id: 'en-IN-PrabhatNeural', name: '🔤 👨 Prabhat (Tanglish & Indian English Professional Male)' },
    
    // 🌐 International English Voices
    { id: 'en-US-JennyNeural', name: '🇺🇸 👩 Jenny (US English Natural Female)' },
    { id: 'en-US-GuyNeural', name: '🇺🇸 👨 Guy (US English Professional Male)' },
    { id: 'en-GB-SoniaNeural', name: '🇬🇧 👩 Sonia (British English Female)' },
  ];

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="glass-card rounded-3xl p-6 border border-emerald-500/30 bg-gradient-to-r from-emerald-950/40 via-slate-900 to-cyan-950/40 relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 flex items-center justify-center font-bold shadow-lg shadow-emerald-500/20 shrink-0">
              <Bot className="w-7 h-7" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-950 border border-emerald-800 text-emerald-400 text-xs font-mono mb-1">
                <BrainCircuit className="w-3.5 h-3.5" /> Text & Voice AI Auto-Reply
              </div>
              <h2 className="text-2xl font-heading font-extrabold text-white">
                WhatsApp AI Auto-Reply & Voice Bot
              </h2>
              <p className="text-xs text-slate-300 mt-0.5">
                Respond to text and voice notes automatically in WhatsApp with AI Speech-to-Text & Voice Replies
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleSaveSettings}
              className="emerald-glow-btn text-slate-950 font-bold text-xs px-5 py-2.5 rounded-xl flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4 fill-slate-950" /> Save Config
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: AI & Voice Settings */}
        <div className="space-y-6">
          {/* Main AI Settings Card */}
          <div className="glass-card rounded-3xl p-6 border border-slate-800 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-white font-bold text-sm">
              <span className="flex items-center gap-2">
                <Settings2 className="w-4 h-4 text-emerald-400" /> OpenRouter LLM Settings
              </span>
              <span className="text-[11px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-mono">
                Active
              </span>
            </div>

            {savedSuccess && (
              <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-800/60 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" /> Configuration saved successfully!
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-amber-400" /> OpenRouter API Key
              </label>
              <input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="sk-or-v1-..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 font-mono outline-none transition-colors"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                AI LLM Model
              </label>
              <select
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 outline-none transition-colors"
              >
                {models.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                System Persona & Rules
              </label>
              <textarea
                value={systemPrompt}
                onChange={(e) => setSystemPrompt(e.target.value)}
                rows={4}
                placeholder="Define how the AI should respond on WhatsApp..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 outline-none transition-colors"
              />
            </div>
          </div>

          {/* Voice AI Settings Card */}
          <div className="glass-card rounded-3xl p-6 border border-slate-800 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-white font-bold text-sm">
              <span className="flex items-center gap-2">
                <Mic className="w-4 h-4 text-cyan-400" /> WhatsApp Voice Notes (STT & TTS)
              </span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={voiceEnabled} 
                  onChange={(e) => setVoiceEnabled(e.target.checked)}
                  className="sr-only peer" 
                />
                <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
              </label>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Voice Reply Mode
                </label>
                <select
                  value={voiceReplyMode}
                  onChange={(e) => setVoiceReplyMode(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 outline-none transition-colors"
                >
                  <option value="match_incoming">Match Incoming (Voice for Voice, Text for Text)</option>
                  <option value="always_voice">Always Reply with Voice Note (PTT)</option>
                  <option value="always_text">Text Only (Listen to Voice, reply as Text)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <Volume2 className="w-3.5 h-3.5 text-cyan-400" /> Voice Audio Generator (TTS)
                </label>
                <select
                  value={ttsProvider}
                  onChange={(e) => setTtsProvider(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 outline-none transition-colors"
                >
                  <option value="edge_neural">✨ Microsoft Neural AI Voice (100% FREE - Natural Tamil & English)</option>
                  <option value="openai">OpenAI Voice Studio (Requires OpenAI Key)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Volume2 className="w-3.5 h-3.5 text-emerald-400" /> Voice Tone (குரல் தேர்வு)
              </label>
              <select
                value={ttsVoice}
                onChange={(e) => setTtsVoice(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 outline-none transition-colors"
              >
                {voiceOptions.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Mic className="w-3.5 h-3.5 text-emerald-400" /> Speech-to-Text Transcription (STT)
              </label>
              <select
                value={sttProvider}
                onChange={(e) => setSttProvider(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 outline-none transition-colors"
              >
                <option value="openrouter_gemini">✨ OpenRouter Gemini Audio (Uses existing OpenRouter Key - No Extra Setup)</option>
                <option value="gemini_studio">Google AI Studio Gemini Key (100% Free)</option>
                <option value="groq">Groq Whisper (Fast & Free)</option>
                <option value="openai">OpenAI Whisper (Paid)</option>
              </select>
            </div>

            {/* Optional Keys based on selection */}
            {sttProvider === 'gemini_studio' && (
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-amber-400" /> Google AI Studio Key (Free)
                  </label>
                  <a 
                    href="https://aistudio.google.com/apikey" 
                    target="_blank" 
                    rel="noreferrer" 
                    className="text-[11px] text-cyan-400 hover:underline flex items-center gap-1"
                  >
                    Get Free Key <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
                <input
                  type="password"
                  value={geminiApiKey}
                  onChange={(e) => setGeminiApiKey(e.target.value)}
                  placeholder="AIzaSy..."
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 font-mono outline-none transition-colors"
                />
              </div>
            )}

            {sttProvider === 'groq' && (
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-amber-400" /> Groq API Key (Fast STT)
                  </label>
                  <a 
                    href="https://console.groq.com/keys" 
                    target="_blank" 
                    rel="noreferrer" 
                    className="text-[11px] text-cyan-400 hover:underline flex items-center gap-1"
                  >
                    Get Groq Key <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
                <input
                  type="password"
                  value={groqApiKey}
                  onChange={(e) => setGroqApiKey(e.target.value)}
                  placeholder="gsk_..."
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 font-mono outline-none transition-colors"
                />
              </div>
            )}

            {ttsProvider === 'openai' && (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <Key className="w-3.5 h-3.5 text-amber-400" /> OpenAI API Key
                </label>
                <input
                  type="password"
                  value={openAiApiKey}
                  onChange={(e) => setOpenAiApiKey(e.target.value)}
                  placeholder="sk-proj-..."
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 font-mono outline-none transition-colors"
                />
              </div>
            )}

            {ttsProvider === 'edge_neural' && sttProvider === 'openrouter_gemini' && (
              <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-800/40 flex items-center gap-3">
                <Gift className="w-5 h-5 text-emerald-400 shrink-0" />
                <p className="text-[11px] text-emerald-300">
                  <strong>100% இலவச மோட் தயார்:</strong> OpenRouter Gemini + Microsoft Neural Natural Tamil Voice மூலமாக எந்தக் கூடுதல் API Key-யும் இல்லாமல் மிகத் துல்லியமான Voice Replies இயங்கும்!
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: AI Test Playground & Webhook Info */}
        <div className="space-y-6">
          {/* Playground Card */}
          <div className="glass-card rounded-3xl p-6 border border-slate-800 space-y-5">
            <div className="flex items-center gap-2.5 pb-3 border-b border-slate-800 text-white font-bold text-sm">
              <MessageCircle className="w-4 h-4 text-cyan-400" /> AI & Voice Simulator
            </div>

            <form onSubmit={handleTestAi} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Test Customer Message (Tamil / English)
                </label>
                <textarea
                  value={testInput}
                  onChange={(e) => setTestInput(e.target.value)}
                  rows={3}
                  placeholder="Type a sample customer question..."
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 outline-none transition-colors"
                />
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="submit"
                  disabled={testing}
                  className="flex-1 bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-bold text-xs py-2.5 rounded-xl flex items-center justify-center gap-2 transition-all shadow-md shadow-emerald-950"
                >
                  {testing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4 fill-slate-950" />}
                  {testing ? 'AI is Thinking...' : 'Generate Text Reply'}
                </button>

                <button
                  type="button"
                  onClick={handleTestVoiceAudio}
                  disabled={testingVoice}
                  className="px-4 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-400 font-semibold text-xs py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition-all"
                  title="Generate & Listen Voice Reply"
                >
                  {testingVoice ? <Loader2 className="w-4 h-4 animate-spin" /> : <Volume2 className="w-4 h-4" />}
                  {testingVoice ? 'Synthesizing...' : 'Preview Voice'}
                </button>
              </div>
            </form>

            {error && (
              <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-800/60 text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" /> {error}
              </div>
            )}

            {testReply && (
              <div className="p-4 rounded-2xl bg-slate-950 border border-emerald-500/40 space-y-3 animate-fadeIn">
                <div className="text-[11px] font-bold text-emerald-400 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Bot className="w-3.5 h-3.5" /> Generated Response:
                  </span>
                  {testAudioUrl && (
                    <button
                      onClick={toggleAudioPlayback}
                      className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800 text-cyan-400 hover:bg-cyan-900"
                    >
                      {isPlayingAudio ? <Square className="w-3 h-3" /> : <Play className="w-3 h-3 fill-cyan-400" />}
                      {isPlayingAudio ? 'Stop Voice' : 'Play Voice'}
                    </button>
                  )}
                </div>
                <p className="text-xs text-slate-200 leading-relaxed bg-slate-900/60 p-3 rounded-xl border border-slate-800/80">
                  &quot;{testReply}&quot;
                </p>
              </div>
            )}
          </div>

          {/* Webhook Endpoint Box */}
          <div className="glass-card rounded-3xl p-6 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-300 font-semibold">
              <span className="flex items-center gap-1.5 text-cyan-400">
                <Zap className="w-3.5 h-3.5" /> Webhook Listener Endpoint
              </span>
              <button
                onClick={copyWebhook}
                className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 bg-slate-900 px-2 py-0.5 rounded border border-slate-800"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                {copied ? 'Copied' : 'Copy'}
              </button>
            </div>
            <p className="text-[11px] text-slate-400 font-mono break-all bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              {webhookUrl}
            </p>
            <p className="text-[11px] text-slate-500">
              Evolution API-ல் இந்த URL-ஐ Webhook ஆக இணைத்தால் Text & Voice Messages-க்கு தானாக AI பதில் அனுப்பும்.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
