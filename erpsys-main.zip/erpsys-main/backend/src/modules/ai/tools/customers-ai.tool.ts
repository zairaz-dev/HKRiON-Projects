import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class CustomersAiTool {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Get top customers, outstanding receivables, and customer metrics
   */
  async getCustomersContext(businessId: string, limit = 5) {
    const [totalCustomerCount, customers] = await Promise.all([
      this.prisma.customer.count({ where: { businessId } }),
      this.prisma.customer.findMany({
        where: { businessId },
        orderBy: { createdAt: 'desc' },
        take: 20,
        include: {
          sales: {
            select: { grandTotal: true, amountPaid: true },
          },
        },
      }),
    ]);

    let totalReceivableDues = 0;

    const enriched = customers.map((c: any) => {
      const salesList: any[] = c.sales || [];
      const totalSpent = salesList.reduce((sum: number, s: any) => sum + Number(s.grandTotal || 0), 0);
      const totalPaid = salesList.reduce((sum: number, s: any) => sum + Number(s.amountPaid || 0), 0);
      const outstandingDue = Math.max(0, totalSpent - totalPaid);

      totalReceivableDues += outstandingDue;

      return {
        id: c.id,
        name: c.name,
        phone: c.phone || 'N/A',
        totalOrders: salesList.length,
        totalSpent,
        outstandingDue,
      };
    });

    enriched.sort((a, b) => b.totalSpent - a.totalSpent);

    return {
      totalCustomersRegistered: totalCustomerCount,
      totalReceivableDuesAcrossCustomers: totalReceivableDues,
      topValuedCustomers: enriched.slice(0, limit),
    };
  }
}
