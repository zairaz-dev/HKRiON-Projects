"use client";

import React, { createContext, useContext, useState, useEffect } from "react";
import { STORAGE_KEYS } from "@/lib/constants/storage";

interface WishlistContextType {
  wishlist: string[]; // Gemstone IDs
  toggleWishlist: (gemstoneId: string) => void;
  isInWishlist: (gemstoneId: string) => boolean;
  wishlistCount: number;
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

export function WishlistProvider({ children }: { children: React.ReactNode }) {
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        const saved =
          localStorage.getItem(STORAGE_KEYS.wishlist) ||
          localStorage.getItem(STORAGE_KEYS.legacyWishlist);
        if (saved) {
          setWishlist(JSON.parse(saved));
        }
      } catch {
        // ignore
      }
      setIsInitialized(true);
    }, 0);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (isInitialized) {
      localStorage.setItem(STORAGE_KEYS.wishlist, JSON.stringify(wishlist));
    }
  }, [wishlist, isInitialized]);

  const toggleWishlist = (gemstoneId: string) => {
    setWishlist((prev) =>
      prev.includes(gemstoneId)
        ? prev.filter((id) => id !== gemstoneId)
        : [...prev, gemstoneId]
    );
  };

  const isInWishlist = (gemstoneId: string) => wishlist.includes(gemstoneId);

  return (
    <WishlistContext.Provider
      value={{
        wishlist,
        toggleWishlist,
        isInWishlist,
        wishlistCount: wishlist.length,
      }}
    >
      {children}
    </WishlistContext.Provider>
  );
}

export function useWishlist() {
  const context = useContext(WishlistContext);
  if (!context) {
    throw new Error("useWishlist must be used within a WishlistProvider");
  }
  return context;
}
