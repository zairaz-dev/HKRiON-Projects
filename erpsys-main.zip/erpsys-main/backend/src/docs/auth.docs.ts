export const LoginBodySchema = {
  type: 'object',
  properties: {
    email: { type: 'string', example: 'admin@hkr.com' },
    password: { type: 'string', example: 'admin123' },
  },
  required: ['email', 'password'],
};

export const LoginResponseSchema = {
  type: 'object',
  properties: {
    token: { type: 'string', example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1c3JfMTIzIiwiZW1haWwiOiJhZG1pbkBoa3IuY29tIiwicm9sZSI6ImFkbWluIn0...' },
    user: {
      type: 'object',
      properties: {
        id: { type: 'string', example: 'usr_9b1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6d' },
        email: { type: 'string', example: 'admin@hkr.com' },
        name: { type: 'string', example: 'HKR Admin' },
        role: { type: 'string', example: 'admin' },
        businessId: { type: 'string', example: 'biz_8a1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6a' },
        createdAt: { type: 'string', example: '2026-08-16T08:00:00.000Z' },
      },
    },
  },
};

export const GoogleLoginBodySchema = {
  type: 'object',
  properties: {
    token: { type: 'string', example: 'ya29.a0AfH6SMD_EXAMPLE_GOOGLE_ID_OR_ACCESS_TOKEN' },
  },
  required: ['token'],
};

export const GoogleLoginResponseSchema = {
  type: 'object',
  properties: {
    token: { type: 'string', example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...' },
    user: {
      type: 'object',
      properties: {
        id: { type: 'string', example: 'usr_google_123' },
        email: { type: 'string', example: 'owner@gmail.com' },
        name: { type: 'string', example: 'Google Owner' },
        role: { type: 'string', example: 'admin' },
        businessId: { type: 'string', example: 'biz_123' },
      },
    },
  },
};

export const CreateUserBodySchema = {
  type: 'object',
  properties: {
    name: { type: 'string', example: 'Alex Manager' },
    email: { type: 'string', example: 'alex@hkr.com' },
    password: { type: 'string', example: 'Password@123' },
    role: { type: 'string', example: 'manager' },
    businessId: { type: 'string', example: 'biz_8a1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6a' },
    branchIds: {
      type: 'array',
      items: { type: 'string' },
      example: ['branch_001', 'branch_002'],
    },
    phone: { type: 'string', example: '+94 77 123 4567' },
    avatar: { type: 'string', example: 'https://example.com/avatar.jpg' },
    address: { type: 'string', example: '123 Main Street, Colombo' },
    isActive: { type: 'boolean', example: true },
  },
  required: ['name', 'email', 'password', 'role'],
};

export const UserResponseSchema = {
  type: 'object',
  properties: {
    id: { type: 'string', example: 'usr_102' },
    name: { type: 'string', example: 'Alex Manager' },
    email: { type: 'string', example: 'alex@hkr.com' },
    role: { type: 'string', example: 'manager' },
    businessId: { type: 'string', example: 'biz_8a1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6a' },
    phone: { type: 'string', example: '+94 77 123 4567' },
    isActive: { type: 'boolean', example: true },
    avatar: { type: 'string', example: 'https://example.com/avatar.jpg' },
    address: { type: 'string', example: '123 Main Street, Colombo' },
    lastLoginAt: { type: 'string', example: '2026-09-01T10:30:00.000Z' },
    lastLoginIp: { type: 'string', example: '192.168.1.1' },
    branches: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string', example: 'branch_001' },
          name: { type: 'string', example: 'Main Branch' },
        },
      },
    },
    createdAt: { type: 'string', example: '2026-08-16T14:30:00.000Z' },
  },
};

export const UsersListResponseSchema = {
  type: 'array',
  items: UserResponseSchema,
};

export const UpdateUserBodySchema = {
  type: 'object',
  properties: {
    name: { type: 'string', example: 'Alex Senior Manager' },
    email: { type: 'string', example: 'alex_new@hkr.com' },
    role: { type: 'string', example: 'manager' },
    password: { type: 'string', example: 'NewPassword@123' },
    phone: { type: 'string', example: '+94 77 123 4567' },
    avatar: { type: 'string', example: 'https://example.com/avatar.jpg' },
    address: { type: 'string', example: '123 Main Street, Colombo' },
    isActive: { type: 'boolean', example: true },
    branchIds: {
      type: 'array',
      items: { type: 'string' },
      example: ['branch_001'],
    },
  },
};

export const DeleteUserResponseSchema = {
  type: 'object',
  properties: {
    success: { type: 'boolean', example: true },
  },
};
