import Navbar from '@/components/Navbar';
import ContactForm from '@/components/ContactForm';
import FAQ from '@/components/FAQ';
import Footer from '@/components/Footer';
import FloatingWidgets from '@/components/FloatingWidgets';
import { Mail, Phone, MapPin, Headphones } from 'lucide-react';

export const metadata = {
  title: 'Contact & Support | HKRION (Pvt) Ltd',
  description: 'Get in touch with HKRION (Pvt) Ltd for free technical consultation, live product demos, and enterprise custom proposals.',
};

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-black text-neutral-100 flex flex-col font-sans">
      <Navbar />
      <main className="grow pt-24">
        
        {/* Dedicated Contact Header Banner */}
        <section className="py-20 relative bg-neutral-950 border-b border-[#1ABE56]/30 overflow-hidden">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#1ABE56]/15 blur-[150px] rounded-full pointer-events-none" />
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-4">
           
            <h1 className="text-4xl sm:text-6xl font-extrabold text-white">
              Contact <span className="gradient-text">HKRION Team</span>
            </h1>
            <p className="text-neutral-300 max-w-2xl mx-auto text-base sm:text-lg leading-relaxed">
              Have a project requirement or need a live demo of HKRION POS/ERP? Our solution engineers are available 24/7.
            </p>
          </div>
        </section>

        {/* Direct Contact Cards */}
        <section className="py-12 bg-black border-b border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            
            <div className="glass-card p-6 rounded-2xl border border-[#1ABE56]/30 bg-black/80 flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-[#1ABE56]/20 flex items-center justify-center shrink-0">
                <Phone className="w-5 h-5 text-[#1ABE56]" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white mb-1">Direct Hotline</h3>
                <p className="text-xs text-neutral-300 font-mono">+94 77 50 14 217</p>
                <p className="text-[11px] text-neutral-500 mt-1">Mon - Sat (8:00 AM - 8:00 PM)</p>
              </div>
            </div>

            <div className="glass-card p-6 rounded-2xl border border-[#1ABE56]/30 bg-black/80 flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-[#1ABE56]/20 flex items-center justify-center shrink-0">
                <Mail className="w-5 h-5 text-[#1ABE56]" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white mb-1">Email Inquiries</h3>
                <p className="text-xs text-neutral-300 font-mono">contact@hkrion.com</p>
                <p className="text-[11px] text-neutral-500 mt-1">Guaranteed reply within 4 hours</p>
              </div>
            </div>

            <div className="glass-card p-6 rounded-2xl border border-[#1ABE56]/30 bg-black/80 flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-[#1ABE56]/20 flex items-center justify-center shrink-0">
                <MapPin className="w-5 h-5 text-[#1ABE56]" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white mb-1">Main Head Office</h3>
                <p className="text-xs text-neutral-300 font-mono">Trincomalee</p>
                <p className="text-[11px] text-neutral-500 mt-1">Sri Lanka</p>
              </div>
            </div>

            <div className="glass-card p-6 rounded-2xl border border-[#1ABE56]/30 bg-black/80 flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-[#1ABE56]/20 flex items-center justify-center shrink-0">
                <Headphones className="w-5 h-5 text-[#1ABE56]" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white mb-1">24/7 SLA Support</h3>
                <p className="text-xs text-neutral-300 font-mono">support@hkrion.com</p>
                <p className="text-[11px] text-neutral-500 mt-1">Dedicated ticket dispatch</p>
              </div>
            </div>

          </div>
        </section>

        <ContactForm />
        <FAQ />
      </main>
      <Footer />
      <FloatingWidgets />
    </div>
  );
}
