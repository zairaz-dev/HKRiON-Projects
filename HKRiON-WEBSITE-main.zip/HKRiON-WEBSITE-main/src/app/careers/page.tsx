import Navbar from '@/components/Navbar';
import CareersSection from '@/components/CareersSection';
import Footer from '@/components/Footer';
import FloatingWidgets from '@/components/FloatingWidgets';

export const metadata = {
  title: 'Careers & Job Openings | HKRION (Pvt) Ltd',
  description: 'Join HKRION (Pvt) Ltd. Explore job opportunities for Software Engineers, Mobile Developers, UI/UX Designers, and Interns in Sri Lanka & Remote.',
  keywords: ['HKRION Careers', 'Software Jobs Sri Lanka', 'Next.js Jobs', 'Flutter Jobs', 'Tech Internships Colombo'],
};

export default function CareersPage() {
  return (
    <div className="min-h-screen bg-black text-neutral-100 flex flex-col font-sans selection:bg-[#1ABE56] selection:text-black">
      <Navbar />
      <main className="grow pt-20">
        <CareersSection />
      </main>
      <Footer />
      <FloatingWidgets />
    </div>
  );
}
