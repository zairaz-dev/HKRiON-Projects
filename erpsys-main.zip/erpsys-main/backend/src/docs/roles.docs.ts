export const GetPermissionsResponseSchema = {
  type: 'object',
  additionalProperties: {
    type: 'array',
    items: { type: 'string' },
  },
  example: {
    admin: ['user.manage', 'product.view', 'product.create', 'sale.create', 'pos.view'],
    cashier: ['pos.view', 'sale.create'],
    manager: ['user.manage', 'product.view', 'sale.view', 'pos.view'],
  },
};

export const SavePermissionsBodySchema = {
  type: 'object',
  properties: {
    permissions: {
      type: 'object',
      additionalProperties: {
        type: 'array',
        items: { type: 'string' },
      },
      example: {
        cashier: ['pos.view', 'sale.create', 'sale.view'],
        manager: ['user.manage', 'product.view', 'sale.view', 'pos.view'],
      },
    },
    businessId: { type: 'string', example: 'biz_8a1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6a', nullable: true },
  },
  required: ['permissions'],
};

export const CreateRoleBodySchema = {
  type: 'object',
  properties: {
    role: { type: 'string', example: 'supervisor' },
    name: { type: 'string', example: 'Floor Supervisor' },
    description: { type: 'string', example: 'Handles floor operations and sales returns' },
    permissions: {
      type: 'array',
      items: { type: 'string' },
      example: ['sale.view', 'sale.create', 'sale.return', 'stock.view'],
    },
    businessId: { type: 'string', example: 'biz_8a1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6a', nullable: true },
  },
  required: ['role', 'name', 'permissions'],
};

export const UpdateRoleBodySchema = {
  type: 'object',
  properties: {
    name: { type: 'string', example: 'Lead Floor Supervisor' },
    description: { type: 'string', example: 'Supervises sales floor and inventory adjustments' },
    permissions: {
      type: 'array',
      items: { type: 'string' },
      example: ['sale.view', 'sale.create', 'sale.return', 'stock.view', 'stock.adjust'],
    },
  },
};

export const RoleResponseSchema = {
  type: 'object',
  properties: {
    id: { type: 'string', example: 'role_002' },
    role: { type: 'string', example: 'supervisor' },
    name: { type: 'string', example: 'Floor Supervisor' },
    description: { type: 'string', example: 'Handles floor operations and sales returns' },
    permissions: {
      type: 'array',
      items: { type: 'string' },
      example: ['sale.view', 'sale.create', 'sale.return', 'stock.view'],
    },
    createdAt: { type: 'string', example: '2026-08-16T15:00:00.000Z' },
  },
};

export const RolesListResponseSchema = {
  type: 'array',
  items: RoleResponseSchema,
};

export const DeleteRoleResponseSchema = {
  type: 'object',
  properties: {
    success: { type: 'boolean', example: true },
    message: { type: 'string', example: 'Role deleted successfully' },
  },
};
