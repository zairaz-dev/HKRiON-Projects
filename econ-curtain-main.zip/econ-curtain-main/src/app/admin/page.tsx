import { SessionManager } from "@/core/auth/session";
import { ProductService } from "@/services/product.service";
import { UserService } from "@/services/user.service";
import { InquiryService } from "@/services/inquiry.service";
import {
  Package,
  Layers,
  Users,
  MessageSquare,
  Sparkles,
  ExternalLink,
  ArrowRight,
  Phone,
  Home,
  Image as ImageIcon,
  Settings,
  Send,
} from "lucide-react";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function AdminDashboardPage() {
  const session = await SessionManager.getCurrentSession();

  // Clean Service Queries
  const [products, users, inquiries, categories] = await Promise.all([
    ProductService.getAllForAdmin(),
    UserService.getAll(),
    InquiryService.getAll(),
    ProductService.getCategories(),
  ]);

  const activeProducts = products.filter((p) => p.isActive).length;
  const recentInquiries = inquiries.slice(0, 5);

  return (
    <div className="space-y-8 w-full">
      {/* 1. Welcoming Briefing Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-black p-6 sm:p-8 rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-none bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/30 text-amber-800 dark:text-amber-400 text-[11px] font-bold uppercase tracking-wider mb-2">
            <Sparkles size={13} className="text-amber-600 dark:text-amber-400" />
            <span>SHADEIT CONTROL CENTER</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white tracking-tight">
            Good day, {session?.name || "Admin"} 👋
          </h1>
          <p className="text-neutral-500 dark:text-neutral-400 text-sm mt-1">
            Here is what is happening with your website, inquiries, and catalog.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-3 shrink-0">
          <Link
            href="/admin/homepage"
            className="inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-4 py-2.5 rounded-none text-xs sm:text-sm shadow-xs transition-all active:scale-95"
          >
            <Home size={15} />
            <span>Edit Home CMS</span>
          </Link>
          <Link
            href="/"
            target="_blank"
            className="inline-flex items-center gap-2 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-900 dark:hover:bg-neutral-850 text-neutral-800 dark:text-neutral-200 font-semibold px-4 py-2.5 rounded-none text-xs sm:text-sm border border-[#E5E5E0] dark:border-neutral-800 transition-all active:scale-95"
          >
            <span>Live Site</span>
            <ExternalLink size={13} className="text-neutral-500 dark:text-neutral-400" />
          </Link>
        </div>
      </div>

      {/* 2. Key Performance Indicators (4 Clean Cards) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        <Link
          href="/admin/inquiries"
          className="p-5 sm:p-6 rounded-none bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 hover:border-amber-400/60 dark:hover:border-amber-400/60 shadow-xs hover:shadow-md transition-all group block"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
              Customer Leads
            </span>
            <div className="w-9 h-9 rounded-none bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-400 flex items-center justify-center group-hover:scale-105 transition-transform">
              <MessageSquare size={18} />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <h3 className="text-3xl font-black text-neutral-900 dark:text-white">{inquiries.length}</h3>
            <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-400/10 px-2 py-0.5 rounded-none border border-emerald-200 dark:border-emerald-400/30">
              Active CRM
            </span>
          </div>
          <p className="text-xs text-neutral-400 dark:text-neutral-500 mt-2 font-medium">Click to view inquiries & WhatsApp</p>
        </Link>

        <Link
          href="/admin/products"
          className="p-5 sm:p-6 rounded-none bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 hover:border-amber-400/60 dark:hover:border-amber-400/60 shadow-xs hover:shadow-md transition-all group block"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
              Products Catalog
            </span>
            <div className="w-9 h-9 rounded-none bg-blue-50 dark:bg-blue-400/10 text-blue-700 dark:text-blue-400 flex items-center justify-center group-hover:scale-105 transition-transform">
              <Package size={18} />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <h3 className="text-3xl font-black text-neutral-900 dark:text-white">{products.length}</h3>
            <span className="text-xs font-semibold text-blue-700 dark:text-blue-400 bg-blue-50 dark:bg-blue-400/10 px-2 py-0.5 rounded-none border border-blue-200 dark:border-blue-400/30">
              {activeProducts} Published
            </span>
          </div>
          <p className="text-xs text-neutral-400 dark:text-neutral-500 mt-2 font-medium">13 core shading solutions</p>
        </Link>

        <Link
          href="/admin/categories"
          className="p-5 sm:p-6 rounded-none bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 hover:border-amber-400/60 dark:hover:border-amber-400/60 shadow-xs hover:shadow-md transition-all group block"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
              Categories
            </span>
            <div className="w-9 h-9 rounded-none bg-purple-50 dark:bg-purple-400/10 text-purple-700 dark:text-purple-400 flex items-center justify-center group-hover:scale-105 transition-transform">
              <Layers size={18} />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <h3 className="text-3xl font-black text-neutral-900 dark:text-white">{categories.length}</h3>
            <span className="text-xs font-semibold text-purple-700 dark:text-purple-400 bg-purple-50 dark:bg-purple-400/10 px-2 py-0.5 rounded-none border border-purple-200 dark:border-purple-400/30">
              Divisions
            </span>
          </div>
          <p className="text-xs text-neutral-400 dark:text-neutral-500 mt-2 font-medium">Organized product navigation</p>
        </Link>

        <Link
          href="/admin/users"
          className="p-5 sm:p-6 rounded-none bg-white dark:bg-black border border-[#E5E5E0] dark:border-neutral-800 hover:border-amber-400/60 dark:hover:border-amber-400/60 shadow-xs hover:shadow-md transition-all group block"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
              Admin Users
            </span>
            <div className="w-9 h-9 rounded-none bg-emerald-50 dark:bg-emerald-400/10 text-emerald-700 dark:text-emerald-400 flex items-center justify-center group-hover:scale-105 transition-transform">
              <Users size={18} />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <h3 className="text-3xl font-black text-neutral-900 dark:text-white">{users.length}</h3>
            <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-400/10 px-2 py-0.5 rounded-none border border-emerald-200 dark:border-emerald-400/30">
              Verified
            </span>
          </div>
          <p className="text-xs text-neutral-400 dark:text-neutral-500 mt-2 font-medium">Role-based access control</p>
        </Link>
      </div>

      {/* 3. Quick Action Strip */}
      <div className="bg-white dark:bg-black p-5 rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs">
        <div className="text-xs font-bold uppercase tracking-wider text-neutral-400 dark:text-neutral-500 mb-3">
          Quick Management Actions
        </div>
        <div className="flex flex-wrap gap-2.5">
          <Link
            href="/admin/homepage"
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-neutral-50 hover:bg-neutral-100 dark:bg-neutral-950 dark:hover:bg-neutral-900 text-neutral-800 dark:text-neutral-200 border border-[#E5E5E0] dark:border-neutral-800 rounded-none text-xs font-bold transition-colors"
          >
            <Home size={14} className="text-amber-600 dark:text-amber-400" />
            <span>Customize Home Sections</span>
          </Link>
          <Link
            href="/admin/products"
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-neutral-50 hover:bg-neutral-100 dark:bg-neutral-950 dark:hover:bg-neutral-900 text-neutral-800 dark:text-neutral-200 border border-[#E5E5E0] dark:border-neutral-800 rounded-none text-xs font-bold transition-colors"
          >
            <Package size={14} className="text-blue-600 dark:text-blue-400" />
            <span>Manage Products</span>
          </Link>
          <Link
            href="/admin/inquiries"
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-neutral-50 hover:bg-neutral-100 dark:bg-neutral-950 dark:hover:bg-neutral-900 text-neutral-800 dark:text-neutral-200 border border-[#E5E5E0] dark:border-neutral-800 rounded-none text-xs font-bold transition-colors"
          >
            <MessageSquare size={14} className="text-emerald-600 dark:text-emerald-400" />
            <span>View All Leads</span>
          </Link>
          <Link
            href="/admin/media"
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-neutral-50 hover:bg-neutral-100 dark:bg-neutral-950 dark:hover:bg-neutral-900 text-neutral-800 dark:text-neutral-200 border border-[#E5E5E0] dark:border-neutral-800 rounded-none text-xs font-bold transition-colors"
          >
            <ImageIcon size={14} className="text-purple-600 dark:text-purple-400" />
            <span>Media Library</span>
          </Link>
          <Link
            href="/admin/settings"
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-neutral-50 hover:bg-neutral-100 dark:bg-neutral-950 dark:hover:bg-neutral-900 text-neutral-800 dark:text-neutral-200 border border-[#E5E5E0] dark:border-neutral-800 rounded-none text-xs font-bold transition-colors"
          >
            <Settings size={14} className="text-neutral-600 dark:text-neutral-400" />
            <span>Website Settings</span>
          </Link>
        </div>
      </div>

      {/* 4. Recent Leads Table with Direct WhatsApp/Call Actions */}
      <div className="bg-white dark:bg-black rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs overflow-hidden">
        <div className="p-5 sm:p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-neutral-900 dark:text-white">
              Recent Customer Inquiries & Leads
            </h2>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
              Direct contact requests from the SHADEIT website forms and WhatsApp inquiries.
            </p>
          </div>
          <Link
            href="/admin/inquiries"
            className="text-xs font-bold text-amber-700 dark:text-amber-400 hover:text-amber-800 dark:hover:text-amber-300 hover:underline flex items-center gap-1"
          >
            <span>View All Leads ({inquiries.length})</span>
            <ArrowRight size={13} />
          </Link>
        </div>

        {recentInquiries.length === 0 ? (
          <div className="p-12 text-center text-neutral-400 dark:text-neutral-500 text-sm">
            No customer inquiries yet. New submissions will appear here automatically.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-neutral-100 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950 text-neutral-500 dark:text-neutral-400 font-bold uppercase tracking-wider text-[10px]">
                  <th className="py-3 px-5 sm:px-6">Customer</th>
                  <th className="py-3 px-4">Interested In</th>
                  <th className="py-3 px-4">Phone Number</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-5 sm:px-6 text-right">Quick Contact</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
                {recentInquiries.map((inquiry) => {
                  const cleanPhone = inquiry.phone.replace(/[^0-9+]/g, "");
                  const whatsappUrl = `https://wa.me/${cleanPhone.replace("+", "")}?text=${encodeURIComponent(
                    `Hello ${inquiry.customerName}, thank you for contacting SHADEIT BLINDS regarding ${inquiry.productName || "our shading solutions"}.`
                  )}`;

                  return (
                    <tr key={inquiry.id} className="hover:bg-neutral-50/80 dark:hover:bg-neutral-900/60 transition-colors">
                      <td className="py-4 px-5 sm:px-6">
                        <div className="font-bold text-neutral-900 dark:text-white text-sm">{inquiry.customerName}</div>
                        {inquiry.email && (
                          <div className="text-[11px] text-neutral-400 dark:text-neutral-400 truncate max-w-48">{inquiry.email}</div>
                        )}
                        {inquiry.message && (
                          <div className="text-[11px] text-neutral-500 dark:text-neutral-300 italic mt-0.5 line-clamp-1">
                            &quot;{inquiry.message}&quot;
                          </div>
                        )}
                      </td>
                      <td className="py-4 px-4 font-semibold text-neutral-700 dark:text-neutral-300">
                        <span className="inline-block px-2.5 py-1 rounded-none bg-neutral-100 dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300 text-xs border border-neutral-200/60 dark:border-neutral-800">
                          {inquiry.productName || "General Inquiry"}
                        </span>
                      </td>
                      <td className="py-4 px-4 font-mono text-neutral-700 dark:text-neutral-300">{inquiry.phone}</td>
                      <td className="py-4 px-4">
                        <span
                          className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-none border ${
                            inquiry.status === "COMPLETED"
                              ? "bg-neutral-100 dark:bg-neutral-900 text-neutral-700 dark:text-neutral-400 border-neutral-300 dark:border-neutral-800"
                              : inquiry.status === "CONTACTED"
                              ? "bg-blue-50 dark:bg-blue-400/10 text-blue-700 dark:text-blue-400 border-blue-200 dark:border-blue-400/30"
                              : "bg-emerald-50 dark:bg-emerald-400/10 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-400/30"
                          }`}
                        >
                          <span
                            className={`w-1.5 h-1.5 rounded-none ${
                              inquiry.status === "COMPLETED"
                                ? "bg-neutral-400 dark:bg-neutral-500"
                                : inquiry.status === "CONTACTED"
                                ? "bg-blue-500"
                                : "bg-emerald-500"
                            }`}
                          />
                          {inquiry.status === "COMPLETED"
                            ? "Closed"
                            : inquiry.status === "CONTACTED"
                            ? "Contacted"
                            : "New Lead"}
                        </span>
                      </td>
                      <td className="py-4 px-5 sm:px-6 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <a
                            href={whatsappUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-none bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs transition-colors shadow-2xs"
                            title="Chat on WhatsApp"
                          >
                            <Send size={12} />
                            <span>WhatsApp</span>
                          </a>
                          <a
                            href={`tel:${cleanPhone}`}
                            className="p-1.5 rounded-none bg-neutral-100 dark:bg-neutral-900 hover:bg-neutral-200 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 transition-colors"
                            title="Call customer"
                          >
                            <Phone size={13} />
                          </a>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

