"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import Image from "next/image";
import { ArrowRight, Sparkles, ChevronLeft, ChevronRight, ChevronDown, CheckCircle2 } from "lucide-react";

export const solutionsData = [
  {
    id: "01",
    title: "Blinds",
    subtitle: "Roller, Zebra & Venetian Systems",
    description: "Architectural precision window controls engineered with motorized automation and anti-glare woven textures for light mastery.",
    image: "/icon_blinds_1786042796413.png",
    link: "/products?cat=Blinds",
    highlights: ["Motorized Somfy / Smart Hubs", "Anti-Glare UV Protection", "Zero-Maintenance Aluminum"]
  },
  {
    id: "02",
    title: "Curtains",
    subtitle: "Custom Sheer & Blackout Drapery",
    description: "Handcrafted luxury drapery tailored for high ceiling residential villas and luxury hotel suites requiring 100% total blackout.",
    image: "/icon_curtains_1786042819663.png",
    link: "/products?cat=Curtains",
    highlights: ["Flame-Retardant Fabrics", "100% Total Acoustic Insulation", "Custom Wave & Ripplefolds"]
  },
  {
    id: "03",
    title: "Shade Systems",
    subtitle: "Tensioned Sails & Canopy Sails",
    description: "Advanced tensile structures and architectural shade sails engineered to withstand heavy coastal winds and intense solar heat.",
    image: "/icon_outdoor_1786042845349.png",
    link: "/products?cat=Outdoor+Solutions",
    highlights: ["High-Tension Steel Cables", "98% UV Blockage", "Custom Architectural Shapes"]
  },
  {
    id: "04",
    title: "Canopy & Awnings",
    subtitle: "Motorized Retractable Patio Shields",
    description: "Transform outdoor terraces into all-weather dining areas with smart motorized awnings that extend at the push of a button.",
    image: "/icon_awnings_1786042874286.png",
    link: "/products?cat=Outdoor+Solutions",
    highlights: ["Automatic Wind Sensor Integration", "Waterproof Marine Acrylic", "Integrated LED Lighting"]
  },
  {
    id: "05",
    title: "Outdoor Fabric",
    subtitle: "Weatherproof Textile Installations",
    description: "Durable, fade-resistant exterior upholstery and shade fabrics specifically formulated to withstand tropical monsoon conditions.",
    image: "/gallery_3.png",
    link: "/products?cat=Outdoor+Solutions",
    highlights: ["Mold & Mildew Resistant", "10-Year Fade Guarantee", "Breathable Heat Release"]
  },
  {
    id: "06",
    title: "PVC Solutions",
    subtitle: "Clear Enclosures & Industrial Screens",
    description: "Heavy-duty crystal clear PVC screens designed for outdoor restaurants and industrial spaces protecting guests from rain and wind.",
    image: "/gallery_4.png",
    link: "/products?cat=PVC+Solutions",
    highlights: ["Crystal Clear Optical Vinyl", "Reinforced Zippers & Track Systems", "Heavy Rain Deflector"]
  }
];

export default function InteractiveSolutions() {
  const [activeIndex, setActiveIndex] = useState(0);

  const activeSolution = solutionsData[activeIndex] || solutionsData[0];

  const handlePrev = () => {
    setActiveIndex((prev) => (prev === 0 ? solutionsData.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setActiveIndex((prev) => (prev === solutionsData.length - 1 ? 0 : prev + 1));
  };

  return (
    <section id="solutions" className="py-14 sm:py-20 md:py-32 bg-slate-950 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/3 left-0 w-96 h-96 bg-primary/5 blur-3xl rounded-full pointer-events-none" />
      <div className="absolute bottom-10 right-0 w-96 h-96 bg-amber-500/5 blur-3xl rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <div className="mb-8 sm:mb-14 md:mb-20 text-left">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary/10 border border-primary/30 text-primary text-xs font-bold uppercase tracking-widest mb-3 sm:mb-4">
            <Sparkles size={14} /> Comprehensive Shading Systems
          </div>
          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-tight">
            Our Solutions Showcase
          </h2>
          <p className="text-slate-400 text-sm sm:text-lg lg:text-xl font-light mt-2 sm:mt-4 max-w-2xl">
            Explore our precision window and architectural exterior shading systems. Select any category to view details.
          </p>
        </div>

        {/* ========================================================================= */}
        {/* MOBILE & TABLET ACCORDION VIEW (Native HTML5 Exclusive Accordion - Instant 0ms Zero-JS Touch) */}
        {/* ========================================================================= */}
        <div className="lg:hidden space-y-3">
          {solutionsData.map((item, index) => {
            return (
              <details
                key={item.id}
                name="solutions-accordion"
                open={index === 0 ? true : undefined}
                className="group rounded-2xl border border-slate-800/80 bg-slate-900/60 open:bg-slate-900 open:border-amber-400/60 open:shadow-xl open:shadow-amber-500/10 open:ring-1 open:ring-amber-400/30 transition-all duration-300 overflow-hidden"
              >
                {/* Accordion Summary Trigger (Browser-Native Touch) */}
                <summary className="w-full p-4 sm:p-5 flex items-center justify-between text-left cursor-pointer select-none list-none [&::-webkit-details-marker]:hidden transition-colors active:bg-slate-800/60 focus:outline-none">
                  <div className="flex items-center gap-3.5 pr-2 pointer-events-none">
                    {/* Number Badge */}
                    <span className="text-xs font-mono font-black px-2.5 py-1 rounded-lg border transition-colors shrink-0 bg-slate-800/90 text-amber-400 border-slate-700 group-open:bg-amber-400 group-open:text-slate-950 group-open:border-amber-400 group-open:shadow-sm">
                      {item.id}
                    </span>

                    {/* Title & Subtitle */}
                    <div>
                      <span className="block text-base sm:text-lg font-bold leading-tight transition-colors text-white group-open:text-amber-300">
                        {item.title}
                      </span>
                      <span className="block text-[11px] sm:text-xs text-slate-400 font-light mt-0.5 line-clamp-1">
                        {item.subtitle}
                      </span>
                    </div>
                  </div>

                  {/* Expand / Collapse Icon */}
                  <div className="w-8 h-8 rounded-full flex items-center justify-center transition-transform duration-300 shrink-0 pointer-events-none bg-slate-800 text-slate-400 group-open:bg-amber-400 group-open:text-slate-950 group-open:rotate-180 group-open:shadow-md group-open:shadow-amber-500/20">
                    <ChevronDown size={16} className="transition-transform duration-300" />
                  </div>
                </summary>

                {/* Dropdown Content with Image & Details */}
                <div className="px-4 sm:px-5 pb-5 pt-1 space-y-4 border-t border-slate-800/70">
                  {/* Image Showcase */}
                  <div className="relative h-52 sm:h-64 w-full rounded-xl overflow-hidden bg-slate-950 border border-slate-800 mt-2 shadow-inner">
                    <Image
                      src={item.image}
                      alt={item.title}
                      fill
                      sizes="(max-width: 1024px) 100vw, 60vw"
                      className="object-cover"
                    />
                    <div className="absolute inset-0 bg-linear-to-t from-slate-950/80 via-slate-950/20 to-transparent" />

                    {/* Image Tag */}
                    <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                      <span className="text-[10px] font-extrabold text-slate-950 bg-amber-400 px-2.5 py-0.5 rounded-full uppercase tracking-wider shadow-sm">
                        Solution {item.id}
                      </span>
                      <span className="text-[11px] font-medium text-amber-200/90 drop-shadow-sm">
                        {item.subtitle}
                      </span>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-slate-300 text-xs sm:text-sm leading-relaxed font-light">
                    {item.description}
                  </p>

                  {/* Highlights Chips */}
                  <div className="flex flex-wrap gap-1.5 pt-0.5">
                    {item.highlights.map((hl, i) => (
                      <span
                        key={i}
                        className="inline-flex items-center gap-1.5 text-[11px] sm:text-xs bg-slate-800/90 text-slate-200 border border-slate-700/80 px-2.5 py-1 rounded-full font-medium"
                      >
                        <CheckCircle2 size={12} className="text-amber-400 shrink-0" />
                        <span>{hl}</span>
                      </span>
                    ))}
                  </div>

                  {/* CTA Link */}
                  <div className="pt-1">
                    <Link
                      href={item.link}
                      className="flex items-center justify-center gap-2 w-full bg-linear-to-r from-amber-400 via-yellow-400 to-amber-500 text-slate-950 font-bold px-4 py-3 rounded-xl text-xs sm:text-sm active:scale-[0.98] transition-transform shadow-md shadow-amber-500/20 hover:brightness-105"
                    >
                      <span>Explore {item.title} Collection</span>
                      <ArrowRight size={15} />
                    </Link>
                  </div>
                </div>
              </details>
            );
          })}
        </div>

        {/* ========================================================================= */}
        {/* DESKTOP INTERACTIVE LAYOUT (LG and larger: 2-Column Showcase) */}
        {/* ========================================================================= */}
        <div className="hidden lg:grid grid-cols-12 gap-12 items-center">
          {/* Left Side: 01-06 Navigation List */}
          <div className="col-span-5 space-y-3">
            {solutionsData.map((item, index) => {
              const isActive = activeIndex === index;
              return (
                <div
                  key={item.id}
                  role="button"
                  tabIndex={0}
                  onClick={() => setActiveIndex(index)}
                  onMouseEnter={() => setActiveIndex(index)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      setActiveIndex(index);
                    }
                  }}
                  className={`w-full text-left p-5 rounded-2xl transition-all duration-300 flex items-center justify-between border cursor-pointer select-none ${
                    isActive
                      ? "bg-slate-900 border-primary/50 shadow-2xl scale-[1.02] translate-x-2"
                      : "bg-slate-950/40 border-slate-800/60 hover:bg-slate-900/50 hover:border-slate-700 text-slate-400"
                  }`}
                >
                  <div className="flex items-center gap-5 pointer-events-none">
                    <span
                      className={`text-sm font-black transition-colors ${
                        isActive ? "text-primary" : "text-slate-600"
                      }`}
                    >
                      {item.id}
                    </span>
                    <div>
                      <span
                        className={`block text-xl font-bold transition-colors ${
                          isActive ? "text-white" : "text-slate-300"
                        }`}
                      >
                        {item.title}
                      </span>
                      <span className="block text-xs text-slate-500 font-light mt-0.5">
                        {item.subtitle}
                      </span>
                    </div>
                  </div>
                  <ArrowRight
                    size={20}
                    className={`transition-all duration-300 pointer-events-none ${
                      isActive
                        ? "text-primary opacity-100 translate-x-0"
                        : "text-slate-600 opacity-0 -translate-x-2"
                    }`}
                  />
                </div>
              );
            })}
          </div>

          {/* Right Side: Showcase Display Card */}
          <div className="col-span-7 relative h-145 rounded-3xl overflow-hidden border border-slate-800 bg-slate-900 shadow-2xl">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeSolution.id}
                initial={{ opacity: 0.2, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0.2, scale: 0.98 }}
                transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                className="absolute inset-0 w-full h-full"
              >
                <Image
                  src={activeSolution.image}
                  alt={activeSolution.title}
                  fill
                  sizes="(max-width: 1024px) 100vw, 60vw"
                  priority
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-linear-to-t from-slate-950 via-slate-950/50 to-transparent" />

                {/* Content Overlay */}
                <div className="absolute bottom-0 inset-x-0 p-10 flex flex-col justify-end">
                  <span className="text-primary text-xs font-black uppercase tracking-widest bg-primary/10 border border-primary/30 px-3.5 py-1 rounded-full w-fit mb-3">
                    Solution {activeSolution.id} / 06
                  </span>
                  <h3 className="text-3xl sm:text-4xl font-bold text-white mb-3">
                    {activeSolution.title}
                  </h3>
                  <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-xl font-light mb-6">
                    {activeSolution.description}
                  </p>

                  <div className="flex flex-wrap gap-2 mb-8">
                    {activeSolution.highlights.map((hl, i) => (
                      <span
                        key={i}
                        className="text-xs bg-slate-900/90 text-slate-200 border border-slate-700/80 px-3 py-1.5 rounded-full font-medium"
                      >
                        ✓ {hl}
                      </span>
                    ))}
                  </div>

                  <Link
                    href={activeSolution.link}
                    className="inline-flex items-center gap-2 bg-linear-to-r from-primary via-amber-500 to-yellow-500 text-slate-950 font-bold px-7 py-3.5 rounded-full text-sm hover:brightness-110 transition-all shadow-xl w-fit"
                  >
                    <span>Explore {activeSolution.title} Catalog</span>
                    <ArrowRight size={18} />
                  </Link>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
