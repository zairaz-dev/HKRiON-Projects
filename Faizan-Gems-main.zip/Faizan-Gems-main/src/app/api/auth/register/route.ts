import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import pool from "@/lib/db";
import { RowDataPacket } from "mysql2";
import crypto from "crypto";
import {
  hashPassword,
  createCustomerSessionToken,
  CUSTOMER_SESSION_COOKIE_NAME,
} from "@/lib/auth";

interface RegisterRecord {
  count: number;
  resetAt: number;
}
const registerLimits = new Map<string, RegisterRecord>();
const MAX_REGISTRATIONS_PER_WINDOW = 5;
const REGISTER_WINDOW_MS = 15 * 60 * 1000; // 15 minutes

import { getClientIp } from "@/lib/request-ip";

function pruneRegisterLimits(now: number) {
  if (registerLimits.size > 1000) {
    for (const [key, record] of registerLimits.entries()) {
      if (record.resetAt <= now) {
        registerLimits.delete(key);
      }
    }
  }
}

export async function POST(request: Request) {
  try {
    const ip = getClientIp(request);
    const now = Date.now();
    pruneRegisterLimits(now);

    let record = registerLimits.get(ip);
    if (!record || record.resetAt <= now) {
      record = { count: 0, resetAt: now + REGISTER_WINDOW_MS };
    }

    if (record.count >= MAX_REGISTRATIONS_PER_WINDOW) {
      const waitMinutes = Math.ceil((record.resetAt - now) / 60000);
      return NextResponse.json(
        { error: `Registration limit exceeded. Please wait ${waitMinutes} minutes before attempting additional account registrations.` },
        { status: 429, headers: { "Retry-After": Math.ceil((record.resetAt - now) / 1000).toString() } }
      );
    }

    // Increment count
    record.count += 1;
    registerLimits.set(ip, record);

    const body = await request.json();
    const { name, email, password, phone, location, salon } = body;

    if (!name || !email || !password || !phone || !phone.trim()) {
      return NextResponse.json(
        { error: "Name, email, phone number, and password are required" },
        { status: 400 }
      );
    }

    const cleanPhone = phone.trim();
    const phoneDigits = cleanPhone.replace(/\D/g, "");
    if (phoneDigits.length < 6) {
      return NextResponse.json(
        { error: "Please provide a valid phone number (at least 6 digits)" },
        { status: 400 }
      );
    }

    const normalizedEmail = email.trim().toLowerCase();

    if (password.length < 6) {
      return NextResponse.json(
        { error: "Password must be at least 6 characters" },
        { status: 400 }
      );
    }

    // Check if user already exists
    const [existing] = await pool.query<RowDataPacket[]>(
      "SELECT id FROM users WHERE email = ? LIMIT 1",
      [normalizedEmail]
    );

    if (existing && existing.length > 0) {
      return NextResponse.json(
        { error: "An account with this email address already exists. Please sign in." },
        { status: 409 }
      );
    }

    const userId = crypto.randomUUID();
    const hashedPassword = await hashPassword(password);
    const userPhone = phone ? phone.trim() : "";
    const clientLocation = location || salon || "Sri Lanka";

    // 1. Insert into users table
    await pool.query(
      `INSERT INTO users (id, name, email, password_hash, phone, role, created_at)
       VALUES (?, ?, ?, ?, ?, 'CUSTOMER', NOW())`,
      [userId, name.trim(), normalizedEmail, hashedPassword, userPhone]
    );

    // 2. Insert into clients table if not already present
    try {
      const clientId = `client-${Date.now()}`;
      await pool.query(
        `INSERT INTO clients (id, name, email, phone, total_spent, acquisitions, tier, location, created_at)
         VALUES (?, ?, ?, ?, 0, 0, 'Regular Customer', ?, NOW())
         ON DUPLICATE KEY UPDATE name = VALUES(name), phone = VALUES(phone)`,
        [clientId, name.trim(), normalizedEmail, userPhone, clientLocation]
      );
    } catch (clientErr) {
      console.warn("Client profile sync note:", clientErr);
    }

    // 3. Issue Session Token
    const sessionToken = createCustomerSessionToken({
      id: userId,
      email: normalizedEmail,
      name: name.trim(),
      phone: userPhone,
    });

    const cookieStore = await cookies();
    cookieStore.set(CUSTOMER_SESSION_COOKIE_NAME, sessionToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 14 * 24 * 60 * 60, // 14 days
    });

    return NextResponse.json(
      {
        success: true,
        user: {
          id: userId,
          name: name.trim(),
          email: normalizedEmail,
          phone: userPhone,
          role: "CUSTOMER",
          tier: "Regular Customer",
          location: clientLocation,
          salon: clientLocation,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Customer registration error:", error);
    return NextResponse.json(
      { error: "Failed to register account. Please try again." },
      { status: 500 }
    );
  }
}
