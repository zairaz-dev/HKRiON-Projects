"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, ChevronLeft, ChevronRight, Quote } from "lucide-react";

const testimonialsData = [
  {
    id: 1,
    quote: "SHADEIT BLINDS completely transformed our luxury villa's living room. The automated zebra blinds operate with whisper-quiet motorization, and the edge-to-edge fitting is absolute perfection.",
    name: "Sarah Johnson",
    role: "Homeowner, Luxury Villa",
    location: "Palm Residence",
    rating: 5,
    bgImage: "/gallery_1.png"
  },
  {
    id: 2,
    quote: "I specify SHADEIT for all my commercial design projects. Their anti-glare sunscreen roller blinds and customized motorized drapery system elevated our 12-floor corporate headquarters flawlessly.",
    name: "Michael Chen",
    role: "Lead Interior Architect",
    location: "Metro Design Studio",
    rating: 5,
    bgImage: "/gallery_2.png"
  },
  {
    id: 3,
    quote: "The heavy-duty motorized retractable awning and clear PVC weather enclosures doubled our bistro's outdoor seating capacity year-round. Monsoon rain or summer heat, our guests stay comfortable.",
    name: "David Miller",
    role: "Managing Director",
    location: "Bistro Terraces & Hospitality",
    rating: 5,
    bgImage: "/icon_restaurant_1786043029527.png"
  }
];

export default function TestimonialsSlider() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonialsData.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonialsData.length) % testimonialsData.length);
  };

  const activeTestimonial = testimonialsData[currentIndex];

  return (
    <section className="relative py-28 md:py-36 bg-slate-950 overflow-hidden px-4 sm:px-6 lg:px-8 border-t border-slate-800">
      {/* Background Image with Blur Crossfade */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTestimonial.id}
          initial={{ opacity: 0.25, scale: 1 }}
          animate={{ opacity: 0.25, scale: 1 }}
          exit={{ opacity: 0, scale: 0.98 }}
          transition={{ duration: 0.8 }}
          className="absolute inset-0 bg-cover bg-center pointer-events-none filter blur-sm"
          style={{ backgroundImage: `url('${activeTestimonial.bgImage}')` }}
        />
      </AnimatePresence>
      <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/90 to-slate-950/90 pointer-events-none" />

      <div className="relative z-10 max-w-5xl mx-auto text-center">
        {/* Header Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/30 text-primary text-xs font-black uppercase tracking-widest mb-8">
          <Quote size={16} /> Verified Client Stories
        </div>

        {/* Dynamic Quote Box */}
        <div className="min-h-[260px] flex flex-col items-center justify-center">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTestimonial.id}
              initial={{ opacity: 0.2, y: 15, filter: "blur(2px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0.2, y: -15, filter: "blur(2px)" }}
              transition={{ duration: 0.5 }}
              className="space-y-6"
            >
              {/* Star Rating */}
              <div className="flex justify-center text-amber-400 gap-1.5 mb-4">
                {[...Array(activeTestimonial.rating)].map((_, i) => (
                  <Star key={i} size={22} fill="currentColor" className="drop-shadow-md" />
                ))}
              </div>

              {/* Big Editorial Quote */}
              <blockquote className="text-xl sm:text-3xl md:text-4xl font-light text-white leading-relaxed tracking-tight max-w-4xl mx-auto italic drop-shadow-lg">
                "{activeTestimonial.quote}"
              </blockquote>

              {/* Client Info */}
              <div className="pt-4">
                <h4 className="text-xl font-bold text-amber-400">{activeTestimonial.name}</h4>
                <p className="text-sm text-slate-300 font-light mt-0.5">
                  {activeTestimonial.role} — <span className="text-slate-400">{activeTestimonial.location}</span>
                </p>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Slider Controls */}
        <div className="mt-12 flex items-center justify-center gap-6">
          <button
            onClick={prevSlide}
            className="w-12 h-12 rounded-full bg-slate-900/90 border border-slate-700 text-white hover:bg-primary hover:text-slate-950 hover:border-primary transition-all flex items-center justify-center shadow-xl active:scale-95 touch-manipulation"
            aria-label="Previous Testimonial"
          >
            <ChevronLeft size={22} />
          </button>

          <span className="text-xs font-black text-slate-400 tracking-widest">
            0{currentIndex + 1} / 0{testimonialsData.length}
          </span>

          <button
            onClick={nextSlide}
            className="w-12 h-12 rounded-full bg-slate-900/90 border border-slate-700 text-white hover:bg-primary hover:text-slate-950 hover:border-primary transition-all flex items-center justify-center shadow-xl active:scale-95 touch-manipulation"
            aria-label="Next Testimonial"
          >
            <ChevronRight size={22} />
          </button>
        </div>
      </div>
    </section>
  );
}
