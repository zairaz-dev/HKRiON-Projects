"use client";

import React from "react";

export function CollectionCardSkeleton() {
  return (
    <div className="relative flex flex-col bg-[#16161D] border border-[#E8E4DC] overflow-hidden rounded-sm shadow-xs aspect-[4/3] sm:aspect-[16/11] w-full">
      {/* Dark Shimmer Frame */}
      <div className="absolute inset-0 bg-[#1A1A24] animate-shimmer-dark" />

      {/* Subtle Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/35 to-transparent pointer-events-none" />

      {/* Bottom Text Placeholders */}
      <div className="absolute bottom-3 sm:bottom-5 inset-x-3 sm:inset-x-5 text-center flex flex-col items-center gap-2">
        {/* Title Bar Placeholder */}
        <div className="w-3/4 sm:w-3/5 h-4 sm:h-6 bg-white/20 rounded-xs animate-pulse" />
        {/* Action Link Placeholder */}
        <div className="hidden sm:block w-24 sm:w-28 h-2.5 bg-[#C5A880]/35 rounded-xs animate-pulse" />
      </div>
    </div>
  );
}

export default CollectionCardSkeleton;
