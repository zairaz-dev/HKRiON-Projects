export interface BranchItem {
  id: string;
  name: string;
}

export interface CustomerBranchItem {
  branchId: string;
  branch: BranchItem;
}

export interface CustomerGroupItem {
  id: string;
  name: string;
}

export interface CustomerItem {
  id: string;
  name: string;
  image?: string | null;
  businessName: string | null;
  email: string | null;
  phone: string | null;
  taxNumber: string | null;
  openingBalance: number;
  creditLimit: number | null;
  address: string | null;
  customerGroupId: string | null;
  customerGroup?: CustomerGroupItem | null;
  isActive: boolean;
  isDefault?: boolean;
  allowCredit?: boolean;
  businessId: string;
  createdAt: string;
  updatedAt: string;
  branches?: CustomerBranchItem[];
  sales?: Array<{
    id: string;
    invoiceNumber: string;
    grandTotal: number;
    amountPaid: number;
    paymentStatus: string;
  }>;
  advances?: Array<{
    id: string;
    amount: number;
    amountRemaining: number;
  }>;
}
