"use client";

import { LogOut } from "lucide-react";

export default function AdminLogoutButton() {
  const handleLogout = async () => {
    try {
      // 1. Delete client-side cookie
      document.cookie = "shadeit_auth_session=; path=/; max-age=0; SameSite=Lax";

      // 2. Clear local storage
      if (typeof window !== "undefined") {
        localStorage.removeItem("shadeit_user");
      }

      // 3. Call server logout API
      await fetch("/api/auth/logout", {
        method: "POST",
        credentials: "include",
      });

      // 4. Redirect to login
      window.location.replace("/login");
    } catch {
      window.location.replace("/login");
    }
  };

  return (
    <button
      type="button"
      onClick={handleLogout}
      className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-2xl bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 text-xs font-bold transition-all cursor-pointer"
    >
      <LogOut size={15} />
      <span>Log Out</span>
    </button>
  );
}
