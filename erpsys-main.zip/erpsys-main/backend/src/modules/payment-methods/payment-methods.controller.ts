import { Controller, Post, Body, Get, Patch, Delete, Param, Query, UseGuards, Put, Req } from '@nestjs/common';
import { PaymentMethodsService } from './payment-methods.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('payment-methods')
export class PaymentMethodsController {
  constructor(private readonly paymentMethodsService: PaymentMethodsService) {}

  @Post()
  async createPaymentMethod(@Req() req: any, @Body() body: any) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }
    const { name, code, description, sortOrder, businessId, createdById, branchIds } = body;
    return this.paymentMethodsService.createPaymentMethod({
      name,
      code,
      description,
      sortOrder: sortOrder ? Number(sortOrder) : 0,
      businessId,
      createdById: createdById || user.id,
      branchIds,
    });
  }

  @Get()
  async getPaymentMethods(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
    @Query('onlyActive') onlyActive?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    const isActiveFiltered = onlyActive === 'true';
    return this.paymentMethodsService.getPaymentMethods(bId, branchId, isActiveFiltered);
  }

  @Get(':id')
  async getPaymentMethodById(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.paymentMethodsService.getPaymentMethodById(id, bId);
  }

  @Patch(':id')
  async updatePaymentMethod(
    @Req() req: any,
    @Param('id') id: string,
    @Body() body: any,
  ) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }
    const { name, description, isActive, sortOrder, branchIds, updatedById, businessId } = body;
    return this.paymentMethodsService.updatePaymentMethod(id, businessId, {
      name,
      description,
      isActive: isActive !== undefined ? Boolean(isActive) : undefined,
      sortOrder: sortOrder !== undefined ? Number(sortOrder) : undefined,
      branchIds,
      updatedById: updatedById || user.id,
    });
  }

  @Delete(':id')
  async deletePaymentMethod(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.paymentMethodsService.deletePaymentMethod(id, bId);
  }

  // Individual branch status override endpoint
  @Patch(':id/branches/:branchId')
  async updateBranchStatus(
    @Req() req: any,
    @Param('id') id: string,
    @Param('branchId') branchId: string,
    @Body() body: { isActive: boolean; businessId: string },
  ) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }
    const { isActive, businessId } = body;
    return this.paymentMethodsService.updateBranchStatus(id, branchId, businessId, isActive);
  }
}

