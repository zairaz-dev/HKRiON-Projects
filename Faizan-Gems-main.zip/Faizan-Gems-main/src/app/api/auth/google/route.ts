import { NextResponse } from "next/server";
import crypto from "crypto";
import { OAUTH_NONCE_COOKIE } from "@/lib/auth";

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const from = searchParams.get("from") || "";
  const checkOnly = searchParams.get("check") === "1";

  const clientId = process.env.GOOGLE_CLIENT_ID;
  const isConfigured = Boolean(clientId && process.env.GOOGLE_CLIENT_SECRET);

  if (checkOnly) {
    return NextResponse.json({ configured: isConfigured });
  }

  if (isConfigured && clientId) {
    const baseUrl = process.env.NEXTAUTH_URL || origin || "http://127.0.0.1:3000";
    const redirectUri = `${baseUrl}/api/auth/google/callback`;
    const nonce = crypto.randomUUID();
    const state = Buffer.from(JSON.stringify({ from, nonce })).toString("base64url");

    const googleAuthUrl = new URL("https://accounts.google.com/o/oauth2/v2/auth");
    googleAuthUrl.searchParams.set("client_id", clientId);
    googleAuthUrl.searchParams.set("redirect_uri", redirectUri);
    googleAuthUrl.searchParams.set("response_type", "code");
    googleAuthUrl.searchParams.set("scope", "openid email profile");
    googleAuthUrl.searchParams.set("state", state);
    googleAuthUrl.searchParams.set("access_type", "online");

    const response = NextResponse.redirect(googleAuthUrl.toString());
    response.cookies.set(OAUTH_NONCE_COOKIE, nonce, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 10 * 60, // 10 minutes
    });

    return response;
  }

  // If Google OAuth credentials are not in .env yet, return to login with error
  const loginUrl = new URL("/login", request.url);
  loginUrl.searchParams.set(
    "error",
    "Google Sign-In is not configured yet. Please sign in with your email and password."
  );
  if (from) loginUrl.searchParams.set("from", from);
  return NextResponse.redirect(loginUrl.toString());
}

export async function POST() {
  return NextResponse.json(
    {
      error:
        "Direct email submission is disabled for security. Please authenticate via the official Google OAuth flow.",
    },
    { status: 405 }
  );
}
