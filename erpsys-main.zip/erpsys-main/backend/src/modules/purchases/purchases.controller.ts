import { Controller, Post, Body, Get, Param, Query, UseGuards, Put, Req } from '@nestjs/common';
import { PurchasesService } from './purchases.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';
import { ApiBody, ApiResponse } from '@nestjs/swagger';
import { CreatePurchaseBodySchema, UpdatePurchaseBodySchema, PurchaseResponseSchema } from '../../docs/purchases.docs';

@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('purchases')
export class PurchasesController {
  constructor(private readonly purchasesService: PurchasesService) {}

  @Get('next-number')
  async getNextPurchaseNumber(@Req() req: any) {
    return { purchaseNumber: await this.purchasesService.generateNextPurchaseNumber(req.user.businessId) };
  }

  @Get('returns/next-number')
  async getNextPurchaseReturnNumber(@Req() req: any) {
    return { returnNumber: await this.purchasesService.generateNextPurchaseReturnNumber(req.user.businessId) };
  }

  @Permissions(Permission.PURCHASE_CREATE)
  @Post()
  @ApiBody({ schema: CreatePurchaseBodySchema })
  @ApiResponse({ status: 201, description: 'Purchase created successfully', schema: PurchaseResponseSchema })
  async createPurchase(@Req() req: any, @Body() body: any) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }

    const {
      purchaseNumber,
      purchaseDate,
      supplierId,
      branchId,
      businessId,
      purchaseLines,
      discountType,
      discountAmount,
      shippingAmount,
      taxAmount,
      grandTotal,
      notes,
      createdById,
      paymentDetails,
    } = body;

    return this.purchasesService.createPurchase({
      purchaseNumber,
      purchaseDate,
      supplierId,
      branchId,
      businessId,
      purchaseLines,
      discountType,
      discountAmount,
      shippingAmount,
      taxAmount,
      grandTotal,
      notes,
      createdById: createdById || user.id,
      paymentDetails,
    });
  }

  @Permissions(Permission.PURCHASE_VIEW)
  @Get()
  async getPurchases(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
    @Query('supplierId') supplierId?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('search') search?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.purchasesService.getPurchases(bId, {
      branchId,
      supplierId,
      page: page ? Number(page) : undefined,
      limit: limit ? Number(limit) : undefined,
      search,
    });
  }

  @Permissions(Permission.PURCHASE_CREATE)
  @Post('returns')
  async createPurchaseReturn(@Req() req: any, @Body() body: any) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }
    return this.purchasesService.createPurchaseReturn(body.businessId, body);
  }

  @Permissions(Permission.PURCHASE_VIEW)
  @Get('returns')
  async getPurchaseReturns(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
    @Query('supplierId') supplierId?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('search') search?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.purchasesService.getPurchaseReturns(bId, {
      branchId,
      supplierId,
      page: page ? Number(page) : undefined,
      limit: limit ? Number(limit) : undefined,
      search,
    });
  }

  @Permissions(Permission.PURCHASE_VIEW)
  @Get('returns/:id')
  async getPurchaseReturnById(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.purchasesService.getPurchaseReturnById(id, bId);
  }

  @Permissions(Permission.PURCHASE_VIEW)
  @Get(':id')
  async getPurchaseById(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.purchasesService.getPurchaseById(id, bId);
  }

  @Permissions(Permission.PURCHASE_UPDATE)
  @Put(':id')
  @ApiBody({ schema: UpdatePurchaseBodySchema })
  @ApiResponse({ status: 200, description: 'Purchase updated successfully', schema: PurchaseResponseSchema })
  async updatePurchase(
    @Req() req: any,
    @Param('id') id: string,
    @Body() body: any,
  ) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      body.businessId = user.businessId;
    }

    const {
      businessId,
      purchaseNumber,
      purchaseDate,
      supplierId,
      branchId,
      purchaseLines,
      discountType,
      discountAmount,
      shippingAmount,
      taxAmount,
      grandTotal,
      notes,
    } = body;

    return this.purchasesService.updatePurchase(id, businessId, {
      purchaseNumber,
      purchaseDate: purchaseDate ? new Date(purchaseDate) : undefined,
      supplierId,
      branchId,
      purchaseLines,
      discountType,
      discountAmount,
      shippingAmount,
      taxAmount,
      grandTotal,
      notes,
    });
  }
}
