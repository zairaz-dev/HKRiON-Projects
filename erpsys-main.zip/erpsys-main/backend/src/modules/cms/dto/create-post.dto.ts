import { IsBoolean, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class CreateCmsPostDto {
  @IsNotEmpty()
  @IsString()
  title: string;

  @IsNotEmpty()
  @IsString()
  slug: string;

  @IsOptional()
  @IsString()
  excerpt?: string;

  @IsNotEmpty()
  @IsString()
  content: string;

  @IsOptional()
  @IsString()
  coverImage?: string;

  @IsOptional()
  @IsString()
  authorName?: string;

  @IsOptional()
  @IsString()
  category?: string;

  @IsOptional()
  @IsString()
  versionTag?: string;

  @IsOptional()
  @IsBoolean()
  isPublished?: boolean;
}

import { PartialType } from '@nestjs/swagger';

export class UpdateCmsPostDto extends PartialType(CreateCmsPostDto) {}
