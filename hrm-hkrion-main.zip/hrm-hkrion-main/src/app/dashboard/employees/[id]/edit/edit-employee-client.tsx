"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { updateEmployee } from "@/actions/employees";
import { Role } from "@prisma/client";
import { 
  ArrowLeft, 
  UserCog, 
  Camera, 
  Eye, 
  EyeOff, 
  AlertTriangle, 
  Loader2,
  Check,
  Shield,
  Briefcase,
  UserCheck,
  ChevronRight,
  Sparkles,
  Mail,
  Phone,
  Lock,
  Building,
  Info,
  CheckCircle2,
  Trash2
} from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { PageHeader } from "@/components/ui/page-header";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

type EmployeeData = {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string | null;
  role: Role;
  positionId: number | null;
  managerId: number | null;
  profileImage: string | null;
  position?: { id: number; title: string } | null;
  manager?: { id: number; firstName: string; lastName: string; profileImage?: string | null } | null;
};

type Position = {
  id: number;
  title: string;
};

type Manager = {
  id: number;
  firstName: string;
  lastName: string;
  role: string;
};

interface EditEmployeeClientProps {
  employee: EmployeeData;
  positions: Position[];
  managers: Manager[];
  isSuperAdmin: boolean;
  currentUserId: number;
}

export default function EditEmployeeClient({
  employee,
  positions,
  managers,
  isSuperAdmin,
  currentUserId,
}: EditEmployeeClientProps) {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(employee.profileImage);

  // Form state for interactive preview
  const [firstName, setFirstName] = useState(employee.firstName);
  const [lastName, setLastName] = useState(employee.lastName);
  const [email, setEmail] = useState(employee.email);
  const [phone, setPhone] = useState(employee.phone || "");
  const [selectedRole, setSelectedRole] = useState(employee.role as string);
  const [selectedPositionId, setSelectedPositionId] = useState(employee.positionId?.toString() || "");
  const [selectedManagerId, setSelectedManagerId] = useState(employee.managerId?.toString() || "");

  const isSelf = employee.id === currentUserId;

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError("Profile image must be less than 5MB");
        toast.error("Profile image must be less than 5MB");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    setPreviewImage(null);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    const formData = new FormData(e.currentTarget);
    const password = formData.get("password") as string;
    const confirmPassword = formData.get("confirmPassword") as string;

    if (password && password.trim().length > 0) {
      if (password !== confirmPassword) {
        setError("New passwords do not match.");
        toast.error("New passwords do not match.");
        setIsLoading(false);
        return;
      }
    }

    const res = await updateEmployee(employee.id, formData);

    if (res.error) {
      setError(res.error);
      toast.error(res.error);
      setIsLoading(false);
    } else {
      toast.success("Employee updated successfully!");
      router.push("/dashboard/employees");
      router.refresh();
    }
  };

  const selectedPositionTitle = positions.find(p => p.id.toString() === selectedPositionId)?.title;
  const selectedManager = managers.find(m => m.id.toString() === selectedManagerId);

  return (
    <form 
      onSubmit={handleSubmit} 
      className="space-y-6"
      onKeyDown={(e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
          e.preventDefault();
          const form = e.currentTarget;
          form.requestSubmit();
        }
      }}
    >
      {/* Top Header & Breadcrumb */}
      <PageHeader 
        title="Edit Employee"
        description={<>Update personal info, phone number, job role, and account settings for <strong className="text-text-primary">{employee.firstName} {employee.lastName}</strong>.</>}
        actions={
          <>
            <Link href="/dashboard/employees">
              <Button type="button" variant="outline" size="sm">
                Cancel
              </Button>
            </Link>
            <Button type="submit" disabled={isLoading} size="sm" className="gap-2 shadow-sm font-semibold cursor-pointer">
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Saving Changes...</span>
                </>
              ) : (
                <>
                  <Check className="h-4 w-4" />
                  <span>Save Changes</span>
                </>
              )}
            </Button>
          </>
        }
      />

      {/* Error Alert Banner */}
      {error && (
        <div className="p-4 rounded-xl bg-error-bg border border-error-border text-error text-sm flex items-start gap-3 shadow-2xs">
          <AlertTriangle className="h-5 w-5 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-semibold text-xs">Update Failed</p>
            <p className="text-xs mt-0.5 leading-relaxed">{error}</p>
          </div>
        </div>
      )}

      {/* Main 12-Column Responsive Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column (8 cols): Joint Personal Information + Photo + Credentials */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Card 1: Joint Personal Information & Avatar */}
          <Card className="bg-surface border-border shadow-xs overflow-hidden">
            <CardHeader className="p-5 sm:p-6 border-b border-border">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-primary-soft text-primary">
                    <UserCheck className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <CardTitle className="text-base font-semibold">Personal Information & Photo</CardTitle>
                  </div>
                </div>
                <Badge variant="outline" className="text-[10px] font-mono">
                  Profile
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="p-5 sm:p-6 space-y-6">
              
              {/* Joint Avatar + Details Layout */}
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 pb-2">
                
                {/* Profile Photo Uploader */}
                <div className="flex flex-col items-center gap-2 shrink-0">
                  <div className="relative group">
                    <div className="w-28 h-28 rounded-full overflow-hidden border-2 border-border bg-surface-secondary flex items-center justify-center shadow-xs transition-all group-hover:border-primary">
                      {previewImage ? (
                        <img src={previewImage} alt="Preview" className="w-full h-full object-cover" />
                      ) : (
                        <div className="flex flex-col items-center justify-center text-primary font-bold text-2xl">
                          {firstName.charAt(0)}{lastName.charAt(0)}
                        </div>
                      )}
                    </div>
                    <label className="absolute bottom-0 right-0 p-2.5 bg-primary text-white rounded-full shadow-md hover:bg-primary/90 transition-transform active:scale-95 cursor-pointer">
                      <Camera className="w-4 h-4" />
                      <input
                        type="file"
                        name="profileImage"
                        accept="image/*"
                        onChange={handleImageChange}
                        className="hidden"
                      />
                    </label>
                  </div>

                  {previewImage ? (
                    <button 
                      type="button" 
                      onClick={handleRemoveImage}
                      className="text-[11px] text-error hover:underline flex items-center gap-1 cursor-pointer pt-1"
                    >
                      <Trash2 className="h-3 w-3" />
                      <span>Remove</span>
                    </button>
                  ) : (
                    <span className="text-[10px] text-text-muted">Max 5MB (PNG, JPG)</span>
                  )}
                </div>

                {/* Name & Contact Fields */}
                <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-4 w-full">
                  <div className="space-y-1.5">
                    <Label htmlFor="firstName" className="text-xs font-semibold text-text-primary">
                      First Name <span className="text-error">*</span>
                    </Label>
                    <Input
                      id="firstName"
                      name="firstName"
                      type="text"
                      required
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      className="h-10 text-sm bg-surface-secondary/40 focus:bg-surface transition-colors"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <Label htmlFor="lastName" className="text-xs font-semibold text-text-primary">
                      Last Name <span className="text-error">*</span>
                    </Label>
                    <Input
                      id="lastName"
                      name="lastName"
                      type="text"
                      required
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                      className="h-10 text-sm bg-surface-secondary/40 focus:bg-surface transition-colors"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <Label htmlFor="email" className="text-xs font-semibold text-text-primary">
                      Work Email Address <span className="text-error">*</span>
                    </Label>
                    <div className="relative">
                      <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-text-muted" />
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="pl-10 h-10 text-sm bg-surface-secondary/40 focus:bg-surface transition-colors font-mono text-xs sm:text-sm"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <Label htmlFor="phone" className="text-xs font-semibold text-text-primary">
                      Phone Number
                    </Label>
                    <div className="relative">
                      <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-text-muted" />
                      <Input
                        id="phone"
                        name="phone"
                        type="tel"
                        placeholder="+1 (555) 019-2834"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="pl-10 h-10 text-sm bg-surface-secondary/40 focus:bg-surface transition-colors font-mono text-xs sm:text-sm"
                      />
                    </div>
                  </div>
                </div>

              </div>

            </CardContent>
          </Card>

          {/* Card 2: Password Reset (Optional) */}
          <Card className="bg-surface border-border shadow-xs overflow-hidden">
            <CardHeader className="p-5 sm:p-6 border-b border-border">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-violet-500/10 text-violet-600 dark:text-violet-400">
                    <Shield className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <CardTitle className="text-base font-semibold">Reset Account Password (Optional)</CardTitle>
                    <CardDescription className="text-xs mt-0.5">
                      Leave blank to preserve the employee&apos;s current active password.
                    </CardDescription>
                  </div>
                </div>
                <Badge variant="outline" className="text-[10px] font-mono">
                  Credentials
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="p-5 sm:p-6 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="password" className="text-xs font-semibold text-text-primary">
                    New Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-text-muted" />
                    <Input
                      id="password"
                      name="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Leave empty to keep current"
                      className="pl-10 pr-10 h-10 text-sm bg-surface-secondary/40 focus:bg-surface transition-colors"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary transition-colors cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="confirmPassword" className="text-xs font-semibold text-text-primary">
                    Confirm New Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-text-muted" />
                    <Input
                      id="confirmPassword"
                      name="confirmPassword"
                      type={showConfirmPassword ? "text" : "password"}
                      placeholder="Re-enter new password"
                      className="pl-10 pr-10 h-10 text-sm bg-surface-secondary/40 focus:bg-surface transition-colors"
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary transition-colors cursor-pointer"
                    >
                      {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

        </div>

        {/* Right Column (4 cols): Role/Manager Hierarchy */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Card 3: Organizational Placement */}
          <Card className="bg-surface border-border shadow-xs overflow-hidden">
            <CardHeader className="p-5 sm:p-6 border-b border-border">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-teal-500/10 text-teal-600 dark:text-teal-400">
                    <Building className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <CardTitle className="text-base font-semibold">Organization & Role</CardTitle>
                  </div>
                </div>
                <Badge variant="outline" className="text-[10px] font-mono">
                  Placement
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="p-5 sm:p-6 space-y-4">
              {/* System Role */}
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-text-primary">
                  System Role <span className="text-error">*</span>
                </Label>
                <Select
                  name="role"
                  value={selectedRole}
                  onValueChange={setSelectedRole}
                  required
                  disabled={isSelf}
                  options={[
                    { value: "EMPLOYEE", label: "Employee (Standard Workspace)" },
                    { value: "MANAGER", label: "Manager (Team Leader)" },
                    ...(isSuperAdmin ? [{ value: "SUPER_ADMIN", label: "Super Admin (Global Access)" }] : []),
                  ]}
                />
                {isSelf && (
                  <p className="text-[10px] text-text-muted">You cannot modify your own role.</p>
                )}
              </div>

              {/* Job Position */}
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-text-primary">Job Position</Label>
                <Select
                  name="positionId"
                  value={selectedPositionId}
                  onValueChange={setSelectedPositionId}
                  placeholder="-- Select Job Title --"
                  options={[
                    { value: "", label: "No Position Assigned" },
                    ...positions.map((pos) => ({
                      value: pos.id.toString(),
                      label: pos.title,
                    })),
                  ]}
                />
              </div>

              {/* Reporting Manager */}
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-text-primary">Reporting Manager</Label>
                <Select
                  name="managerId"
                  value={selectedManagerId}
                  onValueChange={setSelectedManagerId}
                  placeholder="-- Select Reporting Manager --"
                  options={[
                    { value: "", label: "No Direct Manager" },
                    ...managers
                      .filter((m) => m.id !== employee.id)
                      .map((m) => ({
                        value: m.id.toString(),
                        label: `${m.firstName} ${m.lastName} (${m.role.replace("_", " ")})`,
                      })),
                  ]}
                />
              </div>

              {/* Form Save & Cancel Actions */}
              <div className="pt-3 flex flex-col gap-2 border-t border-border/70">
                <Button 
                  type="submit" 
                  disabled={isLoading}
                  className="w-full gap-2 font-semibold shadow-xs cursor-pointer"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span>Saving Changes...</span>
                    </>
                  ) : (
                    <>
                      <Check className="h-4 w-4" />
                      <span>Save Changes</span>
                    </>
                  )}
                </Button>
                <Link href="/dashboard/employees" className="w-full">
                  <Button type="button" variant="outline" className="w-full text-xs">
                    Cancel
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>

        </div>
      </div>
    </form>
  );
}
