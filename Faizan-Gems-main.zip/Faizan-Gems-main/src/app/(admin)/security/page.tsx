import AdminDashboard from "@/features/admin/AdminDashboard";

export default function SecurityPage() {
  return <AdminDashboard initialTab="vault_security" />;
}
