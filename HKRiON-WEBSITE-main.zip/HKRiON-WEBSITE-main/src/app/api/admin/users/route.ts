import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { verifyToken, hashPassword } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('hkrion_auth_token')?.value;

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const currentUser = await verifyToken(token);
    if (!currentUser || currentUser.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden. Admin access required.' }, { status: 403 });
    }

    // Use raw query or prisma findMany safely
    interface DbUserRaw {
      id: string;
      name: string;
      email: string;
      avatar?: string | null;
      roleId?: string | null;
      roleName?: string | null;
      roleDescription?: string | null;
      createdAt: Date | string;
    }

    let dbUsers: DbUserRaw[] = [];
    try {
      dbUsers = await prisma.$queryRaw<DbUserRaw[]>`
        SELECT u.id, u.name, u.email, u.avatar, u.roleId, u.createdAt,
               r.name as roleName, r.description as roleDescription
        FROM User u
        LEFT JOIN Role r ON u.roleId = r.id
        ORDER BY u.createdAt DESC
      `;
    } catch {
      // Fallback findMany
      const rawUsers = await prisma.user.findMany({
        orderBy: { createdAt: 'desc' },
        include: { role: true },
      });
      dbUsers = rawUsers.map((u) => ({
        id: u.id,
        name: u.name,
        email: u.email,
        avatar: (u as { avatar?: string | null }).avatar || null,
        roleId: u.roleId,
        roleName: u.role?.name || 'CUSTOMER',
        roleDescription: u.role?.description || null,
        createdAt: u.createdAt,
      }));
    }

    const users = dbUsers.map((u: DbUserRaw) => ({
      id: u.id,
      name: u.name,
      email: u.email,
      avatar: u.avatar || null,
      roleId: u.roleId || null,
      roleName: u.roleName || 'CUSTOMER',
      roleDescription: u.roleDescription || null,
      createdAt: typeof u.createdAt === 'string' ? u.createdAt : new Date(u.createdAt).toISOString(),
    }));

    return NextResponse.json({ success: true, users, currentUserId: currentUser.id });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Failed to fetch users';
    console.error('Error fetching users from database:', err);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('hkrion_auth_token')?.value;

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const currentUser = await verifyToken(token);
    if (!currentUser || currentUser.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden. Admin access required.' }, { status: 403 });
    }

    const { name, email, password, roleId, avatar } = await request.json();

    if (!name || !email || !password) {
      return NextResponse.json({ error: 'Name, Email, and Password are required.' }, { status: 400 });
    }

    const cleanEmail = email.trim().toLowerCase();

    // Check existing email
    const existing = await prisma.user.findUnique({
      where: { email: cleanEmail },
    });

    if (existing) {
      return NextResponse.json({ error: `User with email '${cleanEmail}' already exists.` }, { status: 400 });
    }

    const hashedPassword = await hashPassword(password);

    const newUser = await prisma.user.create({
      data: {
        name,
        email: cleanEmail,
        password: hashedPassword,
        roleId: roleId || null,
        createdBy: currentUser.id || 'admin',
        updatedBy: currentUser.id || 'admin',
      },
      include: {
        role: true,
      },
    });

    // Update avatar via direct raw query to bypass client schema locks
    if (avatar) {
      await prisma.$executeRaw`UPDATE User SET avatar = ${avatar} WHERE id = ${newUser.id}`;
    }

    return NextResponse.json({
      success: true,
      user: {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        avatar: avatar || null,
        roleId: newUser.roleId,
        roleName: newUser.role?.name || 'CUSTOMER',
        createdAt: newUser.createdAt.toISOString(),
      },
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Failed to create user in database';
    console.error('Error creating user in database:', err);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('hkrion_auth_token')?.value;

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const currentUser = await verifyToken(token);
    if (!currentUser || currentUser.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden. Admin access required.' }, { status: 403 });
    }

    const { id, name, email, password, roleId, avatar } = await request.json();

    if (!id) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
    }

    const updateData: Record<string, string | null> = {
      updatedBy: currentUser.id || 'admin',
    };

    if (name) updateData.name = name;
    if (email) updateData.email = email.trim().toLowerCase();
    if (roleId !== undefined) updateData.roleId = roleId || null;

    if (password && password.trim().length > 0) {
      updateData.password = await hashPassword(password);
    }

    // 1. Update standard fields via Prisma
    const updatedUser = await prisma.user.update({
      where: { id },
      data: updateData,
      include: {
        role: true,
      },
    });

    // 2. Update avatar directly via MySQL raw query to prevent client model validation errors
    if (avatar !== undefined) {
      await prisma.$executeRaw`UPDATE User SET avatar = ${avatar || null} WHERE id = ${id}`;
    }

    return NextResponse.json({
      success: true,
      user: {
        id: updatedUser.id,
        name: updatedUser.name,
        email: updatedUser.email,
        avatar: avatar !== undefined ? (avatar || null) : ((updatedUser as unknown as { avatar?: string | null }).avatar || null),
        roleId: updatedUser.roleId,
        roleName: updatedUser.role?.name || 'CUSTOMER',
        createdAt: updatedUser.createdAt.toISOString(),
      },
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Failed to update user in database';
    console.error('Error updating user in database:', err);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('hkrion_auth_token')?.value;

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const currentUser = await verifyToken(token);
    if (!currentUser || currentUser.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden. Admin access required.' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'User ID parameter is required' }, { status: 400 });
    }

    if (id === currentUser.id) {
      return NextResponse.json({ error: 'Security Protection: You cannot delete your own active administrator account.' }, { status: 400 });
    }

    await prisma.user.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: 'User deleted successfully from database' });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Failed to delete user from database';
    console.error('Error deleting user from database:', err);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
