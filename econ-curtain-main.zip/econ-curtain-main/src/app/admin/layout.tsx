import { SessionManager } from "@/core/auth/session";
import { redirect } from "next/navigation";
import AdminSidebar from "@/components/admin/AdminSidebar";
import AdminTopbar from "@/components/admin/AdminTopbar";
import AdminToast from "@/components/admin/AdminToast";
import { AdminThemeProvider } from "@/components/admin/AdminThemeContext";
import { Suspense } from "react";

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await SessionManager.getCurrentSession();

  if (!session) {
    redirect("/login");
  }

  return (
    <AdminThemeProvider>
      <div className="min-h-screen bg-[#F8FAFC] dark:bg-black text-neutral-900 dark:text-neutral-100 flex flex-col selection:bg-amber-400 selection:text-neutral-900 font-sans antialiased transition-colors duration-200">
        {/* Top-Right Floating Toast Notification */}
        <Suspense fallback={null}>
          <AdminToast />
        </Suspense>

        {/* Responsive Admin Sidebar */}
        <AdminSidebar
          user={{
            name: session.name,
            email: session.email,
            role: session.role,
          }}
        />

        {/* Main Admin Content Area with Left Padding for 256px Sidebar */}
        <div className="grow lg:pl-64 flex flex-col min-w-0">
          {/* Dynamic Admin Topbar with Theme Switcher */}
          <AdminTopbar
            user={{
              name: session.name,
              email: session.email,
              role: session.role,
            }}
          />

          <main className="grow p-3 sm:p-5 lg:p-6 w-full min-w-0">
            {children}
          </main>
        </div>
      </div>
    </AdminThemeProvider>
  );
}


