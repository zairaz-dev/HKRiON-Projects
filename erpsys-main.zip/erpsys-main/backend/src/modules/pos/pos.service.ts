import { Injectable, BadRequestException, NotFoundException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Prisma } from '@prisma/client';
import { CreateInvoiceDto } from './dto/create-invoice.dto';
import { UpdateSaleDto } from './dto/update-sale.dto';

@Injectable()
export class PosService {
  constructor(private readonly prisma: PrismaService) {}

  async checkout(dto: CreateInvoiceDto) {
    const {
      customerId,
      branchId,
      businessId,
      discountType,
      discountAmount = 0,
      taxAmount = 0,
      grandTotal,
      notes,
      createdById,
      status = 'FINAL',
      saleLines,
      payments = [],
      useAdvance = false,
    } = dto;

    if (!saleLines || saleLines.length === 0) {
      throw new BadRequestException('Sale must contain at least one item.');
    }

    let calculatedLineTotal = 0;
    for (const line of saleLines) {
      if (typeof line.quantity !== 'number' || line.quantity <= 0) {
        throw new BadRequestException('Sale line quantity must be a positive number.');
      }
      calculatedLineTotal += (line.quantity * line.unitPrice) - (line.discountAmount || 0) + (line.taxAmount || 0);
    }
    let calculatedDiscountVal = discountAmount || 0;
    if (discountType === 'PERCENTAGE') {
      calculatedDiscountVal = (calculatedLineTotal * (discountAmount || 0)) / 100;
    }
    const expectedGrandTotal = Math.max(0, calculatedLineTotal - calculatedDiscountVal + (taxAmount || 0));
    if (grandTotal !== undefined && Math.abs(grandTotal - expectedGrandTotal) > 0.05) {
      throw new BadRequestException(`Grand total mismatch: expected ${expectedGrandTotal.toFixed(2)}, got ${grandTotal.toFixed(2)}`);
    }

    return this.prisma.$transaction(async (tx) => {
      // Resolve Walk-in Customer
      let finalCustomerId = customerId;
      if (finalCustomerId && finalCustomerId !== 'walk-in') {
        const cust = await tx.customer.findUnique({
          where: { id: finalCustomerId },
        });
        if (cust && cust.businessId && cust.businessId !== businessId) {
          throw new BadRequestException('Customer does not belong to this business organization.');
        }
      }
      if (!finalCustomerId || finalCustomerId === 'walk-in') {
        let walkIn = await tx.customer.findFirst({
          where: {
            businessId,
            OR: [
              { isDefault: true },
              { name: { equals: 'Walk-in Customer', mode: 'insensitive' } },
            ],
          },
        });

        if (!walkIn) {
          walkIn = await tx.customer.create({
            data: {
              name: 'Walk-in Customer',
              isDefault: true,
              allowCredit: false,
              creditLimit: 0,
              businessId,
              createdById,
            },
          });
        } else if (!walkIn.isDefault || walkIn.allowCredit) {
          await tx.customer.update({
            where: { id: walkIn.id },
            data: { isDefault: true, allowCredit: false, creditLimit: 0 },
          });
        }
        finalCustomerId = walkIn.id;
      }

      // 1. Generate Invoice Number using active Invoice Scheme
      const invoiceNumber = dto.invoiceNumber || await this.generateInvoiceNumber(tx, businessId, branchId);

      // 2. Create the Sale record
      const sale = await tx.sale.create({
        data: {
          invoiceNumber,
          saleDate: dto.saleDate ? new Date(dto.saleDate) : new Date(),
          status: status as any,
          paymentStatus: 'DUE', // initially DUE, will update after allocating payments
          amountPaid: 0,
          discountType,
          discountAmount,
          taxAmount,
          grandTotal,
          notes,
          customerId: finalCustomerId,
          branchId,
          businessId,
          createdById,
        },
      });

      // 3. Deduct stock and create Sale lines
      for (const line of saleLines) {
        // Deduct stock using FIFO for non-draft sales
        if (status === 'FINAL') {
          await this.deductStock(tx, line.variantId, branchId, line.quantity, businessId);
        }

        const subtotal = line.quantity * line.unitPrice - (line.discountAmount || 0) + (line.taxAmount || 0);

        const primaryImei = line.imeiNumber || (line.imeis && line.imeis.length > 0 ? line.imeis[0] : null);

        const createdSaleLine = await tx.saleLine.create({
          data: {
            saleId: sale.id,
            variantId: line.variantId,
            quantity: line.quantity,
            unitPrice: line.unitPrice,
            discountAmount: line.discountAmount || 0,
            taxAmount: line.taxAmount || 0,
            subtotal,
            imeiNumber: primaryImei,
            branchId,
            businessId,
          },
        });

        // Mark associated IMEIs as SOLD and bind to saleLineId
        const imeisToSell = (line.imeis && line.imeis.length > 0)
          ? line.imeis
          : (line.imeiNumber ? [line.imeiNumber] : []);

        if (imeisToSell.length > 0 && status === 'FINAL') {
          for (const item of imeisToSell) {
            const cleanImei = String(item).trim();
            if (!cleanImei) continue;

            const existingImei = await tx.productImei.findFirst({
              where: {
                imeiNumber: cleanImei,
                businessId,
              },
            });

            if (existingImei) {
              await tx.productImei.update({
                where: { id: existingImei.id },
                data: {
                  status: 'SOLD',
                  saleLineId: createdSaleLine.id,
                  soldDate: dto.saleDate ? new Date(dto.saleDate) : new Date(),
                },
              });
            } else {
              const v = await tx.productVariant.findUnique({
                where: { id: line.variantId },
                select: { productId: true },
              });
              await tx.productImei.create({
                data: {
                  imeiNumber: cleanImei,
                  status: 'SOLD',
                  productId: v?.productId || '',
                  variantId: line.variantId,
                  branchId,
                  businessId,
                  saleLineId: createdSaleLine.id,
                  soldDate: dto.saleDate ? new Date(dto.saleDate) : new Date(),
                },
              });
            }
          }
        }
      }

      let totalPaid = 0;

      // 4. Handle Customer Advance allocation if requested
      if (useAdvance && status === 'FINAL') {
        const advances = await tx.customerAdvance.findMany({
          where: {
            customerId: finalCustomerId,
            amountRemaining: { gt: 0 },
          },
          orderBy: {
            createdAt: 'asc', // FIFO allocation of advances
          },
        });

        let remainingToPay = grandTotal;

        for (const advance of advances) {
          if (remainingToPay <= 0) break;

          const allocationAmount = Math.min(advance.amountRemaining, remainingToPay);

          // Create allocation record
          await tx.customerAdvanceAllocation.create({
            data: {
              customerAdvanceId: advance.id,
              saleId: sale.id,
              amount: allocationAmount,
            },
          });

          // Update advance remaining amount
          await tx.customerAdvance.update({
            where: { id: advance.id },
            data: {
              amountRemaining: { decrement: allocationAmount },
            },
          });

          remainingToPay -= allocationAmount;
          totalPaid += allocationAmount;
        }
      }

      // 5. Process normal payments if final
      if (status === 'FINAL') {
        for (const pay of payments) {
          if (pay.amount <= 0) continue;

          const paymentNumber = await this.generatePaymentNumber(tx, businessId);

          await tx.salePayment.create({
            data: {
              paymentNumber,
              amount: pay.amount,
              saleId: sale.id,
              customerId: finalCustomerId,
              paymentMethodId: pay.paymentMethodId,
              transactionNo: pay.transactionNo,
              notes: pay.notes,
              branchId,
              businessId,
              createdById,
            },
          });

          totalPaid += pay.amount;
        }
      }

      // 6. Check credit sale restriction
      const customer = await tx.customer.findUnique({
        where: { id: finalCustomerId },
      });

      if (customer && customer.isActive === false) {
        throw new BadRequestException(
          `Cannot process sale for inactive customer "${customer.name}". Please activate the customer first or select an active customer.`
        );
      }

      if (status === 'FINAL' && totalPaid < grandTotal) {
        if (customer && customer.allowCredit === false) {
          throw new BadRequestException(
            `Credit sales are disabled for ${customer.name}. Full payment of ${grandTotal} is required (Amount Paid: ${totalPaid}). Please collect the full payment or select an eligible customer.`
          );
        }

        // Credit Limit enforcement
        if (customer && customer.creditLimit !== null && customer.creditLimit !== undefined) {
          const newUnpaidDue = grandTotal - totalPaid;

          // Fetch previous finalized sales for this customer
          const existingSales = await tx.sale.findMany({
            where: {
              customerId: finalCustomerId,
              businessId,
              status: 'FINAL',
              id: { not: sale.id },
            },
            select: { grandTotal: true, amountPaid: true },
          });

          const currentSalesDue = existingSales.reduce(
            (sum, s) => sum + Math.max(0, s.grandTotal - s.amountPaid),
            0
          );
          const currentTotalDue = (customer.openingBalance || 0) + currentSalesDue;
          const projectedTotalDue = currentTotalDue + newUnpaidDue;

          if (projectedTotalDue > customer.creditLimit) {
            throw new BadRequestException(
              `Credit limit exceeded for ${customer.name}. Credit Limit: ${customer.creditLimit}, Current Outstanding: ${currentTotalDue}, New Sale Due: ${newUnpaidDue}, Projected Due: ${projectedTotalDue}. Please collect at least ${Math.ceil(projectedTotalDue - customer.creditLimit)} more in payment.`
            );
          }
        }
      }

      // 7. Update Sale payment status and total paid
      let paymentStatus: 'PAID' | 'PARTIAL' | 'DUE' = 'DUE';
      if (totalPaid >= grandTotal) {
        paymentStatus = 'PAID';
      } else if (totalPaid > 0) {
        paymentStatus = 'PARTIAL';
      }

      const updatedSale = await tx.sale.update({
        where: { id: sale.id },
        data: {
          amountPaid: totalPaid,
          paymentStatus,
        },
        include: {
          saleLines: {
            include: {
              variant: {
                include: {
                  product: true,
                },
              },
            },
          },
          payments: {
            include: {
              paymentMethod: true,
            },
          },
          customer: true,
          branch: true,
          business: {
            select: {
              id: true,
              name: true,
            },
          },
        },
      });

      return updatedSale;
    });
  }

  async getSales(
    businessId: string,
    filters: {
      branchId?: string;
      customerId?: string;
      status?: 'HOLD' | 'DRAFT' | 'FINAL';
      page?: number;
      limit?: number;
      search?: string;
      userId?: string;
      userRole?: string;
    },
  ) {
    const { branchId, customerId, status, page = 1, limit = 10, search, userId, userRole } = filters;
    const skip = (page - 1) * limit;

    const whereClause: any = {
      businessId,
    };

    // Strict Branch Permission Enforcement:
    // If the user is not admin/super-admin, restrict to their assigned branches
    if (userRole && userRole !== 'admin' && userRole !== 'super-admin' && userId) {
      const userBranches = await this.prisma.userBranch.findMany({
        where: { userId },
        select: { branchId: true },
      });
      const allowedBranchIds = userBranches.map((ub) => ub.branchId);

      if (branchId && branchId !== 'all') {
        if (allowedBranchIds.includes(branchId)) {
          whereClause.branchId = branchId;
        } else {
          whereClause.branchId = { in: allowedBranchIds };
        }
      } else {
        whereClause.branchId = { in: allowedBranchIds };
      }
    } else {
      if (branchId && branchId !== 'all') {
        whereClause.branchId = branchId;
      }
    }

    if (customerId) whereClause.customerId = customerId;
    if (status) whereClause.status = status as any;

    if (search) {
      whereClause.invoiceNumber = {
        contains: search,
        mode: 'insensitive',
      };
    }

    const [total, data] = await Promise.all([
      this.prisma.sale.count({ where: whereClause }),
      this.prisma.sale.findMany({
        where: whereClause,
        include: {
          customer: {
            select: {
              id: true,
              name: true,
              phone: true,
            },
          },
          branch: {
            select: {
              id: true,
              name: true,
              address: true,
              phone: true,
            },
          },
          createdBy: {
            select: {
              id: true,
              name: true,
              email: true,
            },
          },
          business: {
            select: {
              id: true,
              name: true,
            },
          },
          saleLines: {
            include: {
              variant: {
                select: {
                  id: true,
                  name: true,
                  sku: true,
                },
              },
            },
          },
        },
        orderBy: {
          saleDate: 'desc',
        },
        skip,
        take: limit,
      }),
    ]);

    return {
      data,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getSaleById(
    id: string,
    businessId: string,
    userContext?: { userId?: string; userRole?: string; branchIds?: string[] },
  ) {
    const where: any = { id, businessId };
    if (userContext && userContext.userRole !== 'super-admin' && userContext.userRole !== 'admin') {
      let branchIds = userContext.branchIds || [];
      if (branchIds.length === 0 && userContext.userId && (this.prisma as any).userBranch) {
        const userBranches = await (this.prisma as any).userBranch.findMany({
          where: { userId: userContext.userId },
        });
        branchIds = userBranches.map((ub: any) => ub.branchId).filter(Boolean);
      }
      if (branchIds.length > 0) {
        where.branchId = branchIds.length === 1 ? branchIds[0] : { in: branchIds };
      } else {
        where.branchId = 'none';
      }
    }

    const sale = await this.prisma.sale.findFirst({
      where,
      include: {
        customer: true,
        branch: true,
        createdBy: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        business: {
          select: {
            id: true,
            name: true,
          },
        },
        saleLines: {
          include: {
            variant: {
              include: {
                product: true,
              },
            },
            productImeis: true,
          },
        },
        payments: {
          include: {
            paymentMethod: true,
          },
        },
      },
    });

    if (!sale) {
      throw new NotFoundException('Sale record not found.');
    }

    if (
      userContext &&
      userContext.userRole !== 'super-admin' &&
      userContext.userRole !== 'admin' &&
      userContext.branchIds &&
      userContext.branchIds.length > 0 &&
      !userContext.branchIds.includes(sale.branchId)
    ) {
      throw new ForbiddenException('Access denied: You do not have permission to view sales of this branch.');
    }

    return sale;
  }

  async addCustomerAdvance(data: {
    customerId: string;
    amount: number;
    paymentMethodId: string;
    transactionNo?: string;
    notes?: string;
    branchId: string;
    businessId: string;
    createdById?: string;
  }) {
    return this.prisma.$transaction(async (tx) => {
      const advanceNumber = await this.generateAdvanceNumber(tx, data.businessId);

      const advance = await tx.customerAdvance.create({
        data: {
          advanceNumber,
          amount: data.amount,
          amountRemaining: data.amount,
          customerId: data.customerId,
          paymentMethodId: data.paymentMethodId,
          transactionNo: data.transactionNo,
          notes: data.notes,
          branchId: data.branchId,
          businessId: data.businessId,
          createdById: data.createdById,
        },
      });

      return advance;
    });
  }

  async getCustomerAdvances(customerId: string, businessId: string) {
    return this.prisma.customerAdvance.findMany({
      where: { customerId, businessId, amountRemaining: { gt: 0 } },
      include: { paymentMethod: true },
    });
  }

  async deductStock(
    tx: Prisma.TransactionClient,
    variantId: string,
    branchId: string,
    quantityToDeduct: number,
    businessId?: string,
  ) {
    if (quantityToDeduct <= 0) return;

    // Find all batches for this variant and branch with stock remaining, oldest first
    const where: any = {
      variantId,
      branchId,
      quantityRemaining: { gt: 0 },
    };
    if (businessId) {
      where.businessId = businessId;
    }
    const batches = await tx.purchaseLine.findMany({
      where,
      orderBy: {
        createdAt: 'asc', // FIFO
      },
    });

    let remainingToDeduct = quantityToDeduct;

    for (const batch of batches) {
      if (remainingToDeduct <= 0) break;

      if (batch.quantityRemaining >= remainingToDeduct) {
        // This batch has enough stock
        await tx.purchaseLine.update({
          where: { id: batch.id },
          data: {
            quantityRemaining: { decrement: remainingToDeduct },
          },
        });
        remainingToDeduct = 0;
      } else {
        // Take everything from this batch and continue
        remainingToDeduct -= batch.quantityRemaining;
        await tx.purchaseLine.update({
          where: { id: batch.id },
          data: {
            quantityRemaining: 0,
          },
        });
      }
    }

    if (remainingToDeduct > 0) {
      throw new BadRequestException(
        `Insufficient stock for product variant. Needed: ${quantityToDeduct}, Missing: ${remainingToDeduct}`,
      );
    }
  }

  private async generateInvoiceNumber(
    tx: Prisma.TransactionClient,
    businessId: string,
    branchId?: string,
  ): Promise<string> {
    // Check branch-specific scheme first, then default scheme
    let scheme = null;
    if (branchId) {
      scheme = await tx.invoiceScheme.findFirst({
        where: { businessId, branchId },
      });
    }
    if (!scheme) {
      scheme = await tx.invoiceScheme.findFirst({
        where: { businessId, isDefault: true },
      });
    }
    if (!scheme) {
      scheme = await tx.invoiceScheme.findFirst({
        where: { businessId },
        orderBy: { createdAt: 'asc' },
      });
    }

    if (scheme) {
      const prefix = scheme.prefix || '';
      const startNum = scheme.startNumber || 1001;
      const digits = scheme.numberOfDigits || 4;

      const lastSale = await tx.sale.findFirst({
        where: {
          businessId,
          ...(prefix ? { invoiceNumber: { startsWith: prefix } } : {}),
        },
        orderBy: { createdAt: 'desc' },
      });

      let nextNum = startNum;
      if (lastSale && lastSale.invoiceNumber) {
        let numPart = lastSale.invoiceNumber;
        if (prefix && numPart.startsWith(prefix)) {
          numPart = numPart.slice(prefix.length);
        }
        const parsed = parseInt(numPart, 10);
        if (!isNaN(parsed) && parsed >= startNum) {
          nextNum = parsed + 1;
        } else {
          const count = await tx.sale.count({ where: { businessId } });
          nextNum = startNum + count;
        }
      }

      return `${prefix}${String(nextNum).padStart(digits, '0')}`;
    }

    // Fallback if no scheme defined
    const today = new Date();
    const dateStr = today.toISOString().slice(0, 10).replace(/-/g, '');

    const lastSale = await tx.sale.findFirst({
      where: {
        businessId,
        invoiceNumber: {
          startsWith: `INV-${dateStr}-`,
        },
      },
      orderBy: {
        invoiceNumber: 'desc',
      },
    });

    let seqNum = 1;
    if (lastSale) {
      const parts = lastSale.invoiceNumber.split('-');
      const lastSeq = parseInt(parts[parts.length - 1], 10);
      if (!isNaN(lastSeq)) {
        seqNum = lastSeq + 1;
      }
    }

    const seq = seqNum.toString().padStart(4, '0');
    return `INV-${dateStr}-${seq}`;
  }

  private async generatePaymentNumber(tx: Prisma.TransactionClient, businessId: string): Promise<string> {
    const lastPayment = await tx.salePayment.findFirst({
      where: { businessId },
      orderBy: { paymentNumber: 'desc' },
    });

    let seqNum = 1;
    if (lastPayment) {
      const parts = lastPayment.paymentNumber.split('-');
      const lastSeq = parseInt(parts[parts.length - 1], 10);
      if (!isNaN(lastSeq)) {
        seqNum = lastSeq + 1;
      } else {
        const match = lastPayment.paymentNumber.match(/\d+$/);
        if (match) {
          seqNum = parseInt(match[0], 10) + 1;
        }
      }
    }

    const seq = seqNum.toString().padStart(6, '0');
    return `SPAY-${seq}`;
  }

  private async generateAdvanceNumber(tx: Prisma.TransactionClient, businessId: string): Promise<string> {
    const lastAdvance = await tx.customerAdvance.findFirst({
      where: { businessId },
      orderBy: { advanceNumber: 'desc' },
    });

    let seqNum = 1;
    if (lastAdvance) {
      const parts = lastAdvance.advanceNumber.split('-');
      const lastSeq = parseInt(parts[parts.length - 1], 10);
      if (!isNaN(lastSeq)) {
        seqNum = lastSeq + 1;
      } else {
        const match = lastAdvance.advanceNumber.match(/\d+$/);
        if (match) {
          seqNum = parseInt(match[0], 10) + 1;
        }
      }
    }

    const seq = seqNum.toString().padStart(6, '0');
    return `CADV-${seq}`;
  }

  async deleteSale(id: string, businessId: string) {
    const sale = await this.prisma.sale.findFirst({
      where: { id, businessId },
      include: {
        saleLines: true,
        allocations: true,
        salesReturns: true,
      },
    });

    if (!sale) {
      throw new NotFoundException('Sale not found');
    }

    if (sale.salesReturns && sale.salesReturns.length > 0) {
      throw new BadRequestException(
        `Cannot delete invoice ${sale.invoiceNumber} because sales returns have already been processed against it.`,
      );
    }

    return this.prisma.$transaction(async (tx) => {
      // If completed sale, restore stock back into purchaseLine batches
      if (sale.status === 'FINAL') {
        for (const oldLine of sale.saleLines) {
          const rand = Math.floor(1000 + Math.random() * 9000);
          const v = await tx.productVariant.findUnique({
            where: { id: oldLine.variantId },
            select: { purchasePrice: true, sellingPrice: true },
          });
          const costPrice = v?.purchasePrice ?? oldLine.unitPrice;
          const sellPrice = v?.sellingPrice ?? oldLine.unitPrice;
          await tx.purchaseLine.create({
            data: {
              variantId: oldLine.variantId,
              branchId: sale.branchId,
              businessId,
              batchNumber: `RESTORE-DEL-${rand}`,
              quantityPurchased: oldLine.quantity,
              quantityRemaining: oldLine.quantity,
              purchasePrice: costPrice,
              sellingPrice: sellPrice,
            },
          });
        }

        // Restore any customer advance allocations
        if (sale.allocations && sale.allocations.length > 0) {
          for (const alloc of sale.allocations) {
            await tx.customerAdvance.update({
              where: { id: alloc.customerAdvanceId },
              data: {
                amountRemaining: { increment: alloc.amount },
              },
            });
          }
        }

        // Restore IMEIs back to IN_STOCK
        const saleLineIds = sale.saleLines.map((l) => l.id);
        await tx.productImei.updateMany({
          where: { saleLineId: { in: saleLineIds } },
          data: {
            status: 'IN_STOCK',
            saleLineId: null,
            soldDate: null,
          },
        });
      }

      await tx.sale.delete({
        where: { id },
      });

      return {
        success: true,
        message: `Sale ${sale.invoiceNumber} deleted and stock restored successfully.`,
      };
    });
  }

  async updateSale(id: string, businessId: string, dto: UpdateSaleDto) {
    const sale = await this.prisma.sale.findFirst({
      where: { id, businessId },
      include: {
        saleLines: true,
        payments: true,
      },
    });

    if (!sale) {
      throw new NotFoundException('Sale not found');
    }

    if (!dto.saleLines || dto.saleLines.length === 0) {
      throw new BadRequestException('Sale must contain at least one item.');
    }

    return this.prisma.$transaction(async (tx) => {
      // 1. If original sale was FINAL, restore old stock back into purchaseLine batches
      if (sale.status === 'FINAL') {
        for (const oldLine of sale.saleLines) {
          const rand = Math.floor(1000 + Math.random() * 9000);
          const v = await tx.productVariant.findUnique({
            where: { id: oldLine.variantId },
            select: { purchasePrice: true, sellingPrice: true },
          });
          const costPrice = v?.purchasePrice ?? oldLine.unitPrice;
          const sellPrice = v?.sellingPrice ?? oldLine.unitPrice;
          await tx.purchaseLine.create({
            data: {
              variantId: oldLine.variantId,
              branchId: sale.branchId,
              businessId,
              batchNumber: `RESTORE-${rand}`,
              quantityPurchased: oldLine.quantity,
              quantityRemaining: oldLine.quantity,
              purchasePrice: costPrice,
              sellingPrice: sellPrice,
            },
          });
        }

        // Restore IMEIs back to IN_STOCK
        const oldSaleLineIds = sale.saleLines.map((l) => l.id);
        if (oldSaleLineIds.length > 0) {
          await tx.productImei.updateMany({
            where: { saleLineId: { in: oldSaleLineIds } },
            data: {
              status: 'IN_STOCK',
              saleLineId: null,
              soldDate: null,
            },
          });
        }
      }

      // 2. Remove old sale lines
      await tx.saleLine.deleteMany({
        where: { saleId: id },
      });

      // 3. Deduct new stock and create new sale lines
      for (const line of dto.saleLines) {
        if (sale.status === 'FINAL') {
          await this.deductStock(tx, line.variantId, sale.branchId, line.quantity);
        }

        const subtotal =
          line.quantity * line.unitPrice - (line.discountAmount || 0) + (line.taxAmount || 0);
        const primaryImei = (line as any).imeiNumber || ((line as any).imeis && (line as any).imeis.length > 0 ? (line as any).imeis[0] : null);

        const createdSaleLine = await tx.saleLine.create({
          data: {
            saleId: id,
            variantId: line.variantId,
            quantity: line.quantity,
            unitPrice: line.unitPrice,
            discountAmount: line.discountAmount || 0,
            taxAmount: line.taxAmount || 0,
            subtotal,
            imeiNumber: primaryImei,
            branchId: sale.branchId,
            businessId,
          },
        });

        const imeisToSell = ((line as any).imeis && (line as any).imeis.length > 0)
          ? (line as any).imeis
          : (primaryImei ? [primaryImei] : []);

        if (imeisToSell.length > 0 && sale.status === 'FINAL') {
          for (const item of imeisToSell) {
            const cleanImei = String(item).trim();
            if (!cleanImei) continue;

            const existingImei = await tx.productImei.findFirst({
              where: {
                imeiNumber: cleanImei,
                businessId,
              },
            });

            if (existingImei) {
              await tx.productImei.update({
                where: { id: existingImei.id },
                data: {
                  status: 'SOLD',
                  saleLineId: createdSaleLine.id,
                  soldDate: new Date(),
                },
              });
            }
          }
        }
      }

      // 4. Handle additional payments if provided
      let totalPaid = sale.amountPaid || 0;
      if (dto.payments && dto.payments.length > 0) {
        for (const p of dto.payments) {
          if (p.amount > 0) {
            const paymentNumber = await this.generatePaymentNumber(tx, businessId);
            await tx.salePayment.create({
              data: {
                paymentNumber,
                amount: p.amount,
                transactionNo: p.transactionNo,
                notes: p.notes,
                saleId: id,
                customerId: dto.customerId || sale.customerId,
                paymentMethodId: p.paymentMethodId,
                branchId: sale.branchId,
                businessId,
              },
            });
            totalPaid += p.amount;
          }
        }
      }

      // 5. Calculate new payment status & validate Credit Limits
      const newUnpaidDue = Math.max(0, dto.grandTotal - totalPaid);
      if (sale.status === 'FINAL' && newUnpaidDue > 0) {
        const targetCustomerId = dto.customerId || sale.customerId;
        const cust = await tx.customer.findUnique({
          where: { id: targetCustomerId },
        });

        if (cust && cust.allowCredit === false) {
          throw new BadRequestException(
            `Credit sales are disabled for ${cust.name}. Full payment of ${dto.grandTotal} is required.`
          );
        }

        if (cust && cust.creditLimit !== null && cust.creditLimit !== undefined) {
          const otherSales = await tx.sale.findMany({
            where: {
              customerId: targetCustomerId,
              businessId,
              status: 'FINAL',
              id: { not: id },
            },
            select: { grandTotal: true, amountPaid: true },
          });

          const otherSalesDue = otherSales.reduce(
            (sum, s) => sum + Math.max(0, s.grandTotal - s.amountPaid),
            0
          );
          const currentTotalDue = (cust.openingBalance || 0) + otherSalesDue;
          const projectedTotalDue = currentTotalDue + newUnpaidDue;

          if (projectedTotalDue > cust.creditLimit) {
            const minPaymentRequired = Math.ceil(projectedTotalDue - cust.creditLimit);
            const availableCredit = Math.max(0, cust.creditLimit - currentTotalDue);
            throw new BadRequestException(
              `Credit limit exceeded for ${cust.name}. Credit Limit: ${cust.creditLimit}, Current Outstanding: ${currentTotalDue}, Available Credit: ${availableCredit}, New Bill Due: ${newUnpaidDue}, Projected Due: ${projectedTotalDue}. Please collect at least ${minPaymentRequired} in payment.`
            );
          }
        }
      }

      let paymentStatus: 'PAID' | 'PARTIAL' | 'DUE' = 'DUE';
      if (totalPaid >= dto.grandTotal) {
        paymentStatus = 'PAID';
      } else if (totalPaid > 0) {
        paymentStatus = 'PARTIAL';
      }

      // 6. Update Sale record
      const updated = await tx.sale.update({
        where: { id },
        data: {
          customerId: dto.customerId || sale.customerId,
          discountType: dto.discountType,
          discountAmount: dto.discountAmount || 0,
          taxAmount: dto.taxAmount || 0,
          grandTotal: dto.grandTotal,
          notes: dto.notes,
          amountPaid: totalPaid,
          paymentStatus,
        },
        include: {
          saleLines: {
            include: {
              variant: {
                include: {
                  product: true,
                },
              },
            },
          },
          payments: {
            include: {
              paymentMethod: true,
            },
          },
          customer: true,
          branch: true,
          business: {
            select: {
              id: true,
              name: true,
            },
          },
        },
      });

      return updated;
    });
  }

  async addSalePayment(
    saleId: string,
    payload: {
      amount: number;
      paymentMethodId: string;
      transactionNo?: string;
      notes?: string;
      businessId: string;
      createdById?: string;
    },
  ) {
    const { amount, paymentMethodId, transactionNo, notes, businessId, createdById } = payload;

    const sale = await this.prisma.sale.findFirst({
      where: { id: saleId, businessId },
    });

    if (!sale) {
      throw new NotFoundException('Sale not found');
    }

    const remainingDue = sale.grandTotal - sale.amountPaid;
    if (amount <= 0) {
      throw new BadRequestException('Payment amount must be greater than zero.');
    }
    if (amount > remainingDue) {
      throw new BadRequestException(`Payment amount (₹${amount}) exceeds remaining due (₹${remainingDue}).`);
    }

    return this.prisma.$transaction(async (tx) => {
      const paymentNumber = await this.generatePaymentNumber(tx, businessId);

      const payment = await tx.salePayment.create({
        data: {
          paymentNumber,
          amount,
          transactionNo,
          notes,
          saleId,
          customerId: sale.customerId,
          paymentMethodId,
          branchId: sale.branchId,
          businessId,
          createdById,
        },
      });

      const newAmountPaid = sale.amountPaid + amount;
      let paymentStatus: 'DUE' | 'PARTIAL' | 'PAID' = 'PARTIAL';
      if (newAmountPaid >= sale.grandTotal) {
        paymentStatus = 'PAID';
      } else if (newAmountPaid === 0) {
        paymentStatus = 'DUE';
      }

      await tx.sale.update({
        where: { id: saleId },
        data: {
          amountPaid: newAmountPaid,
          paymentStatus,
        },
      });

      return payment;
    });
  }

  async getSalePayments(saleId: string, businessId: string) {
    return this.prisma.salePayment.findMany({
      where: { saleId, businessId },
      include: {
        paymentMethod: true,
      },
      orderBy: {
        createdAt: 'desc',
      },
    });
  }

  async deleteSalePayment(paymentId: string, businessId: string) {
    const payment = await this.prisma.salePayment.findFirst({
      where: { id: paymentId, businessId },
      include: { sale: true },
    });

    if (!payment) {
      throw new NotFoundException('Payment not found');
    }

    return this.prisma.$transaction(async (tx) => {
      await tx.salePayment.delete({
        where: { id: paymentId },
      });

      const newAmountPaid = Math.max(0, payment.sale.amountPaid - payment.amount);
      let paymentStatus: 'DUE' | 'PARTIAL' | 'PAID' = 'PARTIAL';
      if (newAmountPaid >= payment.sale.grandTotal) {
        paymentStatus = 'PAID';
      } else if (newAmountPaid === 0) {
        paymentStatus = 'DUE';
      }

      await tx.sale.update({
        where: { id: payment.saleId },
        data: {
          amountPaid: newAmountPaid,
          paymentStatus,
        },
      });

      return { success: true };
    });
  }
}
