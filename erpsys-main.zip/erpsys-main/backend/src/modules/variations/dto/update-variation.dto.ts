import {
  IsString,
  IsOptional,
  Length,
  IsArray,
  ArrayMinSize,
} from 'class-validator';

export class UpdateVariationDto {
  @IsOptional()
  @IsString()
  @Length(2, 100, { message: 'Variation name must be between 2 and 100 characters' })
  name?: string;

  @IsOptional()
  @IsArray({ message: 'Values must be an array of strings' })
  @ArrayMinSize(1, { message: 'At least one variation value must be provided' })
  @IsString({ each: true, message: 'Each variation value must be a string' })
  values?: string[];

  @IsOptional()
  isActive?: boolean | string;

  @IsOptional()
  @IsString()
  businessId?: string;

  @IsOptional()
  branchIds?: string[] | string;

  @IsOptional()
  @IsString()
  updatedById?: string;
}
