import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { UpdateSmsSettingsDto, TestSmsDto } from './dto/sms-settings.dto';
import { randomUUID } from 'crypto';

@Injectable()
export class SmsSettingsService {
  constructor(private readonly prisma: PrismaService) {}

  async getSettings(businessId: string) {
    if ((this.prisma as any).smsSettings) {
      let settings = await (this.prisma as any).smsSettings.findUnique({
        where: { businessId },
      });

      if (!settings) {
        settings = await (this.prisma as any).smsSettings.create({
          data: {
            businessId,
            enableSms: false,
            httpMethod: 'POST',
            mobileParamName: 'mobile',
            messageParamName: 'message',
            sendOnSale: true,
            saleTemplate:
              'Dear {customer_name}, thank you for your purchase of {grand_total} at {business_name}. Invoice: {invoice_no}',
            sendOnPayment: true,
            paymentTemplate:
              'Dear {customer_name}, we received payment of {paid_amount} for Invoice {invoice_no}. Thank you, {business_name}',
          },
        });
      }
      return settings;
    }

    // Direct database raw query fallback
    const rows: any[] = await this.prisma.$queryRawUnsafe(
      `SELECT * FROM "SmsSettings" WHERE "businessId" = $1 LIMIT 1`,
      businessId,
    );

    if (rows && rows.length > 0) {
      return rows[0];
    }

    const newId = randomUUID();
    await this.prisma.$executeRawUnsafe(
      `INSERT INTO "SmsSettings" 
       ("id", "businessId", "enableSms", "httpMethod", "mobileParamName", "messageParamName", "sendOnSale", "saleTemplate", "sendOnPayment", "paymentTemplate", "createdAt", "updatedAt") 
       VALUES ($1, $2, false, 'POST', 'mobile', 'message', true, 'Dear {customer_name}, thank you for your purchase of {grand_total} at {business_name}. Invoice: {invoice_no}', true, 'Dear {customer_name}, we received payment of {paid_amount} for Invoice {invoice_no}. Thank you, {business_name}', NOW(), NOW())`,
      newId,
      businessId,
    );

    const created: any[] = await this.prisma.$queryRawUnsafe(
      `SELECT * FROM "SmsSettings" WHERE "businessId" = $1 LIMIT 1`,
      businessId,
    );
    return created[0];
  }

  async updateSettings(businessId: string, dto: UpdateSmsSettingsDto) {
    const dataPayload: any = {};
    if (dto.enableSms !== undefined) dataPayload.enableSms = dto.enableSms;
    if (dto.gatewayUrl !== undefined) {
      if (dto.gatewayUrl) {
        try {
          const parsedUrl = new URL(dto.gatewayUrl);
          const hostname = parsedUrl.hostname.toLowerCase();
          const isLocalhost =
            hostname === 'localhost' ||
            hostname === '127.0.0.1' ||
            hostname === '0.0.0.0' ||
            hostname === '::1' ||
            hostname === '[::1]' ||
            hostname.endsWith('.localhost') ||
            hostname.endsWith('.internal');
          const isPrivateIp =
            /^10\./.test(hostname) ||
            /^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(hostname) ||
            /^192\.168\./.test(hostname) ||
            /^169\.254\./.test(hostname);

          if (isLocalhost || isPrivateIp) {
            throw new BadRequestException('Invalid SMS gateway URL: Internal and loopback addresses are prohibited.');
          }
        } catch (e: any) {
          if (e instanceof BadRequestException) throw e;
          throw new BadRequestException('Invalid SMS gateway URL format.');
        }
      }
      dataPayload.gatewayUrl = dto.gatewayUrl;
    }
    if (dto.httpMethod !== undefined) dataPayload.httpMethod = dto.httpMethod;
    if (dto.apiKey !== undefined) dataPayload.apiKey = dto.apiKey;
    if (dto.apiSecret !== undefined) dataPayload.apiSecret = dto.apiSecret;
    if (dto.senderId !== undefined) dataPayload.senderId = dto.senderId;
    if (dto.mobileParamName !== undefined) dataPayload.mobileParamName = dto.mobileParamName;
    if (dto.messageParamName !== undefined) dataPayload.messageParamName = dto.messageParamName;
    if (dto.customHeaders !== undefined) dataPayload.customHeaders = dto.customHeaders;
    if (dto.sendOnSale !== undefined) dataPayload.sendOnSale = dto.sendOnSale;
    if (dto.saleTemplate !== undefined) dataPayload.saleTemplate = dto.saleTemplate;
    if (dto.sendOnPayment !== undefined) dataPayload.sendOnPayment = dto.sendOnPayment;
    if (dto.paymentTemplate !== undefined) dataPayload.paymentTemplate = dto.paymentTemplate;

    if ((this.prisma as any).smsSettings) {
      return (this.prisma as any).smsSettings.upsert({
        where: { businessId },
        create: {
          businessId,
          ...dataPayload,
        },
        update: dataPayload,
      });
    }

    // Direct raw SQL upsert
    const existing: any[] = await this.prisma.$queryRawUnsafe(
      `SELECT "id" FROM "SmsSettings" WHERE "businessId" = $1 LIMIT 1`,
      businessId,
    );

    if (existing && existing.length > 0) {
      const keys = Object.keys(dataPayload);
      if (keys.length > 0) {
        const setClauses = keys.map((k, i) => `"${k}" = $${i + 2}`).join(', ');
        const values = keys.map((k) => dataPayload[k]);
        await this.prisma.$executeRawUnsafe(
          `UPDATE "SmsSettings" SET ${setClauses}, "updatedAt" = NOW() WHERE "businessId" = $1`,
          businessId,
          ...values,
        );
      }
    } else {
      const newId = randomUUID();
      const keys = Object.keys(dataPayload);
      const cols = ['"id"', '"businessId"', ...keys.map((k) => `"${k}"`), '"createdAt"', '"updatedAt"'].join(', ');
      const placeholders = ['$1', '$2', ...keys.map((_, i) => `$${i + 3}`), 'NOW()', 'NOW()'].join(', ');
      const values = keys.map((k) => dataPayload[k]);
      await this.prisma.$executeRawUnsafe(
        `INSERT INTO "SmsSettings" (${cols}) VALUES (${placeholders})`,
        newId,
        businessId,
        ...values,
      );
    }

    const updated: any[] = await this.prisma.$queryRawUnsafe(
      `SELECT * FROM "SmsSettings" WHERE "businessId" = $1 LIMIT 1`,
      businessId,
    );
    return updated[0];
  }

  async sendTestSms(businessId: string, dto: TestSmsDto) {
    const settings = await this.getSettings(businessId);
    if (!settings || !settings.gatewayUrl) {
      throw new BadRequestException('SMS Gateway URL is not configured.');
    }

    try {
      const parsedUrl = new URL(settings.gatewayUrl);
      const hostname = parsedUrl.hostname.toLowerCase();
      const isLocalhost =
        hostname === 'localhost' ||
        hostname === '127.0.0.1' ||
        hostname === '0.0.0.0' ||
        hostname === '::1' ||
        hostname === '[::1]' ||
        hostname.endsWith('.localhost') ||
        hostname.endsWith('.internal');
      const isPrivateIp =
        /^10\./.test(hostname) ||
        /^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(hostname) ||
        /^192\.168\./.test(hostname) ||
        /^169\.254\./.test(hostname);

      if (isLocalhost || isPrivateIp) {
        throw new BadRequestException('Invalid SMS gateway URL: Internal and loopback addresses are prohibited.');
      }
    } catch (e: any) {
      if (e instanceof BadRequestException) throw e;
      throw new BadRequestException('Invalid SMS gateway URL format.');
    }

    const messageText =
      dto.message ||
      `Test SMS from HKRION ERP at ${new Date().toLocaleTimeString()}. If you received this, your SMS gateway is working properly!`;

    const mobile = dto.mobileNumber;
    const method = (settings.httpMethod || 'POST').toUpperCase();
    const mobKey = settings.mobileParamName || 'mobile';
    const msgKey = settings.messageParamName || 'message';

    let headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (settings.apiKey) {
      headers['Authorization'] = `Bearer ${settings.apiKey}`;
      headers['api-key'] = settings.apiKey;
    }

    if (settings.customHeaders) {
      try {
        const parsed = JSON.parse(settings.customHeaders);
        headers = { ...headers, ...parsed };
      } catch (e) {
        // ignore JSON parse err for headers
      }
    }

    let url = settings.gatewayUrl;
    let fetchOptions: RequestInit = {
      method,
      headers,
    };

    if (method === 'GET') {
      const query = new URLSearchParams();
      query.append(mobKey, mobile);
      query.append(msgKey, messageText);
      if (settings.senderId) query.append('sender', settings.senderId);
      if (settings.apiKey) query.append('apikey', settings.apiKey);

      url += (url.includes('?') ? '&' : '?') + query.toString();
    } else {
      const bodyPayload: any = {
        [mobKey]: mobile,
        [msgKey]: messageText,
      };
      if (settings.senderId) bodyPayload.sender = settings.senderId;
      if (settings.apiKey) bodyPayload.apiKey = settings.apiKey;
      if (settings.apiSecret) bodyPayload.apiSecret = settings.apiSecret;

      fetchOptions.body = JSON.stringify(bodyPayload);
    }

    try {
      const response = await fetch(url, fetchOptions);
      const resText = await response.text();
      return {
        success: response.ok,
        status: response.status,
        response: resText,
      };
    } catch (err: any) {
      return {
        success: false,
        error: err.message || 'Failed to dispatch request to SMS Gateway.',
      };
    }
  }
}
