'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import DashboardSidebar from '@/components/DashboardSidebar';
import { Briefcase, RefreshCw } from 'lucide-react';

interface Inquiry {
  id: string;
  name: string;
  email: string;
  phone: string;
  service: string;
  message: string;
  status: string;
  createdAt: string;
}

export default function EmployeeDashboard() {
  const router = useRouter();
  const [tasks, setTasks] = useState<Inquiry[]>([]);
  const [loading, setLoading] = useState(true);
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const fetchTasks = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/employee/inquiries');
      if (res.status === 401 || res.status === 403) {
        router.push('/login');
        return;
      }
      const data = await res.json();
      if (data.inquiries) {
        setTasks(data.inquiries);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    fetchTasks();
  }, [fetchTasks]);

  const handleStatusChange = async (id: string, newStatus: string) => {
    setUpdatingId(id);
    try {
      const res = await fetch('/api/employee/inquiries', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status: newStatus }),
      });
      if (res.ok) {
        setTasks((prev) =>
          prev.map((item) => (item.id === id ? { ...item, status: newStatus } : item))
        );
      }
    } catch (err) {
      console.error(err);
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white radial-bg flex">
      {/* Left Sidebar */}
      <DashboardSidebar
        userRole="EMPLOYEE"
        userName="HKRION Senior Engineer"
        userEmail="employee@hkrion.com"
        activeTab="inquiries"
      />

      {/* Main Content Area */}
      <div className="flex-1 lg:ml-64 flex flex-col min-w-0 min-h-screen">
        
        {/* Top Header */}
        <header className="border-b border-blue-500/20 bg-black/80 backdrop-blur-md sticky top-0 z-30 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-500/20 border border-blue-500/40 flex items-center justify-center">
              <Briefcase className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h1 className="text-lg font-bold font-mono tracking-wide text-white">
                HKRION <span className="text-blue-400">Employee Workspace</span>
              </h1>
              <p className="text-xs text-neutral-400">Assigned Client Tasks & Follow-ups</p>
            </div>
          </div>

          <button
            onClick={fetchTasks}
            className="px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-blue-500/40 text-neutral-300 hover:text-white text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-blue-400' : ''}`} />
            Refresh Tasks
          </button>
        </header>

        {/* Task Cards */}
        <main className="p-6 sm:p-8 space-y-6 flex-1">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-white">Assigned Client Inquiries</h2>
              <p className="text-xs text-neutral-400 mt-1">
                Manage client inquiries assigned to you by HKRION Admin.
              </p>
            </div>
            <span className="px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-mono font-medium">
              {tasks.length} Active Assignments
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {tasks.length === 0 ? (
              <div className="col-span-full glass-card p-12 text-center text-neutral-500 rounded-2xl border border-neutral-800">
                No tasks currently assigned. New tasks will appear here when assigned by Admin.
              </div>
            ) : (
              tasks.map((task) => (
                <div
                  key={task.id}
                  className="glass-card p-6 rounded-2xl border border-blue-500/30 bg-black/90 space-y-4 relative"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-lg font-bold text-white">{task.name}</h3>
                      <p className="text-xs font-mono text-neutral-400">{task.email}</p>
                      {task.phone && <p className="text-xs text-neutral-500">{task.phone}</p>}
                    </div>

                    <select
                      value={task.status}
                      disabled={updatingId === task.id}
                      onChange={(e) => handleStatusChange(task.id, e.target.value)}
                      className="px-3 py-1.5 rounded-lg text-xs font-semibold border bg-black text-blue-400 border-blue-500/50 focus:outline-none cursor-pointer"
                    >
                      <option value="PENDING">PENDING</option>
                      <option value="CONTACTED">CONTACTED</option>
                      <option value="IN_PROGRESS">IN PROGRESS</option>
                      <option value="RESOLVED">RESOLVED</option>
                    </select>
                  </div>

                  <div>
                    <span className="px-2.5 py-1 rounded-lg bg-blue-500/10 text-blue-400 font-medium text-xs border border-blue-500/30">
                      {task.service}
                    </span>
                  </div>

                  <div className="p-4 rounded-xl bg-neutral-900/80 border border-neutral-800 text-xs text-neutral-300 space-y-1">
                    <span className="text-[10px] font-mono text-neutral-500 uppercase block">Client Request Details:</span>
                    <p className="leading-relaxed">{task.message}</p>
                  </div>

                  <div className="text-[10px] font-mono text-neutral-500 text-right">
                    Received: {new Date(task.createdAt).toLocaleString()}
                  </div>
                </div>
              ))
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
