export type AdjustmentType = 'ADDITION' | 'SUBTRACTION';

export interface StockAdjustmentLineItem {
  id?: string;
  variantId: string;
  variantName?: string;
  sku?: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
}

export interface StockAdjustmentItem {
  id: string;
  adjustmentNumber: string;
  adjustmentDate: string;
  type: AdjustmentType;
  reason: string;
  totalAmount: number;
  notes?: string;
  branchId: string;
  branch?: {
    id: string;
    name: string;
  };
  createdById?: string;
  createdBy?: {
    id: string;
    name: string;
    email: string;
  };
  adjustmentLines: Array<{
    id: string;
    variantId: string;
    quantity: number;
    unitPrice: number;
    subtotal: number;
    variant?: {
      id: string;
      name: string;
      sku: string;
      product?: {
        id: string;
        name: string;
      };
    };
  }>;
  createdAt: string;
  updatedAt: string;
}
