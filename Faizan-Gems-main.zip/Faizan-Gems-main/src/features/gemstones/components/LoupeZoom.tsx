"use client";

import React, { useState, useRef, MouseEvent, TouchEvent, useEffect } from "react";
import Image from "next/image";
import { LoupeIcon } from "@/components/ui/LuxuryIcons";

interface LoupeZoomProps {
  src: string;
  alt: string;
  aspectRatio?: string;
}

export function LoupeZoom({ src, alt, aspectRatio = "aspect-[4/3]" }: LoupeZoomProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isActive, setIsActive] = useState(false);
  const [loupeEnabled, setLoupeEnabled] = useState(true);
  const [zoomFactor, setZoomFactor] = useState<number>(10); // True 10x magnification
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const [dimensions, setDimensions] = useState({ width: 600, height: 450 });

  const LOUPE_SIZE = 220; // Expansive 220px inspection lens

  // Update container dimensions on mount or resize
  useEffect(() => {
    const updateDimensions = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          setDimensions({ width: rect.width, height: rect.height });
        }
      }
    };

    updateDimensions();
    window.addEventListener("resize", updateDimensions);
    return () => window.removeEventListener("resize", updateDimensions);
  }, []);

  const updatePosition = (clientX: number, clientY: number) => {
    if (!containerRef.current || !loupeEnabled) return;

    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;

    if (x < 0 || y < 0 || x > rect.width || y > rect.height) {
      setIsActive(false);
      return;
    }

    setDimensions({ width: rect.width, height: rect.height });
    setPos({ x, y });
    setIsActive(true);
  };

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    updatePosition(e.clientX, e.clientY);
  };

  const handleTouchMove = (e: TouchEvent<HTMLDivElement>) => {
    if (e.touches.length > 0) {
      const touch = e.touches[0];
      updatePosition(touch.clientX, touch.clientY);
    }
  };

  const handleMouseLeave = () => {
    setIsActive(false);
  };

  // Precise optical offset: maps cursor point to the exact center of the circular loupe
  const bgWidth = dimensions.width * zoomFactor;
  const bgHeight = dimensions.height * zoomFactor;
  const bgX = LOUPE_SIZE / 2 - pos.x * zoomFactor;
  const bgY = LOUPE_SIZE / 2 - pos.y * zoomFactor;

  return (
    <div className="relative select-none">
      {/* Precision Instrument Control Bar */}
      <div className="mb-3 flex items-center justify-between text-xs font-sans text-[#8C867D]">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 uppercase tracking-wider text-[#18181D] font-medium">
            <LoupeIcon className="w-4 h-4 text-[#C5A880]" />
            10x Gemological Inspection Lens
          </span>

          {/* Magnification Level Switcher */}
          <div className="hidden sm:flex items-center bg-[#F4F1EA] border border-[#E8E4DC] p-0.5 rounded-sm text-[10px]">
            <button
              onClick={() => setZoomFactor(5)}
              className={`px-2 py-0.5 rounded-sm uppercase tracking-wider transition-colors ${
                zoomFactor === 5
                  ? "bg-[#18181D] text-[#E0CFA9] font-medium"
                  : "text-[#8C867D] hover:text-[#18181D]"
              }`}
            >
              5x Macro
            </button>
            <button
              onClick={() => setZoomFactor(10)}
              className={`px-2 py-0.5 rounded-sm uppercase tracking-wider transition-colors ${
                zoomFactor === 10
                  ? "bg-[#18181D] text-[#E0CFA9] font-medium"
                  : "text-[#8C867D] hover:text-[#18181D]"
              }`}
            >
              10x Triplet
            </button>
          </div>
        </div>

        <button
          onClick={() => setLoupeEnabled(!loupeEnabled)}
          className="text-[#9A7B4F] hover:text-[#18181D] hover:underline uppercase tracking-wider text-[11px] font-mono transition-colors"
        >
          {loupeEnabled ? "Loupe Active" : "Enable 10x Lens"}
        </button>
      </div>

      {/* Interactive Gemological Stage Container */}
      <div
        ref={containerRef}
        onMouseMove={handleMouseMove}
        onTouchMove={handleTouchMove}
        onMouseEnter={() => loupeEnabled && setIsActive(true)}
        onTouchStart={() => loupeEnabled && setIsActive(true)}
        onMouseLeave={handleMouseLeave}
        onTouchEnd={() => setIsActive(false)}
        className={`relative ${aspectRatio} w-full overflow-hidden bg-[#121216] border border-[#E8E4DC] cursor-crosshair group shadow-inner`}
      >
        {/* Full-bleed Specimen Photography: Fills 100% of container without padding */}
        <Image
          src={src}
          alt={alt}
          fill
          priority
          sizes="(max-width: 1024px) 100vw, 60vw"
          className="object-cover w-full h-full transition-transform duration-300 group-hover:scale-[1.01]"
        />

        {/* 10x Optical Triplet Magnifier Lens */}
        {isActive && loupeEnabled && (
          <div
            style={{
              width: `${LOUPE_SIZE}px`,
              height: `${LOUPE_SIZE}px`,
              left: `${pos.x - LOUPE_SIZE / 2}px`,
              top: `${pos.y - LOUPE_SIZE / 2}px`,
              backgroundImage: `url(${src})`,
              backgroundPosition: `${bgX}px ${bgY}px`,
              backgroundSize: `${bgWidth}px ${bgHeight}px`,
              backgroundRepeat: "no-repeat",
            }}
            className="pointer-events-none absolute rounded-full border-[3.5px] border-[#C5A880] shadow-[0_20px_50px_rgba(0,0,0,0.65)] z-30 ring-1 ring-black/80 overflow-hidden backdrop-blur-none"
          >
            {/* Optical Glass Lens Reflections & Vignette */}
            <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-black/30 pointer-events-none" />
            <div className="absolute inset-0 rounded-full shadow-[inset_0_0_25px_rgba(0,0,0,0.5)] pointer-events-none" />

            {/* Precision Laser Reticle / Crosshair */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-45">
              <div className="w-full h-[0.5px] bg-[#C5A880]" />
              <div className="h-full w-[0.5px] bg-[#C5A880] absolute" />
              <div className="w-10 h-10 rounded-full border border-[#C5A880] absolute" />
              <div className="w-2 h-2 rounded-full border border-[#C5A880]/70 absolute" />
            </div>

            {/* Swiss Triplet Loupe Engraving Badges */}
            <div className="absolute top-2.5 inset-x-0 text-center pointer-events-none">
              <span className="px-2 py-0.5 bg-black/85 text-[8.5px] font-mono tracking-widest text-[#E0CFA9] uppercase rounded-full border border-[#C5A880]/40 shadow-sm">
                {zoomFactor}x APLANATIC TRIPLET
              </span>
            </div>
            <div className="absolute bottom-2.5 inset-x-0 text-center pointer-events-none">
              <span className="px-2 py-0.5 bg-black/85 text-[7.5px] font-mono tracking-wider text-[#A29F96] uppercase rounded-full border border-white/10">
                SWISS OPTICAL RESOLUTION
              </span>
            </div>
          </div>
        )}

        {/* Hover Cue Pill */}
        {!isActive && loupeEnabled && (
          <div className="absolute bottom-3 right-3 pointer-events-none bg-black/75 backdrop-blur-md border border-[#C5A880]/40 px-3 py-1.5 text-[11px] font-sans text-[#E0CFA9] uppercase tracking-wider flex items-center gap-2 shadow-lg">
            <LoupeIcon className="w-3.5 h-3.5 text-[#C5A880]" />
            <span>Hover Specimen for 10x Loupe</span>
          </div>
        )}
      </div>
    </div>
  );
}
