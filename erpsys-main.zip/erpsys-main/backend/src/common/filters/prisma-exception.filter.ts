import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { Response } from 'express';

@Catch(Prisma.PrismaClientKnownRequestError, Prisma.PrismaClientValidationError)
export class PrismaExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(PrismaExceptionFilter.name);

  catch(
    exception: Prisma.PrismaClientKnownRequestError | Prisma.PrismaClientValidationError,
    host: ArgumentsHost,
  ) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();

    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let message = 'Internal database server error occurred.';
    let error = 'Database Error';

    if (exception instanceof Prisma.PrismaClientKnownRequestError) {
      switch (exception.code) {
        // P2002: Unique constraint failed
        case 'P2002': {
          status = HttpStatus.BAD_REQUEST;
          error = 'Bad Request';
          const target = exception.meta?.target;
          const fields = Array.isArray(target)
            ? target.join(', ')
            : typeof target === 'string'
            ? target
            : 'field';
          message = `A record with this ${fields} already exists in the system.`;
          break;
        }

        // P2003: Foreign key constraint failed (e.g. Deleting parent with active children)
        case 'P2003': {
          status = HttpStatus.BAD_REQUEST;
          error = 'Bad Request';
          const fieldName = (exception.meta?.field_name as string) || 'related items';
          message = `Cannot delete or modify this record because it is currently linked to other active records (${fieldName}).`;
          break;
        }

        // P2025: Record not found
        case 'P2025': {
          status = HttpStatus.NOT_FOUND;
          error = 'Not Found';
          message =
            (exception.meta?.cause as string) ||
            'The requested record was not found or has already been removed.';
          break;
        }

        // P2014: Required relation violation
        case 'P2014': {
          status = HttpStatus.BAD_REQUEST;
          error = 'Bad Request';
          message =
            'The change you are trying to make would violate the required relation between records.';
          break;
        }

        default: {
          this.logger.error(`Prisma error ${exception.code}: ${exception.message}`);
          message = `Database operation failed [Code: ${exception.code}].`;
          break;
        }
      }
    } else if (exception instanceof Prisma.PrismaClientValidationError) {
      status = HttpStatus.BAD_REQUEST;
      error = 'Bad Request';
      message = 'Invalid data provided for database operation.';
      this.logger.warn(`Prisma Validation Error: ${exception.message}`);
    }

    response.status(status).json({
      statusCode: status,
      message,
      error,
      timestamp: new Date().toISOString(),
    });
  }
}
