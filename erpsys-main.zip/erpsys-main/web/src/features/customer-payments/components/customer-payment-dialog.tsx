import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { X, Loader2, Coins } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { User } from "@hkr/types";
import { SaleItem } from "@/features/pos/types";
import { customerPaymentFormSchema, CustomerPaymentFormSchema } from "../schema";
import { useCreateCustomerPaymentMutation } from "../hooks/use-customer-payments";
import { usePaymentMethodsQuery } from "@/features/payment-methods/hooks/use-payment-methods";
import { useSalesQuery } from "@/features/pos";
import { useBranchesQuery } from "@/features/customers/hooks/use-customers";
import { useCurrency } from "@/hooks/use-currency";

interface CustomerPaymentDialogProps {
  isOpen: boolean;
  onClose: () => void;
  sale: SaleItem | null;
  customer?: any | null; // Customer item
  currentUser: User;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

export function CustomerPaymentDialog({
  isOpen,
  onClose,
  sale,
  customer,
  currentUser,
  onSuccess,
  onError,
}: CustomerPaymentDialogProps) {
  const { symbol, format } = useCurrency(currentUser?.businessId);
  const createMutation = useCreateCustomerPaymentMutation();

  const [selectedSaleId, setSelectedSaleId] = useState<string>("direct");
  const [selectedBranchId, setSelectedBranchId] = useState<string>("");
  const [formError, setFormError] = useState<string | null>(null);

  const isWalkIn = Boolean(
    (customer && (customer.isDefault || customer.name?.toLowerCase() === "walk-in customer")) ||
    (sale && ((sale.customer as any)?.isDefault || sale.customer?.name?.toLowerCase() === "walk-in customer"))
  );

  // Determine branchId to query payment methods
  const queryBranchId = sale
    ? sale.branch.id
    : (selectedBranchId || undefined);

  // Query payment methods for this branch
  const { data: paymentMethods = [], isLoading: methodsLoading } = usePaymentMethodsQuery(
    currentUser?.businessId || "",
    queryBranchId,
    true // only active
  );

  // Query customer's sales to allocate payment if customer prop is provided
  const { data: salesResponse, isLoading: salesLoading } = useSalesQuery(
    currentUser?.businessId || "",
    { customerId: customer?.id || "", status: "FINAL", limit: 100 }
  );

  // Filter for unpaid or partially paid sales
  const unpaidSales = React.useMemo(() => {
    const list = salesResponse?.data || [];
    return list.filter((s: any) => s.paymentStatus !== "PAID");
  }, [salesResponse]);

  // Query branches
  const { data: branches = [], isLoading: branchesLoading } = useBranchesQuery(
    currentUser?.businessId || "",
    currentUser?.id
  );

  // Prefill default branch
  useEffect(() => {
    if (branches.length > 0 && !selectedBranchId) {
      setSelectedBranchId(branches[0].id);
    }
  }, [branches, selectedBranchId]);

  // Calculate remaining due
  const remainingDue = React.useMemo(() => {
    if (sale) {
      return Math.max(0, sale.grandTotal - sale.amountPaid);
    }
    if (customer) {
      if (selectedSaleId === "direct") {
        // Calculate dynamic outstanding due from sales list + opening balance to be in sync with UI
        const opening = customer.openingBalance || 0;
        const totalSales = salesResponse?.data?.reduce((sum: number, s: any) => sum + s.grandTotal, 0) || 0;
        const totalPaid = salesResponse?.data?.reduce((sum: number, s: any) => sum + s.amountPaid, 0) || 0;
        return Math.max(0, (totalSales + opening) - totalPaid);
      }
      const matched = unpaidSales.find((s: any) => s.id === selectedSaleId);
      return matched ? Math.max(0, matched.grandTotal - matched.amountPaid) : 0;
    }
    return 0;
  }, [sale, customer, selectedSaleId, unpaidSales, salesResponse]);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<CustomerPaymentFormSchema>({
    resolver: zodResolver(customerPaymentFormSchema),
    defaultValues: {
      amount: 0,
      paymentDate: new Date().toISOString().split("T")[0],
      paymentMethodId: "",
      transactionNo: "",
      notes: "",
    },
  });

  const watchAmount = watch("amount") || 0;

  // Set default values
  useEffect(() => {
    if (isOpen) {
      setFormError(null);
      reset({
        amount: Number(remainingDue.toFixed(2)),
        paymentDate: new Date().toISOString().split("T")[0],
        paymentMethodId: paymentMethods[0]?.id || "",
        transactionNo: "",
        notes: "",
      });
      if (customer) {
        setSelectedSaleId("direct");
      }
    }
  }, [sale, customer, isOpen, reset, paymentMethods, remainingDue]);

  // Update paymentMethodId once payment methods load
  useEffect(() => {
    if (paymentMethods.length > 0) {
      setValue("paymentMethodId", paymentMethods[0].id);
    }
  }, [paymentMethods, setValue]);

  if (!isOpen || (!sale && !customer)) return null;

  const onSubmit = async (data: CustomerPaymentFormSchema) => {
    if (!currentUser.businessId) return;

    const actualCustomerId = sale ? sale.customer.id : customer!.id;
    const actualBranchId = sale ? sale.branch.id : selectedBranchId;
    const actualSaleId = sale ? sale.id : (selectedSaleId === "direct" ? undefined : selectedSaleId);

    if (!actualBranchId) {
      onError("Please select a branch.");
      return;
    }

    if (isWalkIn && data.amount > remainingDue) {
      const msg = `Advance payments cannot be recorded for Walk-in Customer. Maximum allowable payment is ${format(remainingDue)}.`;
      setFormError(msg);
      onError(msg);
      return;
    }

    setFormError(null);
    const payload = {
      amount: data.amount,
      paymentDate: new Date(data.paymentDate).toISOString(),
      saleId: actualSaleId,
      customerId: actualCustomerId,
      paymentMethodId: data.paymentMethodId,
      branchId: actualBranchId,
      businessId: currentUser.businessId,
      transactionNo: data.transactionNo?.trim() || undefined,
      notes: data.notes?.trim() || undefined,
      createdById: currentUser.id,
    };

    try {
      await createMutation.mutateAsync(payload);
      onSuccess("Payment recorded successfully!");
      onClose();
    } catch (err: any) {
      onError(err.message || "Failed to record payment.");
    }
  };

  const isLoading = createMutation.isPending;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-card border border-border rounded-sm shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between border-b border-border p-5 bg-background/40">
          <h2 className="text-lg font-bold text-foreground flex items-center gap-2">
            <Coins className="h-5 w-5 text-primary" /> Record Customer Payment
          </h2>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {formError && (
          <div className="mx-5 mt-3 p-3 bg-destructive/15 text-destructive border border-destructive/30 rounded text-xs flex items-center gap-2 animate-in fade-in duration-150">
            <span>{formError}</span>
          </div>
        )}

        <form onSubmit={handleSubmit(onSubmit)} className="p-5 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Sale Details Summary */}
          {sale ? (
            <div className="p-3 bg-secondary/50 rounded-sm border border-border/40 text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Invoice:</span>
                <span className="font-mono font-bold">{sale.invoiceNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Customer:</span>
                <span className="font-semibold">{sale.customer?.name}</span>
              </div>
              <div className="flex justify-between border-t border-border/30 pt-1.5 mt-1.5">
                <span className="text-muted-foreground">Grand Total:</span>
                <span className="font-bold">{format(sale.grandTotal)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Amount Paid:</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">{format(sale.amountPaid)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Remaining Due:</span>
                <span className="font-extrabold text-rose-600 dark:text-rose-400">{format(remainingDue)}</span>
              </div>
            </div>
          ) : (
            <div className="p-3 bg-secondary/50 rounded-sm border border-border/40 text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Customer:</span>
                <span className="font-semibold">{customer?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Phone Number:</span>
                <span className="font-semibold">{customer?.phone || "N/A"}</span>
              </div>
              <div className="flex justify-between border-t border-border/30 pt-1.5 mt-1.5">
                <span className="text-muted-foreground">Outstanding Balance Due:</span>
                <span className="font-bold text-rose-600 dark:text-rose-400">{format(remainingDue)}</span>
              </div>
            </div>
          )}

          {/* Allocation Selector for Direct Customer Payment */}
          {customer && (
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">Allocation / Destination Invoice</label>
              {salesLoading ? (
                <div className="h-10 flex items-center justify-center border border-input rounded-sm text-xs text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin mr-2" /> Loading customer invoices...
                </div>
              ) : (
                <select
                  value={selectedSaleId}
                  onChange={(e) => setSelectedSaleId(e.target.value)}
                  className="w-full h-10 px-3 py-2 bg-background border border-input text-foreground rounded-sm text-sm focus:outline-none focus:border-primary placeholder:text-muted-foreground/60 transition-all focus:ring-1 focus:ring-primary"
                >
                  <option value="direct">Direct Payment (On-Account / Balance)</option>
                  {unpaidSales.map((s: any) => {
                    const due = Math.max(0, s.grandTotal - s.amountPaid);
                    return (
                      <option key={s.id} value={s.id}>
                        {s.invoiceNumber} (Due: {format(due)})
                      </option>
                    );
                  })}
                </select>
              )}
            </div>
          )}

          {/* Branch Selector for Direct Payment */}
          {customer && selectedSaleId === "direct" && (
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">Branch *</label>
              {branchesLoading ? (
                <div className="h-10 flex items-center justify-center border border-input rounded-sm text-xs text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin mr-2" /> Loading branches...
                </div>
              ) : (
                <select
                  value={selectedBranchId}
                  onChange={(e) => setSelectedBranchId(e.target.value)}
                  className="w-full h-10 px-3 py-2 bg-background border border-input text-foreground rounded-sm text-sm focus:outline-none focus:border-primary placeholder:text-muted-foreground/60 transition-all focus:ring-1 focus:ring-primary"
                >
                  {branches.map((b: any) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </select>
              )}
            </div>
          )}

          {/* Amount field */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">Payment Amount ({symbol}) *</label>
            <Input
              type="number"
              step="any"
              placeholder="0.00"
              {...register("amount", { valueAsNumber: true })}
            />
            {errors.amount && (
              <span className="text-xs text-rose-500">{errors.amount.message}</span>
            )}

            {/* Advance Balance Information or Walk-in Warning */}
            {watchAmount > remainingDue && (
              isWalkIn ? (
                <div className="p-2.5 rounded bg-destructive/15 text-destructive border border-destructive/30 text-[11px] font-medium flex items-center gap-2 animate-in fade-in duration-150">
                  <span>⚠️ Walk-in Customer cannot maintain advance balance. Maximum payment allowed is <strong>{format(remainingDue)}</strong>.</span>
                </div>
              ) : (
                <div className="p-2.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/25 text-[11px] font-medium flex items-center gap-2 animate-in fade-in duration-150">
                  <span>
                    💡 {remainingDue > 0 ? (
                      <>
                        <strong>{format(remainingDue)}</strong> will clear unpaid dues, and the remaining <strong>{format(watchAmount - remainingDue)}</strong> will be credited to <strong>{customer?.name}</strong>'s Customer Advance Balance.
                      </>
                    ) : (
                      <>
                        The full amount of <strong>{format(watchAmount)}</strong> will be credited to <strong>{customer?.name}</strong>'s Customer Advance Balance.
                      </>
                    )}
                  </span>
                </div>
              )
            )}
          </div>

          {/* Payment Date */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">Payment Date *</label>
            <Input
              type="date"
              {...register("paymentDate")}
            />
            {errors.paymentDate && (
              <span className="text-xs text-rose-500">{errors.paymentDate.message}</span>
            )}
          </div>

          {/* Payment Method */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">Payment Method *</label>
            {methodsLoading ? (
              <div className="flex items-center gap-2 text-xs text-muted-foreground h-10 px-3 border border-input rounded-sm">
                <Loader2 className="h-4 w-4 animate-spin" /> Loading payment methods...
              </div>
            ) : (
              <select
                {...register("paymentMethodId")}
                className="w-full h-10 px-3 py-2 bg-background border border-input text-foreground rounded-sm text-sm focus:outline-none focus:border-primary placeholder:text-muted-foreground/60 transition-all focus:ring-1 focus:ring-primary"
              >
                {paymentMethods.map((pm) => (
                  <option key={pm.id} value={pm.id}>
                    {pm.name}
                  </option>
                ))}
              </select>
            )}
            {errors.paymentMethodId && (
              <span className="text-xs text-rose-500">{errors.paymentMethodId.message}</span>
            )}
          </div>

          {/* Transaction No */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">Transaction / Reference No</label>
            <Input
              placeholder="e.g. UPI Ref, Card Txn Ref"
              {...register("transactionNo")}
            />
          </div>

          {/* Notes */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">Notes</label>
            <textarea
              placeholder="Optional payment notes..."
              {...register("notes")}
              className="w-full h-16 px-3 py-2 bg-background border border-input text-foreground rounded-sm text-sm focus:outline-none focus:border-primary placeholder:text-muted-foreground/60 transition-all focus:ring-1 focus:ring-primary"
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 border-t border-border pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Recording...
                </>
              ) : (
                "Record Payment"
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
