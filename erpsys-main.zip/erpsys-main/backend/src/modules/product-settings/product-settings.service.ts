import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { UpdateProductSettingsDto } from './dto/product-settings.dto';
import { randomUUID } from 'crypto';

@Injectable()
export class ProductSettingsService {
  constructor(private readonly prisma: PrismaService) {}

  async getSettings(businessId: string) {
    if ((this.prisma as any).productSettings) {
      let settings = await (this.prisma as any).productSettings.findUnique({
        where: { businessId },
      });

      if (!settings) {
        settings = await (this.prisma as any).productSettings.create({
          data: {
            businessId,
            defaultProfitMargin: 20.0,
            enableAutoSku: true,
            skuPrefix: 'SKU-',
            defaultBarcodeType: 'CODE128',
            enableProductExpiry: true,
            expiryAlertDays: 30,
            onProductExpiry: 'ALERT_ONLY',
            stopSellingBeforeExpiryDays: 0,
            enableBrands: true,
            enableCategories: true,
            enableSubCategories: true,
            enablePriceTax: true,
            enableWarranty: true,
          },
        });
      }
      return settings;
    }

    // Direct database query fallback
    const rows: any[] = await this.prisma.$queryRawUnsafe(
      `SELECT * FROM "ProductSettings" WHERE "businessId" = $1 LIMIT 1`,
      businessId,
    );

    if (rows && rows.length > 0) {
      return rows[0];
    }

    const newId = randomUUID();
    await this.prisma.$executeRawUnsafe(
      `INSERT INTO "ProductSettings" 
       ("id", "businessId", "defaultProfitMargin", "enableAutoSku", "skuPrefix", "defaultBarcodeType", "enableProductExpiry", "expiryAlertDays", "onProductExpiry", "stopSellingBeforeExpiryDays", "enableBrands", "enableCategories", "enableSubCategories", "enablePriceTax", "enableWarranty", "createdAt", "updatedAt") 
       VALUES ($1, $2, 20.0, true, 'SKU-', 'CODE128', true, 30, 'ALERT_ONLY', 0, true, true, true, true, true, NOW(), NOW())`,
      newId,
      businessId,
    );

    const created: any[] = await this.prisma.$queryRawUnsafe(
      `SELECT * FROM "ProductSettings" WHERE "businessId" = $1 LIMIT 1`,
      businessId,
    );
    return created[0];
  }

  async updateSettings(businessId: string, dto: UpdateProductSettingsDto) {
    const dataPayload: any = {};
    if (dto.defaultProfitMargin !== undefined) dataPayload.defaultProfitMargin = Number(dto.defaultProfitMargin);
    if (dto.enableAutoSku !== undefined) dataPayload.enableAutoSku = dto.enableAutoSku;
    if (dto.skuPrefix !== undefined) dataPayload.skuPrefix = dto.skuPrefix;
    if (dto.defaultBarcodeType !== undefined) dataPayload.defaultBarcodeType = dto.defaultBarcodeType;
    if (dto.enableProductExpiry !== undefined) dataPayload.enableProductExpiry = dto.enableProductExpiry;
    if (dto.expiryAlertDays !== undefined) dataPayload.expiryAlertDays = Number(dto.expiryAlertDays);
    if (dto.onProductExpiry !== undefined) dataPayload.onProductExpiry = dto.onProductExpiry;
    if (dto.stopSellingBeforeExpiryDays !== undefined) dataPayload.stopSellingBeforeExpiryDays = Number(dto.stopSellingBeforeExpiryDays);

    if (dto.enableBrands !== undefined) dataPayload.enableBrands = dto.enableBrands;
    if (dto.enableCategories !== undefined) dataPayload.enableCategories = dto.enableCategories;
    if (dto.enableSubCategories !== undefined) dataPayload.enableSubCategories = dto.enableSubCategories;
    if (dto.enablePriceTax !== undefined) dataPayload.enablePriceTax = dto.enablePriceTax;
    if (dto.enableWarranty !== undefined) dataPayload.enableWarranty = dto.enableWarranty;

    if (dto.defaultUnitId !== undefined) dataPayload.defaultUnitId = dto.defaultUnitId;
    if (dto.defaultTaxId !== undefined) dataPayload.defaultTaxId = dto.defaultTaxId;

    if ((this.prisma as any).productSettings) {
      return (this.prisma as any).productSettings.upsert({
        where: { businessId },
        create: {
          businessId,
          ...dataPayload,
        },
        update: dataPayload,
      });
    }

    // Direct raw SQL upsert
    const existing: any[] = await this.prisma.$queryRawUnsafe(
      `SELECT "id" FROM "ProductSettings" WHERE "businessId" = $1 LIMIT 1`,
      businessId,
    );

    if (existing && existing.length > 0) {
      const keys = Object.keys(dataPayload);
      if (keys.length > 0) {
        const setClauses = keys.map((k, i) => `"${k}" = $${i + 2}`).join(', ');
        const values = keys.map((k) => dataPayload[k]);
        await this.prisma.$executeRawUnsafe(
          `UPDATE "ProductSettings" SET ${setClauses}, "updatedAt" = NOW() WHERE "businessId" = $1`,
          businessId,
          ...values,
        );
      }
    } else {
      const newId = randomUUID();
      const keys = Object.keys(dataPayload);
      const cols = ['"id"', '"businessId"', ...keys.map((k) => `"${k}"`), '"createdAt"', '"updatedAt"'].join(', ');
      const placeholders = ['$1', '$2', ...keys.map((_, i) => `$${i + 3}`), 'NOW()', 'NOW()'].join(', ');
      const values = keys.map((k) => dataPayload[k]);
      await this.prisma.$executeRawUnsafe(
        `INSERT INTO "ProductSettings" (${cols}) VALUES (${placeholders})`,
        newId,
        businessId,
        ...values,
      );
    }

    const updated: any[] = await this.prisma.$queryRawUnsafe(
      `SELECT * FROM "ProductSettings" WHERE "businessId" = $1 LIMIT 1`,
      businessId,
    );
    return updated[0];
  }
}
