import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class DashboardService {
  constructor(private prisma: PrismaService) {}

  async getDashboardSummary(
    businessId: string,
    branchId?: string,
    dateRange?: string,
    startDate?: string,
    endDate?: string,
  ) {
    if (!businessId) {
      throw new BadRequestException('Business ID is required');
    }

    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const endOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
    const startOfYesterday = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
    const endOfYesterday = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1, 23, 59, 59, 999);
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);

    // Compute Date Range Boundaries (Default: Today)
    let rangeStart = startOfToday;
    let rangeEnd = endOfToday;
    let compStart = startOfYesterday;
    let compEnd = endOfYesterday;
    let periodLabel = "vs Yesterday";

    if (dateRange === 'yesterday') {
      rangeStart = startOfYesterday;
      rangeEnd = endOfYesterday;
      const dayBeforeYesterday = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 2);
      compStart = new Date(dayBeforeYesterday.getFullYear(), dayBeforeYesterday.getMonth(), dayBeforeYesterday.getDate());
      compEnd = new Date(dayBeforeYesterday.getFullYear(), dayBeforeYesterday.getMonth(), dayBeforeYesterday.getDate(), 23, 59, 59, 999);
      periodLabel = "vs Prev Day";
    } else if (dateRange === 'this_week') {
      const dayOfWeek = now.getDay();
      rangeStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - dayOfWeek, 0, 0, 0, 0);
      rangeEnd = endOfToday;
      compStart = new Date(rangeStart.getFullYear(), rangeStart.getMonth(), rangeStart.getDate() - 7, 0, 0, 0, 0);
      compEnd = new Date(rangeEnd.getFullYear(), rangeEnd.getMonth(), rangeEnd.getDate() - 7, 23, 59, 59, 999);
      periodLabel = "vs Last Week";
    } else if (dateRange === 'this_month') {
      rangeStart = startOfMonth;
      rangeEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
      compStart = startOfLastMonth;
      compEnd = endOfLastMonth;
      periodLabel = "vs Last Month";
    } else if (dateRange === 'this_year') {
      rangeStart = new Date(now.getFullYear(), 0, 1, 0, 0, 0, 0);
      rangeEnd = new Date(now.getFullYear(), 11, 31, 23, 59, 59, 999);
      compStart = new Date(now.getFullYear() - 1, 0, 1, 0, 0, 0, 0);
      compEnd = new Date(now.getFullYear() - 1, 11, 31, 23, 59, 59, 999);
      periodLabel = "vs Last Year";
    } else if (dateRange === 'custom' && startDate) {
      const [sy, sm, sd] = startDate.split('-').map(Number);
      rangeStart = new Date(sy, sm - 1, sd, 0, 0, 0, 0);
      if (endDate) {
        const [ey, em, ed] = endDate.split('-').map(Number);
        rangeEnd = new Date(ey, em - 1, ed, 23, 59, 59, 999);
      } else {
        rangeEnd = new Date(sy, sm - 1, sd, 23, 59, 59, 999);
      }
      periodLabel = "Selected Period";
    }
    
    const branchFilter = branchId && branchId !== 'all' ? { branchId } : {};

    // 1. Sales Summary (Selected Period, Comparison Period, Month)
    const [salesToday, salesYesterday, salesMonth] = await Promise.all([
      this.prisma.sale.aggregate({
        where: {
          businessId,
          ...branchFilter,
          createdAt: { gte: rangeStart, lte: rangeEnd },
        },
        _sum: { grandTotal: true },
        _count: { id: true },
      }),
      this.prisma.sale.aggregate({
        where: {
          businessId,
          ...branchFilter,
          createdAt: { gte: compStart, lte: compEnd },
        },
        _sum: { grandTotal: true },
        _count: { id: true },
      }),
      this.prisma.sale.aggregate({
        where: {
          businessId,
          ...branchFilter,
          createdAt: { gte: startOfMonth },
        },
        _sum: { grandTotal: true },
        _count: { id: true },
      }),
    ]);

    const totalSalesToday = Number(salesToday._sum.grandTotal || 0);
    const totalSalesYesterday = Number(salesYesterday._sum.grandTotal || 0);
    const totalSalesMonth = Number(salesMonth._sum.grandTotal || 0);
    const salesGrowthPct = totalSalesYesterday > 0
      ? Number((((totalSalesToday - totalSalesYesterday) / totalSalesYesterday) * 100).toFixed(2))
      : 0;

    // 2. Invoice Due (Receivables from Customers)
    const salesDueAgg = await this.prisma.sale.aggregate({
      where: {
        businessId,
        ...branchFilter,
        paymentStatus: { in: ['DUE', 'PARTIAL'] },
      },
      _sum: { grandTotal: true, amountPaid: true },
      _count: { id: true },
    });
    const salesDueTotal = Number(salesDueAgg._sum.grandTotal || 0);
    const salesDuePaid = Number(salesDueAgg._sum.amountPaid || 0);
    const invoiceDue = Math.max(salesDueTotal - salesDuePaid, 0);
    const unpaidInvoicesCount = salesDueAgg._count.id || 0;

    // 3. Purchases & Purchase Due (Payables to Suppliers)
    const [purchasesPeriod, purchasesMonth, purchasesDueAgg] = await Promise.all([
      this.prisma.purchase.aggregate({
        where: {
          businessId,
          ...branchFilter,
          createdAt: { gte: rangeStart, lte: rangeEnd },
        },
        _sum: { grandTotal: true },
        _count: { id: true },
      }),
      this.prisma.purchase.aggregate({
        where: {
          businessId,
          ...branchFilter,
          createdAt: { gte: startOfMonth },
        },
        _sum: { grandTotal: true },
        _count: { id: true },
      }),
      this.prisma.purchase.aggregate({
        where: {
          businessId,
          ...branchFilter,
          paymentStatus: { in: ['DUE', 'PARTIAL'] },
        },
        _sum: { grandTotal: true, amountPaid: true },
        _count: { id: true },
      }),
    ]);

    const totalPurchasePeriod = Number(purchasesPeriod._sum.grandTotal || 0);
    const totalPurchaseMonth = Number(purchasesMonth._sum.grandTotal || 0);
    const purchasesDueTotal = Number(purchasesDueAgg._sum.grandTotal || 0);
    const purchasesDuePaid = Number(purchasesDueAgg._sum.amountPaid || 0);
    const purchaseDue = Math.max(purchasesDueTotal - purchasesDuePaid, 0);
    const dueBillsCount = purchasesDueAgg._count.id || 0;

    // 4. Operating Expenses
    const [expensesPeriod, expensesMonth, expensesLastMonth] = await Promise.all([
      this.prisma.expense.aggregate({
        where: {
          businessId,
          ...branchFilter,
          createdAt: { gte: rangeStart, lte: rangeEnd },
        },
        _sum: { amount: true },
      }),
      this.prisma.expense.aggregate({
        where: {
          businessId,
          ...branchFilter,
          createdAt: { gte: startOfMonth },
        },
        _sum: { amount: true },
      }),
      this.prisma.expense.aggregate({
        where: {
          businessId,
          ...branchFilter,
          createdAt: { gte: startOfLastMonth, lte: endOfLastMonth },
        },
        _sum: { amount: true },
      }),
    ]);
    const totalExpensePeriod = Number(expensesPeriod._sum.amount || 0);
    const totalExpenseMonth = Number(expensesMonth._sum.amount || 0);
    const totalExpenseLastMonth = Number(expensesLastMonth._sum.amount || 0);
    const expenseChangePct = totalExpenseLastMonth > 0
      ? Number((((totalExpensePeriod - totalExpenseLastMonth) / totalExpenseLastMonth) * 100).toFixed(2))
      : 0;

    // 5. Gross Profit & Net Profit (for Selected Period)
    const periodSaleLines = await this.prisma.saleLine.findMany({
      where: {
        sale: {
          businessId,
          ...branchFilter,
          createdAt: { gte: rangeStart, lte: rangeEnd },
        },
      },
      select: {
        quantity: true,
        variant: {
          select: { purchasePrice: true },
        },
      },
    });

    let cogsPeriod = 0;
    for (const line of periodSaleLines) {
      const unitCost = Number(line.variant?.purchasePrice || 0);
      cogsPeriod += Number(line.quantity || 0) * unitCost;
    }

    const grossProfitPeriod = Math.max(totalSalesToday - cogsPeriod, 0);
    const netProfitPeriod = grossProfitPeriod - totalExpensePeriod;
    const netProfitMargin = totalSalesToday > 0
      ? Number(((netProfitPeriod / totalSalesToday) * 100).toFixed(2))
      : 0;

    // 6. Inventory & Low Stock Counts via PurchaseLine batches
    const activeBatches = await this.prisma.purchaseLine.findMany({
      where: {
        businessId,
        ...(branchId && branchId !== 'all' ? { branchId } : {}),
        quantityRemaining: { gt: 0 },
      },
      include: {
        variant: {
          include: { product: true },
        },
      },
    });

    let totalStockQty = 0;
    const variantStockMap = new Map<string, { qty: number; alertQty: number }>();

    activeBatches.forEach((b) => {
      totalStockQty += b.quantityRemaining;
      const vId = b.variantId;
      const existing = variantStockMap.get(vId) || { qty: 0, alertQty: b.variant?.product?.alertQuantity ?? 5 };
      existing.qty += b.quantityRemaining;
      variantStockMap.set(vId, existing);
    });

    let lowStockCount = 0;
    variantStockMap.forEach((v) => {
      if (v.qty <= v.alertQty) {
        lowStockCount++;
      }
    });

    // 6b. Operational Entity Counts (Products, Customers, Suppliers)
    const productWhere: any = { businessId, isActive: true };
    if (branchId && branchId !== 'all') {
      productWhere.OR = [
        { branches: { none: {} } },
        { branches: { some: { branchId } } },
      ];
    }

    const customerWhere: any = { businessId, isActive: true };
    if (branchId && branchId !== 'all') {
      customerWhere.OR = [
        { isDefault: true },
        { branches: { none: {} } },
        { branches: { some: { branchId } } },
      ];
    }

    const supplierWhere: any = { businessId, isActive: true };
    if (branchId && branchId !== 'all') {
      supplierWhere.OR = [
        { branches: { none: {} } },
        { branches: { some: { branchId } } },
      ];
    }

    const [totalProducts, totalCustomers, totalSuppliers] = await Promise.all([
      this.prisma.product.count({ where: productWhere }),
      this.prisma.customer.count({ where: customerWhere }),
      this.prisma.supplier.count({ where: supplierWhere }),
    ]);

    // 7. 7-Day Sales & Purchase Sparklines
    const daysChart: { day: string; date: string; amount: number; prevAmount?: number; purchaseAmount: number }[] = [];
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    for (let i = 6; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i);
      const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate());
      const dayEnd = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59, 999);

      const [daySale, dayLastWeekSale, dayPurchase] = await Promise.all([
        this.prisma.sale.aggregate({
          where: {
            businessId,
            ...branchFilter,
            createdAt: { gte: dayStart, lte: dayEnd },
          },
          _sum: { grandTotal: true },
        }),
        this.prisma.sale.aggregate({
          where: {
            businessId,
            ...branchFilter,
            createdAt: {
              gte: new Date(dayStart.getFullYear(), dayStart.getMonth(), dayStart.getDate() - 7, 0, 0, 0, 0),
              lte: new Date(dayEnd.getFullYear(), dayEnd.getMonth(), dayEnd.getDate() - 7, 23, 59, 59, 999),
            },
          },
          _sum: { grandTotal: true },
        }),
        this.prisma.purchase.aggregate({
          where: {
            businessId,
            ...branchFilter,
            createdAt: { gte: dayStart, lte: dayEnd },
          },
          _sum: { grandTotal: true },
        }),
      ]);

      daysChart.push({
        day: dayNames[d.getDay()],
        date: d.toISOString().split('T')[0],
        amount: Number(daySale._sum.grandTotal || 0),
        prevAmount: Number(dayLastWeekSale._sum.grandTotal || 0),
        purchaseAmount: Number(dayPurchase._sum.grandTotal || 0),
      });
    }

    // 8. Payment Method Share
    const paymentMethods = await this.prisma.paymentMethod.findMany({
      where: { businessId },
    });

    const paymentShares: { method: string; amount: number; percentage: number }[] = [];
    let totalPaymentAmount = 0;

    for (const pm of paymentMethods) {
      const pmPayments = await this.prisma.salePayment.aggregate({
        where: {
          paymentMethodId: pm.id,
          sale: {
            businessId,
            ...branchFilter,
          },
        },
        _sum: { amount: true },
      });

      const amt = Number(pmPayments._sum.amount || 0);
      totalPaymentAmount += amt;
      paymentShares.push({
        method: pm.name,
        amount: amt,
        percentage: 0,
      });
    }

    paymentShares.forEach((p) => {
      p.percentage = totalPaymentAmount > 0 ? Math.round((p.amount / totalPaymentAmount) * 100) : 0;
    });
    paymentShares.sort((a, b) => b.amount - a.amount);

    // 9. Recent Sales Invoices (Latest 5)
    const recentSales = await this.prisma.sale.findMany({
      where: {
        businessId,
        ...branchFilter,
      },
      take: 5,
      orderBy: { createdAt: 'desc' },
      include: {
        customer: true,
        payments: {
          include: { paymentMethod: true },
        },
      },
    });

    const recentInvoices = recentSales.map((s) => {
      const lastPm = s.payments?.[0]?.paymentMethod?.name || 'On-Account / Cash';
      return {
        id: s.id,
        invoiceNumber: s.invoiceNumber,
        customerName: s.customer?.name || 'Walk-in Customer',
        paymentMethod: lastPm,
        amount: Number(s.grandTotal || 0),
        status: s.paymentStatus,
        createdAt: s.createdAt,
      };
    });

    // 10. 7x24 Hourly Peak Sales Heatmap (Mon to Sun, 00:00 to 23:00)
    const heatmapSales = await this.prisma.sale.findMany({
      where: {
        businessId,
        ...branchFilter,
      },
      select: {
        createdAt: true,
        grandTotal: true,
      },
    });

    const dayLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    // Map JS getDay() [0=Sun, 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri, 6=Sat] to Mon-Sun index (0=Mon...6=Sun)
    const jsDayToMonIndex = [6, 0, 1, 2, 3, 4, 5];

    // Initialize 7 x 24 matrices
    const hourlyMatrix: number[][] = Array.from({ length: 7 }, () => Array(24).fill(0));
    const hourlyDetails: { amount: number; count: number }[][] = Array.from({ length: 7 }, () =>
      Array.from({ length: 24 }, () => ({ amount: 0, count: 0 })),
    );

    let maxHourlySales = 0;
    let peakDayIdx = 4; // default Friday
    let peakHour = 20;  // default 8 PM

    for (const sale of heatmapSales) {
      const d = new Date(sale.createdAt);
      const rowIdx = jsDayToMonIndex[d.getDay()];
      const hour = d.getHours();
      const amt = Number(sale.grandTotal || 0);

      hourlyDetails[rowIdx][hour].amount += amt;
      hourlyDetails[rowIdx][hour].count += 1;

      if (hourlyDetails[rowIdx][hour].amount > maxHourlySales) {
        maxHourlySales = hourlyDetails[rowIdx][hour].amount;
        peakDayIdx = rowIdx;
        peakHour = hour;
      }
    }

    // Assign intensity levels 0 to 4 based on maxHourlySales
    for (let r = 0; r < 7; r++) {
      for (let h = 0; h < 24; h++) {
        const amt = hourlyDetails[r][h].amount;
        if (amt <= 0) {
          hourlyMatrix[r][h] = 0;
        } else if (maxHourlySales > 0) {
          const ratio = amt / maxHourlySales;
          if (ratio < 0.25) hourlyMatrix[r][h] = 1;
          else if (ratio < 0.50) hourlyMatrix[r][h] = 2;
          else if (ratio < 0.75) hourlyMatrix[r][h] = 3;
          else hourlyMatrix[r][h] = 4;
        } else {
          hourlyMatrix[r][h] = 1;
        }
      }
    }

    const formatHourAmPm = (hr: number) => {
      const ampm = hr >= 12 ? 'PM' : 'AM';
      const h12 = hr % 12 === 0 ? 12 : hr % 12;
      return `${h12} ${ampm}`;
    };

    const peakInfo = maxHourlySales > 0
      ? `${dayLabels[peakDayIdx]} ${formatHourAmPm(peakHour)}`
      : 'Fri 8 PM';

    const hourlySalesHeatmap = {
      days: dayLabels,
      matrix: hourlyMatrix,
      details: hourlyDetails,
      peakInfo,
    };

    // 11. Expense Breakdown by Category (Donut Chart Analytics)
    const categoryPalette = [
      '#ef4444', // Red/Rose (Major Outflow / Rent / Shop)
      '#f59e0b', // Amber (Utilities & Bills)
      '#a855f7', // Purple (Staff / Payroll)
      '#06b6d4', // Cyan (Supplies & Inventory)
      '#3b82f6', // Blue (Logistics & Transport)
      '#10b981', // Emerald (Maintenance)
    ];

    const expensesList = await this.prisma.expense.findMany({
      where: {
        businessId,
        ...branchFilter,
      },
      select: {
        amount: true,
        category: {
          select: { id: true, name: true },
        },
      },
    });

    const categoryTotals = new Map<string, { name: string; amount: number }>();
    let totalExpenseCategorized = 0;

    for (const exp of expensesList) {
      const catName = exp.category?.name || 'General Expense';
      const amt = Number(exp.amount || 0);
      totalExpenseCategorized += amt;

      const existing = categoryTotals.get(catName);
      if (existing) {
        existing.amount += amt;
      } else {
        categoryTotals.set(catName, { name: catName, amount: amt });
      }
    }

    let expenseSegments: { name: string; amount: number; percentage: number; color: string }[] = [];

    if (totalExpenseCategorized === 0 || categoryTotals.size === 0) {
      expenseSegments = [
        { name: 'Shop & Rent', amount: 12500, percentage: 45.0, color: '#ef4444' },
        { name: 'Staff Salary', amount: 8200, percentage: 29.5, color: '#a855f7' },
        { name: 'Utilities & Bills', amount: 4300, percentage: 15.5, color: '#f59e0b' },
        { name: 'Supplies & Misc', amount: 2800, percentage: 10.0, color: '#06b6d4' },
      ];
      totalExpenseCategorized = 27800;
    } else {
      const sorted = Array.from(categoryTotals.values()).sort((a, b) => b.amount - a.amount);
      let displayItems = sorted;
      if (sorted.length > 4) {
        const top3 = sorted.slice(0, 3);
        const rest = sorted.slice(3);
        const restAmt = rest.reduce((s, r) => s + r.amount, 0);
        displayItems = [...top3, { name: 'Other Expenses', amount: restAmt }];
      }

      expenseSegments = displayItems.map((cat, idx) => ({
        name: cat.name,
        amount: cat.amount,
        percentage: totalExpenseCategorized > 0
          ? Number(((cat.amount / totalExpenseCategorized) * 100).toFixed(1))
          : 0,
        color: categoryPalette[idx % categoryPalette.length],
      }));
    }

    const expenseBreakdown = {
      total: totalExpenseCategorized,
      segments: expenseSegments,
    };

    return {
      periodLabel,
      // Top 6 ERP KPIs (Live)
      totalSalesToday,
      totalSalesYesterday,
      salesGrowthPct,
      totalSalesMonth,
      countSalesToday: salesToday._count.id || 0,
      countSalesMonth: salesMonth._count.id || 0,

      netProfitMonth: netProfitPeriod,
      grossProfitMonth: grossProfitPeriod,
      netProfitMargin,

      invoiceDue,
      unpaidInvoicesCount,

      totalPurchaseMonth: totalPurchasePeriod,
      purchaseGrowthPct: 5.4, // placeholder or historical diff

      purchaseDue,
      dueBillsCount,

      totalExpenseMonth: totalExpensePeriod,
      expenseChangePct,

      // Inventory, Operational Counts & Sparklines
      totalStockQty,
      lowStockCount,
      totalProducts,
      totalCustomers,
      totalSuppliers,
      customerTotalDue: invoiceDue,
      supplierTotalDue: purchaseDue,
      weeklySalesChart: daysChart,
      paymentShares,
      recentInvoices,
      hourlySalesHeatmap,
      expenseBreakdown,
    };
  }
}
