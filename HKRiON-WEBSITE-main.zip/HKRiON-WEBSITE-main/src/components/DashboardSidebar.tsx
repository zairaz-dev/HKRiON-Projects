'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import {
  MessageSquare,
  Users,
  Briefcase,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronRight,
  Sparkles,
  Globe,
  ShieldCheck,
  Layers
} from 'lucide-react';

interface SidebarProps {
  userRole?: 'ADMIN' | 'EMPLOYEE' | 'CUSTOMER';
  userName?: string;
  userEmail?: string;
  userAvatar?: string | null;
  activeTab?: string;
  setActiveTab?: (tab: string) => void;
}

export default function DashboardSidebar({
  userRole = 'ADMIN',
  userName = 'HKRION Admin',
  userEmail = 'admin@hkrion.com',
  userAvatar,
  activeTab = 'inquiries',
  setActiveTab,
}: SidebarProps) {
  const router = useRouter();
  const [isOpen, setIsOpen] = useState(false);

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/login');
    router.refresh();
  };

  const navItems = [
    {
      id: 'inquiries',
      label: 'All Inquiries',
      icon: MessageSquare,
      href: '/dashboard/admin',
      roles: ['ADMIN', 'EMPLOYEE', 'CUSTOMER'],
    },
    {
      id: 'roles',
      label: 'Role Management',
      icon: ShieldCheck,
      href: '/dashboard/admin/roles',
      roles: ['ADMIN'],
    },
    {
      id: 'users',
      label: 'User Management',
      icon: Users,
      href: '/dashboard/admin/users',
      roles: ['ADMIN'],
    },
    {
      id: 'jobs',
      label: 'Manage Job Openings',
      icon: Layers,
      href: '/dashboard/admin/jobs',
      roles: ['ADMIN'],
    },
    {
      id: 'careers',
      label: 'Job Applications',
      icon: Briefcase,
      href: '/dashboard/admin/careers',
      roles: ['ADMIN', 'EMPLOYEE'],
    },
    {
      id: 'services',
      label: 'Service Requests',
      icon: Briefcase,
      href: '/dashboard/admin',
      roles: ['ADMIN', 'EMPLOYEE'],
    },
    {
      id: 'settings',
      label: 'System Settings',
      icon: Settings,
      href: '/dashboard/admin',
      roles: ['ADMIN'],
    },
  ];

  const filteredNav = navItems.filter((item) => item.roles.includes(userRole));

  return (
    <>
      {/* Mobile Toggle Button */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="p-3 rounded-xl bg-black/90 border border-[#1ABE56]/40 text-[#1ABE56] shadow-xl backdrop-blur-md cursor-pointer"
        >
          {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Backdrop for Mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-40 lg:hidden animate-fade-in"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 left-0 bottom-0 w-64 bg-black/95 border-r border-[#1ABE56]/30 shadow-2xl z-40 flex flex-col justify-between transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Top Header */}
        <div className="p-6 border-b border-neutral-900 space-y-4">
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-xl bg-black border border-[#1ABE56]/40 p-1 flex items-center justify-center group-hover:scale-105 transition-transform shrink-0">
              <Image 
                src="/assets/logos/logo.png" 
                alt="HKRION Logo" 
                width={36} 
                height={36} 
                className="w-full h-full object-contain"
                priority
              />
            </div>
            <div>
              <span className="text-lg font-bold font-mono tracking-wider text-white block">
                HKRION<span className="text-[#1ABE56]">.{userRole}</span>
              </span>
              <span className="text-[10px] font-mono text-neutral-400 uppercase tracking-widest block">
                Enterprise Portal
              </span>
            </div>
          </Link>

          {/* Role Pill */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#1ABE56]/10 border border-[#1ABE56]/30 text-xs font-mono text-[#1ABE56]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Role: {userRole}</span>
          </div>
        </div>

        {/* Navigation Items */}
        <div className="p-4 space-y-1.5 flex-1 overflow-y-auto">
          <p className="text-[10px] font-mono uppercase text-neutral-500 px-3 pb-2">
            Main Menu
          </p>

          {filteredNav.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  if (setActiveTab) setActiveTab(item.id);
                  if (item.href) router.push(item.href);
                  setIsOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#1ABE56]/20 text-[#1ABE56] border border-[#1ABE56]/40 shadow-lg shadow-[#1ABE56]/10'
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-900/80 border border-transparent'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#1ABE56]' : 'text-neutral-400'}`} />
                  <span>{item.label}</span>
                </div>
                {isActive && <ChevronRight className="w-4 h-4 text-[#1ABE56]" />}
              </button>
            );
          })}

          <div className="pt-4 mt-4 border-t border-neutral-900 space-y-1.5">
            <p className="text-[10px] font-mono uppercase text-neutral-500 px-3 pb-2">
              Website
            </p>
            <Link
              href="/"
              className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-medium text-neutral-400 hover:text-white hover:bg-neutral-900 transition-all"
            >
              <Globe className="w-4 h-4 text-neutral-400" />
              <span>Back to Website</span>
            </Link>
          </div>
        </div>

        {/* User Profile & Sign Out Footer */}
        <div className="p-4 border-t border-neutral-900 bg-neutral-950/80 space-y-3">
          <div className="flex items-center gap-3 px-2">
            {userAvatar ? (
              <img
                src={userAvatar}
                alt={userName}
                className="w-9 h-9 rounded-full object-cover border border-[#1ABE56]/50 shrink-0"
              />
            ) : (
              <div className="w-9 h-9 rounded-full bg-[#1ABE56]/20 border border-[#1ABE56]/40 flex items-center justify-center text-[#1ABE56] font-bold text-xs font-mono shrink-0">
                {userName.slice(0, 2).toUpperCase()}
              </div>
            )}
            <div className="overflow-hidden text-left flex-1">
              <h4 className="text-xs font-semibold text-white truncate">{userName}</h4>
              <p className="text-[10px] font-mono text-neutral-500 truncate">{userEmail}</p>
            </div>
          </div>

          <button
            onClick={handleLogout}
            className="w-full py-2.5 rounded-xl bg-red-500/10 border border-red-500/30 hover:bg-red-500/20 text-red-400 text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </aside>
    </>
  );
}
