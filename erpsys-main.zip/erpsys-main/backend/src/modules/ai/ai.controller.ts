import { Controller, Post, Get, Body, UseGuards } from '@nestjs/common';
import { AiService } from './ai.service';
import { ChatPromptDto } from './dto/chat-prompt.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Public } from '../../common/decorators/public.decorator';

@UseGuards(JwtAuthGuard)
@Controller('ai')
export class AiController {
  constructor(private readonly aiService: AiService) {}

  @Public()
  @Get('status')
  async getAiStatus() {
    return this.aiService.getPublicAiStatus();
  }

  @Post('chat')
  async chat(
    @Body() dto: ChatPromptDto,
    @CurrentUser() user: any,
  ) {
    return this.aiService.chat(dto, user);
  }
}
