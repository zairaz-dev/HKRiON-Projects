# Finance Module

This module handles accounting ledgers, expenses, and tax records:
- Double-entry ledger postings (automatically triggered by sales or expenses)
- Tax collections records
- Profit & Loss calculations
- Business expense logging

## Files to create
- `finance.controller.ts`: Handles ledger and expense API endpoints.
- `finance.service.ts`: Handles bookkeeping and tax calculations.
- `finance.module.ts`: NestJS module declaration.
