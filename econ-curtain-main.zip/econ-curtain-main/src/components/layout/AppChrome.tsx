"use client";

import { usePathname } from "next/navigation";

export default function AppChrome({ 
  children,
  navbar,
  footer,
  whatsapp
}: { 
  children: React.ReactNode;
  navbar: React.ReactNode;
  footer: React.ReactNode;
  whatsapp: React.ReactNode;
}) {
  const pathname = usePathname();

  // Hide public chrome (Navbar, Footer, WhatsApp button) on Admin and Login pages
  const isAdminOrAuth = pathname?.startsWith("/admin") || pathname?.startsWith("/login");

  if (isAdminOrAuth) {
    return <>{children}</>;
  }

  return (
    <>
      {navbar}
      <main className="grow pt-18">
        {children}
      </main>
      {footer}
      {whatsapp}
    </>
  );
}
