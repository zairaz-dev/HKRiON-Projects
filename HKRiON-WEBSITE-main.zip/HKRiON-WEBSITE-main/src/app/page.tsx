import dynamic from 'next/dynamic';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import TrustedBy from '@/components/TrustedBy';
import Products from '@/components/Products';

const Services = dynamic(() => import('@/components/Services'));
const Industries = dynamic(() => import('@/components/Industries'));
const WhyChooseUs = dynamic(() => import('@/components/WhyChooseUs'));
const TechStack = dynamic(() => import('@/components/TechStack'));
const Process = dynamic(() => import('@/components/Process'));
const Portfolio = dynamic(() => import('@/components/Portfolio'));
const CaseStudies = dynamic(() => import('@/components/CaseStudies'));
const Testimonials = dynamic(() => import('@/components/Testimonials'));
const FAQ = dynamic(() => import('@/components/FAQ'));
const ContactForm = dynamic(() => import('@/components/ContactForm'));
const FloatingWidgets = dynamic(() => import('@/components/FloatingWidgets'));
const Footer = dynamic(() => import('@/components/Footer'));

export const metadata = {
  title: 'HKRION (Pvt) Ltd | Enterprise ERP, IoT, Web & Mobile Software Solutions',
  description: 'HKRION (Pvt) Ltd is a premier software engineering company delivering Next-Gen Enterprise ERPs, IoT Smart Systems, Web Applications, Mobile Apps, Digital Marketing, and Cloud Infrastructure.',
  keywords: ['HKRION', 'HKRION POS', 'HKRION ERP', 'HKRION HRM', 'IoT Telemetry', 'Web Development', 'Mobile Apps', 'Sri Lanka Tech Startup'],
};

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-neutral-100 flex flex-col font-sans selection:bg-[#1ABE56] selection:text-black">
      <Navbar />
      <main className="grow">
        <Hero />
        <TrustedBy />
        <Products />
        <Services />
        <WhyChooseUs />
        <Testimonials />
        <Industries />
        <Process />
        <Portfolio />
        <CaseStudies />
        <TechStack />
        <FAQ />
        <ContactForm />
      </main>
      <Footer />
      <FloatingWidgets />
    </div>
  );
}
