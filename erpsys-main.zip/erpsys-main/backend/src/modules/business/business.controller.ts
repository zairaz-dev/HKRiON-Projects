import { Controller, Post, Body, Get, Patch, Param, UseGuards, UseInterceptors, UploadedFile, BadRequestException, Req, ForbiddenException } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { getImageUploadOptions } from '../../common/utils/upload.util';
import { BusinessService } from './business.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Public } from '../../common/decorators/public.decorator';
import { ApiTags, ApiOperation, ApiBody, ApiResponse, ApiBearerAuth, ApiParam, ApiConsumes } from '@nestjs/swagger';
import {
  RegisterBusinessBodySchema,
  RegisterBusinessResponseSchema,
  RegisterBusinessGoogleBodySchema,
  RegisterBusinessGoogleResponseSchema,
  GetBusinessResponseSchema,
  UpdateBusinessBodySchema,
} from '../../docs/business.docs';

@ApiTags('Auth')
@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('auth')
export class BusinessController {
  constructor(private readonly businessService: BusinessService) {}

  @Public()
  @Post('register-business')
  @ApiOperation({ summary: 'Register a new business organization and admin account' })
  @ApiBody({ schema: RegisterBusinessBodySchema })
  @ApiResponse({
    status: 201,
    description: 'Business and admin user registered successfully',
    schema: RegisterBusinessResponseSchema,
  })
  async registerBusiness(@Body() body: any) {
    return this.businessService.registerBusiness(
      body.businessName,
      body.industry,
      body.phone,
      body.phoneCodeId,
      body.countryId,
      body.currencyId,
      body.ownerName,
      body.email,
      body.password,
    );
  }

  @Public()
  @Post('register-business-google')
  @ApiOperation({ summary: 'Register a new business organization via Google OAuth' })
  @ApiBody({ schema: RegisterBusinessGoogleBodySchema })
  @ApiResponse({
    status: 201,
    description: 'Business and admin user registered via Google successfully',
    schema: RegisterBusinessGoogleResponseSchema,
  })
  async registerBusinessGoogle(@Body() body: any) {
    return this.businessService.registerBusinessGoogle(
      body.businessName,
      body.industry,
      body.phone,
      body.phoneCodeId,
      body.countryId,
      body.currencyId,
      body.token,
    );
  }

  @ApiBearerAuth()
  @Get('business/:id')
  @ApiOperation({ summary: 'Get business details and configuration by ID' })
  @ApiParam({ name: 'id', description: 'Business UUID' })
  @ApiResponse({
    status: 200,
    description: 'Business details retrieved successfully',
    schema: GetBusinessResponseSchema,
  })
  async getBusinessById(@Req() req: any, @Param('id') id: string) {
    const user = req.user;
    if (user && user.role !== 'super-admin' && user.businessId !== id) {
      throw new ForbiddenException('Access denied: You can only view your own business.');
    }
    return this.businessService.getBusinessById(id);
  }

  @ApiBearerAuth()
  @Patch('business/:id')
  @ApiOperation({ summary: 'Update business information' })
  @ApiParam({ name: 'id', description: 'Business UUID' })
  @ApiBody({ schema: UpdateBusinessBodySchema })
  @ApiResponse({
    status: 200,
    description: 'Business updated successfully',
    schema: GetBusinessResponseSchema,
  })
  async updateBusiness(
    @Req() req: any,
    @Param('id') id: string,
    @Body() body: any,
  ) {
    const user = req.user;
    if (user && user.role !== 'super-admin') {
      if (user.businessId !== id) {
        throw new ForbiddenException('Access denied: You can only update your own business.');
      }
      if (user.role !== 'admin') {
        throw new ForbiddenException('Access denied: Only administrators can modify business information.');
      }
    }
    return this.businessService.updateBusiness(id, body);
  }

  @ApiBearerAuth()
  @Post('business/:id/upload-logo')
  @UseInterceptors(FileInterceptor('logo', getImageUploadOptions('business')))
  @ApiOperation({ summary: 'Upload business logo image' })
  @ApiParam({ name: 'id', description: 'Business UUID' })
  @ApiConsumes('multipart/form-data')
  async uploadLogo(
    @Req() req: any,
    @Param('id') id: string,
    @UploadedFile() file: any,
  ) {
    const user = req.user;
    if (user && user.role !== 'super-admin') {
      if (user.businessId !== id) {
        throw new ForbiddenException('Access denied: You can only update your own business logo.');
      }
      if (user.role !== 'admin') {
        throw new ForbiddenException('Access denied: Only administrators can modify business logo.');
      }
    }
    if (!file) {
      throw new BadRequestException('No logo file provided');
    }
    const logoUrl = `/uploads/business/${file.filename}`;
    await this.businessService.updateBusiness(id, { logo: logoUrl });
    return { logoUrl };
  }
}
