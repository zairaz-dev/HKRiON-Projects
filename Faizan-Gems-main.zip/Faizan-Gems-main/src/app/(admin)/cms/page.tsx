import AdminDashboard from "@/features/admin/AdminDashboard";

export default function CMSPage() {
  return <AdminDashboard initialTab="cms" />;
}
