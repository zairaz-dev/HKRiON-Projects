import * as React from "react"
import { cn } from "@/lib/utils"
import { Check } from "lucide-react"

/**
 * ==========================================================================
 * CheckboxProps Interface
 * ==========================================================================
 * 
 * Extends standard HTML input attributes (excluding 'type') and adds custom
 * checked state and change handler properties.
 */
export interface CheckboxProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type'> {
  /**
   * The checked state of the checkbox.
   */
  checked?: boolean;
  /**
   * Callback triggered when the checked state changes.
   */
  onCheckedChange?: (checked: boolean) => void;
}

/**
 * ==========================================================================
 * Reusable Checkbox Component
 * ==========================================================================
 * 
 * A custom checkbox component designed with smooth transitions, custom checkmark
 * animation, and optimized visibility for dark themes.
 * Uses a hidden native checkbox under the hood for accessibility and keyboard focus.
 */
const Checkbox = React.forwardRef<HTMLInputElement, CheckboxProps>(
  ({ className, checked, onCheckedChange, ...props }, ref) => {
    const [localChecked, setLocalChecked] = React.useState(checked || false);

    // Sync external checked prop to local state
    React.useEffect(() => {
      if (checked !== undefined) {
        setLocalChecked(checked);
      }
    }, [checked]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const newChecked = e.target.checked;
      setLocalChecked(newChecked);
      if (onCheckedChange) {
        onCheckedChange(newChecked);
      }
    };

    return (
      <label className="flex items-center gap-2 cursor-pointer select-none">
        <div className="relative">
          {/* Native Hidden Checkbox for accessibility */}
          <input
            type="checkbox"
            checked={localChecked}
            onChange={handleChange}
            className="sr-only"
            ref={ref}
            {...props}
          />
          {/* Custom Styled Checkbox UI */}
          <div
            className={cn(
               "w-4 h-4 rounded-sm border border-input bg-card/40 flex items-center justify-center transition-all",
               localChecked ? "bg-primary border-primary shadow-lg shadow-primary/20" : "hover:border-muted-foreground/60",
               className
            )}
          >
            {/* Custom checkmark icon */}
            {localChecked && <Check className="w-3 h-3 text-primary-foreground stroke-[3.5px]" />}
          </div>
        </div>
      </label>
    )
  }
)
Checkbox.displayName = "Checkbox"

export { Checkbox }
