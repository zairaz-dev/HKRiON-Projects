'use client';

import { ArrowRight, Activity } from 'lucide-react';
import DarkVeil from '@/components/DarkVeil';
import GlobeBackground from '@/components/GlobeBackground';

export default function Hero() {
  return (
    <section className="relative pt-28 pb-16 sm:pt-36 sm:pb-28 md:pt-44 md:pb-36 overflow-hidden bg-black min-h-[85vh] sm:min-h-[90vh] flex items-center justify-center">
      
      {/* 3D Green Dotted Globe Interactive Background (Optimized Mobile Opacity) */}
      <div className="absolute inset-0 w-full h-full opacity-35 sm:opacity-50 pointer-events-auto z-0">
        <GlobeBackground />
      </div>

      {/* React Bits DarkVeil WebGL Background Shader (blended) */}
      <div className="absolute inset-0 w-full h-full opacity-15 sm:opacity-20 pointer-events-none z-0">
        <DarkVeil 
          hueShift={120} 
          speed={0.3} 
          warpAmount={0.15} 
          noiseIntensity={0.02} 
          scanlineIntensity={0.03} 
        />
      </div>

      {/* Background Ambient Glowing Orbits */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 sm:w-150 h-80 sm:h-150 bg-[#1ABE56]/15 blur-[120px] sm:blur-[160px] rounded-full pointer-events-none z-0" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="text-center max-w-4xl mx-auto space-y-5 sm:space-y-8">

          {/* Hero Headline */}
          <h1 className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight text-white leading-tight sm:leading-[1.15] font-sans drop-shadow-[0_4px_24px_rgba(0,0,0,0.9)]">
            <span className="block mb-1 sm:mb-2 font-medium text-neutral-100">Transforming Businesses Through</span>
            <span className="gradient-text block font-bold">Smart Digital Solutions</span>
          </h1>

          {/* Subtitle */}
          <p className="text-sm sm:text-lg md:text-xl text-neutral-300 max-w-2xl mx-auto leading-relaxed font-normal font-sans px-2 sm:px-0 drop-shadow-[0_2px_12px_rgba(0,0,0,0.95)]">
            We build easy-to-use ERP, POS, Web & Mobile software designed to automate your business operations and grow your revenue.
          </p>

          {/* Action Buttons - Stacked on Mobile, Side-by-Side on Desktop */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 pt-2 sm:pt-4 max-w-md sm:max-w-none mx-auto w-full px-2 sm:px-0">
            <a
              href="#contact"
              className="glow-btn w-full sm:w-auto px-6 py-3.5 sm:px-8 sm:py-4 rounded-xl text-sm sm:text-base font-semibold text-white flex items-center justify-center gap-2 sm:gap-3 group"
            >
              <span>Get Free Consultation</span>
              <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5 group-hover:translate-x-1.5 transition-transform shrink-0" />
            </a>
            <a
              href="#products"
              className="w-full sm:w-auto px-6 py-3.5 sm:px-8 sm:py-4 rounded-xl text-sm sm:text-base font-semibold text-neutral-200 glass-card hover:bg-neutral-900 transition-all border border-[#1ABE56]/40 hover:border-[#1ABE56] hover:scale-105 text-center flex items-center justify-center gap-2"
            >
              <Activity className="w-4 h-4 text-[#1ABE56] animate-pulse shrink-0" />
              <span>Explore Products</span>
            </a>
          </div>

        </div>
      </div>
    </section>
  );
}
