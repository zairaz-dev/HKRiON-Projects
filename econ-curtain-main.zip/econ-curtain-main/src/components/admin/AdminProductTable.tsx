"use client";

import { useState, useCallback } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import {
  Edit3,
  X,
  Save,
  Search,
  Package,
  Trash2,
} from "lucide-react";

export interface ProductItem {
  id: string;
  name: string;
  category: string;
  description: string;
  imageUrl: string;
  images?: string; // JSON string array of URLs
  features: string;
  isActive: boolean;
}

interface AdminProductTableProps {
  products: ProductItem[];
  categories: string[];
  editingProductId?: string;
  basePath?: string;
}

function parseProductImages(product: ProductItem | null): string[] {
  if (!product) return [];
  try {
    const parsed = JSON.parse(product.images || "[]");
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed.filter((img): img is string => typeof img === "string" && img.trim().length > 0);
    }
    if (product.imageUrl && product.imageUrl.trim().length > 0) {
      return [product.imageUrl];
    }
    return [];
  } catch {
    if (product.imageUrl && product.imageUrl.trim().length > 0) {
      return [product.imageUrl];
    }
    return [];
  }
}

export default function AdminProductTable({
  products,
  categories,
  editingProductId,
  basePath = "/admin/products",
}: AdminProductTableProps) {
  const [activeCategory, setActiveCategory] = useState<string>("ALL");
  const [searchQuery, setSearchQuery] = useState<string>("");
  
  const getInitialProduct = useCallback(() => {
    if (editingProductId === "new") {
      return { id: "new", name: "", category: categories[0] || "", description: "", imageUrl: "", features: "[]", isActive: true };
    }
    if (editingProductId) {
      return products.find((p) => p.id === editingProductId) || null;
    }
    return null;
  }, [editingProductId, products, categories]);

  const [prevEditingProductId, setPrevEditingProductId] = useState(editingProductId);
  const [selectedProduct, setSelectedProduct] = useState<ProductItem | null>(() => getInitialProduct());
  const [currentImages, setCurrentImages] = useState<string[]>(() => parseProductImages(getInitialProduct()));
  const [isUploading, setIsUploading] = useState(false);
  const [productToDelete, setProductToDelete] = useState<ProductItem | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const router = useRouter();

  if (prevEditingProductId !== editingProductId) {
    setPrevEditingProductId(editingProductId);
    const prod = getInitialProduct();
    setSelectedProduct(prod);
    setCurrentImages(parseProductImages(prod));
  }

  const handleOpenProduct = (product: ProductItem) => {
    setSelectedProduct(product);
    setCurrentImages(parseProductImages(product));
  };

  const confirmDeleteProduct = async () => {
    if (!productToDelete) return;
    setIsDeleting(true);
    try {
      const res = await fetch(`/api/admin/products/delete?id=${productToDelete.id}`, {
        method: "DELETE",
      });
      if (res.ok) {
        window.location.reload();
      } else {
        const data = await res.json();
        alert("Failed to delete product: " + (data.error || "Unknown error"));
        setIsDeleting(false);
        setProductToDelete(null);
      }
    } catch (err) {
      console.error(err);
      alert("An error occurred while deleting the product.");
      setIsDeleting(false);
      setProductToDelete(null);
    }
  };

  const handleCloseModal = () => {
    setSelectedProduct(null);
    setCurrentImages([]);
    router.replace(basePath, { scroll: false });
  };

  const filteredProducts = products.filter((p) => {
    const matchesCategory =
      activeCategory === "ALL" || p.category === activeCategory;
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-6 w-full">
      {/* Category Pills & Search & View Mode Switcher */}
      <div className="bg-white dark:bg-black p-4 sm:p-5 rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 scrollbar-none">
          <button
            type="button"
            onClick={() => setActiveCategory("ALL")}
            className={`px-3 py-1.5 rounded-none text-xs font-bold transition-all whitespace-nowrap cursor-pointer border ${
              activeCategory === "ALL"
                ? "bg-amber-500 text-slate-950 border-amber-600 shadow-xs"
                : "bg-neutral-50 dark:bg-neutral-950 hover:bg-neutral-100 dark:hover:bg-neutral-900 text-neutral-600 dark:text-neutral-300 border-[#E5E5E0] dark:border-neutral-800"
            }`}
          >
            All Products ({products.length})
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-none text-xs font-bold transition-all whitespace-nowrap cursor-pointer border ${
                activeCategory === cat
                  ? "bg-amber-500 text-slate-950 border-amber-600 shadow-xs"
                  : "bg-neutral-50 dark:bg-neutral-950 hover:bg-neutral-100 dark:hover:bg-neutral-900 text-neutral-600 dark:text-neutral-300 border-[#E5E5E0] dark:border-neutral-800"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-64">
          <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-500 pointer-events-none" />
          <input
            type="text"
            placeholder="Search product..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 dark:placeholder:text-neutral-500 outline-hidden font-medium"
          />
        </div>
      </div>

      {/* Visual Product Grid */}
      {filteredProducts.length === 0 ? (
        <div className="bg-white dark:bg-black p-12 rounded-none border border-[#E5E5E0] dark:border-neutral-800 text-center text-neutral-400 dark:text-neutral-500">
          <Package size={36} className="mx-auto mb-2 opacity-30 text-neutral-500 dark:text-neutral-400" />
          <p className="font-bold text-neutral-700 dark:text-neutral-300">No products found matching your filter</p>
          <p className="text-xs text-neutral-400 dark:text-neutral-500 mt-0.5">Try clearing your search query.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {filteredProducts.map((product, index) => {
            let parsedFeatures: string[] = [];
            try {
              parsedFeatures = JSON.parse(product.features || "[]");
            } catch {
              parsedFeatures = [];
            }

            return (
              <div
                key={product.id}
                className="bg-white dark:bg-black rounded-none border border-[#E5E5E0] dark:border-neutral-800 overflow-hidden shadow-2xs hover:shadow-md hover:border-amber-400/50 dark:hover:border-amber-400/50 transition-all flex flex-col group"
              >
                {/* Product Thumbnail Banner */}
                <div className="relative h-44 w-full bg-neutral-100 dark:bg-neutral-950 overflow-hidden">
                  <Image
                    src={product.imageUrl}
                    alt={product.name}
                    fill
                    sizes="(max-width: 768px) 100vw, 300px"
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                    unoptimized
                    priority={index < 4}
                  />
                  <div className="absolute inset-0 bg-linear-to-t from-black/70 via-black/20 to-transparent" />

                  {/* Category badge */}
                  <span className="absolute top-3 left-3 bg-neutral-900/80 backdrop-blur-xs text-amber-400 border border-amber-400/30 text-[10px] font-bold px-2.5 py-0.5 rounded-none shadow-xs">
                    {product.category}
                  </span>

                  {/* Status badge */}
                  <span
                    className={`absolute top-3 right-3 text-[10px] font-bold px-2 py-0.5 rounded-none border shadow-xs ${
                      product.isActive
                        ? "bg-emerald-500 text-white border-emerald-600"
                        : "bg-neutral-800 text-neutral-300 border-neutral-700"
                    }`}
                  >
                    {product.isActive ? "Published" : "Hidden"}
                  </span>

                  {/* Bottom Title on Image */}
                  <div className="absolute bottom-2.5 left-3 right-3">
                    <h3 className="text-sm font-black text-white truncate drop-shadow-sm">
                      {product.name}
                    </h3>
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-4 flex flex-col grow justify-between space-y-3">
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 line-clamp-2 leading-relaxed font-light">
                    {product.description}
                  </p>

                  {/* Features pills */}
                  {parsedFeatures.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {parsedFeatures.slice(0, 2).map((feat, i) => (
                        <span
                          key={i}
                          className="text-[9px] bg-neutral-100 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-300 px-2 py-0.5 rounded-none font-medium truncate max-w-28 border border-neutral-200/50 dark:border-neutral-800"
                        >
                          {feat}
                        </span>
                      ))}
                      {parsedFeatures.length > 2 && (
                        <span className="text-[9px] text-neutral-400 dark:text-neutral-500 self-center">
                          +{parsedFeatures.length - 2} more
                        </span>
                      )}
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex flex-col gap-2 w-full mt-2">
                    <button
                      type="button"
                      onClick={() => handleOpenProduct(product)}
                      className="w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded-none bg-neutral-50 dark:bg-neutral-900 hover:bg-amber-500 dark:hover:bg-amber-500 hover:text-slate-950 dark:hover:text-slate-950 text-neutral-700 dark:text-neutral-200 text-xs font-bold border border-[#E5E5E0] dark:border-neutral-800 hover:border-amber-600 transition-all cursor-pointer"
                    >
                      <Edit3 size={12} />
                      <span>Edit Product Details</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setProductToDelete(product)}
                      className="w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded-none bg-neutral-50 dark:bg-neutral-900 hover:bg-red-500 dark:hover:bg-red-500 hover:text-white dark:hover:text-white text-red-600 dark:text-red-400 text-xs font-bold border border-[#E5E5E0] dark:border-neutral-800 hover:border-red-600 transition-all cursor-pointer"
                    >
                      <Trash2 size={12} />
                      <span>Delete Product</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Slide-over Edit Product Drawer / Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 bg-neutral-950/80 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-black w-full max-w-xl rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between bg-neutral-50/50 dark:bg-neutral-950/50">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
                  {selectedProduct.id === "new" ? "ADD PRODUCT" : "EDIT PRODUCT"}
                </span>
                <h3 className="text-base font-bold text-neutral-900 dark:text-white mt-0.5">
                  {selectedProduct.id === "new" ? "New Product" : selectedProduct.name}
                </h3>
              </div>
              <button
                type="button"
                onClick={handleCloseModal}
                className="p-1.5 rounded-none text-neutral-400 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-900 cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Form */}
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                setIsUploading(true);

                try {
                  const form = e.currentTarget;
                  const finalImages = [...currentImages];

                  const updateData = new FormData(form);
                  if (finalImages.length > 0) {
                    updateData.set("imageUrl", finalImages[0]);
                    updateData.set("images", JSON.stringify(finalImages));
                  } else {
                    // Fallback to empty if they removed everything
                    updateData.set("imageUrl", "");
                    updateData.set("images", "[]");
                  }

                  const url = selectedProduct.id === "new" ? "/api/admin/products/create" : "/api/admin/products/update";
                  const updateRes = await fetch(url, {
                    method: "POST",
                    body: updateData
                  });

                  if (updateRes.ok) {
                    window.location.reload();
                  } else {
                    alert("Update failed.");
                    setIsUploading(false);
                  }
                } catch (err) {
                  console.error(err);
                  alert("An error occurred");
                  setIsUploading(false);
                }
              }}
              className="p-6 overflow-y-auto space-y-4 text-xs scrollbar-thin"
            >
              <input type="hidden" name="id" value={selectedProduct.id} />

              <div>
                <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">Product Name</label>
                <input
                  type="text"
                  name="name"
                  defaultValue={selectedProduct.name}
                  placeholder="e.g. Premium Motorized Zebra Blinds"
                  required
                  className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 dark:placeholder:text-neutral-500 outline-hidden font-medium"
                />
              </div>

              <div>
                <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">Category</label>
                <select
                  name="category"
                  defaultValue={selectedProduct.category}
                  className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-medium"
                >
                  {categories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">Description</label>
                <textarea
                  name="description"
                  rows={3}
                  defaultValue={selectedProduct.description}
                  placeholder="Describe the product, its materials, and ideal use cases..."
                  required
                  className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 dark:placeholder:text-neutral-500 outline-hidden font-medium"
                />
              </div>

              <div>
                <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">Upload Additional Images</label>
                <input
                  type="file"
                  name="files"
                  multiple
                  accept="image/*"
                  onChange={async (e) => {
                    const files = e.target.files;
                    if (!files || files.length === 0) return;
                    
                    setIsUploading(true);
                    try {
                      const formData = new FormData();
                      for (let i = 0; i < files.length; i++) {
                        formData.append("files", files[i]);
                      }

                      const res = await fetch("/api/admin/upload", {
                        method: "POST",
                        body: formData,
                      });

                      const data = await res.json();
                      if (data.success) {
                        setCurrentImages((prev) => [...prev, ...data.urls]);
                      } else {
                        alert("Upload failed: " + data.error);
                      }
                    } catch (err) {
                      console.error("Upload error:", err);
                      alert("Failed to upload images.");
                    } finally {
                      setIsUploading(false);
                      // Reset file input so the same files can be selected again if needed
                      e.target.value = "";
                    }
                  }}
                  className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 outline-hidden font-mono"
                />
                <p className="text-neutral-500 mt-1 text-[10px]">Images will be uploaded immediately and added below.</p>
                
                {/* Show existing images preview if any */}
                {currentImages.length > 0 && (
                  <div className="mt-3">
                    <p className="font-bold text-neutral-700 dark:text-neutral-300 mb-2">Current Images</p>
                    <div className="flex gap-2 overflow-x-auto pb-2">
                      {currentImages.map((img, idx) => (
                        <div key={idx} className="relative w-20 h-20 shrink-0 border border-neutral-200 dark:border-neutral-800 group rounded-xs overflow-hidden">
                          <Image src={img} alt="Preview" fill className="object-cover" unoptimized />
                          <button
                            type="button"
                            onClick={() => setCurrentImages(currentImages.filter((_, i) => i !== idx))}
                            className="absolute top-1 right-1 bg-black/60 hover:bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                            title="Remove image"
                          >
                            <X size={12} />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  Features (Comma separated)
                </label>
                <input
                  type="text"
                  name="features"
                  defaultValue={(() => {
                    try {
                       return JSON.parse(selectedProduct.features).join(", ");
                    } catch {
                       return selectedProduct.features;
                    }
                  })()}
                  placeholder="e.g. UV Protection, Motorized, Easy to clean"
                  required
                  className="w-full px-3.5 py-2 bg-neutral-50 dark:bg-neutral-950 border border-[#E5E5E0] dark:border-neutral-800 focus:border-amber-500 rounded-none text-xs text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 dark:placeholder:text-neutral-500 outline-hidden font-mono"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="product-active-toggle"
                  name="isActive"
                  value="true"
                  defaultChecked={selectedProduct.isActive}
                  className="w-4 h-4 rounded-none text-amber-500 focus:ring-amber-400 border-neutral-300 dark:border-neutral-800 bg-white dark:bg-neutral-950"
                />
                <label
                  htmlFor="product-active-toggle"
                  className="font-bold text-neutral-800 dark:text-neutral-200 cursor-pointer"
                >
                  Published on Website Catalog (Active)
                </label>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={handleCloseModal}
                  disabled={isUploading}
                  className="px-4 py-2 rounded-none bg-neutral-100 dark:bg-neutral-900 hover:bg-neutral-200 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 text-xs font-bold cursor-pointer border border-neutral-200 dark:border-neutral-800 disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isUploading}
                  className="inline-flex items-center gap-1.5 px-5 py-2 rounded-none bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-extrabold shadow-xs cursor-pointer transition-all active:scale-95 disabled:opacity-50"
                >
                  <Save size={13} />
                  <span>{isUploading ? "Saving..." : "Save Changes"}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Delete Confirmation Modal */}
      {productToDelete && (
        <div className="fixed inset-0 z-[60] bg-neutral-950/80 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-black w-full max-w-sm rounded-none border border-[#E5E5E0] dark:border-neutral-800 shadow-2xl overflow-hidden flex flex-col">
            <div className="p-6">
              <h3 className="text-lg font-bold text-neutral-900 dark:text-white mb-2">Delete Product?</h3>
              <p className="text-sm text-neutral-600 dark:text-neutral-400">
                Are you sure you want to delete <span className="font-bold text-neutral-900 dark:text-white">{productToDelete.name}</span>? This action cannot be undone.
              </p>
            </div>
            <div className="px-6 py-4 border-t border-neutral-100 dark:border-neutral-800 flex flex-col sm:flex-row gap-3 bg-neutral-50/50 dark:bg-neutral-950/50 justify-end">
              <button
                type="button"
                onClick={() => setProductToDelete(null)}
                disabled={isDeleting}
                className="px-4 py-2 rounded-none bg-white dark:bg-neutral-900 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 text-xs font-bold cursor-pointer border border-[#E5E5E0] dark:border-neutral-800 disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDeleteProduct}
                disabled={isDeleting}
                className="inline-flex items-center justify-center gap-1.5 px-5 py-2 rounded-none bg-red-600 hover:bg-red-700 text-white text-xs font-extrabold shadow-xs cursor-pointer transition-all active:scale-95 disabled:opacity-50"
              >
                <Trash2 size={13} />
                <span>{isDeleting ? "Deleting..." : "Delete Product"}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
