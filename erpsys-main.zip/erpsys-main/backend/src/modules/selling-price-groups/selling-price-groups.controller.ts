import {
  Controller,
  Post,
  Body,
  Get,
  Put,
  Delete,
  Param,
  Query,
  UseGuards,
  Req,
} from '@nestjs/common';
import { SellingPriceGroupsService } from './selling-price-groups.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';
import {
  ApiTags,
  ApiOperation,
  ApiBody,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiQuery,
} from '@nestjs/swagger';

import { CreateSellingPriceGroupDto } from './dto/create-selling-price-group.dto';
import { UpdateSellingPriceGroupDto } from './dto/update-selling-price-group.dto';

@ApiTags('Selling Price Groups')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('selling-price-groups')
export class SellingPriceGroupsController {
  constructor(private readonly spgService: SellingPriceGroupsService) {}

  @Permissions(Permission.PRODUCT_CREATE)
  @Post()
  @ApiOperation({ summary: 'Create selling price group (e.g. Retail, Wholesale)' })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        name: { type: 'string', minLength: 2, maxLength: 100, example: 'Wholesale Tier 1' },
        description: { type: 'string', maxLength: 500, example: 'Price tier for bulk buyers' },
        isActive: { type: 'boolean', example: true },
        businessId: { type: 'string', example: 'biz_123' },
        branchIds: { type: 'array', items: { type: 'string' }, example: ['branch_01'] },
      },
      required: ['name', 'businessId'],
    },
  })
  @ApiResponse({ status: 201, description: 'Selling price group created successfully' })
  async createSellingPriceGroup(
    @Req() req: any,
    @Body() body: CreateSellingPriceGroupDto,
  ) {
    const user = req.user;
    if (user.role !== 'super-admin' || !body.businessId) {
      body.businessId = user.businessId;
    }
    if (!body.createdById) {
      body.createdById = user.id;
    }
    return this.spgService.createSellingPriceGroup(body as any);
  }

  @Permissions(Permission.PRODUCT_VIEW)
  @Get()
  @ApiOperation({ summary: 'Get list of selling price groups' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiQuery({ name: 'branchId', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Selling price groups retrieved successfully' })
  async getSellingPriceGroups(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.spgService.getSellingPriceGroups(bId, branchId);
  }

  @Permissions(Permission.PRODUCT_VIEW)
  @Get(':id')
  @ApiOperation({ summary: 'Get selling price group details by ID' })
  @ApiParam({ name: 'id', description: 'SPG UUID' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Selling price group retrieved successfully' })
  async getSellingPriceGroupById(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.spgService.getSellingPriceGroupById(id, bId);
  }

  @Permissions(Permission.PRODUCT_UPDATE)
  @Put(':id')
  @ApiOperation({ summary: 'Update selling price group' })
  @ApiParam({ name: 'id', description: 'SPG UUID' })
  @ApiResponse({ status: 200, description: 'Selling price group updated successfully' })
  async updateSellingPriceGroup(
    @Req() req: any,
    @Param('id') id: string,
    @Body() body: UpdateSellingPriceGroupDto,
  ) {
    const user = req.user;
    let bId = body.businessId;
    if (user.role !== 'super-admin' || !bId) {
      bId = user.businessId;
    }
    if (!body.updatedById) {
      body.updatedById = user.id;
    }
    const { businessId, ...data } = body;
    return this.spgService.updateSellingPriceGroup(id, bId, data as any);
  }

  @Permissions(Permission.PRODUCT_DELETE)
  @Delete(':id')
  @ApiOperation({ summary: 'Delete selling price group' })
  @ApiParam({ name: 'id', description: 'SPG UUID' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Selling price group deleted successfully' })
  async deleteSellingPriceGroup(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.spgService.deleteSellingPriceGroup(id, bId);
  }
}
