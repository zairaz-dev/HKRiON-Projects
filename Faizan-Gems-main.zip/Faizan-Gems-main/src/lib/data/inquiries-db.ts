import { pool } from "@/lib/db";
import crypto from "crypto";
import { RowDataPacket } from "mysql2";

export interface SalonInquiry {
  id: string;
  date: string;
  clientName: string;
  email: string;
  phone: string;
  gemstoneId?: string;
  gemstoneName?: string;
  location: string;
  salon: string;
  message: string;
  status: "new" | "scheduled" | "resolved";
  createdAt?: string;
}

interface InquiryRow extends RowDataPacket {
  id: string;
  gemstone_id: string | null;
  gemstone_name: string | null;
  name: string;
  email: string;
  phone: string | null;
  preferred_location?: string | null;
  preferred_salon?: string | null;
  message: string | null;
  status: string;
  created_at: Date;
}

function formatDate(date: Date): string {
  const now = new Date();
  const diffHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

  if (diffHours < 24) {
    return `Today, ${date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;
  }
  if (diffHours < 48) {
    return "Yesterday";
  }
  return date.toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" });
}

export async function getInquiries(): Promise<SalonInquiry[]> {
  try {
    const [rows] = await pool.query<InquiryRow[]>(
      "SELECT * FROM inquiries ORDER BY created_at DESC"
    );

    if (rows && rows.length > 0) {
      return rows.map((r) => {
        const loc = r.preferred_location || r.preferred_salon || "Trincomalee Flagship Showroom";
        return {
          id: r.id,
          date: formatDate(new Date(r.created_at)),
          clientName: r.name,
          email: r.email,
          phone: r.phone || "—",
          gemstoneId: r.gemstone_id || undefined,
          gemstoneName: r.gemstone_name || undefined,
          location: loc,
          salon: loc,
          message: r.message || "Consultation requested.",
          status: (r.status as "new" | "scheduled" | "resolved") || "new",
          createdAt: r.created_at.toISOString(),
        };
      });
    }
    return [];
  } catch (error) {
    console.warn("Failed to fetch inquiries from MySQL:", error);
    return [];
  }
}

export async function createInquiry(data: {
  name: string;
  email: string;
  phone?: string;
  preferredLocation?: string;
  preferredSalon?: string;
  message?: string;
  gemstoneId?: string;
  gemstoneName?: string;
}): Promise<boolean> {
  try {
    const id = `INQ-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
    const targetLocation = data.preferredLocation || data.preferredSalon || "Trincomalee Flagship Showroom";
    await pool.query(
      `INSERT INTO inquiries (
        id, gemstone_id, gemstone_name, name, email, phone, preferred_location, message, status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'new', NOW())`,
      [
        id,
        data.gemstoneId || null,
        data.gemstoneName || null,
        data.name,
        data.email,
        data.phone || null,
        targetLocation,
        data.message || null,
      ]
    );
    return true;
  } catch (error) {
    console.error("Failed to create inquiry in MySQL:", error);
    return false;
  }
}

export async function updateInquiryStatus(id: string, status: "new" | "scheduled" | "resolved"): Promise<boolean> {
  try {
    await pool.query(
      "UPDATE inquiries SET status = ? WHERE id = ?",
      [status, id]
    );
    return true;
  } catch (error) {
    console.error(`Failed to update inquiry status ${id} in MySQL:`, error);
    return false;
  }
}
