'use client';

import { useState } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';

export default function ContactForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: 'Enterprise ERP & Business Systems',
    message: ''
  });

  const [loading, setLoading] = useState(false);
  const [responseMsg, setResponseMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setResponseMsg(null);

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const data = await res.json();

      if (res.ok) {
        setResponseMsg({
          type: 'success',
          text: data.message || 'Thank you! HKRION team has received your message.'
        });
        setFormData({
          name: '',
          email: '',
          phone: '',
          service: 'Enterprise ERP & Business Systems',
          message: ''
        });
      } else {
        setResponseMsg({
          type: 'error',
          text: data.error || 'Failed to submit form. Please try again.'
        });
      }
    } catch (err) {
      setResponseMsg({
        type: 'error',
        text: 'Network error. Please try again later.'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="contact" className="py-24 relative bg-black radial-bg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          
          {/* Left Column: Contact Info */}
          <div className="lg:col-span-5 space-y-8">
            <div className="space-y-4">
              <h2 className="text-xs font-semibold uppercase tracking-widest text-[#1ABE56] font-mono">
                GET IN TOUCH
              </h2>
              <h3 className="text-3xl sm:text-5xl font-semibold text-white leading-tight">
                Let&apos;s Build Your Next <span className="gradient-text">Big Idea</span>
              </h3>
              <p className="text-neutral-300 text-base leading-relaxed">
                Ready to digitize your operations or build custom enterprise software? Contact the HKRION team for a consultation and proposal.
              </p>
            </div>

            <div className="space-y-6 pt-4">
              <div className="glass-card p-5 rounded-2xl border border-[#1ABE56]/30 flex items-center gap-4 bg-black/90">
                <div className="w-12 h-12 rounded-xl bg-[#1ABE56]/20 flex items-center justify-center shrink-0">
                  <Mail className="w-6 h-6 text-[#1ABE56]" />
                </div>
                <div>
                  <h4 className="text-xs font-mono uppercase text-neutral-400">Email Us</h4>
                  <p className="text-base font-semibold text-white">hello@hkrion.com</p>
                </div>
              </div>

              <div className="glass-card p-5 rounded-2xl border border-[#1ABE56]/30 flex items-center gap-4 bg-black/90">
                <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center shrink-0">
                  <Phone className="w-6 h-6 text-emerald-400" />
                </div>
                <div>
                  <h4 className="text-xs font-mono uppercase text-neutral-400">Call / WhatsApp</h4>
                  <p className="text-base font-semibold text-white">+94 77 50 14 217</p>
                </div>
              </div>

              <div className="glass-card p-5 rounded-2xl border border-[#1ABE56]/30 flex items-center gap-4 bg-black/90">
                <div className="w-12 h-12 rounded-xl bg-green-500/20 flex items-center justify-center shrink-0">
                  <MapPin className="w-6 h-6 text-green-400" />
                </div>
                <div>
                  <h4 className="text-xs font-mono uppercase text-neutral-400">Headquarters</h4>
                  <p className="text-base font-semibold text-white">HKRION (Pvt) Ltd, Sri Lanka</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Contact Form */}
          <div className="lg:col-span-7">
            <div className="glass-card p-8 sm:p-10 rounded-3xl border border-[#1ABE56]/40 shadow-2xl relative bg-black/95">
              <h4 className="text-2xl font-bold text-white mb-6">Send Us a Message</h4>

              {responseMsg && (
                <div className={`p-4 rounded-xl mb-6 border flex items-center gap-3 ${
                  responseMsg.type === 'success'
                    ? 'bg-[#1ABE56]/20 border-[#1ABE56]/50 text-[#1ABE56]'
                    : 'bg-red-500/10 border-red-500/30 text-red-300'
                }`}>
                  {responseMsg.type === 'success' ? (
                    <CheckCircle2 className="w-5 h-5 shrink-0" />
                  ) : (
                    <AlertCircle className="w-5 h-5 shrink-0" />
                  )}
                  <p className="text-sm font-medium">{responseMsg.text}</p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-mono uppercase text-neutral-300 mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="e.g. John Doe"
                      className="w-full px-4 py-3 rounded-xl bg-black border border-[#1ABE56]/30 text-white placeholder-neutral-500 focus:outline-none focus:border-[#1ABE56] transition-colors text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono uppercase text-neutral-300 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="john@company.com"
                      className="w-full px-4 py-3 rounded-xl bg-black border border-[#1ABE56]/30 text-white placeholder-neutral-500 focus:outline-none focus:border-[#1ABE56] transition-colors text-sm"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-mono uppercase text-neutral-300 mb-2">
                      Phone / WhatsApp
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      placeholder="+94 77..."
                      className="w-full px-4 py-3 rounded-xl bg-black border border-[#1ABE56]/30 text-white placeholder-neutral-500 focus:outline-none focus:border-[#1ABE56] transition-colors text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono uppercase text-neutral-300 mb-2">
                      Service Required *
                    </label>
                    <select
                      name="service"
                      value={formData.service}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-xl bg-black border border-[#1ABE56]/30 text-white focus:outline-none focus:border-[#1ABE56] transition-colors text-sm"
                    >
                      <option value="Enterprise ERP & Business Systems">Enterprise ERP & Business Systems</option>
                      <option value="Custom Web & Mobile Development">Custom Web & Mobile Development</option>
                      <option value="Cloud Infrastructure & DevOps">Cloud Infrastructure & DevOps</option>
                      <option value="AI & Workflow Automation">AI & Workflow Automation</option>
                      <option value="MySQL & Database Solutions">MySQL & Database Solutions</option>
                      <option value="Cybersecurity & Code Auditing">Cybersecurity & Code Auditing</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase text-neutral-300 mb-2">
                    Project Details / Message *
                  </label>
                  <textarea
                    name="message"
                    required
                    rows={4}
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Tell us about your project requirements..."
                    className="w-full px-4 py-3 rounded-xl bg-black border border-[#1ABE56]/30 text-white placeholder-neutral-500 focus:outline-none focus:border-[#1ABE56] transition-colors text-sm resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="glow-btn w-full py-4 rounded-xl text-base font-semibold text-white flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Submitting to MySQL Database...
                    </>
                  ) : (
                    <>
                      Submit Inquiry
                      <Send className="w-4 h-4 ml-1" />
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
