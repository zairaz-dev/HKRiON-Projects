import { PrismaClient } from "@prisma/client";
import { PrismaMariaDb } from "@prisma/adapter-mariadb";
import bcrypt from "bcryptjs";

const adapter = new PrismaMariaDb({
  host: "localhost",
  port: 3306,
  user: "root",
  password: "",
  database: "hrm_db",
});
const prisma = new PrismaClient({ adapter });

async function main() {
  const passwordHash = await bcrypt.hash("Admin@123", 12);

  const superAdmin = await prisma.user.upsert({
    where: { email: "admin@hkrion.com" },
    update: {
      passwordHash,
      role: "SUPER_ADMIN",
    },
    create: {
      firstName: "Super",
      lastName: "Admin",
      email: "admin@hkrion.com",
      passwordHash,
      role: "SUPER_ADMIN",
    },
  });

  console.log(`✅ Super Admin seeded: ${superAdmin.email} (ID: ${superAdmin.id})`);

  const positions = ["Software Engineer", "UIUX", "Social Media Agency"];
  const createdPositions = [];
  for (const title of positions) {
    const position = await prisma.position.upsert({
      where: { title },
      update: {},
      create: { title },
    });
    createdPositions.push(position);
    console.log(`✅ Position seeded: ${position.title} (ID: ${position.id})`);
  }

  // Seed a Manager
  const managerPasswordHash = await bcrypt.hash("Manager@123", 12);
  const manager = await prisma.user.upsert({
    where: { email: "manager@hkrion.com" },
    update: {},
    create: {
      firstName: "Jane",
      lastName: "Manager",
      email: "manager@hkrion.com",
      passwordHash: managerPasswordHash,
      role: "MANAGER",
      positionId: createdPositions[0].id
    },
  });
  console.log(`✅ Manager seeded: ${manager.email}`);

  // Seed some Employees under this Manager
  const employeePasswordHash = await bcrypt.hash("Employee@123", 12);
  const employeesData = [
    { firstName: "John", lastName: "Doe", email: "john@hkrion.com" },
    { firstName: "Alice", lastName: "Smith", email: "alice@hkrion.com" },
    { firstName: "Bob", lastName: "Johnson", email: "bob@hkrion.com" },
  ];

  for (const emp of employeesData) {
    const employee = await prisma.user.upsert({
      where: { email: emp.email },
      update: { managerId: manager.id },
      create: {
        firstName: emp.firstName,
        lastName: emp.lastName,
        email: emp.email,
        passwordHash: employeePasswordHash,
        role: "EMPLOYEE",
        positionId: createdPositions[1].id,
        managerId: manager.id,
      },
    });
    console.log(`✅ Employee seeded: ${employee.email}`);

    // Seed Attendance for today
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Make Alice and John present, Bob absent
    if (emp.firstName !== "Bob") {
      const clockIn = new Date();
      clockIn.setHours(9, 0, 0, 0); // 9 AM
      
      await prisma.attendance.upsert({
        where: { userId_date: { userId: employee.id, date: today } },
        update: {},
        create: {
          userId: employee.id,
          date: today,
          clockIn,
          status: "PRESENT",
        }
      });
    }

    // Seed Pending Leave Requests
    if (emp.firstName === "John") {
      const nextWeekStart = new Date();
      nextWeekStart.setDate(nextWeekStart.getDate() + 7);
      const nextWeekEnd = new Date();
      nextWeekEnd.setDate(nextWeekEnd.getDate() + 9);

      // We don't have a unique constraint on leave requests to upsert by easily,
      // so we'll just check if he has any first.
      const existingLeaves = await prisma.leaveRequest.findMany({ where: { userId: employee.id }});
      if (existingLeaves.length === 0) {
        await prisma.leaveRequest.create({
          data: {
            userId: employee.id,
            startDate: nextWeekStart,
            endDate: nextWeekEnd,
            reason: "Taking a short vacation to the mountains.",
            status: "PENDING"
          }
        });
        console.log(`✅ Leave Request seeded for ${employee.email}`);
      }
    }
  }
}

main()
  .catch((e) => {
    console.error("❌ Seed failed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
