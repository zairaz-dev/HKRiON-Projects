import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { expenseService } from "@/services/expense-service";
import { branchService } from "@/services/branch-service";
import { queryKeys } from "@/lib/query-keys";
import { ExpenseItem } from "../types";

export function useExpensesQuery(
  businessId: string,
  filters: {
    branchId?: string;
    categoryId?: string;
    search?: string;
    page?: number;
    limit?: number;
  } = {},
) {
  return useQuery({
    queryKey: queryKeys.expenses.list(
      businessId,
      filters.branchId,
      filters.categoryId,
      filters.search,
      filters.page,
      filters.limit,
    ),
    queryFn: () => expenseService.getExpenses(businessId, filters),
    enabled: !!businessId,
  });
}

export function useCreateExpenseMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: Parameters<typeof expenseService.createExpense>[0]) =>
      expenseService.createExpense(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.expenses.all });
    },
  });
}

export function useUpdateExpenseMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Parameters<typeof expenseService.updateExpense>[1] }) =>
      expenseService.updateExpense(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.expenses.all });
    },
  });
}

export function useDeleteExpenseMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, businessId }: { id: string; businessId: string }) =>
      expenseService.deleteExpense(id, businessId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.expenses.all });
    },
  });
}

export function useAddExpensePaymentMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({
      expenseId,
      businessId,
      data,
    }: {
      expenseId: string;
      businessId: string;
      data: Parameters<typeof expenseService.addExpensePayment>[2];
    }) => expenseService.addExpensePayment(expenseId, businessId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.expenses.all });
    },
  });
}

export function useDeleteExpensePaymentMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ paymentId, businessId }: { paymentId: string; businessId: string }) =>
      expenseService.deleteExpensePayment(paymentId, businessId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.expenses.all });
    },
  });
}
