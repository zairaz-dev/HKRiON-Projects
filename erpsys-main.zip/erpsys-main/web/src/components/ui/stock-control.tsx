import * as React from "react"
import { Checkbox } from "./checkbox"
import { Input } from "./input"
import { InfoTooltip } from "./info-tooltip"
import { cn } from "@/lib/utils"

export interface StockControlProps {
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
  quantityValue: number;
  onQuantityChange: (value: number) => void;
  disabled?: boolean;
}

/**
 * Redesigned StockControl Component (Manage Stock? + Alert Quantity side-by-side)
 */
export function StockControl({
  checked,
  onCheckedChange,
  quantityValue,
  onQuantityChange,
  disabled = false,
}: StockControlProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full items-center">
      {/* Left Column: Manage Stock Checkbox */}
      <div className="flex items-center space-x-2">
        <Checkbox
          id="manage-stock-checkbox"
          checked={checked}
          onCheckedChange={(val) => !disabled && onCheckedChange(!!val)}
          disabled={disabled}
          className="h-5 w-5 rounded-sm border-input data-[state=checked]:bg-primary data-[state=checked]:text-black"
        />
        <label
          htmlFor="manage-stock-checkbox"
          className={cn(
            "text-xs font-bold uppercase tracking-wider text-foreground flex items-center gap-1.5 cursor-pointer select-none",
            disabled && "cursor-not-allowed"
          )}
        >
          Manage Stock?
        </label>
        <InfoTooltip text="Enable stock management at product level" />
      </div>

      {/* Right Column: Alert Quantity Input (only displayed if checked is true) */}
      <div className="flex flex-col gap-1.5 justify-start">
        {checked ? (
          <div className="space-y-1.5 animate-in fade-in slide-in-from-top-2 duration-200">
            <div className="flex items-center gap-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-foreground">
                Alert Quantity:
              </label>
              <InfoTooltip text="Get low stock alerts when remaining inventory reaches this quantity" />
            </div>
            <Input
              type="number"
              min={0}
              placeholder="Alert quantity"
              value={quantityValue === 0 ? "" : quantityValue}
              onChange={(e) => {
                const val = parseInt(e.target.value, 10);
                onQuantityChange(isNaN(val) ? 0 : val);
              }}
              disabled={disabled}
              className="w-full h-10 bg-background/50 border border-input rounded-sm text-sm"
            />
          </div>
        ) : (
          <div className="hidden sm:block" />
        )}
      </div>
    </div>
  );
}
