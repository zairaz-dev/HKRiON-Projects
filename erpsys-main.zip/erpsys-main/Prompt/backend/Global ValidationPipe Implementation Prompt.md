Act as a Senior NestJS Architect.

Implement Global ValidationPipe in my existing NestJS project.

Requirements:

1. Install required packages if missing:
   - class-validator
   - class-transformer

2. Configure ValidationPipe globally in main.ts.

Use:

app.useGlobalPipes(
new ValidationPipe({
whitelist: true,
transform: true,
forbidNonWhitelisted: true,
transformOptions: {
enableImplicitConversion: true,
},
}),
);

3. Do NOT change any business logic.

4. Ensure all existing DTOs work correctly.

5. Make ValidationPipe production-ready.

6. Explain what each ValidationPipe option does.

7. Generate the updated main.ts.

8. Verify compatibility with NestJS latest version.

9. Generate a report containing:
   - Packages Installed
   - Files Modified
   - Validation Features Enabled
