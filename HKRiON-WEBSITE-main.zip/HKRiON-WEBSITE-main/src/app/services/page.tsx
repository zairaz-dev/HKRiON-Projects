import Navbar from '@/components/Navbar';
import Services from '@/components/Services';
import Industries from '@/components/Industries';
import TechStack from '@/components/TechStack';
import Process from '@/components/Process';
import Footer from '@/components/Footer';
import FloatingWidgets from '@/components/FloatingWidgets';

export const metadata = {
  title: 'Services | HKRION (Pvt) Ltd',
  description: 'Enterprise ERP, IoT Automation, Custom Web & Mobile Development, Digital Marketing, and Cloud Advisory by HKRION (Pvt) Ltd.',
};

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-black text-neutral-100 flex flex-col font-sans">
      <Navbar />
      <main className="grow pt-24">
        
        {/* Dedicated Services Header Banner */}
        <section className="py-20 relative bg-neutral-950 border-b border-[#1ABE56]/30 overflow-hidden">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#1ABE56]/15 blur-[150px] rounded-full pointer-events-none" />
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-4">
            <h1 className="text-4xl sm:text-6xl font-extrabold text-white">
              HKRION <span className="gradient-text">Services & Expertise</span>
            </h1>
            <p className="text-neutral-300 max-w-2xl mx-auto text-base sm:text-lg leading-relaxed">
              We turn complex business challenges into intuitive digital platforms, smart IoT hardware pipelines, and high-growth digital marketing strategies.
            </p>
          </div>
        </section>

        <Services />
        <Industries />
        <TechStack />
        <Process />
      </main>
      <Footer />
      <FloatingWidgets />
    </div>
  );
}
