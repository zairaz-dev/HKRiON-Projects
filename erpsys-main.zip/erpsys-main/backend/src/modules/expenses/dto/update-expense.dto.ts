export class UpdateExpenseDto {
  refNo?: string;
  amount?: number;
  expenseDate?: string | Date;
  paymentStatus?: 'PAID' | 'DUE' | 'PARTIAL';
  amountPaid?: number;
  notes?: string;
  attachmentUrl?: string;
  categoryId?: string;
  branchId?: string;
  businessId: string;
  updatedById?: string;
}
