import React from "react";
import Image from "next/image";
import Link from "next/link";
import { CloseIcon } from "@/components/ui/LuxuryIcons";
import { useCMS } from "@/features/cms/useCMS";
import { AdminTab, AdminUser } from "../types";

interface AdminSidebarProps {
  activeTab: AdminTab;
  setActiveTab: (tab: AdminTab) => void;
  isMobileSidebarOpen: boolean;
  setIsMobileSidebarOpen: (open: boolean) => void;
  gemstonesCount: number;
  activeShipments: number;
  clientsCount: number;
  newInquiriesCount: number;
  adminUser?: AdminUser | null;
  handleLogout?: () => void;
}

export function AdminSidebar({
  activeTab,
  setActiveTab,
  isMobileSidebarOpen,
  setIsMobileSidebarOpen,
  gemstonesCount,
  activeShipments,
  clientsCount,
  newInquiriesCount,
}: AdminSidebarProps) {
  const { getBlock } = useCMS();
  const sidebarLogo = getBlock("branding.footer_logo", getBlock("branding.header_logo", "/faizan-gems-logo.png"));

  const navigationItems = [
    {
      id: "overview" as AdminTab,
      label: "Dashboard",
      href: "/admindashboard",
      icon: ({ active }: { active: boolean }) => (
        <svg className={`w-4 h-4 ${active ? "text-[#C5A880]" : "text-[#8C867D]"}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <rect x="3" y="3" width="7" height="7" />
          <rect x="14" y="3" width="7" height="7" />
          <rect x="14" y="14" width="7" height="7" />
          <rect x="3" y="14" width="7" height="7" />
        </svg>
      ),
    },
    {
      id: "inventory" as AdminTab,
      label: "Inventory",
      href: "/inventory",
      icon: ({ active }: { active: boolean }) => (
        <svg className={`w-4 h-4 ${active ? "text-[#C5A880]" : "text-[#8C867D]"}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M6 3h12l4 6-10 12L2 9l4-6z" />
          <path d="M2 9h20" />
          <path d="M10 3l-2 6 4 12 4-12-2-6" />
        </svg>
      ),
    },
    {
      id: "orders" as AdminTab,
      label: "Orders",
      href: "/orders",
      badge: activeShipments > 0 ? `${activeShipments} Active` : undefined,
      icon: ({ active }: { active: boolean }) => (
        <svg className={`w-4 h-4 ${active ? "text-[#C5A880]" : "text-[#8C867D]"}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <rect x="1" y="4" width="15" height="13" rx="1" />
          <polygon points="16 8 20 8 23 11 23 17 16 17 16 8" />
          <circle cx="5.5" cy="18.5" r="2.5" />
          <circle cx="18.5" cy="18.5" r="2.5" />
        </svg>
      ),
    },
    {
      id: "clients" as AdminTab,
      label: "Customers",
      href: "/clients",
      icon: ({ active }: { active: boolean }) => (
        <svg className={`w-4 h-4 ${active ? "text-[#C5A880]" : "text-[#8C867D]"}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
          <circle cx="9" cy="7" r="4" />
          <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
          <path d="M16 3.13a4 4 0 0 1 0 7.75" />
        </svg>
      ),
    },
    {
      id: "inquiries" as AdminTab,
      label: "Messages & Inquiries",
      href: "/inquiries",
      badge: newInquiriesCount > 0 ? `${newInquiriesCount} New` : undefined,
      icon: ({ active }: { active: boolean }) => (
        <svg className={`w-4 h-4 ${active ? "text-[#C5A880]" : "text-[#8C867D]"}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
        </svg>
      ),
    },
    {
      id: "cms" as AdminTab,
      label: "Settings",
      href: "/cms",
      icon: ({ active }: { active: boolean }) => (
        <svg className={`w-4 h-4 ${active ? "text-[#C5A880]" : "text-[#8C867D]"}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <circle cx="12" cy="12" r="3" />
          <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
        </svg>
      ),
    },
  ];

  return (
    <>
      {/* Mobile Drawer Overlay */}
      {isMobileSidebarOpen && (
        <div
          onClick={() => setIsMobileSidebarOpen(false)}
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm md:hidden"
        />
      )}

      {/* Sidebar Navigation */}
      <aside
        className={`fixed top-0 bottom-0 left-0 h-screen w-64 lg:w-72 bg-[#141419] border-r border-[#24242C] z-50 md:z-40 flex flex-col justify-between transition-transform duration-300 ease-in-out ${isMobileSidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
          }`}
      >
        {/* Sidebar Brand Header */}
        <div className="h-16 shrink-0 px-5 border-b border-[#24242C] flex items-center justify-between">
          <Link
            href="/admindashboard"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab("overview");
              setIsMobileSidebarOpen(false);
            }}
            className="flex items-center group transition-opacity hover:opacity-85"
          >
            <Image
              src={sidebarLogo}
              alt="Faizan Gems"
              width={160}
              height={40}
              className="h-8 w-auto object-contain"
              unoptimized
            />
          </Link>

          {/* Close Button on Mobile */}
          <button
            onClick={() => setIsMobileSidebarOpen(false)}
            className="md:hidden text-[#8C867D] hover:text-white"
          >
            <CloseIcon className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Links */}
        <div className="flex-1 overflow-y-auto px-4 py-6 space-y-1">
          <div className="px-3 pb-2 text-[10px] font-mono uppercase tracking-widest text-[#554F47]">
            Main Menu
          </div>
          {navigationItems.map((item) => {
            const active = activeTab === item.id;
            return (
              <Link
                key={item.id}
                href={item.href}
                onClick={(e) => {
                  e.preventDefault();
                  setActiveTab(item.id);
                  setIsMobileSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-sm text-xs font-sans tracking-wide border-l-2 ${active
                    ? "bg-[#1E1E26] text-[#C5A880] font-medium border-[#C5A880]"
                    : "border-transparent text-[#9E9BA3] hover:text-white hover:bg-[#181820]"
                  }`}
              >
                <div className="flex items-center gap-3">
                  {item.icon({ active })}
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span
                    className={`text-[10px] font-mono tabular-nums px-2 py-0.5 rounded-full ${active
                        ? "bg-[#C5A880]/20 text-[#C5A880] border border-[#C5A880]/30"
                        : "bg-[#202028] text-[#8C867D]"
                      }`}
                  >
                    {item.badge}
                  </span>
                )}
              </Link>
            );
          })}

          <div className="pt-6 px-3 pb-2 text-[10px] font-mono uppercase tracking-widest text-[#554F47]">
            Online Store
          </div>
          <Link
            href="/shop"
            target="_blank"
            className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-sm text-xs text-[#9E9BA3] hover:text-white hover:bg-[#181820] font-sans tracking-wide transition-colors"
          >
            <div className="flex items-center gap-3">
              <svg className="w-4 h-4 text-[#8C867D]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                <polyline points="15 3 21 3 21 9" />
                <line x1="10" y1="14" x2="21" y2="3" />
              </svg>
              <span>View Online Store</span>
            </div>
            <span className="text-[10px] text-[#554F47] uppercase font-mono">&rarr;</span>
          </Link>
        </div>
      </aside>
    </>
  );
}
