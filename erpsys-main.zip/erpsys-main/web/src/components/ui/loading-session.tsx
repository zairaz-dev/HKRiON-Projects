import React from "react";
import { Loader2 } from "lucide-react";

export function LoadingSession() {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center relative overflow-hidden">
      {/* Glowing background effect */}
      <div className="absolute w-[250px] h-[250px] rounded-full bg-primary/10 blur-[100px] animate-pulse" />
      
      <div className="z-10 flex flex-col items-center gap-5">
        {/* Glowing Spinner Container */}
        <div className="relative flex items-center justify-center h-16 w-16">
          {/* Pulsing Outer Ring */}
          <div className="absolute inset-0 rounded-full border-2 border-primary/30 animate-ping opacity-75" />
          
          {/* Main Spinning Loader */}
          <Loader2 className="w-10 h-10 text-primary animate-spin filter drop-shadow-[0_0_10px_rgba(59,130,246,0.5)]" />
        </div>
        
        {/* Animated Texts */}
        <div className="flex flex-col items-center gap-1.5 text-center">
          <h3 className="font-mono text-[11px] font-bold text-foreground tracking-[0.2em] uppercase animate-pulse">
            Loading Session
          </h3>
          <div className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0ms' }} />
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '150ms' }} />
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '300ms' }} />
          </div>
        </div>
      </div>
    </div>
  );
}
