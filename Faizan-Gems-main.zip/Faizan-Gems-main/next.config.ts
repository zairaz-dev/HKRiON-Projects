import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "lh3.googleusercontent.com",
      },
      {
        protocol: "https",
        hostname: "*.googleusercontent.com",
      },
      {
        protocol: "https",
        hostname: "images.unsplash.com",
      },
    ],
  },
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          {
            key: "X-Frame-Options",
            value: "SAMEORIGIN",
          },
          {
            key: "X-Content-Type-Options",
            value: "nosniff",
          },
          {
            key: "Referrer-Policy",
            value: "strict-origin-when-cross-origin",
          },
          {
            key: "Permissions-Policy",
            value: "camera=(), microphone=(), geolocation=()",
          },
        ],
      },
    ];
  },
  async rewrites() {
    return [
      { source: "/Inventory", destination: "/inventory" },
      { source: "/Admindashboard", destination: "/admindashboard" },
      { source: "/Orders", destination: "/orders" },
      { source: "/Clients", destination: "/clients" },
      { source: "/Inquiries", destination: "/inquiries" },
      { source: "/CMS", destination: "/cms" },
      { source: "/VaultSecurity", destination: "/vault-security" },
      { source: "/Security", destination: "/vault-security" },
    ];
  },
};

export default nextConfig;
