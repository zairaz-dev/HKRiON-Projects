export enum Role {
  SUPER_ADMIN = 'super-admin',
  ADMIN = 'admin',
  MANAGER = 'manager',
  CASHIER = 'cashier',
  INVENTORY_MANAGER = 'inventory-manager',
  ACCOUNTANT = 'accountant',
  SALES = 'sales',
}
