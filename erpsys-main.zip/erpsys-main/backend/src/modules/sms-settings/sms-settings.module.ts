import { Module } from '@nestjs/common';
import { SmsSettingsController } from './sms-settings.controller';
import { SmsSettingsService } from './sms-settings.service';
import { PrismaModule } from '../prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [SmsSettingsController],
  providers: [SmsSettingsService],
  exports: [SmsSettingsService],
})
export class SmsSettingsModule {}
