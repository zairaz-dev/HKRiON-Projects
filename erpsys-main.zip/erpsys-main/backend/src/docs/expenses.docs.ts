export const CreateExpenseBodySchema = {
  type: 'object',
  properties: {
    refNo: { type: 'string', example: 'EXP-2026-001' },
    amount: { type: 'number', example: 120.00 },
    expenseDate: { type: 'string', example: '2026-07-09T00:00:00.000Z' },
    paymentStatus: { type: 'string', enum: ['PAID', 'DUE', 'PARTIAL'], example: 'PAID' },
    amountPaid: { type: 'number', example: 120.00 },
    notes: { type: 'string', example: 'Office internet bill' },
    attachmentUrl: { type: 'string', example: '/uploads/expenses/receipt.pdf' },
    categoryId: { type: 'string', example: 'exp-category-uuid' },
    branchId: { type: 'string', example: 'branch-uuid-123' },
    businessId: { type: 'string', example: 'business-uuid-123' },
    createdById: { type: 'string', example: 'user-uuid-123' },
    paymentMethodId: { type: 'string', example: 'pm-cash-uuid' }
  },
  required: ['amount', 'paymentStatus', 'categoryId', 'branchId', 'businessId']
};

export const UpdateExpenseBodySchema = {
  type: 'object',
  properties: {
    refNo: { type: 'string', example: 'EXP-2026-001-REV' },
    amount: { type: 'number', example: 130.00 },
    expenseDate: { type: 'string', example: '2026-07-09T00:00:00.000Z' },
    paymentStatus: { type: 'string', enum: ['PAID', 'DUE', 'PARTIAL'], example: 'PAID' },
    amountPaid: { type: 'number', example: 130.00 },
    notes: { type: 'string', example: 'Internet bill updated' },
    categoryId: { type: 'string', example: 'exp-category-uuid' },
    branchId: { type: 'string', example: 'branch-uuid-123' },
    businessId: { type: 'string', example: 'business-uuid-123' }
  },
  required: ['businessId']
};

export const ExpensePaymentBodySchema = {
  type: 'object',
  properties: {
    amount: { type: 'number', example: 50.00 },
    paymentMethodId: { type: 'string', example: 'pm-cash-uuid' },
    notes: { type: 'string', example: 'Remaining balance payment' },
    paymentDate: { type: 'string', example: '2026-07-09T00:00:00.000Z' }
  },
  required: ['amount', 'paymentMethodId']
};

export const ExpenseResponseSchema = {
  type: 'object',
  properties: {
    id: { type: 'string', example: 'expense-uuid-123' },
    refNo: { type: 'string', example: 'EXP-2026-001' },
    amount: { type: 'number', example: 120.00 },
    paymentStatus: { type: 'string', example: 'PAID' },
    businessId: { type: 'string', example: 'business-uuid-123' }
  }
};
