import AdminDashboard from "@/features/admin/AdminDashboard";

export default function InventoryPage() {
  return <AdminDashboard initialTab="inventory" />;
}
