"use client";

import { useState, useEffect, useCallback } from "react";
import { Gemstone } from "@/types/gemstone";

export const DEFAULT_GEMSTONE_TYPES: string[] = [
  "Sapphire",
  "Ruby",
  "Emerald",
  "Padparadscha",
  "Alexandrite",
  "Tourmaline",
  "Spinel",
  "Aquamarine",
  "Tanzanite",
];

export const DEFAULT_CUTS: string[] = [
  "Baguette",
  "Cushion",
  "Oval",
  "Emerald Cut",
  "Round",
  "Pear",
  "Radiant",
  "Heart",
  "Marquise",
  "Princess",
];

export const DEFAULT_CLARITIES: string[] = [
  "Eye Clean",
  "Flawless",
  "IF",
  "VVS1",
  "VVS2",
  "VS1",
];

export const DEFAULT_TREATMENTS: string[] = [
  "Unheated",
  "Unheated / Untreated",
  "Traditional Minor Heat",
  "Minor Cedar Oil (Insignificant)",
  "Untreated Oil-Free",
];

export type AttributeCategory = "type" | "cut" | "clarity" | "treatment";

const STORAGE_KEY = "faizan_gems_custom_attributes_v2";
const SYNC_EVENT = "faizan-gemstone-attributes-updated";

interface StoredAttributes {
  types?: string[];
  cuts?: string[];
  clarities?: string[];
  treatments?: string[];
}

function formatTitleCase(str: string): string {
  const trimmed = str.trim();
  if (!trimmed) return "";
  // Capitalize first letter of each word if user entered lowercase
  return trimmed
    .split(/\s+/)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

function mergeUnique(base: string[], ...additions: (string[] | undefined)[]): string[] {
  const result = [...base];
  for (const list of additions) {
    if (!Array.isArray(list)) continue;
    for (const item of list) {
      if (!item || typeof item !== "string") continue;
      const formatted = item.trim();
      if (!formatted) continue;
      const exists = result.some(
        (existing) => existing.toLowerCase() === formatted.toLowerCase()
      );
      if (!exists) {
        result.push(formatted);
      }
    }
  }
  return result;
}

function getInitialStored(): StoredAttributes {
  if (typeof window === "undefined") return {};
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function useGemstoneAttributes(gemstones?: Gemstone[]) {
  const [types, setTypes] = useState<string[]>(() => {
    const fromGems = gemstones?.map((g) => g.type).filter(Boolean) as string[] | undefined;
    return mergeUnique(DEFAULT_GEMSTONE_TYPES, fromGems);
  });

  const [cuts, setCuts] = useState<string[]>(() => {
    const fromGems = gemstones?.map((g) => g.cut).filter(Boolean) as string[] | undefined;
    return mergeUnique(DEFAULT_CUTS, fromGems);
  });

  const [clarities, setClarities] = useState<string[]>(() => {
    const fromGems = gemstones?.map((g) => g.clarity).filter(Boolean) as string[] | undefined;
    return mergeUnique(DEFAULT_CLARITIES, fromGems);
  });

  const [treatments, setTreatments] = useState<string[]>(() => {
    const fromGems = gemstones?.map((g) => g.treatment).filter(Boolean) as string[] | undefined;
    return mergeUnique(DEFAULT_TREATMENTS, fromGems);
  });

  // Re-sync attributes if gemstones change or sync event fires
  // Fetch and merge CMS persisted attributes
  const fetchCmsAttributes = useCallback(() => {
    fetch("/api/cms")
      .then((res) => res.json())
      .then((data) => {
        if (!data?.blocks) return;
        const parseJsonList = (val?: string) => {
          if (!val) return [];
          try {
            const parsed = JSON.parse(val);
            return Array.isArray(parsed) ? parsed : [];
          } catch {
            return [];
          }
        };

        const cmsTypes = parseJsonList(data.blocks["inventory.custom_types"]);
        const cmsCuts = parseJsonList(data.blocks["inventory.custom_cuts"]);
        const cmsClarities = parseJsonList(data.blocks["inventory.custom_clarities"]);
        const cmsTreatments = parseJsonList(data.blocks["inventory.custom_treatments"]);

        if (cmsTypes.length) setTypes(cmsTypes);
        if (cmsCuts.length) setCuts(cmsCuts);
        if (cmsClarities.length) setClarities(cmsClarities);
        if (cmsTreatments.length) setTreatments(cmsTreatments);
      })
      .catch(() => {});
  }, []);

  // Re-sync attributes if gemstones change or sync event fires
  const loadAttributes = useCallback(() => {
    const stored = getInitialStored();
    if (stored.types && stored.types.length > 0) setTypes(stored.types);
    if (stored.cuts && stored.cuts.length > 0) setCuts(stored.cuts);
    if (stored.clarities && stored.clarities.length > 0) setClarities(stored.clarities);
    if (stored.treatments && stored.treatments.length > 0) setTreatments(stored.treatments);
    fetchCmsAttributes();
  }, [fetchCmsAttributes]);

  useEffect(() => {
    // Initial load of stored and CMS attributes after mount
    loadAttributes();

    // Listen to sync events across tabs/components
    const handleSync = () => {
      loadAttributes();
    };

    if (typeof window !== "undefined") {
      window.addEventListener(SYNC_EVENT, handleSync);
      window.addEventListener("cms-updated", handleSync);
      window.addEventListener("storage", handleSync);
    }
    return () => {
      if (typeof window !== "undefined") {
        window.removeEventListener(SYNC_EVENT, handleSync);
        window.removeEventListener("cms-updated", handleSync);
        window.removeEventListener("storage", handleSync);
      }
    };
  }, [loadAttributes, fetchCmsAttributes]);

  // Add a new custom attribute
  const addCustomOption = useCallback(
    (category: AttributeCategory, rawValue: string): string | null => {
      const formatted = formatTitleCase(rawValue);
      if (!formatted) return null;

      let updatedList: string[] = [];

      switch (category) {
        case "type": {
          const existing = types.find(
            (t) => t.toLowerCase() === formatted.toLowerCase()
          );
          if (existing) return existing;
          updatedList = [...types, formatted];
          setTypes(updatedList);
          break;
        }
        case "cut": {
          const existing = cuts.find(
            (c) => c.toLowerCase() === formatted.toLowerCase()
          );
          if (existing) return existing;
          updatedList = [...cuts, formatted];
          setCuts(updatedList);
          break;
        }
        case "clarity": {
          const existing = clarities.find(
            (cl) => cl.toLowerCase() === formatted.toLowerCase()
          );
          if (existing) return existing;
          updatedList = [...clarities, formatted];
          setClarities(updatedList);
          break;
        }
        case "treatment": {
          const existing = treatments.find(
            (tr) => tr.toLowerCase() === formatted.toLowerCase()
          );
          if (existing) return existing;
          updatedList = [...treatments, formatted];
          setTreatments(updatedList);
          break;
        }
      }

      // Persist to localStorage
      if (typeof window !== "undefined") {
        try {
          const stored: StoredAttributes = JSON.parse(
            localStorage.getItem(STORAGE_KEY) || "{}"
          );
          const key = (
            category === "type"
              ? "types"
              : category === "cut"
              ? "cuts"
              : category === "clarity"
              ? "clarities"
              : "treatments"
          ) as keyof StoredAttributes;
          stored[key] = updatedList;
          localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));

          // Broadcast to other components
          window.dispatchEvent(
            new CustomEvent(SYNC_EVENT, { detail: { category, action: "add", value: formatted } })
          );
        } catch (err) {
          console.warn("Failed to persist custom attribute to localStorage:", err);
        }
      }

      // Persist to CMS blocks so all admins have access
      const cmsKey = `custom_${category}s`;
      fetch("/api/cms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "block",
          section: "inventory",
          key: cmsKey,
          value: JSON.stringify(updatedList),
        }),
      })
        .then(() => {
          if (typeof window !== "undefined") {
            window.dispatchEvent(new CustomEvent("cms-updated"));
          }
        })
        .catch((err) => {
          console.warn("Failed to persist custom attribute to CMS:", err);
        });

      return formatted;
    },
    [types, cuts, clarities, treatments]
  );

  // Edit an existing attribute
  const editCustomOption = useCallback(
    (category: AttributeCategory, oldValue: string, rawNewValue: string): boolean => {
      const formattedOld = oldValue.trim();
      const formattedNew = formatTitleCase(rawNewValue);
      if (!formattedOld || !formattedNew) return false;

      let currentList: string[] = [];
      let setList: React.Dispatch<React.SetStateAction<string[]>>;

      switch (category) {
        case "type":
          currentList = types;
          setList = setTypes;
          break;
        case "cut":
          currentList = cuts;
          setList = setCuts;
          break;
        case "clarity":
          currentList = clarities;
          setList = setClarities;
          break;
        case "treatment":
          currentList = treatments;
          setList = setTreatments;
          break;
      }

      const oldIndex = currentList.findIndex(
        (item) => item.toLowerCase() === formattedOld.toLowerCase()
      );
      if (oldIndex === -1) return false;

      // Check if new name already exists elsewhere in list
      const alreadyExists = currentList.some(
        (item, idx) => idx !== oldIndex && item.toLowerCase() === formattedNew.toLowerCase()
      );
      if (alreadyExists) return false;

      const updatedList = [...currentList];
      updatedList[oldIndex] = formattedNew;
      setList(updatedList);

      // Persist to localStorage
      if (typeof window !== "undefined") {
        try {
          const stored: StoredAttributes = JSON.parse(
            localStorage.getItem(STORAGE_KEY) || "{}"
          );
          const key = (
            category === "type"
              ? "types"
              : category === "cut"
              ? "cuts"
              : category === "clarity"
              ? "clarities"
              : "treatments"
          ) as keyof StoredAttributes;
          stored[key] = updatedList;
          localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));

          window.dispatchEvent(
            new CustomEvent(SYNC_EVENT, {
              detail: { category, action: "edit", oldValue: formattedOld, newValue: formattedNew },
            })
          );
        } catch (err) {
          console.warn("Failed to persist edited attribute to localStorage:", err);
        }
      }

      // Persist to CMS blocks
      const cmsKey = `custom_${category}s`;
      fetch("/api/cms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "block",
          section: "inventory",
          key: cmsKey,
          value: JSON.stringify(updatedList),
        }),
      })
        .then(() => {
          if (typeof window !== "undefined") {
            window.dispatchEvent(new CustomEvent("cms-updated"));
          }
        })
        .catch((err) => {
          console.warn("Failed to persist edited attribute to CMS:", err);
        });

      return true;
    },
    [types, cuts, clarities, treatments]
  );

  // Delete an existing attribute
  const deleteCustomOption = useCallback(
    (category: AttributeCategory, valueToDelete: string): boolean => {
      const formatted = valueToDelete.trim();
      if (!formatted) return false;

      let currentList: string[] = [];
      let setList: React.Dispatch<React.SetStateAction<string[]>>;

      switch (category) {
        case "type":
          currentList = types;
          setList = setTypes;
          break;
        case "cut":
          currentList = cuts;
          setList = setCuts;
          break;
        case "clarity":
          currentList = clarities;
          setList = setClarities;
          break;
        case "treatment":
          currentList = treatments;
          setList = setTreatments;
          break;
      }

      const updatedList = currentList.filter(
        (item) => item.toLowerCase() !== formatted.toLowerCase()
      );

      // Prevent clearing entire list
      if (updatedList.length === 0) return false;

      setList(updatedList);

      // Persist to localStorage
      if (typeof window !== "undefined") {
        try {
          const stored: StoredAttributes = JSON.parse(
            localStorage.getItem(STORAGE_KEY) || "{}"
          );
          const key = (
            category === "type"
              ? "types"
              : category === "cut"
              ? "cuts"
              : category === "clarity"
              ? "clarities"
              : "treatments"
          ) as keyof StoredAttributes;
          stored[key] = updatedList;
          localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));

          window.dispatchEvent(
            new CustomEvent(SYNC_EVENT, { detail: { category, action: "delete", value: formatted } })
          );
        } catch (err) {
          console.warn("Failed to persist deleted attribute to localStorage:", err);
        }
      }

      // Persist to CMS blocks
      const cmsKey = `custom_${category}s`;
      fetch("/api/cms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "block",
          section: "inventory",
          key: cmsKey,
          value: JSON.stringify(updatedList),
        }),
      })
        .then(() => {
          if (typeof window !== "undefined") {
            window.dispatchEvent(new CustomEvent("cms-updated"));
          }
        })
        .catch((err) => {
          console.warn("Failed to persist deleted attribute to CMS:", err);
        });

      return true;
    },
    [types, cuts, clarities, treatments]
  );

  return {
    types,
    cuts,
    clarities,
    treatments,
    addCustomOption,
    editCustomOption,
    deleteCustomOption,
  };
}
