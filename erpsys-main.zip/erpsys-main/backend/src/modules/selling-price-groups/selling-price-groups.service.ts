import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class SellingPriceGroupsService {
  constructor(private readonly prisma: PrismaService) {}

  async createSellingPriceGroup(data: {
    name: string;
    description?: string;
    isActive?: boolean;
    businessId: string;
    branchIds?: string[];
    createdById?: string;
  }) {
    // 0. Field validations
    const trimmedName = data.name?.trim();
    if (!trimmedName) {
      throw new BadRequestException('Selling price group name is required');
    }
    if (trimmedName.length < 2 || trimmedName.length > 100) {
      throw new BadRequestException('Group name must be between 2 and 100 characters');
    }

    if (!data.businessId || !data.businessId.trim()) {
      throw new BadRequestException('Business ID is required');
    }

    if (data.description && data.description.length > 500) {
      throw new BadRequestException('Description cannot exceed 500 characters');
    }

    // 1. Check for duplicate name in the same business
    const existing = await this.prisma.sellingPriceGroup.findFirst({
      where: {
        name: { equals: trimmedName, mode: 'insensitive' },
        businessId: data.businessId,
      },
    });

    if (existing) {
      throw new BadRequestException('A selling price group with this name already exists in this business');
    }

    // 2. Verify branches belong to the business
    if (data.branchIds && data.branchIds.length > 0) {
      const validBranches = await this.prisma.branch.findMany({
        where: {
          id: { in: data.branchIds },
          businessId: data.businessId,
        },
      });
      if (validBranches.length !== data.branchIds.length) {
        throw new BadRequestException('One or more selected branches are invalid');
      }
    }

    // 3. Create Selling Price Group and its branch connections in a transaction
    return this.prisma.$transaction(async (tx) => {
      const spg = await tx.sellingPriceGroup.create({
        data: {
          name: trimmedName,
          description: data.description ? data.description.trim() : null,
          ...(data.isActive !== undefined && { isActive: data.isActive }),
          businessId: data.businessId,
          createdById: data.createdById || null,
          branches: data.branchIds && data.branchIds.length > 0
            ? {
                create: data.branchIds.map((branchId) => ({
                  branchId,
                })),
              }
            : undefined,
        },
        include: {
          branches: {
            include: {
              branch: true,
            },
          },
        },
      });

      return spg;
    });
  }

  async getSellingPriceGroups(businessId: string, branchId?: string) {
    const whereClause: any = {
      businessId,
    };

    if (branchId) {
      whereClause.OR = [
        { branches: { none: {} } },
        { branches: { some: { branchId } } },
      ];
    }

    return this.prisma.sellingPriceGroup.findMany({
      where: whereClause,
      include: {
        branches: {
          include: {
            branch: {
              select: {
                id: true,
                name: true,
              },
            },
          },
        },
      },
      orderBy: {
        createdAt: 'asc',
      },
    });
  }

  async getSellingPriceGroupById(id: string, businessId: string) {
    const spg = await this.prisma.sellingPriceGroup.findFirst({
      where: { id, businessId },
      include: {
        branches: {
          include: {
            branch: true,
          },
        },
      },
    });

    if (!spg) {
      throw new BadRequestException('Selling price group not found');
    }

    return spg;
  }

  async updateSellingPriceGroup(
    id: string,
    businessId: string,
    data: {
      name?: string;
      description?: string;
      isActive?: boolean;
      branchIds?: string[];
      updatedById?: string;
    },
  ) {
    const spg = await this.getSellingPriceGroupById(id, businessId);

    // 0. Field validations
    let trimmedName: string | undefined = undefined;
    if (data.name !== undefined) {
      trimmedName = data.name.trim();
      if (!trimmedName) {
        throw new BadRequestException('Group name cannot be empty');
      }
      if (trimmedName.length < 2 || trimmedName.length > 100) {
        throw new BadRequestException('Group name must be between 2 and 100 characters');
      }
    }

    if (data.description !== undefined && data.description !== null && data.description.length > 500) {
      throw new BadRequestException('Description cannot exceed 500 characters');
    }

    // 1. Check duplicate name if name is changing
    if (trimmedName && trimmedName.toLowerCase() !== spg.name.toLowerCase()) {
      const existing = await this.prisma.sellingPriceGroup.findFirst({
        where: {
          id: { not: id },
          name: { equals: trimmedName, mode: 'insensitive' },
          businessId,
        },
      });
      if (existing) {
        throw new BadRequestException('A selling price group with this name already exists in this business');
      }
    }

    // 2. Verify branches belong to the business if branchIds are changing
    if (data.branchIds && data.branchIds.length > 0) {
      const validBranches = await this.prisma.branch.findMany({
        where: {
          id: { in: data.branchIds },
          businessId,
        },
      });
      if (validBranches.length !== data.branchIds.length) {
        throw new BadRequestException('One or more selected branches are invalid');
      }
    }

    return this.prisma.$transaction(async (tx) => {
      // 3. Update branches if branchIds are provided
      if (data.branchIds !== undefined) {
        await tx.sellingPriceGroupBranch.deleteMany({
          where: { sellingPriceGroupId: id },
        });

        if (data.branchIds.length > 0) {
          await tx.sellingPriceGroupBranch.createMany({
            data: data.branchIds.map((branchId) => ({
              sellingPriceGroupId: id,
              branchId,
            })),
          });
        }
      }

      // 4. Update Selling Price Group basic fields
      const updateData: any = {};
      if (trimmedName !== undefined) updateData.name = trimmedName;
      if (data.description !== undefined) updateData.description = data.description ? data.description.trim() : null;
      if (data.isActive !== undefined) updateData.isActive = data.isActive;
      if (data.updatedById !== undefined) updateData.updatedById = data.updatedById;

      const updated = await tx.sellingPriceGroup.update({
        where: { id },
        data: updateData,
        include: {
          branches: {
            include: {
              branch: true,
            },
          },
        },
      });

      return updated;
    });
  }

  async deleteSellingPriceGroup(id: string, businessId: string) {
    await this.getSellingPriceGroupById(id, businessId);

    // 1. Check if SPG has configured prices for product variants
    const groupPricesCount = await this.prisma.variantGroupPrice.count({
      where: { sellingPriceGroupId: id },
    });

    if (groupPricesCount > 0) {
      throw new BadRequestException(
        `Cannot delete selling price group because it has price rules configured for ${groupPricesCount} product variant(s). Please remove the price configurations first.`,
      );
    }

    // 2. Check if SPG is assigned to customer groups
    const customerGroupCount = await this.prisma.customerGroup.count({
      where: { sellingPriceGroupId: id },
    });

    if (customerGroupCount > 0) {
      throw new BadRequestException(
        `Cannot delete selling price group because it is assigned to ${customerGroupCount} customer group(s). Please reassign the customer groups first.`,
      );
    }

    await this.prisma.sellingPriceGroup.delete({
      where: { id },
    });

    return { success: true };
  }
}
