import { db } from "@/core/db/client";

export interface CreateInquiryInput {
  customerName: string;
  phone: string;
  email?: string;
  productName?: string;
  message?: string;
  productId?: string;
}

export class InquiryService {
  static async create(data: CreateInquiryInput) {
    return db.inquiry.create({
      data: {
        customerName: data.customerName,
        phone: data.phone,
        email: data.email,
        productName: data.productName,
        message: data.message,
        productId: data.productId,
      },
    });
  }

  static async getAll() {
    return db.inquiry.findMany({
      orderBy: { createdAt: "desc" },
      include: { product: true },
    });
  }
}
