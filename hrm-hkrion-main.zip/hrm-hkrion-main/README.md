# HKRiON Enterprise HRM Dashboard

A modern, highly interactive Human Resource Management (HRM) system built for enterprise scale. Powered by **Next.js 16 (App Router)**, **React 19**, **Tailwind CSS v4**, and the **Prisma ORM**.

## ✨ Core Features

- **Enterprise Architecture**: Fully structured using the `src/` directory, Route Groups `(auth)` and `(dashboard)`, and strict domain-driven component design (`ui/`, `layout/`, `features/`).
- **Role-Based Access Control (RBAC)**: Supports `SUPER_ADMIN`, `MANAGER`, and `EMPLOYEE` roles, each with strict dashboard data boundaries and secure server actions.
- **Interactive Task Management**: A full drag-and-drop Kanban board for assigning, tracking, and prioritizing team tasks.
- **Attendance & Leave Management**: Track clock-ins, clock-outs, and submit/approve leave requests dynamically.
- **Employee Directory**: Complete user management with dynamic profile picture uploads stored via the local file system.
- **Bank-Grade Session Security**: Includes a sleek Inactivity Timer that warns users and auto-logs them out after periods of inactivity.

## 🛠 Prerequisites

- [Node.js](https://nodejs.org/) (v20 or higher recommended)
- [MySQL](https://www.mysql.com/) or [MariaDB](https://mariadb.org/) server running locally or remotely

## 🚀 Getting Started

### 1. Clone the repository

```bash
git clone <your-repo-url>
cd hrm-hkrion
```

### 2. Install dependencies

```bash
npm install 
```

### 3. Environment Setup

Create a `.env` file in the root of the project by copying the example:

```bash
cp "example .env" .env
```
*(On Windows, you can use `copy "example .env" .env`)*

Update your `.env` file with your database URL:
```env
DATABASE_URL="mysql://USER:PASSWORD@HOST:PORT/DATABASE_NAME"
```

### 4. Database Setup

The database schema is managed via Prisma in the `prisma/` directory. 

**Push the schema to your database & generate the client:**
```bash
npx prisma db push
npx prisma generate
```

**Seed the database (Optional):**
To populate the database with initial data (like roles, positions, and a default admin user), run the seed script:
```bash
npx tsx scripts/seed.ts
```

### 5. Run the Development Server

Start the application in development mode:

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to log in and start managing!

## 📁 Project Structure

- `src/app` - Next.js App Router using Route Groups `(auth)` and `(dashboard)`
- `src/actions` - Secure Next.js Server Actions for all database mutations
- `src/components` - Organized into `ui` (base components), `layout` (sidebars/headers), and `features` (role-specific dashboards)
- `src/lib` - Utilities, Zod schemas, DB connections, and JWT session logic
- `prisma/` - Prisma ORM configuration and database schema
- `scripts/` - Utility scripts, including database seeding
- `public/` - Static assets and local profile picture uploads

## 💻 Tech Stack

- **Framework**: [Next.js 16+](https://nextjs.org/) (React 19)
- **Styling**: [Tailwind CSS v4](https://tailwindcss.com/)
- **Database**: MySQL / MariaDB
- **ORM**: [Prisma](https://www.prisma.io/)
- **Icons**: [Lucide React](https://lucide.dev/)
- **Authentication**: Custom JWT implementation via `jose` and `bcryptjs`
