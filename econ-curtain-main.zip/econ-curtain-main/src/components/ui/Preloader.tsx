"use client";

import { useState, useEffect } from "react";
import Logo from "@/components/ui/Logo";

export default function Preloader() {
  const [mounted, setMounted] = useState(true);

  useEffect(() => {
    // Automatically unmount preloader after snappy animation completes (~1.4s)
    const timer = setTimeout(() => {
      setMounted(false);
    }, 1400);

    return () => clearTimeout(timer);
  }, []);

  if (!mounted) return null;

  return (
    <div
      className="fixed inset-0 z-[99999] flex items-center justify-center overflow-hidden animate-venetian-dismiss bg-transparent select-none"
      style={{ pointerEvents: "none" }}
      aria-hidden="true"
    >
      {/* 01. Left Bi-Parting Motorized Glass Shutter Panel */}
      <div 
        className="absolute top-0 bottom-0 left-0 w-1/2 z-10 animate-shutter-left bg-slate-950/85 backdrop-blur-2xl border-r border-amber-400/40 shadow-[15px_0_35px_rgba(0,0,0,0.8)] overflow-hidden"
        style={{ pointerEvents: "none" }}
      >
        {/* Subtle Horizontal Architectural Slat Guidelines */}
        <div className="absolute inset-0 grid grid-rows-12 gap-px opacity-15" style={{ pointerEvents: "none" }}>
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="border-b border-white/20 w-full h-full" />
          ))}
        </div>
        {/* Radial Gold Ambient Glow */}
        <div className="absolute -right-32 top-1/2 -translate-y-1/2 w-64 h-64 rounded-full bg-amber-500/15 blur-3xl" style={{ pointerEvents: "none" }} />
      </div>

      {/* 02. Right Bi-Parting Motorized Glass Shutter Panel */}
      <div 
        className="absolute top-0 bottom-0 right-0 w-1/2 z-10 animate-shutter-right bg-slate-950/85 backdrop-blur-2xl border-l border-amber-400/40 shadow-[-15px_0_35px_rgba(0,0,0,0.8)] overflow-hidden"
        style={{ pointerEvents: "none" }}
      >
        {/* Subtle Horizontal Architectural Slat Guidelines */}
        <div className="absolute inset-0 grid grid-rows-12 gap-px opacity-15" style={{ pointerEvents: "none" }}>
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="border-b border-white/20 w-full h-full" />
          ))}
        </div>
        {/* Radial Emerald Ambient Glow */}
        <div className="absolute -left-32 top-1/2 -translate-y-1/2 w-64 h-64 rounded-full bg-emerald-500/15 blur-3xl" style={{ pointerEvents: "none" }} />
      </div>

      {/* 03. Center Vertical Golden Laser Meeting Seam */}
      <div 
        className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 z-20 w-0.5 bg-linear-to-b from-transparent via-amber-400 to-transparent shadow-[0_0_18px_rgba(234,179,8,1)] animate-laser-seam" 
        style={{ pointerEvents: "none" }}
      />

      {/* 04. Center Brand Stage: Compact Animated Aperture & Ultra-Modern Typography */}
      <div 
        className="absolute inset-0 flex flex-col items-center justify-center z-30 animate-venetian-logo px-4"
        style={{ pointerEvents: "none" }}
      >
        {/* Compact Animated Brand Aperture Icon with Radiant Glow */}
        <div className="relative mb-3">
          <div className="absolute inset-0 rounded-full bg-linear-to-tr from-amber-500/35 to-emerald-500/35 blur-xl animate-pulse" />
          <Logo
            className="w-14 h-14 sm:w-16 sm:h-16 md:w-20 md:h-20 relative z-10 drop-shadow-[0_0_25px_rgba(234,179,8,0.7)]"
            animated={true}
            iconOnly={true}
          />
        </div>

        {/* Refined Ultra-Modern Brand Title */}
        <h1 className="text-base sm:text-lg md:text-xl font-black tracking-[0.25em] text-white font-sans uppercase drop-shadow-lg mb-1">
          <span>SHADEIT</span>
          <span className="text-amber-400 ml-2 font-extrabold">BLINDS</span>
        </h1>

        {/* Subtitle Tagline */}
        <p className="text-[9px] sm:text-[10px] font-semibold tracking-[0.3em] text-slate-300 uppercase drop-shadow-sm mb-3">
          LUXURY ARCHITECTURAL SHADING
        </p>

        {/* Ultra-Modern System Ready Indicator Badge */}
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900/80 border border-amber-500/30 text-[9px] text-amber-300 font-mono tracking-widest backdrop-blur-md shadow-md">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
          <span>MOTORIZED SHADE SYSTEM</span>
        </div>
      </div>
    </div>
  );
}
