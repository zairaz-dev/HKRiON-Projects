import { NextResponse } from 'next/server';
import { updateLeadStatus } from '@/lib/leadsStore';
import { addMessageToConversation } from '@/lib/chatStore';

const EVOLUTION_API_URL = process.env.EVOLUTION_API_URL || 'http://localhost:8080';
const EVOLUTION_API_KEY = process.env.EVOLUTION_API_KEY || '429683C4C977415CAAFCCE10F7D57E11';

export async function POST(req) {
  try {
    const body = await req.json();
    const { 
      instanceName = 'saas_instance', 
      leads = [], 
      messageTemplate = '', 
      delaySeconds = 10,
      isVoicePitch = false 
    } = body;

    if (!Array.isArray(leads) || leads.length === 0) {
      return NextResponse.json({ error: 'No leads selected for campaign' }, { status: 400 });
    }

    if (!messageTemplate || !messageTemplate.trim()) {
      return NextResponse.json({ error: 'Message template is required' }, { status: 400 });
    }

    const results = [];

    for (let i = 0; i < leads.length; i++) {
      const lead = leads[i];
      const targetNumber = (lead.phoneNumber || '').replace(/[^0-9]/g, '');

      if (!targetNumber) {
        results.push({ leadId: lead.id, name: lead.name, status: 'skipped', reason: 'no phone' });
        continue;
      }

      // Replace dynamic tags in template
      const personalizedMessage = messageTemplate
        .replace(/\{business_name\}/gi, lead.name || 'வணிகர்')
        .replace(/\{location\}/gi, lead.location || lead.address || 'உங்கள் பகுதி')
        .replace(/\{category\}/gi, lead.category || 'Restaurant')
        .replace(/\{phone\}/gi, lead.formattedPhone || lead.phoneNumber || '');

      let sentSuccess = false;
      let errorMsg = null;

      try {
        const sendRes = await fetch(`${EVOLUTION_API_URL}/message/sendText/${instanceName}`, {
          method: 'POST',
          headers: {
            'apikey': EVOLUTION_API_KEY,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            number: targetNumber,
            text: personalizedMessage,
          }),
        });

        if (sendRes.ok) {
          sentSuccess = true;
          // Update lead status to Contacted
          if (lead.id) {
            updateLeadStatus(lead.id, 'Contacted', 'POS proposal sent via Campaign');
          }
          // Add to Chat History
          addMessageToConversation({
            senderNumber: targetNumber,
            senderName: lead.name,
            text: personalizedMessage,
            fromMe: true,
            isAi: false,
            status: 'sent',
          });
        } else {
          const errBody = await sendRes.text();
          errorMsg = `Evolution API error (${sendRes.status}): ${errBody}`;
        }
      } catch (err) {
        errorMsg = err.message;
      }

      results.push({
        leadId: lead.id,
        name: lead.name,
        phone: targetNumber,
        status: sentSuccess ? 'sent' : 'failed',
        error: errorMsg,
        message: personalizedMessage,
      });

      // Safe anti-ban delay between messages if more leads remain
      if (i < leads.length - 1 && delaySeconds > 0) {
        await new Promise((r) => setTimeout(r, delaySeconds * 1000));
      }
    }

    const sentCount = results.filter((r) => r.status === 'sent').length;
    const failedCount = results.filter((r) => r.status === 'failed').length;

    return NextResponse.json({
      success: true,
      total: leads.length,
      sentCount,
      failedCount,
      results,
    });
  } catch (err) {
    console.error('[Campaign Dispatcher Exception]:', err);
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
