import { prisma } from "./db";

export async function logAudit(userId: number | null, action: string, details: string) {
  try {
    await prisma.auditLog.create({
      data: {
        userId,
        action,
        details,
      }
    });
  } catch (error) {
    // We swallow the error so that audit logging failure doesn't break the main flow,
    // but in a real production app we'd log this to an external monitoring service.
    console.error("Failed to write audit log:", error);
  }
}
