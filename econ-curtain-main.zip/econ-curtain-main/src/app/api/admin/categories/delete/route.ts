import { NextResponse } from "next/server";
import { CategoryService } from "@/services/category.service";
import { SessionManager } from "@/core/auth/session";
import { SafeHttp } from "@/core/http/redirect";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  try {
    const session = await SessionManager.getCurrentSession();
    if (!session) {
      return SafeHttp.redirect("/login", request, 303);
    }

    const contentType = request.headers.get("content-type") || "";
    const isJson = contentType.includes("application/json");

    let id = "";

    if (isJson) {
      const body = await request.json();
      id = body.id || "";
    } else {
      const formData = await request.formData();
      id = (formData.get("id") as string) || "";
    }

    if (!id) {
      if (isJson) {
        return NextResponse.json({ success: false, error: "Missing Category ID" }, { status: 400 });
      }
      return SafeHttp.redirect("/admin/categories?error=Missing+Category+ID", request, 303);
    }

    await CategoryService.delete(id);

    revalidatePath("/admin/categories");
    revalidatePath("/admin/products");
    revalidatePath("/products");
    revalidatePath("/admin");
    revalidatePath("/");

    if (isJson) {
      return NextResponse.json({ success: true, message: "Category deleted successfully" });
    }

    return SafeHttp.redirect("/admin/categories?success=Category+deleted+successfully!", request, 303);
  } catch (error: unknown) {
    console.error("Failed to delete category:", error);
    return SafeHttp.redirect("/admin/categories?error=Failed+to+delete+category", request, 303);
  }
}
