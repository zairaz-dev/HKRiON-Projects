import * as React from "react"
import { cn } from "@/lib/utils"

export interface BadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: "default" | "success" | "warning" | "error" | "info" | "outline" | "secondary"
}

function Badge({ className, variant = "default", ...props }: BadgeProps) {
  return (
    <div
      className={cn(
        "inline-flex items-center rounded-[6px] px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2",
        {
          "bg-primary-soft text-primary dark:text-primary-hover": variant === "default",
          "bg-success-bg text-success": variant === "success",
          "bg-warning-bg text-warning": variant === "warning",
          "bg-error-bg text-error": variant === "error",
          "bg-info-bg text-info": variant === "info",
          "text-text-primary border border-border": variant === "outline",
          "bg-surface-secondary text-text-secondary border border-transparent": variant === "secondary",
        },
        className
      )}
      {...props}
    />
  )
}

export { Badge }
