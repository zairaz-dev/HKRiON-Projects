import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { verifyToken } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

interface RawJobPosting {
  id: string;
  title: string;
  department: string;
  location: string;
  type: string;
  salary: string;
  badge: string;
  description: string;
  requirements: string;
  responsibilities: string;
  status: string;
  createdAt: Date | string;
}

export async function GET() {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('hkrion_auth_token')?.value;

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const currentUser = await verifyToken(token);
    if (!currentUser || currentUser.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden. Admin access required.' }, { status: 403 });
    }

    let jobs: RawJobPosting[] = [];
    try {
      jobs = await prisma.$queryRaw<RawJobPosting[]>`
        SELECT id, title, department, location, type, salary, badge, description, requirements, responsibilities, status, createdAt
        FROM JobPosting
        ORDER BY createdAt DESC
      `;
    } catch {
      jobs = [];
    }

    const formattedJobs = jobs.map((job) => {
      let parsedReqs: string[] = [];
      let parsedResps: string[] = [];

      try {
        parsedReqs = typeof job.requirements === 'string' ? JSON.parse(job.requirements) : [];
      } catch {
        parsedReqs = job.requirements ? job.requirements.split('\n') : [];
      }

      try {
        parsedResps = typeof job.responsibilities === 'string' ? JSON.parse(job.responsibilities) : [];
      } catch {
        parsedResps = job.responsibilities ? job.responsibilities.split('\n') : [];
      }

      return {
        ...job,
        requirements: parsedReqs,
        responsibilities: parsedResps,
        createdAt: typeof job.createdAt === 'string' ? job.createdAt : new Date(job.createdAt).toISOString(),
      };
    });

    return NextResponse.json({ success: true, jobs: formattedJobs });
  } catch (error) {
    console.error('Error fetching admin jobs:', error);
    return NextResponse.json({ error: 'Failed to fetch jobs' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('hkrion_auth_token')?.value;

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const currentUser = await verifyToken(token);
    if (!currentUser || currentUser.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden. Admin access required.' }, { status: 403 });
    }

    const body = await request.json();
    const {
      title,
      department,
      location,
      type,
      salary,
      badge,
      description,
      requirements,
      responsibilities,
      status,
    } = body;

    if (!title || !department || !location || !salary) {
      return NextResponse.json(
        { error: 'Title, Department, Location, and Salary are required fields.' },
        { status: 400 }
      );
    }

    const id = `job-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const formattedReqs = Array.isArray(requirements) ? JSON.stringify(requirements) : JSON.stringify(requirements ? String(requirements).split('\n').filter(Boolean) : []);
    const formattedResps = Array.isArray(responsibilities) ? JSON.stringify(responsibilities) : JSON.stringify(responsibilities ? String(responsibilities).split('\n').filter(Boolean) : []);
    const jobStatus = status || 'ACTIVE';

    await prisma.$executeRaw`
      INSERT INTO JobPosting (id, title, department, location, type, salary, badge, description, requirements, responsibilities, status, createdBy, updatedBy, createdAt, updatedAt)
      VALUES (${id}, ${title}, ${department}, ${location}, ${type || 'Full-Time'}, ${salary}, ${badge || 'Open Role'}, ${description || ''}, ${formattedReqs}, ${formattedResps}, ${jobStatus}, ${currentUser.id}, ${currentUser.id}, NOW(), NOW())
    `;

    return NextResponse.json({ success: true, message: 'Job opening created successfully', id });
  } catch (error) {
    console.error('Error creating job opening:', error);
    return NextResponse.json({ error: 'Failed to create job opening' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('hkrion_auth_token')?.value;

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const currentUser = await verifyToken(token);
    if (!currentUser || currentUser.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden. Admin access required.' }, { status: 403 });
    }

    const body = await request.json();
    const {
      id,
      title,
      department,
      location,
      type,
      salary,
      badge,
      description,
      requirements,
      responsibilities,
      status,
    } = body;

    if (!id) {
      return NextResponse.json({ error: 'Job ID is required' }, { status: 400 });
    }

    // Toggle status quickly or update full record
    if (status && !title) {
      await prisma.$executeRaw`
        UPDATE JobPosting
        SET status = ${status}, updatedAt = NOW(), updatedBy = ${currentUser.id}
        WHERE id = ${id}
      `;
      return NextResponse.json({ success: true, message: `Hiring status updated to ${status}` });
    }

    const formattedReqs = Array.isArray(requirements) ? JSON.stringify(requirements) : JSON.stringify(requirements ? String(requirements).split('\n').filter(Boolean) : []);
    const formattedResps = Array.isArray(responsibilities) ? JSON.stringify(responsibilities) : JSON.stringify(responsibilities ? String(responsibilities).split('\n').filter(Boolean) : []);

    await prisma.$executeRaw`
      UPDATE JobPosting
      SET title = ${title},
          department = ${department},
          location = ${location},
          type = ${type},
          salary = ${salary},
          badge = ${badge},
          description = ${description},
          requirements = ${formattedReqs},
          responsibilities = ${formattedResps},
          status = ${status || 'ACTIVE'},
          updatedBy = ${currentUser.id},
          updatedAt = NOW()
      WHERE id = ${id}
    `;

    return NextResponse.json({ success: true, message: 'Job opening updated successfully' });
  } catch (error) {
    console.error('Error updating job opening:', error);
    return NextResponse.json({ error: 'Failed to update job opening' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('hkrion_auth_token')?.value;

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const currentUser = await verifyToken(token);
    if (!currentUser || currentUser.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden. Admin access required.' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Job ID parameter is required' }, { status: 400 });
    }

    await prisma.$executeRaw`
      DELETE FROM JobPosting WHERE id = ${id}
    `;

    return NextResponse.json({ success: true, message: 'Job opening deleted successfully' });
  } catch (error) {
    console.error('Error deleting job opening:', error);
    return NextResponse.json({ error: 'Failed to delete job opening' }, { status: 500 });
  }
}
