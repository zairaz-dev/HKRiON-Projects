"use strict";
"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { cmsService, CmsPage } from "@/services/cms-service";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  FileText,
  ShieldCheck,
  Clock,
  ArrowLeft,
  Printer,
  Search,
  Lock,
  Database,
  Key,
  Download,
  Mail,
  Phone,
  Building,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Scale,
  Sparkles,
  Server,
  CreditCard,
} from "lucide-react";

/**
 * Lightweight formatting helper for Markdown content
 */
function MarkdownRenderer({
  content,
  searchFilter = "",
}: {
  content: string;
  searchFilter?: string;
}) {
  const lines = content.split("\n");

  const formatInline = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*|`.*?`)/g);
    return parts.map((part, i) => {
      if (part.startsWith("**") && part.endsWith("**")) {
        return (
          <strong key={i} className="font-bold text-foreground">
            {part.slice(2, -2)}
          </strong>
        );
      }
      if (part.startsWith("`") && part.endsWith("`")) {
        return (
          <code
            key={i}
            className="px-1.5 py-0.5 rounded bg-secondary/80 text-primary font-mono text-[11px]"
          >
            {part.slice(1, -1)}
          </code>
        );
      }
      return part;
    });
  };

  const elements: React.ReactNode[] = [];
  let inList = false;
  let listItems: React.ReactNode[] = [];

  const flushList = () => {
    if (inList && listItems.length > 0) {
      elements.push(
        <ul
          key={`list-${elements.length}`}
          className="space-y-2 my-3 pl-5 list-disc text-xs md:text-sm text-muted-foreground"
        >
          {listItems}
        </ul>
      );
      listItems = [];
      inList = false;
    }
  };

  lines.forEach((line, index) => {
    const trimmed = line.trim();

    if (searchFilter && !trimmed.toLowerCase().includes(searchFilter.toLowerCase())) {
      if (!trimmed.startsWith("#") && trimmed !== "---") return;
    }

    if (trimmed.startsWith("### ")) {
      flushList();
      elements.push(
        <h3
          key={index}
          className="text-sm md:text-base font-bold text-primary mt-6 mb-2 font-mono flex items-center gap-1.5"
        >
          {formatInline(trimmed.replace("### ", ""))}
        </h3>
      );
    } else if (trimmed.startsWith("## ")) {
      flushList();
      elements.push(
        <h2
          key={index}
          className="text-base md:text-lg font-extrabold text-foreground mt-8 mb-3 pb-2 border-b border-border font-mono flex items-center gap-2"
        >
          <Scale className="w-4 h-4 text-primary" />
          {formatInline(trimmed.replace("## ", ""))}
        </h2>
      );
    } else if (trimmed.startsWith("# ")) {
      flushList();
      elements.push(
        <h1
          key={index}
          className="text-xl md:text-2xl font-black text-foreground mb-4 tracking-tight font-mono"
        >
          {formatInline(trimmed.replace("# ", ""))}
        </h1>
      );
    } else if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
      inList = true;
      listItems.push(
        <li key={`item-${index}`} className="leading-relaxed">
          {formatInline(trimmed.replace(/^[-*]\s+/, ""))}
        </li>
      );
    } else if (trimmed === "---") {
      flushList();
      elements.push(<hr key={index} className="my-6 border-border/60" />);
    } else if (trimmed.length > 0) {
      flushList();
      elements.push(
        <p
          key={index}
          className="text-xs md:text-sm text-muted-foreground leading-relaxed my-2.5"
        >
          {formatInline(trimmed)}
        </p>
      );
    }
  });

  flushList();

  return <div className="space-y-1">{elements}</div>;
}

export default function TermsOfServicePage() {
  const [page, setPage] = useState<CmsPage | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeSection, setActiveSection] = useState<string>("");

  const defaultContent = `# HKRION Cloud ERP - Terms of Service & End User License Agreement (EULA)

**Effective Date:** August 31, 2026  
**Operating Entity:** HKRION SYSTEMS (PVT) LTD (Colombo, Sri Lanka)  
**Applicability:** Cloud SaaS Platform, Multi-Branch POS, and Web Management Suite

---

## 1. Acceptance of Terms & Cloud Licensing
By registering an account, purchasing a subscription, or accessing the **HKRION ERP** platform (accessible via web and desktop applications), you ("Tenant", "Customer", or "User") agree to be legally bound by these Terms of Service. If you are entering into this agreement on behalf of a company, retail business, or enterprise entity, you represent that you have the legal authority to bind such entity to these terms.

---

## 2. Multi-Tenant Accounts, Branches & Role Quotas
- **Account Security:** The tenant administrator is responsible for maintaining the confidentiality of login credentials for all branch cashiers, inventory managers, and accountants created under their account.
- **Resource Quotas:** Each subscription tier (Starter, Professional, Enterprise) includes specific resource limits regarding the maximum number of active branches, registered cashier users, product catalog SKUs, and monthly invoices.
- **Usage Limits:** If your operational volume exceeds the designated plan tier limits, the system may prompt you to upgrade your subscription to ensure uninterrupted service.

---

## 3. Subscription Billing, PayHere Gateway & Renewals
- **Billing Frequency:** Subscriptions are billed in advance on either a Monthly or Yearly recurring cycle.
- **Payment Methods:** We accept major credit/debit cards (Visa, Mastercard), FriMi, Genie, eZ Cash via **PayHere.lk** (Licensed by the Central Bank of Sri Lanka), and manual Direct Bank Transfer.
- **Trial Period:** New businesses enjoy a **14-Day Full-Featured Free Trial** with no credit card required at signup.
- **Failed Payments & Grace Period:** In the event of a failed subscription renewal, a 3-day grace period is provided during which the system remains operational to prevent checkout interruption at your retail counters.

---

## 4. 100% Customer Data Ownership & Tenant Isolation
- **Exclusive Ownership:** You retain full, exclusive, and unencumbered ownership of all data, transactions, customer directories, inventory SKUs, and accounting ledgers entered into HKRION ERP.
- **Row-Level Partitioning:** Every tenant's records are cryptographically separated by a unique \`businessId\`. Cross-tenant data access is strictly prohibited and blocked by runtime architecture.
- **Data Portability:** You retain the right to export your complete transactional records, inventory valuations, and financial ledgers to Excel (XLSX) or PDF format at any time.

---

## 5. 99.9% Service Level Agreement (SLA) & Uptime Guarantee
- **Uptime Commitment:** HKRION ERP guarantees a 99.9% application uptime for all core Point of Sale (POS) billing and database synchronization services.
- **Scheduled Maintenance:** Routine server optimizations and software feature updates are scheduled during off-peak retail hours (1:00 AM - 4:00 AM IST) and announced at least 48 hours in advance via the Top Announcement Banner.
- **Emergency Support:** Active paid subscribers have access to 24/7 emergency incident support for business-critical billing outages.

---

## 6. Prohibited Activities & Acceptable Use Policy
You agree not to use the HKRION ERP platform for any unlawful purpose, including but not limited to:
- Attempting to reverse engineer, decompile, or disassemble the platform API, database schemas, or source code.
- Utilizing automated scraping tools, bots, or brute-force mechanisms against authentication endpoints.
- Storing or distributing fraudulent, counterfeit, or illicit inventory items prohibited by Sri Lankan or international law.
- Intentionally overloading, disrupting, or compromising the integrity of our cloud server infrastructure.

---

## 7. Intellectual Property Rights
- The HKRION ERP software, user interface design, logo marks, algorithm architecture, and proprietary documentation are the exclusive intellectual property of **HKRION SYSTEMS (PVT) LTD**.
- This agreement grants you a non-exclusive, non-transferable, revocable cloud software license to use the service for your internal business management during active subscription periods.

---

## 8. Account Termination & Data Retention Grace Period
- **Cancellation:** You may cancel your subscription at any time via the Super Admin / Subscription Manager portal without penalty.
- **30-Day Export Grace Period:** Following subscription cancellation, your account transitions to read-only status for 30 calendar days, allowing you ample time to export all financial archives and customer databases.
- **Permanent Purge:** After 30 days of inactivity following confirmed termination, tenant database partitions are permanently purged in accordance with our Privacy Policy.

---

## 9. Limitation of Liability & Warranty Disclaimers
- HKRION ERP is provided on an "as is" and "as available" basis. While we employ automated multi-region backups, enterprise encryption, and resilient failover architecture, HKRION SYSTEMS (PVT) LTD shall not be liable for indirect, incidental, or consequential damages resulting from third-party internet service provider outages, power cuts, or hardware failures at local store counters.
- Our total aggregate liability under any circumstances is strictly capped at the total subscription fees paid by the tenant in the twelve (12) months preceding the claim.

---

## 10. Governing Law, Legal Jurisdiction & Contact Details
These Terms of Service are governed by and construed in accordance with the laws of the **Democratic Socialist Republic of Sri Lanka**. Any disputes arising under this agreement shall be subject to the exclusive jurisdiction of the commercial courts of Colombo, Sri Lanka.

### 🏢 Official Contact Channels:
- **Operating Entity:** HKRION SYSTEMS (PVT) LTD
- **Headquarters:** Level 14, World Trade Center, Echelon Square, Colombo 00100, Sri Lanka
- **Legal Inquiries:** legal@hkrion.com
- **Billing & Subscriptions:** billing@hkrion.com
- **Direct Hotline:** +94 11 234 5678 / +94 77 123 4567`;

  useEffect(() => {
    cmsService
      .getPageBySlug("terms")
      .then((data) => {
        setPage(data);
      })
      .catch(() => {
        setPage({
          slug: "terms",
          title: "Terms of Service & Cloud SLA",
          metaDescription:
            "Official Terms of Service, End User License Agreement (EULA), and 99.9% Uptime SLA for HKRION Cloud ERP.",
          content: defaultContent,
          isPublished: true,
        });
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, []);

  const handlePrint = () => {
    window.print();
  };

  const sections = [
    { title: "1. Acceptance of Terms", id: "1-acceptance" },
    { title: "2. Accounts & Role Quotas", id: "2-quotas" },
    { title: "3. Subscription Billing & PayHere", id: "3-billing" },
    { title: "4. 100% Data Ownership", id: "4-data" },
    { title: "5. 99.9% Cloud Uptime SLA", id: "5-sla" },
    { title: "6. Prohibited Activities", id: "6-acceptable-use" },
    { title: "7. Intellectual Property", id: "7-ip" },
    { title: "8. Termination & 30-Day Export", id: "8-termination" },
    { title: "9. Limitation of Liability", id: "9-liability" },
    { title: "10. Governing Law (Sri Lanka)", id: "10-governing-law" },
  ];

  return (
    <div className="bg-transparent text-foreground flex flex-col items-center justify-center p-4 sm:p-6 relative">
      <div className="w-full max-w-6xl mt-6 relative z-10 space-y-8 pb-16">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between">
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 text-xs font-mono text-muted-foreground hover:text-primary transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back to Home
          </Link>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrint}
              className="text-xs h-8 px-3 rounded-sm font-bold gap-1.5 border-border bg-card/60 hover:bg-secondary"
            >
              <Printer className="w-3.5 h-3.5 text-primary" /> Print / Save PDF
            </Button>
          </div>
        </div>

        {/* Hero Header */}
        <div className="text-center space-y-3 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-sm bg-primary/10 border border-primary/20 text-primary text-[10px] font-bold tracking-wider uppercase font-mono">
            <Scale className="w-3.5 h-3.5" /> Legal & Cloud User Agreement
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-foreground tracking-tight leading-tight font-mono">
            Terms of Service & <span className="text-primary">Cloud SLA</span>
          </h1>
          <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
            {page?.metaDescription ||
              "Official Terms of Service, End User License Agreement (EULA), Tenant Data Isolation, and 99.9% Uptime SLA for HKRION Cloud ERP."}
          </p>
          <div className="flex items-center justify-center gap-4 text-[11px] font-mono text-muted-foreground pt-1">
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-primary" /> Effective: August 31, 2026
            </span>
            <span>•</span>
            <span className="flex items-center gap-1 text-emerald-400 font-bold">
              <ShieldCheck className="w-3.5 h-3.5" /> 99.9% Uptime SLA
            </span>
            <span>•</span>
            <span>Jurisdiction: Sri Lanka</span>
          </div>
        </div>

        {/* 4 Core Terms Highlights Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-4 space-y-2 hover:border-primary/50 transition-colors">
            <div className="w-8 h-8 rounded-sm bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
              <Database className="w-4 h-4" />
            </div>
            <h4 className="text-xs font-bold text-foreground font-mono">100% Data Ownership</h4>
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              You retain absolute ownership of all inventory SKUs, customer ledgers, and transactions.
            </p>
          </Card>

          <Card className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-4 space-y-2 hover:border-primary/50 transition-colors">
            <div className="w-8 h-8 rounded-sm bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Server className="w-4 h-4" />
            </div>
            <h4 className="text-xs font-bold text-foreground font-mono">99.9% Uptime SLA</h4>
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              Enterprise high-availability architecture guaranteeing non-stop retail checkout.
            </p>
          </Card>

          <Card className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-4 space-y-2 hover:border-primary/50 transition-colors">
            <div className="w-8 h-8 rounded-sm bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <CreditCard className="w-4 h-4" />
            </div>
            <h4 className="text-xs font-bold text-foreground font-mono">Transparent Billing</h4>
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              No hidden fees. Secured by PayHere.lk with 14-day risk-free full-featured free trial.
            </p>
          </Card>

          <Card className="bg-card/40 border border-border/70 backdrop-blur-md rounded-sm p-4 space-y-2 hover:border-primary/50 transition-colors">
            <div className="w-8 h-8 rounded-sm bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
              <Lock className="w-4 h-4" />
            </div>
            <h4 className="text-xs font-bold text-foreground font-mono">Tenant Isolation</h4>
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              Cryptographically verified database boundaries with role-based access control.
            </p>
          </Card>
        </div>

        {/* Main Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Table of Contents Sidebar (4 cols) */}
          <div className="lg:col-span-4 space-y-4 sticky top-6">
            <Card className="bg-card/40 border border-border/80 backdrop-blur-md rounded-sm p-5 space-y-4">
              <div>
                <h3 className="text-xs font-bold text-foreground uppercase tracking-wider font-mono flex items-center gap-2">
                  <FileText className="w-4 h-4 text-primary" /> Table of Contents
                </h3>
                <p className="text-[11px] text-muted-foreground mt-0.5">Quick jump to specific legal clauses</p>
              </div>

              {/* Search Filter */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search in terms (e.g. SLA, PayHere, quota)..."
                  className="pl-9 h-8 text-xs bg-secondary/30 rounded-sm"
                />
              </div>

              <div className="space-y-1 pt-1">
                {sections.map((sec, sIdx) => (
                  <button
                    key={sIdx}
                    onClick={() => {
                      setSearchQuery("");
                      const headings = document.querySelectorAll("h2");
                      const target = Array.from(headings).find((h) =>
                        h.textContent?.toLowerCase().includes(sec.title.toLowerCase().slice(3))
                      );
                      if (target) {
                        target.scrollIntoView({ behavior: "smooth", block: "start" });
                      }
                    }}
                    className="w-full text-left px-2.5 py-1.5 rounded-sm text-xs font-mono text-muted-foreground hover:text-primary hover:bg-secondary/40 transition-colors flex items-center justify-between group"
                  >
                    <span className="truncate">{sec.title}</span>
                    <span className="text-[10px] text-muted-foreground/60 group-hover:text-primary">→</span>
                  </button>
                ))}
              </div>

              <div className="pt-3 border-t border-border/60 text-[11px] text-muted-foreground font-mono space-y-1">
                <div>Operating Company:</div>
                <div className="font-bold text-foreground">HKRION SYSTEMS (PVT) LTD</div>
                <div className="text-[10px]">Colombo 00100, Sri Lanka</div>
              </div>
            </Card>

            {/* Quick Related Links Card */}
            <Card className="bg-card/40 border border-border/80 backdrop-blur-md rounded-sm p-4 space-y-2 text-xs">
              <h4 className="font-bold text-foreground font-mono">Related Legal Policies</h4>
              <ul className="space-y-1.5 text-muted-foreground">
                <li>
                  <Link href="/privacy" className="hover:text-primary transition-colors flex items-center gap-1.5">
                    • Privacy Policy & Data Protection
                  </Link>
                </li>
                <li>
                  <Link href="/refund" className="hover:text-primary transition-colors flex items-center gap-1.5">
                    • Subscription Refund & Dispute Policy
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-primary transition-colors flex items-center gap-1.5">
                    • Contact Enterprise Legal Desk
                  </Link>
                </li>
              </ul>
            </Card>
          </div>

          {/* Right Document Body (8 cols) */}
          <div className="lg:col-span-8">
            <Card className="bg-card/40 border border-border/80 backdrop-blur-md rounded-sm p-6 sm:p-10 shadow-xl">
              {isLoading ? (
                <div className="py-16 text-center text-muted-foreground">
                  <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-primary" />
                  <p className="text-xs font-mono">Loading legal terms agreement...</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <MarkdownRenderer
                    content={page?.content || defaultContent}
                    searchFilter={searchQuery}
                  />

                  {/* Document Footer Verification */}
                  <div className="pt-8 mt-8 border-t border-border/60 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] font-mono text-muted-foreground">
                    <div className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>Legally Verified Document & End User License Agreement</span>
                    </div>
                    <span>HKRION ERP v2.5.0</span>
                  </div>
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
