import { IsOptional, IsString } from 'class-validator';

export class TestAiDto {
  @IsOptional()
  @IsString()
  apiKey?: string;

  @IsOptional()
  @IsString()
  model?: string;
}
