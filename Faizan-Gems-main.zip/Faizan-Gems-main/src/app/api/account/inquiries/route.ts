import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import pool from "@/lib/db";
import { RowDataPacket } from "mysql2";
import {
  verifyCustomerSessionToken,
  CUSTOMER_SESSION_COOKIE_NAME,
} from "@/lib/auth";

export async function GET() {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get(CUSTOMER_SESSION_COOKIE_NAME)?.value;

    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const session = verifyCustomerSessionToken(token);
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const [rows] = await pool.query<RowDataPacket[]>(
      "SELECT * FROM inquiries WHERE email = ? ORDER BY created_at DESC",
      [session.email]
    );

    const inquiries = rows.map((inq) => ({
      id: inq.id,
      date: inq.created_at
        ? new Date(inq.created_at).toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "short",
            year: "numeric",
          })
        : "Recently",
      preferredLocation: inq.preferred_location || inq.preferred_salon || "Trincomalee Flagship Showroom",
      preferredSalon: inq.preferred_location || inq.preferred_salon || "Trincomalee Flagship Showroom",
      status: inq.status || "new",
      message: inq.message || "",
      gemstoneName: inq.gemstone_name,
    }));

    return NextResponse.json({ success: true, inquiries });
  } catch (error) {
    console.error("Account inquiries fetch error:", error);
    return NextResponse.json({ error: "Failed to fetch appointments" }, { status: 500 });
  }
}
