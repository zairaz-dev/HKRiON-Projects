import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import FloatingWidgets from '@/components/FloatingWidgets';
import { blogPosts } from '@/components/BlogSection';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { 
  Calendar, 
  Clock, 
  ArrowLeft, 
  CheckCircle2, 
  Share2, 
  Send, 
  Sparkles,
  BookOpen,
  Award
} from 'lucide-react';

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = blogPosts.find(p => p.slug === slug);
  if (!post) return { title: 'Article Not Found | HKRION' };

  return {
    title: `${post.title} | HKRION Tech Insights`,
    description: post.excerpt,
    keywords: post.tags,
  };
}

export default async function BlogPostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = blogPosts.find(p => p.slug === slug);

  if (!post) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-black text-neutral-100 flex flex-col font-sans selection:bg-[#1ABE56] selection:text-black">
      <Navbar />

      <main className="grow pt-28 pb-24 relative overflow-hidden">
        
        {/* Ambient Glow */}
        <div className="absolute top-20 left-1/2 -translate-x-1/2 w-150 h-150 bg-[#1ABE56]/10 blur-[180px] rounded-full pointer-events-none" />

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-12">
          
          {/* Back to Blog */}
          <div>
            <Link
              href="/blog"
              className="inline-flex items-center gap-2 text-xs font-mono text-neutral-400 hover:text-[#1ABE56] transition-colors bg-neutral-950 px-4 py-2 rounded-xl border border-white/10"
            >
              <ArrowLeft className="w-4 h-4 text-[#1ABE56]" /> Back to All Insights
            </Link>
          </div>

          {/* Article Header */}
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <span className="text-xs font-mono font-bold uppercase tracking-widest text-black bg-[#1ABE56] px-3 py-1 rounded-full shadow-md">
                {post.category}
              </span>
              <span className="text-xs font-mono text-neutral-400 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-[#1ABE56]" /> {post.readTime}
              </span>
              <span className="text-xs font-mono text-neutral-400 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-[#1ABE56]" /> {post.date}
              </span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight leading-tight">
              {post.title}
            </h1>

            {/* Author Bar */}
            <div className="flex items-center justify-between pt-4 border-y border-white/10 py-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#1ABE56] text-black font-bold flex items-center justify-center text-sm shadow-md">
                  {post.author.avatar}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">{post.author.name}</h4>
                  <p className="text-xs text-neutral-400 font-mono">{post.author.role}</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-neutral-400 hidden sm:inline">HKRION Engineering Insight</span>
              </div>
            </div>
          </div>

          {/* Key Takeaways Box */}
          <div className="glass-card p-6 sm:p-8 rounded-3xl border border-[#1ABE56] bg-neutral-950/90 space-y-4">
            <h3 className="text-sm font-mono font-bold text-[#1ABE56] uppercase tracking-widest flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#1ABE56]" /> Executive Summary & Key Takeaways
            </h3>
            <ul className="space-y-2.5 text-xs sm:text-sm font-mono text-neutral-300">
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#1ABE56] shrink-0 mt-0.5" />
                <span>Enterprise software performance directly dictates customer retention & operational uptime.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#1ABE56] shrink-0 mt-0.5" />
                <span>MySQL ACID relational schemas provide bank-grade data integrity for heavy transactional workloads.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#1ABE56] shrink-0 mt-0.5" />
                <span>Modular API architectures allow seamless cloud deployment with zero server bottlenecking.</span>
              </li>
            </ul>
          </div>

          {/* Formatted Article Body Content */}
          <div className="prose prose-invert max-w-none text-neutral-300 space-y-6 text-base leading-relaxed font-sans">
            <p className="text-lg text-white font-medium leading-relaxed">
              {post.excerpt}
            </p>

            <h2 className="text-2xl font-bold text-white pt-4">1. Architectural Foundation & Data Scalability</h2>
            <p>
              When scaling enterprise operations across multiple warehouses or client interfaces, performance bottlenecks frequently occur due to un-indexed relational queries or unoptimized client-side rendering. Implementing server-side rendering (SSR) via Next.js 16 alongside type-safe TypeScript interfaces guarantees that 95% of potential runtime exceptions are caught prior to production deployment.
            </p>

            <div className="p-4 rounded-xl bg-neutral-900 border border-[#1ABE56]/30 font-mono text-xs text-[#1ABE56] space-y-1">
              <p className="text-neutral-400">// HKRION Production Standard Protocol</p>
              <p>SELECT * FROM transactions WHERE tenant_id = ? AND status = &apos;EXECUTED&apos; INDEXED BY idx_tenant_status;</p>
            </div>

            <h2 className="text-2xl font-bold text-white pt-4">2. Real-Time Telemetry & Hardware Security</h2>
            <p>
              In IoT telemetry automation, asynchronous event loops processing MQTT protocol streams ensure that hardware sensors update centralized dashboard state within sub-50ms latency windows. Coupled with role-based access control (RBAC), unauthorized device access is prevented at the edge level.
            </p>

            <h2 className="text-2xl font-bold text-white pt-4">3. Conclusion & Strategic Implementation</h2>
            <p>
              Adopting modern, production-grade frameworks ensures long-term software resilience, security compliance, and effortless scalability as user traffic grows.
            </p>
          </div>

          {/* Article Footer Tags */}
          <div className="pt-6 border-t border-white/10 flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-neutral-400">Tags:</span>
              {post.tags.map((tag, idx) => (
                <span key={idx} className="text-xs font-mono text-[#1ABE56] bg-[#1ABE56]/10 px-2.5 py-1 rounded-lg border border-[#1ABE56]/30">
                  #{tag}
                </span>
              ))}
            </div>

            <Link
              href="/contact"
              className="glow-btn px-6 py-3 rounded-xl text-xs font-bold text-white inline-flex items-center gap-2 cursor-pointer shadow-lg"
            >
              <span>Consult HKRION Architects</span>
              <Send className="w-4 h-4" />
            </Link>
          </div>

        </div>
      </main>

      <Footer />
      <FloatingWidgets />
    </div>
  );
}
