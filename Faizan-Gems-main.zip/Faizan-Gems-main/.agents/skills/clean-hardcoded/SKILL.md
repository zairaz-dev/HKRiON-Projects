---
name: clean-hardcoded
description: >-
  Audits the project for hardcoded values (API URLs, credentials/secrets, phone numbers,
  email addresses, bank details, magic numbers, duplicated arrays, and promo codes) and
  systematically refactors them into environment variables, CMS blocks, or centralized constants.
---

# Clean Hardcoded Values Skill

This skill provides an automated and systematic workflow to audit, categorize, and eliminate hardcoded values across the Faizan Gems codebase.

## Overview & Categorization Matrix

When removing hardcoded values, adhere strictly to this destination hierarchy:

| Category | Typical Values | Destination | Example |
| :--- | :--- | :--- | :--- |
| **Tier 1: Secrets & Env** | DB URLs, API secrets, Auth secrets, Service keys | `.env` & `.env.example` via `process.env.*` | `AUTH_SECRET`, `DATABASE_URL` |
| **Tier 2: Editable Business Copy** | Showroom addresses, phone numbers, contact emails, bank accounts, hero titles | `src/lib/constants/site.ts` -> `DEFAULT_CMS_BLOCKS` / `useCMS()` | `SITE_CONFIG.phone` -> `getBlock("contact.phone", SITE_CONFIG.phone)` |
| **Tier 3: Domain Data & Magic Constants** | Districts lists, country lists, promo codes, fee rates, storage keys | `src/lib/data/` or `src/lib/constants/` | `SRI_LANKA_DISTRICTS`, `PROMO_CODES`, `STORAGE_KEYS` |
| **Tier 4: System URLs & Routing** | Origin URLs, Callback URLs, Ports | `process.env.NEXTAUTH_URL` or `NEXT_PUBLIC_APP_URL` with relative paths | `const origin = process.env.NEXTAUTH_URL \|\| ""` |

---

## Workflow

### Step 1: Run Automated Hardcode Detection

Run the bundled scanner script from the project root:

```bash
node .agents/skills/clean-hardcoded/scripts/detect-hardcoded.mjs
```

Options:
- `--json`: Outputs machine-readable JSON results.
- `--summary`: Shows high-level counts per category.
- `--category=<secrets|contact|banking|data|urls>`: Filters by specific category.

Refer to [patterns.md](./references/patterns.md) for detailed detection heuristics.

---

### Step 2: Extract to Centralized Constants or Data

1. **For Contact and Showroom Information**:
   - Centralize in `src/lib/constants/site.ts`.
   - Update `DEFAULT_CMS_BLOCKS` in `src/features/cms/useCMS.ts` to use `SITE_CONFIG.*` as fallbacks.
   - In UI components, call `useCMS().getBlock(key, SITE_CONFIG.property)`.

2. **For Banking Details**:
   - Centralize in `SITE_CONFIG.banking` in `src/lib/constants/site.ts`.
   - Ensure `checkout/page.tsx` and admin CMS tabs consume the central configuration.

3. **For Duplicated Lists & Geographic Data**:
   - Place in `src/lib/data/` (e.g., `src/lib/data/districts.ts`).
   - Export named constants (`SRI_LANKA_DISTRICTS`).

4. **For Storage Keys & Promo Codes**:
   - Place in `src/lib/constants/storage.ts` and `src/lib/constants/promo.ts`.

---

### Step 3: Refactor References Safely

1. **Client vs Server Components**:
   - Only expose client-safe constants to client components (`"use client"`).
   - Never import server-only secrets or Node.js modules into client files.
   - For public runtime configs needed in client files, use `NEXT_PUBLIC_*` or CMS blocks.

2. **Zero Breaking Changes / Hydration Safety**:
   - When updating localStorage keys, provide fallback reads for legacy keys so existing user carts and wishlists are not wiped:
     ```ts
     const saved = localStorage.getItem(NEW_KEY) || localStorage.getItem(LEGACY_KEY);
     ```
   - Ensure SSR default values match client initial values to prevent hydration warnings.

---

### Step 4: Verification & Validation

After performing refactorings:

1. Re-run the detection script to confirm no rogue hardcoded values remain:
   ```bash
   node .agents/skills/clean-hardcoded/scripts/detect-hardcoded.mjs
   ```
2. Run the Next.js TypeScript and production build:
   ```bash
   pnpm run build
   ```
3. Run the linter:
   ```bash
   pnpm run lint
   ```
