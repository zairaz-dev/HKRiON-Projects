"use strict";
"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import {
  Users,
  UserPlus,
  Edit2,
  Trash2,
  Shield,
  UserCheck,
  CheckCircle,
  AlertCircle,
  XCircle,
  Briefcase,
  Phone,
  MapPin,
  Eye,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { DataTable } from "@/components/ui/table";
import { LoadingSession } from "@/components/ui/loading-session";
import { authService } from "@/services/auth-service";
import { getFullAssetUrl } from "@/lib/utils";
import { User } from "@hkr/types";
import {
  useUsersQuery,
  useRolesQuery,
  useBranchesQuery,
  useToggleUserStatusMutation,
  UserDialog,
  UserDeleteDialog,
} from "@/features/users";

export default function UserManagementPage() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  // Notification states
  const [error, setError] = useState<string>("");
  const [successMessage, setSuccessMessage] = useState<string>("");

  // Dialog states
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState<boolean>(false);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);

  // Authenticate user
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
      return;
    }

    if (user && user.role === "super-admin" && !user.businessId) {
      window.location.href = "/super/users";
    }
  }, []);

  // React Query data fetching
  const businessId = currentUser?.businessId || undefined;
  const { data: users = [], isLoading: usersLoading, error: queryError } = useUsersQuery(businessId);
  const { data: rolesList = [] } = useRolesQuery(businessId);
  const { data: branchesList = [] } = useBranchesQuery(currentUser?.businessId || "", currentUser?.id);

  // Toggle status mutation
  const toggleStatusMutation = useToggleUserStatusMutation();

  // Handle Query errors
  useEffect(() => {
    if (queryError) {
      setError(queryError.message || "Failed to load users.");
    }
  }, [queryError]);

  // Auto-dismiss notifications
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(""), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(""), 6000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  const handleOpenCreateModal = () => {
    setEditingUser(null);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (user: User) => {
    setEditingUser(user);
    setIsModalOpen(true);
  };

  const handleOpenDeleteConfirm = (user: User) => {
    setUserToDelete(user);
    setIsDeleteConfirmOpen(true);
  };

  const handleToggleUserStatus = async (user: User) => {
    if (user.id === currentUser?.id) {
      setError("You cannot deactivate your own logged-in account.");
      return;
    }
    const newStatus = user.isActive === false ? true : false;
    try {
      await toggleStatusMutation.mutateAsync({
        id: user.id,
        isActive: newStatus,
        updatedById: currentUser?.id,
      });
      setSuccessMessage(`User "${user.name}" has been ${newStatus ? "activated" : "deactivated"}.`);
    } catch (err: any) {
      setError(err.message || "Failed to update user status.");
    }
  };

  // Metric computations
  const totalUsersCount = users.length;
  const adminCount = users.filter((u) => u.role === "admin").length;
  const staffCount = totalUsersCount - adminCount;
  const activeRolesCount = rolesList.length;

  // Table columns definition
  const columns = [
    {
      header: "User Profile",
      render: (user: User) => (
        <div className="flex items-center gap-3">
          {user.avatar ? (
            <img
              src={getFullAssetUrl(user.avatar) || user.avatar}
              alt={user.name}
              className="w-10 h-10 sm:w-11 sm:h-11 rounded-full object-cover border border-primary/20 shrink-0 shadow-xs"
              onError={(e) => {
                (e.currentTarget as HTMLElement).style.display = "none";
              }}
            />
          ) : (
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center text-primary font-bold uppercase text-xs sm:text-sm shrink-0">
              {user.name.substring(0, 2)}
            </div>
          )}
          <div className="min-w-0">
            <Link
              href={`/users/view?id=${user.id}`}
              className="font-semibold text-foreground hover:text-primary transition-colors duration-150 truncate block hover:underline"
              title="View user details"
            >
              {user.name}
            </Link>
            <p className="text-[10px] text-muted-foreground mt-0.5 truncate">{user.email}</p>
            {user.address && (
              <p className="text-[9px] text-muted-foreground/70 flex items-center gap-1 mt-0.5 truncate">
                <MapPin className="w-2.5 h-2.5 shrink-0 text-primary/70" /> {user.address}
              </p>
            )}
          </div>
        </div>
      ),
    },
    {
      header: "Contact",
      render: (user: User) => (
        <div>
          {user.phone ? (
            <span className="inline-flex items-center gap-1.5 text-xs font-mono font-medium text-foreground">
              <Phone className="w-3 h-3 text-primary" /> {user.phone}
            </span>
          ) : (
            <span className="text-muted-foreground/50 text-[10px] italic font-mono">No phone</span>
          )}
        </div>
      ),
    },
    {
      header: "Role",
      render: (user: User) => (
        <span
          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-sm text-[10px] font-semibold font-mono border ${
            user.role === "admin" || user.role === "super-admin"
              ? "bg-primary/10 text-primary border-primary/20"
              : "bg-secondary text-secondary-foreground border-border"
          }`}
        >
          {user.role.toUpperCase()}
        </span>
      ),
    },
    {
      header: "Branches",
      render: (user: User) => {
        const isAdmin = user.role === "admin" || user.role === "super-admin";
        if (isAdmin) {
          return (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-sm text-[10px] font-semibold bg-primary/10 text-primary border border-primary/20 font-mono">
              All Branches
            </span>
          );
        }

        if (!user.branches || user.branches.length === 0) {
          return <span className="text-muted-foreground text-[10px] italic">None</span>;
        }

        return (
          <div className="flex flex-wrap gap-1 max-w-[180px]">
            {user.branches.map((b: any) => (
              <span
                key={b.id}
                className="inline-flex items-center px-1.5 py-0.5 rounded-sm text-[9px] bg-secondary text-secondary-foreground border border-border font-mono"
              >
                {b.name}
              </span>
            ))}
          </div>
        );
      },
    },
    {
      header: "Status",
      render: (user: User) => {
        const active = user.isActive !== false;
        return (
          <button
            type="button"
            onClick={() => handleToggleUserStatus(user)}
            disabled={user.id === currentUser?.id}
            title={user.id === currentUser?.id ? "Cannot toggle own status" : "Click to toggle active/inactive status"}
            className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-sm text-[10px] font-mono font-bold border transition-all ${
              active
                ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/25 hover:bg-emerald-500/20"
                : "bg-rose-500/10 text-rose-400 border-rose-500/25 hover:bg-rose-500/20"
            } ${user.id === currentUser?.id ? "cursor-default" : "cursor-pointer"}`}
          >
            <span className={`w-1.5 h-1.5 rounded-full ${active ? "bg-emerald-400 animate-pulse" : "bg-rose-400"}`} />
            {active ? "Active" : "Inactive"}
          </button>
        );
      },
    },
    {
      header: "Last Login",
      render: (user: User) => (
        <div className="space-y-0.5 text-[11px] font-mono">
          {user.lastLoginAt ? (
            <>
              <span className="text-foreground font-medium block">
                {new Date(user.lastLoginAt).toLocaleDateString("en-US", {
                  month: "short",
                  day: "numeric",
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </span>
              {user.lastLoginIp && (
                <span className="text-[10px] text-muted-foreground/80 block">
                  IP: {user.lastLoginIp}
                </span>
              )}
            </>
          ) : (
            <span className="text-muted-foreground/40 text-[10px] italic">Never</span>
          )}
        </div>
      ),
    },
    {
      header: "Actions",
      render: (user: User) => (
        <div className="flex items-center justify-end gap-1.5">
          <Link
            href={`/users/view?id=${user.id}`}
            className="inline-flex items-center justify-center h-8 w-8 rounded-sm border border-input bg-background hover:bg-secondary/40 text-muted-foreground hover:text-primary transition-colors"
            title="View User Details"
          >
            <Eye className="w-3.5 h-3.5" />
          </Link>
          <Button
            variant="outline"
            size="icon"
            onClick={() => handleOpenEditModal(user)}
            className="h-8 w-8 text-muted-foreground hover:text-foreground"
            title="Edit User"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => handleOpenDeleteConfirm(user)}
            className="h-8 w-8 text-muted-foreground hover:text-rose-500"
            title="Delete User"
            disabled={user.id === currentUser?.id}
          >
            <Trash2 className={`w-3.5 h-3.5 ${user.id === currentUser?.id ? "opacity-30 cursor-not-allowed" : ""}`} />
          </Button>
        </div>
      ),
    },
  ];

  if (isAuthenticated === null) {
    return <LoadingSession />;
  }

  if (isAuthenticated === false) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-4 text-center p-4">
        <XCircle className="w-12 h-12 text-destructive animate-bounce" />
        <h2 className="text-xl font-bold text-foreground">Access Denied</h2>
        <p className="text-sm text-muted-foreground max-w-sm">
          You must be signed in to access the User Management page. Redirecting to login page...
        </p>
        <Link href="/login">
          <Button className="mt-2">Go to Login</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="h-screen bg-background text-foreground flex overflow-hidden">
      {/* Sidebar */}
      <Sidebar activePath="/users" />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Navbar */}
        <Navbar title="User Management" />

        {/* Scrollable Main Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2.5">
                <Users className="h-7 w-7 text-primary" /> User Management
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Manage user credentials, business roles, and branch level access rights.
              </p>
            </div>
          </div>

          <div className="w-full space-y-6 pb-8">
            {/* Status Notifications */}
            {successMessage && (
              <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 p-4 rounded-sm text-xs animate-fadeIn">
                <CheckCircle className="w-4 h-4 flex-shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}

            {error && (
              <div className="flex items-center gap-2 bg-rose-500/10 border border-rose-500/20 text-rose-450 p-4 rounded-sm text-xs animate-fadeIn">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Tab Navigation */}
            <div className="flex border-b border-border gap-6">
              <span className="pb-3 text-xs font-semibold text-primary border-b-2 border-primary cursor-default block">
                Users Directory
              </span>
              <Link href="/roles">
                <span className="pb-3 text-xs font-semibold text-muted-foreground hover:text-foreground cursor-pointer transition-colors block">
                  Role Management
                </span>
              </Link>
            </div>

            {/* Stats Overview */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-card/40 backdrop-blur-md border-border/50 shadow-sm">
                <CardContent className="p-6 flex items-center justify-between">
                  <div>
                    <p className="text-[10px] font-semibold text-muted-foreground font-mono uppercase tracking-wider">
                      Total Team
                    </p>
                    <h3 className="text-2xl font-bold text-foreground tracking-tight mt-1">
                      {totalUsersCount}
                    </h3>
                  </div>
                  <div className="p-2 rounded-sm bg-primary/10 text-primary">
                    <Users className="w-5 h-5" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-card/40 backdrop-blur-md border-border/50 shadow-sm">
                <CardContent className="p-6 flex items-center justify-between">
                  <div>
                    <p className="text-[10px] font-semibold text-muted-foreground font-mono uppercase tracking-wider">
                      Admins
                    </p>
                    <h3 className="text-2xl font-bold text-foreground tracking-tight mt-1">
                      {adminCount}
                    </h3>
                  </div>
                  <div className="p-2 rounded-sm bg-primary/10 text-primary">
                    <Shield className="w-5 h-5" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-card/40 backdrop-blur-md border-border/50 shadow-sm">
                <CardContent className="p-6 flex items-center justify-between">
                  <div>
                    <p className="text-[10px] font-semibold text-muted-foreground font-mono uppercase tracking-wider">
                      Other Staff
                    </p>
                    <h3 className="text-2xl font-bold text-foreground tracking-tight mt-1">
                      {staffCount}
                    </h3>
                  </div>
                  <div className="p-2 rounded-sm bg-primary/10 text-primary">
                    <UserCheck className="w-5 h-5" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-card/40 backdrop-blur-md border-border/50 shadow-sm">
                <CardContent className="p-6 flex items-center justify-between">
                  <div>
                    <p className="text-[10px] font-semibold text-muted-foreground font-mono uppercase tracking-wider">
                      Active Roles
                    </p>
                    <h3 className="text-2xl font-bold text-foreground tracking-tight mt-1">
                      {activeRolesCount}
                    </h3>
                  </div>
                  <div className="p-2 rounded-sm bg-primary/10 text-primary">
                    <Briefcase className="w-5 h-5" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Users Data Table */}
            <DataTable
              data={users}
              columns={columns}
              isLoading={usersLoading}
              searchPlaceholder="Search users by name or email..."
              searchKeys={["name", "email"]}
              filterKey="role"
              filterPlaceholder="All Roles"
              filterOptions={rolesList.map((r) => ({ label: r.name, value: r.role }))}
              actionButton={{
                label: "Add New User",
                onClick: handleOpenCreateModal,
                icon: <UserPlus className="w-4 h-4" />,
              }}
              reportTitle="Users Directory Report"
            />
          </div>
        </main>
      </div>

      {/* User Create / Edit Dialog Component */}
      <UserDialog
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        user={editingUser}
        rolesList={rolesList}
        branchesList={branchesList}
        currentUser={currentUser}
        onSuccess={(msg) => setSuccessMessage(msg)}
        onError={(msg) => setError(msg)}
      />

      {/* User Delete Confirmation Dialog Component */}
      <UserDeleteDialog
        isOpen={isDeleteConfirmOpen}
        onClose={() => setIsDeleteConfirmOpen(false)}
        user={userToDelete}
        currentUser={currentUser}
        onSuccess={(msg) => setSuccessMessage(msg)}
        onError={(msg) => setError(msg)}
      />
    </div>
  );
}
