'use client';

import { useState } from 'react';
import Link from 'next/link';
import { 
  Search, 
  Clock, 
  ArrowRight, 
  BookOpen, 
  ChevronRight
} from 'lucide-react';

export interface BlogPost {
  slug: string;
  title: string;
  excerpt: string;
  category: 'ERP & Business' | 'IoT & Hardware' | 'Web & Cloud' | 'Security & Data';
  readTime: string;
  date: string;
  image: string;
  author: {
    name: string;
    role: string;
    avatar: string;
  };
  featured?: boolean;
  tags: string[];
  bannerGradient: string;
}

export const blogPosts: BlogPost[] = [
  {
    slug: 'next-gen-erp-inventory-automation',
    title: 'How Next-Gen ERP Systems Drive 40% Efficiency in Retail & Supply Chains',
    excerpt: 'Explore how real-time inventory tracking, automated HR payroll, and MySQL transactional data vaults eliminate operational bottlenecks for Sri Lankan & global enterprises.',
    category: 'ERP & Business',
    readTime: '5 min read',
    date: 'Jul 28, 2026',
    image: '/blog/erp.png',
    featured: true,
    author: {
      name: 'Ahamed Ilham',
      role: 'Chief Technology Architect',
      avatar: 'AI'
    },
    tags: ['ERP Systems', 'Inventory', 'Automation', 'MySQL Vault'],
    bannerGradient: 'from-emerald-950 via-neutral-950 to-black'
  },
  {
    slug: 'iot-telemetry-smart-factory-automation',
    title: 'Scaling Smart Factories with Real-Time IoT Telemetry & MQTT Gateways',
    excerpt: 'A deep dive into industrial hardware micro-controllers, low-latency WebSocket streams, and threshold alert engines powering modern automated telemetry.',
    category: 'IoT & Hardware',
    readTime: '6 min read',
    date: 'Jul 24, 2026',
    image: '/blog/iot.png',
    author: {
      name: 'Dr. K. Jayasuriya',
      role: 'IoT Hardware Lead',
      avatar: 'KJ'
    },
    tags: ['Industrial IoT', 'MQTT Telemetry', 'Sensors', 'Automation'],
    bannerGradient: 'from-green-950 via-neutral-950 to-black'
  },
  {
    slug: 'nextjs-16-turbopack-enterprise-web',
    title: 'Why Enterprise SaaS Platforms Are Upgrading to Next.js 16 & Server Components',
    excerpt: 'Discover how sub-second server-side rendering (SSR), Turbopack compilation, and strict TypeScript types deliver bank-grade web performance.',
    category: 'Web & Cloud',
    readTime: '4 min read',
    date: 'Jul 20, 2026',
    image: '/blog/nextjs.png',
    author: {
      name: 'R. Perera',
      role: 'Senior Web Architect',
      avatar: 'RP'
    },
    tags: ['Next.js 16', 'React 19', 'TypeScript', 'Turbopack'],
    bannerGradient: 'from-[#1ABE56]/20 via-neutral-950 to-black'
  },
  {
    slug: 'mysql-database-security-hardening',
    title: 'Bank-Grade MySQL Security Hardening: Protecting Relational Data Vaults',
    excerpt: 'Best practices for securing enterprise database schemas, role-based access control (RBAC), end-to-end TLS encryption, and zero-downtime backup pipelines.',
    category: 'Security & Data',
    readTime: '7 min read',
    date: 'Jul 15, 2026',
    image: '/blog/security.png',
    author: {
      name: 'M. S. Farook',
      role: 'Cybersecurity Engineer',
      avatar: 'MF'
    },
    tags: ['MySQL Security', 'Encryption', 'RBAC', 'Cloud Vault'],
    bannerGradient: 'from-emerald-900 via-neutral-950 to-black'
  }
];

export default function BlogSection() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { label: 'All Insights', value: 'all' },
    { label: 'ERP & Business', value: 'ERP & Business' },
    { label: 'IoT & Hardware', value: 'IoT & Hardware' },
    { label: 'Web & Cloud', value: 'Web & Cloud' },
    { label: 'Security & Data', value: 'Security & Data' }
  ];

  const featuredPost = blogPosts.find(post => post.featured) || blogPosts[0];

  const filteredPosts = blogPosts.filter(post => {
    const matchesCategory = selectedCategory === 'all' || post.category === selectedCategory;
    const matchesSearch = post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          post.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  return (
    <section className="py-24 bg-black text-white relative overflow-hidden">
      
      {/* Ambient background glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-150 h-150 bg-[#1ABE56]/10 blur-[180px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-16">
        
        {/* Blog Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
         
          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight">
            Enterprise <span className="gradient-text">Software & Tech Insights</span>
          </h1>
          <p className="text-neutral-300 text-base sm:text-lg leading-relaxed">
            Architectural guides, ERP best practices, IoT telemetry frameworks, and cloud security engineering written by HKRION experts.
          </p>
        </div>

        {/* Featured Article Hero Card */}
        {featuredPost && (
          <div className="glass-card p-6 sm:p-10 rounded-3xl border border-[#1ABE56] bg-linear-to-r from-black via-neutral-950 to-black relative overflow-hidden shadow-2xl shadow-[#1ABE56]/15 group">
            <div className="absolute top-0 right-0 w-96 h-96 bg-[#1ABE56]/15 blur-3xl pointer-events-none" />

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
              
              {/* Featured Image */}
              <div className="lg:col-span-5 relative h-64 sm:h-80 w-full rounded-2xl overflow-hidden border border-[#1ABE56]/40 shadow-lg">
                <img
                  src={featuredPost.image}
                  alt={featuredPost.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-linear-to-t from-black via-transparent to-transparent opacity-60" />
              </div>

              <div className="lg:col-span-7 space-y-4 flex flex-col justify-between h-full">
                <div>
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-xs font-mono font-bold uppercase tracking-widest text-black bg-[#1ABE56] px-3 py-1 rounded-full shadow-md">
                      FEATURED INSIGHT
                    </span>
                    <span className="text-xs font-mono text-[#1ABE56] bg-[#1ABE56]/10 px-3 py-1 rounded-full border border-[#1ABE56]/30">
                      {featuredPost.category}
                    </span>
                  </div>

                  <Link href={`/blog/${featuredPost.slug}`}>
                    <h2 className="text-2xl sm:text-3xl font-extrabold text-white group-hover:text-[#1ABE56] transition-colors leading-tight cursor-pointer">
                      {featuredPost.title}
                    </h2>
                  </Link>

                  <p className="text-neutral-300 text-xs sm:text-sm leading-relaxed font-mono mt-3">
                    {featuredPost.excerpt}
                  </p>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-white/10">
                  <div className="flex items-center gap-3 text-xs font-mono text-neutral-400">
                    <div className="flex items-center gap-2 text-white font-bold">
                      <div className="w-7 h-7 rounded-full bg-[#1ABE56] text-black flex items-center justify-center text-xs font-bold">
                        {featuredPost.author.avatar}
                      </div>
                      <span>{featuredPost.author.name}</span>
                    </div>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-[#1ABE56]" />
                      {featuredPost.readTime}
                    </span>
                  </div>

                  <Link
                    href={`/blog/${featuredPost.slug}`}
                    className="glow-btn px-5 py-2.5 rounded-xl text-xs font-bold text-white flex items-center gap-2 group/btn cursor-pointer shadow-lg shrink-0"
                  >
                    <span>Read Full Article</span>
                    <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* Search & Category Filter Controls */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pt-6 border-t border-neutral-900">
          
          {/* Category Tabs */}
          <div className="flex items-center flex-wrap gap-2 w-full md:w-auto">
            {categories.map((cat) => (
              <button
                key={cat.value}
                onClick={() => setSelectedCategory(cat.value)}
                className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer ${
                  selectedCategory === cat.value
                    ? 'bg-[#1ABE56] text-black shadow-[0_0_20px_#1ABE56] border border-white'
                    : 'bg-neutral-950 text-neutral-400 border border-neutral-800 hover:border-[#1ABE56]/50 hover:text-white'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Search Bar Input */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search ERP, IoT, Cloud guides..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-neutral-950 border border-[#1ABE56]/30 text-white placeholder-neutral-500 text-xs font-mono focus:outline-none focus:border-[#1ABE56]"
            />
          </div>
        </div>

        {/* Blog Posts Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPosts.map((post) => (
            <div
              key={post.slug}
              className="glass-card rounded-3xl border border-[#1ABE56]/30 hover:border-[#1ABE56] bg-neutral-950/90 transition-all duration-300 group flex flex-col justify-between hover:shadow-2xl hover:shadow-[#1ABE56]/20 relative overflow-hidden"
            >
              <div>
                {/* Article Cover Image */}
                <div className="relative h-48 w-full overflow-hidden border-b border-[#1ABE56]/20">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-3 left-3 flex items-center gap-2">
                    <span className="text-[10px] font-mono text-black bg-[#1ABE56] font-bold px-2.5 py-0.5 rounded-full shadow-md">
                      {post.category}
                    </span>
                  </div>
                  <div className="absolute bottom-3 right-3 bg-black/80 backdrop-blur-md text-[10px] font-mono text-[#1ABE56] px-2.5 py-0.5 rounded-full border border-[#1ABE56]/30 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {post.readTime}
                  </div>
                </div>

                <div className="p-6">
                  <Link href={`/blog/${post.slug}`}>
                    <h3 className="text-lg font-bold text-white group-hover:text-[#1ABE56] transition-colors mb-3 leading-snug cursor-pointer line-clamp-2">
                      {post.title}
                    </h3>
                  </Link>

                  <p className="text-xs text-neutral-400 leading-relaxed mb-4 font-mono line-clamp-3">
                    {post.excerpt}
                  </p>
                </div>
              </div>

              <div className="px-6 pb-6 space-y-4">
                {/* Tags */}
                <div className="flex flex-wrap gap-1.5 pt-3 border-t border-white/10">
                  {post.tags.map((tag, tIdx) => (
                    <span key={tIdx} className="text-[10px] font-mono text-neutral-300 bg-neutral-900 px-2 py-0.5 rounded-md border border-white/5">
                      #{tag}
                    </span>
                  ))}
                </div>

                {/* Author & Read Link */}
                <div className="flex items-center justify-between text-xs font-mono pt-1">
                  <div className="flex items-center gap-2 text-neutral-300 font-semibold">
                    <div className="w-6 h-6 rounded-full bg-[#1ABE56]/20 text-[#1ABE56] border border-[#1ABE56]/40 flex items-center justify-center text-[10px] font-bold">
                      {post.author.avatar}
                    </div>
                    <span>{post.author.name}</span>
                  </div>

                  <Link
                    href={`/blog/${post.slug}`}
                    className="text-[#1ABE56] font-bold hover:translate-x-1 transition-transform flex items-center gap-1"
                  >
                    Read <ChevronRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
}

