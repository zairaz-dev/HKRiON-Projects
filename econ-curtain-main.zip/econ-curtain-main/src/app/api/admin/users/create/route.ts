import { NextResponse } from "next/server";
import { UserService } from "@/services/user.service";
import { SessionManager } from "@/core/auth/session";
import { SafeHttp } from "@/core/http/redirect";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  try {
    const session = await SessionManager.getCurrentSession();
    if (!session) {
      return SafeHttp.redirect("/login", request, 303);
    }

    const contentType = request.headers.get("content-type") || "";
    const isJson = contentType.includes("application/json");

    let name = "";
    let email = "";
    let password = "";
    let role = "ADMIN";

    if (isJson) {
      const body = await request.json();
      name = body.name || "";
      email = body.email || "";
      password = body.password || "";
      role = body.role || "ADMIN";
    } else {
      const formData = await request.formData();
      name = (formData.get("name") as string) || "";
      email = (formData.get("email") as string) || "";
      password = (formData.get("password") as string) || "";
      role = (formData.get("role") as string) || "ADMIN";
    }

    if (!name || !email || !password) {
      if (isJson) {
        return NextResponse.json({ success: false, error: "All fields are required" }, { status: 400 });
      }
      return SafeHttp.redirect("/admin/users?error=All+fields+are+required", request, 303);
    }

    if (password.length < 6) {
      if (isJson) {
        return NextResponse.json({ success: false, error: "Password must be at least 6 characters" }, { status: 400 });
      }
      return SafeHttp.redirect("/admin/users?error=Password+must+be+at+least+6+characters", request, 303);
    }

    await UserService.create({
      name,
      email,
      password,
      role,
    });

    revalidatePath("/admin/users");
    revalidatePath("/admin");

    if (isJson) {
      return NextResponse.json({ success: true, message: "User created successfully" });
    }

    return SafeHttp.redirect(`/admin/users?success=${encodeURIComponent(`User "${name}" created successfully!`)}`, request, 303);
  } catch (error: unknown) {
    console.error("Failed to create user:", error);
    const isPrismaError = typeof error === "object" && error !== null && "code" in error && (error as { code: string }).code === "P2002";
    const msg = isPrismaError ? "Email already exists" : "Failed to create user";
    return SafeHttp.redirect(`/admin/users?error=${encodeURIComponent(msg)}`, request, 303);
  }
}
