'use client';
import { useState } from 'react';
import { MessageSquare, Send, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { sendTextMessage } from '@/lib/evolutionApi';

export default function LiveMessenger({ instanceName = 'saas_instance' }) {
  const [recipient, setRecipient] = useState('');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [result, setResult] = useState(null);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!recipient || !message) return;

    setSending(true);
    setResult(null);

    try {
      const res = await sendTextMessage(instanceName, recipient.trim(), message.trim());
      setResult({ success: true, message: `Message sent successfully to ${recipient}!` });
      setMessage('');
    } catch (err) {
      setResult({ success: false, message: err.message || 'Failed to send message' });
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto glass-card rounded-3xl p-6 border border-slate-800 space-y-6">
      <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
        <div className="w-10 h-10 rounded-xl bg-cyan-950/80 border border-cyan-800/50 flex items-center justify-center text-cyan-400">
          <MessageSquare className="w-5 h-5" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white">Live WhatsApp Messenger</h2>
          <p className="text-xs text-slate-400">Send direct test messages via Evolution Baileys API</p>
        </div>
      </div>

      <form onSubmit={handleSendMessage} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1.5">
            Recipient Phone Number (with Country Code)
          </label>
          <input
            type="text"
            value={recipient}
            onChange={(e) => setRecipient(e.target.value)}
            placeholder="e.g. 919876543210"
            className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-sm text-slate-200 outline-none transition-colors font-mono"
            required
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1.5">
            Message Text
          </label>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Type your message here..."
            rows={4}
            className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-sm text-slate-200 outline-none transition-colors"
            required
          />
        </div>

        {result && (
          <div className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
            result.success 
              ? 'bg-emerald-950/50 border border-emerald-800/60 text-emerald-300' 
              : 'bg-rose-950/50 border border-rose-800/60 text-rose-300'
          }`}>
            {result.success ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
            <span>{result.message}</span>
          </div>
        )}

        <button
          type="submit"
          disabled={sending}
          className="w-full emerald-glow-btn text-slate-950 font-bold text-xs py-3 rounded-xl flex items-center justify-center gap-2 transition-all"
        >
          {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4 fill-slate-950" />}
          {sending ? 'Sending Message...' : 'Send Message'}
        </button>
      </form>
    </div>
  );
}
