import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class CustomerPaymentsService {
  constructor(private readonly prisma: PrismaService) {}

  async createPayment(data: {
    amount: number;
    paymentDate?: Date;
    saleId?: string;
    customerId: string;
    paymentMethodId: string;
    branchId: string;
    businessId: string;
    transactionNo?: string;
    notes?: string;
    createdById?: string;
  }) {
    const {
      amount,
      paymentDate,
      saleId,
      customerId,
      paymentMethodId,
      branchId,
      businessId,
      transactionNo,
      notes,
      createdById,
    } = data;

    if (amount <= 0) {
      throw new BadRequestException('Payment amount must be greater than zero.');
    }

    // Verify customer exists
    const customer = await this.prisma.customer.findFirst({
      where: { id: customerId, businessId },
    });
    if (!customer) {
      throw new NotFoundException('Customer not found.');
    }

    // Verify branch exists
    const branch = await this.prisma.branch.findFirst({
      where: { id: branchId, businessId },
    });
    if (!branch) {
      throw new NotFoundException('Branch not found.');
    }

    // Verify payment method exists and is linked to the branch
    const paymentMethodLink = await this.prisma.branchPaymentMethod.findUnique({
      where: {
        branchId_paymentMethodId: {
          branchId,
          paymentMethodId,
        },
      },
    });
    if (!paymentMethodLink) {
      throw new BadRequestException('Payment method is not active or available for this branch.');
    }

    // If sale ID is provided, verify sale exists
    let sale = null;
    if (saleId) {
      sale = await this.prisma.sale.findFirst({
        where: { id: saleId, businessId, customerId },
      });
      if (!sale) {
        throw new NotFoundException('Sale invoice not found or does not belong to this customer.');
      }
      
      const currentDue = sale.grandTotal - sale.amountPaid;
      if (amount > currentDue + 0.01) {
        throw new BadRequestException(`Payment amount (₹${amount}) exceeds the remaining due (₹${currentDue.toFixed(2)}).`);
      }
    }

    // Generate unique payment number PAY-SL-YYYY-XXXX using max sequence
    const year = new Date(paymentDate || new Date()).getFullYear();
    const lastPayment = await this.prisma.salePayment.findFirst({
      where: {
        businessId,
        paymentNumber: {
          startsWith: `PAY-SL-${year}-`,
        },
      },
      orderBy: {
        paymentNumber: 'desc',
      },
    });

    let seqNum = 1;
    if (lastPayment) {
      const parts = lastPayment.paymentNumber.split('-');
      const lastSeq = parseInt(parts[parts.length - 1], 10);
      if (!isNaN(lastSeq)) {
        seqNum = lastSeq + 1;
      }
    }
    const paymentNumber = `PAY-SL-${year}-${String(seqNum).padStart(4, '0')}`;

    return this.prisma.$transaction(async (tx) => {
      if (saleId && sale) {
        // 1. Create a single payment record linked to the sale
        const payment = await tx.salePayment.create({
          data: {
            paymentNumber,
            paymentDate: paymentDate ? new Date(paymentDate) : new Date(),
            amount,
            saleId,
            customerId,
            paymentMethodId,
            branchId,
            businessId,
            transactionNo: transactionNo || null,
            notes: notes || null,
            createdById: createdById || null,
          },
          include: {
            paymentMethod: true,
            customer: true,
            branch: true,
          },
        });

        // 2. Update Sale amountPaid & status
        const newAmountPaid = sale.amountPaid + amount;
        let newStatus = 'PARTIAL';
        if (newAmountPaid >= sale.grandTotal - 0.01) {
          newStatus = 'PAID';
        }

        await tx.sale.update({
          where: { id: saleId },
          data: {
            amountPaid: newAmountPaid,
            paymentStatus: newStatus as any,
          },
        });

        return payment;
      } else {
        // Direct Payment (FIFO Allocation)
        const unpaidSales = await tx.sale.findMany({
          where: {
            customerId,
            businessId,
            status: 'FINAL',
            paymentStatus: { in: ['DUE', 'PARTIAL'] },
          },
          orderBy: {
            saleDate: 'asc',
          },
        });

        let remainingAmount = amount;
        let seqIndex = seqNum;
        const createdPayments = [];

        for (const unpaidSale of unpaidSales) {
          if (remainingAmount <= 0) break;

          const due = unpaidSale.grandTotal - unpaidSale.amountPaid;
          if (due <= 0) continue;

          const allocated = Math.min(due, remainingAmount);
          const splitPaymentNumber = `PAY-SL-${year}-${String(seqIndex).padStart(4, '0')}`;
          seqIndex++;

          const payment = await tx.salePayment.create({
            data: {
              paymentNumber: splitPaymentNumber,
              paymentDate: paymentDate ? new Date(paymentDate) : new Date(),
              amount: allocated,
              saleId: unpaidSale.id,
              customerId,
              paymentMethodId,
              branchId,
              businessId,
              transactionNo: transactionNo || null,
              notes: notes ? `${notes} (Allocated to ${unpaidSale.invoiceNumber})` : `FIFO allocation for invoice ${unpaidSale.invoiceNumber}`,
              createdById: createdById || null,
            },
            include: {
              paymentMethod: true,
              customer: true,
              branch: true,
            },
          });
          createdPayments.push(payment);

          const newAmountPaid = unpaidSale.amountPaid + allocated;
          let newStatus = 'PARTIAL';
          if (newAmountPaid >= unpaidSale.grandTotal - 0.01) {
            newStatus = 'PAID';
          }

          await tx.sale.update({
            where: { id: unpaidSale.id },
            data: {
              amountPaid: newAmountPaid,
              paymentStatus: newStatus as any,
            },
          });

          remainingAmount -= allocated;
        }

        // If there is still remaining amount, FIRST settle customer's opening balance (if any)
        if (remainingAmount > 0 && customer.openingBalance && customer.openingBalance > 0) {
          const openingDue = customer.openingBalance;
          const allocatedToOpening = Math.min(openingDue, remainingAmount);

          // Deduct from openingBalance
          await tx.customer.update({
            where: { id: customerId },
            data: {
              openingBalance: Math.max(0, customer.openingBalance - allocatedToOpening),
            },
          });

          const splitPaymentNumber = `PAY-SL-${year}-${String(seqIndex).padStart(4, '0')}`;
          seqIndex++;

          const payment = await tx.salePayment.create({
            data: {
              paymentNumber: splitPaymentNumber,
              paymentDate: paymentDate ? new Date(paymentDate) : new Date(),
              amount: allocatedToOpening,
              saleId: null,
              customerId,
              paymentMethodId,
              branchId,
              businessId,
              transactionNo: transactionNo || null,
              notes: notes
                ? `${notes} (Paid toward Opening Balance)`
                : 'Settlement of Opening Balance',
              createdById: createdById || null,
            },
            include: {
              paymentMethod: true,
              customer: true,
              branch: true,
            },
          });
          createdPayments.push(payment);

          remainingAmount -= allocatedToOpening;
        }

        // Create remaining unallocated amount as an on-account credit payment & CustomerAdvance
        if (remainingAmount > 0 || createdPayments.length === 0) {
          if (customer.isDefault || customer.name.toLowerCase() === 'walk-in customer') {
            throw new BadRequestException('Advance payments cannot be recorded for Walk-in Customer.');
          }

          const splitPaymentNumber = `PAY-SL-${year}-${String(seqIndex).padStart(4, '0')}`;
          const payment = await tx.salePayment.create({
            data: {
              paymentNumber: splitPaymentNumber,
              paymentDate: paymentDate ? new Date(paymentDate) : new Date(),
              amount: remainingAmount,
              saleId: null,
              customerId,
              paymentMethodId,
              branchId,
              businessId,
              transactionNo: transactionNo || null,
              notes: notes || 'Direct Payment (On-Account / Advance)',
              createdById: createdById || null,
            },
            include: {
              paymentMethod: true,
              customer: true,
              branch: true,
            },
          });
          createdPayments.push(payment);

          // Generate corresponding CustomerAdvance record for advance balance tracking
          const advYear = new Date().getFullYear();
          const lastAdv = await tx.customerAdvance.findFirst({
            where: { businessId, advanceNumber: { startsWith: `CADV-${advYear}-` } },
            orderBy: { advanceNumber: 'desc' },
          });

          let advSeq = 1;
          if (lastAdv) {
            const parts = lastAdv.advanceNumber.split('-');
            const lastSeq = parseInt(parts[parts.length - 1], 10);
            if (!isNaN(lastSeq)) advSeq = lastSeq + 1;
          }
          const advanceNumber = `CADV-${advYear}-${String(advSeq).padStart(4, '0')}`;

          await tx.customerAdvance.create({
            data: {
              advanceNumber,
              advanceDate: paymentDate ? new Date(paymentDate) : new Date(),
              amount: remainingAmount,
              amountRemaining: remainingAmount,
              customerId,
              paymentMethodId,
              branchId,
              businessId,
              transactionNo: transactionNo || null,
              notes: notes ? `${notes} (On-Account / Advance - ${splitPaymentNumber})` : `Direct Advance Payment (${splitPaymentNumber})`,
              createdById: createdById || null,
            },
          });
        }

        return createdPayments[0];
      }
    });
  }

  async getPayments(
    businessId: string,
    filters: {
      branchId?: string;
      customerId?: string;
      saleId?: string;
    },
  ) {
    const { branchId, customerId, saleId } = filters;
    const whereClause: any = { businessId };

    if (branchId) {
      whereClause.branchId = branchId;
    }
    if (customerId) {
      whereClause.customerId = customerId;
    }
    if (saleId) {
      whereClause.saleId = saleId;
    }

    return this.prisma.salePayment.findMany({
      where: whereClause,
      include: {
        paymentMethod: {
          select: {
            id: true,
            name: true,
            code: true,
          },
        },
        customer: {
          select: {
            id: true,
            name: true,
          },
        },
        branch: {
          select: {
            id: true,
            name: true,
          },
        },
      },
      orderBy: {
        paymentDate: 'desc',
      },
    });
  }

  async deletePayment(id: string, businessId: string) {
    const payment = await this.prisma.salePayment.findFirst({
      where: { id, businessId },
      include: {
        customer: true,
      },
    });

    if (!payment) {
      throw new NotFoundException('Payment record not found.');
    }

    if (
      payment.customer &&
      (payment.customer.isDefault ||
        payment.customer.name.toLowerCase() === 'walk-in customer' ||
        payment.customer.allowCredit === false)
    ) {
      throw new BadRequestException(
        'Payments for Walk-in Customer cannot be deleted as credit sales are not permitted. Please process a Sales Return if a refund is required.'
      );
    }

    return this.prisma.$transaction(async (tx) => {
      // If linked to a sale, decrement amountPaid and update status
      if (payment.saleId) {
        const sale = await tx.sale.findUnique({
          where: { id: payment.saleId },
        });

        if (sale) {
          const newAmountPaid = Math.max(0, sale.amountPaid - payment.amount);
          let newStatus = 'PARTIAL';
          if (newAmountPaid <= 0.01) {
            newStatus = 'DUE';
          } else if (newAmountPaid >= sale.grandTotal - 0.01) {
            newStatus = 'PAID';
          }

          await tx.sale.update({
            where: { id: payment.saleId },
            data: {
              amountPaid: newAmountPaid,
              paymentStatus: newStatus as any,
            },
          });
        }
      }

      // If this is an opening balance settlement, restore customer openingBalance
      if (!payment.saleId && payment.notes?.includes('Opening Balance') && payment.customerId) {
        await tx.customer.update({
          where: { id: payment.customerId },
          data: {
            openingBalance: { increment: payment.amount },
          },
        });
      } else if (!payment.saleId) {
        // If this is an advance payment (saleId is null), check and remove matching CustomerAdvance
        const matchingAdvance = await tx.customerAdvance.findFirst({
          where: {
            businessId,
            customerId: payment.customerId,
            amount: payment.amount,
            notes: { contains: payment.paymentNumber },
          },
        });

        if (matchingAdvance) {
          if (matchingAdvance.amountRemaining < matchingAdvance.amount - 0.01) {
            throw new BadRequestException(
              'This advance payment has already been partially or fully used in sales transactions and cannot be deleted.'
            );
          }
          await tx.customerAdvance.delete({
            where: { id: matchingAdvance.id },
          });
        }
      }

      // Delete the payment record
      await tx.salePayment.delete({
        where: { id },
      });

      return { success: true };
    });
  }

  async refundAdvance(data: {
    customerId: string;
    amount: number;
    paymentMethodId: string;
    branchId: string;
    businessId: string;
    notes?: string;
    createdById?: string;
  }) {
    const { customerId, amount, paymentMethodId, branchId, businessId, notes, createdById } = data;

    if (!amount || amount <= 0) {
      throw new BadRequestException('Refund amount must be greater than zero.');
    }

    const customer = await this.prisma.customer.findFirst({
      where: { id: customerId, businessId },
    });

    if (!customer) {
      throw new NotFoundException('Customer record not found.');
    }

    return this.prisma.$transaction(async (tx) => {
      // Find all active advances for this customer with remaining credit in FIFO order
      const advances = await tx.customerAdvance.findMany({
        where: {
          customerId,
          businessId,
          amountRemaining: { gt: 0 },
        },
        orderBy: {
          advanceDate: 'asc',
        },
      });

      const totalAvailable = advances.reduce((sum, a) => sum + a.amountRemaining, 0);

      if (amount > totalAvailable) {
        throw new BadRequestException(
          `Refund amount of ${amount} exceeds the total available advance balance of ${totalAvailable}.`
        );
      }

      let remainingToDeduct = amount;
      const refundDate = new Date();

      for (const advance of advances) {
        if (remainingToDeduct <= 0) break;

        const deduct = Math.min(advance.amountRemaining, remainingToDeduct);
        const newRemaining = Math.max(0, advance.amountRemaining - deduct);

        const refundLog = `Refunded ${deduct} on ${refundDate.toLocaleDateString('en-IN')}${notes ? ` (${notes})` : ''}`;
        const updatedNotes = advance.notes ? `${advance.notes} | ${refundLog}` : refundLog;

        await tx.customerAdvance.update({
          where: { id: advance.id },
          data: {
            amountRemaining: newRemaining,
            notes: updatedNotes,
          },
        });

        remainingToDeduct -= deduct;
      }

      // Generate a refund voucher in sale payments for cash register & audit trail
      const year = new Date().getFullYear();
      const lastPayment = await tx.salePayment.findFirst({
        where: {
          businessId,
          paymentNumber: { startsWith: `REF-CADV-${year}` },
        },
        orderBy: { createdAt: 'desc' },
      });

      let seqNum = 1;
      if (lastPayment && lastPayment.paymentNumber) {
        const parts = lastPayment.paymentNumber.split('-');
        const lastSeq = parseInt(parts[parts.length - 1], 10);
        if (!isNaN(lastSeq)) {
          seqNum = lastSeq + 1;
        }
      }

      const refundNumber = `REF-CADV-${year}-${String(seqNum).padStart(4, '0')}`;

      const refundPayment = await tx.salePayment.create({
        data: {
          paymentNumber: refundNumber,
          paymentDate: refundDate,
          amount: amount,
          saleId: null,
          customerId,
          paymentMethodId,
          branchId,
          businessId,
          notes: notes ? `Customer Advance Refund: ${notes}` : 'Customer Advance Cash Refund',
          createdById: createdById || null,
        },
      });

      return {
        success: true,
        refundNumber,
        refundedAmount: amount,
        remainingTotalAdvance: totalAvailable - amount,
        payment: refundPayment,
      };
    });
  }
}
