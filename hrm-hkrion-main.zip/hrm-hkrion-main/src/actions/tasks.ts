"use server";

import { prisma } from "@/lib/db";
import { getSession } from "@/lib/session";
import { revalidatePath } from "next/cache";
import { CreateTaskSchema, ReviewTaskSchema, UpdateTaskStatusSchema } from "@/lib/schemas";
import { Role, TaskStatus, TaskHealth } from "@prisma/client";

export async function createTask(formData: FormData) {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    if (session.role === Role.EMPLOYEE) {
      return { error: "Employees cannot create tasks." };
    }

    const data = Object.fromEntries(formData.entries());
    
    // Parse arrays that come as JSON strings from the client
    const parsedData = {
      ...data,
      assigneeIds: data.assigneeIds ? JSON.parse(data.assigneeIds as string) : undefined,
      dependencies: data.dependencies ? JSON.parse(data.dependencies as string) : undefined,
      milestones: data.milestones ? JSON.parse(data.milestones as string) : undefined,
    };

    const parsed = CreateTaskSchema.safeParse(parsedData);

    if (!parsed.success) {
      const err = parsed.error as any;
      return { error: err.issues[0].message };
    }

    const { 
      title, description, deliverables, instructions, category, 
      priority, startDate, dueDate, deadline, assigneeIds, dependencies, milestones 
    } = parsed.data;

    let taskId: number | undefined;

    await prisma.$transaction(async (tx) => {
      const task = await tx.task.create({
        data: {
          title,
          description: description || null,
          deliverables: deliverables || null,
          instructions: instructions || null,
          category: category || null,
          status: TaskStatus.PENDING,
          health: TaskHealth.NOT_STARTED,
          priority: priority,
          startDate: startDate ? new Date(startDate) : null,
          dueDate: dueDate ? new Date(dueDate) : null,
          deadline: deadline ? new Date(deadline) : null,
          assignerId: session.userId,
          
          assignees: assigneeIds && assigneeIds.length > 0 
            ? { connect: assigneeIds.map(id => ({ id })) } 
            : undefined,
            
          dependencies: dependencies && dependencies.length > 0
            ? { connect: dependencies.map(id => ({ id })) }
            : undefined,
            
          milestones: milestones && milestones.length > 0
            ? { create: milestones.map(m => ({ title: m })) }
            : undefined,
        },
        include: {
          assignees: true,
        },
      });

      taskId = task.id;

      // Create Audit Log
      await tx.auditLog.create({
        data: {
          userId: session.userId,
          action: "CREATE_TASK",
          details: `Created and assigned task #${task.id}: "${task.title}"`,
        },
      });

      // Create Notifications for assignees
      if (task.assignees && task.assignees.length > 0) {
        await tx.notification.createMany({
          data: task.assignees.map(a => ({
            userId: a.id,
            title: "New Task Assigned",
            message: `You were assigned task #${task.id}: "${task.title}" (Priority: ${task.priority})`,
            link: `/dashboard/tasks/${task.id}`,
          })),
        });
      }
    });

    revalidatePath("/dashboard/tasks");
    return { success: true, taskId };
  } catch (error) {
    console.error("Failed to create task:", error);
    return { error: "Failed to create task" };
  }
}

export async function startTask(taskId: number) {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    const task = await prisma.task.findUnique({
      where: { id: taskId },
      include: { assignees: true },
    });

    if (!task) return { error: "Task not found." };

    const isAssignee = task.assignees.some(a => a.id === session.userId);
    const isManagerOrAdmin = session.role === Role.MANAGER || session.role === Role.SUPER_ADMIN || task.assignerId === session.userId;

    if (!isAssignee && !isManagerOrAdmin) {
      return { error: "You are not authorized to start this task." };
    }

    await prisma.$transaction(async (tx) => {
      await tx.task.update({
        where: { id: taskId },
        data: {
          status: TaskStatus.IN_PROGRESS,
          health: TaskHealth.ON_TRACK,
          progress: task.progress === 0 ? 10 : task.progress,
        },
      });

      const author = await tx.user.findUnique({
        where: { id: session.userId },
        select: { firstName: true, lastName: true },
      });
      const authorName = author ? `${author.firstName} ${author.lastName}` : "Assignee";

      await tx.taskUpdate.create({
        data: {
          taskId,
          authorId: session.userId,
          type: "SYSTEM",
          content: `Task started by ${authorName}. Status changed to IN PROGRESS.`,
          progressSnapshot: task.progress === 0 ? 10 : task.progress,
          healthSnapshot: TaskHealth.ON_TRACK,
        },
      });

      if (task.assignerId !== session.userId) {
        await tx.notification.create({
          data: {
            userId: task.assignerId,
            title: "Task Started",
            message: `${authorName} started working on task #${task.id}: "${task.title}".`,
            link: `/dashboard/tasks/${task.id}`,
          },
        });
      }
    });

    revalidatePath(`/dashboard/tasks/${taskId}`);
    revalidatePath("/dashboard/tasks");
    return { success: true };
  } catch (error) {
    console.error("Failed to start task:", error);
    return { error: "Failed to start task." };
  }
}

export async function submitTaskForReview(taskId: number, submissionNotes?: string) {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    const task = await prisma.task.findUnique({
      where: { id: taskId },
      include: { assignees: true },
    });

    if (!task) return { error: "Task not found." };

    const isAssignee = task.assignees.some(a => a.id === session.userId);
    const isManagerOrAdmin = session.role === Role.MANAGER || session.role === Role.SUPER_ADMIN || task.assignerId === session.userId;

    if (!isAssignee && !isManagerOrAdmin) {
      return { error: "You are not authorized to submit this task." };
    }

    await prisma.$transaction(async (tx) => {
      await tx.task.update({
        where: { id: taskId },
        data: {
          status: TaskStatus.UNDER_REVIEW,
          health: TaskHealth.WAITING_REVIEW,
          progress: 100,
          submittedAt: new Date(),
        },
      });

      const author = await tx.user.findUnique({
        where: { id: session.userId },
        select: { firstName: true, lastName: true },
      });
      const authorName = author ? `${author.firstName} ${author.lastName}` : "Assignee";

      const noteText = submissionNotes?.trim() 
        ? `\n\n**Submission Notes:**\n${submissionNotes.trim()}`
        : "";

      await tx.taskUpdate.create({
        data: {
          taskId,
          authorId: session.userId,
          type: "PROGRESS",
          content: `Task submitted for Manager Review by ${authorName}.${noteText}`,
          progressSnapshot: 100,
          healthSnapshot: TaskHealth.WAITING_REVIEW,
        },
      });

      // Notify task assigner / creator
      if (task.assignerId !== session.userId) {
        await tx.notification.create({
          data: {
            userId: task.assignerId,
            title: "Task Submitted for Review",
            message: `${authorName} submitted task #${task.id}: "${task.title}" for your approval.`,
            link: `/dashboard/tasks/${task.id}`,
          },
        });
      }
    });

    revalidatePath(`/dashboard/tasks/${taskId}`);
    revalidatePath("/dashboard/tasks");
    return { success: true };
  } catch (error) {
    console.error("Failed to submit task for review:", error);
    return { error: "Failed to submit task for review." };
  }
}

export async function reviewTask(taskId: number, formData: FormData) {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    if (session.role === Role.EMPLOYEE) {
      return { error: "Only managers and admins can review tasks." };
    }

    const data = Object.fromEntries(formData.entries());
    const parsed = ReviewTaskSchema.safeParse(data);

    if (!parsed.success) {
      return { error: parsed.error.issues[0].message };
    }

    const { action, reviewNotes } = parsed.data;

    const task = await prisma.task.findUnique({
      where: { id: taskId },
      include: { assignees: true },
    });

    if (!task) return { error: "Task not found." };

    const reviewer = await prisma.user.findUnique({
      where: { id: session.userId },
      select: { firstName: true, lastName: true },
    });
    const reviewerName = reviewer ? `${reviewer.firstName} ${reviewer.lastName}` : "Manager";

    await prisma.$transaction(async (tx) => {
      if (action === "APPROVE") {
        await tx.task.update({
          where: { id: taskId },
          data: {
            status: TaskStatus.COMPLETED,
            health: TaskHealth.ON_TRACK,
            progress: 100,
            reviewedAt: new Date(),
            completedAt: new Date(),
            reviewNotes: reviewNotes || null,
          },
        });

        await tx.taskUpdate.create({
          data: {
            taskId,
            authorId: session.userId,
            type: "SYSTEM",
            content: `Task approved and marked as COMPLETED by ${reviewerName}.${reviewNotes ? `\n\n**Review Notes:** ${reviewNotes}` : ""}`,
            progressSnapshot: 100,
            healthSnapshot: TaskHealth.ON_TRACK,
          },
        });

        await tx.auditLog.create({
          data: {
            userId: session.userId,
            action: "APPROVE_TASK",
            details: `Approved and completed task #${taskId}: "${task.title}"`,
          },
        });

        // Notify assignees
        if (task.assignees.length > 0) {
          await tx.notification.createMany({
            data: task.assignees.map(a => ({
              userId: a.id,
              title: "Task Approved & Completed! 🎉",
              message: `Your task #${task.id} ("${task.title}") was approved by ${reviewerName}.`,
              link: `/dashboard/tasks/${task.id}`,
            })),
          });
        }
      } else {
        // REJECT
        await tx.task.update({
          where: { id: taskId },
          data: {
            status: TaskStatus.REJECTED,
            health: TaskHealth.AT_RISK,
            progress: Math.min(task.progress, 85),
            reviewedAt: new Date(),
            reviewNotes: reviewNotes || "Revisions required by manager.",
          },
        });

        await tx.taskUpdate.create({
          data: {
            taskId,
            authorId: session.userId,
            type: "BLOCKER",
            content: `Task review returned with revision request by ${reviewerName}.\n\n**Feedback / Required Revisions:**\n${reviewNotes || "Please review deliverables and update your work."}`,
            progressSnapshot: Math.min(task.progress, 85),
            healthSnapshot: TaskHealth.AT_RISK,
          },
        });

        await tx.auditLog.create({
          data: {
            userId: session.userId,
            action: "REJECT_TASK",
            details: `Requested revisions for task #${taskId}: "${task.title}"`,
          },
        });

        // Notify assignees
        if (task.assignees.length > 0) {
          await tx.notification.createMany({
            data: task.assignees.map(a => ({
              userId: a.id,
              title: "Task Revision Requested ⚠️",
              message: `Revisions requested for task #${task.id}: "${task.title}". Feedback: ${reviewNotes || "Please update your submission."}`,
              link: `/dashboard/tasks/${task.id}`,
            })),
          });
        }
      }
    });

    revalidatePath(`/dashboard/tasks/${taskId}`);
    revalidatePath("/dashboard/tasks");
    return { success: true, action };
  } catch (error) {
    console.error("Failed to review task:", error);
    return { error: "Failed to review task." };
  }
}

export async function updateTaskStatus(taskId: number, status: TaskStatus) {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    if (session.role === Role.EMPLOYEE && status !== TaskStatus.IN_PROGRESS && status !== TaskStatus.SUBMITTED) {
      return { error: "Employees can only set tasks to In Progress or Submitted." };
    }

    const task = await prisma.task.findUnique({
      where: { id: taskId },
      include: { assignees: true },
    });

    if (!task) return { error: "Task not found." };

    await prisma.$transaction(async (tx) => {
      const updateData: any = { status };
      if (status === TaskStatus.COMPLETED) {
        updateData.progress = 100;
        updateData.completedAt = new Date();
        updateData.health = TaskHealth.ON_TRACK;
      }

      await tx.task.update({
        where: { id: taskId },
        data: updateData,
      });

      await tx.taskUpdate.create({
        data: {
          taskId,
          authorId: session.userId,
          type: "SYSTEM",
          content: `Task status updated to ${status.replace("_", " ")}.`,
          progressSnapshot: status === TaskStatus.COMPLETED ? 100 : task.progress,
        },
      });
    });

    revalidatePath(`/dashboard/tasks/${taskId}`);
    revalidatePath("/dashboard/tasks");
    return { success: true };
  } catch (error) {
    console.error("Failed to update task status:", error);
    return { error: "Failed to update task status." };
  }
}

export async function deleteTask(id: number) {
  try {
    const session = await getSession();
    if (!session) return { error: "Not authenticated" };

    if (session.role === Role.EMPLOYEE) {
      return { error: "Only managers and admins can delete tasks." };
    }

    const task = await prisma.task.findUnique({
      where: { id },
      include: { assigner: true },
    });

    if (!task) {
      return { error: "Task not found." };
    }

    // A Manager can only delete tasks they assigned, or a Super Admin can delete any task
    if (session.role === Role.MANAGER && task.assignerId !== session.userId) {
      return { error: "You can only delete tasks that you created." };
    }

    await prisma.$transaction(async (tx) => {
      await tx.task.delete({
        where: { id },
      });

      await tx.auditLog.create({
        data: {
          userId: session.userId,
          action: "DELETE_TASK",
          details: `Deleted task #${id}: "${task.title}"`,
        },
      });
    });

    revalidatePath("/dashboard/tasks");
    return { success: true };
  } catch (error) {
    console.error("Failed to delete task:", error);
    return { error: "Failed to delete task" };
  }
}
