import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class BranchesService {
  constructor(private readonly prisma: PrismaService) {}

  async createBranch(data: {
    name: string;
    code?: string;
    logo?: string;
    type?: string;
    isMainBranch?: boolean;
    managerName?: string;
    phone?: string;
    alternatePhone?: string;
    email?: string;
    address?: string;
    city?: string;
    state?: string;
    postalCode?: string;
    taxNumber?: string;
    allowPosSales?: boolean;
    businessId: string;
    createdById?: string;
  }) {
    const existingBranch = await this.prisma.branch.findFirst({
      where: {
        name: data.name,
        businessId: data.businessId,
      },
    });

    if (existingBranch) {
      throw new BadRequestException('Branch with this name already exists in your business');
    }

    return this.prisma.$transaction(async (tx) => {
      if (data.isMainBranch) {
        await tx.branch.updateMany({
          where: { businessId: data.businessId },
          data: { isMainBranch: false },
        });
      }

      const newBranch = await tx.branch.create({
        data,
      });

      const activeBusinessMethods = await tx.paymentMethod.findMany({
        where: {
          businessId: data.businessId,
          isActive: true,
        },
      });

      if (activeBusinessMethods.length > 0) {
        await tx.branchPaymentMethod.createMany({
          data: activeBusinessMethods.map((pm) => ({
            branchId: newBranch.id,
            paymentMethodId: pm.id,
            isActive: true,
          })),
        });
      }

      return newBranch;
    });
  }

  async getBranches(businessId: string) {
    return this.prisma.branch.findMany({
      where: { businessId },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getBranchById(id: string, businessId: string) {
    const branch = await this.prisma.branch.findFirst({
      where: { id, businessId },
    });
    if (!branch) {
      throw new BadRequestException('Branch not found');
    }
    return branch;
  }

  async updateBranch(
    id: string,
    businessId: string,
    data: {
      name?: string;
      code?: string;
      logo?: string;
      type?: string;
      isMainBranch?: boolean;
      managerName?: string;
      phone?: string;
      alternatePhone?: string;
      email?: string;
      address?: string;
      city?: string;
      state?: string;
      postalCode?: string;
      taxNumber?: string;
      allowPosSales?: boolean;
      isActive?: boolean;
      updatedById?: string;
    },
  ) {
    const branch = await this.getBranchById(id, businessId);

    if (data.name && data.name !== branch.name) {
      const existingBranch = await this.prisma.branch.findFirst({
        where: {
          name: data.name,
          businessId,
        },
      });
      if (existingBranch && existingBranch.id !== id) {
        throw new BadRequestException('Branch with this name already exists in your business');
      }
    }

    if (data.isMainBranch) {
      await this.prisma.branch.updateMany({
        where: { businessId, id: { not: id } },
        data: { isMainBranch: false },
      });
    }

    return this.prisma.branch.update({
      where: { id },
      data,
    });
  }

  async updateBranchLogo(id: string, logoUrl: string) {
    return this.prisma.branch.update({
      where: { id },
      data: { logo: logoUrl },
    });
  }

  async deleteBranch(id: string, businessId: string) {
    await this.getBranchById(id, businessId);
    await this.prisma.branch.delete({
      where: { id },
    });
    return { success: true };
  }

  // UserBranch mappings
  async assignUserToBranch(userId: string, branchId: string, businessId: string) {
    await this.getBranchById(branchId, businessId);

    const user = await this.prisma.user.findFirst({
      where: { id: userId, businessId },
    });
    if (!user) {
      throw new BadRequestException('User not found in this business');
    }

    const existing = await this.prisma.userBranch.findUnique({
      where: {
        userId_branchId: { userId, branchId },
      },
    });

    if (existing) {
      return existing;
    }

    return this.prisma.userBranch.create({
      data: { userId, branchId },
    });
  }

  async removeUserFromBranch(userId: string, branchId: string, businessId: string) {
    await this.getBranchById(branchId, businessId);

    await this.prisma.userBranch.delete({
      where: {
        userId_branchId: { userId, branchId },
      },
    });

    return { success: true };
  }

  async getUserBranches(userId: string, businessId: string) {
    const user = await this.prisma.user.findFirst({
      where: { id: userId, businessId },
      include: { role: true },
    });

    if (!user) {
      throw new BadRequestException('User not found');
    }

    const roleSlug = user.role?.role || 'admin';
    if (roleSlug === 'admin' || roleSlug === 'super-admin') {
      return this.getBranches(businessId);
    }

    const mappings = await this.prisma.userBranch.findMany({
      where: {
        userId,
        branch: { businessId },
      },
      include: {
        branch: true,
      },
    });

    return mappings.map((m) => m.branch);
  }
}
