export const CreateCustomerBodySchema = {
  type: 'object',
  properties: {
    name: { type: 'string', example: 'Alex Smith' },
    businessName: { type: 'string', example: 'Alex Enterprise' },
    email: { type: 'string', example: 'alex@example.com' },
    phone: { type: 'string', example: '+1234567890' },
    taxNumber: { type: 'string', example: 'TAX998877' },
    openingBalance: { type: 'number', example: 1000 },
    creditLimit: { type: 'number', example: 5000 },
    address: { type: 'string', example: '456 Main St, NY' },
    customerGroupId: { type: 'string', example: 'group-uuid-123' },
    businessId: { type: 'string', example: 'business-uuid-123' },
    branchIds: { type: 'array', items: { type: 'string' }, example: ['branch-uuid-1'] },
    createdById: { type: 'string', example: 'user-uuid-123' }
  },
  required: ['name', 'businessId']
};

export const UpdateCustomerBodySchema = {
  type: 'object',
  properties: {
    name: { type: 'string', example: 'Alex Smith Jr.' },
    businessName: { type: 'string', example: 'Alex Enterprise Updated' },
    email: { type: 'string', example: 'alex.jr@example.com' },
    phone: { type: 'string', example: '+1234567890' },
    taxNumber: { type: 'string', example: 'TAX998877' },
    openingBalance: { type: 'number', example: 1500 },
    creditLimit: { type: 'number', example: 6000 },
    address: { type: 'string', example: '456 Main St, NY, NY' },
    customerGroupId: { type: 'string', example: 'group-uuid-123' },
    businessId: { type: 'string', example: 'business-uuid-123' },
    branchIds: { type: 'array', items: { type: 'string' }, example: ['branch-uuid-1'] },
    updatedById: { type: 'string', example: 'user-uuid-123' }
  },
  required: ['businessId']
};

export const CustomerResponseSchema = {
  type: 'object',
  properties: {
    id: { type: 'string', example: 'customer-uuid-123' },
    name: { type: 'string', example: 'Alex Smith' },
    businessName: { type: 'string', example: 'Alex Enterprise' },
    email: { type: 'string', example: 'alex@example.com' },
    phone: { type: 'string', example: '+1234567890' },
    taxNumber: { type: 'string', example: 'TAX998877' },
    openingBalance: { type: 'number', example: 1000 },
    creditLimit: { type: 'number', example: 5000 },
    address: { type: 'string', example: '456 Main St, NY' },
    customerGroupId: { type: 'string', example: 'group-uuid-123' },
    businessId: { type: 'string', example: 'business-uuid-123' }
  }
};
