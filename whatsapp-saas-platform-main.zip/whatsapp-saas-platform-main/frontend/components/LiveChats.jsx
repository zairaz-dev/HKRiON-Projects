'use client';
import { useState, useEffect, useRef } from 'react';
import { 
  MessageSquare, 
  Send, 
  Search, 
  Bot, 
  User, 
  CheckCheck, 
  Sparkles, 
  RefreshCw, 
  Phone, 
  Plus, 
  X, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  ToggleLeft,
  ToggleRight,
  Shield,
  Loader2
} from 'lucide-react';

export default function LiveChats({ instanceName = 'saas_instance', initialChatId = null }) {
  const [chats, setChats] = useState([]);
  const [selectedChatId, setSelectedChatId] = useState(initialChatId || null);
  const [inputText, setInputText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState('all'); // all, unread, ai
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [showNewChatModal, setShowNewChatModal] = useState(false);
  const [newChatNumber, setNewChatNumber] = useState('');
  const [newChatInitialMessage, setNewChatInitialMessage] = useState('');
  const [statusMessage, setStatusMessage] = useState(null);

  useEffect(() => {
    if (initialChatId) {
      setSelectedChatId(initialChatId);
    }
  }, [initialChatId]);

  const messagesEndRef = useRef(null);

  // Fetch chats list
  const fetchChats = async () => {
    try {
      const res = await fetch('/api/chats');
      if (res.ok) {
        const data = await res.json();
        if (data.chats) {
          setChats(data.chats);
          // Default select first chat if none selected
          if (!selectedChatId && data.chats.length > 0) {
            setSelectedChatId(data.chats[0].id);
          }
        }
      }
    } catch (err) {
      console.warn('[LiveChats] Failed to fetch chats:', err);
    }
  };

  // Poll chats periodically
  useEffect(() => {
    fetchChats();
    const interval = setInterval(fetchChats, 3000);
    return () => clearInterval(interval);
  }, [selectedChatId]);

  // Scroll to bottom when messages update
  const activeChat = chats.find(c => c.id === selectedChatId) || null;

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeChat?.messages?.length]);

  // Send message
  const handleSendMessage = async (e) => {
    if (e) e.preventDefault();
    if (!inputText.trim() || !activeChat) return;

    const textToSend = inputText.trim();
    setInputText('');
    setSending(true);

    try {
      const res = await fetch('/api/chats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          recipient: activeChat.phoneNumber || activeChat.id,
          text: textToSend,
          instanceName,
        }),
      });

      if (res.ok) {
        await fetchChats();
      } else {
        const errData = await res.json();
        setStatusMessage({ type: 'error', text: errData.error || 'Failed to send message' });
        setTimeout(() => setStatusMessage(null), 4000);
      }
    } catch (err) {
      setStatusMessage({ type: 'error', text: err.message || 'Error sending message' });
      setTimeout(() => setStatusMessage(null), 4000);
    } finally {
      setSending(false);
    }
  };

  // Toggle AI for active chat
  const handleToggleAi = async () => {
    if (!activeChat) return;
    const newAiState = !activeChat.aiEnabled;

    try {
      const res = await fetch('/api/chats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'toggle_ai',
          recipient: activeChat.id,
          aiEnabled: newAiState,
        }),
      });

      if (res.ok) {
        setChats(prev => prev.map(c => c.id === activeChat.id ? { ...c, aiEnabled: newAiState } : c));
        setStatusMessage({ 
          type: 'success', 
          text: newAiState ? '🤖 AI Auto-Reply Enabled for this chat' : '👤 AI Paused - Human Takeover Mode Active' 
        });
        setTimeout(() => setStatusMessage(null), 3000);
      }
    } catch (err) {
      console.error('Failed to toggle AI:', err);
    }
  };

  // Start new chat
  const handleStartNewChat = async (e) => {
    e.preventDefault();
    if (!newChatNumber.trim()) return;

    const cleanNum = newChatNumber.replace(/[^0-9]/g, '');
    const msg = newChatInitialMessage.trim() || 'Hi 👋 Welcome to HKRiON! How can we assist you today?';

    setSending(true);
    try {
      const res = await fetch('/api/chats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          recipient: cleanNum,
          text: msg,
          instanceName,
        }),
      });

      if (res.ok) {
        setShowNewChatModal(false);
        setNewChatNumber('');
        setNewChatInitialMessage('');
        setSelectedChatId(cleanNum);
        await fetchChats();
      } else {
        const errData = await res.json();
        alert(errData.error || 'Failed to start chat');
      }
    } catch (err) {
      alert(err.message || 'Error starting chat');
    } finally {
      setSending(false);
    }
  };

  // Quick reply click handler
  const handleQuickReply = (text) => {
    setInputText(text);
  };

  // Filtered chats
  const filteredChats = chats.filter(chat => {
    const matchesSearch = 
      (chat.name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (chat.phoneNumber || '').includes(searchQuery) ||
      (chat.lastMessage || '').toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;
    if (filter === 'unread') return (chat.unreadCount || 0) > 0;
    if (filter === 'ai') return chat.aiEnabled !== false;
    if (filter === 'human') return chat.aiEnabled === false;
    return true;
  });

  const quickReplies = [
    "வணக்கம்! HKRiON-ஐ தொடர்பு கொண்டதற்கு நன்றி. எப்படி உதவலாம்? 👋",
    "Sure! உங்கள் Business Requirements பற்றி விளக்க முடியுமா? 💡",
    "எங்களின் Web & Software Development Packages பற்றிய விவரங்களை அனுப்புகிறேன் 📄",
    "நன்றி! உங்கள் கோரிக்கையை எங்கள் தொழில்நுட்பக் குழுவுக்கு அனுப்பியுள்ளோம் 👍",
  ];

  return (
    <div className="h-[calc(100vh-140px)] min-h-[600px] glass-card rounded-3xl border border-slate-800 overflow-hidden flex flex-col md:flex-row bg-[#0b1319] shadow-2xl relative">
      
      {/* Toast Status Banner */}
      {statusMessage && (
        <div className={`absolute top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 shadow-2xl backdrop-blur-md animate-fadeIn ${
          statusMessage.type === 'success' 
            ? 'bg-emerald-950/90 border border-emerald-600 text-emerald-300' 
            : 'bg-rose-950/90 border border-rose-600 text-rose-300'
        }`}>
          {statusMessage.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          {statusMessage.text}
        </div>
      )}

      {/* LEFT PANEL: Conversations Sidebar */}
      <div className="w-full md:w-80 lg:w-96 border-r border-slate-800/80 flex flex-col bg-[#0d161d] shrink-0">
        {/* Header & Search */}
        <div className="p-4 border-b border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-white font-bold text-base">
              <MessageSquare className="w-5 h-5 text-emerald-400" />
              <span>WhatsApp Chats</span>
              <span className="text-xs bg-emerald-950 text-emerald-400 border border-emerald-800/60 px-2 py-0.5 rounded-full font-mono">
                {chats.length}
              </span>
            </div>
            <button
              onClick={() => setShowNewChatModal(true)}
              className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 p-2 rounded-xl text-xs font-bold flex items-center gap-1 shadow-md shadow-emerald-950 transition-colors"
              title="Start New Chat"
            >
              <Plus className="w-4 h-4" /> New Chat
            </button>
          </div>

          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search contact or message..."
              className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl pl-9 pr-3.5 py-2 text-xs text-slate-200 outline-none transition-colors"
            />
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px]">
            {['all', 'unread', 'ai', 'human'].map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-3 py-1 rounded-lg font-medium capitalize transition-colors shrink-0 ${
                  filter === f
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                    : 'text-slate-400 hover:text-slate-200 bg-slate-900/60'
                }`}
              >
                {f === 'ai' ? '🤖 AI Active' : f === 'human' ? '👤 Human Only' : f}
              </button>
            ))}
          </div>
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-800/40">
          {filteredChats.length === 0 ? (
            <div className="p-8 text-center text-slate-500 space-y-3">
              <MessageSquare className="w-10 h-10 mx-auto text-slate-600 opacity-50" />
              <p className="text-xs">No conversations yet.</p>
              <p className="text-[11px] text-slate-600">
                Incoming WhatsApp messages will appear here live in real-time.
              </p>
              <button
                onClick={() => setShowNewChatModal(true)}
                className="text-xs text-emerald-400 underline hover:text-emerald-300"
              >
                Start a test chat now
              </button>
            </div>
          ) : (
            filteredChats.map((chat) => {
              const isSelected = chat.id === selectedChatId;
              return (
                <div
                  key={chat.id}
                  onClick={() => setSelectedChatId(chat.id)}
                  className={`p-3.5 flex items-start gap-3 cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-900/90 border-l-4 border-emerald-400'
                      : 'hover:bg-slate-900/40'
                  }`}
                >
                  {/* Avatar */}
                  <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-slate-800 to-slate-700 border border-slate-700 flex items-center justify-center text-white font-bold shrink-0 relative shadow-inner">
                    <User className="w-5 h-5 text-slate-300" />
                    <span className="w-3 h-3 rounded-full bg-emerald-500 border-2 border-slate-900 absolute -bottom-0.5 -right-0.5" />
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="text-xs font-bold text-white truncate max-w-[150px]">
                        {chat.name || `+${chat.id}`}
                      </h4>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {chat.messages && chat.messages.length > 0 
                          ? chat.messages[chat.messages.length - 1].timestamp
                          : ''}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <p className="text-xs text-slate-400 truncate max-w-[170px] flex items-center gap-1">
                        {chat.lastMessage || 'No messages'}
                      </p>
                      <div className="flex items-center gap-1">
                        {chat.aiEnabled !== false ? (
                          <span className="text-[9px] bg-emerald-950 text-emerald-400 border border-emerald-800/60 px-1 rounded font-mono">
                            AI
                          </span>
                        ) : (
                          <span className="text-[9px] bg-cyan-950 text-cyan-400 border border-cyan-800/60 px-1 rounded font-mono">
                            MANUAL
                          </span>
                        )}
                        {chat.unreadCount > 0 && (
                          <span className="w-4 h-4 rounded-full bg-emerald-500 text-slate-950 text-[10px] font-bold flex items-center justify-center shrink-0">
                            {chat.unreadCount}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* RIGHT PANEL: Active Chat Thread */}
      {activeChat ? (
        <div className="flex-1 flex flex-col bg-[#091016] min-w-0">
          {/* Chat Header */}
          <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-[#0d161d]/80 backdrop-blur-md">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-slate-950 font-bold shadow-lg shadow-emerald-950">
                <User className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  {activeChat.name || `+${activeChat.id}`}
                  <span className="inline-flex items-center gap-1 text-[10px] font-normal text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-full border border-emerald-800/60 font-mono">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    +{activeChat.phoneNumber || activeChat.id}
                  </span>
                </h3>
                <p className="text-[11px] text-slate-400">
                  {activeChat.aiEnabled !== false ? '⚡ AI Auto-Reply is actively assisting this customer' : '👤 Manual Human Agent Mode Active'}
                </p>
              </div>
            </div>

            {/* Actions: AI Toggle & Refresh */}
            <div className="flex items-center gap-2">
              <button
                onClick={handleToggleAi}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-2 border transition-all ${
                  activeChat.aiEnabled !== false
                    ? 'bg-emerald-950/80 border-emerald-700/70 text-emerald-300 hover:bg-emerald-900/90'
                    : 'bg-amber-950/80 border-amber-700/70 text-amber-300 hover:bg-amber-900/90'
                }`}
                title={activeChat.aiEnabled !== false ? 'Click to Pause AI for this chat' : 'Click to Resume AI for this chat'}
              >
                <Bot className="w-3.5 h-3.5" />
                <span>{activeChat.aiEnabled !== false ? 'AI Bot: ON' : 'AI Bot: PAUSED'}</span>
              </button>

              <button
                onClick={fetchChats}
                className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:text-emerald-400 text-slate-400 transition-colors"
                title="Refresh Chat"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Messages Container */}
          <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-3.5 bg-[radial-gradient(#111d27_1px,transparent_1px)] [background-size:16px_16px]">
            {activeChat.messages && activeChat.messages.length > 0 ? (
              activeChat.messages.map((msg, idx) => {
                const isFromMe = msg.fromMe;
                return (
                  <div
                    key={msg.id || idx}
                    className={`flex flex-col ${isFromMe ? 'items-end' : 'items-start'} space-y-1 animate-fadeIn`}
                  >
                    <div
                      className={`max-w-md lg:max-w-lg p-3.5 rounded-2xl shadow-lg relative ${
                        isFromMe
                          ? msg.isAi
                            ? 'bg-gradient-to-r from-emerald-950 via-teal-950 to-emerald-900 border border-emerald-500/40 text-slate-100 rounded-tr-xs'
                            : 'bg-gradient-to-r from-slate-900 to-cyan-950 border border-cyan-800/40 text-slate-100 rounded-tr-xs'
                          : 'bg-slate-900/95 border border-slate-800 text-slate-200 rounded-tl-xs'
                      }`}
                    >
                      {/* Tag for AI vs Human */}
                      {isFromMe && (
                        <div className="flex items-center gap-1 text-[10px] font-mono mb-1.5 opacity-80">
                          {msg.isAi ? (
                            <span className="text-emerald-400 flex items-center gap-1 font-bold">
                              <Sparkles className="w-3 h-3" /> HKRiON AI Auto-Reply
                            </span>
                          ) : (
                            <span className="text-cyan-400 flex items-center gap-1 font-bold">
                              <User className="w-3 h-3" /> Agent (You)
                            </span>
                          )}
                        </div>
                      )}

                      {/* Text */}
                      <p className="text-xs sm:text-sm leading-relaxed whitespace-pre-wrap">
                        {msg.text}
                      </p>

                      {/* Timestamp & Status */}
                      <div className="flex items-center justify-end gap-1 mt-1.5 text-[10px] text-slate-400 font-mono">
                        <span>{msg.timestamp || 'Now'}</span>
                        {isFromMe && (
                          <CheckCheck className={`w-3.5 h-3.5 ${msg.status === 'failed' ? 'text-rose-400' : 'text-emerald-400'}`} />
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-500 text-xs space-y-2">
                <MessageSquare className="w-8 h-8 opacity-40" />
                <p>No messages in this chat yet.</p>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Reply Pills */}
          <div className="px-4 py-2 bg-slate-950/90 border-t border-slate-800/80 flex items-center gap-2 overflow-x-auto">
            <span className="text-[11px] text-slate-400 shrink-0 font-semibold flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-400" /> Quick:
            </span>
            {quickReplies.map((qr, i) => (
              <button
                key={i}
                onClick={() => handleQuickReply(qr)}
                className="text-[11px] bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-emerald-500/40 px-2.5 py-1 rounded-lg shrink-0 transition-colors truncate max-w-[200px]"
                title={qr}
              >
                {qr}
              </button>
            ))}
          </div>

          {/* Input Bar */}
          <form onSubmit={handleSendMessage} className="p-3 bg-[#0d161d] border-t border-slate-800 flex items-center gap-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`Reply to +${activeChat.phoneNumber || activeChat.id} via WhatsApp...`}
              className="flex-1 bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-4 py-3 text-xs sm:text-sm text-slate-200 outline-none transition-colors"
            />
            <button
              type="submit"
              disabled={sending || !inputText.trim()}
              className="emerald-glow-btn text-slate-950 font-bold text-xs px-5 py-3 rounded-xl flex items-center gap-2 disabled:opacity-50 transition-all shrink-0"
            >
              {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4 fill-slate-950" />}
              <span>Send</span>
            </button>
          </form>
        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-500 bg-[#091016]">
          <div className="w-16 h-16 rounded-3xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-600 mb-3 shadow-inner">
            <MessageSquare className="w-8 h-8" />
          </div>
          <h3 className="text-sm font-bold text-white mb-1">Select a Conversation</h3>
          <p className="text-xs text-slate-400 max-w-sm">
            Choose a customer from the left list or start a new chat to view messages and live replies.
          </p>
        </div>
      )}

      {/* START NEW CHAT MODAL */}
      {showNewChatModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
          <div className="bg-[#0f171e] border border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl relative space-y-4">
            <button
              onClick={() => setShowNewChatModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-900"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-950 border border-emerald-800 flex items-center justify-center text-emerald-400">
                <Plus className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Start New WhatsApp Chat</h3>
                <p className="text-xs text-slate-400">Send an initial WhatsApp message to any phone number</p>
              </div>
            </div>

            <form onSubmit={handleStartNewChat} className="space-y-3.5 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Recipient Phone Number (with Country Code)
                </label>
                <input
                  type="text"
                  value={newChatNumber}
                  onChange={(e) => setNewChatNumber(e.target.value)}
                  placeholder="e.g. 94771234567 or 919876543210"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 font-mono outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  First Message
                </label>
                <textarea
                  value={newChatInitialMessage}
                  onChange={(e) => setNewChatInitialMessage(e.target.value)}
                  placeholder="Type opening message..."
                  rows={3}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewChatModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white bg-slate-900 border border-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={sending}
                  className="emerald-glow-btn text-slate-950 font-bold text-xs px-5 py-2 rounded-xl flex items-center gap-1.5"
                >
                  {sending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5 fill-slate-950" />}
                  <span>Start Conversation</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
