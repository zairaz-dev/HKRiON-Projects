import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { verifyToken } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('hkrion_auth_token')?.value;

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const currentUser = await verifyToken(token);
    if (!currentUser || currentUser.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden. Admin access required.' }, { status: 403 });
    }

    interface RawApplication {
      id: string;
      jobId: string;
      jobTitle: string;
      fullName: string;
      email: string;
      phone: string;
      experience: string;
      portfolioUrl: string | null;
      resumeUrl: string;
      coverNote: string | null;
      status: string;
      createdAt: Date | string;
    }

    let applications: RawApplication[] = [];
    try {
      applications = await prisma.$queryRaw<RawApplication[]>`
        SELECT id, jobId, jobTitle, fullName, email, phone, experience, portfolioUrl, resumeUrl, coverNote, status, createdAt
        FROM JobApplication
        ORDER BY createdAt DESC
      `;
    } catch (dbErr) {
      console.warn('Raw query fallback for applications:', dbErr);
    }

    const formattedApplications = applications.map((app) => ({
      ...app,
      createdAt: typeof app.createdAt === 'string' ? app.createdAt : new Date(app.createdAt).toISOString(),
    }));

    return NextResponse.json({ success: true, applications: formattedApplications });
  } catch (err) {
    console.error('Error fetching job applications:', err);
    return NextResponse.json({ error: 'Failed to fetch job applications' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('hkrion_auth_token')?.value;

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const currentUser = await verifyToken(token);
    if (!currentUser || currentUser.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden. Admin access required.' }, { status: 403 });
    }

    const { id, status } = await request.json();

    if (!id || !status) {
      return NextResponse.json({ error: 'Application ID and status are required' }, { status: 400 });
    }

    await prisma.$executeRaw`
      UPDATE JobApplication
      SET status = ${status}, updatedAt = NOW(), updatedBy = ${currentUser.id}
      WHERE id = ${id}
    `;

    return NextResponse.json({ success: true, message: 'Application status updated' });
  } catch (err) {
    console.error('Error updating application status:', err);
    return NextResponse.json({ error: 'Failed to update application status' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('hkrion_auth_token')?.value;

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const currentUser = await verifyToken(token);
    if (!currentUser || currentUser.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden. Admin access required.' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Application ID parameter is required' }, { status: 400 });
    }

    await prisma.$executeRaw`
      DELETE FROM JobApplication WHERE id = ${id}
    `;

    return NextResponse.json({ success: true, message: 'Application deleted successfully' });
  } catch (err) {
    console.error('Error deleting application:', err);
    return NextResponse.json({ error: 'Failed to delete application' }, { status: 500 });
  }
}
