import { getPositions } from "@/actions/positions";
import { getPotentialManagers } from "@/actions/employees";
import { getSession } from "@/lib/session";
import { Role } from "@prisma/client";
import { redirect } from "next/navigation";
import CreateEmployeeClient from "./create-employee-client";

export default async function CreateEmployeePage() {
  const session = await getSession();

  if (!session || session.role === Role.EMPLOYEE) {
    redirect("/dashboard/employees");
  }

  const isSuperAdmin = session.role === Role.SUPER_ADMIN;

  const [positionsRes, managersRes] = await Promise.all([
    getPositions(),
    getPotentialManagers(),
  ]);

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-24">
      <CreateEmployeeClient 
        positions={positionsRes.data || []}
        managers={managersRes.data || []}
        isSuperAdmin={isSuperAdmin}
      />
    </div>
  );
}
