"use client";

import { useState } from "react";
import Link from "next/link";
import Logo from "@/components/ui/Logo";
import {
  LayoutDashboard,
  Package,
  ShieldCheck,
  LogOut,
  ExternalLink,
  Menu,
  X,
  UserCheck,
  Sparkles,
} from "lucide-react";

interface AdminNavbarProps {
  user: {
    name: string;
    email: string;
    role: string;
  };
}

export default function AdminNavbar({ user }: AdminNavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full bg-slate-950/90 backdrop-blur-2xl border-b border-slate-800 shadow-2xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          {/* Left: Brand & Admin Badge */}
          <div className="flex items-center gap-4 sm:gap-6">
            <Link href="/admin" className="flex items-center gap-3 group">
              <Logo className="h-8 sm:h-9 w-auto" />
            </Link>

            <div className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-400 text-xs font-black uppercase tracking-widest">
              <Sparkles size={13} />
              <span>Admin Console</span>
            </div>
          </div>

          {/* Center: Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1.5 bg-slate-900/80 p-1.5 rounded-full border border-slate-800">
            <Link
              href="/admin"
              className="flex items-center gap-2 px-4 py-2 rounded-full bg-linear-to-r from-primary via-amber-500 to-yellow-500 text-slate-950 font-bold text-xs shadow-md transition-all active:scale-95"
            >
              <LayoutDashboard size={15} />
              <span>Dashboard</span>
            </Link>
            <Link
              href="/products"
              target="_blank"
              className="flex items-center gap-2 px-4 py-2 rounded-full text-slate-300 hover:text-white hover:bg-slate-800 text-xs font-medium transition-all"
            >
              <Package size={15} />
              <span>Live Products</span>
              <ExternalLink size={12} className="text-slate-500" />
            </Link>
            <Link
              href="/"
              target="_blank"
              className="flex items-center gap-2 px-4 py-2 rounded-full text-slate-300 hover:text-white hover:bg-slate-800 text-xs font-medium transition-all"
            >
              <ShieldCheck size={15} />
              <span>View Website</span>
              <ExternalLink size={12} className="text-slate-500" />
            </Link>
          </nav>

          {/* Right: User Profile Badge & Logout Action */}
          <div className="hidden md:flex items-center gap-3 sm:gap-4">
            {/* User Profile Pill */}
            <div className="flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-slate-900 border border-slate-800">
              <div className="w-7 h-7 rounded-full bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-400 font-black text-xs">
                {user.name.charAt(0)}
              </div>
              <div className="text-left pr-1">
                <p className="text-xs font-bold text-white leading-tight">{user.name}</p>
                <p className="text-[10px] text-amber-400/90 font-semibold">{user.role}</p>
              </div>
            </div>

            {/* Native Browser Form Logout Action (0ms instant redirect) */}
            <form method="POST" action="/api/auth/logout">
              <button
                type="submit"
                className="flex items-center gap-2 px-4 py-2 rounded-full bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 text-xs font-bold transition-all cursor-pointer active:scale-95"
                title="Log Out of Admin Console"
              >
                <LogOut size={14} />
                <span>Log Out</span>
              </button>
            </form>
          </div>

          {/* Mobile Hamburger Button */}
          <div className="flex md:hidden items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-400 font-bold text-xs">
              {user.name.charAt(0)}
            </div>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-slate-900/95 backdrop-blur-2xl border-b border-slate-800 p-4 space-y-3 shadow-2xl animate-in slide-in-from-top duration-200">
          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-400 font-bold">
              <UserCheck size={18} />
            </div>
            <div>
              <p className="text-xs font-bold text-white">{user.name}</p>
              <p className="text-[11px] text-slate-400">{user.email}</p>
            </div>
          </div>

          <nav className="space-y-1">
            <Link
              href="/admin"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-3 px-4 py-2.5 rounded-xl bg-amber-400/10 text-amber-400 font-bold text-xs border border-amber-400/20"
            >
              <LayoutDashboard size={16} />
              <span>Admin Dashboard</span>
            </Link>
            <Link
              href="/products"
              target="_blank"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center justify-between px-4 py-2.5 rounded-xl text-slate-300 hover:bg-slate-800 text-xs font-medium"
            >
              <div className="flex items-center gap-3">
                <Package size={16} />
                <span>Live Products Catalog</span>
              </div>
              <ExternalLink size={14} className="text-slate-500" />
            </Link>
            <Link
              href="/"
              target="_blank"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center justify-between px-4 py-2.5 rounded-xl text-slate-300 hover:bg-slate-800 text-xs font-medium"
            >
              <div className="flex items-center gap-3">
                <ShieldCheck size={16} />
                <span>Main Website Home</span>
              </div>
              <ExternalLink size={14} className="text-slate-500" />
            </Link>
          </nav>

          <div className="pt-2 border-t border-slate-800">
            <form method="POST" action="/api/auth/logout">
              <button
                type="submit"
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-red-500/10 text-red-400 border border-red-500/20 text-xs font-bold active:scale-95"
              >
                <LogOut size={15} />
                <span>Log Out</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </header>
  );
}
