import { NextResponse } from "next/server";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import sharp from "sharp";
import { createSlipAccessToken } from "@/lib/auth";

const MAX_FILE_SIZE = 25 * 1024 * 1024; // 25MB

const ALLOWED_MIME_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/avif",
  "image/gif",
  "application/pdf",
]);

// IP Rate Limiting Store to prevent upload spam & disk exhaustion
interface UploadRecord {
  count: number;
  resetAt: number;
}
const uploadLimits = new Map<string, UploadRecord>();
const MAX_UPLOADS_PER_WINDOW = 10;
const WINDOW_DURATION_MS = 10 * 60 * 1000; // 10 minutes

function pruneUploadLimits(now: number): void {
  if (uploadLimits.size > 1000) {
    for (const [key, record] of uploadLimits.entries()) {
      if (record.resetAt <= now) {
        uploadLimits.delete(key);
      }
    }
  }
}

import { getClientIp } from "@/lib/request-ip";

export async function POST(request: Request) {
  try {
    const ip = getClientIp(request);
    const now = Date.now();
    pruneUploadLimits(now);

    // Check rate limit
    let record = uploadLimits.get(ip);
    if (!record || record.resetAt <= now) {
      record = { count: 0, resetAt: now + WINDOW_DURATION_MS };
    }

    if (record.count >= MAX_UPLOADS_PER_WINDOW) {
      const waitMinutes = Math.ceil((record.resetAt - now) / 60000);
      return NextResponse.json(
        { error: `Upload rate limit exceeded. Please wait ${waitMinutes} minutes before attempting additional uploads.` },
        { status: 429, headers: { "Retry-After": Math.ceil((record.resetAt - now) / 1000).toString() } }
      );
    }

    const formData = await request.formData();
    const file = formData.get("file") as File | null;

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json(
        { error: "File exceeds 25MB limit" },
        { status: 400 }
      );
    }

    if (!ALLOWED_MIME_TYPES.has(file.type)) {
      return NextResponse.json(
        { error: `Unsupported file type: ${file.type}. Allowed: JPEG, PNG, WEBP, AVIF, GIF, PDF.` },
        { status: 400 }
      );
    }

    // Increment valid upload count for rate limiting
    record.count += 1;
    uploadLimits.set(ip, record);

    // Private storage: outside of public static assets (configurable for persistent volumes)
    const baseUploadDir = process.env.SLIP_STORAGE_DIR
      ? path.resolve(process.env.SLIP_STORAGE_DIR)
      : path.resolve(process.cwd(), "private_uploads", "slips");
    await mkdir(baseUploadDir, { recursive: true });

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    const timestamp = Date.now();
    const randomSuffix = Math.random().toString(36).substring(2, 8);

    let fileName: string;
    if (file.type === "application/pdf") {
      fileName = `slip-${timestamp}-${randomSuffix}.pdf`;
      const filePath = path.resolve(baseUploadDir, fileName);
      if (!filePath.startsWith(baseUploadDir + path.sep)) {
        return NextResponse.json({ error: "Invalid file destination" }, { status: 400 });
      }
      await writeFile(filePath, buffer);
    } else {
      // Optimize image (JPEG/PNG/WEBP/etc.) to WEBP for fast loading
      fileName = `slip-${timestamp}-${randomSuffix}.webp`;
      const filePath = path.resolve(baseUploadDir, fileName);
      if (!filePath.startsWith(baseUploadDir + path.sep)) {
        return NextResponse.json({ error: "Invalid file destination" }, { status: 400 });
      }

      await sharp(buffer)
        .rotate()
        .webp({ quality: 85 })
        .toFile(filePath);
    }

    const slipToken = createSlipAccessToken(fileName);
    const response = NextResponse.json({
      success: true,
      url: `/api/slips/${fileName}`,
      fileName,
      originalName: file.name,
      token: slipToken,
    });

    // Set short-lived secure HttpOnly cookie so customer can preview their slip during checkout
    response.cookies.set(`fg_slip_${fileName}`, slipToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 24 * 60 * 60, // 24 hours
    });

    return response;
  } catch (error) {
    console.error("Payment slip upload error:", error);
    return NextResponse.json(
      { error: "Failed to process payment slip upload" },
      { status: 500 }
    );
  }
}
