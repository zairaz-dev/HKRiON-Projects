import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Prisma } from '@prisma/client';

interface PurchaseLineInput {
  variantId: string;
  quantityPurchased: number;
  purchasePrice: number;
  sellingPrice: number;
  batchNumber?: string;
  expiryDate?: Date;
  imeis?: (string | { imeiNumber: string })[];
}

@Injectable()
export class PurchasesService {
  constructor(private readonly prisma: PrismaService) {}

  async createPurchase(data: {
    purchaseNumber: string;
    purchaseDate?: Date;
    supplierId: string;
    branchId: string;
    businessId: string;
    purchaseLines: PurchaseLineInput[];
    discountType?: string;
    discountAmount?: number;
    shippingAmount?: number;
    taxAmount?: number;
    grandTotal: number;
    notes?: string;
    createdById?: string;
    paymentDetails?: {
      amount: number;
      paymentMethodId: string;
      transactionNo?: string;
      notes?: string;
    };
  }) {
    const {
      purchaseNumber,
      purchaseDate,
      supplierId,
      branchId,
      businessId,
      purchaseLines,
      discountType,
      discountAmount,
      shippingAmount,
      taxAmount,
      grandTotal,
      notes,
      createdById,
      paymentDetails,
    } = data;

    if (!purchaseLines || purchaseLines.length === 0) {
      throw new BadRequestException('Purchase must contain at least one product line.');
    }

    // 1. Validation: Check duplicate purchase invoice number
    const duplicatePurchase = await this.prisma.purchase.findFirst({
      where: {
        businessId,
        purchaseNumber: purchaseNumber.trim(),
      },
    });
    if (duplicatePurchase) {
      throw new BadRequestException(`Purchase invoice number "${purchaseNumber.trim()}" is already in use.`);
    }

    // 2. Validation: Positive quantities and non-negative prices
    for (const line of purchaseLines) {
      if (line.quantityPurchased <= 0) {
        throw new BadRequestException('Quantity must be greater than 0 for all items.');
      }
      if (line.purchasePrice < 0 || line.sellingPrice < 0) {
        throw new BadRequestException('Purchase cost and selling price cannot be negative.');
      }
    }

    // 3. Validation: Duplicate IMEI checks within payload and against database
    const seenImeis = new Set<string>();
    for (const line of purchaseLines) {
      if (line.imeis && Array.isArray(line.imeis)) {
        for (const item of line.imeis) {
          const num = typeof item === 'string' ? item.trim() : item?.imeiNumber?.trim();
          if (num) {
            if (seenImeis.has(num)) {
              throw new BadRequestException(`Duplicate IMEI "${num}" found in purchase lines.`);
            }
            seenImeis.add(num);
          }
        }
      }
    }

    if (seenImeis.size > 0) {
      const existingDbImeis = await this.prisma.productImei.findMany({
        where: {
          businessId,
          imeiNumber: { in: Array.from(seenImeis) },
        },
      });
      if (existingDbImeis.length > 0) {
        throw new BadRequestException(
          `IMEI "${existingDbImeis[0].imeiNumber}" is already registered in the system.`,
        );
      }
    }

    // 4. Validation: Payment amount validation
    if (paymentDetails && paymentDetails.amount > 0) {
      if (!paymentDetails.paymentMethodId) {
        throw new BadRequestException('Payment method is required when a payment amount is provided.');
      }
      if (paymentDetails.amount > grandTotal + 0.01) {
        throw new BadRequestException('Payment amount cannot exceed the grand total.');
      }
    }

    // Start Transaction
    return this.prisma.$transaction(async (tx) => {
      // Calculate initial payment status
      const initialPaid = (paymentDetails && paymentDetails.amount > 0)
        ? Math.min(Number(paymentDetails.amount), grandTotal)
        : 0;
      let initialStatus: 'DUE' | 'PARTIAL' | 'PAID' = 'DUE';
      if (initialPaid >= grandTotal - 0.01 && grandTotal > 0) {
        initialStatus = 'PAID';
      } else if (initialPaid > 0) {
        initialStatus = 'PARTIAL';
      }

      // 1. Create the purchase
      const purchase = await tx.purchase.create({
        data: {
          purchaseNumber: purchaseNumber.trim(),
          purchaseDate: purchaseDate ? new Date(purchaseDate) : new Date(),
          supplierId,
          branchId,
          businessId,
          discountType: discountType || null,
          discountAmount: discountAmount ? Number(discountAmount) : 0,
          shippingAmount: shippingAmount ? Number(shippingAmount) : 0,
          taxAmount: taxAmount ? Number(taxAmount) : 0,
          grandTotal,
          amountPaid: initialPaid,
          paymentStatus: initialStatus as any,
          notes,
          createdById,
        },
      });

      // 2. Create purchase lines & update variant pricing
      for (const line of purchaseLines) {
        // Create the batch stock record (PurchaseLine)
        const createdLine = await tx.purchaseLine.create({
          data: {
            purchaseId: purchase.id,
            variantId: line.variantId,
            branchId,
            businessId,
            batchNumber: line.batchNumber || null,
            quantityPurchased: line.quantityPurchased,
            quantityRemaining: line.quantityPurchased, // initially fully available
            purchasePrice: line.purchasePrice,
            sellingPrice: line.sellingPrice,
            expiryDate: line.expiryDate ? new Date(line.expiryDate) : null,
          },
        });

        // Insert IMEIs if provided
        if (line.imeis && Array.isArray(line.imeis) && line.imeis.length > 0) {
          const variant = await tx.productVariant.findUnique({
            where: { id: line.variantId },
            select: { productId: true },
          });

          for (const item of line.imeis) {
            const imeiNumber = typeof item === 'string' ? item.trim() : item?.imeiNumber?.trim();
            if (!imeiNumber) continue;

            await tx.productImei.upsert({
              where: {
                imeiNumber_businessId: {
                  imeiNumber,
                  businessId,
                },
              },
              create: {
                imeiNumber,
                status: 'IN_STOCK',
                productId: variant?.productId || '',
                variantId: line.variantId,
                branchId,
                businessId,
                purchaseLineId: createdLine.id,
                purchaseDate: purchaseDate ? new Date(purchaseDate) : new Date(),
              },
              update: {
                status: 'IN_STOCK',
                productId: variant?.productId || '',
                variantId: line.variantId,
                branchId,
                purchaseLineId: createdLine.id,
                purchaseDate: purchaseDate ? new Date(purchaseDate) : new Date(),
              },
            });
          }
        }

        // Also update standard cost and retail prices in ProductVariant to match latest batch
        await tx.productVariant.update({
          where: { id: line.variantId },
          data: {
            purchasePrice: line.purchasePrice,
            sellingPrice: line.sellingPrice,
          },
        });
      }

      // 3. Create purchase payment record if initial payment is made
      if (paymentDetails && initialPaid > 0 && paymentDetails.paymentMethodId) {
        const year = new Date(purchaseDate || new Date()).getFullYear();
        const lastPayment = await tx.purchasePayment.findFirst({
          where: {
            businessId,
            paymentNumber: { startsWith: `PAY-${year}-` },
          },
          orderBy: { paymentNumber: 'desc' },
        });

        let nextSeq = 1;
        if (lastPayment && lastPayment.paymentNumber) {
          const parts = lastPayment.paymentNumber.split('-');
          const lastNum = parseInt(parts[parts.length - 1], 10);
          if (!isNaN(lastNum)) nextSeq = lastNum + 1;
        }

        const paymentNumber = `PAY-${year}-${String(nextSeq).padStart(4, '0')}`;

        await tx.purchasePayment.create({
          data: {
            paymentNumber,
            paymentDate: purchaseDate ? new Date(purchaseDate) : new Date(),
            amount: initialPaid,
            purchaseId: purchase.id,
            supplierId,
            paymentMethodId: paymentDetails.paymentMethodId,
            branchId,
            businessId,
            transactionNo: paymentDetails.transactionNo || null,
            notes: paymentDetails.notes || 'Initial payment on purchase creation',
            createdById: createdById || null,
          },
        });
      }

      return purchase;
    });
  }

  async getPurchases(
    businessId: string,
    filters: {
      branchId?: string;
      supplierId?: string;
      page?: number;
      limit?: number;
      search?: string;
    },
  ) {
    const { branchId, supplierId, page = 1, limit = 10, search } = filters;
    const skip = (page - 1) * limit;

    const whereClause: any = {
      businessId,
    };

    if (branchId) {
      whereClause.branchId = branchId;
    }

    if (supplierId) {
      whereClause.supplierId = supplierId;
    }

    if (search) {
      whereClause.purchaseNumber = {
        contains: search,
        mode: 'insensitive',
      };
    }

    const [total, data] = await Promise.all([
      this.prisma.purchase.count({ where: whereClause }),
      this.prisma.purchase.findMany({
        where: whereClause,
        include: {
          supplier: {
            select: {
              id: true,
              name: true,
              businessName: true,
            },
          },
          branch: {
            select: {
              id: true,
              name: true,
            },
          },
          purchaseLines: {
            include: {
              variant: {
                select: {
                  id: true,
                  name: true,
                  sku: true,
                  product: {
                    select: {
                      id: true,
                      name: true,
                    },
                  },
                },
              },
            },
          },
        },
        orderBy: {
          purchaseDate: 'desc',
        },
        skip,
        take: limit,
      }),
    ]);

    return {
      data,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getPurchaseById(id: string, businessId: string) {
    const purchase = await this.prisma.purchase.findFirst({
      where: { id, businessId },
      include: {
        supplier: true,
        branch: true,
        purchaseLines: {
          include: {
            variant: {
              include: {
                product: true,
              },
            },
            productImeis: true,
          },
        },
        payments: {
          include: {
            paymentMethod: true,
          },
          orderBy: {
            paymentDate: 'desc',
          },
        },
      },
    });

    if (!purchase) {
      throw new NotFoundException('Purchase not found');
    }

    return purchase;
  }

  /**
   * FIFO based Stock Deduction Utility
   */
  async deductStock(
    tx: Prisma.TransactionClient,
    variantId: string,
    branchId: string,
    quantityToDeduct: number,
  ) {
    if (quantityToDeduct <= 0) return;

    // Find all batches for this variant and branch with stock remaining, oldest first
    const batches = await tx.purchaseLine.findMany({
      where: {
        variantId,
        branchId,
        quantityRemaining: { gt: 0 },
      },
      orderBy: {
        createdAt: 'asc', // FIFO
      },
    });

    let remainingToDeduct = quantityToDeduct;

    for (const batch of batches) {
      if (remainingToDeduct <= 0) break;

      if (batch.quantityRemaining >= remainingToDeduct) {
        // This batch has enough stock to satisfy the remaining deduction
        await tx.purchaseLine.update({
          where: { id: batch.id },
          data: {
            quantityRemaining: { decrement: remainingToDeduct },
          },
        });
        remainingToDeduct = 0;
      } else {
        // Take everything from this batch and continue to next batch
        remainingToDeduct -= batch.quantityRemaining;
        await tx.purchaseLine.update({
          where: { id: batch.id },
          data: {
            quantityRemaining: 0,
          },
        });
      }
    }

    // If there is still a deduction qty left, we have insufficient stock
    if (remainingToDeduct > 0) {
      throw new BadRequestException(
        `Insufficient stock for product variant ID ${variantId}. Needed: ${quantityToDeduct}, Missing: ${remainingToDeduct}`,
      );
    }
  }

  async updatePurchase(
    id: string,
    businessId: string,
    data: {
      purchaseNumber: string;
      purchaseDate?: Date;
      supplierId: string;
      branchId: string;
      purchaseLines: PurchaseLineInput[];
      discountType?: string;
      discountAmount?: number;
      shippingAmount?: number;
      taxAmount?: number;
      grandTotal?: number;
      notes?: string;
    },
  ) {
    const {
      purchaseNumber,
      purchaseDate,
      supplierId,
      branchId,
      purchaseLines,
      discountType,
      discountAmount,
      shippingAmount,
      taxAmount,
      grandTotal,
      notes,
    } = data;

    if (!purchaseLines || purchaseLines.length === 0) {
      throw new BadRequestException('Purchase must contain at least one product line.');
    }

    const existingPurchase = await this.prisma.purchase.findFirst({
      where: { id, businessId },
      include: {
        purchaseLines: {
          include: {
            productImeis: true,
          },
        },
        payments: true,
      },
    });

    if (!existingPurchase) {
      throw new NotFoundException('Purchase not found.');
    }

    // 1. Validation: Check duplicate purchase invoice number
    const duplicatePurchase = await this.prisma.purchase.findFirst({
      where: {
        businessId,
        purchaseNumber: purchaseNumber.trim(),
        id: { not: id },
      },
    });
    if (duplicatePurchase) {
      throw new BadRequestException(`Purchase invoice number "${purchaseNumber.trim()}" is already in use.`);
    }

    // 2. Validation: Branch lock if units have already been sold
    const totalSoldUnits = existingPurchase.purchaseLines.reduce(
      (sum, l) => sum + (l.quantityPurchased - l.quantityRemaining),
      0,
    );
    if (existingPurchase.branchId !== branchId && totalSoldUnits > 0) {
      throw new BadRequestException(
        `Cannot change destination branch because ${totalSoldUnits.toFixed(2)} unit(s) from this purchase have already been sold or used at this branch.`,
      );
    }

    // 3. Validation: Positive quantities and non-negative prices
    for (const line of purchaseLines) {
      if (line.quantityPurchased <= 0) {
        throw new BadRequestException('Quantity must be greater than 0 for all items.');
      }
      if (line.purchasePrice < 0 || line.sellingPrice < 0) {
        throw new BadRequestException('Purchase cost and selling price cannot be negative.');
      }
    }

    // 4. Validation: Check duplicate IMEIs in the incoming payload and against other purchases
    const seenImeis = new Set<string>();
    for (const line of purchaseLines) {
      if (line.imeis && Array.isArray(line.imeis)) {
        for (const item of line.imeis) {
          const num = typeof item === 'string' ? item.trim() : item?.imeiNumber?.trim();
          if (num) {
            if (seenImeis.has(num)) {
              throw new BadRequestException(`Duplicate IMEI "${num}" found in purchase items.`);
            }
            seenImeis.add(num);
          }
        }
      }
    }

    if (seenImeis.size > 0) {
      const existingDbImeis = await this.prisma.productImei.findMany({
        where: {
          businessId,
          imeiNumber: { in: Array.from(seenImeis) },
        },
        include: { purchaseLine: true },
      });
      for (const dbImei of existingDbImeis) {
        if (dbImei.purchaseLine && dbImei.purchaseLine.purchaseId !== id) {
          throw new BadRequestException(
            `IMEI "${dbImei.imeiNumber}" is already registered under another purchase.`,
          );
        }
      }
    }

    return this.prisma.$transaction(async (tx) => {
      // 1. Check if any old purchase lines have been sold, and if the new quantities are valid
      const oldLinesMap = new Map(existingPurchase.purchaseLines.map((l) => [l.variantId, l]));
      const newLinesMap = new Map(purchaseLines.map((l) => [l.variantId, l]));

      for (const oldLine of existingPurchase.purchaseLines) {
        const soldQty = oldLine.quantityPurchased - oldLine.quantityRemaining;
        if (soldQty > 0) {
          const newLine = newLinesMap.get(oldLine.variantId);
          if (!newLine) {
            throw new BadRequestException(
              `Cannot remove product variant ID ${oldLine.variantId} because ${soldQty.toFixed(2)} unit(s) have already been sold/used.`
            );
          }
          if (newLine.quantityPurchased < soldQty) {
            throw new BadRequestException(
              `Cannot set quantity for variant ID ${oldLine.variantId} to ${newLine.quantityPurchased} because ${soldQty.toFixed(2)} unit(s) have already been sold/used.`
            );
          }
        }
      }

      // Check existing IMEIs for this purchase
      const existingImeis = existingPurchase.purchaseLines.flatMap((l) => l.productImeis || []);
      const incomingImeiSet = new Set<string>();
      for (const line of purchaseLines) {
        if (line.imeis && Array.isArray(line.imeis)) {
          for (const item of line.imeis) {
            const imeiNum = typeof item === 'string' ? item.trim() : item?.imeiNumber?.trim();
            if (imeiNum) incomingImeiSet.add(imeiNum);
          }
        }
      }

      // Ensure sold IMEIs are not removed
      for (const existingImei of existingImeis) {
        if (existingImei.status === 'SOLD' || existingImei.saleLineId) {
          if (!incomingImeiSet.has(existingImei.imeiNumber)) {
            throw new BadRequestException(
              `Cannot remove IMEI "${existingImei.imeiNumber}" because it has already been sold.`
            );
          }
        }
      }

      // Delete/remove unselected IMEIs that are IN_STOCK
      for (const existingImei of existingImeis) {
        if (!incomingImeiSet.has(existingImei.imeiNumber) && existingImei.status === 'IN_STOCK') {
          await tx.productImei.delete({
            where: { id: existingImei.id },
          });
        }
      }

      // 2. Delete all old purchase lines
      await tx.purchaseLine.deleteMany({
        where: { purchaseId: id },
      });

      // 3. Create new purchase lines and update variant pricing & IMEIs
      let calculatedGrandTotal = 0;
      for (const line of purchaseLines) {
        const oldLine = oldLinesMap.get(line.variantId);
        let soldQty = 0;
        if (oldLine) {
          const oldLineImeis = existingImeis.filter((i) => i.purchaseLineId === oldLine.id);
          if (oldLineImeis.length > 0) {
            soldQty = oldLineImeis.filter((i) => i.status === 'SOLD' || i.saleLineId).length;
          } else {
            soldQty = Math.max(0, oldLine.quantityPurchased - oldLine.quantityRemaining);
          }
        }
        
        const quantityRemaining = Math.max(0, line.quantityPurchased - soldQty);
        calculatedGrandTotal += line.quantityPurchased * line.purchasePrice;

        const createdLine = await tx.purchaseLine.create({
          data: {
            purchaseId: id,
            variantId: line.variantId,
            branchId,
            businessId,
            batchNumber: line.batchNumber || null,
            quantityPurchased: line.quantityPurchased,
            quantityRemaining,
            purchasePrice: line.purchasePrice,
            sellingPrice: line.sellingPrice,
            expiryDate: line.expiryDate ? new Date(line.expiryDate) : null,
          },
        });

        // Upsert IMEIs for this line if provided
        if (line.imeis && Array.isArray(line.imeis) && line.imeis.length > 0) {
          const variant = await tx.productVariant.findUnique({
            where: { id: line.variantId },
            select: { productId: true },
          });

          for (const item of line.imeis) {
            const imeiNumber = typeof item === 'string' ? item.trim() : item?.imeiNumber?.trim();
            if (!imeiNumber) continue;

            await tx.productImei.upsert({
              where: {
                imeiNumber_businessId: {
                  imeiNumber,
                  businessId,
                },
              },
              create: {
                imeiNumber,
                status: 'IN_STOCK',
                productId: variant?.productId || '',
                variantId: line.variantId,
                branchId,
                businessId,
                purchaseLineId: createdLine.id,
                purchaseDate: purchaseDate ? new Date(purchaseDate) : new Date(),
              },
              update: {
                productId: variant?.productId || '',
                variantId: line.variantId,
                branchId,
                purchaseLineId: createdLine.id,
                purchaseDate: purchaseDate ? new Date(purchaseDate) : new Date(),
              },
            });
          }
        }

        // Update cost & price in variant
        await tx.productVariant.update({
          where: { id: line.variantId },
          data: {
            purchasePrice: line.purchasePrice,
            sellingPrice: line.sellingPrice,
          },
        });
      }

      // 4. Recalculate paymentStatus based on the sum of existing payments
      const totalPaymentsSum = existingPurchase.payments.reduce((sum, p) => sum + p.amount, 0);
      const finalGrandTotal = grandTotal !== undefined ? grandTotal : Math.max(0, calculatedGrandTotal - (discountAmount || 0) + (shippingAmount || 0) + (taxAmount || 0));

      if (totalPaymentsSum > 0 && finalGrandTotal < totalPaymentsSum - 0.01) {
        throw new BadRequestException(
          `Grand total (${finalGrandTotal.toFixed(2)}) cannot be less than already paid amount (${totalPaymentsSum.toFixed(2)}).`,
        );
      }

      let newPaymentStatus = 'DUE';
      if (totalPaymentsSum >= finalGrandTotal - 0.01) {
        newPaymentStatus = 'PAID';
      } else if (totalPaymentsSum > 0.01) {
        newPaymentStatus = 'PARTIAL';
      }

      // 5. Update purchase details
      const updatedPurchase = await tx.purchase.update({
        where: { id },
        data: {
          purchaseNumber: purchaseNumber.trim(),
          purchaseDate: purchaseDate ? new Date(purchaseDate) : new Date(),
          supplierId,
          branchId,
          discountType: discountType !== undefined ? discountType : existingPurchase.discountType,
          discountAmount: discountAmount !== undefined ? Number(discountAmount) : existingPurchase.discountAmount,
          shippingAmount: shippingAmount !== undefined ? Number(shippingAmount) : existingPurchase.shippingAmount,
          taxAmount: taxAmount !== undefined ? Number(taxAmount) : existingPurchase.taxAmount,
          grandTotal: finalGrandTotal,
          amountPaid: totalPaymentsSum,
          paymentStatus: newPaymentStatus as any,
          notes,
        },
      });

      return updatedPurchase;
    });
  }

  async createPurchaseReturn(
    businessId: string,
    data: {
      returnNumber: string;
      returnDate?: Date;
      purchaseId: string;
      notes?: string;
      createdById?: string;
      returnLines: {
        purchaseLineId: string;
        quantityReturned: number;
        imeis?: string[];
      }[];
    },
  ) {
    const {
      returnNumber,
      returnDate,
      purchaseId,
      notes,
      createdById,
      returnLines,
    } = data;

    if (!returnLines || returnLines.length === 0) {
      throw new BadRequestException('Return must contain at least one line.');
    }

    const purchase = await this.prisma.purchase.findFirst({
      where: { id: purchaseId, businessId },
      include: {
        purchaseLines: {
          include: {
            productImeis: true,
          },
        },
      },
    });

    if (!purchase) {
      throw new NotFoundException('Purchase not found');
    }

    return this.prisma.$transaction(async (tx) => {
      let grandTotal = 0;
      const linesToCreate: {
        purchaseLineId: string;
        variantId: string;
        quantityReturned: number;
        purchasePrice: number;
      }[] = [];

      for (const line of returnLines) {
        const purchaseLine = purchase.purchaseLines.find(
          (pl) => pl.id === line.purchaseLineId,
        );
        if (!purchaseLine) {
          throw new BadRequestException(
            `Purchase line ID ${line.purchaseLineId} not found in this purchase.`,
          );
        }

        if (line.quantityReturned <= 0) {
          throw new BadRequestException('Returned quantity must be greater than zero.');
        }

        // Calculate total previously returned quantity for this line item
        const previousReturns = await tx.purchaseReturnLine.aggregate({
          where: { purchaseLineId: purchaseLine.id },
          _sum: { quantityReturned: true },
        });

        const totalAlreadyReturned = previousReturns._sum.quantityReturned || 0;
        const maxReturnable = purchaseLine.quantityPurchased - totalAlreadyReturned;

        if (line.quantityReturned > maxReturnable) {
          throw new BadRequestException(
            `Cannot return ${line.quantityReturned} units. Only ${maxReturnable} unit(s) returnable (${totalAlreadyReturned} already returned out of ${purchaseLine.quantityPurchased} purchased).`,
          );
        }

        const inStockImeis = (purchaseLine.productImeis || []).filter(
          (pi) => pi.status === 'IN_STOCK',
        );
        const effectiveRemaining =
          (purchaseLine.productImeis && purchaseLine.productImeis.length > 0)
            ? inStockImeis.length
            : purchaseLine.quantityRemaining;

        if (line.quantityReturned > effectiveRemaining) {
          throw new BadRequestException(
            `Cannot return ${line.quantityReturned} units of variant ID ${purchaseLine.variantId}. Only ${effectiveRemaining} units remaining in stock.`,
          );
        }

        // IMEI validation if purchase line has tracked IMEIs or if IMEIs provided
        const lineImeis = purchaseLine.productImeis || [];
        const imeisToReturnRecords: typeof lineImeis = [];

        if (lineImeis.length > 0 || (line.imeis && line.imeis.length > 0)) {
          if (!line.imeis || line.imeis.length !== line.quantityReturned) {
            throw new BadRequestException(
              `Please select exactly ${line.quantityReturned} IMEI(s) for returning variant ID ${purchaseLine.variantId}.`,
            );
          }

          // Check duplicates in payload
          const uniqueImeis = new Set(line.imeis);
          if (uniqueImeis.size !== line.imeis.length) {
            throw new BadRequestException('Duplicate IMEIs found in the return request.');
          }

          for (const imeiStr of line.imeis) {
            const foundImei = lineImeis.find(
              (pi) => pi.imeiNumber === imeiStr || pi.id === imeiStr,
            );
            if (!foundImei) {
              throw new BadRequestException(
                `IMEI "${imeiStr}" does not belong to this purchase line item.`,
              );
            }
            if (foundImei.status === 'SOLD') {
              throw new BadRequestException(
                `Cannot return IMEI "${imeiStr}" because it has already been sold to a customer.`,
              );
            }
            if (foundImei.status === 'RETURNED') {
              throw new BadRequestException(
                `IMEI "${imeiStr}" has already been returned.`,
              );
            }
            if (foundImei.status !== 'IN_STOCK') {
              throw new BadRequestException(
                `IMEI "${imeiStr}" is not in stock (current status: ${foundImei.status}).`,
              );
            }
            imeisToReturnRecords.push(foundImei);
          }
        }

        // Decrement quantityRemaining
        await tx.purchaseLine.update({
          where: { id: purchaseLine.id },
          data: {
            quantityRemaining: { decrement: line.quantityReturned },
          },
        });

        // Update returned ProductImeis status to RETURNED
        for (const imeiRecord of imeisToReturnRecords) {
          await tx.productImei.update({
            where: { id: imeiRecord.id },
            data: {
              status: 'RETURNED',
              notes: (imeiRecord.notes ? `${imeiRecord.notes} | ` : '') +
                `Returned on Purchase Return #${returnNumber.trim()}`,
            },
          });
        }

        // Add to grand total of return
        grandTotal += line.quantityReturned * purchaseLine.purchasePrice;

        linesToCreate.push({
          purchaseLineId: purchaseLine.id,
          variantId: purchaseLine.variantId,
          quantityReturned: line.quantityReturned,
          purchasePrice: purchaseLine.purchasePrice,
        });
      }

      const purchaseReturn = await tx.purchaseReturn.create({
        data: {
          returnNumber: returnNumber.trim(),
          returnDate: returnDate ? new Date(returnDate) : new Date(),
          purchaseId,
          supplierId: purchase.supplierId,
          branchId: purchase.branchId,
          businessId,
          grandTotal,
          notes,
          createdById,
        },
      });

      for (const rLine of linesToCreate) {
        await tx.purchaseReturnLine.create({
          data: {
            purchaseReturnId: purchaseReturn.id,
            purchaseLineId: rLine.purchaseLineId,
            variantId: rLine.variantId,
            quantityReturned: rLine.quantityReturned,
            purchasePrice: rLine.purchasePrice,
            businessId,
          },
        });
      }

      // Financial Ledger Adjustment
      const currentDue = Math.max(0, purchase.grandTotal - purchase.amountPaid);
      const newPurchaseTotal = Math.max(0, purchase.grandTotal - grandTotal);
      let excessCredit = 0;

      if (grandTotal <= currentDue) {
        // Return amount is fully absorbed by the unpaid due
        let newStatus = 'DUE';
        if (purchase.amountPaid >= newPurchaseTotal - 0.01) {
          newStatus = 'PAID';
        } else if (purchase.amountPaid > 0.01) {
          newStatus = 'PARTIAL';
        }

        await tx.purchase.update({
          where: { id: purchaseId },
          data: {
            grandTotal: newPurchaseTotal,
            paymentStatus: newStatus as any,
          },
        });
      } else {
        // Return amount exceeds unpaid due => creates excess supplier credit
        excessCredit = grandTotal - currentDue;

        await tx.purchase.update({
          where: { id: purchaseId },
          data: {
            grandTotal: newPurchaseTotal,
            paymentStatus: 'PAID',
          },
        });
      }

      // If there is excess credit (or purchase was already fully paid), record a SupplierAdvance credit note
      if (excessCredit > 0.01) {
        // Find a payment method for the branch
        const branchPaymentMethod = await tx.branchPaymentMethod.findFirst({
          where: { branchId: purchase.branchId, isActive: true },
          select: { paymentMethodId: true },
        });

        const fallbackPaymentMethod = await tx.paymentMethod.findFirst({
          where: { businessId, isActive: true },
          select: { id: true },
        });

        const paymentMethodId =
          branchPaymentMethod?.paymentMethodId || fallbackPaymentMethod?.id;

        if (paymentMethodId) {
          const year = new Date().getFullYear();
          const rand = Math.floor(1000 + Math.random() * 9000);
          const advanceNumber = `ADV-RET-${year}-${rand}`;

          await tx.supplierAdvance.create({
            data: {
              advanceNumber,
              advanceDate: returnDate ? new Date(returnDate) : new Date(),
              amount: excessCredit,
              amountRemaining: excessCredit,
              supplierId: purchase.supplierId,
              paymentMethodId,
              branchId: purchase.branchId,
              businessId,
              notes: `Credit advance generated from Purchase Return #${returnNumber.trim()}`,
              createdById: createdById || null,
            },
          });
        }
      }

      return purchaseReturn;
    });
  }

  async getPurchaseReturns(
    businessId: string,
    filters: {
      branchId?: string;
      supplierId?: string;
      page?: number;
      limit?: number;
      search?: string;
    },
  ) {
    const { branchId, supplierId, page = 1, limit = 10, search } = filters;
    const skip = (page - 1) * limit;

    const whereClause: any = {
      businessId,
    };

    if (branchId) {
      whereClause.branchId = branchId;
    }

    if (supplierId) {
      whereClause.supplierId = supplierId;
    }

    if (search) {
      whereClause.returnNumber = {
        contains: search,
        mode: 'insensitive',
      };
    }

    const [total, data] = await Promise.all([
      this.prisma.purchaseReturn.count({ where: whereClause }),
      this.prisma.purchaseReturn.findMany({
        where: whereClause,
        include: {
          supplier: {
            select: {
              id: true,
              name: true,
              businessName: true,
            },
          },
          branch: {
            select: {
              id: true,
              name: true,
            },
          },
          purchase: {
            select: {
              id: true,
              purchaseNumber: true,
            },
          },
          returnLines: {
            include: {
              variant: {
                select: {
                  id: true,
                  name: true,
                  sku: true,
                },
              },
            },
          },
        },
        orderBy: {
          returnDate: 'desc',
        },
        skip,
        take: limit,
      }),
    ]);

    return {
      data,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getPurchaseReturnById(id: string, businessId: string) {
    const purchaseReturn = await this.prisma.purchaseReturn.findFirst({
      where: { id, businessId },
      include: {
        supplier: true,
        branch: true,
        purchase: true,
        returnLines: {
          include: {
            variant: {
              include: {
                product: true,
              },
            },
            purchaseLine: {
              include: {
                productImeis: true,
              },
            },
          },
        },
      },
    });

    if (!purchaseReturn) {
      throw new NotFoundException('Purchase return not found');
    }

    const formattedReturnLines = purchaseReturn.returnLines.map((line) => {
      const returnedImeis = (line.purchaseLine?.productImeis || [])
        .filter(
          (pi) =>
            pi.status === 'RETURNED' &&
            pi.notes?.includes(purchaseReturn.returnNumber),
        )
        .map((pi) => pi.imeiNumber);

      return {
        ...line,
        returnedImeis,
      };
    });

    return {
      ...purchaseReturn,
      returnLines: formattedReturnLines,
    };
  }

  async generateNextPurchaseNumber(businessId: string): Promise<string> {
    const docPrefix = await this.prisma.documentPrefix.findUnique({
      where: { businessId },
    });
    const prefix = docPrefix?.purchase || 'PO-';
    const count = await this.prisma.purchase.count({ where: { businessId } });
    return `${prefix}${String(count + 1).padStart(4, '0')}`;
  }

  async generateNextPurchaseReturnNumber(businessId: string): Promise<string> {
    const docPrefix = await this.prisma.documentPrefix.findUnique({
      where: { businessId },
    });
    const prefix = docPrefix?.purchaseReturn || 'PR-';
    const count = await this.prisma.purchaseReturn.count({ where: { businessId } });
    return `${prefix}${String(count + 1).padStart(4, '0')}`;
  }
}
