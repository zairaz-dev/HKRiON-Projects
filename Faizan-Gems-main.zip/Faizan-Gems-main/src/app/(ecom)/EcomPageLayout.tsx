"use client";

import React from "react";
import { usePathname } from "next/navigation";

const HERO_ROUTES = ["/", "/about"];

interface EcomPageLayoutProps {
  header: React.ReactNode;
  footer: React.ReactNode;
  children: React.ReactNode;
}

export function EcomPageLayout({ header, footer, children }: EcomPageLayoutProps) {
  const pathname = usePathname();
  const isCheckout = pathname === "/checkout" || pathname?.startsWith("/checkout/");

  if (isCheckout) {
    return <main className="grow min-h-screen bg-[#FAF8F5]">{children}</main>;
  }

  const isHero = pathname ? HERO_ROUTES.includes(pathname) : false;

  return (
    <>
      {header}
      <main className={`grow ${isHero ? "-mt-20" : ""}`}>{children}</main>
      {footer}
    </>
  );
}

export { EcomPageLayout as EcomCheckoutWrapper };
export default EcomPageLayout;
