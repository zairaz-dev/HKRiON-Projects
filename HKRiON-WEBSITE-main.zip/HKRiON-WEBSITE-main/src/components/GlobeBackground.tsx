'use client';

import React, { useEffect, useRef } from 'react';

interface NodePoint {
  lat: number;
  lng: number;
  label: string;
  icon: string;
}

const FEATURED_NODES: NodePoint[] = [
  { lat: 6.9271, lng: 79.8612, label: 'HKRION HQ (Sri Lanka)', icon: '🛡️' },
  { lat: 37.7749, lng: -122.4194, label: 'Cloud Infrastructure (US)', icon: '☁️' },
  { lat: 51.5074, lng: -0.1278, label: 'ERP & POS Engine (Europe)', icon: '⚡' },
  { lat: 35.6762, lng: 139.6503, label: 'Smart IoT Systems (Tokyo)', icon: '📡' },
  { lat: -33.8688, lng: 151.2093, label: 'Enterprise Security (Sydney)', icon: '🔒' },
  { lat: 1.3521, lng: 103.8198, label: 'Data Analytics (Singapore)', icon: '📊' },
];

interface GlobeDot {
  x: number;
  y: number;
  z: number;
  isLand: boolean;
  lat: number;
  lng: number;
}

export default function GlobeBackground() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let isIntersecting = true;

    const observer = new IntersectionObserver(
      ([entry]) => {
        isIntersecting = entry.isIntersecting;
      },
      { threshold: 0.05 }
    );
    observer.observe(canvas);

    let width = 0;
    let height = 0;

    // Initial Rotation facing Asia & Sri Lanka
    let rotY = 1.35;
    let rotX = 0.22;
    let targetRotY = 1.35;
    let targetRotX = 0.22;
    let isDragging = false;
    let previousMouseX = 0;
    let previousMouseY = 0;

    // 1. Ultra-High Resolution (1440x720) Offscreen World Map Landmask
    const offCanvas = document.createElement('canvas');
    offCanvas.width = 1440;
    offCanvas.height = 720;
    const offCtx = offCanvas.getContext('2d');

    if (offCtx) {
      offCtx.fillStyle = '#000000';
      offCtx.fillRect(0, 0, 1440, 720);
      offCtx.scale(2, 2); // Scale 720x360 coordinates to 1440x720 resolution
      offCtx.fillStyle = '#FFFFFF';

      const continentPaths = [
        // North America & Alaska
        'M 40,40 L 75,30 L 130,20 L 220,25 L 255,50 L 240,80 L 210,95 L 200,115 L 184,136 L 164,152 L 150,136 L 124,116 L 96,104 L 70,84 L 40,64 Z',
        'M 10,40 L 44,30 L 60,44 L 44,64 L 16,60 Z', // Alaska
        'M 240,10 L 296,8 L 316,30 L 290,56 L 250,44 Z', // Greenland
        'M 150,136 L 176,140 L 196,164 L 190,176 L 164,170 Z', // Mexico
        'M 204,148 L 224,152 L 220,160 L 200,156 Z', // Caribbean

        // South America
        'M 196,180 L 230,172 L 264,184 L 290,220 L 276,260 L 244,304 L 224,310 L 210,270 L 200,230 L 190,204 Z',

        // Europe & Scandinavia
        'M 340,64 L 380,48 L 424,52 L 436,76 L 404,96 L 370,104 L 344,96 Z',
        'M 336,72 L 352,68 L 356,88 L 340,92 Z', // UK
        'M 376,28 L 410,24 L 420,48 L 390,60 Z', // Scandinavia
        'M 336,96 L 360,94 L 362,114 L 338,116 Z', // Iberia

        // Africa
        'M 330,108 L 390,100 L 450,120 L 464,156 L 444,200 L 416,248 L 390,252 L 370,220 L 340,176 L 320,140 Z',
        'M 452,208 L 464,204 L 460,240 L 448,242 Z', // Madagascar

        // Middle East
        'M 430,104 L 468,100 L 480,132 L 456,152 L 432,136 Z',

        // Eurasia / Russia / China
        'M 424,52 L 500,36 L 600,30 L 690,36 L 710,64 L 684,100 L 630,116 L 560,124 L 500,112 L 450,92 Z',

        // India
        'M 488,116 L 524,120 L 536,144 L 520,172 L 504,168 L 488,140 Z',

        // Sri Lanka
        'M 516,170 L 528,170 L 526,184 L 514,184 Z',

        // East Asia (China / Korea / Japan)
        'M 570,116 L 608,124 L 616,156 L 590,168 L 564,150 Z',
        'M 624,96 L 648,104 L 640,136 L 624,124 Z', // Japan

        // Southeast Asia & Philippines
        'M 540,152 L 576,160 L 592,184 L 570,204 L 544,184 Z',
        'M 604,170 L 614,170 L 612,192 L 600,192 Z', // Philippines
        'M 540,192 L 610,188 L 640,204 L 590,212 L 540,198 Z', // Indonesia

        // Australia & NZ
        'M 584,212 L 650,204 L 672,232 L 656,264 L 610,268 L 580,244 Z',
        'M 648,276 L 660,276 L 656,288 L 644,288 Z', // Tasmania
        'M 684,252 L 700,250 L 696,280 L 680,276 Z', // New Zealand
      ];

      continentPaths.forEach((pStr) => {
        try {
          if (typeof Path2D !== 'undefined') {
            offCtx.fill(new Path2D(pStr));
          }
        } catch {
          // Ignored
        }
      });
    }

    const imgData = offCtx ? offCtx.getImageData(0, 0, 1440, 720).data : new Uint8ClampedArray(0);

    // 2. Generate High-Density Micro-Dot Cloud (~30,000 Points)
    const globeDots: GlobeDot[] = [];
    const latStep = 0.95; // Ultra-fine latitude step for high density
    const lngStep = 1.05; // Ultra-fine longitude step for high density

    for (let lat = -84; lat <= 84; lat += latStep) {
      const phi = (lat * Math.PI) / 180;
      const cosPhi = Math.cos(phi);
      const sinPhi = Math.sin(phi);

      const count = Math.max(12, Math.floor((360 / lngStep) * cosPhi));
      const step = (Math.PI * 2) / count;

      for (let j = 0; j < count; j++) {
        const theta = j * step - Math.PI;
        const lng = (theta * 180) / Math.PI;

        const mapX = Math.floor(((lng + 180) / 360) * 1440);
        const mapY = Math.floor(((90 - lat) / 180) * 720);

        const clampX = Math.max(0, Math.min(1439, mapX));
        const clampY = Math.max(0, Math.min(719, mapY));
        const idx = (clampY * 1440 + clampX) * 4;

        const isLand = imgData.length > 0 ? imgData[idx] > 100 : false;

        const x = cosPhi * Math.sin(theta);
        const y = sinPhi;
        const z = cosPhi * Math.cos(theta);

        globeDots.push({ x, y, z, isLand, lat, lng });
      }
    }

    const convertLatLngToVector = (lat: number, lng: number) => {
      const phi = (lat * Math.PI) / 180;
      const theta = (lng * Math.PI) / 180;
      return {
        x: Math.cos(phi) * Math.sin(theta),
        y: Math.sin(phi),
        z: Math.cos(phi) * Math.cos(theta),
      };
    };

    const nodeVectors = FEATURED_NODES.map((node) => ({
      ...node,
      vec: convertLatLngToVector(node.lat, node.lng),
    }));

    const resize = () => {
      if (!canvas || !canvas.parentElement) return;
      const rect = canvas.parentElement.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = rect.width;
      height = rect.height;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      ctx.scale(dpr, dpr);
    };

    window.addEventListener('resize', resize);
    resize();

    // Scroll Velocity Physics for dynamic rotation when scrolling the page
    let scrollVelocity = 0;
    let lastScrollY = typeof window !== 'undefined' ? window.scrollY : 0;

    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      const delta = currentScrollY - lastScrollY;
      lastScrollY = currentScrollY;
      scrollVelocity += delta * 0.0025; // Add scroll delta to rotation velocity
    };

    window.addEventListener('scroll', handleScroll, { passive: true });

    const handleMouseDown = (e: MouseEvent) => {
      isDragging = true;
      previousMouseX = e.clientX;
      previousMouseY = e.clientY;
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const deltaX = e.clientX - previousMouseX;
      const deltaY = e.clientY - previousMouseY;
      targetRotY += deltaX * 0.005;
      targetRotX = Math.max(-0.8, Math.min(0.8, targetRotX + deltaY * 0.005));
      previousMouseX = e.clientX;
      previousMouseY = e.clientY;
    };

    const handleMouseUp = () => {
      isDragging = false;
    };

    const canvasEl = canvas;
    canvasEl.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);

    let time = 0;

    const render = () => {
      time += 0.015;
      if (!isDragging) {
        targetRotY += 0.0018 + scrollVelocity; // Dynamic rotation driven by scroll velocity
      }
      scrollVelocity *= 0.92; // Friction decay for smooth spinning inertia

      rotY += (targetRotY - rotY) * 0.08;
      rotX += (targetRotX - rotX) * 0.08;

      ctx.clearRect(0, 0, width, height);

      const centerX = width / 2;
      const centerY = height * 0.50; // Perfectly centered vertically
      const isMobile = width < 640;
      const globeRadius = Math.min(width * (isMobile ? 0.42 : 0.35), height * 0.40, 340); // Perfect sweet-spot radius without cropping
      const focalLength = 800;

      // 1. Soft Green Ambient Glow behind Globe (#1ABE56)
      const glowGrad = ctx.createRadialGradient(
        centerX,
        centerY,
        globeRadius * 0.2,
        centerX,
        centerY,
        globeRadius * 1.5
      );
      glowGrad.addColorStop(0, 'rgba(26, 190, 86, 0.12)');
      glowGrad.addColorStop(0.5, 'rgba(26, 190, 86, 0.03)');
      glowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = glowGrad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, globeRadius * 1.5, 0, Math.PI * 2);
      ctx.fill();

      // 2. Subtle Background Slate Grid
      const gridSpacing = 40;
      ctx.fillStyle = 'rgba(148, 163, 184, 0.02)';
      for (let x = 0; x < width; x += gridSpacing) {
        for (let y = 0; y < height; y += gridSpacing) {
          ctx.fillRect(x, y, 1.2, 1.2);
        }
      }

      // Rotate 3D Vector Math
      const rotatePoint = (v: { x: number; y: number; z: number }) => {
        const cosY = Math.cos(rotY);
        const sinY = Math.sin(rotY);
        const x1 = v.x * cosY + v.z * sinY;
        const z1 = -v.x * sinY + v.z * cosY;

        const cosX = Math.cos(rotX);
        const sinX = Math.sin(rotX);
        const y2 = v.y * cosX - z1 * sinX;
        const z2 = v.y * sinX + z1 * cosX;

        return { x: x1, y: y2, z: z2 };
      };

      // 3. Render Low-Contrast Soft Micro-Dot Cloud (#1ABE56 Green Continents + Slate Gray Ocean Grid)
      for (let i = 0; i < globeDots.length; i++) {
        const pt = globeDots[i];
        const rot = rotatePoint(pt);

        const scale = focalLength / (focalLength - rot.z * globeRadius);
        const sx = centerX + rot.x * globeRadius * scale;
        const sy = centerY + rot.y * globeRadius * scale;

        const depthAlpha = (rot.z + 1) / 2; // 0 to 1

        if (pt.isLand) {
          // CONTINENT MICRO-DOTS: Softened #1ABE56 Emerald Green
          if (rot.z > -0.2) {
            const opacity = Math.pow(depthAlpha, 1.3) * 0.45 + 0.05;
            ctx.fillStyle = `rgba(26, 190, 86, ${opacity.toFixed(2)})`;
            const dotSize = (rot.z > 0.4 ? 1.1 : 0.85) * scale;
            ctx.fillRect(sx - dotSize / 2, sy - dotSize / 2, dotSize, dotSize);
          } else {
            // Back-side continent dots
            ctx.fillStyle = `rgba(71, 85, 105, ${(depthAlpha * 0.10).toFixed(2)})`;
            ctx.fillRect(sx - 0.5, sy - 0.5, 0.8, 0.8);
          }
        } else {
          // OCEAN GRID MICRO-DOTS: Dim Slate Gray
          if (rot.z > 0.05) {
            const oceanAlpha = (depthAlpha * 0.10).toFixed(2);
            ctx.fillStyle = `rgba(148, 163, 184, ${oceanAlpha})`;
            ctx.fillRect(sx - 0.4, sy - 0.4, 0.6, 0.6);
          }
        }
      }

      // 4. Project Hotspot Nodes & Green/Gray Connection Arcs
      const projectedNodes = nodeVectors.map((node) => {
        const rot = rotatePoint(node.vec);
        const scale = focalLength / (focalLength - rot.z * globeRadius);
        const sx = centerX + rot.x * globeRadius * scale;
        const sy = centerY + rot.y * globeRadius * scale;
        return { ...node, sx, sy, rotZ: rot.z, scale };
      });

      // Draw Arcs
      for (let i = 0; i < projectedNodes.length; i++) {
        for (let j = i + 1; j < projectedNodes.length; j++) {
          const n1 = projectedNodes[i];
          const n2 = projectedNodes[j];

          if (n1.rotZ > -0.1 && n2.rotZ > -0.1) {
            const midX = (n1.sx + n2.sx) / 2;
            const midY = (n1.sy + n2.sy) / 2 - 45;

            const arcAlpha = Math.min(n1.rotZ + 0.1, n2.rotZ + 0.1) * 0.65;

            // Dual Gradient Arc (Green #1ABE56 & Slate Gray)
            ctx.beginPath();
            ctx.moveTo(n1.sx, n1.sy);
            ctx.quadraticCurveTo(midX, midY, n2.sx, n2.sy);
            ctx.strokeStyle = `rgba(26, 190, 86, ${arcAlpha})`;
            ctx.lineWidth = 1.4;
            ctx.stroke();

            // Energy packet along arc
            const progress = (time * 0.45 + i + j) % 1;
            const px = (1 - progress) * (1 - progress) * n1.sx + 2 * (1 - progress) * progress * midX + progress * progress * n2.sx;
            const py = (1 - progress) * (1 - progress) * n1.sy + 2 * (1 - progress) * progress * midY + progress * progress * n2.sy;

            ctx.fillStyle = '#1ABE56';
            ctx.beginPath();
            ctx.arc(px, py, 2.5, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#FFFFFF';
            ctx.beginPath();
            ctx.arc(px, py, 1.2, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      }

      // Render glowing node markers and connection arcs cleanly without text labels
      projectedNodes.forEach((node) => {
        if (node.rotZ > 0.05) {
          const alpha = Math.min(1, node.rotZ * 1.5);

          const pulse = (Math.sin(time * 3 + node.lat) + 1) / 2;
          const ringRadius = (8 + pulse * 7) * node.scale;

          // Outer Green Ring
          ctx.strokeStyle = `rgba(26, 190, 86, ${alpha * 0.85})`;
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(node.sx, node.sy, ringRadius, 0, Math.PI * 2);
          ctx.stroke();

          // Slate Gray Accent Ring
          ctx.strokeStyle = `rgba(148, 163, 184, ${alpha * 0.5})`;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.arc(node.sx, node.sy, ringRadius + 3, 0, Math.PI * 2);
          ctx.stroke();

          // Green Core Marker
          ctx.fillStyle = '#1ABE56';
          ctx.beginPath();
          ctx.arc(node.sx, node.sy, 4.5 * node.scale, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = '#FFFFFF';
          ctx.beginPath();
          ctx.arc(node.sx, node.sy, 2 * node.scale, 0, Math.PI * 2);
          ctx.fill();
        }
      });

      if (isIntersecting) {
        animationFrameId = requestAnimationFrame(render);
      } else {
        // Retry when visible without doing expensive calculations
        animationFrameId = requestAnimationFrame(() => {
          if (isIntersecting) render();
        });
      }
    };

    render();

    return () => {
      observer.disconnect();
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', resize);
      canvasEl.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  return (
    <div className="absolute inset-0 w-full h-full overflow-hidden pointer-events-auto">
      <canvas
        ref={canvasRef}
        className="w-full h-full block cursor-grab active:cursor-grabbing"
      />
    </div>
  );
}
