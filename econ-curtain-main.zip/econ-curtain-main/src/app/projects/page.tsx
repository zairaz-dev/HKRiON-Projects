"use client";

import { Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { projects, projectCategories } from "@/data/projects";
import Link from "next/link";
import Image from "next/image";

function ProjectsContent() {
  const searchParams = useSearchParams();
  const catParam = searchParams.get("cat");
  const activeCategory = (catParam && projectCategories.includes(catParam)) ? catParam : "All";

  const filteredProjects = activeCategory === "All" 
    ? projects 
    : projects.filter(project => project.category === activeCategory);

  return (
    <div className="flex flex-col w-full bg-slate-950 text-slate-100 min-h-screen">
      {/* Page Header */}
      <section className="bg-slate-900 py-20 px-4 border-b border-slate-800">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Our <span className="text-amber-400">Projects</span>
          </h1>
          <p className="text-slate-300 max-w-2xl mx-auto text-lg">
            Browse through our portfolio of residential and commercial installations. Each project showcases our commitment to quality and design.
          </p>
        </div>
      </section>

      {/* Filter Options */}
      <section className="py-6 bg-slate-900/90 backdrop-blur-xl border-b border-slate-800 sticky top-17 sm:top-18 z-30 shadow-2xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3">
            {projectCategories.map((category) => {
              const isActive = activeCategory === category;
              const href = category === "All" ? "/projects" : `/projects?cat=${encodeURIComponent(category)}`;

              return (
                <Link
                  key={category}
                  href={href}
                  scroll={false}
                  className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-semibold transition-all duration-200 ${
                    isActive
                      ? "bg-linear-to-r from-primary via-amber-500 to-yellow-500 text-slate-950 shadow-lg shadow-amber-500/20 scale-105 font-bold"
                      : "bg-slate-950 text-slate-400 border border-slate-800 hover:text-white hover:border-slate-700"
                  }`}
                >
                  {category}
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Project Grid */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project) => (
              <div 
                key={project.id}
                className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-xl hover:border-amber-400/50 transition-all group"
              >
                <div className="relative h-64 overflow-hidden bg-slate-950">
                  <Image 
                    src={project.image} 
                    alt={project.title}
                    fill
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4 bg-slate-900/90 backdrop-blur-md text-amber-400 border border-amber-400/30 px-3 py-1 rounded-full text-xs font-semibold">
                    {project.category}
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="text-xl font-bold text-white mb-2">{project.title}</h3>
                  <p className="text-slate-400 text-sm mb-4 line-clamp-2">{project.description}</p>
                  
                  <div className="pt-4 border-t border-slate-800/80 text-xs text-slate-400">
                    <p><span className="font-semibold text-slate-300">Client:</span> {project.client}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default function ProjectsPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">Loading Projects...</div>}>
      <ProjectsContent />
    </Suspense>
  );
}
