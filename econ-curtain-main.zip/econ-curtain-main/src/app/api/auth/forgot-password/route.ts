import { NextResponse } from "next/server";
import { UserService } from "@/services/user.service";
import { SafeHttp } from "@/core/http/redirect";
import { RateLimiter } from "@/core/security/rateLimiter";

export async function POST(request: Request) {
  try {
    const clientIp = RateLimiter.getClientIp(request);
    const rateCheck = RateLimiter.check(`forgot_pw_${clientIp}`, 3, 5 * 60 * 1000);

    const contentType = request.headers.get("content-type") || "";
    const isJson = contentType.includes("application/json");

    if (!rateCheck.allowed) {
      const errorMsg = `Too many password reset attempts. Please wait ${rateCheck.retryAfterSeconds} seconds before trying again.`;
      if (isJson) {
        return NextResponse.json(
          { success: false, error: errorMsg },
          { status: 429, headers: { "Retry-After": rateCheck.retryAfterSeconds.toString() } }
        );
      }
      return SafeHttp.redirect(`/forgot-password?error=${encodeURIComponent(errorMsg)}`, request, 303);
    }

    let email = "";
    let newPassword = "";
    let confirmPassword = "";

    if (isJson) {
      const body = await request.json();
      email = body.email || "";
      newPassword = body.newPassword || "";
      confirmPassword = body.confirmPassword || "";
    } else {
      const formData = await request.formData();
      email = (formData.get("email") as string) || "";
      newPassword = (formData.get("newPassword") as string) || "";
      confirmPassword = (formData.get("confirmPassword") as string) || "";
    }

    if (!email || !newPassword) {
      if (isJson) {
        return NextResponse.json({ success: false, error: "Email and new password are required." }, { status: 400 });
      }
      return SafeHttp.redirect(
        `/forgot-password?error=${encodeURIComponent("Email and new password are required.")}`,
        request,
        303
      );
    }

    if (newPassword.length < 6) {
      if (isJson) {
        return NextResponse.json({ success: false, error: "Password must be at least 6 characters long." }, { status: 400 });
      }
      return SafeHttp.redirect(
        `/forgot-password?error=${encodeURIComponent("Password must be at least 6 characters long.")}`,
        request,
        303
      );
    }

    if (newPassword !== confirmPassword) {
      if (isJson) {
        return NextResponse.json(
          { success: false, error: "New password and confirmation do not match." },
          { status: 400 }
        );
      }
      return SafeHttp.redirect(
        `/forgot-password?error=${encodeURIComponent("New password and confirmation do not match.")}`,
        request,
        303
      );
    }

    const result = await UserService.resetPassword(email, newPassword);

    if (!result.success) {
      if (isJson) {
        return NextResponse.json({ success: false, error: result.error }, { status: 400 });
      }
      return SafeHttp.redirect(
        `/forgot-password?error=${encodeURIComponent(result.error || "Password reset failed.")}`,
        request,
        303
      );
    }

    if (isJson) {
      return NextResponse.json({ success: true, message: "Password reset successfully!" });
    }

    return SafeHttp.redirect(
      `/login?success=${encodeURIComponent("Password reset successfully! Please sign in with your new password.")}`,
      request,
      303
    );
  } catch (error) {
    console.error("Forgot password error:", error);
    return SafeHttp.redirect(
      `/forgot-password?error=${encodeURIComponent("An unexpected error occurred.")}`,
      request,
      303
    );
  }
}
