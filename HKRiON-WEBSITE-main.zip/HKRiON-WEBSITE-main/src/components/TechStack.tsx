'use client';

import { useState } from 'react';
import Image from 'next/image';
import { Zap, Sparkles } from 'lucide-react';

interface TechItem {
  name: string;
  desc: string;
  glowColor: string;
  icon: React.ReactNode;
}

const allTechnologies: TechItem[] = [
  {
    name: 'React 19',
    desc: 'Concurrent rendering & modern UI components',
    glowColor: 'rgba(97, 218, 251, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/react/61DAFB" alt="React Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'Next.js 16',
    desc: 'SSR, App Router & Turbopack speed',
    glowColor: 'rgba(255, 255, 255, 0.35)',
    icon: (
      <Image src="https://cdn.simpleicons.org/nextdotjs/ffffff" alt="Next.js Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'TypeScript',
    desc: 'Strict type safety & bug-free code',
    glowColor: 'rgba(49, 120, 198, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/typescript/3178C6" alt="TypeScript Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'Tailwind CSS',
    desc: 'Utility-first fluid responsive design engine',
    glowColor: 'rgba(56, 189, 248, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/tailwindcss/06B6D4" alt="Tailwind CSS Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'Flutter',
    desc: 'Cross-platform 60 FPS native mobile apps',
    glowColor: 'rgba(84, 197, 248, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/flutter/02569B" alt="Flutter Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'React Native',
    desc: 'Native iOS & Android mobile ecosystem',
    glowColor: 'rgba(97, 218, 251, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/react/61DAFB" alt="React Native Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'Node.js',
    desc: 'Asynchronous event-driven server runtime',
    glowColor: 'rgba(104, 160, 99, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/nodedotjs/5FA04E" alt="Node.js Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'NestJS',
    desc: 'Enterprise modular Node backend framework',
    glowColor: 'rgba(234, 40, 88, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/nestjs/E0234E" alt="NestJS Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'Express.js',
    desc: 'Minimalist RESTful microservices engine',
    glowColor: 'rgba(255, 255, 255, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/express/ffffff" alt="Express.js Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'GraphQL',
    desc: 'Precise client data query language',
    glowColor: 'rgba(229, 53, 171, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/graphql/E10098" alt="GraphQL Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'MySQL',
    desc: 'ACID-compliant relational database vault',
    glowColor: 'rgba(68, 121, 161, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/mysql/4479A1" alt="MySQL Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'PostgreSQL',
    desc: 'Robust object-relational analytics database',
    glowColor: 'rgba(65, 105, 225, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/postgresql/4169E1" alt="PostgreSQL Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'MongoDB',
    desc: 'High-velocity NoSQL document store',
    glowColor: 'rgba(71, 162, 72, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/mongodb/47A248" alt="MongoDB Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'Prisma ORM',
    desc: 'Type-safe database client & safe migrations',
    glowColor: 'rgba(255, 255, 255, 0.35)',
    icon: (
      <Image src="https://cdn.simpleicons.org/prisma/ffffff" alt="Prisma Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'Redis',
    desc: 'Sub-millisecond in-memory cache & sessions',
    glowColor: 'rgba(220, 56, 45, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/redis/DC382D" alt="Redis Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'Firebase',
    desc: 'Realtime WebSocket document & state sync',
    glowColor: 'rgba(255, 202, 40, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/firebase/FFCA28" alt="Firebase Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'Docker',
    desc: 'Standardized containerized software deployment',
    glowColor: 'rgba(36, 150, 237, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/docker/2496ED" alt="Docker Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'AWS Cloud',
    desc: 'Scalable elastic cloud server infrastructure',
    glowColor: 'rgba(255, 153, 0, 0.4)',
    icon: (
      <svg viewBox="0 0 24 24" className="w-4.5 h-4.5 sm:w-6 sm:h-6 fill-[#FF9900]">
        <path d="M18.75 10.31a6.002 6.002 0 0 0-11.5-1.81A4.5 4.5 0 0 0 3 13.5 4.5 4.5 0 0 0 7.5 18h11a3.5 3.5 0 0 0 3.5-3.5 3.5 3.5 0 0 0-3.25-3.19z"/>
      </svg>
    )
  },
  {
    name: 'Microsoft Azure',
    desc: 'Enterprise hybrid cloud hosting ecosystem',
    glowColor: 'rgba(0, 137, 214, 0.4)',
    icon: (
      <svg viewBox="0 0 24 24" className="w-4.5 h-4.5 sm:w-6 sm:h-6 fill-[#0089D6]">
        <path d="M13.05 2.25L6.6 13.5l4.35 8.25h6.45l-4.35-8.25 6.45-11.25h-6.45zm-7.95 12l-2.7 4.5h4.35l2.7-4.5h-4.35z"/>
      </svg>
    )
  },
  {
    name: 'Kubernetes',
    desc: 'Microservices container cluster orchestration',
    glowColor: 'rgba(50, 108, 229, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/kubernetes/326CE5" alt="Kubernetes Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'Nginx',
    desc: 'High-speed HTTP reverse proxy & SSL load balancer',
    glowColor: 'rgba(0, 150, 57, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/nginx/009639" alt="Nginx Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'GitHub Actions',
    desc: 'Automated CI/CD testing & zero-downtime deploy',
    glowColor: 'rgba(32, 136, 255, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/githubactions/2088FF" alt="GitHub Actions Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'Git',
    desc: 'Distributed version control & source code audit',
    glowColor: 'rgba(240, 50, 50, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/git/F05032" alt="Git Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  },
  {
    name: 'Postman',
    desc: 'API testing, documentation & mock servers',
    glowColor: 'rgba(255, 108, 55, 0.4)',
    icon: (
      <Image src="https://cdn.simpleicons.org/postman/FF6C37" alt="Postman Logo" width={24} height={24} className="w-4.5 h-4.5 sm:w-6 sm:h-6 object-contain shrink-0" unoptimized />
    )
  }
];

const row1Techs = allTechnologies.slice(0, 12);
const row2Techs = allTechnologies.slice(12);

export default function TechStack() {
  const [hoveredTech, setHoveredTech] = useState<TechItem | null>(null);

  return (
    <section id="techstack" className="py-8 sm:py-12 bg-black relative overflow-hidden border-b border-[#1ABE56]/30">
      
      {/* Ambient background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 sm:w-120 h-80 sm:h-120 bg-[#1ABE56]/10 blur-[120px] sm:blur-[150px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto space-y-2 mb-6 sm:mb-8">
          <span className="text-[9px] sm:text-[10px] font-mono font-bold uppercase tracking-widest text-[#1ABE56] bg-[#1ABE56]/10 px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-full border border-[#1ABE56]/30 inline-flex items-center gap-1.5 animate-pulse">
            <Zap className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-[#1ABE56]" />
            POWERING MODERN APPLICATIONS
          </span>
          <h2 className="text-xl sm:text-4xl font-semibold text-white tracking-tight">
            Engineered with <span className="gradient-text">Modern Tech Stack</span>
          </h2>
          <p className="text-neutral-400 text-[11px] sm:text-sm max-w-lg mx-auto">
            We leverage battle-tested frameworks, cloud infrastructure, and database architectures to build fast, secure, and future-proof software.
          </p>
        </div>

        {/* Continuous Auto-Scrolling Logo Tickers */}
        <div className="space-y-2 sm:space-y-3">
          
          {/* Row 1 - Auto-Scrolling Left to Right */}
          <div className="overflow-hidden relative py-1.5 sm:py-2">
            <div className="absolute left-0 top-0 bottom-0 w-12 sm:w-24 bg-linear-to-r from-black via-black/80 to-transparent z-20 pointer-events-none" />
            <div className="absolute right-0 top-0 bottom-0 w-12 sm:w-24 bg-linear-to-l from-black via-black/80 to-transparent z-20 pointer-events-none" />

            <div className="animate-marquee-slow flex items-center gap-2.5 sm:gap-4">
              {[...row1Techs, ...row1Techs, ...row1Techs].map((tech, idx) => (
                <div
                  key={idx}
                  onMouseEnter={() => setHoveredTech(tech)}
                  onMouseLeave={() => setHoveredTech(null)}
                  className={`w-8.5 h-8.5 sm:w-11 sm:h-11 rounded-lg sm:rounded-xl bg-neutral-950 border flex items-center justify-center shrink-0 transition-all duration-300 hover:scale-115 cursor-pointer shadow-md group ${
                    hoveredTech?.name === tech.name ? 'border-[#1ABE56] scale-110' : 'border-white/10 hover:border-[#1ABE56]'
                  }`}
                  style={{ boxShadow: `0 0 10px ${tech.glowColor}` }}
                >
                  {tech.icon}
                </div>
              ))}
            </div>
          </div>

          {/* Row 2 - Auto-Scrolling Right to Left */}
          <div className="overflow-hidden relative py-1.5 sm:py-2">
            <div className="absolute left-0 top-0 bottom-0 w-12 sm:w-24 bg-linear-to-r from-black via-black/80 to-transparent z-20 pointer-events-none" />
            <div className="absolute right-0 top-0 bottom-0 w-12 sm:w-24 bg-linear-to-l from-black via-black/80 to-transparent z-20 pointer-events-none" />

            <div className="animate-marquee-reverse flex items-center gap-2.5 sm:gap-4">
              {[...row2Techs, ...row2Techs, ...row2Techs].map((tech, idx) => (
                <div
                  key={idx}
                  onMouseEnter={() => setHoveredTech(tech)}
                  onMouseLeave={() => setHoveredTech(null)}
                  className={`w-8.5 h-8.5 sm:w-11 sm:h-11 rounded-lg sm:rounded-xl bg-neutral-950 border flex items-center justify-center shrink-0 transition-all duration-300 hover:scale-115 cursor-pointer shadow-md group ${
                    hoveredTech?.name === tech.name ? 'border-[#1ABE56] scale-110' : 'border-white/10 hover:border-[#1ABE56]'
                  }`}
                  style={{ boxShadow: `0 0 10px ${tech.glowColor}` }}
                >
                  {tech.icon}
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Dynamic High-Tech Live Inspector Bar (Never Cut Off / Clipped!) */}
        <div className="mt-4 sm:mt-6 flex justify-center">
          <div className="glass-card px-4 sm:px-6 py-2 sm:py-2.5 rounded-xl sm:rounded-2xl border border-[#1ABE56]/40 bg-neutral-950/90 flex items-center justify-center min-h-11 sm:min-h-12 shadow-lg shadow-[#1ABE56]/10 max-w-md w-full transition-all duration-300">
            {hoveredTech ? (
              <div className="flex items-center gap-3 text-left w-full">
                <div 
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-black flex items-center justify-center border border-white/10 shrink-0"
                  style={{ boxShadow: `0 0 10px ${hoveredTech.glowColor}` }}
                >
                  {hoveredTech.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs sm:text-sm font-extrabold text-white truncate">{hoveredTech.name}</h4>
                    <span className="w-1.5 h-1.5 rounded-full bg-[#1ABE56] shrink-0 animate-pulse" />
                  </div>
                  <p className="text-[10px] sm:text-xs text-neutral-400 font-mono truncate mt-0.5">{hoveredTech.desc}</p>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-neutral-400 text-[11px] sm:text-xs font-mono">
                <Sparkles className="w-3.5 h-3.5 text-[#1ABE56] shrink-0 animate-pulse" />
                <span>Hover over any technology icon to inspect details</span>
              </div>
            )}
          </div>
        </div>

      </div>
    </section>
  );
}

