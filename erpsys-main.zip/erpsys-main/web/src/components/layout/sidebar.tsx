"use strict";
"use client";

import React, { useEffect, useState } from "react";
import { 
  Layers, 
  LayoutDashboard, 
  ShoppingBag, 
  Package, 
  Users, 
  CreditCard, 
  Settings, 
  Menu, 
  X, 
  Globe, 
  ChevronDown, 
  Building2, 
  Tag, 
  Scale, 
  SlidersHorizontal, 
  ArrowRightLeft, 
  BarChart3 
} from "lucide-react";
import { authService } from "@/services/auth-service";
import { usePermissions } from "@/hooks/use-permissions";
import { User } from "@hkr/types";
import Link from "next/link";
import { cn } from "@/lib/utils";

/**
 * ==========================================================================
 * SidebarProps Interface
 * ==========================================================================
 */
interface SidebarProps {
  /**
   * The current active URL path (e.g. "/dashboard", "/pos")
   * Used to highlight the active navigation item.
   */
  activePath: string;
}

/**
 * ==========================================================================
 * Reusable Sidebar Component
 * ==========================================================================
 * 
 * Renders the fixed vertical sidebar on the left side of the screen.
 * Features:
 * - Logo branding.
 * - Navigation links (Dashboard, POS, Inventory, etc.) with active states.
 * - Disabled states for locked modules.
 * - Current logged-in user profile badge.
 * - Sign Out button linked to `authService.logout()`.
 */
export function Sidebar({ activePath }: SidebarProps) {
  const { hasPermission, isAdmin, isSuperAdmin, isMounted, currentUser } = usePermissions();
  const [isSuperAdminOpen, setIsSuperAdminOpen] = useState(false);
  const [isProductsOpen, setIsProductsOpen] = useState(false);
  const [isContactsOpen, setIsContactsOpen] = useState(false);
  const [isExpensesOpen, setIsExpensesOpen] = useState(false);
  const [isPurchasesOpen, setIsPurchasesOpen] = useState(false);
  const [isSalesOpen, setIsSalesOpen] = useState(false);
  const [isReportsOpen, setIsReportsOpen] = useState(false);

  // Auto-open dropdowns based on active route
  useEffect(() => {
    if (activePath.startsWith("/super")) {
      setIsSuperAdminOpen(true);
    }
    if (
      activePath === "/products" ||
      activePath === "/categories" ||
      activePath === "/brands" ||
      activePath === "/units" ||
      activePath === "/variations" ||
      activePath === "/selling-price-groups" ||
      activePath === "/warranties" ||
      activePath === "/products/imei"
    ) {
      setIsProductsOpen(true);
    }
    if (activePath === "/customer-groups" || activePath === "/customers" || activePath === "/suppliers") {
      setIsContactsOpen(true);
    }
    if (activePath === "/expense-categories" || activePath === "/expenses") {
      setIsExpensesOpen(true);
    }
    if (activePath.startsWith("/purchases")) {
      setIsPurchasesOpen(true);
    }
    if (activePath.startsWith("/sales") || activePath === "/pos") {
      setIsSalesOpen(true);
    }
    if (activePath.startsWith("/reports")) {
      setIsReportsOpen(true);
    }
  }, [activePath]);

  // Master navigation links configuration with permission gates
  const rawNavItems = React.useMemo(() => [
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    { name: "User Management", href: "/users", icon: Users, permission: "users:view" },
    { name: "Branches", href: "/branches", icon: Building2, permission: "settings:view" },
    {
      name: "Contacts",
      href: "#",
      icon: Users,
      permission: "contacts:view",
      subItems: [
        { name: "Customers", href: "/customers", permission: "contacts:view" },
        { name: "Suppliers", href: "/suppliers", permission: "contacts:view" },
        { name: "Customer Groups", href: "/customer-groups", permission: "contacts:view" },
      ]
    },
    {
      name: "Products",
      href: "#",
      icon: Layers,
      permission: "inventory:view",
      subItems: [
        { name: "Product List", href: "/products", permission: "inventory:view" },
        { name: "Categories", href: "/categories", permission: "inventory:view" },
        { name: "Brands", href: "/brands", permission: "inventory:view" },
        { name: "Units", href: "/units", permission: "inventory:view" },
        { name: "Variations", href: "/variations", permission: "inventory:view" },
        { name: "Selling Price Groups", href: "/selling-price-groups", permission: "inventory:view" },
        { name: "Warranties", href: "/warranties", permission: "inventory:view" },
        { name: "IMEI / Serial Tracker", href: "/products/imei", permission: "inventory:view" },
      ]
    },
    { name: "Stock Adjustments", href: "/stock-adjustments", icon: SlidersHorizontal, permission: "inventory:adjust_stock" },
    { name: "Stock Transfers", href: "/stock-transfers", icon: ArrowRightLeft, permission: "inventory:transfer_stock" },
    {
      name: "Expenses",
      href: "#",
      icon: CreditCard,
      permission: "finance:add_expense",
      subItems: [
        { name: "Expense List", href: "/expenses", permission: "finance:add_expense" },
        { name: "Expense Categories", href: "/expense-categories", permission: "finance:add_expense" },
      ]
    },
    {
      name: "Sales",
      href: "#",
      icon: ShoppingBag,
      permission: "pos:view",
      subItems: [
        { name: "Sales", href: "/sales", permission: "pos:view" },
        { name: "Hold Bills", href: "/sales/drafts", permission: "pos:view" },
        { name: "Quotations", href: "/sales/quotations", permission: "quotations:view" },
        { name: "POS", href: "/pos", permission: "pos:view" },
        { name: "Sales Returns", href: "/sales/returns", permission: "pos:view" },
      ]
    },
    {
      name: "Purchases",
      href: "#",
      icon: Package,
      permission: "purchases:view",
      subItems: [
        { name: "Purchases", href: "/purchases", permission: "purchases:view" },
        { name: "Add Purchases", href: "/purchases/create", permission: "purchases:create" },
        { name: "Purchase Returns", href: "/purchases/returns", permission: "purchases:view" },
      ]
    },
    {
      name: "Reports",
      href: "#",
      icon: BarChart3,
      permission: "finance:view_reports",
      subItems: [
        { name: "Profit & Loss", href: "/reports/profit-loss", permission: "finance:view_reports" },
        { name: "Stock Valuation", href: "/reports/stock-valuation", permission: "finance:view_reports" },
        { name: "Sales & Purchases", href: "/reports/sales-purchases", permission: "finance:view_reports" },
        { name: "Contact Balances", href: "/reports/contact-balances", permission: "finance:view_reports" },
      ]
    },
    { name: "Settings", href: "/settings", icon: Settings, permission: "settings:view" },
  ], []);

  // Filter navigation links dynamically according to current user's permissions
  const navItems = React.useMemo(() => {
    // Before mounting on the client, render rawNavItems to guarantee SSR and Client initial HTML match 100%
    if (!isMounted) {
      return rawNavItems;
    }

    const list: any[] = rawNavItems
      .filter((item) => {
        if (!item.permission) return true;
        return hasPermission(item.permission);
      })
      .map((item) => {
        if (item.subItems) {
          const visibleSubItems = item.subItems.filter(
            (sub: any) => !sub.permission || hasPermission(sub.permission)
          );
          return { ...item, subItems: visibleSubItems };
        }
        return item;
      })
      .filter((item) => !item.subItems || item.subItems.length > 0);

    if (isSuperAdmin) {
      list.push({
        name: "Super Admin",
        href: "#",
        icon: Globe,
        disabled: false,
        subItems: [
          { name: "Business Registry", href: "/super", disabled: false },
          { name: "User Management", href: "/super/users", disabled: false },
          { name: "Subscription Plans", href: "/super/subscriptions", disabled: false },
          { name: "CMS & Landing Page", href: "/super/cms", disabled: false },
          { name: "Platform Settings", href: "/super/settings", disabled: false },
          { name: "System Analytics", href: "/super/analytics", disabled: false },
        ]
      });
    }

    return list;
  }, [rawNavItems, hasPermission, isSuperAdmin, isMounted]);

  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  // Listen for custom toggle-sidebar event from Navbar
  useEffect(() => {
    const handleToggle = () => setIsDrawerOpen(prev => !prev);
    document.addEventListener("toggle-sidebar", handleToggle);
    return () => document.removeEventListener("toggle-sidebar", handleToggle);
  }, []);

  // Close button inside drawer
  const DrawerClose = (
    <button
      className="absolute top-4 right-4 text-muted-foreground hover:text-foreground"
      onClick={() => setIsDrawerOpen(false)}
    >
      <X className="w-6 h-6" />
    </button>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="w-56 border-r border-border bg-card/60 backdrop-blur-md hidden md:flex flex-col h-screen sticky top-0 z-30">
        {/* Logo Brand Section */}
        <div className="h-16 border-b border-border px-4 flex items-center shrink-0">
          <Link href="/" className="block">
            <div className="flex items-center gap-3 cursor-pointer">
              <div className="w-9 h-9 flex items-center justify-center shrink-0">
                <img 
                  src="/logo.png" 
                  alt="HKRiON ERP Logo" 
                  className="w-full h-full object-contain" 
                />
              </div>
              <div>
                <h1 className="text-md font-extrabold tracking-tight text-foreground">
                  HKRiON <span className="text-primary">ERP</span>
                </h1>
              </div>
            </div>
          </Link>
        </div>
        
        {/* Navigation Links List */}
        <nav className="flex-1 overflow-y-auto space-y-2.5 px-3 pt-3.5 pb-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            
            if (item.subItems) {
              const isSubActive = item.subItems.some((sub: any) => activePath === sub.href);
              let isOpen = false;
              let setIsOpen = (val: boolean) => {};

              if (item.name === "Super Admin") {
                isOpen = isSuperAdminOpen;
                setIsOpen = setIsSuperAdminOpen;
              } else if (item.name === "Products") {
                isOpen = isProductsOpen;
                setIsOpen = setIsProductsOpen;
              } else if (item.name === "Contacts") {
                isOpen = isContactsOpen;
                setIsOpen = setIsContactsOpen;
              } else if (item.name === "Expenses") {
                isOpen = isExpensesOpen;
                setIsOpen = setIsExpensesOpen;
              } else if (item.name === "Purchases") {
                isOpen = isPurchasesOpen;
                setIsOpen = setIsPurchasesOpen;
              } else if (item.name === "Sales") {
                isOpen = isSalesOpen;
                setIsOpen = setIsSalesOpen;
              } else if (item.name === "Reports") {
                isOpen = isReportsOpen;
                setIsOpen = setIsReportsOpen;
              }
              
              return (
                <div key={item.name} className="space-y-1">
                  <button
                    onClick={() => setIsOpen(!isOpen)}
                    className={cn(
                      "relative group w-full flex items-center justify-between px-3 py-2.5 rounded-sm font-medium text-sm transition-all duration-200 text-left outline-none",
                      isSubActive 
                        ? "bg-primary/5 text-primary font-semibold" 
                        : "text-muted-foreground hover:text-foreground hover:bg-accent"
                    )}
                  >
                    {isSubActive && (
                      <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-5 rounded-r bg-primary animate-in fade-in slide-in-from-left-1 duration-200" />
                    )}
                    <div className="flex items-center gap-3">
                      <Icon className="w-4 h-4 transition-transform duration-200 group-hover:scale-110 group-hover:translate-x-0.5" />
                      {item.name}
                    </div>
                    <ChevronDown 
                      className={cn(
                        "w-3.5 h-3.5 text-muted-foreground transition-transform duration-200",
                        isOpen && "transform rotate-180"
                      )} 
                    />
                  </button>
                  
                  <div className={cn(
                    "grid transition-[grid-template-rows] duration-200 ease-in-out",
                    isOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]"
                  )}>
                    <div className="overflow-hidden">
                      <div className="pl-3 space-y-1 mt-1 pb-1">
                        {item.subItems.map((sub: any) => {
                          if (sub.disabled) {
                            return (
                              <span
                                key={sub.name}
                                className="flex items-center gap-2.5 pl-2.5 pr-3 py-2 text-sm text-muted-foreground/30 cursor-not-allowed select-none font-medium"
                              >
                                <span className="w-1.5 h-1.5 rounded-full border border-muted-foreground/30 shrink-0" />
                                {sub.name}
                              </span>
                            );
                          }
                          const isSubItemActive = activePath === sub.href;
                          return (
                            <Link key={sub.name} href={sub.href}>
                              <span
                                className={cn(
                                  "group flex items-center gap-2.5 pl-2.5 pr-3 py-2 rounded-sm text-sm font-medium transition cursor-pointer",
                                  isSubItemActive
                                    ? "text-primary font-semibold bg-primary/5"
                                    : "text-muted-foreground hover:text-foreground hover:bg-accent/40"
                                )}
                              >
                                <span className={cn(
                                  "w-1.5 h-1.5 rounded-full border shrink-0 transition-all duration-200",
                                  isSubItemActive 
                                    ? "border-primary bg-primary scale-125 shadow-sm shadow-primary/30" 
                                    : "border-muted-foreground/70 group-hover:border-foreground/90 group-hover:scale-110"
                                  )} />
                                <span className="transition-transform duration-200 group-hover:translate-x-0.5">
                                  {sub.name}
                                </span>
                              </span>
                            </Link>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              );
            }

            // Render disabled link state
            if (item.disabled) {
              return (
                <span 
                  key={item.name}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-sm text-muted-foreground/40 font-medium text-sm cursor-not-allowed select-none"
                >
                  <Icon className="w-4 h-4" />
                  {item.name}
                </span>
              );
            }

            const isActive = activePath === item.href;

            // Render active/inactive interactive link state
            return (
              <Link key={item.name} href={item.href} className="block w-full">
                <span 
                  className={cn(
                    "relative group flex items-center gap-3 px-3 py-2.5 rounded-sm font-medium text-sm cursor-pointer transition-all duration-200",
                    isActive 
                      ? "bg-primary/10 text-primary border border-primary/15 font-semibold" 
                      : "text-muted-foreground hover:text-foreground hover:bg-accent"
                  )}
                >
                  {isActive && (
                    <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-5 rounded-r bg-primary animate-in fade-in slide-in-from-left-1 duration-200" />
                  )}
                  <Icon className="w-4 h-4 transition-transform duration-200 group-hover:scale-110 group-hover:translate-x-0.5" />
                  {item.name}
                </span>
              </Link>
            );
          })}
        </nav>
      </aside>

      {/* Mobile Drawer Sidebar */}
      <div 
        className={cn(
          "fixed inset-0 bg-black/60 backdrop-blur-sm z-30 md:hidden transition-opacity duration-300",
          isDrawerOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        )}
        onClick={() => setIsDrawerOpen(false)}
      />
      <aside
        className={cn(
          "fixed top-0 bottom-0 left-0 w-64 z-40 bg-card/95 border-r border-border flex flex-col h-screen transform transition-transform duration-300 md:hidden",
          isDrawerOpen ? "translate-x-0" : "-translate-x-full"
        )}
        aria-hidden={!isDrawerOpen}
      >
        {DrawerClose}
        <div className="h-16 border-b border-border px-4 flex items-center shrink-0">
          <Link href="/" className="block w-full">
            <div className="flex items-center gap-3 cursor-pointer">
              <div className="w-9 h-9 flex items-center justify-center shrink-0">
                <img 
                  src="/logo.png" 
                  alt="HKRiON ERP Logo" 
                  className="w-full h-full object-contain" 
                />
              </div>
              <div>
                <h1 className="text-md font-extrabold tracking-tight text-foreground">
                  HKRiON <span className="text-primary">ERP</span>
                </h1>
              </div>
            </div>
          </Link>
        </div>
        <nav className="flex-1 overflow-y-auto space-y-2.5 px-3 pt-3.5 pb-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            
            if (item.subItems) {
              const isSubActive = item.subItems.some((sub: any) => activePath === sub.href);
              let isOpen = false;
              let setIsOpen = (val: boolean) => {};

              if (item.name === "Super Admin") {
                isOpen = isSuperAdminOpen;
                setIsOpen = setIsSuperAdminOpen;
              } else if (item.name === "Products") {
                isOpen = isProductsOpen;
                setIsOpen = setIsProductsOpen;
              } else if (item.name === "Contacts") {
                isOpen = isContactsOpen;
                setIsOpen = setIsContactsOpen;
              } else if (item.name === "Expenses") {
                isOpen = isExpensesOpen;
                setIsOpen = setIsExpensesOpen;
              } else if (item.name === "Purchases") {
                isOpen = isPurchasesOpen;
                setIsOpen = setIsPurchasesOpen;
              } else if (item.name === "Sales") {
                isOpen = isSalesOpen;
                setIsOpen = setIsSalesOpen;
              } else if (item.name === "Reports") {
                isOpen = isReportsOpen;
                setIsOpen = setIsReportsOpen;
              }
              
              return (
                <div key={item.name} className="space-y-1">
                  <button
                    onClick={() => setIsOpen(!isOpen)}
                    className={cn(
                      "relative group w-full flex items-center justify-between px-3 py-2.5 rounded-sm font-medium text-sm transition-all duration-200 text-left outline-none",
                      isSubActive 
                        ? "bg-primary/5 text-primary font-semibold" 
                        : "text-muted-foreground hover:text-foreground hover:bg-accent"
                    )}
                  >
                    {isSubActive && (
                      <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-5 rounded-r bg-primary animate-in fade-in slide-in-from-left-1 duration-200" />
                    )}
                    <div className="flex items-center gap-3">
                      <Icon className="w-4 h-4 transition-transform duration-200 group-hover:scale-110 group-hover:translate-x-0.5" />
                      {item.name}
                    </div>
                    <ChevronDown 
                      className={cn(
                        "w-3.5 h-3.5 text-muted-foreground transition-transform duration-200",
                        isOpen && "transform rotate-180"
                      )} 
                    />
                  </button>
                  
                  <div className={cn(
                    "grid transition-[grid-template-rows] duration-200 ease-in-out",
                    isOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]"
                  )}>
                    <div className="overflow-hidden">
                      <div className="pl-3 space-y-1 mt-1 pb-1">
                        {item.subItems.map((sub: any) => {
                          if (sub.disabled) {
                            return (
                              <span
                                key={sub.name}
                                className="flex items-center gap-2.5 pl-2.5 pr-3 py-2 text-sm text-muted-foreground/30 cursor-not-allowed select-none font-medium"
                              >
                                <span className="w-1.5 h-1.5 rounded-full border border-muted-foreground/30 shrink-0" />
                                {sub.name}
                              </span>
                            );
                          }
                          const isSubItemActive = activePath === sub.href;
                          return (
                            <Link key={sub.name} href={sub.href} className="block w-full">
                              <span
                                className={cn(
                                  "group flex items-center gap-2.5 pl-2.5 pr-3 py-2 rounded-sm text-sm font-medium transition cursor-pointer",
                                  isSubItemActive
                                    ? "text-primary font-semibold bg-primary/5"
                                    : "text-muted-foreground hover:text-foreground hover:bg-accent/40"
                                )}
                              >
                                <span className={cn(
                                  "w-1.5 h-1.5 rounded-full border shrink-0 transition-all duration-200",
                                  isSubItemActive 
                                    ? "border-primary bg-primary scale-125 shadow-sm shadow-primary/30" 
                                    : "border-muted-foreground/70 group-hover:border-foreground/90 group-hover:scale-110"
                                )} />
                                <span className="transition-transform duration-200 group-hover:translate-x-0.5">
                                  {sub.name}
                                </span>
                              </span>
                            </Link>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              );
            }

            if (item.disabled) {
              return (
                <span
                  key={item.name}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-sm text-muted-foreground/40 font-medium text-sm cursor-not-allowed select-none"
                >
                  <Icon className="w-4 h-4" />
                  {item.name}
                </span>
              );
            }
            const isActive = activePath === item.href;
            return (
              <Link key={item.name} href={item.href} className="block w-full">
                <span
                  className={cn(
                    "relative group flex items-center gap-3 px-3 py-2.5 rounded-sm font-medium text-sm cursor-pointer transition-all duration-200",
                    isActive
                      ? "bg-primary/10 text-primary border border-primary/15 font-semibold"
                      : "text-muted-foreground hover:text-foreground hover:bg-accent"
                  )}
                >
                  {isActive && (
                    <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-5 rounded-r bg-primary animate-in fade-in slide-in-from-left-1 duration-200" />
                  )}
                  <Icon className="w-4 h-4 transition-transform duration-200 group-hover:scale-110 group-hover:translate-x-0.5" />
                  {item.name}
                </span>
              </Link>
            );
          })}
        </nav>
      </aside>
    </>
  );
}
