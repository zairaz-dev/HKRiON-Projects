"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { Gemstone } from "@/types/gemstone";
import { COLLECTIONS, getParsedCollectionCards } from "@/lib/data/collections";
import { GemstoneCard } from "@/features/gemstones/components/GemstoneCard";
import { GemstoneCardSkeleton } from "@/features/gemstones/components/GemstoneCardSkeleton";
import { ConsultationModal } from "@/features/gemstones/components/ConsultationModal";
import { 
  CertificateShieldIcon, 
  SecurityLockIcon, 
  AwardIcon, 
  SparklesIcon, 
  ChevronRightIcon,
  LoupeIcon,
  ScaleIcon
} from "@/components/ui/LuxuryIcons";
import { useCMS } from "@/features/cms/useCMS";

export default function HomePage() {
  const [isConsultationOpen, setIsConsultationOpen] = useState(false);
  const [gemstonesList, setGemstonesList] = useState<Gemstone[]>([]);
  const [isLoadingGems, setIsLoadingGems] = useState<boolean>(true);

  useEffect(() => {
    let isMounted = true;
    fetch("/api/gemstones")
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (isMounted && Array.isArray(data)) {
          setGemstonesList(data);
        }
      })
      .catch((err) => {
        console.warn("Failed to fetch gemstones:", err);
      })
      .finally(() => {
        if (isMounted) {
          setIsLoadingGems(false);
        }
      });
    return () => {
      isMounted = false;
    };
  }, []);

  const featuredList = gemstonesList.filter((g) => g.featured);
  const featuredGemstones = (featuredList.length > 0 ? featuredList : gemstonesList).slice(0, 4);
  const { getBlock, isLoading } = useCMS();

  const heroImage = getBlock("homepage.hero_image", "/uploads/banners/hero-1789651834163-md9w3c.webp");
  const heroHeadline = getBlock(
    "homepage.hero_headline",
    "Discover Rare Natural Gemstones"
  );
  const heroSubheadline = getBlock(
    "homepage.hero_subheadline",
    "Natural unheated sapphires, rubies, emeralds, and fine gemstones. Certified for quality, color, and authenticity."
  );
  const heroCtaPrimaryText = getBlock(
    "homepage.hero_cta_primary_text",
    "Browse Gemstones"
  );
  const heroCtaPrimaryLink = getBlock(
    "homepage.hero_cta_primary_link",
    "/shop"
  );
  const heroCtaSecondaryText = getBlock(
    "homepage.hero_cta_secondary_text",
    "Our Collection"
  );
  const heroCtaSecondaryLink = getBlock(
    "homepage.hero_cta_secondary_link",
    "/shop"
  );

  // Section 1: Hero Metrics
  const metric1Val = getBlock("homepage.metric1_val", "100%");
  const metric1Lbl = getBlock("homepage.metric1_lbl", "Certified Natural");
  const metric2Val = getBlock("homepage.metric2_val", "GIA & GRS");
  const metric2Lbl = getBlock("homepage.metric2_lbl", "Independent Reports");
  const metric3Val = getBlock("homepage.metric3_val", "Armored");
  const metric3Lbl = getBlock("homepage.metric3_lbl", "Worldwide Courier");
  const metric4Val = getBlock("homepage.metric4_val", "30 Days");
  const metric4Lbl = getBlock("homepage.metric4_lbl", "Inspection Period");

  // Section 2: Trust & Assurance Strip
  const trust1Title = getBlock("homepage.trust1_title", "Independently Certified Labs");
  const trust1Desc = getBlock("homepage.trust1_desc", "GIA, Gübelin, SSEF & GRS lab reports you can verify online");
  const trust2Title = getBlock("homepage.trust2_title", "30-Day Money-Back Guarantee");
  const trust2Desc = getBlock("homepage.trust2_desc", "Not satisfied? Return within 30 days for a full refund — no questions asked");

  // Section 3: Collections
  const collectionsEyebrow = getBlock("homepage.collections_eyebrow", "Our Collections");
  const collectionsHeadline = getBlock("homepage.collections_headline", "Explore Our Gemstone Collections");
  const collectionsSubheadline = getBlock("homepage.collections_subheadline", "Browse collections of the world's finest natural gemstones — sourced directly from the mines and cut by expert craftsmen.");
  const rawCardsJson = getBlock("collections.cards_list", "");
  const homeCollectionCards = React.useMemo(() => {
    const cards = getParsedCollectionCards(rawCardsJson);
    return cards.filter((c) => c.showOnHome);
  }, [rawCardsJson]);

  // Section 4: Vault
  const vaultEyebrow = getBlock("homepage.vault_eyebrow", "New Arrivals");
  const vaultHeadline = getBlock("homepage.vault_headline", "Certified Natural Gemstones");
  const vaultSubheadline = getBlock("homepage.vault_subheadline", "One-of-a-kind natural gemstones, each with an official lab certificate from GIA, Gübelin, SSEF, or GRS.");
  const vaultCtaText = getBlock("homepage.vault_cta_text", "View All Gemstones");

  // Section 5: Loupe
  const loupeEyebrow = getBlock("homepage.loupe_eyebrow", "See Every Detail Online");
  const loupeHeadline = getBlock("homepage.loupe_headline", "Zoom In & Inspect Every Gemstone Up Close");
  const loupeSubheadline = getBlock("homepage.loupe_subheadline", "Can't visit in person? No problem. Our high-resolution image viewer lets you examine every detail of the gemstone — just like a professional gemologist would.");
  const loupeFeat1Title = getBlock("homepage.loupe_feat1_title", "10x Zoom Magnification");
  const loupeFeat1Desc = getBlock("homepage.loupe_feat1_desc", "See the natural details and clarity of each stone up close.");
  const loupeFeat2Title = getBlock("homepage.loupe_feat2_title", "Detailed Photo Gallery");
  const loupeFeat2Desc = getBlock("homepage.loupe_feat2_desc", "View the cut quality, light performance, and sparkle from every angle.");
  const loupeFeat3Title = getBlock("homepage.loupe_feat3_title", "Lab Certificate Included");
  const loupeFeat3Desc = getBlock("homepage.loupe_feat3_desc", "Every gemstone comes with its original lab report and certificate.");
  const loupeCtaText = getBlock("homepage.loupe_cta_text", "View a Gemstone Up Close →");
  const loupeCtaLink = getBlock("homepage.loupe_cta_link", "/shop");
  const loupeImage = getBlock("homepage.loupe_image", "/uploads/banners/hero-1789651886835-6o989i.webp");
  const loupeImageCaption = getBlock("homepage.loupe_image_caption", "ROYAL BLUE CEYLON SAPPHIRE • CLOSE-UP VIEW");

  // Section 7: Story
  const storyImage = getBlock("homepage.story_image", "/uploads/banners/hero-1789651917652-xw752j.webp");
  const storyImageBadge = getBlock("homepage.story_image_badge", "Ethically Sourced");
  const storyImageCaption = getBlock("homepage.story_image_caption", "From Sri Lankan mines to expertly cut gemstones.");
  const storyEyebrow = getBlock("homepage.story_eyebrow", "Our Story");
  const storyHeadline = getBlock("homepage.story_headline", "Crafted by Nature. Delivered with Trust.");
  const storyP1 = getBlock("homepage.story_p1", "At Faizan Gems, we believe the world's finest gemstones should stay 100% natural — no heating, no chemical treatment, no artificial enhancements.");
  const storyP2 = getBlock("homepage.story_p2", "We work directly with miners in Sri Lanka, Colombia, and Thailand. Every stone is bought from small-scale, eco-friendly mining operations — ensuring fair pay for workers and minimal impact on the environment.");
  const storyStat1Val = getBlock("homepage.story_stat1_val", "100%");
  const storyStat1Lbl = getBlock("homepage.story_stat1_lbl", "Natural & Untreated");
  const storyStat2Val = getBlock("homepage.story_stat2_val", "3");
  const storyStat2Lbl = getBlock("homepage.story_stat2_lbl", "Generations of Expert Cutters");
  const storyStat3Val = getBlock("homepage.story_stat3_val", "Direct");
  const storyStat3Lbl = getBlock("homepage.story_stat3_lbl", "Mine-to-You Direct");
  const storyCtaText = getBlock("homepage.story_cta_text", "Read Our Story →");
  const storyCtaLink = getBlock("homepage.story_cta_link", "/about");

  // Section 8: Consultation
  const consultationEyebrow = getBlock("homepage.consultation_eyebrow", "Need Help Choosing?");
  const consultationHeadline = getBlock("homepage.consultation_headline", "Looking for a Specific Gemstone?");
  const consultationDesc = getBlock("homepage.consultation_desc", "Our gemstone experts are happy to help — visit our Trincomalee showroom or book a free video call consultation.");
  const consultationBtnText = getBlock("homepage.consultation_button_text", "Book a Free Consultation");

  return (
    <div className="bg-[#FAF8F5]">
      {/* 1. CINEMATIC HERO SECTION */}
      <section className="relative min-h-[85vh] lg:min-h-[92vh] flex items-center justify-center overflow-hidden bg-[#0D0D11] text-white">
        {/* Background Image with Cinematic Overlay */}
        {heroImage && (
          <div className="absolute inset-0 z-0">
            <Image
              src={heroImage}
              alt={heroHeadline}
              fill
              priority
              sizes="100vw"
              unoptimized={heroImage.startsWith("/uploads")}
              className="object-cover object-center opacity-40 scale-105 transition-transform duration-10000 ease-out"
            />
            {/* Vignette & Gradients */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D11] via-[#0D0D11]/40 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#0D0D11]/80 via-transparent to-[#0D0D11]/80" />
          </div>
        )}

        {/* Hero Content */}
        <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-28 pb-16 sm:pt-36 sm:pb-24 lg:pt-40 lg:pb-28">

          <h1 className="font-serif text-3xl sm:text-5xl lg:text-7xl font-light tracking-wide text-white leading-[1.15] sm:leading-[1.1] max-w-4xl mx-auto">
            {heroHeadline}
          </h1>

          <p className="mt-4 sm:mt-6 text-sm sm:text-base lg:text-lg text-[#D3CBBF] font-sans font-light max-w-2xl mx-auto leading-relaxed">
            {heroSubheadline}
          </p>

          {/* CTAs */}
          <div className="mt-8 sm:mt-10 flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4">
            <Link
              href={heroCtaPrimaryLink}
              className="w-full sm:w-auto min-h-[48px] px-8 py-3.5 sm:py-4 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-xs font-sans uppercase tracking-luxury transition-all duration-300 shadow-xl shadow-[#C5A880]/10 font-medium active:scale-95 flex items-center justify-center text-center"
            >
              {heroCtaPrimaryText}
            </Link>
            <Link
              href={heroCtaSecondaryLink}
              className="w-full sm:w-auto min-h-[48px] px-8 py-3.5 sm:py-4 border border-[#E0CFA9]/40 hover:border-[#E0CFA9] text-[#E0CFA9] hover:bg-white/5 text-xs font-sans uppercase tracking-luxury transition-all duration-300 backdrop-blur-sm flex items-center justify-center text-center"
            >
              {heroCtaSecondaryText}
            </Link>
          </div>

          {/* Quick Metrics */}
          <div className="mt-12 sm:mt-16 pt-6 sm:pt-8 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6 max-w-3xl mx-auto text-left sm:text-center font-sans">
            <div>
              <span className="font-serif text-xl sm:text-2xl text-white block">{metric1Val}</span>
              <span className="text-[10px] sm:text-[11px] uppercase tracking-wider text-[#8C867D]">{metric1Lbl}</span>
            </div>
            <div>
              <span className="font-serif text-xl sm:text-2xl text-white block">{metric2Val}</span>
              <span className="text-[10px] sm:text-[11px] uppercase tracking-wider text-[#8C867D]">{metric2Lbl}</span>
            </div>
            <div>
              <span className="font-serif text-xl sm:text-2xl text-white block">{metric3Val}</span>
              <span className="text-[10px] sm:text-[11px] uppercase tracking-wider text-[#8C867D]">{metric3Lbl}</span>
            </div>
            <div>
              <span className="font-serif text-xl sm:text-2xl text-white block">{metric4Val}</span>
              <span className="text-[10px] sm:text-[11px] uppercase tracking-wider text-[#8C867D]">{metric4Lbl}</span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. THE 9 PRINCIPLES OF TRUST & ASSURANCE STRIP */}
      <section className="bg-white border-b border-[#E8E4DC] py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-center md:text-left divide-y md:divide-y-0 md:divide-x divide-[#F2EFE9]">
            <div className="flex items-center justify-center md:justify-start gap-4 p-2">
              <CertificateShieldIcon className="w-6 h-6 text-[#C5A880] flex-shrink-0" />
              <div>
                <span className="text-xs font-serif font-medium text-[#18181D] block">
                  {trust1Title}
                </span>
                <span className="text-[11px] text-[#8C867D] font-sans">
                  {trust1Desc}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-center md:justify-start gap-4 p-2 md:pl-8">
              <SecurityLockIcon className="w-6 h-6 text-[#C5A880] flex-shrink-0" />
              <div>
                <span className="text-xs font-serif font-medium text-[#18181D] block">
                  {trust2Title}
                </span>
                <span className="text-[11px] text-[#8C867D] font-sans">
                  {trust2Desc}
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. FEATURED EDITORIAL COLLECTIONS */}
      <section className="py-12 sm:py-20 lg:py-28 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-8 sm:mb-12 lg:mb-16">
          <span className="text-[11px] sm:text-xs font-sans tracking-wide-luxury uppercase text-[#9A7B4F] block mb-1.5 sm:mb-2">
            {collectionsEyebrow}
          </span>
          <h2 className="font-serif text-2xl sm:text-4xl lg:text-5xl text-[#18181D] font-normal leading-tight sm:leading-snug">
            {collectionsHeadline}
          </h2>
          <p className="mt-2 sm:mt-3 text-xs sm:text-sm text-[#6B655C] font-sans leading-relaxed max-w-xl mx-auto line-clamp-3 sm:line-clamp-none">
            {collectionsSubheadline}
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5 lg:gap-6">
          {isLoading ? (
            [...Array(4)].map((_, i) => (
              <div key={i} className="relative flex flex-col bg-[#16161D] border border-[#E8E4DC] rounded-sm overflow-hidden aspect-[4/5] sm:aspect-[3/4] w-full">
                <div className="absolute inset-0 bg-[#1A1A24] animate-shimmer-dark" />
                <div className="absolute bottom-3 sm:bottom-4 inset-x-3 sm:inset-x-4 space-y-2 z-10">
                  <div className="w-3/4 h-4 sm:h-5 bg-white/20 rounded-xs animate-pulse" />
                  <div className="w-16 h-2.5 bg-[#C5A880]/30 rounded-xs animate-pulse" />
                </div>
              </div>
            ))
          ) : (
            homeCollectionCards.map((card) => (
              <Link
                key={card.id}
                href={`/collections/${card.slug}`}
                className="group relative flex flex-col bg-[#16161D] border border-[#E8E4DC] hover:border-[#C5A880] rounded-sm overflow-hidden shadow-xs hover:shadow-lg transition-all duration-300 active:scale-[0.98]"
              >
                <div className="relative aspect-[4/5] sm:aspect-[3/4] w-full overflow-hidden bg-[#16161D]">
                  <Image
                    src={card.image}
                    alt={card.name}
                    fill
                    sizes="(max-width: 640px) 50vw, (max-width: 1024px) 50vw, 25vw"
                    unoptimized={card.image.startsWith("/uploads")}
                    className="object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                  />
                  {/* Luxury editorial vignette gradient */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/35 to-black/5 group-hover:from-black/95 transition-colors duration-300" />
                  
                  {/* Subtle top pill badge */}
                  <div className="absolute top-2 sm:top-3 left-2 sm:left-3 z-10 pointer-events-none">
                    <span className="inline-flex items-center px-1.5 sm:px-2 py-0.5 bg-black/60 backdrop-blur-xs border border-[#C5A880]/30 text-[#E0CFA9] text-[7.5px] sm:text-[9px] font-mono uppercase tracking-widest rounded-[2px]">
                      Vault
                    </span>
                  </div>

                  {/* Card bottom title and explore affordance */}
                  <div className="absolute bottom-2.5 sm:bottom-4 inset-x-2.5 sm:inset-x-4 text-center sm:text-left z-10">
                    <h3 className="font-serif text-sm sm:text-lg lg:text-xl font-normal text-white leading-tight mb-1 group-hover:text-[#E0CFA9] transition-colors line-clamp-2">
                      {card.name}
                    </h3>
                    <span className="inline-flex items-center gap-1 text-[9px] sm:text-xs text-[#C5A880] uppercase tracking-wider font-sans font-medium">
                      Explore <span className="transition-transform duration-300 group-hover:translate-x-1">&rarr;</span>
                    </span>
                  </div>
                </div>
              </Link>
            ))
          )}
        </div>

        {/* Explore All Collections Button */}
        <div className="mt-8 sm:mt-12 text-center">
          <Link
            href="/collections"
            className="inline-flex items-center gap-2 px-6 py-2.5 sm:px-8 sm:py-3.5 border border-[#18181D] hover:border-[#9A7B4F] hover:bg-[#18181D] hover:text-white text-[11px] sm:text-xs uppercase tracking-luxury font-sans font-medium text-[#18181D] transition-all duration-300 active:scale-95"
          >
            <span>View All Collections</span>
            <span>&rarr;</span>
          </Link>
        </div>
      </section>

      {/* 4. FEATURED GEMSTONES VAULT (Product Grid) */}
      <section className="py-12 sm:py-20 bg-white border-t border-b border-[#E8E4DC]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-6 sm:mb-10 gap-3 sm:gap-4">
            <div>
              <span className="text-[11px] sm:text-xs font-sans tracking-wide-luxury uppercase text-[#9A7B4F] block mb-1.5 sm:mb-2">
                {vaultEyebrow}
              </span>
              <h2 className="font-serif text-2xl sm:text-4xl text-[#18181D] leading-tight sm:leading-snug">
                {vaultHeadline}
              </h2>
              <p className="mt-1.5 sm:mt-2 text-xs sm:text-sm text-[#6B655C] font-sans max-w-xl leading-relaxed">
                {vaultSubheadline}
              </p>
            </div>

            <Link
              href="/shop"
              className="inline-flex items-center gap-1.5 text-[11px] sm:text-xs font-sans uppercase tracking-luxury text-[#18181D] hover:text-[#9A7B4F] transition-colors border-b border-[#18181D] hover:border-[#9A7B4F] pb-0.5 w-fit"
            >
              <span>{vaultCtaText} ({gemstonesList.length > 0 ? `${gemstonesList.length}` : "0"})</span>
              <ChevronRightIcon className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-[#C5A880]" />
            </Link>
          </div>

          {isLoadingGems ? (
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6 lg:gap-8">
              {[...Array(4)].map((_, idx) => (
                <GemstoneCardSkeleton key={idx} className={idx === 3 ? "lg:hidden" : ""} />
              ))}
            </div>
          ) : featuredGemstones.length === 0 ? (
            <div className="py-12 sm:py-14 text-center border border-[#E8E4DC] bg-[#FAF8F5] rounded-sm">
              <p className="font-serif text-base sm:text-lg text-[#18181D]">Coming Soon</p>
              <p className="mt-1 text-xs text-[#6B655C]">New certified gemstones are being added — check back soon!</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6 lg:gap-8">
              {featuredGemstones.map((gem, idx) => (
                <GemstoneCard
                  key={gem.id}
                  gemstone={gem}
                  priority={idx < 3}
                  className={idx === 3 ? "lg:hidden" : ""}
                />
              ))}
            </div>
          )}

          <div className="mt-8 sm:mt-14 text-center">
            <Link
              href="/shop"
              className="inline-block px-8 py-3.5 sm:px-10 sm:py-4 bg-[#18181D] hover:bg-[#2A2A32] text-white text-[11px] sm:text-xs uppercase tracking-luxury font-sans transition-all shadow-md active:scale-95"
            >
              {vaultCtaText} &rarr;
            </Link>
          </div>
        </div>
      </section>

      {/* 5. INTERACTIVE GEMMOLOGY INNOVATION HIGHLIGHT */}
      <section className="py-20 lg:py-28 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#121214] text-white border border-[#2A2A32] p-8 sm:p-12 lg:p-16 relative overflow-hidden shadow-2xl">
          {/* Subtle gold line pattern */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-xs font-sans tracking-wide-luxury uppercase text-[#C5A880] block mb-3">
                {loupeEyebrow}
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-light leading-tight text-white">
                {loupeHeadline}
              </h2>
              <p className="mt-4 text-xs sm:text-sm text-[#8C867D] font-sans leading-relaxed">
                {loupeSubheadline}
              </p>

              <div className="mt-8 space-y-4 font-sans text-xs">
                <div className="flex items-start gap-3.5">
                  <div className="w-8 h-8 rounded-full bg-white/5 border border-[#C5A880]/40 text-[#C5A880] flex items-center justify-center flex-shrink-0">
                    <LoupeIcon className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-white block font-medium">{loupeFeat1Title}</span>
                    <span className="text-[#8C867D] text-[11px]">{loupeFeat1Desc}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-8 h-8 rounded-full bg-white/5 border border-[#C5A880]/40 text-[#C5A880] flex items-center justify-center flex-shrink-0">
                    <SparklesIcon className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-white block font-medium">{loupeFeat2Title}</span>
                    <span className="text-[#8C867D] text-[11px]">{loupeFeat2Desc}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-8 h-8 rounded-full bg-white/5 border border-[#C5A880]/40 text-[#C5A880] flex items-center justify-center flex-shrink-0">
                    <CertificateShieldIcon className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-white block font-medium">{loupeFeat3Title}</span>
                    <span className="text-[#8C867D] text-[11px]">{loupeFeat3Desc}</span>
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <Link
                  href={loupeCtaLink}
                  className="inline-block px-6 py-3 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-xs uppercase tracking-wider font-sans font-medium transition-colors"
                >
                  {loupeCtaText}
                </Link>
              </div>
            </div>

            {/* Visual representation */}
            {loupeImage && (
              <div className="relative aspect-square w-full max-w-md mx-auto border border-[#C5A880]/30 overflow-hidden bg-black shadow-2xl">
                <Image
                  src={loupeImage}
                  alt={loupeHeadline}
                  fill
                  unoptimized={loupeImage.startsWith("/uploads")}
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />
                <div className="absolute bottom-6 inset-x-6 text-center">
                  <span className="inline-block px-3 py-1 bg-black/80 border border-[#C5A880] text-[#E0CFA9] text-[10px] font-mono tracking-widest uppercase">
                    {loupeImageCaption}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* 7. FAIZAN GEMS HERITAGE & ETHICAL SOURCING */}
      <section className="py-20 lg:py-28 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {storyImage && (
            <div className="relative aspect-[4/5] w-full max-w-md mx-auto lg:max-w-none bg-[#F7F5F1] border border-[#E8E4DC] overflow-hidden shadow-xl">
              <Image
                src={storyImage}
                alt={storyHeadline}
                fill
                unoptimized={storyImage.startsWith("/uploads")}
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              <div className="absolute bottom-6 inset-x-6 text-white text-xs font-sans">
                <span className="text-[#C5A880] uppercase tracking-wider text-[10px] block">{storyImageBadge}</span>
                <span>{storyImageCaption}</span>
              </div>
            </div>
          )}

          <div className="space-y-6">
            <span className="text-xs font-sans tracking-wide-luxury uppercase text-[#9A7B4F] block">
              {storyEyebrow}
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-[#18181D] leading-tight font-light">
              {storyHeadline}
            </h2>
            <p className="text-xs sm:text-sm text-[#554F47] font-sans leading-relaxed">
              {storyP1}
            </p>
            <p className="text-xs sm:text-sm text-[#554F47] font-sans leading-relaxed">
              {storyP2}
            </p>

            <div className="pt-4 flex flex-wrap gap-6 text-xs font-sans text-[#18181D]">
              <div>
                <span className="font-serif text-2xl text-[#9A7B4F] block">{storyStat1Val}</span>
                <span className="text-[11px] text-[#8C867D] uppercase">{storyStat1Lbl}</span>
              </div>
              <div>
                <span className="font-serif text-2xl text-[#9A7B4F] block">{storyStat2Val}</span>
                <span className="text-[11px] text-[#8C867D] uppercase">{storyStat2Lbl}</span>
              </div>
              <div>
                <span className="font-serif text-2xl text-[#9A7B4F] block">{storyStat3Val}</span>
                <span className="text-[11px] text-[#8C867D] uppercase">{storyStat3Lbl}</span>
              </div>
            </div>

            <div className="pt-4">
              <Link
                href={storyCtaLink}
                className="inline-block px-6 py-3 border border-[#18181D] hover:bg-[#18181D] hover:text-white text-xs uppercase tracking-luxury font-sans transition-colors"
              >
                {storyCtaText}
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 8. CONCIERGE & ADVISORY CONSULTATION CTA */}
      <section className="bg-[#18181D] text-white py-16 px-4 sm:px-6 lg:px-8 border-t border-[#2A2A32]">
        <div className="max-w-4xl mx-auto text-center space-y-4">
          <span className="text-xs font-sans tracking-wide-luxury uppercase text-[#C5A880] block">
            {consultationEyebrow}
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-light text-white">
            {consultationHeadline}
          </h2>
          <p className="text-xs sm:text-sm text-[#D3CBBF] font-sans max-w-xl mx-auto leading-relaxed">
            {consultationDesc}
          </p>
          <div className="pt-4">
            <button
              onClick={() => setIsConsultationOpen(true)}
              className="px-8 py-4 bg-[#C5A880] hover:bg-[#E0CFA9] text-[#0D0D11] text-xs uppercase tracking-luxury font-sans font-medium transition-colors shadow-lg active:scale-95 cursor-pointer"
            >
              {consultationBtnText}
            </button>
          </div>
        </div>
      </section>

      {/* Consultation Modal */}
      {isConsultationOpen && (
        <ConsultationModal onClose={() => setIsConsultationOpen(false)} />
      )}
    </div>
  );
}
