import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class VariationsService {
  constructor(private readonly prisma: PrismaService) {}

  async createVariation(data: {
    name: string;
    isActive?: boolean;
    businessId: string;
    branchIds?: string[];
    values: string[];
    createdById?: string;
  }) {
    // 0. Field validations
    const trimmedName = data.name?.trim();
    if (!trimmedName) {
      throw new BadRequestException('Variation name is required');
    }
    if (trimmedName.length < 2 || trimmedName.length > 100) {
      throw new BadRequestException('Variation name must be between 2 and 100 characters');
    }

    if (!data.businessId || !data.businessId.trim()) {
      throw new BadRequestException('Business ID is required');
    }

    if (!data.values || !Array.isArray(data.values) || data.values.length === 0) {
      throw new BadRequestException('At least one variation value must be provided');
    }

    const uniqueValues = Array.from(
      new Set(
        data.values
          .map((v) => (typeof v === 'string' ? v.trim() : ''))
          .filter((v) => v.length > 0),
      ),
    );

    if (uniqueValues.length === 0) {
      throw new BadRequestException('At least one valid variation value must be provided');
    }

    for (const val of uniqueValues) {
      if (val.length > 50) {
        throw new BadRequestException(`Variation value "${val}" exceeds the maximum length of 50 characters`);
      }
    }

    // 1. Check for duplicate name in the same business
    const existing = await this.prisma.variation.findFirst({
      where: {
        name: { equals: trimmedName, mode: 'insensitive' },
        businessId: data.businessId,
      },
    });

    if (existing) {
      throw new BadRequestException('A variation with this name already exists in this business');
    }

    // 2. Verify branches belong to the business
    if (data.branchIds && data.branchIds.length > 0) {
      const validBranches = await this.prisma.branch.findMany({
        where: {
          id: { in: data.branchIds },
          businessId: data.businessId,
        },
      });
      if (validBranches.length !== data.branchIds.length) {
        throw new BadRequestException('One or more selected branches are invalid');
      }
    }

    // 3. Create Variation, Values, and Branch connections in a transaction
    return this.prisma.$transaction(async (tx) => {
      const variation = await tx.variation.create({
        data: {
          name: trimmedName,
          ...(data.isActive !== undefined && { isActive: data.isActive }),
          businessId: data.businessId,
          createdById: data.createdById || null,
          branches: data.branchIds && data.branchIds.length > 0
            ? {
                create: data.branchIds.map((branchId) => ({
                  branchId,
                })),
              }
            : undefined,
          values: {
            create: uniqueValues.map((val) => ({
              value: val,
            })),
          },
        },
        include: {
          values: true,
          branches: {
            include: {
              branch: true,
            },
          },
        },
      });

      return variation;
    });
  }

  async getVariations(businessId: string, branchId?: string) {
    const whereClause: any = {
      businessId,
    };

    if (branchId) {
      whereClause.OR = [
        { branches: { none: {} } },
        { branches: { some: { branchId } } },
      ];
    }

    return this.prisma.variation.findMany({
      where: whereClause,
      include: {
        values: {
          orderBy: {
            createdAt: 'asc',
          },
        },
        branches: {
          include: {
            branch: {
              select: {
                id: true,
                name: true,
              },
            },
          },
        },
      },
      orderBy: {
        createdAt: 'asc',
      },
    });
  }

  async getVariationById(id: string, businessId: string) {
    const variation = await this.prisma.variation.findFirst({
      where: { id, businessId },
      include: {
        values: {
          orderBy: {
            createdAt: 'asc',
          },
        },
        branches: {
          include: {
            branch: true,
          },
        },
      },
    });

    if (!variation) {
      throw new BadRequestException('Variation not found');
    }

    return variation;
  }

  async updateVariation(
    id: string,
    businessId: string,
    data: {
      name?: string;
      isActive?: boolean;
      branchIds?: string[];
      values?: string[];
      updatedById?: string;
    },
  ) {
    const variation = await this.getVariationById(id, businessId);

    // 0. Field validations
    let trimmedName: string | undefined = undefined;
    if (data.name !== undefined) {
      trimmedName = data.name.trim();
      if (!trimmedName) {
        throw new BadRequestException('Variation name cannot be empty');
      }
      if (trimmedName.length < 2 || trimmedName.length > 100) {
        throw new BadRequestException('Variation name must be between 2 and 100 characters');
      }
    }

    let uniqueNewValues: string[] | undefined = undefined;
    if (data.values !== undefined) {
      if (!Array.isArray(data.values) || data.values.length === 0) {
        throw new BadRequestException('At least one variation value must be provided');
      }
      uniqueNewValues = Array.from(
        new Set(
          data.values
            .map((v) => (typeof v === 'string' ? v.trim() : ''))
            .filter((v) => v.length > 0),
        ),
      );
      if (uniqueNewValues.length === 0) {
        throw new BadRequestException('At least one valid variation value must be provided');
      }
      for (const val of uniqueNewValues) {
        if (val.length > 50) {
          throw new BadRequestException(`Variation value "${val}" exceeds the maximum length of 50 characters`);
        }
      }
    }

    // 1. Check for duplicate name if name is changing
    if (trimmedName && trimmedName.toLowerCase() !== variation.name.toLowerCase()) {
      const existing = await this.prisma.variation.findFirst({
        where: {
          id: { not: id },
          name: { equals: trimmedName, mode: 'insensitive' },
          businessId,
        },
      });
      if (existing) {
        throw new BadRequestException('A variation with this name already exists in this business');
      }
    }

    // 2. Verify branches belong to the business if branchIds are changing
    if (data.branchIds && data.branchIds.length > 0) {
      const validBranches = await this.prisma.branch.findMany({
        where: {
          id: { in: data.branchIds },
          businessId,
        },
      });
      if (validBranches.length !== data.branchIds.length) {
        throw new BadRequestException('One or more selected branches are invalid');
      }
    }

    return this.prisma.$transaction(async (tx) => {
      // 3. Update branches if branchIds are provided
      if (data.branchIds !== undefined) {
        await tx.variationBranch.deleteMany({
          where: { variationId: id },
        });

        if (data.branchIds.length > 0) {
          await tx.variationBranch.createMany({
            data: data.branchIds.map((branchId) => ({
              variationId: id,
              branchId,
            })),
          });
        }
      }

      // 4. Synchronize values if values are provided
      if (uniqueNewValues !== undefined) {
        const existingValues = variation.values.map((v) => v.value);

        // Values to delete: existing values that are NOT in uniqueNewValues
        const valuesToDelete = variation.values.filter((v) => !uniqueNewValues!.includes(v.value));
        if (valuesToDelete.length > 0) {
          // Check if any value to delete is actively linked to a product variant
          const inUseCount = await tx.variantValueMap.count({
            where: {
              valueId: { in: valuesToDelete.map((v) => v.id) },
            },
          });

          if (inUseCount > 0) {
            throw new BadRequestException(
              `Cannot remove variation value(s) because they are actively used in ${inUseCount} product variant(s). Please reassign or remove the product variants first.`,
            );
          }

          await tx.variationValue.deleteMany({
            where: {
              id: { in: valuesToDelete.map((v) => v.id) },
            },
          });
        }

        // Values to add: new values that are NOT in existingValues
        const valuesToAdd = uniqueNewValues.filter((val) => !existingValues.includes(val));
        if (valuesToAdd.length > 0) {
          await tx.variationValue.createMany({
            data: valuesToAdd.map((val) => ({
              variationId: id,
              value: val,
            })),
          });
        }
      }

      // 5. Update Variation basic fields
      const updateData: any = {};
      if (trimmedName !== undefined) updateData.name = trimmedName;
      if (data.isActive !== undefined) updateData.isActive = data.isActive;
      if (data.updatedById !== undefined) updateData.updatedById = data.updatedById;

      const updated = await tx.variation.update({
        where: { id },
        data: updateData,
        include: {
          values: {
            orderBy: {
              createdAt: 'asc',
            },
          },
          branches: {
            include: {
              branch: true,
            },
          },
        },
      });

      return updated;
    });
  }

  async deleteVariation(id: string, businessId: string) {
    await this.getVariationById(id, businessId);

    // Check if any variation value is actively used in product variants
    const inUseCount = await this.prisma.variantValueMap.count({
      where: {
        value: {
          variationId: id,
        },
      },
    });

    if (inUseCount > 0) {
      throw new BadRequestException(
        `Cannot delete variation because its values are actively used in ${inUseCount} product variant(s). Please reassign or remove the product variants first.`,
      );
    }

    await this.prisma.variation.delete({
      where: { id },
    });

    return { success: true };
  }
}
