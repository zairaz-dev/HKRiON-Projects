import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { customerService } from "@/services/customer-service";
import { branchService } from "@/services/branch-service";
import { customerGroupService } from "@/services/customer-group-service";
import { queryKeys } from "@/lib/query-keys";
import { CustomerItem } from "../types";

export function useCustomersQuery(businessId: string, branchId?: string) {
  return useQuery<CustomerItem[]>({
    queryKey: queryKeys.customers.list(businessId, branchId),
    queryFn: () => customerService.getCustomers(businessId, branchId),
    enabled: !!businessId,
  });
}

export function useCustomerByIdQuery(id: string, businessId: string) {
  return useQuery<CustomerItem>({
    queryKey: queryKeys.customers.detail(id, businessId),
    queryFn: () => customerService.getCustomerById(id, businessId),
    enabled: !!id && !!businessId,
  });
}

export function useBranchesQuery(businessId: string, userId?: string) {
  return useQuery({
    queryKey: queryKeys.branches.list(businessId, userId),
    queryFn: () => branchService.getBranches(businessId, userId),
    enabled: !!businessId,
  });
}

export function useCustomerGroupsQuery(businessId: string) {
  return useQuery({
    queryKey: queryKeys.customerGroups.list(businessId),
    queryFn: () => customerGroupService.getCustomerGroups(businessId),
    enabled: !!businessId,
  });
}

export function useCreateCustomerMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: Parameters<typeof customerService.createCustomer>[0]) =>
      customerService.createCustomer(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.customers.all });
    },
  });
}

export function useUpdateCustomerMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Parameters<typeof customerService.updateCustomer>[1] }) =>
      customerService.updateCustomer(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.customers.all });
    },
  });
}

export function useDeleteCustomerMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, businessId }: { id: string; businessId: string }) =>
      customerService.deleteCustomer(id, businessId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.customers.all });
    },
  });
}
