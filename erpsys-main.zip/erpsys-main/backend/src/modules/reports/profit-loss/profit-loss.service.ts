import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class ProfitLossService {
  constructor(private readonly prisma: PrismaService) {}

  async getProfitAndLoss(
    businessId: string,
    filters: {
      startDate?: Date;
      endDate?: Date;
      branchId?: string;
    },
  ) {
    const { startDate, endDate, branchId } = filters;

    const dateFilter: any = {};
    if (startDate || endDate) {
      dateFilter.createdAt = {};
      if (startDate) dateFilter.createdAt.gte = new Date(startDate);
      if (endDate) dateFilter.createdAt.lte = new Date(endDate);
    }

    const saleWhere: any = { businessId, status: 'FINAL', ...dateFilter };
    const returnWhere: any = { businessId, ...dateFilter };
    const expenseWhere: any = { businessId, ...dateFilter };

    if (branchId && branchId !== 'all') {
      saleWhere.branchId = branchId;
      returnWhere.branchId = branchId;
      expenseWhere.branchId = branchId;
    }

    // Aggregate Sales Revenue
    const salesAggregate = await this.prisma.sale.aggregate({
      where: saleWhere,
      _sum: {
        grandTotal: true,
      },
    });
    const totalSalesGross = salesAggregate._sum.grandTotal || 0;

    // Aggregate Sales Returns
    const returnsAggregate = await this.prisma.salesReturn.aggregate({
      where: returnWhere,
      _sum: {
        grandTotal: true,
      },
    });
    const totalSalesReturns = returnsAggregate._sum.grandTotal || 0;

    const netSalesRevenue = totalSalesGross - totalSalesReturns;

    // Calculate Cost of Goods Sold (COGS)
    const saleLines = await this.prisma.saleLine.findMany({
      where: {
        sale: saleWhere,
      },
      include: {
        variant: {
          select: { purchasePrice: true },
        },
      },
    });

    let cogs = 0;
    for (const line of saleLines) {
      const unitCost = line.variant?.purchasePrice || 0;
      cogs += line.quantity * unitCost;
    }

    const grossProfit = netSalesRevenue - cogs;

    // Aggregate Operating Expenses
    const expenseAggregate = await this.prisma.expense.aggregate({
      where: expenseWhere,
      _sum: {
        amount: true,
      },
    });
    const totalExpenses = expenseAggregate._sum.amount || 0;

    const netProfit = grossProfit - totalExpenses;

    return {
      totalSalesGross,
      totalSalesReturns,
      netSalesRevenue,
      cogs,
      grossProfit,
      totalExpenses,
      netProfit,
      marginPercentage: netSalesRevenue > 0 ? (netProfit / netSalesRevenue) * 100 : 0,
    };
  }
}
