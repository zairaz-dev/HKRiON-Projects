import { Module } from '@nestjs/common';
import { AiController } from './ai.controller';
import { AiService } from './ai.service';
import { AiToolsService } from './ai-tools.service';
import { SalesAiTool } from './tools/sales-ai.tool';
import { ProductsAiTool } from './tools/products-ai.tool';
import { CustomersAiTool } from './tools/customers-ai.tool';
import { SuppliersAiTool } from './tools/suppliers-ai.tool';
import { UsersAiTool } from './tools/users-ai.tool';
import { FinanceAiTool } from './tools/finance-ai.tool';
import { PrismaModule } from '../prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [AiController],
  providers: [
    AiService,
    AiToolsService,
    SalesAiTool,
    ProductsAiTool,
    CustomersAiTool,
    SuppliersAiTool,
    UsersAiTool,
    FinanceAiTool,
  ],
  exports: [
    AiService,
    AiToolsService,
    SalesAiTool,
    ProductsAiTool,
    CustomersAiTool,
    SuppliersAiTool,
    UsersAiTool,
    FinanceAiTool,
  ],
})
export class AiModule {}
