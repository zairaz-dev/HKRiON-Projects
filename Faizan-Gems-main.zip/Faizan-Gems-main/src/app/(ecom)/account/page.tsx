"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Gemstone } from "@/types/gemstone";
import { useWishlist } from "@/features/wishlist/context/WishlistContext";
import { useCurrency } from "@/features/currency/context/CurrencyContext";
import { useAuth } from "@/features/auth/context/AuthContext";
import { GemstoneCard } from "@/features/gemstones/components/GemstoneCard";
import {
  UserIcon,
  HeartIcon,
  BagIcon,
  CertificateShieldIcon,
  AwardIcon,
  CheckIcon,
  SecurityLockIcon,
  ArmoredTruckIcon,
  CloseIcon,
} from "@/components/ui/LuxuryIcons";
import { LuxuryPrice } from "@/components/ui/LuxuryPrice";
import { LuxurySelect } from "@/components/ui/LuxurySelect";
import { useToast } from "@/components/ui/LuxuryToast";
import { COUNTRY_OPTIONS, getCountryFlag, isSriLanka } from "@/lib/data/countries";
import { SRI_LANKA_DISTRICTS } from "@/lib/data/districts";
import {
  getAddressFormat,
  requiresPostalCode,
} from "@/lib/data/address-formats";

interface CustomerOrder {
  id: string;
  orderNumber: string;
  date: string;
  status: string;
  courier: string;
  trackingNumber: string | null;
  paymentMethod?: string;
  bankReference?: string | null;
  paymentSlipUrl?: string | null;
  total: number;
  currency: string;
  primaryItemName: string;
  primaryItemCarat: number;
  primaryItemImage: string;
  destination: string;
}

interface CustomerInquiry {
  id: string;
  date: string;
  preferredLocation?: string;
  preferredSalon?: string;
  status: string;
  message: string;
  gemstoneName?: string;
}

function parseInquiryMessage(rawMessage?: string | null): {
  tags: string[];
  cleanMessage: string;
} {
  if (!rawMessage) return { tags: [], cleanMessage: "" };

  const trimmed = rawMessage.trim();
  const match = trimmed.match(/^\[([\s\S]*?)\]\s*([\s\S]*)$/);

  if (!match) {
    return { tags: [], cleanMessage: trimmed };
  }

  const tagString = match[1];
  const cleanMessage = match[2].trim();

  const tags = tagString
    .split("|")
    .map((t) => t.trim())
    .filter(Boolean);

  return { tags, cleanMessage };
}

export default function AccountPage() {
  const router = useRouter();
  const { user, isAuthenticated, isLoading: authLoading, logout, updateProfile } = useAuth();
  const { wishlist } = useWishlist();
  const { formatPrice } = useCurrency();
  const { toast, confirm } = useToast();

  // Authenticated Portal Tabs
  const [activeTab, setActiveTab] = useState<"acquisitions" | "inquiries" | "vault" | "profile">("acquisitions");

  // Live Orders & Inquiries State from MySQL
  const [orders, setOrders] = useState<CustomerOrder[]>([]);
  const [inquiries, setInquiries] = useState<CustomerInquiry[]>([]);
  const [savedAddresses, setSavedAddresses] = useState<any[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(false);
  const [loadingInquiries, setLoadingInquiries] = useState(false);

  // Profile Edit State
  const [profileName, setProfileName] = useState("");
  const [profilePhone, setProfilePhone] = useState("");
  const [profileSaving, setProfileSaving] = useState(false);
  const [profileSuccess, setProfileSuccess] = useState(false);

  // Saved Address Editing State
  const [editingAddressId, setEditingAddressId] = useState<string | null>(null);
  const [addressForm, setAddressForm] = useState({
    fullName: "",
    phone: "",
    address: "",
    city: "",
    district: "Colombo",
    postalCode: "",
    country: "Sri Lanka",
  });
  const [addressFormErrors, setAddressFormErrors] = useState<Record<string, string>>({});
  const [addressSaving, setAddressSaving] = useState(false);

  const [allGems, setAllGems] = useState<Gemstone[]>([]);

  useEffect(() => {
    fetch("/api/gemstones")
      .then((res) => (res.ok ? res.json() : []))
      .then((data) => {
        if (Array.isArray(data)) setAllGems(data);
      })
      .catch(() => {});
  }, []);

  const wishlistGems = allGems.filter((g) => wishlist.includes(g.id));

  // Initialize Profile Form on user change
  useEffect(() => {
    if (user) {
      setProfileName(user.name || "");
      setProfilePhone(user.phone || "");
    }
  }, [user]);

  // Support #vault deep-link
  useEffect(() => {
    if (typeof window !== "undefined" && window.location.hash === "#vault") {
      setActiveTab("vault");
    }
  }, []);

  // Fetch orders and inquiries when authenticated
  useEffect(() => {
    if (!isAuthenticated) return;

    setLoadingOrders(true);
    fetch("/api/account/orders")
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data?.orders) setOrders(data.orders);
      })
      .catch(() => {})
      .finally(() => setLoadingOrders(false));

    setLoadingInquiries(true);
    fetch("/api/account/inquiries")
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data?.inquiries) setInquiries(data.inquiries);
      })
      .catch(() => {})
      .finally(() => setLoadingInquiries(false));

    fetch("/api/account/addresses")
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data?.addresses) setSavedAddresses(data.addresses);
      })
      .catch(() => {});
  }, [isAuthenticated]);

  // Admins can only go to the admin dashboard
  useEffect(() => {
    if (!authLoading && isAuthenticated && user?.role === "ADMIN") {
      router.replace("/admindashboard");
    }
  }, [authLoading, isAuthenticated, user, router]);

  // Client-side automatic redirect to unified login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      router.replace("/login?from=/account");
    }
  }, [authLoading, isAuthenticated, router]);



  const handleLogout = async () => {
    const confirmed = await confirm({
      title: "Log Out?",
      message: "Are you sure you wish to log out of your account?",
      confirmLabel: "Log Out",
      cancelLabel: "Stay Signed In",
      variant: "gold",
      badgeText: "Account Security",
    });

    if (confirmed) {
      await logout();
      toast.info("Session Concluded", "Your private client session is now locked.");
      router.push("/login");
    }
  };

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileSaving(true);
    setProfileSuccess(false);
    const res = await updateProfile({
      name: profileName,
      phone: profilePhone,
    });
    setProfileSaving(false);
    if (res.success) {
      setProfileSuccess(true);
      toast.success("Profile Updated", "Your private client details have been recorded.");
      setTimeout(() => setProfileSuccess(false), 4000);
    } else {
      toast.error("Update Notice", "Could not update client profile at this time.");
    }
  };

  const handleStartEditAddress = (addr: any) => {
    setEditingAddressId(addr.id);
    setAddressForm({
      fullName: addr.fullName || user?.name || "",
      phone: addr.phone || user?.phone || "",
      address: addr.address || "",
      city: addr.city || "",
      district: addr.district || "Colombo",
      postalCode: addr.postalCode || "",
      country: addr.country || "Sri Lanka",
    });
    setAddressFormErrors({});
  };

  const handleStartAddAddress = () => {
    setEditingAddressId("new");
    setAddressForm({
      fullName: user?.name || "",
      phone: user?.phone || "",
      address: "",
      city: "",
      district: "",
      postalCode: "",
      country: "United States",
    });
    setAddressFormErrors({});
  };

  const handleCancelAddressEdit = () => {
    setEditingAddressId(null);
    setAddressFormErrors({});
  };

  const handleSaveAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    const errors: Record<string, string> = {};
    const format = getAddressFormat(addressForm.country);

    if (!addressForm.country || !addressForm.country.trim()) {
      errors.country = "Please select your country.";
    }
    if (!addressForm.address.trim() || addressForm.address.trim().length < 3) {
      errors.address = `Please enter your ${format.fields.addressLine1.label.toLowerCase()} (minimum 3 characters).`;
    }
    if (!addressForm.city.trim() || addressForm.city.trim().length < 2) {
      errors.city = `Please enter your ${format.fields.city.label.toLowerCase()}.`;
    }
    if (format.fields.state.required && !addressForm.district.trim()) {
      errors.district = format.fields.state.type === "select"
        ? `Please select your ${format.fields.state.label.toLowerCase()}.`
        : `Please enter your ${format.fields.state.label.toLowerCase()}.`;
    }
    if (format.hasPostalCode && (!addressForm.postalCode.trim() || addressForm.postalCode.trim().length < 2)) {
      errors.postalCode = "Please enter a valid postal / ZIP code.";
    }

    if (Object.keys(errors).length > 0) {
      setAddressFormErrors(errors);
      return;
    }

    setAddressSaving(true);
    try {
      const sanitizedPostal = format.hasPostalCode ? addressForm.postalCode.trim() : "";
      if (editingAddressId === "new") {
        const res = await fetch("/api/account/addresses", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email: user?.email,
            ...addressForm,
            postalCode: sanitizedPostal,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Failed to save address");

        setSavedAddresses((prev) => [data.address, ...prev]);
        toast.success("Address Added", "Your delivery address has been saved.");
      } else {
        const res = await fetch("/api/account/addresses", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            id: editingAddressId,
            email: user?.email,
            ...addressForm,
            postalCode: sanitizedPostal,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Failed to update address");

        setSavedAddresses((prev) =>
          prev.map((a) => (a.id === editingAddressId ? data.address : a))
        );
        toast.success("Address Updated", "Your delivery address details have been updated.");
      }
      setEditingAddressId(null);
      setAddressFormErrors({});
    } catch (err: any) {
      toast.error("Address Error", err.message || "Failed to save address.");
    } finally {
      setAddressSaving(false);
    }
  };

  const handleDeleteAddress = async (id: string) => {
    const confirmed = await confirm({
      title: "Delete Delivery Address?",
      message: "Are you sure you want to remove this delivery address from your account?",
      confirmLabel: "Delete Address",
      cancelLabel: "Keep Address",
      variant: "danger",
      badgeText: "Address Management",
    });
    if (!confirmed) return;

    try {
      const res = await fetch(`/api/account/addresses?id=${encodeURIComponent(id)}&email=${encodeURIComponent(user?.email || "")}`, {
        method: "DELETE",
      });
      if (res.ok) {
        setSavedAddresses((prev) => prev.filter((a) => a.id !== id));
        toast.success("Address Removed", "Delivery address has been deleted.");
      } else {
        toast.error("Delete Notice", "Could not remove delivery address.");
      }
    } catch {
      toast.error("Delete Notice", "Could not remove delivery address.");
    }
  };

  // Get status badge configuration
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending_verification":
      case "pending_inspection":
        return {
          label: "Payment Under Review",
          classes: "bg-amber-50 text-amber-900 border-amber-300 font-medium",
        };
      case "accepted":
        return {
          label: "Order Confirmed",
          classes: "bg-emerald-50 text-emerald-900 border-emerald-400 font-semibold",
        };
      case "vault_packed":
        return {
          label: "Packed & Ready",
          classes: "bg-purple-50 text-purple-900 border-purple-300 font-medium",
        };
      case "in_transit":
        return {
          label: "In Transit",
          classes: "bg-blue-50 text-blue-900 border-blue-300 font-medium",
        };
      case "delivered":
        return {
          label: "Delivered",
          classes: "bg-emerald-50 text-emerald-900 border-emerald-300 font-medium",
        };
      case "rejected":
        return {
          label: "Payment Rejected",
          classes: "bg-red-50 text-red-900 border-red-300 font-medium",
        };
      default:
        return {
          label: status.replace("_", " "),
          classes: "bg-stone-50 text-stone-900 border-stone-300",
        };
    }
  };

  // -------------------------------------------------------------
  // 1. Loading State
  // -------------------------------------------------------------
  if (authLoading) {
    return (
      <div className="bg-[#FAF8F5] min-h-screen py-24 flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 border-2 border-[#C5A880] border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="font-serif text-lg text-[#18181D]">Synchronizing Private Vault Gateway...</p>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // 1.5. Admin User Guard - Redirect to Admin Dashboard
  // -------------------------------------------------------------
  if (isAuthenticated && user?.role === "ADMIN") {
    return (
      <div className="bg-[#FAF8F5] min-h-screen py-24 flex items-center justify-center selection:bg-[#C5A880] selection:text-[#0D0D11]">
        <div className="text-center space-y-4 max-w-sm px-4">
          <div className="w-10 h-10 border-2 border-[#C5A880] border-t-transparent rounded-full animate-spin mx-auto" />
          <h2 className="font-serif text-2xl text-[#18181D]">Admin Dashboard Access</h2>
          <p className="text-xs text-[#8C867D] font-sans leading-relaxed">
            Redirecting to your Admin Dashboard...
          </p>
          <Link
            href="/admindashboard"
            className="inline-block mt-3 text-xs uppercase tracking-widest text-[#9A7B4F] hover:text-[#7A5B2F] underline font-sans"
          >
            Click here if not redirected automatically
          </Link>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // 2. Unauthenticated State: Redirecting to Unified Gateway
  // -------------------------------------------------------------
  if (!isAuthenticated) {
    return (
      <div className="bg-[#FAF8F5] min-h-screen py-24 flex items-center justify-center selection:bg-[#C5A880] selection:text-[#0D0D11]">
        <div className="text-center space-y-4 max-w-sm px-4">
          <div className="w-10 h-10 border-2 border-[#C5A880] border-t-transparent rounded-full animate-spin mx-auto" />
          <h2 className="font-serif text-2xl text-[#18181D]">Redirecting to Private Client Login...</h2>
          <p className="text-xs text-[#8C867D] font-sans leading-relaxed">
            Please authenticate through the unified security portal to access your gemstone portfolio, active vault acquisitions, and concierge inquiries.
          </p>
          <Link
            href="/login?from=/account"
            className="inline-block mt-3 text-xs uppercase tracking-widest text-[#9A7B4F] hover:text-[#7A5B2F] underline font-sans"
          >
            Click here if not redirected automatically
          </Link>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // 3. Authenticated State: Private Client Portal
  // -------------------------------------------------------------
  const userInitials = (user?.name || "Client")
    .split(" ")
    .map((n) => n[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <div className="bg-[#FAF8F5] min-h-screen py-12 lg:py-16 selection:bg-[#C5A880] selection:text-[#0D0D11]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Client Profile Header Banner */}
        <div className="bg-white border border-[#E8E4DC] p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-[#18181D] text-[#C5A880] border-2 border-[#C5A880]/30 flex items-center justify-center font-serif text-2xl font-light">
              {userInitials}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-serif text-2xl text-[#18181D]">{user?.name}</h1>
                <span className="px-2.5 py-0.5 bg-[#FAF8F5] border border-[#C5A880] text-[#9A7B4F] text-[10px] font-sans uppercase tracking-widest font-medium">
                  {user?.tier || "Private Patron"}
                </span>
              </div>
              <p className="text-xs text-[#8C867D] font-sans mt-0.5">
                {user?.email}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleLogout}
              className="px-4 py-2 border border-[#E8E4DC] hover:border-[#18181D] hover:bg-[#FAF8F5] text-xs text-[#8C867D] hover:text-[#18181D] uppercase tracking-wider transition-colors"
            >
              Log Out
            </button>
          </div>
        </div>

        {/* Portal Navigation Tabs */}
        <div className="flex border-b border-[#E8E4DC] gap-6 sm:gap-8 text-xs font-sans overflow-x-auto pb-1">
          <button
            onClick={() => setActiveTab("acquisitions")}
            className={`pb-3 uppercase tracking-luxury transition-colors whitespace-nowrap relative ${
              activeTab === "acquisitions"
                ? "text-[#18181D] font-medium after:absolute after:bottom-[-1px] after:inset-x-0 after:h-[2px] after:bg-[#C5A880]"
                : "text-[#8C867D] hover:text-[#18181D]"
            }`}
          >
            My Orders ({orders.length})
          </button>
          <button
            onClick={() => setActiveTab("inquiries")}
            className={`pb-3 uppercase tracking-luxury transition-colors whitespace-nowrap relative ${
              activeTab === "inquiries"
                ? "text-[#18181D] font-medium after:absolute after:bottom-[-1px] after:inset-x-0 after:h-[2px] after:bg-[#C5A880]"
                : "text-[#8C867D] hover:text-[#18181D]"
            }`}
          >
            Appointments & Inquiries ({inquiries.length})
          </button>
          <button
            onClick={() => setActiveTab("vault")}
            className={`pb-3 uppercase tracking-luxury transition-colors whitespace-nowrap relative ${
              activeTab === "vault"
                ? "text-[#18181D] font-medium after:absolute after:bottom-[-1px] after:inset-x-0 after:h-[2px] after:bg-[#C5A880]"
                : "text-[#8C867D] hover:text-[#18181D]"
            }`}
          >
            Saved Gems ({wishlist.length})
          </button>
          <button
            onClick={() => setActiveTab("profile")}
            className={`pb-3 uppercase tracking-luxury transition-colors whitespace-nowrap relative ${
              activeTab === "profile"
                ? "text-[#18181D] font-medium after:absolute after:bottom-[-1px] after:inset-x-0 after:h-[2px] after:bg-[#C5A880]"
                : "text-[#8C867D] hover:text-[#18181D]"
            }`}
          >
            Profile & Delivery Address
          </button>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* Tab 1: Acquisitions Orders */}
        {/* ------------------------------------------------------------- */}
        {activeTab === "acquisitions" && (
          <div className="space-y-4">
            {loadingOrders ? (
              <div className="bg-white border border-[#E8E4DC] p-12 text-center text-xs font-sans text-[#8C867D]">
                <div className="w-8 h-8 border-2 border-[#C5A880] border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                Loading your orders...
              </div>
            ) : orders.length === 0 ? (
              <div className="bg-white border border-[#E8E4DC] p-12 text-center shadow-sm space-y-3">
                <CertificateShieldIcon className="w-10 h-10 text-[#C5A880] mx-auto" />
                <h3 className="font-serif text-xl text-[#18181D]">No Orders Yet</h3>
                <p className="text-xs text-[#8C867D] font-sans max-w-sm mx-auto">
                  Orders placed through our store will appear here with real-time status and delivery updates.
                </p>
                <Link
                  href="/shop"
                  className="inline-block mt-4 px-6 py-2.5 bg-[#18181D] text-white text-xs uppercase tracking-wider font-sans"
                >
                  Explore Natural Gemstones &rarr;
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                {orders.map((order) => {
                  const badge = getStatusBadge(order.status);
                  const progressStage =
                    order.status === "accepted" ? 2 :
                    order.status === "vault_packed" ? 3 :
                    order.status === "in_transit" ? 4 :
                    order.status === "delivered" ? 5 : 1;

                  return (
                    <div
                      key={order.id}
                      className="bg-white border border-[#E8E4DC] p-6 sm:p-7 shadow-sm space-y-4 text-xs font-sans hover:border-[#C5A880]/50 transition-colors"
                    >
                      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
                        <div className="space-y-1.5 flex-1">
                          {(() => {
                            const cleanPaymentMethod = !order.paymentMethod
                              ? null
                              : order.paymentMethod.toLowerCase().includes("wire") || order.paymentMethod.toLowerCase().includes("bank")
                              ? "Bank Transfer"
                              : order.paymentMethod.toLowerCase().includes("card")
                              ? "Card"
                              : order.paymentMethod.replace(/\s*\(Ref:[^)]+\)/i, "").trim();

                            return (
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="font-mono text-xs text-[#9A7B4F] font-semibold">
                                  {order.id}
                                </span>
                                <span className={`px-2.5 py-0.5 rounded text-[10px] border font-sans ${badge.classes}`}>
                                  {badge.label}
                                </span>
                                {cleanPaymentMethod && (
                                  <span className="text-[10px] text-[#8C867D] font-mono border border-[#E8E4DC] px-2 py-0.5 bg-[#FAF8F5]">
                                    {cleanPaymentMethod}
                                  </span>
                                )}
                              </div>
                            );
                          })()}

                          <h4 className="font-serif text-xl text-[#18181D] font-medium">
                            {order.primaryItemName}
                          </h4>

                          <div className="text-[11px] text-[#8C867D] flex flex-wrap items-center gap-x-4 gap-y-1">
                            <span>Order Date: <strong>{order.date}</strong></span>
                            <span>Weight: <strong>{order.primaryItemCarat.toFixed(2)} ct</strong></span>
                            <span>Destination: <strong>{order.destination}</strong></span>
                          </div>
                        </div>

                        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 lg:gap-6 border-t lg:border-t-0 border-[#F2EFE9] pt-3 lg:pt-0 w-full lg:w-auto justify-between shrink-0">
                          <div className="text-left lg:text-right">
                            <span className="text-[10px] uppercase text-[#8C867D] block">
                              {order.status === "rejected" ? "Total Amount" : "Order Total"}
                            </span>
                            <LuxuryPrice amount={order.total} size="lg" />
                          </div>

                          <div className="flex items-center gap-2">
                            <Link
                              href={`/orders/${order.id}`}
                              className="px-5 py-2.5 bg-[#18181D] hover:bg-[#2A2A32] text-white uppercase tracking-wider text-[11px] font-sans font-medium transition-colors"
                            >
                              View Order &rarr;
                            </Link>
                          </div>
                        </div>
                      </div>

                      {/* Order Progress / Status Section */}
                      {order.status === "rejected" ? (
                        <div className="pt-3 border-t border-[#F2EFE9]">
                          <div className="bg-red-50 border border-red-200 p-3.5 rounded-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                            <div className="flex items-center gap-2 text-red-800">
                              <span className="w-4 h-4 rounded-full bg-red-600 text-white text-[10px] flex items-center justify-center font-bold">✕</span>
                              <span><strong>Payment Declined:</strong> Payment verification was declined. This order will not be fulfilled.</span>
                            </div>
                            <Link
                              href="/contact"
                              className="text-red-800 hover:text-red-950 font-medium underline shrink-0 text-[11px]"
                            >
                              Contact Support &rarr;
                            </Link>
                          </div>
                        </div>
                      ) : (
                        /* 4-Step Interactive Order Progress Bar */
                        <div className="pt-3 border-t border-[#F2EFE9] space-y-2.5">
                          <div className="flex items-center justify-between text-[11px] font-sans">
                            {/* Step 1: Placed */}
                            <div className="flex items-center gap-1.5 text-emerald-800 font-medium">
                              <span className="w-4 h-4 rounded-full bg-emerald-700 text-white text-[9px] flex items-center justify-center font-mono">✓</span>
                              <span>Order Placed</span>
                            </div>
                            <span className={`h-[1.5px] flex-1 mx-2 sm:mx-3 ${progressStage >= 2 ? "bg-emerald-600" : "bg-[#E8E4DC]"}`} />

                            {/* Step 2: Payment & Accepted */}
                            <div className={`flex items-center gap-1.5 ${progressStage >= 2 ? "text-emerald-800 font-medium" : "text-[#8C867D]"}`}>
                              <span className={`w-4 h-4 rounded-full text-[9px] flex items-center justify-center font-mono ${
                                progressStage >= 2 ? "bg-emerald-700 text-white" : "bg-[#E8E4DC] text-[#8C867D]"
                              }`}>
                                {progressStage >= 2 ? "✓" : "2"}
                              </span>
                              <span>{progressStage >= 2 ? "Order Confirmed" : "Payment Under Review"}</span>
                            </div>
                            <span className={`h-[1.5px] flex-1 mx-2 sm:mx-3 ${progressStage >= 3 ? "bg-emerald-600" : "bg-[#E8E4DC]"}`} />

                            {/* Step 3: Packed & Ready */}
                            <div className={`flex items-center gap-1.5 ${progressStage >= 3 ? "text-emerald-800 font-medium" : "text-[#8C867D]"}`}>
                              <span className={`w-4 h-4 rounded-full text-[9px] flex items-center justify-center font-mono ${
                                progressStage >= 3 ? "bg-emerald-700 text-white" : "bg-[#E8E4DC] text-[#8C867D]"
                              }`}>
                                {progressStage >= 3 ? "✓" : "3"}
                              </span>
                              <span>Packed & Ready</span>
                            </div>
                            <span className={`h-[1.5px] flex-1 mx-2 sm:mx-3 ${progressStage >= 5 ? "bg-emerald-600" : "bg-[#E8E4DC]"}`} />

                            {/* Step 4: Delivered */}
                            <div className={`flex items-center gap-1.5 ${progressStage >= 5 ? "text-emerald-800 font-medium" : "text-[#8C867D]"}`}>
                              <span className={`w-4 h-4 rounded-full text-[9px] flex items-center justify-center font-mono ${
                                progressStage >= 5 ? "bg-emerald-700 text-white" : "bg-[#E8E4DC] text-[#8C867D]"
                              }`}>
                                {progressStage >= 5 ? "✓" : "4"}
                              </span>
                              <span>Delivered</span>
                            </div>
                          </div>

                          {/* Status Message */}
                          <div className="bg-[#FAF8F5] px-3.5 py-2 border border-[#E8E4DC] text-[11px] text-[#554F47] flex flex-wrap items-center justify-between gap-2">
                            <span className="flex items-center gap-1.5">
                              {progressStage >= 2 && <CheckIcon className="w-3.5 h-3.5 text-emerald-600 shrink-0" />}
                              {progressStage === 1 && "Payment Under Review: We are verifying your bank transfer and payment slip."}
                              {progressStage === 2 && "✓ Payment Confirmed: Your order has been approved and is being prepared."}
                              {progressStage === 3 && "Packed & Ready: Your gemstone has been inspected and packaged."}
                              {progressStage === 4 && "In Transit: Your order is on the way."}
                              {progressStage === 5 && "✓ Delivered: Order successfully delivered."}
                            </span>
                            {(() => {
                              const ref =
                                order.bankReference ||
                                order.paymentMethod?.match(/\(Ref:\s*([^)]+)\)/i)?.[1]?.trim() ||
                                null;

                              return ref ? (
                                <span className="font-mono text-[10px] text-[#8C867D] shrink-0">
                                  Reference: <strong className="text-[#18181D]">{ref}</strong>
                                </span>
                              ) : null;
                            })()}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* Tab 2: Private Appointments */}
        {/* ------------------------------------------------------------- */}
        {activeTab === "inquiries" && (
          <div className="space-y-4">
            {loadingInquiries ? (
              <div className="bg-white border border-[#E8E4DC] p-12 text-center text-xs font-sans text-[#8C867D]">
                <div className="w-8 h-8 border-2 border-[#C5A880] border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                Loading Appointments & Inquiries...
              </div>
            ) : inquiries.length === 0 ? (
              <div className="bg-white border border-[#E8E4DC] p-12 text-center shadow-sm space-y-3">
                <h3 className="font-serif text-xl text-[#18181D]">No Consultations Scheduled</h3>
                <p className="text-xs text-[#8C867D] font-sans max-w-sm mx-auto">
                  Book a consultation with our gemologists in Colombo or arrange a live video consultation.
                </p>
                <Link
                  href="/contact"
                  className="inline-block mt-4 px-6 py-2.5 bg-[#18181D] text-white text-xs uppercase tracking-wider font-sans"
                >
                  Schedule Appointment &rarr;
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                {inquiries.map((inq) => (
                  <div
                    key={inq.id}
                    className="bg-white border border-[#E8E4DC] p-6 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs font-sans"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-serif text-base text-[#18181D] font-medium">
                          {inq.preferredLocation || inq.preferredSalon || "Private"} Consultation
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-mono uppercase ${
                            inq.status === "scheduled"
                              ? "bg-purple-50 text-purple-900 border border-purple-300"
                              : inq.status === "resolved"
                              ? "bg-emerald-50 text-emerald-900 border border-emerald-300"
                              : "bg-amber-50 text-amber-900 border border-amber-300"
                          }`}
                        >
                          {inq.status.replace("_", " ")}
                        </span>
                      </div>
                      <p className="text-[#8C867D] text-[11px]">Requested Date: {inq.date}</p>
                      {inq.message && (() => {
                        const { tags, cleanMessage } = parseInquiryMessage(inq.message);
                        return (
                          <div className="mt-2 space-y-1.5">
                            {tags.length > 0 && (
                              <div className="flex flex-wrap gap-1.5">
                                {tags.map((tag, idx) => (
                                  <span
                                    key={idx}
                                    className="px-2 py-0.5 bg-[#F2EEE9] border border-[#E0D9CE] text-[#8A6D3B] text-[10px] font-mono rounded"
                                  >
                                    {tag}
                                  </span>
                                ))}
                              </div>
                            )}
                            {cleanMessage && (
                              <p className="text-[#3A3833] text-xs leading-relaxed mt-1">
                                {cleanMessage}
                              </p>
                            )}
                          </div>
                        );
                      })()}
                    </div>

                    <Link
                      href="/contact"
                      className="px-4 py-2 border border-[#E8E4DC] hover:border-[#18181D] text-xs uppercase tracking-wider text-[#18181D] transition-colors"
                    >
                      Contact Concierge
                    </Link>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* Tab 3: Saved Vault (Wishlist) */}
        {/* ------------------------------------------------------------- */}
        {activeTab === "vault" && (
          <div>
            {wishlistGems.length === 0 ? (
              <div className="bg-white border border-[#E8E4DC] p-12 text-center shadow-sm">
                <HeartIcon className="w-10 h-10 text-[#8C867D] mx-auto mb-3" />
                <h3 className="font-serif text-xl text-[#18181D]">Your Saved Vault is Empty</h3>
                <p className="text-xs text-[#8C867D] font-sans mt-2 max-w-sm mx-auto">
                  Click the heart icon on any rare unheated specimen in our catalog to save it to your private portfolio.
                </p>
                <Link
                  href="/shop"
                  className="inline-block mt-6 px-6 py-2.5 bg-[#18181D] text-white text-xs uppercase font-sans tracking-wider"
                >
                  Explore Gemstones &rarr;
                </Link>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {wishlistGems.map((gem) => (
                  <GemstoneCard key={gem.id} gemstone={gem} />
                ))}
              </div>
            )}
          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* Tab 4: Profile & Delivery Address */}
        {/* ------------------------------------------------------------- */}
        {activeTab === "profile" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Profile Information Form */}
            <div className="bg-white border border-[#E8E4DC] p-6 sm:p-8 shadow-sm space-y-6">
              <h3 className="font-serif text-lg text-[#18181D] border-b border-[#F2EFE9] pb-3 font-medium">
                Profile Information
              </h3>

              {profileSuccess && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-sans rounded-sm">
                  ✓ Profile successfully updated.
                </div>
              )}

              <form onSubmit={handleProfileSubmit} className="space-y-4 text-xs font-sans">
                <div>
                  <label className="block text-[#18181D] uppercase text-[10px] tracking-wider mb-1">
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={profileName}
                    onChange={(e) => setProfileName(e.target.value)}
                    className="w-full p-2.5 bg-[#FAF8F5] border border-[#E8E4DC] text-[#18181D] focus:outline-none focus:border-[#C5A880]"
                  />
                </div>

                <div>
                  <label className="block text-[#18181D] uppercase text-[10px] tracking-wider mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    disabled
                    value={user?.email || ""}
                    className="w-full p-2.5 bg-[#F2EFE9] border border-[#E8E4DC] text-[#8C867D] cursor-not-allowed"
                  />
                </div>

                <div>
                  <label className="block text-[#18181D] uppercase text-[10px] tracking-wider mb-1">
                    Phone / WhatsApp Number
                  </label>
                  <input
                    type="tel"
                    value={profilePhone}
                    onChange={(e) => setProfilePhone(e.target.value)}
                    placeholder="+94 (75) 000 0000"
                    className="w-full p-2.5 bg-[#FAF8F5] border border-[#E8E4DC] text-[#18181D] focus:outline-none focus:border-[#C5A880]"
                  />
                </div>

                <button
                  type="submit"
                  disabled={profileSaving}
                  className="w-full py-2.5 bg-[#18181D] hover:bg-[#2A2A32] text-white text-xs uppercase tracking-wider font-sans font-medium transition-colors disabled:opacity-50"
                >
                  {profileSaving ? "Saving..." : "Save Profile Changes"}
                </button>
              </form>
            </div>

            {/* Saved Delivery Addresses */}
            <div className="bg-white border border-[#E8E4DC] p-6 sm:p-8 shadow-sm space-y-6 text-xs font-sans">
              <div className="border-b border-[#F2EFE9] pb-3">
                <h3 className="font-serif text-lg text-[#18181D] font-medium">
                  Saved Delivery Address
                </h3>
                <p className="text-[11px] text-[#8C867D] font-sans mt-0.5">
                  Your destination for order delivery across Sri Lanka and worldwide.
                </p>
              </div>

              {editingAddressId ? (
                /* Address Edit Form */
                <form onSubmit={handleSaveAddress} className="space-y-4 p-5 bg-[#FAF8F5] border border-[#C5A880]/60 rounded-sm animate-in fade-in duration-200">
                  <div className="flex items-center justify-between pb-2 border-b border-[#E8E4DC]">
                    <span className="font-serif text-sm font-medium text-[#18181D]">
                      {editingAddressId === "new" ? "Add Delivery Address" : "Edit Delivery Address"}
                    </span>
                    <button
                      type="button"
                      onClick={handleCancelAddressEdit}
                      className="text-[11px] text-[#8C867D] hover:text-[#18181D] uppercase tracking-wider cursor-pointer"
                    >
                      &times; Cancel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[#554F47] uppercase text-[10px] tracking-wider mb-1">
                        Recipient Full Name
                      </label>
                      <input
                        type="text"
                        value={addressForm.fullName}
                        onChange={(e) => setAddressForm({ ...addressForm, fullName: e.target.value })}
                        placeholder="Full name"
                        className="w-full p-2.5 bg-white border border-[#E8E4DC] focus:border-[#C5A880] text-[#18181D] focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-[#554F47] uppercase text-[10px] tracking-wider mb-1">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        value={addressForm.phone}
                        onChange={(e) => setAddressForm({ ...addressForm, phone: e.target.value })}
                        placeholder="+94 (77) 000 0000"
                        className="w-full p-2.5 bg-white border border-[#E8E4DC] focus:border-[#C5A880] text-[#18181D] focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-[#554F47] uppercase text-[10px] tracking-wider">Country *</label>
                      {addressFormErrors.country && (
                        <span className="text-[10px] text-red-600 font-sans">{addressFormErrors.country}</span>
                      )}
                    </div>
                    <LuxurySelect
                      variant="light"
                      value={addressForm.country}
                      onChange={(val) => {
                        const newFmt = getAddressFormat(val);
                        setAddressForm({
                          ...addressForm,
                          country: val,
                          district: newFmt.fields.state.options ? "" : addressForm.district,
                          postalCode: newFmt.hasPostalCode ? addressForm.postalCode : "",
                        });
                        if (addressFormErrors.country)
                          setAddressFormErrors((prev) => ({ ...prev, country: "" }));
                        if (addressFormErrors.district)
                          setAddressFormErrors((prev) => ({ ...prev, district: "" }));
                        if (addressFormErrors.postalCode)
                          setAddressFormErrors((prev) => ({ ...prev, postalCode: "" }));
                      }}
                      options={COUNTRY_OPTIONS}
                      placeholder="Select Country"
                      searchable={true}
                      searchPlaceholder="Search country or code..."
                      triggerClassName={`!p-2.5 text-xs ${addressFormErrors.country ? "!border-red-500" : ""}`}
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-[#554F47] uppercase text-[10px] tracking-wider">
                        {getAddressFormat(addressForm.country).fields.addressLine1.label} *
                      </label>
                      {addressFormErrors.address && (
                        <span className="text-[10px] text-red-600 font-sans">{addressFormErrors.address}</span>
                      )}
                    </div>
                    <input
                      type="text"
                      value={addressForm.address}
                      onChange={(e) => {
                        setAddressForm({ ...addressForm, address: e.target.value });
                        if (addressFormErrors.address) setAddressFormErrors((prev) => ({ ...prev, address: "" }));
                      }}
                      placeholder={getAddressFormat(addressForm.country).fields.addressLine1.placeholder}
                      className={`w-full p-2.5 bg-white border text-[#18181D] focus:outline-none ${
                        addressFormErrors.address ? "border-red-500" : "border-[#E8E4DC] focus:border-[#C5A880]"
                      }`}
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-[#554F47] uppercase text-[10px] tracking-wider">
                          {getAddressFormat(addressForm.country).fields.city.label} *
                        </label>
                        {addressFormErrors.city && (
                          <span className="text-[10px] text-red-600 font-sans">{addressFormErrors.city}</span>
                        )}
                      </div>
                      <input
                        type="text"
                        value={addressForm.city}
                        onChange={(e) => {
                          setAddressForm({ ...addressForm, city: e.target.value });
                          if (addressFormErrors.city) setAddressFormErrors((prev) => ({ ...prev, city: "" }));
                        }}
                        placeholder={getAddressFormat(addressForm.country).fields.city.placeholder}
                        className={`w-full p-2.5 bg-white border text-[#18181D] focus:outline-none ${
                          addressFormErrors.city ? "border-red-500" : "border-[#E8E4DC] focus:border-[#C5A880]"
                        }`}
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-[#554F47] uppercase text-[10px] tracking-wider">
                          {getAddressFormat(addressForm.country).fields.state.label} {getAddressFormat(addressForm.country).fields.state.required ? "*" : ""}
                        </label>
                        {addressFormErrors.district && (
                          <span className="text-[10px] text-red-600 font-sans">{addressFormErrors.district}</span>
                        )}
                      </div>
                      {getAddressFormat(addressForm.country).fields.state.options ? (
                        <LuxurySelect
                          variant="light"
                          value={addressForm.district}
                          onChange={(val) => {
                            setAddressForm({ ...addressForm, district: val });
                            if (addressFormErrors.district)
                              setAddressFormErrors((prev) => ({ ...prev, district: "" }));
                          }}
                          options={getAddressFormat(addressForm.country).fields.state.options || []}
                          placeholder={getAddressFormat(addressForm.country).fields.state.placeholder}
                          searchable={true}
                          searchPlaceholder="Search state / region..."
                          triggerClassName={`!p-2.5 text-xs ${addressFormErrors.district ? "!border-red-500" : ""}`}
                        />
                      ) : (
                        <input
                          type="text"
                          value={addressForm.district}
                          onChange={(e) => {
                            setAddressForm({ ...addressForm, district: e.target.value });
                            if (addressFormErrors.district)
                              setAddressFormErrors((prev) => ({ ...prev, district: "" }));
                          }}
                          placeholder={getAddressFormat(addressForm.country).fields.state.placeholder}
                          className={`w-full p-2.5 bg-white border text-[#18181D] focus:outline-none ${
                            addressFormErrors.district ? "border-red-500" : "border-[#E8E4DC] focus:border-[#C5A880]"
                          }`}
                        />
                      )}
                    </div>
                  </div>

                  {getAddressFormat(addressForm.country).hasPostalCode && (
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-[#554F47] uppercase text-[10px] tracking-wider">
                          {getAddressFormat(addressForm.country).fields.postalCode?.label || "Postal Code"} *
                        </label>
                        {addressFormErrors.postalCode && (
                          <span className="text-[10px] text-red-600 font-sans">{addressFormErrors.postalCode}</span>
                        )}
                      </div>
                      <input
                        type="text"
                        value={addressForm.postalCode}
                        onChange={(e) => {
                          setAddressForm({ ...addressForm, postalCode: e.target.value });
                          if (addressFormErrors.postalCode) setAddressFormErrors((prev) => ({ ...prev, postalCode: "" }));
                        }}
                        placeholder={getAddressFormat(addressForm.country).fields.postalCode?.placeholder || "e.g. 10001"}
                        className={`w-full p-2.5 bg-white border font-mono text-xs text-[#18181D] focus:outline-none ${
                          addressFormErrors.postalCode ? "border-red-500" : "border-[#E8E4DC] focus:border-[#C5A880]"
                        }`}
                      />
                    </div>
                  )}

                  <div className="flex gap-2 pt-2">
                    <button
                      type="button"
                      onClick={handleCancelAddressEdit}
                      className="px-5 py-2.5 border border-[#E8E4DC] hover:bg-white text-xs uppercase tracking-wider font-medium text-[#554F47] transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={addressSaving}
                      className="flex-1 py-2.5 bg-[#18181D] hover:bg-[#2A2A32] text-white text-xs uppercase tracking-wider font-medium transition-colors disabled:opacity-50 cursor-pointer"
                    >
                      {addressSaving ? "Saving Address..." : "Save Delivery Address"}
                    </button>
                  </div>
                </form>
              ) : (
                /* Address Display View */
                <div className="space-y-4 text-[#554F47]">
                  {savedAddresses.length > 0 ? (
                    <div className="space-y-3">
                      {savedAddresses.map((addr, idx) => (
                        <div
                          key={addr.id || idx}
                          className="p-4 bg-[#FAF8F5] border border-[#E8E4DC] hover:border-[#C5A880]/60 transition-colors space-y-2 text-xs relative group"
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-[#18181D]">{addr.fullName || user?.name}</span>
                              {addr.isDefault && (
                                <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 bg-[#18181D] text-white">
                                  Default
                                </span>
                              )}
                            </div>

                            <div className="flex items-center gap-3">
                              <button
                                type="button"
                                onClick={() => handleStartEditAddress(addr)}
                                className="text-[11px] text-[#9A7B4F] hover:text-[#18181D] font-medium uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-colors"
                              >
                                <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round">
                                  <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                                  <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                                </svg>
                                <span>Edit Address</span>
                              </button>
                              {savedAddresses.length > 1 && (
                                <button
                                  type="button"
                                  onClick={() => handleDeleteAddress(addr.id)}
                                  className="text-[11px] text-[#8C867D] hover:text-red-600 uppercase tracking-wider cursor-pointer transition-colors"
                                  title="Delete address"
                                >
                                  Delete
                                </button>
                              )}
                            </div>
                          </div>

                          <p className="text-[#3A3732] font-medium">{addr.address}</p>
                          <p className="text-[#7D776E]">
                            {addr.city}, {addr.district} {addr.postalCode && `• ${addr.postalCode}`}
                          </p>
                          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[#8C867D] text-[11px]">
                            <span>{getCountryFlag(addr.country)} {addr.country || "Sri Lanka"}</span>
                            {addr.phone && <span>• Phone: {addr.phone}</span>}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6 px-4 bg-[#FAF8F5] border border-dashed border-[#E8E4DC] rounded-sm space-y-3">
                      <div className="w-10 h-10 rounded-full bg-white border border-[#E8E4DC] flex items-center justify-center mx-auto text-[#9A7B4F]">
                        <ArmoredTruckIcon className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="font-serif text-sm text-[#18181D]">No Saved Delivery Address</p>
                        <p className="text-[11px] text-[#8C867D] mt-0.5">
                          Add your delivery address for insured delivery worldwide.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={handleStartAddAddress}
                        className="px-4 py-2 bg-[#18181D] hover:bg-[#2A2A32] text-white text-xs uppercase tracking-wider font-medium transition-colors cursor-pointer"
                      >
                        + Add Delivery Address
                      </button>
                    </div>
                  )}

                  <div className="p-4 bg-[#FAF8F5] border border-[#E8E4DC] space-y-2 mt-4">
                    <div className="flex items-center gap-2 text-[#9A7B4F] font-semibold text-xs">
                      <SecurityLockIcon className="w-4 h-4" />
                      <span>100% Insured Delivery Worldwide</span>
                    </div>
                    <p className="text-[11px] text-[#6E6B65] leading-relaxed">
                      All orders are fully insured and securely transported via specialized armored air courier directly to your door.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
