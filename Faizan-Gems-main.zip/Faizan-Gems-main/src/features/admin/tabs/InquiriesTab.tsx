import React, { useState, useEffect } from "react";
import { SalonInquiry } from "../types";
import { LuxurySelect } from "@/components/ui/LuxurySelect";

interface InquiriesTabProps {
  inquiriesList: SalonInquiry[];
  newInquiriesCount: number;
  onUpdateInquiryStatus: (inquiryId: string, newStatus: "new" | "scheduled" | "resolved") => void;
  onRefresh?: () => void;
  isLoading?: boolean;
}

function parseInquiryMessage(rawMessage?: string | null): {
  tags: string[];
  cleanMessage: string;
} {
  if (!rawMessage) return { tags: [], cleanMessage: "" };

  const trimmed = rawMessage.trim();
  const match = trimmed.match(/^\[([\s\S]*?)\]\s*([\s\S]*)$/);

  if (!match) {
    return { tags: [], cleanMessage: trimmed };
  }

  const tagString = match[1];
  const cleanMessage = match[2].trim();

  const tags = tagString
    .split("|")
    .map((t) => t.trim())
    .filter(Boolean);

  return { tags, cleanMessage };
}

export function InquiriesTab({
  inquiriesList,
  newInquiriesCount,
  onUpdateInquiryStatus,
  onRefresh,
  isLoading = false,
}: InquiriesTabProps) {
  const [filterStatus, setFilterStatus] = useState<string>("all");

  // Automatically refresh inquiries whenever this tab is opened
  useEffect(() => {
    onRefresh?.();
  }, [onRefresh]);

  const filteredInquiries = inquiriesList.filter((inq) => {
    if (filterStatus === "all") return true;
    return inq.status === filterStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#24242C] pb-6">
        <div>
          <h1 className="font-sans text-xl sm:text-2xl text-white font-semibold tracking-tight">
            Customer Messages &amp; Inquiries
          </h1>
          <p className="text-xs text-[#A1A1AA] font-sans mt-1">
            View customer messages, consultation requests, and contact details.
          </p>
        </div>
        <div className="flex items-center gap-3">
          {isLoading && (
            <span className="text-xs text-[#C5A880] font-sans flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C5A880]" />
              Syncing...
            </span>
          )}
          <span className="text-xs font-mono font-medium tabular-nums text-[#C5A880] bg-[#C5A880]/10 border border-[#C5A880]/30 px-3 py-1.5 rounded-sm">
            {newInquiriesCount} New Messages
          </span>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="flex items-center gap-3 relative z-20">
        <span className="text-[#8C867D] text-[10px] uppercase font-mono tracking-wider shrink-0 select-none">
          Filter:
        </span>
        <div className="w-52 sm:w-56">
          <LuxurySelect
            value={filterStatus}
            onChange={(val) => setFilterStatus(val)}
            variant="dark"
            size="sm"
            options={[
              { value: "all", label: "All Messages", badge: String(inquiriesList.length) },
              {
                value: "new",
                label: "New Messages",
                badge: String(inquiriesList.filter((i) => i.status === "new").length),
              },
              {
                value: "scheduled",
                label: "Scheduled",
                badge: String(inquiriesList.filter((i) => i.status === "scheduled").length),
              },
              {
                value: "resolved",
                label: "Closed",
                badge: String(inquiriesList.filter((i) => i.status === "resolved").length),
              },
            ]}
          />
        </div>
      </div>

      {/* Inquiries Cards Stream */}
      <div className="space-y-4">
        {filteredInquiries.length === 0 ? (
          <div className="p-12 text-center bg-[#141419] border border-[#24242C] rounded-sm text-[#8C867D]">
            <p className="text-sm font-sans">No inquiries match the selected filter.</p>
          </div>
        ) : (
          filteredInquiries.map((inq) => {
            const { tags, cleanMessage } = parseInquiryMessage(inq.message);
            return (
              <div
                key={inq.id}
                className="bg-[#141419] border border-[#24242C] p-6 rounded-sm space-y-4 text-xs font-sans hover:border-[#C5A880]/40 transition-colors"
              >
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-[#24242C] pb-3">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs font-semibold tabular-nums text-[#C5A880]">{inq.id}</span>
                    <span className="text-white font-medium text-sm">{inq.clientName}</span>
                    <span className="text-[#8C867D] font-mono text-xs tabular-nums">• {inq.date}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[#8C867D] text-[10px] uppercase whitespace-nowrap">Status:</span>
                    <div className="w-48">
                      <LuxurySelect
                        variant="dark"
                        size="sm"
                        value={inq.status}
                        onChange={(val) =>
                          onUpdateInquiryStatus(
                            inq.id,
                            val as "new" | "scheduled" | "resolved"
                          )
                        }
                        options={[
                          { value: "new", label: "New Request" },
                          { value: "scheduled", label: "Appointment Scheduled" },
                          { value: "resolved", label: "Completed / Closed" },
                        ]}
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-[#A29F96]">
                  <div>
                    <span className="text-[#6E6B65] uppercase text-[10px] block mb-1">Gemstone / Subject</span>
                    <span className="text-white font-sans font-medium">{inq.gemstoneName || "General Inquiry"}</span>
                    <p className="text-[11px] text-[#C5A880] mt-1">{inq.location || inq.salon}</p>
                  </div>

                  <div className="sm:col-span-2">
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                      <span className="text-[#6E6B65] uppercase text-[10px] block font-mono">
                        Customer Message
                      </span>
                      {tags.length > 0 && (
                        <div className="flex flex-wrap items-center gap-1.5">
                          {tags.map((tag, idx) => (
                            <span
                              key={idx}
                              className="px-2 py-0.5 bg-[#1F1F2B] border border-[#2D2D3D] text-[#C5A880] text-[10px] font-mono rounded-sm"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="p-3.5 bg-[#191922] border border-[#22222C] rounded-sm">
                      <p className="text-[#E0DDD5] text-xs font-sans leading-relaxed whitespace-pre-wrap">
                        {cleanMessage || "Customer requested more details."}
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center gap-4 mt-2.5 text-[11px] font-mono text-[#8C867D]">
                      <span>Email: <strong className="text-white font-sans">{inq.email}</strong></span>
                      <span>Phone: <strong className="text-white font-sans">{inq.phone || "Not provided"}</strong></span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
