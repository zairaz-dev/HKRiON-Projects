import { useQuery } from "@tanstack/react-query";
import { reportService } from "@/services/report-service";
import { queryKeys } from "@/lib/query-keys";

export function useContactBalancesQuery(
  businessId: string,
  filters: {
    search?: string;
  },
) {
  return useQuery({
    queryKey: queryKeys.reports.contactBalances(
      businessId,
      filters.search,
    ),
    queryFn: () => reportService.getContactBalances(businessId, filters),
    enabled: !!businessId,
  });
}
