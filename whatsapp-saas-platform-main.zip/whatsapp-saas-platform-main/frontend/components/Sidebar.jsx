'use client';
import { 
  LayoutDashboard, 
  Workflow, 
  Download, 
  MessageSquare, 
  MessagesSquare,
  Users, 
  Contact2,
  Bot,
  Send,
  Settings, 
  QrCode, 
  Sparkles, 
  ShieldCheck, 
  Server,
  MapPin
} from 'lucide-react';

export default function Sidebar({ activeTab, setActiveTab, onOpenQrModal, onOpenConfigModal, connectionStatus }) {
  const navItems = [
    { id: 'overview', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'chats', label: 'Live Chats Inbox', icon: MessagesSquare },
    { id: 'leads', label: 'Google Maps Lead Ads', icon: MapPin },
    { id: 'aibot', label: 'AI Auto-Reply Bot', icon: Bot },
    { id: 'contacts', label: 'Contacts Directory', icon: Contact2 },
    { id: 'extractor', label: 'Group Extractor', icon: Users },
    { id: 'messenger', label: 'Quick Sender', icon: Send },
    { id: 'downloads', label: 'Downloads Hub', icon: Download },
  ];

  return (
    <aside className="w-64 bg-[#0d151c] border-r border-slate-800/80 flex flex-col justify-between p-4 shrink-0 h-screen sticky top-0">
      <div>
        {/* Brand Header */}
        <div className="flex items-center gap-3 px-2 py-3 mb-6 border-b border-slate-800/80">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 font-bold shadow-lg shadow-emerald-500/20">
            <Sparkles className="w-5 h-5 fill-slate-950" />
          </div>
          <div>
            <h1 className="font-heading font-bold text-lg text-white leading-tight flex items-center gap-1">
              WA SaaS Pro
            </h1>
            <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/50 px-1.5 py-0.5 rounded">
              Evolution v2.0
            </span>
          </div>
        </div>

        {/* Live Status Badge */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 mb-6">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>Evolution Server</span>
            <span className="flex items-center gap-1 text-[10px] text-emerald-400">
              <ShieldCheck className="w-3 h-3" /> Active
            </span>
          </div>
          <div 
            onClick={onOpenQrModal}
            className="flex items-center justify-between cursor-pointer bg-slate-950/80 border border-slate-800 hover:border-emerald-500/50 p-2.5 rounded-lg transition-all"
          >
            <div className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full ${
                connectionStatus === 'open' || connectionStatus === 'connected' 
                  ? 'bg-emerald-400 shadow-[0_0_8px_#10b981]' 
                  : connectionStatus === 'connecting'
                  ? 'bg-amber-400 animate-pulse'
                  : 'bg-rose-500'
              }`} />
              <span className="text-xs font-semibold text-slate-200 capitalize">
                {connectionStatus || 'Disconnected'}
              </span>
            </div>
            <QrCode className="w-4 h-4 text-emerald-400 hover:scale-110 transition-transform" />
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="space-y-1.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-emerald-500/15 to-teal-500/5 text-emerald-400 border border-emerald-500/30 shadow-md shadow-emerald-950/40'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                {item.label}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Sidebar Footer */}
      <div className="space-y-2 pt-4 border-t border-slate-800/80">
        <button
          onClick={onOpenConfigModal}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs text-slate-400 hover:text-white bg-slate-900/50 hover:bg-slate-900 border border-slate-800/80 transition-colors"
        >
          <Server className="w-3.5 h-3.5 text-cyan-400" />
          <span>API Configuration</span>
        </button>
        <div className="text-[11px] text-center text-slate-500 font-mono py-1">
          Next.js + Baileys Architecture
        </div>
      </div>
    </aside>
  );
}
