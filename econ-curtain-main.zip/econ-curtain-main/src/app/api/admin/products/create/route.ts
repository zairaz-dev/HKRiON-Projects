import { NextResponse } from "next/server";
import { ProductService } from "@/services/product.service";
import { SessionManager } from "@/core/auth/session";
import { SafeHttp } from "@/core/http/redirect";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  try {
    const session = await SessionManager.getCurrentSession();
    if (!session) {
      return SafeHttp.redirect("/login", request, 303);
    }

    const contentType = request.headers.get("content-type") || "";
    const isJson = contentType.includes("application/json");

    let name = "";
    let category = "";
    let description = "";
    let imageUrl = "";
    let images: string[] = [];
    let featuresRaw = "";
    let isActive = true;

    let redirectPath = "/admin/products";

    if (isJson) {
      const body = await request.json();
      name = body.name;
      category = body.category;
      description = body.description;
      imageUrl = body.imageUrl;
      images = Array.isArray(body.images) ? body.images : [];
      featuresRaw = Array.isArray(body.features) ? body.features.join(", ") : (body.features || "");
      isActive = body.isActive !== false;
      redirectPath = body.redirectPath || "/admin/products";
    } else {
      const formData = await request.formData();
      name = (formData.get("name") as string) || "";
      category = (formData.get("category") as string) || "";
      description = (formData.get("description") as string) || "";
      imageUrl = (formData.get("imageUrl") as string) || "";
      
      const imagesRaw = formData.get("images") as string;
      if (imagesRaw) {
        try {
          images = JSON.parse(imagesRaw);
        } catch {
          images = [];
        }
      }

      featuresRaw = (formData.get("features") as string) || "";
      isActive = formData.get("isActive") === "on" || formData.get("isActive") === "true";
      redirectPath = (formData.get("redirectPath") as string) || "/admin/products";
    }

    if (!name) {
      if (isJson) {
        return NextResponse.json({ success: false, error: "Missing required fields" }, { status: 400 });
      }
      return SafeHttp.redirect(`${redirectPath}?error=Missing+required+fields`, request, 303);
    }

    const features = featuresRaw
      .split(",")
      .map((f) => f.trim())
      .filter(Boolean);

    await ProductService.create({
      name,
      category,
      description,
      imageUrl,
      images,
      features,
      isActive,
    });

    // Revalidate paths so public pages and admin immediately show updated product data
    revalidatePath("/products");
    revalidatePath("/admin");
    revalidatePath("/admin/products");
    revalidatePath("/");

    if (isJson) {
      return NextResponse.json({ success: true, message: "Product created successfully" });
    }

    return SafeHttp.redirect(`${redirectPath}?success=${encodeURIComponent(`Product "${name}" created successfully!`)}`, request, 303);
  } catch (error) {
    console.error("Failed to create product:", error);
    return SafeHttp.redirect("/admin/products?error=Failed+to+create+product", request, 303);
  }
}
