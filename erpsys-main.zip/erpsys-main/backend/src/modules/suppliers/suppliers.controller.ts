import {
  Controller,
  Get,
  Post,
  Body,
  Put,
  Param,
  Delete,
  Query,
  UseGuards,
  Req,
  UseInterceptors,
  UploadedFile,
  BadRequestException,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { getImageUploadOptions } from '../../common/utils/upload.util';
import { SuppliersService } from './suppliers.service';
import { CreateSupplierDto } from './dto/create-supplier.dto';
import { UpdateSupplierDto } from './dto/update-supplier.dto';
import {
  ApiTags,
  ApiOperation,
  ApiBody,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiQuery,
} from '@nestjs/swagger';
import {
  CreateSupplierBodySchema,
  UpdateSupplierBodySchema,
  SupplierResponseSchema,
} from '../../docs/suppliers.docs';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';

@ApiTags('Suppliers')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
@Controller('suppliers')
export class SuppliersController {
  constructor(private readonly suppliersService: SuppliersService) {}

  @Permissions(Permission.SUPPLIER_CREATE)
  @Post('upload-image')
  @UseInterceptors(FileInterceptor('image', getImageUploadOptions('suppliers')))
  async uploadImage(@UploadedFile() file: any) {
    if (!file) {
      throw new BadRequestException('No image file provided');
    }
    const imageUrl = `/uploads/suppliers/${file.filename}`;
    return { imageUrl };
  }

  @Permissions(Permission.USER_MANAGE)
  @Post(':id/upload-image')
  @UseInterceptors(FileInterceptor('image', getImageUploadOptions('suppliers')))
  async uploadSupplierImageForId(
    @Param('id') id: string,
    @UploadedFile() file: any,
  ) {
    if (!file) {
      throw new BadRequestException('No image file provided');
    }
    const imageUrl = `/uploads/suppliers/${file.filename}`;
    await this.suppliersService.update(id, { image: imageUrl });
    return { imageUrl };
  }

  @Permissions(Permission.SUPPLIER_CREATE)
  @Post()
  @ApiOperation({ summary: 'Create new supplier' })
  @ApiBody({ schema: CreateSupplierBodySchema })
  @ApiResponse({
    status: 201,
    description: 'Supplier created successfully',
    schema: SupplierResponseSchema,
  })
  create(@Req() req: any, @Body() createDto: CreateSupplierDto) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      createDto.businessId = user.businessId;
    }
    if (!createDto.createdById) {
      createDto.createdById = user.id;
    }
    return this.suppliersService.create(createDto);
  }

  @Permissions(Permission.SUPPLIER_VIEW)
  @Get()
  @ApiOperation({ summary: 'Get list of suppliers' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiQuery({ name: 'branchId', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Suppliers retrieved successfully' })
  findAll(
    @Req() req: any,
    @Query('businessId') businessId?: string,
    @Query('branchId') branchId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.suppliersService.findAll(bId, branchId);
  }

  @Permissions(Permission.SUPPLIER_VIEW)
  @Get(':id')
  @ApiOperation({ summary: 'Get supplier details by ID' })
  @ApiParam({ name: 'id', description: 'Supplier UUID' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiResponse({
    status: 200,
    description: 'Supplier retrieved successfully',
    schema: SupplierResponseSchema,
  })
  findOne(@Req() req: any, @Param('id') id: string, @Query('businessId') businessId?: string) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.suppliersService.findOne(id, bId);
  }

  @Permissions(Permission.USER_MANAGE)
  @Put(':id')
  @ApiOperation({ summary: 'Update supplier details' })
  @ApiParam({ name: 'id', description: 'Supplier UUID' })
  @ApiBody({ schema: UpdateSupplierBodySchema })
  @ApiResponse({
    status: 200,
    description: 'Supplier updated successfully',
    schema: SupplierResponseSchema,
  })
  update(
    @Req() req: any,
    @Param('id') id: string,
    @Body() updateDto: UpdateSupplierDto,
  ) {
    const user = req.user;
    if (user.role !== 'super-admin') {
      updateDto.businessId = user.businessId;
    }
    if (!updateDto.updatedById) {
      updateDto.updatedById = user.id;
    }
    return this.suppliersService.update(id, updateDto);
  }

  @Permissions(Permission.USER_MANAGE)
  @Delete(':id')
  @ApiOperation({ summary: 'Delete supplier' })
  @ApiParam({ name: 'id', description: 'Supplier UUID' })
  @ApiQuery({ name: 'businessId', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Supplier deleted successfully' })
  remove(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId?: string,
  ) {
    const user = req.user;
    let bId = businessId;
    if (user.role !== 'super-admin') {
      bId = user.businessId;
    }
    return this.suppliersService.remove(id, bId);
  }
}
