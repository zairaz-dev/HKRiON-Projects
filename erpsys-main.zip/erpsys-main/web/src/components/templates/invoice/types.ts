import { InvoiceLayout } from "@/services/invoice-settings-service";

export interface InvoiceSaleLine {
  id: string;
  quantity: number;
  unitPrice: number;
  discountAmount?: number;
  taxAmount?: number;
  subtotal: number;
  imeiNumber?: string;
  productImeis?: { imeiNumber: string }[];
  variant?: {
    name?: string;
    sku?: string;
    product?: {
      name?: string;
    };
  };
}

export interface InvoiceSaleData {
  id: string;
  invoiceNumber: string;
  saleDate: string | Date;
  discountAmount: number;
  taxAmount: number;
  grandTotal: number;
  amountPaid: number;
  notes?: string;
  businessId?: string;
  branchId?: string;
  customer?: {
    name?: string;
    phone?: string;
    email?: string;
    address?: string;
    taxNumber?: string;
  };
  branch?: {
    name?: string;
    address?: string;
    phone?: string;
    email?: string;
  };
  saleLines?: InvoiceSaleLine[];
}

export interface InvoiceTemplateProps {
  sale: InvoiceSaleData;
  layout?: InvoiceLayout | null;
  businessName: string;
  isPrintMode?: boolean;
  currencySymbol?: string;
}
