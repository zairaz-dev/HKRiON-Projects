import { NextResponse } from "next/server";
import { pool } from "@/lib/db";
import { RowDataPacket } from "mysql2";
import { requireAdmin } from "@/lib/require-admin";
import { sanitizeString } from "@/lib/sanitize";
import { invalidateServerCMSCache } from "@/lib/cms/server";

export interface ContentBlockRow extends RowDataPacket {
  id: string;
  section: string;
  key: string;
  value: string;
  updated_at: string;
}

export interface FaqItemRow extends RowDataPacket {
  id: string;
  question: string;
  answer: string;
  category: string;
  order_index: number;
  created_at: string;
  updated_at: string;
}

export const dynamic = "force-dynamic";
export const revalidate = 0;

// GET: Fetch all CMS Content (Blocks, FAQs)
export async function GET() {
  try {
    const [blockRows] = await pool.query<ContentBlockRow[]>(
      "SELECT id, section, `key`, `value`, updated_at FROM content_blocks ORDER BY section, `key`"
    );

    const [faqRows] = await pool.query<FaqItemRow[]>(
      "SELECT id, question, answer, category, order_index, created_at, updated_at FROM faq_items ORDER BY order_index ASC"
    );

    // Build key-value map for fast frontend consumption
    const blockMap: Record<string, string> = {};
    for (const b of blockRows) {
      blockMap[`${b.section}.${b.key}`] = b.value;
      blockMap[b.key] = b.value;
    }

    return NextResponse.json(
      {
        success: true,
        blocks: blockMap,
        blockRows,
        faqs: faqRows,
      },
      {
        headers: {
          "Cache-Control": "no-store, no-cache, must-revalidate, proxy-revalidate",
        },
      }
    );
  } catch (error) {
    console.error("Failed to load CMS content from database:", error);
    return NextResponse.json(
      {
        success: false,
        warning: "Database currently unavailable. Using built-in default configuration.",
        blocks: {},
        blockRows: [],
        faqs: [],
      },
      {
        status: 200,
        headers: {
          "Cache-Control": "no-store, no-cache, must-revalidate, proxy-revalidate",
        },
      }
    );
  }
}

// POST: Create or batch-upsert CMS content — Admin only
export async function POST(request: Request) {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const body = await request.json();
    const { type } = body;

    // 1. Batch upsert content blocks
    if (type === "blocks") {
      const { items } = body as { items: { section: string; key: string; value: string }[] };
      if (!Array.isArray(items) || items.length === 0) {
        return NextResponse.json({ error: "Missing items array" }, { status: 400 });
      }

      for (const item of items) {
        const id = `block-${item.section}-${item.key}`;
        const safeValue = sanitizeString(item.value);
        await pool.execute(
          `INSERT INTO content_blocks (id, section, \`key\`, \`value\`, updated_at)
           VALUES (?, ?, ?, ?, NOW(3))
           ON DUPLICATE KEY UPDATE \`value\` = VALUES(\`value\`), updated_at = NOW(3)`,
          [id, item.section, item.key, safeValue]
        );
      }

      invalidateServerCMSCache();
      return NextResponse.json({ success: true, count: items.length });
    }

    // 2. Single Content Block Upsert
    if (type === "block") {
      const { section, key, value } = body;
      if (!section || !key || value === undefined) {
        return NextResponse.json({ error: "Section, key, and value are required" }, { status: 400 });
      }

      const id = `block-${section}-${key}`;
      const safeValue = sanitizeString(String(value));
      await pool.execute(
        `INSERT INTO content_blocks (id, section, \`key\`, \`value\`, updated_at)
         VALUES (?, ?, ?, ?, NOW(3))
         ON DUPLICATE KEY UPDATE \`value\` = VALUES(\`value\`), updated_at = NOW(3)`,
        [id, section, key, safeValue]
      );

      invalidateServerCMSCache();
      return NextResponse.json({ success: true, id, section, key, value: safeValue });
    }

    // 3. Create new FAQ Item
    if (type === "faq") {
      const { question, answer, category, orderIndex } = body;
      if (!question || !answer) {
        return NextResponse.json({ error: "Question and answer are required" }, { status: 400 });
      }

      const safeQuestion = sanitizeString(question);
      const safeAnswer = sanitizeString(answer);
      const id = `faq-${Date.now()}`;
      await pool.execute(
        `INSERT INTO faq_items (id, question, answer, category, order_index, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, NOW(3), NOW(3))`,
        [id, safeQuestion, safeAnswer, category || "General", Number(orderIndex) || 0]
      );

      invalidateServerCMSCache();
      return NextResponse.json({
        success: true,
        faq: { id, question: safeQuestion, answer: safeAnswer, category: category || "General", order_index: Number(orderIndex) || 0 },
      });
    }

    return NextResponse.json({ error: "Invalid content type specified" }, { status: 400 });
  } catch (error) {
    console.error("CMS POST error:", error);
    return NextResponse.json(
      { error: "Failed to persist CMS record", details: (error as Error).message },
      { status: 500 }
    );
  }
}

// PUT: Update an existing FAQ — Admin only
export async function PUT(request: Request) {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const body = await request.json();
    const { type, id } = body;

    if (!id) {
      return NextResponse.json({ error: "Record ID is required for update" }, { status: 400 });
    }

    if (type === "faq") {
      const { question, answer, category, orderIndex } = body;
      const safeQuestion = sanitizeString(question);
      const safeAnswer = sanitizeString(answer);
      await pool.execute(
        `UPDATE faq_items
         SET question = ?, answer = ?, category = ?, order_index = ?, updated_at = NOW(3)
         WHERE id = ?`,
        [safeQuestion, safeAnswer, category || "General", Number(orderIndex) || 0, id]
      );

      invalidateServerCMSCache();
      return NextResponse.json({ success: true, id });
    }

    return NextResponse.json({ error: "Invalid update type specified" }, { status: 400 });
  } catch (error) {
    console.error("CMS PUT error:", error);
    return NextResponse.json(
      { error: "Failed to update CMS record", details: (error as Error).message },
      { status: 500 }
    );
  }
}

// DELETE: Delete an item — Admin only
export async function DELETE(request: Request) {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get("type");
    const id = searchParams.get("id");

    if (!type || !id) {
      return NextResponse.json({ error: "Missing type or id parameter" }, { status: 400 });
    }

    if (type === "faq") {
      await pool.execute("DELETE FROM faq_items WHERE id = ?", [id]);
      invalidateServerCMSCache();
      return NextResponse.json({ success: true, deletedId: id, type: "faq" });
    }

    if (type === "block") {
      await pool.execute("DELETE FROM content_blocks WHERE id = ?", [id]);
      invalidateServerCMSCache();
      return NextResponse.json({ success: true, deletedId: id, type: "block" });
    }

    return NextResponse.json({ error: "Invalid deletion type" }, { status: 400 });
  } catch (error) {
    console.error("CMS DELETE error:", error);
    return NextResponse.json(
      { error: "Failed to delete CMS record", details: (error as Error).message },
      { status: 500 }
    );
  }
}
