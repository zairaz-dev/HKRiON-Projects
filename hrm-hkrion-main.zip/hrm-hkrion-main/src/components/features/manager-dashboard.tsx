"use client";

import { Users, UserCheck, CalendarClock, ArrowRight, BarChartIcon } from "lucide-react";
import Link from "next/link";
import { Card } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, Tooltip as RechartsTooltip, ResponsiveContainer, Cell, CartesianGrid } from 'recharts';

type RecentActivity = {
  id: number;
  date: Date;
  clockIn: Date | null;
  clockOut: Date | null;
  user: {
    firstName: string;
    lastName: string;
    email: string;
  };
};

type ManagerDashboardProps = {
  teamHeadcount: number;
  teamPresentToday: number;
  teamPendingLeaves: number;
  teamRecentActivity: RecentActivity[];
};

export default function ManagerDashboard({
  teamHeadcount,
  teamPresentToday,
  teamPendingLeaves,
  teamRecentActivity,
}: ManagerDashboardProps) {

  const formatTime = (d: Date | null) => d ? new Intl.DateTimeFormat("en-US", { hour: "numeric", minute: "numeric", hour12: true }).format(d) : "—";
  const formatDate = (d: Date) => new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric" }).format(d);

  // Process data for the chart: count attendees per date
  const attendanceByDate = teamRecentActivity.reduce((acc, record) => {
    const dateStr = formatDate(record.date);
    acc[dateStr] = (acc[dateStr] || 0) + (record.clockIn ? 1 : 0);
    return acc;
  }, {} as Record<string, number>);

  const chartData = Object.entries(attendanceByDate)
    .map(([date, count]) => ({ date, count }))
    .slice(0, 7) // Last 7 days
    .reverse();

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {[
          {
            label: "My Team Headcount",
            value: teamHeadcount.toString(),
            icon: <Users className="h-5 w-5" />,
            trend: "Direct Reports",
          },
          {
            label: "Team Present Today",
            value: teamPresentToday.toString(),
            icon: <UserCheck className="h-5 w-5" />,
            trend: "Clocked In",
          },
          {
            label: "Team Pending Leaves",
            value: teamPendingLeaves.toString(),
            icon: <CalendarClock className="h-5 w-5" />,
            trend: "To Review",
          },
        ].map((stat, i) => (
          <Card key={i} className="p-5 shadow-sm transition-shadow hover:shadow-md border-border bg-surface">
            <div className="mb-4 flex items-center justify-between">
              <span className="text-sm font-medium text-text-secondary">
                {stat.label}
              </span>
              <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-bg text-primary">
                {stat.icon}
              </span>
            </div>
            <div className="flex items-baseline gap-2">
              <p className="text-3xl font-semibold text-text-primary">
                {stat.value}
              </p>
              <span className="text-xs font-medium text-success">
                {stat.trend}
              </span>
            </div>
          </Card>
        ))}
      </div>

      {/* Main Content Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Recent Activity Feed */}
        <div className="lg:col-span-2 rounded-xl border border-border bg-surface shadow-sm flex flex-col">
          <div className="border-b border-border p-5 flex justify-between items-center">
            <h2 className="font-semibold text-text-primary">My Team's Recent Attendance</h2>
          </div>
          <div className="flex-1 p-0 overflow-hidden">
            {teamRecentActivity.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-48 text-text-secondary text-sm">
                <CalendarClock className="h-8 w-8 text-border mb-2" />
                <p>No recent activity found for your team.</p>
              </div>
            ) : (
              <div className="divide-y divide-border h-[400px] overflow-y-auto custom-scrollbar">
                {teamRecentActivity.map((activity) => (
                  <div key={activity.id} className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-surface-secondary/50 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className="relative">
                        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-primary/20 to-primary/5 text-primary font-semibold text-sm border border-primary/20 shadow-sm">
                          {activity.user.firstName.charAt(0)}{activity.user.lastName.charAt(0)}
                        </div>
                        <div className="absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-surface border border-border shadow-sm">
                          <CalendarClock className="h-3 w-3 text-text-secondary" />
                        </div>
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-text-primary">
                          {activity.user.firstName} {activity.user.lastName}
                        </p>
                        <p className="text-xs text-text-secondary mt-0.5 font-medium">
                          {formatDate(activity.date)}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-end gap-3 sm:gap-4 bg-surface-elevated sm:bg-transparent p-3 sm:p-0 rounded-lg border border-border sm:border-none">
                      <div className="flex flex-col">
                        <span className="text-[10px] font-medium uppercase tracking-wider text-text-secondary mb-1.5">Clock In</span>
                        <span className="inline-flex w-[84px] items-center justify-center rounded-md bg-success-bg/50 px-2 py-1 text-xs font-mono font-medium text-success border border-success/10">
                          {formatTime(activity.clockIn)}
                        </span>
                      </div>
                      
                      <div className="hidden sm:flex items-center justify-center h-[26px] mb-[1px]">
                        <ArrowRight className="h-4 w-4 text-text-secondary/40" />
                      </div>
                      
                      <div className="flex flex-col">
                        <span className="text-[10px] font-medium uppercase tracking-wider text-text-secondary mb-1.5">Clock Out</span>
                        <span className={`inline-flex w-[84px] items-center justify-center rounded-md px-2 py-1 text-xs font-mono font-medium border ${activity.clockOut ? 'bg-error-bg/50 text-error border-error/10' : 'bg-surface-secondary text-text-secondary border-border'}`}>
                          {formatTime(activity.clockOut)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Weekly Attendance Trend Chart */}
        <div className="lg:col-span-1 rounded-xl border border-border bg-surface shadow-sm flex flex-col">
          <div className="border-b border-border p-5 flex justify-between items-center">
            <h2 className="font-semibold text-text-primary flex items-center gap-2">
              <BarChartIcon className="h-5 w-5 text-primary" />
              Attendance Trend
            </h2>
          </div>
          <div className="flex-1 p-5 flex items-center justify-center min-h-[300px]">
            {chartData.length === 0 ? (
              <div className="flex flex-col items-center justify-center text-text-secondary text-sm">
                <BarChartIcon className="h-8 w-8 text-border mb-2" />
                <p>Not enough data for chart.</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" />
                  <XAxis 
                    dataKey="date" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 12, fill: 'var(--text-secondary)' }}
                    dy={10}
                  />
                  <YAxis 
                    allowDecimals={false} 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 12, fill: 'var(--text-secondary)' }}
                  />
                  <RechartsTooltip
                    cursor={{ fill: 'var(--surface-secondary)' }}
                    contentStyle={{ borderRadius: '8px', border: '1px solid var(--border)', backgroundColor: 'var(--surface-elevated)' }}
                    itemStyle={{ color: 'var(--text-primary)' }}
                  />
                  <Bar dataKey="count" name="Clocked In" radius={[4, 4, 0, 0]}>
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill="var(--primary)" />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
