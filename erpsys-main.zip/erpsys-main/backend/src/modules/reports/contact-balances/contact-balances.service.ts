import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class ContactBalancesService {
  constructor(private readonly prisma: PrismaService) {}

  async getContactBalances(
    businessId: string,
    filters: {
      search?: string;
    },
  ) {
    const { search } = filters;

    // 1. Customer Receivables
    const customerWhere: any = { businessId };
    if (search) {
      customerWhere.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search, mode: 'insensitive' } },
      ];
    }

    const customers = await this.prisma.customer.findMany({
      where: customerWhere,
      include: {
        sales: {
          where: {
            paymentStatus: { in: ['DUE', 'PARTIAL'] },
            status: 'FINAL',
          },
          select: {
            id: true,
            grandTotal: true,
            amountPaid: true,
          },
        },
        advances: {
          select: {
            amountRemaining: true,
          },
        },
      },
    });

    const customerLedger = customers
      .map((c) => {
        const totalDue = c.sales.reduce((sum, s) => sum + (s.grandTotal - s.amountPaid), 0);
        const totalAdvance = c.advances.reduce((sum, a) => sum + a.amountRemaining, 0);

        return {
          id: c.id,
          name: c.name,
          phone: c.phone || 'N/A',
          totalDue,
          totalAdvance,
          netBalance: totalDue - totalAdvance, // positive means customer owes money
        };
      })
      .filter((c) => c.totalDue > 0 || c.totalAdvance > 0);

    const totalCustomerReceivables = customerLedger.reduce((sum, c) => sum + Math.max(0, c.netBalance), 0);

    // 2. Supplier Payables
    const supplierWhere: any = { businessId };
    if (search) {
      supplierWhere.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search, mode: 'insensitive' } },
      ];
    }

    const suppliers = await this.prisma.supplier.findMany({
      where: supplierWhere,
      include: {
        purchases: {
          where: {
            paymentStatus: { in: ['DUE', 'PARTIAL'] },
          },
          select: {
            id: true,
            grandTotal: true,
            amountPaid: true,
          },
        },
        advances: {
          select: {
            amountRemaining: true,
          },
        },
      },
    });

    const supplierLedger = suppliers
      .map((s) => {
        const totalDue = s.purchases.reduce((sum, p) => sum + (p.grandTotal - p.amountPaid), 0);
        const totalAdvance = s.advances.reduce((sum, a) => sum + a.amountRemaining, 0);

        return {
          id: s.id,
          name: s.name,
          mobile: s.phone || 'N/A',
          totalDue,
          totalAdvance,
          netBalance: totalDue - totalAdvance, // positive means business owes supplier
        };
      })
      .filter((s) => s.totalDue > 0 || s.totalAdvance > 0);

    const totalSupplierPayables = supplierLedger.reduce((sum, s) => sum + Math.max(0, s.netBalance), 0);

    return {
      totalCustomerReceivables,
      totalSupplierPayables,
      customerLedger,
      supplierLedger,
    };
  }
}
