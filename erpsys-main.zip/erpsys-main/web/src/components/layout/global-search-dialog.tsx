'use client';

import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { useRouter } from 'next/navigation';
import { 
  Search, 
  X, 
  Loader2, 
  Package, 
  Receipt, 
  ShoppingBag, 
  Users, 
  Truck, 
  ShoppingCart, 
  BarChart3, 
  Settings, 
  CreditCard, 
  PlusCircle, 
  ExternalLink, 
  History, 
  Trash2,
  CornerDownLeft,
  ArrowUpDown
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { 
  searchService, 
  GlobalSearchResponse, 
  ProductSearchResult, 
  SaleSearchResult, 
  PurchaseSearchResult, 
  ContactSearchResult 
} from '@/services/search-service';

export interface GlobalSearchDialogProps {
  isOpen: boolean;
  onClose: () => void;
  businessId?: string;
  branchId?: string;
}

type TabType = 'all' | 'products' | 'sales' | 'purchases' | 'contacts' | 'pages';

interface PageItem {
  title: string;
  category: 'Page' | 'Action';
  href: string;
  icon: React.ElementType;
  keywords: string[];
}

const ERP_PAGES: PageItem[] = [
  { title: 'POS Terminal', category: 'Action', href: '/pos', icon: ShoppingCart, keywords: ['pos', 'sale', 'checkout', 'counter', 'cashier'] },
  { title: 'Sales & Invoices', category: 'Page', href: '/sales', icon: Receipt, keywords: ['sales', 'invoices', 'receipts', 'billing', 'orders'] },
  { title: 'Products Catalog', category: 'Page', href: '/products', icon: Package, keywords: ['products', 'items', 'inventory', 'catalog', 'sku', 'stock'] },
  { title: 'Purchases & Bills', category: 'Page', href: '/purchases', icon: ShoppingBag, keywords: ['purchases', 'bills', 'supplier invoices', 'po'] },
  { title: 'Customers', category: 'Page', href: '/customers', icon: Users, keywords: ['customers', 'clients', 'debtors', 'accounts'] },
  { title: 'Suppliers', category: 'Page', href: '/suppliers', icon: Truck, keywords: ['suppliers', 'vendors', 'creditors'] },
  { title: 'Reports & Analytics', category: 'Page', href: '/reports', icon: BarChart3, keywords: ['reports', 'analytics', 'profit', 'loss', 'overview'] },
  { title: 'Expenses', category: 'Page', href: '/expenses', icon: CreditCard, keywords: ['expenses', 'spending', 'cost', 'bills'] },
  { title: 'Settings', category: 'Page', href: '/settings', icon: Settings, keywords: ['settings', 'config', 'branches', 'business', 'roles'] },
];

interface RecentSearchItem {
  id: string;
  title: string;
  subtitle: string;
  href: string;
  type: 'product' | 'sale' | 'purchase' | 'contact' | 'page';
  timestamp: number;
}

export function GlobalSearchDialog({
  isOpen,
  onClose,
  businessId,
  branchId,
}: GlobalSearchDialogProps) {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const resultsContainerRef = useRef<HTMLDivElement>(null);

  const [query, setQuery] = useState('');
  const [activeTab, setActiveTab] = useState<TabType>('all');
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState<GlobalSearchResponse>({
    query: '',
    products: [],
    sales: [],
    purchases: [],
    contacts: [],
  });
  const [recentSearches, setRecentSearches] = useState<RecentSearchItem[]>([]);
  const [selectedIndex, setSelectedIndex] = useState<number>(0);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  // Load recent searches from localStorage
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('hkr_recent_searches');
        if (saved) {
          setRecentSearches(JSON.parse(saved));
        }
      } catch (err) {
        console.error('Failed to load recent searches', err);
      }
    }
  }, [isOpen]);

  const saveRecentSearch = (item: Omit<RecentSearchItem, 'timestamp'>) => {
    try {
      const updated = [
        { ...item, timestamp: Date.now() },
        ...recentSearches.filter((r) => r.href !== item.href),
      ].slice(0, 6);
      setRecentSearches(updated);
      localStorage.setItem('hkr_recent_searches', JSON.stringify(updated));
    } catch (err) {
      console.error('Failed to save recent search', err);
    }
  };

  const clearRecentSearches = () => {
    setRecentSearches([]);
    localStorage.removeItem('hkr_recent_searches');
  };

  // Focus input and lock scroll on open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      setTimeout(() => {
        inputRef.current?.focus();
        inputRef.current?.select();
      }, 50);
    } else {
      document.body.style.overflow = '';
      setQuery('');
      setActiveTab('all');
      setSelectedIndex(0);
    }

    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  // Debounced API search
  useEffect(() => {
    const trimmed = query.trim();
    if (!trimmed) {
      setResults({
        query: '',
        products: [],
        sales: [],
        purchases: [],
        contacts: [],
      });
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    const handler = setTimeout(async () => {
      try {
        const res = await searchService.searchGlobal(trimmed, businessId, branchId, 5);
        setResults(res);
      } catch (error) {
        console.error('Global search error', error);
      } finally {
        setIsLoading(false);
      }
    }, 220);

    return () => clearTimeout(handler);
  }, [query, businessId, branchId]);

  // Filter client-side pages based on query
  const filteredPages = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    return ERP_PAGES.filter((p) => 
      p.title.toLowerCase().includes(q) || 
      p.keywords.some(k => k.includes(q))
    );
  }, [query]);

  // Flatten items for keyboard navigation based on activeTab
  const flatSelectableItems = useMemo(() => {
    const items: Array<{
      id: string;
      title: string;
      subtitle: string;
      href: string;
      type: 'product' | 'sale' | 'purchase' | 'contact' | 'page';
    }> = [];

    // If query is empty, allow navigating recent searches
    if (!query.trim()) {
      recentSearches.forEach((r) => {
        items.push({
          id: `recent-${r.id}`,
          title: r.title,
          subtitle: r.subtitle,
          href: r.href,
          type: r.type,
        });
      });
      return items;
    }

    // Pages / Shortcuts
    if (activeTab === 'all' || activeTab === 'pages') {
      filteredPages.forEach((p) => {
        items.push({
          id: `page-${p.href}`,
          title: p.title,
          subtitle: p.category,
          href: p.href,
          type: 'page',
        });
      });
    }

    // Products
    if (activeTab === 'all' || activeTab === 'products') {
      results.products.forEach((p) => {
        items.push({
          id: `prod-${p.id}`,
          title: p.name,
          subtitle: p.sku ? `SKU: ${p.sku}` : (p.categoryName || 'Product'),
          href: `/products?search=${encodeURIComponent(p.sku || p.name)}`,
          type: 'product',
        });
      });
    }

    // Sales
    if (activeTab === 'all' || activeTab === 'sales') {
      results.sales.forEach((s) => {
        items.push({
          id: `sale-${s.id}`,
          title: s.invoiceNumber,
          subtitle: `${s.customerName} • ${s.paymentStatus}`,
          href: `/sales?search=${encodeURIComponent(s.invoiceNumber)}`,
          type: 'sale',
        });
      });
    }

    // Purchases
    if (activeTab === 'all' || activeTab === 'purchases') {
      results.purchases.forEach((pu) => {
        items.push({
          id: `purch-${pu.id}`,
          title: pu.purchaseNumber,
          subtitle: `${pu.supplierName} • ${pu.status}`,
          href: `/purchases?search=${encodeURIComponent(pu.purchaseNumber)}`,
          type: 'purchase',
        });
      });
    }

    // Contacts
    if (activeTab === 'all' || activeTab === 'contacts') {
      results.contacts.forEach((c) => {
        items.push({
          id: `contact-${c.id}`,
          title: c.name,
          subtitle: `${c.type} • ${c.phone || c.email || ''}`,
          href: c.type === 'CUSTOMER' 
            ? `/customers?search=${encodeURIComponent(c.name)}`
            : `/suppliers?search=${encodeURIComponent(c.name)}`,
          type: 'contact',
        });
      });
    }

    return items;
  }, [query, activeTab, filteredPages, results, recentSearches]);

  // Reset selected index when items list changes
  useEffect(() => {
    setSelectedIndex(0);
  }, [flatSelectableItems.length, activeTab]);

  const handleSelectItem = useCallback((item: {
    id: string;
    title: string;
    subtitle: string;
    href: string;
    type: 'product' | 'sale' | 'purchase' | 'contact' | 'page';
  }) => {
    saveRecentSearch({
      id: item.id,
      title: item.title,
      subtitle: item.subtitle,
      href: item.href,
      type: item.type,
    });
    onClose();
    router.push(item.href);
  }, [onClose, router]);

  // Keyboard navigation inside modal
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      e.preventDefault();
      onClose();
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => 
        prev < flatSelectableItems.length - 1 ? prev + 1 : 0
      );
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => 
        prev > 0 ? prev - 1 : flatSelectableItems.length - 1
      );
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (flatSelectableItems[selectedIndex]) {
        handleSelectItem(flatSelectableItems[selectedIndex]);
      }
    }
  };

  if (!isOpen || !mounted) return null;

  const totalResultsCount = 
    filteredPages.length + 
    results.products.length + 
    results.sales.length + 
    results.purchases.length + 
    results.contacts.length;

  const hasAnyResults = totalResultsCount > 0;
  const isQueryActive = query.trim().length > 0;

  return createPortal(
    <>
      {/* Invisible overlay over the top bar to close search dialog on click, without blurring the top bar */}
      <div 
        className="fixed top-0 inset-x-0 h-16 z-50 bg-transparent cursor-default"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Backdrop overlay starting below the top bar (top-16) without blur */}
      <div 
        className="fixed inset-x-0 top-16 bottom-0 z-50 flex items-start justify-center p-3 sm:p-4 pt-4 md:pt-6 bg-black/60 transition-opacity animate-in fade-in-0 duration-150"
        onClick={onClose}
      >
        <div 
          className="w-full max-w-2xl bg-card border border-border shadow-2xl rounded-sm overflow-hidden flex flex-col max-h-[calc(100vh-6.5rem)] animate-in zoom-in-95 duration-150"
          onClick={(e) => e.stopPropagation()}
          onKeyDown={handleKeyDown}
        >
        {/* Top Search Input Bar */}
        <div className="relative flex items-center border-b border-border/80 px-4 py-3 bg-muted/20">
          <Search className="w-5 h-5 text-muted-foreground shrink-0 mr-3" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search products, SKU, invoices, customers, pages..."
            className="w-full bg-transparent text-sm sm:text-base text-foreground placeholder:text-muted-foreground/70 outline-none"
          />
          <div className="flex items-center gap-2 shrink-0 ml-2">
            {isLoading ? (
              <Loader2 className="w-4 h-4 text-primary animate-spin" />
            ) : query ? (
              <button 
                onClick={() => setQuery('')}
                className="text-muted-foreground hover:text-foreground p-1 rounded-sm transition-colors"
                title="Clear query"
              >
                <X className="w-4 h-4" />
              </button>
            ) : null}
            <kbd className="hidden sm:inline-flex items-center gap-1 text-[11px] font-medium text-muted-foreground bg-muted border border-border px-1.5 py-0.5 rounded-sm shadow-xs">
              ESC
            </kbd>
          </div>
        </div>

        {/* Filter Tabs (Visible when query exists or when items present) */}
        {isQueryActive && (
          <div className="flex items-center gap-1.5 px-4 py-2 border-b border-border/40 overflow-x-auto bg-muted/10 scrollbar-none text-xs">
            <button
              onClick={() => setActiveTab('all')}
              className={cn(
                "px-2.5 py-1 rounded-sm transition-colors font-medium shrink-0",
                activeTab === 'all'
                  ? "bg-primary text-primary-foreground shadow-xs"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              )}
            >
              All ({totalResultsCount})
            </button>
            {filteredPages.length > 0 && (
              <button
                onClick={() => setActiveTab('pages')}
                className={cn(
                  "px-2.5 py-1 rounded-sm transition-colors font-medium shrink-0",
                  activeTab === 'pages'
                    ? "bg-primary text-primary-foreground shadow-xs"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                )}
              >
                Pages ({filteredPages.length})
              </button>
            )}
            {results.products.length > 0 && (
              <button
                onClick={() => setActiveTab('products')}
                className={cn(
                  "px-2.5 py-1 rounded-sm transition-colors font-medium shrink-0",
                  activeTab === 'products'
                    ? "bg-primary text-primary-foreground shadow-xs"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                )}
              >
                Products ({results.products.length})
              </button>
            )}
            {results.sales.length > 0 && (
              <button
                onClick={() => setActiveTab('sales')}
                className={cn(
                  "px-2.5 py-1 rounded-sm transition-colors font-medium shrink-0",
                  activeTab === 'sales'
                    ? "bg-primary text-primary-foreground shadow-xs"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                )}
              >
                Invoices ({results.sales.length})
              </button>
            )}
            {results.purchases.length > 0 && (
              <button
                onClick={() => setActiveTab('purchases')}
                className={cn(
                  "px-2.5 py-1 rounded-sm transition-colors font-medium shrink-0",
                  activeTab === 'purchases'
                    ? "bg-primary text-primary-foreground shadow-xs"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                )}
              >
                Purchases ({results.purchases.length})
              </button>
            )}
            {results.contacts.length > 0 && (
              <button
                onClick={() => setActiveTab('contacts')}
                className={cn(
                  "px-2.5 py-1 rounded-sm transition-colors font-medium shrink-0",
                  activeTab === 'contacts'
                    ? "bg-primary text-primary-foreground shadow-xs"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                )}
              >
                Contacts ({results.contacts.length})
              </button>
            )}
          </div>
        )}

        {/* Scrollable Results Content */}
        <div 
          ref={resultsContainerRef}
          className="flex-1 overflow-y-auto p-2 sm:p-3 divide-y divide-border/30 space-y-3"
        >
          {/* 1. Empty Query State: Show Recent Searches & Quick Actions */}
          {!isQueryActive && (
            <div className="space-y-4 py-1">
              {/* Recent searches */}
              {recentSearches.length > 0 && (
                <div>
                  <div className="flex items-center justify-between px-2 mb-1.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    <span className="flex items-center gap-1.5">
                      <History className="w-3.5 h-3.5" /> Recent Searches
                    </span>
                    <button 
                      onClick={clearRecentSearches}
                      className="text-[11px] text-muted-foreground hover:text-destructive transition-colors flex items-center gap-1 normal-case"
                    >
                      <Trash2 className="w-3 h-3" /> Clear
                    </button>
                  </div>
                  <div className="space-y-1">
                    {recentSearches.map((r, idx) => {
                      const isSelected = selectedIndex === idx;
                      return (
                        <div
                          key={`recent-${r.id}-${idx}`}
                          onClick={() => handleSelectItem(r)}
                          onMouseEnter={() => setSelectedIndex(idx)}
                          className={cn(
                            "flex items-center justify-between px-3 py-2 rounded-sm cursor-pointer transition-colors text-sm",
                            isSelected 
                              ? "bg-primary/15 text-foreground border border-primary/30" 
                              : "hover:bg-accent text-foreground/90 border border-transparent"
                          )}
                        >
                          <div className="flex items-center gap-2.5 truncate">
                            <History className="w-4 h-4 text-muted-foreground shrink-0" />
                            <span className="font-medium truncate">{r.title}</span>
                            <span className="text-xs text-muted-foreground truncate">{r.subtitle}</span>
                          </div>
                          <span className="text-xs text-muted-foreground uppercase text-[10px] font-semibold bg-muted px-1.5 py-0.5 rounded-sm border border-border">
                            {r.type}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Quick Actions / Shortcuts */}
              <div>
                <div className="px-2 mb-1.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  Quick Navigation
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                  {ERP_PAGES.slice(0, 6).map((page) => {
                    const PageIcon = page.icon;
                    return (
                      <button
                        key={page.href}
                        onClick={() => {
                          onClose();
                          router.push(page.href);
                        }}
                        className="flex items-center gap-2.5 p-2.5 rounded-sm border border-border/60 bg-muted/20 hover:bg-primary/10 hover:border-primary/30 text-left transition-all group"
                      >
                        <div className="p-1.5 rounded-sm bg-muted text-muted-foreground group-hover:text-primary group-hover:bg-primary/20 transition-colors">
                          <PageIcon className="w-4 h-4" />
                        </div>
                        <div className="truncate">
                          <p className="text-xs font-medium text-foreground group-hover:text-primary truncate transition-colors">
                            {page.title}
                          </p>
                          <p className="text-[10px] text-muted-foreground truncate">
                            {page.category}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* 2. Active Query Results */}
          {isQueryActive && (
            <>
              {/* No results message */}
              {!isLoading && !hasAnyResults && (
                <div className="py-12 text-center">
                  <Package className="w-10 h-10 text-muted-foreground/40 mx-auto mb-2" />
                  <p className="text-sm font-medium text-foreground">No results found for &ldquo;{query}&rdquo;</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Try searching by Product Name, SKU, Invoice #, or Contact.
                  </p>
                </div>
              )}

              {/* Pages / Navigation Section */}
              {(activeTab === 'all' || activeTab === 'pages') && filteredPages.length > 0 && (
                <div className="pt-2 first:pt-0">
                  <div className="px-2 mb-1.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    Pages & Navigation
                  </div>
                  <div className="space-y-1">
                    {filteredPages.map((page) => {
                      const itemObj = {
                        id: `page-${page.href}`,
                        title: page.title,
                        subtitle: page.category,
                        href: page.href,
                        type: 'page' as const,
                      };
                      const itemIdx = flatSelectableItems.findIndex((i) => i.id === itemObj.id);
                      const isSelected = selectedIndex === itemIdx;
                      const PageIcon = page.icon;

                      return (
                        <div
                          key={page.href}
                          onClick={() => handleSelectItem(itemObj)}
                          onMouseEnter={() => setSelectedIndex(itemIdx)}
                          className={cn(
                            "flex items-center justify-between px-3 py-2 rounded-sm cursor-pointer transition-colors text-sm",
                            isSelected 
                              ? "bg-primary/15 text-foreground border border-primary/30" 
                              : "hover:bg-accent text-foreground/90 border border-transparent"
                          )}
                        >
                          <div className="flex items-center gap-2.5 truncate">
                            <PageIcon className="w-4 h-4 text-primary shrink-0" />
                            <span className="font-medium truncate">{page.title}</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                            <span>Jump to</span>
                            <CornerDownLeft className="w-3.5 h-3.5 text-primary" />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Products Section */}
              {(activeTab === 'all' || activeTab === 'products') && results.products.length > 0 && (
                <div className="pt-2 first:pt-0">
                  <div className="px-2 mb-1.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    Products & SKUs
                  </div>
                  <div className="space-y-1">
                    {results.products.map((prod) => {
                      const itemObj = {
                        id: `prod-${prod.id}`,
                        title: prod.name,
                        subtitle: prod.sku ? `SKU: ${prod.sku}` : (prod.categoryName || 'Product'),
                        href: `/products?search=${encodeURIComponent(prod.sku || prod.name)}`,
                        type: 'product' as const,
                      };
                      const itemIdx = flatSelectableItems.findIndex((i) => i.id === itemObj.id);
                      const isSelected = selectedIndex === itemIdx;

                      return (
                        <div
                          key={prod.id}
                          onClick={() => handleSelectItem(itemObj)}
                          onMouseEnter={() => setSelectedIndex(itemIdx)}
                          className={cn(
                            "flex items-center justify-between px-3 py-2 rounded-sm cursor-pointer transition-colors text-sm",
                            isSelected 
                              ? "bg-primary/15 text-foreground border border-primary/30" 
                              : "hover:bg-accent text-foreground/90 border border-transparent"
                          )}
                        >
                          <div className="flex items-center gap-3 truncate">
                            <div className="p-1.5 rounded-sm bg-muted text-muted-foreground shrink-0">
                              <Package className="w-4 h-4" />
                            </div>
                            <div className="truncate">
                              <div className="flex items-center gap-2">
                                <span className="font-medium text-foreground truncate">{prod.name}</span>
                                {prod.sku && (
                                  <span className="text-[10px] font-mono font-medium px-1.5 py-0.2 bg-muted text-muted-foreground border border-border rounded-sm">
                                    {prod.sku}
                                  </span>
                                )}
                              </div>
                              <p className="text-xs text-muted-foreground truncate">
                                {prod.categoryName || 'General Category'}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-3 shrink-0 text-right">
                            {prod.sellingPrice !== null && prod.sellingPrice !== undefined && (
                              <span className="text-xs font-semibold text-foreground">
                                {prod.sellingPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                              </span>
                            )}
                            <span className={cn(
                              "text-[10px] font-semibold px-2 py-0.5 rounded-sm border",
                              prod.stock > 0 
                                ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20" 
                                : "bg-rose-500/10 text-rose-500 border-rose-500/20"
                            )}>
                              {prod.stock > 0 ? `${prod.stock} in stock` : 'Out of stock'}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Sales / Invoices Section */}
              {(activeTab === 'all' || activeTab === 'sales') && results.sales.length > 0 && (
                <div className="pt-2 first:pt-0">
                  <div className="px-2 mb-1.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    Sales Transactions & Invoices
                  </div>
                  <div className="space-y-1">
                    {results.sales.map((sale) => {
                      const itemObj = {
                        id: `sale-${sale.id}`,
                        title: sale.invoiceNumber,
                        subtitle: `${sale.customerName} • ${sale.paymentStatus}`,
                        href: `/sales?search=${encodeURIComponent(sale.invoiceNumber)}`,
                        type: 'sale' as const,
                      };
                      const itemIdx = flatSelectableItems.findIndex((i) => i.id === itemObj.id);
                      const isSelected = selectedIndex === itemIdx;

                      return (
                        <div
                          key={sale.id}
                          onClick={() => handleSelectItem(itemObj)}
                          onMouseEnter={() => setSelectedIndex(itemIdx)}
                          className={cn(
                            "flex items-center justify-between px-3 py-2 rounded-sm cursor-pointer transition-colors text-sm",
                            isSelected 
                              ? "bg-primary/15 text-foreground border border-primary/30" 
                              : "hover:bg-accent text-foreground/90 border border-transparent"
                          )}
                        >
                          <div className="flex items-center gap-3 truncate">
                            <div className="p-1.5 rounded-sm bg-muted text-muted-foreground shrink-0">
                              <Receipt className="w-4 h-4" />
                            </div>
                            <div className="truncate">
                              <div className="flex items-center gap-2">
                                <span className="font-semibold text-foreground font-mono">{sale.invoiceNumber}</span>
                                <span className="text-xs text-muted-foreground">•</span>
                                <span className="text-xs font-medium text-muted-foreground truncate">{sale.customerName}</span>
                              </div>
                              <p className="text-[11px] text-muted-foreground">
                                {new Date(sale.saleDate).toLocaleDateString()} {sale.branchName ? `(${sale.branchName})` : ''}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2.5 shrink-0">
                            <span className="text-xs font-semibold text-foreground">
                              {sale.grandTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                            </span>
                            <span className={cn(
                              "text-[10px] font-semibold px-2 py-0.5 rounded-sm border uppercase",
                              sale.paymentStatus === 'PAID'
                                ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
                                : sale.paymentStatus === 'PARTIAL'
                                ? "bg-amber-500/10 text-amber-500 border-amber-500/20"
                                : "bg-rose-500/10 text-rose-500 border-rose-500/20"
                            )}>
                              {sale.paymentStatus}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Purchases Section */}
              {(activeTab === 'all' || activeTab === 'purchases') && results.purchases.length > 0 && (
                <div className="pt-2 first:pt-0">
                  <div className="px-2 mb-1.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    Purchases & Bills
                  </div>
                  <div className="space-y-1">
                    {results.purchases.map((purch) => {
                      const itemObj = {
                        id: `purch-${purch.id}`,
                        title: purch.purchaseNumber,
                        subtitle: `${purch.supplierName} • ${purch.status}`,
                        href: `/purchases?search=${encodeURIComponent(purch.purchaseNumber)}`,
                        type: 'purchase' as const,
                      };
                      const itemIdx = flatSelectableItems.findIndex((i) => i.id === itemObj.id);
                      const isSelected = selectedIndex === itemIdx;

                      return (
                        <div
                          key={purch.id}
                          onClick={() => handleSelectItem(itemObj)}
                          onMouseEnter={() => setSelectedIndex(itemIdx)}
                          className={cn(
                            "flex items-center justify-between px-3 py-2 rounded-sm cursor-pointer transition-colors text-sm",
                            isSelected 
                              ? "bg-primary/15 text-foreground border border-primary/30" 
                              : "hover:bg-accent text-foreground/90 border border-transparent"
                          )}
                        >
                          <div className="flex items-center gap-3 truncate">
                            <div className="p-1.5 rounded-sm bg-muted text-muted-foreground shrink-0">
                              <ShoppingBag className="w-4 h-4" />
                            </div>
                            <div className="truncate">
                              <div className="flex items-center gap-2">
                                <span className="font-semibold text-foreground font-mono">{purch.purchaseNumber}</span>
                                <span className="text-xs text-muted-foreground">•</span>
                                <span className="text-xs font-medium text-muted-foreground truncate">{purch.supplierName}</span>
                              </div>
                              <p className="text-[11px] text-muted-foreground">
                                {new Date(purch.purchaseDate).toLocaleDateString()}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2.5 shrink-0">
                            <span className="text-xs font-semibold text-foreground">
                              {purch.grandTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                            </span>
                            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-sm border bg-muted text-muted-foreground border-border uppercase">
                              {purch.status}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Contacts Section */}
              {(activeTab === 'all' || activeTab === 'contacts') && results.contacts.length > 0 && (
                <div className="pt-2 first:pt-0">
                  <div className="px-2 mb-1.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    Customers & Suppliers
                  </div>
                  <div className="space-y-1">
                    {results.contacts.map((contact) => {
                      const itemObj = {
                        id: `contact-${contact.id}`,
                        title: contact.name,
                        subtitle: `${contact.type} • ${contact.phone || contact.email || ''}`,
                        href: contact.type === 'CUSTOMER'
                          ? `/customers?search=${encodeURIComponent(contact.name)}`
                          : `/suppliers?search=${encodeURIComponent(contact.name)}`,
                        type: 'contact' as const,
                      };
                      const itemIdx = flatSelectableItems.findIndex((i) => i.id === itemObj.id);
                      const isSelected = selectedIndex === itemIdx;

                      return (
                        <div
                          key={contact.id}
                          onClick={() => handleSelectItem(itemObj)}
                          onMouseEnter={() => setSelectedIndex(itemIdx)}
                          className={cn(
                            "flex items-center justify-between px-3 py-2 rounded-sm cursor-pointer transition-colors text-sm",
                            isSelected 
                              ? "bg-primary/15 text-foreground border border-primary/30" 
                              : "hover:bg-accent text-foreground/90 border border-transparent"
                          )}
                        >
                          <div className="flex items-center gap-3 truncate">
                            <div className="p-1.5 rounded-sm bg-muted text-muted-foreground shrink-0">
                              {contact.type === 'CUSTOMER' ? (
                                <Users className="w-4 h-4 text-blue-500" />
                              ) : (
                                <Truck className="w-4 h-4 text-amber-500" />
                              )}
                            </div>
                            <div className="truncate">
                              <span className="font-medium text-foreground truncate">{contact.name}</span>
                              <p className="text-xs text-muted-foreground truncate">
                                {contact.phone || contact.email || 'No contact details'}
                              </p>
                            </div>
                          </div>

                          <span className={cn(
                            "text-[10px] font-semibold px-2 py-0.5 rounded-sm border uppercase tracking-wide",
                            contact.type === 'CUSTOMER'
                              ? "bg-blue-500/10 text-blue-500 border-blue-500/20"
                              : "bg-amber-500/10 text-amber-500 border-amber-500/20"
                          )}>
                            {contact.type}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Bottom Footer with Keyboard Shortcuts Help */}
        <div className="flex items-center justify-between px-4 py-2.5 border-t border-border/60 bg-muted/20 text-[11px] text-muted-foreground">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <kbd className="bg-muted px-1.5 py-0.5 rounded-sm border border-border text-[10px] font-semibold">↑</kbd>
              <kbd className="bg-muted px-1.5 py-0.5 rounded-sm border border-border text-[10px] font-semibold">↓</kbd>
              <span>Navigate</span>
            </span>
            <span className="flex items-center gap-1">
              <kbd className="bg-muted px-1.5 py-0.5 rounded-sm border border-border text-[10px] font-semibold">↵</kbd>
              <span>Select</span>
            </span>
            <span className="flex items-center gap-1">
              <kbd className="bg-muted px-1.5 py-0.5 rounded-sm border border-border text-[10px] font-semibold">ESC</kbd>
              <span>Close</span>
            </span>
          </div>

          <span className="text-[10px] text-muted-foreground/60">
            HKRION Global Search
          </span>
        </div>
      </div>
    </div>
    </>,
    document.body
  );
}
