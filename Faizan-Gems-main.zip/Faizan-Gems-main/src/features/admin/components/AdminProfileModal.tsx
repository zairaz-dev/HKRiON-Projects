"use client";

import React, { useState, useEffect } from "react";
import { createPortal } from "react-dom";
import { AdminUser } from "../types";
import { useToast } from "@/components/ui/LuxuryToast";
import { SITE_CONFIG } from "@/lib/constants/site";

interface AdminProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  adminUser: AdminUser | null;
  onUpdateAdminUser: (user: AdminUser) => void;
}

export function AdminProfileModal({
  isOpen,
  onClose,
  adminUser,
  onUpdateAdminUser,
}: AdminProfileModalProps) {
  const { toast } = useToast();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");

  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [isSaving, setIsSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  // Sync state when modal opens or adminUser changes
  useEffect(() => {
    if (isOpen) {
      setName(adminUser?.name || "Admin");
      setEmail(adminUser?.email || SITE_CONFIG.contact.adminEmail);
      setPhone(adminUser?.phone || SITE_CONFIG.contact.phone);
      setIsChangingPassword(false);
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      setErrorMessage("");

      // Fetch latest profile details from database
      fetch("/api/admin/profile")
        .then((res) => (res.ok ? res.json() : null))
        .then((data) => {
          if (data?.user) {
            setName(data.user.name || "");
            setEmail(data.user.email || "");
            setPhone(data.user.phone || "");
          }
        })
        .catch(() => {});
    }
  }, [isOpen, adminUser]);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen && !isSaving) {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, isSaving, onClose]);

  if (!isOpen || !mounted) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");

    if (!name.trim()) {
      setErrorMessage("Please enter an administrator name.");
      return;
    }

    if (!email.trim() || !email.includes("@")) {
      setErrorMessage("Please enter a valid email address.");
      return;
    }

    if (isChangingPassword) {
      if (!currentPassword) {
        setErrorMessage("Please enter your current password to change credentials.");
        return;
      }
      if (newPassword.length < 6) {
        setErrorMessage("New password must be at least 6 characters long.");
        return;
      }
      if (newPassword !== confirmPassword) {
        setErrorMessage("New passwords do not match. Please verify.");
        return;
      }
    }

    setIsSaving(true);
    try {
      const res = await fetch("/api/admin/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim().toLowerCase(),
          phone: phone.trim(),
          currentPassword: isChangingPassword ? currentPassword : undefined,
          newPassword: isChangingPassword ? newPassword : undefined,
        }),
      });

      const data = await res.json();

      if (res.ok && data.success) {
        const updated: AdminUser = {
          name: data.user.name,
          email: data.user.email,
          phone: data.user.phone,
          role: data.user.role,
        };
        onUpdateAdminUser(updated);
        toast.success(
          "Profile Updated",
          "Administrator details and credentials have been updated."
        );
        onClose();
      } else {
        setErrorMessage(data.error || "Failed to update admin profile.");
      }
    } catch {
      setErrorMessage("Network error: Failed to communicate with server.");
    } finally {
      setIsSaving(false);
    }
  };

  const initials = name
    ? name
        .split(" ")
        .map((p) => p[0])
        .join("")
        .toUpperCase()
        .slice(0, 2)
    : "AD";

  return createPortal(
    <div
      className="fixed inset-0 z-[99999] flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-luxury-backdrop"
    >
      <div className="relative w-full max-w-lg bg-[#141419] border border-[#2A2A38] rounded-sm shadow-2xl overflow-hidden flex flex-col max-h-[90vh] my-auto animate-luxury-modal">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#24242C] bg-[#16161D]">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#242430] to-[#181822] border border-[#C5A880] flex items-center justify-center text-[#C5A880] text-sm font-sans font-bold shadow-inner">
              {initials}
            </div>
            <div>
              <h2 className="font-sans text-lg text-white font-semibold tracking-tight">
                Administrator Profile
              </h2>
              <p className="text-xs text-[#A1A1AA] font-sans mt-0.5">
                Update account details, contact number, and credentials.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            disabled={isSaving}
            className="text-[#8C867D] hover:text-white p-1 rounded transition-colors disabled:opacity-50"
            title="Close modal"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Error Banner */}
          {errorMessage && (
            <div className="p-3 bg-red-950/40 border border-red-800/60 rounded-sm text-xs text-red-300 flex items-start gap-2 animate-in fade-in duration-150">
              <svg className="w-4 h-4 text-red-400 shrink-0 mt-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10" />
                <line x1="12" y1="8" x2="12" y2="12" />
                <line x1="12" y1="16" x2="12.01" y2="16" />
              </svg>
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Section 1: Administrator Details */}
          <div className="space-y-3.5">
            <div className="flex items-center justify-between pb-1 border-b border-[#22222B]">
              <span className="text-[10px] font-mono text-[#C5A880] uppercase tracking-wider">
                Account Information
              </span>
              <span className="text-[9px] font-mono uppercase bg-[#1E1E26] text-[#A29F96] border border-[#2D2D38] px-2 py-0.5 rounded">
                Full Administrator
              </span>
            </div>

            {/* Name Field */}
            <div>
              <label className="block text-xs font-sans text-[#A29F96] mb-1.5">
                Admin Name <span className="text-[#C5A880]">*</span>
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Chief Administrator"
                required
                className="w-full bg-[#181820] border border-[#282834] focus:border-[#C5A880] text-xs text-white px-3.5 py-2.5 rounded-sm outline-none transition-colors placeholder-[#55524B]"
              />
            </div>

            {/* Email Field */}
            <div>
              <label className="block text-xs font-sans text-[#A29F96] mb-1.5">
                Admin Email <span className="text-[#C5A880]">*</span>
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={SITE_CONFIG.contact.adminEmail}
                required
                className="w-full bg-[#181820] border border-[#282834] focus:border-[#C5A880] text-xs text-white px-3.5 py-2.5 rounded-sm outline-none transition-colors placeholder-[#55524B] font-mono tabular-nums"
              />
            </div>

            {/* Phone Field */}
            <div>
              <label className="block text-xs font-sans text-[#A29F96] mb-1.5">
                Contact Phone
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+41 22 700 8900"
                className="w-full bg-[#181820] border border-[#282834] focus:border-[#C5A880] text-xs text-white px-3.5 py-2.5 rounded-sm outline-none transition-colors placeholder-[#55524B] font-mono tabular-nums"
              />
            </div>
          </div>

          {/* Section 2: Security & Password */}
          <div className="space-y-3.5 pt-2 border-t border-[#22222B]">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono text-[#C5A880] uppercase tracking-wider">
                Security & Password
              </span>
              <button
                type="button"
                onClick={() => {
                  setIsChangingPassword(!isChangingPassword);
                  setErrorMessage("");
                }}
                className="text-[11px] font-sans text-[#C5A880] hover:text-[#E0CFA9] transition-colors"
              >
                {isChangingPassword ? "Cancel Password Change" : "+ Change Password"}
              </button>
            </div>

            {isChangingPassword && (
              <div className="bg-[#181820] border border-[#282834] p-4 rounded-sm space-y-3 animate-in fade-in duration-150">
                {/* Current Password */}
                <div>
                  <label className="block text-xs font-sans text-[#A29F96] mb-1.5">
                    Current Password <span className="text-[#C5A880]">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showCurrentPassword ? "text" : "password"}
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      placeholder="Enter current password"
                      className="w-full bg-[#141419] border border-[#282834] focus:border-[#C5A880] text-xs text-white px-3.5 py-2.5 pr-10 rounded-sm outline-none transition-colors font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8C867D] hover:text-white"
                      tabIndex={-1}
                    >
                      {showCurrentPassword ? (
                        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
                          <line x1="1" y1="1" x2="23" y2="23" />
                        </svg>
                      ) : (
                        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                          <circle cx="12" cy="12" r="3" />
                        </svg>
                      )}
                    </button>
                  </div>
                </div>

                {/* New Password */}
                <div>
                  <label className="block text-xs font-sans text-[#A29F96] mb-1.5">
                    New Password (minimum 6 characters) <span className="text-[#C5A880]">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showNewPassword ? "text" : "password"}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Enter new password"
                      className="w-full bg-[#141419] border border-[#282834] focus:border-[#C5A880] text-xs text-white px-3.5 py-2.5 pr-10 rounded-sm outline-none transition-colors font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8C867D] hover:text-white"
                      tabIndex={-1}
                    >
                      {showNewPassword ? (
                        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
                          <line x1="1" y1="1" x2="23" y2="23" />
                        </svg>
                      ) : (
                        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                          <circle cx="12" cy="12" r="3" />
                        </svg>
                      )}
                    </button>
                  </div>
                </div>

                {/* Confirm New Password */}
                <div>
                  <label className="block text-xs font-sans text-[#A29F96] mb-1.5">
                    Confirm New Password <span className="text-[#C5A880]">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showConfirmPassword ? "text" : "password"}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Repeat new password"
                      className="w-full bg-[#141419] border border-[#282834] focus:border-[#C5A880] text-xs text-white px-3.5 py-2.5 pr-10 rounded-sm outline-none transition-colors font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8C867D] hover:text-white"
                      tabIndex={-1}
                    >
                      {showConfirmPassword ? (
                        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
                          <line x1="1" y1="1" x2="23" y2="23" />
                        </svg>
                      ) : (
                        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                          <circle cx="12" cy="12" r="3" />
                        </svg>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Modal Footer */}
          <div className="pt-4 border-t border-[#24242C] flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={isSaving}
              className="px-4 py-2 text-xs font-sans text-[#8C867D] hover:text-white hover:bg-[#181820] rounded-sm transition-colors disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-5 py-2 text-xs font-sans font-medium text-[#0D0D11] bg-[#C5A880] hover:bg-[#D4BB95] rounded-sm shadow-md transition-all flex items-center gap-2 btn-luxury-press disabled:opacity-50"
            >
              {isSaving && (
                <svg className="w-3.5 h-3.5 animate-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
              )}
              <span>{isSaving ? "Saving..." : "Save Profile"}</span>
            </button>
          </div>
        </form>
      </div>
    </div>,
    document.body
  );
}
