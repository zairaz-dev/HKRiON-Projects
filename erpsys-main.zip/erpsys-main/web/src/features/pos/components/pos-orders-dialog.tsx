"use client";

import React, { useState, useEffect } from "react";
import { Dialog } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useSalesQuery } from "../hooks/use-pos";
import { useQuotationsQuery } from "@/features/quotations/hooks/use-quotations";
import { QuotationItem } from "@/features/quotations/types";
import { useCurrency } from "@/hooks/use-currency";
import {
  Search,
  ShoppingCart,
  Trash2,
  Clock,
  FileText,
  CheckCircle2,
  User,
  Package,
  Loader2,
  Printer,
  Eye,
  CreditCard,
  Calendar,
  Layers,
  Pencil,
} from "lucide-react";
import { cn } from "@/lib/utils";

export type POSOrdersTab = "HOLD" | "QUOTATION" | "FINAL";

interface POSOrdersDialogProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: POSOrdersTab;
  businessId: string;
  branchId: string;
  // Hold Bill Actions
  onResumeHoldBill: (sale: any) => void;
  onDeleteHoldBill: (saleId: string) => void;
  isDeletingHold?: boolean;
  // Quotation Actions
  onResumeQuotation: (quotation: QuotationItem) => void;
  onPreviewQuotation: (quotation: QuotationItem) => void;
  onDeleteQuotation: (id: string, number: string) => void;
  isDeletingQuotation?: boolean;
  // Final Sales Actions
  onViewReceipt: (sale: any) => void;
  onEditSale?: (sale: any) => void;
  onDeleteFinalSale?: (saleId: string, invoiceNumber: string) => void;
}

export function POSOrdersDialog({
  isOpen,
  onClose,
  initialTab = "HOLD",
  businessId,
  branchId,
  onResumeHoldBill,
  onDeleteHoldBill,
  isDeletingHold = false,
  onResumeQuotation,
  onPreviewQuotation,
  onDeleteQuotation,
  isDeletingQuotation = false,
  onViewReceipt,
  onEditSale,
  onDeleteFinalSale,
}: POSOrdersDialogProps) {
  const { format } = useCurrency(businessId);
  const [activeTab, setActiveTab] = useState<POSOrdersTab>(initialTab);
  const [searchQuery, setSearchQuery] = useState("");

  // Sync tab when initialTab changes on open
  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
      setSearchQuery("");
    }
  }, [isOpen, initialTab]);

  // 1. Fetch Hold Bills (Last 20)
  const { data: holdSalesResponse, isLoading: isLoadingHold } = useSalesQuery(
    businessId,
    {
      branchId: branchId || undefined,
      status: "HOLD",
      limit: 20,
    },
    { enabled: isOpen && !!branchId }
  );
  const holdSales = (holdSalesResponse?.data || []).slice(0, 20);

  // 2. Fetch Quotations (Last 20)
  const { data: quotationsResponse, isLoading: isLoadingQuotations } = useQuotationsQuery(
    {
      branchId: branchId || undefined,
      status: "PENDING",
      limit: 20,
    },
    { enabled: isOpen && !!branchId }
  );
  const quotations = (quotationsResponse?.data || []).slice(0, 20);

  // 3. Fetch Final Sales (Last 20 completed invoices)
  const { data: finalSalesResponse, isLoading: isLoadingFinal } = useSalesQuery(
    businessId,
    {
      branchId: branchId || undefined,
      status: "FINAL",
      limit: 20,
    },
    { enabled: isOpen && !!branchId }
  );
  const finalSales = (finalSalesResponse?.data || []).slice(0, 20);

  // Filtering for active tab (strictly last 20)
  const filteredHoldSales = React.useMemo(() => {
    const list = holdSales.slice(0, 20);
    if (!searchQuery.trim()) return list;
    const q = searchQuery.toLowerCase();
    return list.filter((s: any) => {
      const invMatch = s.invoiceNumber?.toLowerCase().includes(q);
      const custMatch = s.customer?.name?.toLowerCase().includes(q);
      const phoneMatch = s.customer?.phone?.toLowerCase().includes(q);
      return invMatch || custMatch || phoneMatch;
    });
  }, [holdSales, searchQuery]);

  const filteredQuotations = React.useMemo(() => {
    const list = quotations.slice(0, 20);
    if (!searchQuery.trim()) return list;
    const q = searchQuery.toLowerCase();
    return list.filter((item) => {
      const numMatch = item.quotationNumber?.toLowerCase().includes(q);
      const custMatch = item.customer?.name?.toLowerCase().includes(q);
      const phoneMatch = item.customer?.phone?.toLowerCase().includes(q);
      return numMatch || custMatch || phoneMatch;
    });
  }, [quotations, searchQuery]);

  const filteredFinalSales = React.useMemo(() => {
    const list = finalSales.slice(0, 20);
    if (!searchQuery.trim()) return list;
    const q = searchQuery.toLowerCase();
    return list.filter((s: any) => {
      const invMatch = s.invoiceNumber?.toLowerCase().includes(q);
      const custMatch = s.customer?.name?.toLowerCase().includes(q);
      const phoneMatch = s.customer?.phone?.toLowerCase().includes(q);
      return invMatch || custMatch || phoneMatch;
    });
  }, [finalSales, searchQuery]);

  return (
    <Dialog isOpen={isOpen} onClose={onClose} title="Recent Transactions" size="4xl">
      <div className="space-y-4 py-1">
        {/* Navigation Tabs Header */}
        <div className="flex items-center gap-1.5 p-1 bg-muted/40 border border-border/80 rounded-sm">
          {/* Tab 1: Hold Bills */}
          <button
            type="button"
            onClick={() => {
              setActiveTab("HOLD");
              setSearchQuery("");
            }}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-2 px-3 text-xs font-bold rounded-sm transition-all select-none",
              activeTab === "HOLD"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground hover:bg-muted/30"
            )}
          >
            <Clock className={cn("h-3.5 w-3.5", activeTab === "HOLD" ? "text-primary-foreground" : "text-muted-foreground")} />
            <span>Hold Bills</span>
            <span
              className={cn(
                "ml-1 px-1.5 py-0.2 text-[10px] font-mono font-bold rounded-full",
                activeTab === "HOLD"
                  ? "bg-black/25 text-primary-foreground border border-black/15"
                  : "bg-muted text-muted-foreground"
              )}
            >
              {holdSales.length}
            </span>
          </button>

          {/* Tab 2: Quotations */}
          <button
            type="button"
            onClick={() => {
              setActiveTab("QUOTATION");
              setSearchQuery("");
            }}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-2 px-3 text-xs font-bold rounded-sm transition-all select-none",
              activeTab === "QUOTATION"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground hover:bg-muted/30"
            )}
          >
            <FileText className={cn("h-3.5 w-3.5", activeTab === "QUOTATION" ? "text-primary-foreground" : "text-muted-foreground")} />
            <span>Quotations</span>
            <span
              className={cn(
                "ml-1 px-1.5 py-0.2 text-[10px] font-mono font-bold rounded-full",
                activeTab === "QUOTATION"
                  ? "bg-black/25 text-primary-foreground border border-black/15"
                  : "bg-muted text-muted-foreground"
              )}
            >
              {quotations.length}
            </span>
          </button>

          {/* Tab 3: Final Sales */}
          <button
            type="button"
            onClick={() => {
              setActiveTab("FINAL");
              setSearchQuery("");
            }}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-2 px-3 text-xs font-bold rounded-sm transition-all select-none",
              activeTab === "FINAL"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground hover:bg-muted/30"
            )}
          >
            <CheckCircle2 className={cn("h-3.5 w-3.5", activeTab === "FINAL" ? "text-primary-foreground" : "text-muted-foreground")} />
            <span>Final Sales</span>
            <span
              className={cn(
                "ml-1 px-1.5 py-0.2 text-[10px] font-mono font-bold rounded-full",
                activeTab === "FINAL"
                  ? "bg-black/25 text-primary-foreground border border-black/15"
                  : "bg-muted text-muted-foreground"
              )}
            >
              {finalSales.length}
            </span>
          </button>
        </div>

        {/* Search Input Bar */}
        <div className="flex items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder={
                activeTab === "HOLD"
                  ? "Search by Bill No or Customer..."
                  : activeTab === "QUOTATION"
                  ? "Search by Quotation No or Customer..."
                  : "Search completed invoice by Invoice No or Customer..."
              }
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 h-9 text-xs bg-background/50 border border-input rounded-sm"
            />
          </div>

          <div className="text-xs font-semibold text-muted-foreground whitespace-nowrap px-2">
            {activeTab === "HOLD" && (
              <>Total on Hold: <strong className="text-foreground">{holdSales.length}</strong></>
            )}
            {activeTab === "QUOTATION" && (
              <>Active Quotes: <strong className="text-foreground">{quotations.length}</strong></>
            )}
            {activeTab === "FINAL" && (
              <>Recent Invoices: <strong className="text-foreground">{finalSales.length}</strong></>
            )}
          </div>
        </div>

        {/* Tab Content Body - Fixed 5 rows height so dialog doesn't jump on tab change */}
        <div className="h-[370px] overflow-y-auto space-y-2 pr-1">
          {/* TAB 1: HOLD BILLS */}
          {activeTab === "HOLD" && (
            isLoadingHold ? (
              <div className="h-full min-h-[350px] flex flex-col items-center justify-center text-muted-foreground gap-2">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
                <span className="text-xs">Loading hold bills...</span>
              </div>
            ) : filteredHoldSales.length === 0 ? (
              <div className="h-full min-h-[350px] flex flex-col items-center justify-center text-muted-foreground border border-dashed border-border/80 rounded-sm bg-background/20 gap-2 p-6">
                <Clock className="h-8 w-8 text-muted-foreground/50 mb-1" />
                <span className="text-xs font-semibold text-foreground">No bills currently on hold</span>
                <span className="text-[11px] text-muted-foreground text-center">
                  When you click "Hold" in POS cart, the bill will appear here to resume anytime.
                </span>
              </div>
            ) : (
              filteredHoldSales.map((sale: any) => {
                const itemCount = sale.saleLines?.reduce((sum: number, l: any) => sum + l.quantity, 0) || 0;
                const formattedDate = new Date(sale.saleDate || sale.createdAt).toLocaleTimeString([], {
                  hour: "2-digit",
                  minute: "2-digit",
                });

                return (
                  <div
                    key={sale.id}
                    className="flex items-center justify-between p-3 min-h-[66px] bg-secondary/20 hover:bg-secondary/35 border border-border/60 hover:border-border rounded-sm transition-all gap-4"
                  >
                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-foreground text-xs tracking-wide">
                          {sale.invoiceNumber}
                        </span>
                        <span className="inline-flex items-center px-1.5 py-0.2 rounded-xs text-[10px] font-bold bg-amber-500/15 text-amber-500 border border-amber-500/20">
                          HELD
                        </span>
                        <span className="text-[10px] text-muted-foreground flex items-center gap-1 font-mono">
                          <Clock className="h-2.5 w-2.5" />
                          {formattedDate}
                        </span>
                      </div>

                      <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
                        <span className="flex items-center gap-1 text-foreground font-medium truncate">
                          <User className="h-3 w-3 text-primary shrink-0" />
                          {sale.customer?.name || "Walk-in Customer"}
                        </span>
                        <span className="flex items-center gap-1 font-mono text-[11px]">
                          <Package className="h-3 w-3 shrink-0" />
                          {itemCount} items
                        </span>
                        {sale.createdBy?.name && (
                          <span className="text-[10px] text-muted-foreground font-medium">
                            By: <strong className="text-foreground/90">{sale.createdBy.name}</strong>
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 shrink-0">
                      <div className="text-right pr-2">
                        <span className="font-mono font-bold text-sm text-emerald-400 block">
                          {format(sale.grandTotal)}
                        </span>
                        <span className="text-[10px] text-muted-foreground">Grand Total</span>
                      </div>

                      <Button
                        type="button"
                        size="sm"
                        onClick={() => onResumeHoldBill(sale)}
                        className="h-8 px-3 text-xs font-bold bg-emerald-500 text-black hover:bg-emerald-400 flex items-center gap-1 rounded-sm shadow-sm"
                        title="Resume into active POS cart"
                      >
                        <ShoppingCart className="h-3.5 w-3.5" />
                        Resume
                      </Button>

                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        disabled={isDeletingHold}
                        onClick={() => onDeleteHoldBill(sale.id)}
                        className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-sm"
                        title="Delete Hold Bill"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                );
              })
            )
          )}

          {/* TAB 2: QUOTATIONS */}
          {activeTab === "QUOTATION" && (
            isLoadingQuotations ? (
              <div className="h-full min-h-[350px] flex flex-col items-center justify-center text-muted-foreground gap-2">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
                <span className="text-xs">Loading quotations...</span>
              </div>
            ) : filteredQuotations.length === 0 ? (
              <div className="h-full min-h-[350px] flex flex-col items-center justify-center text-muted-foreground border border-dashed border-border/80 rounded-sm bg-background/20 gap-2 p-6">
                <FileText className="h-8 w-8 text-muted-foreground/50 mb-1" />
                <span className="text-xs font-semibold text-foreground">No active quotations found</span>
                <span className="text-[11px] text-muted-foreground text-center">
                  When you click "Quote" in POS cart, the price estimate will appear here to resume anytime.
                </span>
              </div>
            ) : (
              filteredQuotations.map((item) => {
                const itemCount = item.quotationLines?.reduce((sum, l) => sum + l.quantity, 0) || 0;
                const dateStr = new Date(item.date).toLocaleDateString();

                return (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-3 min-h-[66px] bg-secondary/20 hover:bg-secondary/35 border border-border/60 hover:border-border rounded-sm transition-all gap-4"
                  >
                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-primary text-xs tracking-wide">
                          {item.quotationNumber}
                        </span>
                        <span className="text-[10px] text-muted-foreground font-mono">{dateStr}</span>
                        {item.expiryDate && (
                          <span className="text-[10px] text-amber-400 font-mono">
                            (Valid till {new Date(item.expiryDate).toLocaleDateString()})
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
                        <span className="flex items-center gap-1 text-foreground font-medium truncate">
                          <User className="h-3 w-3 text-primary shrink-0" />
                          {item.customer?.name || "Walk-in Customer"}
                        </span>
                        <span className="flex items-center gap-1 font-mono text-[11px]">
                          <Package className="h-3 w-3 shrink-0" />
                          {itemCount} items
                        </span>
                        {item.createdBy?.name && (
                          <span className="text-[10px] text-muted-foreground font-medium">
                            By: <strong className="text-foreground/90">{item.createdBy.name}</strong>
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 shrink-0">
                      <div className="text-right pr-2">
                        <span className="font-mono font-bold text-sm text-foreground block">
                          {format(item.grandTotal)}
                        </span>
                        <span className="text-[10px] text-muted-foreground uppercase">Estimated</span>
                      </div>

                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => onPreviewQuotation(item)}
                        className="h-8 px-2.5 text-xs flex items-center gap-1 rounded-sm border-border hover:bg-secondary"
                        title="View & Print Quotation"
                      >
                        <Eye className="h-3.5 w-3.5" />
                      </Button>

                      <Button
                        type="button"
                        size="sm"
                        onClick={() => onResumeQuotation(item)}
                        className="h-8 px-3 text-xs font-bold bg-primary text-black hover:bg-primary/90 flex items-center gap-1 rounded-sm shadow-sm"
                        title="Resume this quotation in active POS cart"
                      >
                        <ShoppingCart className="h-3.5 w-3.5" />
                        Resume
                      </Button>

                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        disabled={isDeletingQuotation}
                        onClick={() => onDeleteQuotation(item.id, item.quotationNumber)}
                        className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-sm"
                        title="Delete Quotation"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                );
              })
            )
          )}

          {/* TAB 3: FINAL SALES (RECENT COMPLETED INVOICES) */}
          {activeTab === "FINAL" && (
            isLoadingFinal ? (
              <div className="h-full min-h-[350px] flex flex-col items-center justify-center text-muted-foreground gap-2">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
                <span className="text-xs">Loading completed sales...</span>
              </div>
            ) : filteredFinalSales.length === 0 ? (
              <div className="h-full min-h-[350px] flex flex-col items-center justify-center text-muted-foreground border border-dashed border-border/80 rounded-sm bg-background/20 gap-2 p-6">
                <CheckCircle2 className="h-8 w-8 text-muted-foreground/50 mb-1" />
                <span className="text-xs font-semibold text-foreground">No completed sales yet</span>
                <span className="text-[11px] text-muted-foreground text-center">
                  Completed customer billing invoices for this branch will show here for instant reprint.
                </span>
              </div>
            ) : (
              filteredFinalSales.map((sale: any) => {
                const itemCount = sale.saleLines?.reduce((sum: number, l: any) => sum + l.quantity, 0) || 0;
                const saleTime = new Date(sale.saleDate || sale.createdAt).toLocaleTimeString([], {
                  hour: "2-digit",
                  minute: "2-digit",
                });
                const saleDate = new Date(sale.saleDate || sale.createdAt).toLocaleDateString();

                return (
                  <div
                    key={sale.id}
                    className="flex items-center justify-between p-3 min-h-[66px] bg-secondary/20 hover:bg-secondary/35 border border-border/60 hover:border-border rounded-sm transition-all gap-4"
                  >
                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-foreground text-xs tracking-wide">
                          {sale.invoiceNumber}
                        </span>
                        <span className="inline-flex items-center px-1.5 py-0.2 rounded-xs text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">
                          PAID
                        </span>
                        <span className="text-[10px] text-muted-foreground font-mono">
                          {saleDate} {saleTime}
                        </span>
                      </div>

                      <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
                        <span className="flex items-center gap-1 text-foreground font-medium truncate">
                          <User className="h-3 w-3 text-primary shrink-0" />
                          {sale.customer?.name || "Walk-in Customer"}
                        </span>
                        <span className="flex items-center gap-1 font-mono text-[11px]">
                          <Package className="h-3 w-3 shrink-0" />
                          {itemCount} items
                        </span>
                        {sale.createdBy?.name && (
                          <span className="text-[10px] text-muted-foreground font-medium">
                            By: <strong className="text-foreground/90">{sale.createdBy.name}</strong>
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 shrink-0">
                      <div className="text-right pr-2">
                        <span className="font-mono font-bold text-sm text-foreground block">
                          {format(sale.grandTotal)}
                        </span>
                        <span className="text-[10px] text-emerald-400 font-semibold">Completed</span>
                      </div>

                      {/* Edit Sale */}
                      {onEditSale && (
                        <Button
                          type="button"
                          size="sm"
                          onClick={() => {
                            onClose();
                            onEditSale(sale);
                          }}
                          className="h-8 px-2.5 text-xs font-bold bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-500 flex items-center gap-1.5 rounded-sm shadow-sm"
                          title="Edit this invoice in POS"
                        >
                          <Pencil className="h-3.5 w-3.5 text-amber-500" />
                          Edit
                        </Button>
                      )}

                      {/* View & Reprint Receipt */}
                      <Button
                        type="button"
                        size="sm"
                        onClick={() => onViewReceipt(sale)}
                        className="h-8 px-3 text-xs font-bold bg-secondary hover:bg-secondary/80 border border-border text-foreground flex items-center gap-1.5 rounded-sm shadow-sm"
                        title="View and Print Receipt"
                      >
                        <Printer className="h-3.5 w-3.5 text-primary" />
                        Print
                      </Button>

                      {/* Delete Sale */}
                      {onDeleteFinalSale && (
                        <Button
                          type="button"
                          size="sm"
                          onClick={() => onDeleteFinalSale(sale.id, sale.invoiceNumber)}
                          className="h-8 px-2 text-xs font-bold bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-500 flex items-center gap-1 rounded-sm shadow-sm"
                          title="Delete this invoice and restore inventory"
                        >
                          <Trash2 className="h-3.5 w-3.5 text-rose-500" />
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })
            )
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-border/80 text-xs text-muted-foreground">
          <span>
            {activeTab === "HOLD" && "Clicking Resume loads held items into your active POS cart."}
            {activeTab === "QUOTATION" && "Clicking Resume loads quotation items into cart to complete checkout."}
            {activeTab === "FINAL" && "Clicking Print opens the receipt preview for immediate printing."}
          </span>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={onClose}
            className="h-8 text-xs font-semibold rounded-sm"
          >
            Close
          </Button>
        </div>
      </div>
    </Dialog>
  );
}
