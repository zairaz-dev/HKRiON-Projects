import { db } from "@/core/db/client";
import { SiteSettingsData, defaultSiteSettings } from "@/types/settings";

export { defaultSiteSettings };
export type { SiteSettingsData };

export class SettingsService {
  /**
   * Retrieves global site settings from DB with fallback to defaultSiteSettings
   */
  static async getSettings(): Promise<SiteSettingsData> {
    try {
      if ((db as any).siteSettings) {
        const found = await (db as any).siteSettings.findUnique({
          where: { id: "settings_default" },
        });
        if (found) return found as SiteSettingsData;

        const created = await (db as any).siteSettings.create({
          data: defaultSiteSettings,
        });
        return created as SiteSettingsData;
      }
    } catch {
      // Fallback through raw query
    }

    try {
      const rawRows: any = await db.$queryRaw`SELECT * FROM site_settings WHERE id = 'settings_default' LIMIT 1`;
      if (Array.isArray(rawRows) && rawRows.length > 0) {
        return rawRows[0] as SiteSettingsData;
      }
    } catch {
      // Table may not yet be initialized
    }

    return defaultSiteSettings;
  }

  /**
   * Updates global site settings
   */
  static async updateSettings(data: Partial<SiteSettingsData>): Promise<SiteSettingsData> {
    const current = await this.getSettings();
    const updated: SiteSettingsData = {
      ...current,
      ...data,
      id: "settings_default",
      updatedAt: new Date().toISOString(),
    };

    try {
      if ((db as any).siteSettings) {
        await (db as any).siteSettings.upsert({
          where: { id: "settings_default" },
          update: {
            ...data,
            updatedAt: new Date(),
          },
          create: {
            ...updated,
            updatedAt: new Date(),
          },
        });
      } else {
        await db.$executeRaw`
          INSERT INTO site_settings (
            id, companyName, tagline, establishedYear, currencySymbol,
            phone, email, address, workingHours,
            instagram, facebook, linkedin, tiktok, whatsapp, youtube, twitter,
            metaTitle, metaDescription, updatedAt
          ) VALUES (
            'settings_default',
            ${updated.companyName}, ${updated.tagline}, ${updated.establishedYear}, ${updated.currencySymbol},
            ${updated.phone}, ${updated.email}, ${updated.address}, ${updated.workingHours},
            ${updated.instagram}, ${updated.facebook}, ${updated.linkedin}, ${updated.tiktok}, ${updated.whatsapp}, ${updated.youtube}, ${updated.twitter},
            ${updated.metaTitle}, ${updated.metaDescription}, CURRENT_TIMESTAMP
          )
          ON CONFLICT(id) DO UPDATE SET
            companyName = excluded.companyName,
            tagline = excluded.tagline,
            establishedYear = excluded.establishedYear,
            currencySymbol = excluded.currencySymbol,
            phone = excluded.phone,
            email = excluded.email,
            address = excluded.address,
            workingHours = excluded.workingHours,
            instagram = excluded.instagram,
            facebook = excluded.facebook,
            linkedin = excluded.linkedin,
            tiktok = excluded.tiktok,
            whatsapp = excluded.whatsapp,
            youtube = excluded.youtube,
            twitter = excluded.twitter,
            metaTitle = excluded.metaTitle,
            metaDescription = excluded.metaDescription,
            updatedAt = CURRENT_TIMESTAMP;
        `;
      }
    } catch (e) {
      console.warn("Could not execute direct SQLite upsert for site_settings:", e);
    }

    return updated;
  }

  /**
   * Helper to format a WhatsApp string into a valid web URL
   */
  static formatWhatsAppUrl(input: string): string {
    if (!input || !input.trim()) return "";
    const clean = input.trim();
    if (clean.startsWith("http://") || clean.startsWith("https://")) {
      return clean;
    }
    const digitsOnly = clean.replace(/\D/g, "");
    if (!digitsOnly) return "";
    return `https://wa.me/${digitsOnly}`;
  }
}
