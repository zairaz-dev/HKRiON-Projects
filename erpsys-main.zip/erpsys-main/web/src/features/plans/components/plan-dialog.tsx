"use strict";
"use client";

import React, { useState, useEffect } from 'react';
import { Plan } from '../../subscriptions/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { X, Loader2, Sparkles, Shield, Lock } from 'lucide-react';
import { subscriptionService } from '@/services/subscription-service';
import { authService } from '@/services/auth-service';
import { useQueryClient } from '@tanstack/react-query';
import { queryKeys } from '@/lib/query-keys';

interface PlanDialogProps {
  plan?: Plan | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  defaultCustom?: boolean;
}

export function PlanDialog({ plan, isOpen, onClose, onSuccess, defaultCustom = false }: PlanDialogProps) {
  const isEdit = !!plan;

  const [name, setName] = useState('');
  const [slug, setSlug] = useState('');
  const [description, setDescription] = useState('');
  const [priceMonthly, setPriceMonthly] = useState<number | string>(499);
  const [priceYearly, setPriceYearly] = useState<number | string>(4999);
  const [priceMonthlyUsd, setPriceMonthlyUsd] = useState<number | string>(2);
  const [priceYearlyUsd, setPriceYearlyUsd] = useState<number | string>(20);
  const [trialDays, setTrialDays] = useState<number>(0);
  const [maxBranches, setMaxBranches] = useState<number>(1);
  const [maxUsers, setMaxUsers] = useState<number>(2);
  const [maxProducts, setMaxProducts] = useState<number>(500);
  const [maxInvoicesMonthly, setMaxInvoicesMonthly] = useState<number>(200);

  const [enablePos, setEnablePos] = useState(true);
  const [enableImei, setEnableImei] = useState(false);
  const [enableAccounting, setEnableAccounting] = useState(false);
  const [enableSms, setEnableSms] = useState(false);
  const [enableApiAccess, setEnableApiAccess] = useState(false);
  const [isActive, setIsActive] = useState(true);
  const [isPopular, setIsPopular] = useState(false);
  const [isCustom, setIsCustom] = useState(false);
  const [businessId, setBusinessId] = useState('');
  const [businesses, setBusinesses] = useState<any[]>([]);
  const [isBusinessesLoading, setIsBusinessesLoading] = useState(false);
  const [sortOrder, setSortOrder] = useState<number>(1);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const queryClient = useQueryClient();

  useEffect(() => {
    if (isOpen) {
      setIsBusinessesLoading(true);
      authService
        .getBusinesses()
        .then((res) => {
          if (Array.isArray(res)) setBusinesses(res);
        })
        .catch((err) => console.error('Failed to load businesses', err))
        .finally(() => setIsBusinessesLoading(false));
    }
  }, [isOpen]);

  useEffect(() => {
    if (plan) {
      setName(plan.name);
      setSlug(plan.slug);
      setDescription(plan.description || '');
      setPriceMonthly(plan.priceMonthly);
      setPriceYearly(plan.priceYearly);
      setPriceMonthlyUsd(plan.priceMonthlyUsd || 0);
      setPriceYearlyUsd(plan.priceYearlyUsd || 0);
      setTrialDays(plan.trialDays || 0);
      setMaxBranches(plan.maxBranches);
      setMaxUsers(plan.maxUsers);
      setMaxProducts(plan.maxProducts);
      setMaxInvoicesMonthly(plan.maxInvoicesMonthly);
      setEnablePos(plan.enablePos);
      setEnableImei(plan.enableImei);
      setEnableAccounting(plan.enableAccounting);
      setEnableSms(plan.enableSms);
      setEnableApiAccess(plan.enableApiAccess);
      setIsActive(plan.isActive);
      setIsPopular(plan.isPopular);
      setIsCustom(plan.isCustom || false);
      setBusinessId(plan.businessId || '');
      setSortOrder(plan.sortOrder || 1);
    } else {
      setName('');
      setSlug('');
      setDescription('');
      setPriceMonthly(499);
      setPriceYearly(4999);
      setPriceMonthlyUsd(2);
      setPriceYearlyUsd(20);
      setTrialDays(0);
      setMaxBranches(1);
      setMaxUsers(2);
      setMaxProducts(500);
      setMaxInvoicesMonthly(200);
      setEnablePos(true);
      setEnableImei(false);
      setEnableAccounting(false);
      setEnableSms(false);
      setEnableApiAccess(false);
      setIsActive(true);
      setIsPopular(false);
      setIsCustom(defaultCustom || false);
      setBusinessId('');
      setSortOrder(1);
    }
    setError('');
  }, [plan, isOpen, defaultCustom]);

  const isDefaultPlan = ['trial', 'starter', 'pro', 'business', 'enterprise'].includes((plan?.slug || slug).toLowerCase().trim());
  const isEnterprise = (plan?.slug || slug).toLowerCase().trim() === 'enterprise';

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !slug.trim()) {
      setError('Please provide a plan name and slug.');
      return;
    }

    if (isCustom && !businessId) {
      setError('Please select a client business for this custom dedicated enterprise plan.');
      return;
    }

    setLoading(true);
    setError('');

    const payload: any = {
      name,
      slug: slug.toLowerCase().trim(),
      description,
      priceMonthly: isEnterprise ? 0 : (Number(priceMonthly) || 0),
      priceYearly: isEnterprise ? 0 : (Number(priceYearly) || 0),
      priceMonthlyUsd: isEnterprise ? 0 : (Number(priceMonthlyUsd) || 0),
      priceYearlyUsd: isEnterprise ? 0 : (Number(priceYearlyUsd) || 0),
      currency: 'LKR',
      trialDays: Number(trialDays),
      maxBranches: Number(maxBranches),
      maxUsers: Number(maxUsers),
      maxProducts: Number(maxProducts),
      maxInvoicesMonthly: Number(maxInvoicesMonthly),
      enablePos,
      enableImei,
      enableAccounting,
      enableSms,
      enableApiAccess,
      isActive,
      isPopular,
      isCustom,
      businessId: isCustom ? businessId : null,
      sortOrder: Number(sortOrder),
    };

    try {
      if (isEdit && plan) {
        await subscriptionService.updatePlan(plan.id, payload);
      } else {
        await subscriptionService.createPlan(payload);
      }
      await queryClient.invalidateQueries({ queryKey: queryKeys.plans.all });
      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save plan.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-2xl bg-card border border-border rounded-sm overflow-hidden shadow-2xl relative max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border bg-background/50">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            <h3 className="text-sm font-bold text-foreground tracking-wider uppercase font-mono">
              {isEdit ? `Edit Plan: ${plan.name}` : 'Create New SaaS Plan'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-5">
          {error && (
            <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 p-3 rounded-sm text-xs">
              {error}
            </div>
          )}

          {/* Basic Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono">
                Plan Name *
              </label>
              <Input
                required
                placeholder="e.g. Starter Plan"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  if (!isEdit) {
                    setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9]/g, '-'));
                  }
                }}
                className="h-9 text-xs"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono">
                Unique Slug *
              </label>
              <Input
                required
                placeholder="e.g. starter"
                value={slug}
                disabled={isEdit && isDefaultPlan}
                onChange={(e) => setSlug(e.target.value)}
                className="h-9 text-xs font-mono disabled:opacity-60"
              />
              {isEdit && isDefaultPlan && (
                <p className="text-[10px] text-muted-foreground font-mono flex items-center gap-1 mt-0.5">
                  <Lock className="w-2.5 h-2.5" /> Slug is locked for core system default plans.
                </p>
              )}
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono">
              Description
            </label>
            <Input
              placeholder="Brief summary of who this plan is for..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="h-9 text-xs"
            />
          </div>

          {/* Pricing Details */}
          <div className="border-t border-border/60 pt-4 space-y-4">
            <div>
              <h4 className="text-xs font-bold text-foreground font-mono uppercase">
                Pricing & Trial
              </h4>
              <p className="text-[11px] text-muted-foreground">
                Set individual pricing in Sri Lankan Rupees (LKR) and US Dollars (USD).
              </p>
            </div>

            {isEnterprise ? (
              <div className="bg-primary/5 border border-primary/20 rounded-sm p-4 text-center space-y-1.5 animate-fadeIn">
                <div className="text-xs font-bold text-primary font-mono flex items-center justify-center gap-1.5">
                  <Shield className="w-4 h-4" /> Enterprise Custom Pricing (Contact Sales)
                </div>
                <p className="text-[11px] text-muted-foreground max-w-md mx-auto leading-relaxed">
                  Fixed price settings are disabled for the Enterprise Plan. This package is configured as <strong>Custom Quote</strong> on public pricing cards and directs clients to sales for custom enterprise onboarding.
                </p>
              </div>
            ) : (
              <>
                {/* LKR Pricing */}
                <div className="bg-muted/30 border border-border/50 rounded-sm p-3 space-y-2">
                  <div className="text-[11px] font-bold text-primary font-mono flex items-center gap-1.5">
                    <span>🇱🇰</span> Sri Lankan Rupee Pricing (LKR / Rs.)
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono">
                        Monthly Price (Rs. LKR)
                      </label>
                      <Input
                        type="number"
                        step="any"
                        min="0"
                        required
                        value={priceMonthly}
                        onChange={(e) => setPriceMonthly(e.target.value)}
                        className="h-8 text-xs font-mono"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono">
                        Yearly Price (Rs. LKR)
                      </label>
                      <Input
                        type="number"
                        step="any"
                        min="0"
                        required
                        value={priceYearly}
                        onChange={(e) => setPriceYearly(e.target.value)}
                        className="h-8 text-xs font-mono"
                      />
                    </div>
                  </div>
                </div>

                {/* USD Pricing */}
                <div className="bg-muted/30 border border-border/50 rounded-sm p-3 space-y-2">
                  <div className="text-[11px] font-bold text-primary font-mono flex items-center gap-1.5">
                    <span>🌐</span> International Pricing (USD / $)
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono">
                        Monthly Price ($ USD)
                      </label>
                      <Input
                        type="number"
                        step="0.01"
                        min="0"
                        required
                        value={priceMonthlyUsd}
                        onChange={(e) => setPriceMonthlyUsd(e.target.value)}
                        placeholder="e.g. 2.99"
                        className="h-8 text-xs font-mono"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono">
                        Yearly Price ($ USD)
                      </label>
                      <Input
                        type="number"
                        step="0.01"
                        min="0"
                        required
                        value={priceYearlyUsd}
                        onChange={(e) => setPriceYearlyUsd(e.target.value)}
                        placeholder="e.g. 29.99"
                        className="h-8 text-xs font-mono"
                      />
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* Trial Days */}
            <div className="space-y-1 max-w-xs">
              <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono">
                Trial Days (0 if none)
              </label>
              <Input
                type="number"
                min="0"
                value={trialDays}
                onChange={(e) => setTrialDays(Number(e.target.value))}
                className="h-8 text-xs font-mono"
              />
            </div>
          </div>

          {/* Resource Limits */}
          <div className="border-t border-border/60 pt-4">
            <h4 className="text-xs font-bold text-foreground font-mono uppercase mb-1">
              Resource Limits (-1 for Unlimited)
            </h4>
            <p className="text-[11px] text-muted-foreground mb-3">
              Specify maximum allowed quotas per organization on this plan.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono">
                  Max Branches
                </label>
                <Input
                  type="number"
                  required
                  value={maxBranches}
                  onChange={(e) => setMaxBranches(Number(e.target.value))}
                  className="h-9 text-xs font-mono"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono">
                  Max Users
                </label>
                <Input
                  type="number"
                  required
                  value={maxUsers}
                  onChange={(e) => setMaxUsers(Number(e.target.value))}
                  className="h-9 text-xs font-mono"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono">
                  Max Products
                </label>
                <Input
                  type="number"
                  required
                  value={maxProducts}
                  onChange={(e) => setMaxProducts(Number(e.target.value))}
                  className="h-9 text-xs font-mono"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-muted-foreground uppercase font-mono">
                  Monthly Invoices
                </label>
                <Input
                  type="number"
                  required
                  value={maxInvoicesMonthly}
                  onChange={(e) => setMaxInvoicesMonthly(Number(e.target.value))}
                  className="h-9 text-xs font-mono"
                />
              </div>
            </div>
          </div>

          {/* Module Feature Toggles */}
          <div className="border-t border-border/60 pt-4 space-y-3">
            <h4 className="text-xs font-bold text-foreground font-mono uppercase">
              Module Access & Visibility
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <label className="flex items-center gap-2 text-xs text-foreground cursor-pointer">
                <input
                  type="checkbox"
                  checked={enablePos}
                  onChange={(e) => setEnablePos(e.target.checked)}
                  className="rounded border-border text-primary focus:ring-primary h-4 w-4"
                />
                <span>POS Billing</span>
              </label>

              <label className="flex items-center gap-2 text-xs text-foreground cursor-pointer">
                <input
                  type="checkbox"
                  checked={enableImei}
                  onChange={(e) => setEnableImei(e.target.checked)}
                  className="rounded border-border text-primary focus:ring-primary h-4 w-4"
                />
                <span>IMEI / Serial Tracker</span>
              </label>

              <label className="flex items-center gap-2 text-xs text-foreground cursor-pointer">
                <input
                  type="checkbox"
                  checked={enableAccounting}
                  onChange={(e) => setEnableAccounting(e.target.checked)}
                  className="rounded border-border text-primary focus:ring-primary h-4 w-4"
                />
                <span>Finance & Ledger</span>
              </label>

              <label className="flex items-center gap-2 text-xs text-foreground cursor-pointer">
                <input
                  type="checkbox"
                  checked={enableSms}
                  onChange={(e) => setEnableSms(e.target.checked)}
                  className="rounded border-border text-primary focus:ring-primary h-4 w-4"
                />
                <span>SMS / Email Alerts</span>
              </label>

              <label className="flex items-center gap-2 text-xs text-foreground cursor-pointer">
                <input
                  type="checkbox"
                  checked={isPopular}
                  onChange={(e) => setIsPopular(e.target.checked)}
                  className="rounded border-border text-primary focus:ring-primary h-4 w-4"
                />
                <span>Highlight as &quot;Most Popular&quot;</span>
              </label>

              <label className="flex items-center gap-2 text-xs text-foreground cursor-pointer">
                <input
                  type="checkbox"
                  checked={isActive}
                  onChange={(e) => setIsActive(e.target.checked)}
                  className="rounded border-border text-primary focus:ring-primary h-4 w-4"
                />
                <span>Plan is Active</span>
              </label>

              <div className="col-span-full border-t border-border/40 pt-2">
                <label className="flex items-start gap-2.5 text-xs text-foreground cursor-pointer bg-primary/5 border border-primary/20 rounded-sm p-2.5">
                  <input
                    type="checkbox"
                    checked={isCustom}
                    onChange={(e) => setIsCustom(e.target.checked)}
                    className="rounded-sm border-border text-primary focus:ring-primary h-4 w-4 mt-0.5"
                  />
                  <div>
                    <span className="font-bold text-primary block">Custom Dedicated Enterprise Plan (Hidden from public website)</span>
                    <span className="text-[11px] text-muted-foreground">
                      Check this for negotiated client contracts. This plan will not appear on the public pricing page and will be exclusive to the chosen business.
                    </span>
                  </div>
                </label>

                {isCustom && (
                  <div className="mt-3 p-3 bg-secondary/30 border border-primary/30 rounded-sm space-y-2">
                    <label className="block text-xs font-bold text-foreground font-mono">
                      Target Client Business <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={businessId}
                      onChange={(e) => setBusinessId(e.target.value)}
                      required={isCustom}
                      className="w-full h-9 px-3 text-xs rounded-sm bg-background border border-border text-foreground font-mono focus:border-primary focus:outline-none"
                    >
                      <option value="">-- Select Client Business (Mandatory) --</option>
                      {businesses.map((b) => (
                        <option key={b.id} value={b.id}>
                          {b.name} ({b.phone || b.email || b.id.substring(0, 8)})
                        </option>
                      ))}
                    </select>
                    {isBusinessesLoading && (
                      <p className="text-[10px] text-muted-foreground flex items-center gap-1">
                        <Loader2 className="w-3 h-3 animate-spin" /> Loading businesses...
                      </p>
                    )}
                    <p className="text-[11px] text-muted-foreground">
                      🔒 <strong>Exclusive Access:</strong> This plan will exclusively be accessible to this business in their <code>settings/subscription</code> page. Other businesses cannot see or subscribe to this.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="px-0 py-2 flex items-center justify-end gap-3 border-t border-border/60">
            <Button type="button" variant="outline" onClick={onClose} className="text-xs h-9 rounded-sm">
              Cancel
            </Button>
            <Button type="submit" disabled={loading} className="text-xs h-9 px-5 rounded-sm">
              {loading ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin mr-1.5" /> Saving...
                </>
              ) : isEdit ? (
                'Update Plan'
              ) : (
                'Create Plan'
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
