import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { posService } from "@/services/pos-service";
import { posSettingsService, PosSettingsData } from "@/services/pos-settings-service";
import { queryKeys } from "@/lib/query-keys";
import { SaleCheckoutInput } from "../types";

export function usePosSettingsQuery(businessId: string, branchId?: string | null) {
  return useQuery<PosSettingsData>({
    queryKey: ["pos-settings", businessId, branchId],
    queryFn: () => posSettingsService.getSettings(businessId, branchId),
    enabled: !!businessId,
  });
}

export function useCheckoutMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: SaleCheckoutInput) => posService.checkout(payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.pos.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
    },
  });
}

export function useSalesQuery(
  businessId: string,
  filters: {
    branchId?: string;
    customerId?: string;
    status?: 'HOLD' | 'DRAFT' | 'FINAL';
    page?: number;
    limit?: number;
    search?: string;
  },
  options?: { enabled?: boolean }
) {
  return useQuery({
    queryKey: queryKeys.pos.list(
      businessId,
      filters.branchId,
      filters.customerId,
      filters.page,
      filters.limit,
      filters.search,
      filters.status
    ),
    queryFn: () => posService.getSales(businessId, filters),
    enabled: !!businessId && (options?.enabled ?? true),
  });
}

export function useSaleByIdQuery(id: string, businessId: string) {
  return useQuery({
    queryKey: queryKeys.pos.detail(id),
    queryFn: () => posService.getSaleById(id, businessId),
    enabled: !!id && !!businessId,
  });
}

export function useCustomerAdvancesQuery(customerId: string, businessId: string) {
  return useQuery({
    queryKey: queryKeys.pos.advances(customerId, businessId),
    queryFn: () => posService.getCustomerAdvances(customerId, businessId),
    enabled: !!customerId && !!businessId,
  });
}

export function useAddCustomerAdvanceMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: {
      customerId: string;
      amount: number;
      paymentMethodId: string;
      transactionNo?: string;
      notes?: string;
      branchId: string;
      businessId: string;
      createdById?: string;
    }) => posService.addCustomerAdvance(payload),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({
        queryKey: queryKeys.pos.advances(variables.customerId, variables.businessId),
      });
    },
  });
}

export function useDeleteSaleMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, businessId }: { id: string; businessId: string }) =>
      posService.deleteSale(id, businessId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.pos.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
    },
  });
}

export function useUpdateSaleMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      payload,
      businessId,
    }: {
      id: string;
      payload: any;
      businessId: string;
    }) => posService.updateSale(id, payload, businessId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.pos.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
    },
  });
}

export function useSalePaymentsQuery(saleId: string, businessId: string) {
  return useQuery({
    queryKey: queryKeys.pos.payments(saleId, businessId),
    queryFn: () => posService.getSalePayments(saleId, businessId),
    enabled: !!saleId && !!businessId,
  });
}

export function useAddSalePaymentMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({
      saleId,
      payload,
    }: {
      saleId: string;
      payload: {
        amount: number;
        paymentMethodId: string;
        transactionNo?: string;
        notes?: string;
        businessId: string;
        createdById?: string;
      };
    }) => posService.addSalePayment(saleId, payload),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({
        queryKey: queryKeys.pos.payments(variables.saleId, variables.payload.businessId),
      });
      queryClient.invalidateQueries({ queryKey: queryKeys.pos.lists() });
    },
  });
}

export function useDeleteSalePaymentMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ paymentId, businessId }: { paymentId: string; businessId: string }) =>
      posService.deleteSalePayment(paymentId, businessId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.pos.all });
    },
  });
}
