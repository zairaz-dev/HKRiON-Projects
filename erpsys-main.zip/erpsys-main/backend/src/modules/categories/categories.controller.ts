import {
  Controller,
  Post,
  Body,
  Get,
  Put,
  Delete,
  Param,
  Query,
  UseInterceptors,
  UploadedFile,
  Req,
} from '@nestjs/common';
import { CategoriesService } from './categories.service';
import { FileInterceptor } from '@nestjs/platform-express';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Permission } from '../../common/enums/permission.enum';
import {
  ApiTags,
  ApiOperation,
  ApiBody,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiQuery,
  ApiConsumes,
} from '@nestjs/swagger';
import {
  CreateCategoryBodySchema,
  UpdateCategoryBodySchema,
  CategoryResponseSchema,
} from '../../docs/categories.docs';
import { CreateCategoryDto } from './dto/create-category.dto';
import { UpdateCategoryDto } from './dto/update-category.dto';
import { getImageUploadOptions } from '../../common/utils/upload.util';
import { join, resolve } from 'path';
import * as fs from 'fs';

@ApiTags('Categories')
@ApiBearerAuth()
@Controller('categories')
export class CategoriesController {
  constructor(private readonly categoriesService: CategoriesService) {}

  @Permissions(Permission.CATEGORY_CREATE)
  @Post()
  @UseInterceptors(FileInterceptor('image', getImageUploadOptions('categories')))
  @ApiConsumes('multipart/form-data', 'application/json')
  @ApiOperation({ summary: 'Create category or subcategory' })
  @ApiBody({ schema: CreateCategoryBodySchema })
  @ApiResponse({
    status: 201,
    description: 'Category created successfully',
    schema: CategoryResponseSchema,
  })
  async createCategory(
    @Req() req: any,
    @UploadedFile() file: any,
    @Body() body: CreateCategoryDto,
  ) {
    const { name, description, color, businessId, parentId, branchIds, isActive, imageUrl, createdById } = body;
    const user = req?.user;
    const targetBusinessId = (user && user.role !== 'super-admin') ? user.businessId : (businessId || user?.businessId);

    // Convert parentId (if it is 'none' or 'null' or empty, set to null)
    const parentIdVal = parentId === 'none' || parentId === 'null' || !parentId ? null : parentId;

    // Convert branchIds array
    let parsedBranchIds: string[] = [];
    if (branchIds) {
      if (Array.isArray(branchIds)) {
        parsedBranchIds = branchIds;
      } else if (typeof branchIds === 'string') {
        try {
          const parsed = JSON.parse(branchIds);
          if (Array.isArray(parsed)) {
            parsedBranchIds = parsed;
          } else {
            parsedBranchIds = [branchIds];
          }
        } catch {
          parsedBranchIds = branchIds
            .split(',')
            .map((id: string) => id.trim())
            .filter(Boolean);
        }
      }
    }

    // Determine final imageUrl: uploaded file takes priority, otherwise use imageUrl text field
    let finalImageUrl = imageUrl || null;
    if (file) {
      finalImageUrl = `/uploads/categories/${file.filename}`;
    }

    const parsedIsActive =
      isActive !== undefined ? isActive === 'true' || isActive === true : true;

    return this.categoriesService.createCategory({
      name,
      description,
      imageUrl: finalImageUrl,
      color: color || '#3B82F6',
      isActive: parsedIsActive,
      businessId: targetBusinessId,
      branchIds: parsedBranchIds,
      parentId: parentIdVal,
      createdById,
    });
  }

  @Permissions(Permission.CATEGORY_VIEW)
  @Get()
  @ApiOperation({ summary: 'Get list of categories / subcategories' })
  @ApiQuery({ name: 'businessId', required: true, type: String })
  @ApiQuery({ name: 'branchId', required: false, type: String })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'search', required: false, type: String })
  @ApiQuery({ name: 'type', required: false, type: String })
  @ApiResponse({
    status: 200,
    description: 'Categories retrieved successfully',
  })
  async getCategories(
    @Query('businessId') businessId: string,
    @Query('branchId') branchId?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('search') search?: string,
    @Query('type') type?: string,
  ) {
    return this.categoriesService.getCategories(businessId, {
      branchId,
      page: page ? Number(page) : undefined,
      limit: limit ? Number(limit) : undefined,
      search,
      type,
    });
  }

  @Permissions(Permission.CATEGORY_VIEW)
  @Get(':id')
  @ApiOperation({ summary: 'Get category details by ID' })
  @ApiParam({ name: 'id', description: 'Category UUID' })
  @ApiQuery({ name: 'businessId', required: true, type: String })
  @ApiResponse({
    status: 200,
    description: 'Category details retrieved successfully',
    schema: CategoryResponseSchema,
  })
  async getCategoryById(
    @Param('id') id: string,
    @Query('businessId') businessId: string,
  ) {
    return this.categoriesService.getCategoryById(id, businessId);
  }

  @Permissions(Permission.CATEGORY_UPDATE)
  @Put(':id')
  @UseInterceptors(FileInterceptor('image', getImageUploadOptions('categories')))
  @ApiConsumes('multipart/form-data', 'application/json')
  @ApiOperation({ summary: 'Update category details' })
  @ApiParam({ name: 'id', description: 'Category UUID' })
  @ApiBody({ schema: UpdateCategoryBodySchema })
  @ApiResponse({
    status: 200,
    description: 'Category updated successfully',
    schema: CategoryResponseSchema,
  })
  async updateCategory(
    @Req() req: any,
    @Param('id') id: string,
    @UploadedFile() file: any,
    @Body() body: UpdateCategoryDto,
  ) {
    const { name, description, color, businessId, parentId, branchIds, isActive, imageUrl, updatedById } = body;
    const user = req?.user;
    const targetBusinessId = (user && user.role !== 'super-admin') ? user.businessId : (businessId || user?.businessId);

    const updateData: any = { businessId: targetBusinessId };

    if (name !== undefined) updateData.name = name;
    if (description !== undefined) updateData.description = description;
    if (color !== undefined) updateData.color = color;

    if (isActive !== undefined) {
      updateData.isActive = isActive === 'true' || isActive === true;
    }

    if (parentId !== undefined) {
      updateData.parentId = parentId === 'none' || parentId === 'null' || !parentId ? null : parentId;
    }

    if (branchIds !== undefined) {
      let parsedBranchIds: string[] = [];
      if (Array.isArray(branchIds)) {
        parsedBranchIds = branchIds;
      } else if (typeof branchIds === 'string') {
        try {
          const parsed = JSON.parse(branchIds);
          if (Array.isArray(parsed)) {
            parsedBranchIds = parsed;
          } else {
            parsedBranchIds = [branchIds];
          }
        } catch {
          parsedBranchIds = branchIds
            .split(',')
            .map((id: string) => id.trim())
            .filter(Boolean);
        }
      }
      updateData.branchIds = parsedBranchIds;
    }

    // Handle image update
    if (file) {
      updateData.imageUrl = `/uploads/categories/${file.filename}`;

      // Clean up the old image file from the server if it was local
      try {
        const oldCategory = await this.categoriesService.getCategoryById(id, targetBusinessId);
        if (oldCategory.imageUrl && oldCategory.imageUrl.startsWith('/uploads/')) {
          const uploadsDir = join(process.cwd(), 'uploads');
          const oldFilePath = resolve(join(process.cwd(), oldCategory.imageUrl));
          if (oldFilePath.startsWith(uploadsDir) && fs.existsSync(oldFilePath)) {
            fs.unlinkSync(oldFilePath);
          }
        }
      } catch (err) {
        // File deletion error shouldn't block update
      }
    } else if (imageUrl !== undefined) {
      updateData.imageUrl = imageUrl === 'null' || !imageUrl ? null : imageUrl;
    }

    if (updatedById !== undefined) {
      updateData.updatedById = updatedById;
    }

    return this.categoriesService.updateCategory(id, targetBusinessId, updateData);
  }

  @Permissions(Permission.CATEGORY_DELETE)
  @Delete(':id')
  @ApiOperation({ summary: 'Delete category' })
  @ApiParam({ name: 'id', description: 'Category UUID' })
  @ApiQuery({ name: 'businessId', required: true, type: String })
  @ApiResponse({
    status: 200,
    description: 'Category deleted successfully',
  })
  async deleteCategory(
    @Req() req: any,
    @Param('id') id: string,
    @Query('businessId') businessId: string,
  ) {
    const user = req?.user;
    let targetBusinessId = businessId;
    if (user && user.role !== 'super-admin') {
      targetBusinessId = user.businessId;
    }
    // Delete local image file when category is deleted
    try {
      const category = await this.categoriesService.getCategoryById(id, targetBusinessId);
      if (category && category.imageUrl && category.imageUrl.startsWith('/uploads/')) {
        const uploadsDir = join(process.cwd(), 'uploads');
        const filePath = resolve(join(process.cwd(), category.imageUrl));
        if (filePath.startsWith(uploadsDir) && fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
        }
      }
    } catch (err) {
      // File cleanup error shouldn't block delete
    }

    return this.categoriesService.deleteCategory(id, targetBusinessId);
  }
}
