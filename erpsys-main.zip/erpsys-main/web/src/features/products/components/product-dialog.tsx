import React, { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  Package, 
  X, 
  Loader2, 
  Layers, 
  Tag, 
  Scale, 
  ShieldCheck, 
  Upload, 
  Coins, 
  Sliders, 
  Check,
  DollarSign,
  ChevronDown,
  ChevronUp,
  Smartphone,
  AlertTriangle,
  Power,
  Boxes,
  Bell,
  Ban,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { MultiSelect } from "@/components/ui/multi-select";
import { Checkbox } from "@/components/ui/checkbox";
import { InfoTooltip } from "@/components/ui/info-tooltip";
import { Dialog } from "@/components/ui/dialog";
import { RichTextEditor } from "@/components/ui/rich-text-editor";
import { cn, getFullAssetUrl } from "@/lib/utils";
import { productService } from "@/services/product-service";
import { ProductItem, ProductVariantItem } from "../types";
import { productFormSchema, ProductFormValues } from "../schema";
import { 
  useCategoriesQuery, 
  useBrandsQuery, 
  useUnitsQuery, 
  useWarrantiesQuery, 
  useVariationsQuery, 
  useSpgQuery, 
  useBranchesQuery,
  useCreateProductMutation,
  useUpdateProductMutation
} from "../hooks/use-products";

interface ProductDialogProps {
  isOpen: boolean;
  onClose: () => void;
  product: ProductItem | null;
  businessId: string;
  userId: string;
  onSuccessMessage: (msg: string) => void;
  onErrorMessage: (msg: string) => void;
}

export function ProductDialog({
  isOpen,
  onClose,
  product,
  businessId,
  userId,
  onSuccessMessage,
  onErrorMessage
}: ProductDialogProps) {
  const [activeTab, setActiveTab] = useState<"general" | "pricing">("general");

  // Custom States
  const [singleGroupPrices, setSingleGroupPrices] = useState<{ [groupId: string]: string }>({});
  const [selectedVariationIds, setSelectedVariationIds] = useState<string[]>([]);
  const [selectedVariationValues, setSelectedVariationValues] = useState<{ [variationId: string]: string[] }>({});
  const [generatedVariants, setGeneratedVariants] = useState<ProductVariantItem[]>([]);
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [showDescription, setShowDescription] = useState(false);
  const [selectedParentCategoryId, setSelectedParentCategoryId] = useState<string>("none");
  const [selectedSubCategoryId, setSelectedSubCategoryId] = useState<string>("none");

  // Metadata Queries
  const { data: categories = [] } = useCategoriesQuery(businessId);
  const { data: brandsResponse } = useBrandsQuery(businessId);
  const brands = brandsResponse?.data || [];
  const { data: units = [] } = useUnitsQuery(businessId);
  const { data: warranties = [] } = useWarrantiesQuery(businessId);
  const { data: variations = [] } = useVariationsQuery(businessId);
  const { data: spgList = [] } = useSpgQuery(businessId);
  const { data: branchesList = [] } = useBranchesQuery(businessId, userId);

  const branchOptions = React.useMemo(() => {
    return branchesList.map((b: any) => ({ value: b.id, label: b.name }));
  }, [branchesList]);

  const parentCategories = React.useMemo(() => {
    return categories.filter((c: any) => !c.parentId);
  }, [categories]);

  const subCategories = React.useMemo(() => {
    return categories.filter((c: any) => c.parentId && c.parentId === selectedParentCategoryId);
  }, [categories, selectedParentCategoryId]);

  // Mutation hooks
  const createMutation = useCreateProductMutation();
  const updateMutation = useUpdateProductMutation();
  const isPending = createMutation.isPending || updateMutation.isPending;

  // React Hook Form
  const { 
    register, 
    handleSubmit, 
    reset, 
    watch, 
    setValue, 
    control,
    trigger,
    formState: { errors } 
  } = useForm<ProductFormValues>({
    resolver: zodResolver(productFormSchema),
    defaultValues: {
      name: "",
      description: "",
      imageUrl: "",
      type: "SINGLE",
      isActive: true,
      enableStock: true,
      isImei: false,
      enableImei: false,
      alertQuantity: 0,
      notForSelling: false,
      weight: null,
      categoryId: "none",
      brandId: "none",
      unitId: "none",
      warrantyId: "none",
      branchIds: [],
      sku: "",
      purchasePrice: 0,
      sellingPrice: 0,
      openingStock: 0,
      openingStockBranchId: "none",
    }
  });

  // Keep categoryId form field in sync with parent and sub category selections
  React.useEffect(() => {
    const finalVal = selectedSubCategoryId !== "none" ? selectedSubCategoryId : selectedParentCategoryId;
    setValue("categoryId", finalVal, { shouldValidate: true });
  }, [selectedParentCategoryId, selectedSubCategoryId, setValue]);

  const formType = watch("type");
  const formImageUrl = watch("imageUrl");
  const formEnableStock = watch("enableStock");
  const formBranchIds = watch("branchIds") || [];
  const formCategoryId = watch("categoryId") || "none";
  const formBrandId = watch("brandId") || "none";
  const formUnitId = watch("unitId") || "none";
  const formWarrantyId = watch("warrantyId") || "none";
  const formOpeningStockBranchId = watch("openingStockBranchId") || "none";
  const formPurchasePrice = watch("purchasePrice");
  const formSellingPrice = watch("sellingPrice");

  const onInvalid = (formErrors: any) => {
    if (formErrors.name || formErrors.categoryId || formErrors.brandId || formErrors.unitId || formErrors.alertQuantity) {
      setActiveTab("general");
    } else if (formErrors.purchasePrice || formErrors.sellingPrice || formErrors.openingStockBranchId) {
      setActiveTab("pricing");
    }
  };

  const handleNext = async (e?: React.SyntheticEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    const isGeneralValid = await trigger([
      "name",
      "categoryId",
      "brandId",
      "unitId",
      "alertQuantity",
      "weight"
    ]);
    if (isGeneralValid) {
      setActiveTab("pricing");
    }
  };

  // Reset or Populate form only when dialog opens or target product changes
  const prevIsOpenRef = React.useRef(false);
  const prevProductRef = React.useRef<string | null>(null);

  React.useEffect(() => {
    const isOpening = isOpen && !prevIsOpenRef.current;
    const isProductChanged = isOpen && product?.id !== prevProductRef.current;

    if (isOpening || isProductChanged) {
      if (product) {
        reset({
          name: product.name,
          description: product.description || "",
          imageUrl: product.imageUrl || "",
          type: product.type,
          isActive: product.isActive,
          enableStock: product.enableStock,
          isImei: product.isImei || product.enableImei || false,
          enableImei: product.isImei || product.enableImei || false,
          alertQuantity: product.alertQuantity,
          notForSelling: product.notForSelling || false,
          weight: product.weight || null,
          categoryId: product.categoryId || "none",
          brandId: product.brandId || "none",
          unitId: product.unitId || "none",
          warrantyId: product.warrantyId || "none",
          branchIds: product.branches?.map((pb) => pb.branchId) || [],
          sku: "",
          purchasePrice: 0,
          sellingPrice: 0,
          openingStock: 0,
          openingStockBranchId: "none",
        });
        setShowDescription(!!product.description);

        const prodCatId = product.categoryId || "none";
        const matchedCat = categories.find((c: any) => c.id === prodCatId);
        if (matchedCat && matchedCat.parentId) {
          setSelectedParentCategoryId(matchedCat.parentId);
          setSelectedSubCategoryId(matchedCat.id);
        } else {
          setSelectedParentCategoryId(prodCatId);
          setSelectedSubCategoryId("none");
        }

        if (product.type === "SINGLE") {
          const variant = product.variants[0];
          setValue("sku", variant?.sku || "");
          setValue("purchasePrice", variant?.purchasePrice || 0);
          setValue("sellingPrice", variant?.sellingPrice || 0);

          const gPrices: { [groupId: string]: string } = {};
          variant?.groupPrices?.forEach((gp) => {
            gPrices[gp.sellingPriceGroupId] = String(gp.price);
          });
          setSingleGroupPrices(gPrices);
        } else {
          setGeneratedVariants(product.variants);

          const valIds = new Set<string>();
          const varIds = new Set<string>();
          const varVals: { [varId: string]: string[] } = {};

          product.variants.forEach((v) => {
            v.valueMaps?.forEach((vm) => {
              valIds.add(vm.valueId);
              const parentVar = variations.find((vList) =>
                vList.values.some((val: any) => val.id === vm.valueId)
              );
              if (parentVar) {
                varIds.add(parentVar.id);
                if (!varVals[parentVar.id]) varVals[parentVar.id] = [];
                if (!varVals[parentVar.id].includes(vm.valueId)) {
                  varVals[parentVar.id].push(vm.valueId);
                }
              }
            });
          });

          setSelectedVariationIds(Array.from(varIds));
          setSelectedVariationValues(varVals);
        }
      } else {
        reset({
          name: "",
          description: "",
          imageUrl: "",
          type: "SINGLE",
          isActive: true,
          enableStock: true,
          alertQuantity: 0,
          notForSelling: false,
          weight: null,
          categoryId: "none",
          brandId: "none",
          unitId: "none",
          warrantyId: "none",
          branchIds: [],
          sku: "",
          purchasePrice: 0,
          sellingPrice: 0,
          openingStock: 0,
          openingStockBranchId: "none",
        });
        setSingleGroupPrices({});
        setSelectedVariationIds([]);
        setSelectedVariationValues({});
        setGeneratedVariants([]);
        setShowDescription(false);
        setSelectedParentCategoryId("none");
        setSelectedSubCategoryId("none");
      }
      setActiveTab("general");
    }

    prevIsOpenRef.current = isOpen;
    prevProductRef.current = product?.id || null;
  }, [product, isOpen, reset, setValue, variations, categories]);

  if (!isOpen) return null;

  // Image Upload to Backend
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const allowedTypes = ["image/jpeg", "image/png", "image/webp", "image/gif"];
    if (!allowedTypes.includes(file.type)) {
      onErrorMessage("Invalid image format. Please select JPG, PNG, WEBP, or GIF.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      onErrorMessage("Image size exceeds 5MB limit. Please choose a smaller image.");
      return;
    }

    try {
      setIsUploadingImage(true);
      const res = await productService.uploadProductImage(file);
      setValue("imageUrl", res.imageUrl);
    } catch (err: any) {
      onErrorMessage(err.message || "Failed to upload image");
    } finally {
      setIsUploadingImage(false);
    }
  };

  const handleToggleBranchForm = (branchId: string) => {
    const next = formBranchIds.includes(branchId)
      ? formBranchIds.filter((id) => id !== branchId)
      : [...formBranchIds, branchId];
    setValue("branchIds", next);
  };

  const handleToggleVariationSelector = (varId: string) => {
    setSelectedVariationIds((prev) => {
      const isSelected = prev.includes(varId);
      if (isSelected) {
        const next = prev.filter((id) => id !== varId);
        const nextVals = { ...selectedVariationValues };
        delete nextVals[varId];
        setSelectedVariationValues(nextVals);
        return next;
      } else {
        return [...prev, varId];
      }
    });
  };

  const handleToggleVariationValueSelector = (varId: string, valId: string) => {
    setSelectedVariationValues((prev) => {
      const currentVals = prev[varId] || [];
      const nextVals = currentVals.includes(valId)
        ? currentVals.filter((id) => id !== valId)
        : [...currentVals, valId];
      return { ...prev, [varId]: nextVals };
    });
  };

  // Generate combinations algorithm
  const handleGenerateVariants = () => {
    const formName = watch("name");
    const singlePurchasePrice = String(watch("purchasePrice") || "");
    const singleSellingPrice = String(watch("sellingPrice") || "");

    if (selectedVariationIds.length === 0) {
      onErrorMessage("Please select at least one variation attribute.");
      return;
    }

    const selectedValuesArrays = selectedVariationIds
      .map((varId) => selectedVariationValues[varId] || [])
      .filter((arr) => arr.length > 0);

    if (selectedValuesArrays.length !== selectedVariationIds.length) {
      onErrorMessage("Please select at least one value for each selected attribute.");
      return;
    }

    const cartesian = (a: any[]): any[] =>
      a.reduce((b, c) => b.flatMap((d: any) => c.map((e: any) => [d, e].flat())));

    const combinations = selectedValuesArrays.length === 1
      ? selectedValuesArrays[0].map((val: string) => [val])
      : cartesian(selectedValuesArrays);

    const newVariants: ProductVariantItem[] = combinations.map((combo: string[], index: number) => {
      const names: string[] = [];
      const valueIds: string[] = [];

      combo.forEach((valId) => {
        valueIds.push(valId);
        for (const v of variations) {
          const matchingVal = v.values.find((val: any) => val.id === valId);
          if (matchingVal) {
            names.push(matchingVal.value);
            break;
          }
        }
      });

      const comboName = `${formName || "Product"} - ${names.join(" - ")}`;
      const comboSku = `${(formName || "PROD").substring(0, 3).toUpperCase()}-${names.join("-").toUpperCase()}-${index + 1}`;

      const existingMatch = generatedVariants.find((gv) => {
        const maps = gv.valueMaps;
        if (!maps || maps.length !== valueIds.length) return false;
        return valueIds.every((vid) => maps.some((vm) => vm.valueId === vid));
      });

      if (existingMatch) {
        return existingMatch;
      }

      return {
        name: comboName,
        sku: comboSku,
        barcode: null,
        purchasePrice: parseFloat(singlePurchasePrice) || 0,
        sellingPrice: parseFloat(singleSellingPrice) || 0,
        valueIds,
        groupPrices: spgList.map((spg) => ({ sellingPriceGroupId: spg.id, price: 0 })),
        openingStock: 0,
        openingStockBranchId: "none",
      };
    });

    setGeneratedVariants(newVariants);
  };

  const handleUpdateGeneratedVariant = (
    index: number,
    field: keyof ProductVariantItem,
    value: any
  ) => {
    setGeneratedVariants((prev) =>
      prev.map((v, idx) => (idx === index ? { ...v, [field]: value } : v))
    );
  };

  const handleUpdateGeneratedVariantGroupPrice = (
    variantIndex: number,
    spgId: string,
    priceValue: string
  ) => {
    setGeneratedVariants((prev) =>
      prev.map((v, idx) => {
        if (idx !== variantIndex) return v;
        const currentGroupPrices = v.groupPrices || [];
        const exists = currentGroupPrices.some((gp) => gp.sellingPriceGroupId === spgId);
        const priceNum = parseFloat(priceValue) || 0;

        let nextGroupPrices = [];
        if (exists) {
          nextGroupPrices = currentGroupPrices.map((gp) =>
            gp.sellingPriceGroupId === spgId ? { ...gp, price: priceNum } : gp
          );
        } else {
          nextGroupPrices = [...currentGroupPrices, { sellingPriceGroupId: spgId, price: priceNum }];
        }
        return { ...v, groupPrices: nextGroupPrices };
      })
    );
  };

  const onSubmit = async (data: ProductFormValues) => {
    if (data.type === "SINGLE") {
      if (data.purchasePrice === undefined || isNaN(data.purchasePrice) || data.purchasePrice < 0) {
        onErrorMessage("Purchase price must be 0 or greater.");
        setActiveTab("pricing");
        return;
      }
      if (data.sellingPrice === undefined || isNaN(data.sellingPrice) || data.sellingPrice < 0) {
        onErrorMessage("Selling price must be 0 or greater.");
        setActiveTab("pricing");
        return;
      }
      if (!product && data.openingStock && data.openingStock > 0) {
        if (!data.openingStockBranchId || data.openingStockBranchId === "none") {
          onErrorMessage("Please select a branch to allocate opening stock.");
          setActiveTab("pricing");
          return;
        }
      }
    } else {
      if (generatedVariants.length === 0) {
        onErrorMessage("Please configure at least one variant for variable products.");
        setActiveTab("pricing");
        return;
      }

      const seenSkus = new Set<string>();
      for (let i = 0; i < generatedVariants.length; i++) {
        const v = generatedVariants[i];
        if (!v.name || v.name.trim() === "") {
          onErrorMessage(`Variant #${i + 1} must have a name.`);
          setActiveTab("pricing");
          return;
        }
        const pPrice = parseFloat(String(v.purchasePrice));
        const sPrice = parseFloat(String(v.sellingPrice));
        if (isNaN(pPrice) || pPrice < 0) {
          onErrorMessage(`Variant "${v.name}" purchase price must be 0 or greater.`);
          setActiveTab("pricing");
          return;
        }
        if (isNaN(sPrice) || sPrice < 0) {
          onErrorMessage(`Variant "${v.name}" selling price must be 0 or greater.`);
          setActiveTab("pricing");
          return;
        }
        if (v.sku && v.sku.trim()) {
          const normSku = v.sku.trim().toUpperCase();
          if (seenSkus.has(normSku)) {
            onErrorMessage(`Duplicate SKU "${normSku}" found among variants. Each variant must have a unique SKU.`);
            setActiveTab("pricing");
            return;
          }
          seenSkus.add(normSku);
        }
        if (!product && v.openingStock && parseFloat(String(v.openingStock)) > 0) {
          if (!v.openingStockBranchId || v.openingStockBranchId === "none") {
            onErrorMessage(`Please select an opening stock branch for variant "${v.name}".`);
            setActiveTab("pricing");
            return;
          }
        }
      }
    }

    const payload: any = {
      name: data.name.trim(),
      description: data.description?.trim() || undefined,
      imageUrl: data.imageUrl || undefined,
      type: data.type,
      isActive: data.isActive,
      enableStock: data.enableStock,
      isImei: data.isImei || false,
      enableImei: data.isImei || false,
      alertQuantity: data.alertQuantity,
      notForSelling: data.notForSelling || false,
      weight: data.weight !== undefined && data.weight !== null ? data.weight : null,
      businessId,
      categoryId: data.categoryId !== "none" ? data.categoryId : null,
      brandId: data.brandId !== "none" ? data.brandId : null,
      unitId: data.unitId !== "none" ? data.unitId : null,
      warrantyId: data.warrantyId !== "none" ? data.warrantyId : null,
      branchIds: data.branchIds,
      createdById: !product ? userId : undefined,
      updatedById: product ? userId : undefined,
    };

    if (data.type === "SINGLE") {
      payload.sku = data.sku?.trim() ? data.sku.trim().toUpperCase() : undefined;
      payload.purchasePrice = data.purchasePrice || 0;
      payload.sellingPrice = data.sellingPrice || 0;
      
      if (!product && data.openingStock && data.openingStock > 0) {
        payload.openingStock = data.openingStock;
        payload.openingStockBranchId = data.openingStockBranchId !== "none" ? data.openingStockBranchId : undefined;
      }

      payload.groupPrices = Object.keys(singleGroupPrices).map((groupId) => ({
        sellingPriceGroupId: groupId,
        price: parseFloat(singleGroupPrices[groupId]) || 0
      }));
    } else {
      payload.variants = generatedVariants.map((v) => ({
        id: v.id || undefined,
        name: v.name,
        sku: v.sku.trim().toUpperCase(),
        purchasePrice: parseFloat(String(v.purchasePrice)) || 0,
        sellingPrice: parseFloat(String(v.sellingPrice)) || 0,
        openingStock: !product && v.openingStock ? parseFloat(String(v.openingStock)) : undefined,
        openingStockBranchId: !product && v.openingStockBranchId && v.openingStockBranchId !== "none" ? v.openingStockBranchId : undefined,
        valueIds: v.valueIds || v.valueMaps?.map((vm) => vm.valueId),
        groupPrices: v.groupPrices?.map((gp) => ({
          sellingPriceGroupId: gp.sellingPriceGroupId,
          price: parseFloat(String(gp.price)) || 0
        }))
      }));
    }

    try {
      if (!product) {
        await createMutation.mutateAsync(payload);
        onSuccessMessage("Product created successfully!");
      } else {
        await updateMutation.mutateAsync({ id: product.id, productData: payload });
        onSuccessMessage("Product updated successfully!");
      }
      onClose();
    } catch (err: any) {
      onErrorMessage(err.message || "Failed to save product.");
    }
  };

  return (
    <Dialog
      isOpen={isOpen}
      onClose={onClose}
      size="3xl"
      contentClassName="flex-1 flex flex-col overflow-hidden pl-0 pr-6"
      title={
        <span className="flex items-center gap-2">
          <Package className="h-5 w-5 text-primary" />
          {!product ? "Create New Product" : "Edit Product"}
        </span>
      }
      headerAccessory={
        <div className="bg-secondary/40 border border-primary/60 rounded-full p-1 flex items-center gap-1">
          <button
            type="button"
            onClick={() => {
              if (!product) setValue("type", "SINGLE", { shouldValidate: true });
            }}
            disabled={isPending || !!product}
            className={cn(
              "px-4 py-1.5 rounded-full text-xs font-bold uppercase transition-all duration-200",
              formType === "SINGLE"
                ? "bg-primary text-black font-extrabold shadow-md"
                : "text-muted-foreground hover:text-foreground disabled:opacity-50"
            )}
          >
            Single
          </button>
          <button
            type="button"
            onClick={() => {
              if (!product) setValue("type", "VARIABLE", { shouldValidate: true });
            }}
            disabled={isPending || !!product}
            className={cn(
              "px-4 py-1.5 rounded-full text-xs font-bold uppercase transition-all duration-200",
              formType === "VARIABLE"
                ? "bg-primary text-black font-extrabold shadow-md"
                : "text-muted-foreground hover:text-foreground disabled:opacity-50"
            )}
          >
            Variable
          </button>
        </div>
      }
    >

        {/* Tabs Selector */}
        <div className="flex gap-2 border-b border-border/50 pb-2 mb-4 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab("general")}
            className={cn(
              "px-4 py-1.5 text-xs font-bold rounded-lg transition",
              activeTab === "general"
                ? "bg-primary/10 text-primary"
                : "text-muted-foreground hover:bg-secondary/40"
            )}
          >
            1. General Info
          </button>
          <button
            type="button"
            onClick={() => handleNext()}
            className={cn(
              "px-4 py-1.5 text-xs font-bold rounded-lg transition",
              activeTab === "pricing"
                ? "bg-primary/10 text-primary"
                : "text-muted-foreground hover:bg-secondary/40"
            )}
          >
            2. Pricing & Variants
          </button>
        </div>

        <form 
          onSubmit={(e) => {
            if (activeTab !== "pricing") {
              e.preventDefault();
              e.stopPropagation();
              handleNext(e);
              return;
            }
            handleSubmit(onSubmit, onInvalid)(e);
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter" && (e.target as HTMLElement).tagName !== "TEXTAREA") {
              if (activeTab === "general") {
                e.preventDefault();
                e.stopPropagation();
                handleNext(e);
              }
            }
          }}
          className="flex-1 flex flex-col overflow-hidden"
        >
          <div className="flex-1 overflow-y-auto px-2 space-y-4 pb-12">
            {activeTab === "general" ? (
              <>
                <div className="grid grid-cols-1 gap-4">
                  {/* Name */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1">
                      <Package className="h-3 w-3" /> Product Name <span className="text-destructive">*</span>
                    </label>
                    <Input
                      placeholder="e.g., iPhone 15 Pro, HKR Gold Tea"
                      {...register("name")}
                      disabled={isPending}
                      className={cn(errors.name && "border-destructive focus-visible:ring-destructive")}
                    />
                    {errors.name && (
                      <span className="text-[10px] text-destructive">{errors.name.message}</span>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {/* Category */}
                  <div className="space-y-1.5 col-span-1">
                    <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1">
                      <Layers className="h-3 w-3" /> Category
                    </label>
                    <Select
                      value={selectedParentCategoryId}
                      onValueChange={(val) => {
                        setSelectedParentCategoryId(val);
                        setSelectedSubCategoryId("none");
                      }}
                      disabled={isPending}
                      className="w-full"
                    >
                      <option value="none">None</option>
                      {parentCategories.map((c: any) => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </Select>
                  </div>

                  {/* Sub Category */}
                  <div className="space-y-1.5 col-span-1">
                    <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1">
                      <Layers className="h-3 w-3" /> Sub Category
                    </label>
                    <Select
                      value={selectedSubCategoryId}
                      onValueChange={(val) => setSelectedSubCategoryId(val)}
                      disabled={isPending || selectedParentCategoryId === "none" || subCategories.length === 0}
                      className="w-full"
                    >
                      <option value="none">None</option>
                      {subCategories.map((c: any) => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </Select>
                  </div>

                  {/* Brand */}
                  <div className="space-y-1.5 col-span-1">
                    <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1">
                      <Tag className="h-3 w-3" /> Brand
                    </label>
                    <Select
                      value={formBrandId}
                      onValueChange={(val) => setValue("brandId", val, { shouldValidate: true })}
                      disabled={isPending}
                      className="w-full"
                    >
                      <option value="none">None</option>
                      {brands.map((b: any) => (
                        <option key={b.id} value={b.id}>{b.name}</option>
                      ))}
                    </Select>
                  </div>

                  {/* Unit */}
                  <div className="space-y-1.5 col-span-1">
                    <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1">
                      <Scale className="h-3 w-3" /> Unit of Measure
                    </label>
                    <Select
                      value={formUnitId}
                      onValueChange={(val) => setValue("unitId", val, { shouldValidate: true })}
                      disabled={isPending}
                      className="w-full"
                    >
                      <option value="none">None</option>
                      {units.map((u: any) => (
                        <option key={u.id} value={u.id}>{`${u.name} (${u.code})`}</option>
                      ))}
                    </Select>
                  </div>

                  {/* Warranty */}
                  <div className="space-y-1.5 col-span-1">
                    <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1">
                      <ShieldCheck className="h-3 w-3" /> Warranty
                    </label>
                    <Select
                      value={formWarrantyId}
                      onValueChange={(val) => setValue("warrantyId", val, { shouldValidate: true })}
                      disabled={isPending}
                      className="w-full"
                    >
                      <option value="none">No Warranty</option>
                      {warranties.map((w: any) => (
                        <option key={w.id} value={w.id}>{w.name}</option>
                      ))}
                    </Select>
                  </div>

                  {/* Image Upload */}
                  <div className="col-span-1 flex flex-col gap-1.5 justify-end">
                    <label className="text-xs font-bold text-muted-foreground uppercase block">
                      Product Image
                    </label>
                    <div 
                      onClick={() => !isUploadingImage && fileInputRef.current?.click()}
                      className="border border-input bg-background/50 rounded-sm px-2.5 flex items-center justify-between hover:bg-secondary/30 transition cursor-pointer relative h-10 group"
                    >
                      {isUploadingImage ? (
                        <div className="flex items-center justify-center w-full gap-1.5">
                          <Loader2 className="h-4 w-4 animate-spin text-primary" />
                          <span className="text-xs text-muted-foreground font-medium">Uploading...</span>
                        </div>
                      ) : formImageUrl ? (
                        <>
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className="relative group/thumb shrink-0">
                              <img 
                                src={getFullAssetUrl(formImageUrl) || ""} 
                                alt="Product Preview" 
                                className="h-7 w-7 rounded-sm object-cover border border-border bg-muted shadow-sm" 
                              />
                              {/* Hover zoom preview */}
                              <div className="hidden group-hover/thumb:block absolute bottom-full mb-2 left-0 z-50 p-1.5 bg-popover border border-border rounded-md shadow-2xl pointer-events-none animate-in fade-in zoom-in-95 duration-150">
                                <img 
                                  src={getFullAssetUrl(formImageUrl) || ""} 
                                  alt="Full Preview" 
                                  className="w-36 h-36 object-cover rounded" 
                                />
                              </div>
                            </div>
                            <span className="text-xs text-foreground font-medium truncate">
                              Image selected
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <span className="text-[11px] text-muted-foreground group-hover:text-primary transition font-medium">
                              Change
                            </span>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setValue("imageUrl", "");
                              }}
                              className="p-1 rounded-sm text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition"
                              title="Remove image"
                            >
                              <X className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </>
                      ) : (
                        <div className="flex items-center justify-center w-full gap-1.5">
                          <Upload className="h-4 w-4 text-muted-foreground/60" />
                          <span className="text-xs text-muted-foreground font-medium">Upload File</span>
                        </div>
                      )}
                    </div>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </div>

                  {/* Branch Mapping */}
                  <div className="col-span-1 sm:col-span-2 flex flex-col gap-1.5 justify-end">
                    <label className="text-xs font-bold text-muted-foreground uppercase block truncate">
                      Branch Scope (Optional)
                    </label>
                    <MultiSelect
                      options={branchOptions}
                      selectedValues={formBranchIds}
                      onChange={(vals) => setValue("branchIds", vals, { shouldValidate: true })}
                      placeholder="Select branches..."
                      disabled={isPending}
                    />
                  </div>

                  {/* Weight */}
                  <div className="col-span-1 flex flex-col gap-1.5 justify-end">
                    <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1">
                      <Scale className="h-3 w-3" /> Weight
                    </label>
                    <Input
                      type="number"
                      step="any"
                      placeholder="e.g. 0.50"
                      {...register("weight", { valueAsNumber: true })}
                      disabled={isPending}
                    />
                  </div>
                </div>

                {/* Stock Settings, IMEI Tracking, Active Status & Not for selling */}
                <div className="pt-2 border-t border-border/30 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 items-center">
                  {/* 1. Active / Inactive Status Checkbox */}
                  <div className="flex items-center justify-between p-3 rounded-sm border border-border/40 bg-secondary/15 min-h-[48px]">
                    <div className="flex items-center space-x-2">
                      <Controller
                        name="isActive"
                        control={control}
                        render={({ field }) => (
                          <Checkbox
                            id="isActive"
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            disabled={isPending}
                            className="border-muted-foreground/60 data-[state=checked]:bg-emerald-600 data-[state=checked]:border-emerald-600"
                          />
                        )}
                      />
                      <label 
                        htmlFor="isActive" 
                        className="text-xs font-bold text-foreground flex items-center gap-1.5 cursor-pointer select-none"
                      >
                        <Power className="w-3.5 h-3.5 text-emerald-500" /> Active Product?
                      </label>
                    </div>
                    <InfoTooltip text="Active products appear in POS, sales, and catalogs. Uncheck to deactivate and hide." />
                  </div>

                  {/* 2. Manage Stock Checkbox */}
                  <div className="flex items-center justify-between p-3 rounded-sm border border-border/40 bg-secondary/15 min-h-[48px]">
                    <div className="flex items-center space-x-2">
                      <Controller
                        name="enableStock"
                        control={control}
                        render={({ field }) => (
                          <Checkbox
                            id="enableStock"
                            checked={field.value}
                            onCheckedChange={(val) => {
                              field.onChange(val);
                              if (!val) {
                                setValue("alertQuantity", 0, { shouldValidate: true });
                              }
                            }}
                            disabled={isPending}
                            className="border-muted-foreground/60 data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                          />
                        )}
                      />
                      <label 
                        htmlFor="enableStock" 
                        className="text-xs font-bold text-foreground flex items-center gap-1.5 cursor-pointer select-none"
                      >
                        <Boxes className="w-3.5 h-3.5 text-primary" /> Manage Stock?
                      </label>
                    </div>
                    <InfoTooltip text="Enable inventory tracking and alert quantity monitoring for this product." />
                  </div>

                  {/* 3. IMEI / Serial Tracking Checkbox */}
                  <div className="flex items-center justify-between p-3 rounded-sm border border-border/40 bg-secondary/15 min-h-[48px]">
                    <div className="flex items-center space-x-2">
                      <Controller
                        name="isImei"
                        control={control}
                        render={({ field }) => (
                          <Checkbox
                            id="isImei"
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            disabled={isPending}
                            className="border-muted-foreground/60 data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                          />
                        )}
                      />
                      <label 
                        htmlFor="isImei" 
                        className="text-xs font-bold text-foreground flex items-center gap-1.5 cursor-pointer select-none"
                      >
                        <Smartphone className="w-3.5 h-3.5 text-primary" /> Track IMEI / Serial?
                      </label>
                    </div>
                    <InfoTooltip text="Enable unique IMEI/Serial number tracking for mobile phones, laptops, and serialized electronics." />
                  </div>

                  {/* 4. Not for selling checkbox */}
                  <div className="flex items-center justify-between p-3 rounded-sm border border-border/40 bg-secondary/15 min-h-[48px]">
                    <div className="flex items-center space-x-2">
                      <Controller
                        name="notForSelling"
                        control={control}
                        render={({ field }) => (
                          <Checkbox
                            id="notForSelling"
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            disabled={isPending}
                            className="border-muted-foreground/60 data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                          />
                        )}
                      />
                      <label 
                        htmlFor="notForSelling" 
                        className="text-xs font-bold text-muted-foreground uppercase cursor-pointer select-none flex items-center gap-1.5"
                      >
                        <Ban className="w-3.5 h-3.5 text-muted-foreground" /> Not for selling?
                      </label>
                    </div>
                    <InfoTooltip text="Disable selling this product in POS and customer invoices." />
                  </div>
                </div>

                {/* Simple Alert Quantity Row when Manage Stock is ON */}
                {formEnableStock && (
                  <div className="flex flex-wrap items-center gap-3 p-2.5 rounded-sm border border-border/40 bg-secondary/15 text-xs animate-in fade-in duration-150">
                    <label 
                      htmlFor="alertQuantity" 
                      className="font-bold text-foreground flex items-center gap-1.5 cursor-pointer select-none shrink-0"
                    >
                      <Bell className="w-3.5 h-3.5 text-blue-500" /> Alert Quantity:
                    </label>
                    <Input
                      id="alertQuantity"
                      type="number"
                      min={0}
                      placeholder="0"
                      {...register("alertQuantity", { valueAsNumber: true })}
                      disabled={isPending}
                      className="w-24 h-8 text-xs bg-background text-center font-medium"
                    />
                    <span className="text-[11px] text-muted-foreground">
                      Low stock alert threshold
                    </span>
                    {errors.alertQuantity && (
                      <span className="text-[10px] text-destructive font-medium">
                        {errors.alertQuantity.message}
                      </span>
                    )}
                  </div>
                )}

                {/* More Information Button */}
                <div className="pt-2 border-t border-border/30 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setShowDescription(!showDescription)}
                    className="text-xs font-bold text-primary hover:text-primary/80 flex items-center gap-1.5 transition"
                  >
                    {showDescription ? (
                      <>
                        <ChevronUp className="h-4 w-4" /> Less Information
                      </>
                    ) : (
                      <>
                        <ChevronDown className="h-4 w-4" /> More Information
                      </>
                    )}
                  </button>
                </div>

                {/* Description - Full Width (Shown when expanded) */}
                {showDescription && (
                  <div className="space-y-1.5 animate-in fade-in slide-in-from-top-1 duration-200">
                    <label className="text-xs font-bold text-muted-foreground uppercase">
                      Description
                    </label>
                    <Controller
                      name="description"
                      control={control}
                      render={({ field }) => (
                        <RichTextEditor
                          value={field.value || ""}
                          onChange={field.onChange}
                          disabled={isPending}
                        />
                      )}
                    />
                  </div>
                )}
              </>
            ) : (
              <>
                {formType === "SINGLE" ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 gap-4">
                      {/* SKU */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1">
                          <Tag className="h-3 w-3" /> SKU <span className="text-muted-foreground/60 font-normal lowercase">(Optional - Auto-generates if empty)</span>
                        </label>
                        <Input
                          placeholder="e.g., TEA-250G"
                          {...register("sku")}
                          disabled={isPending}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      {/* Purchase Price */}
                      <div className="space-y-1.5 col-span-1">
                        <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1">
                          <DollarSign className="h-3 w-3" /> Purchase Price (Cost) <span className="text-destructive">*</span>
                        </label>
                        <Input
                          type="number"
                          step="any"
                          placeholder="0.00"
                          {...register("purchasePrice", { valueAsNumber: true })}
                          disabled={isPending}
                          className={cn(errors.purchasePrice && "border-destructive focus-visible:ring-destructive")}
                        />
                        {errors.purchasePrice && (
                          <span className="text-[10px] text-destructive block">{errors.purchasePrice.message}</span>
                        )}
                      </div>

                      {/* Selling Price */}
                      <div className="space-y-1.5 col-span-1">
                        <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1">
                          <DollarSign className="h-3 w-3" /> Selling Price (Retail) <span className="text-destructive">*</span>
                        </label>
                        <Input
                          type="number"
                          step="any"
                          placeholder="0.00"
                          {...register("sellingPrice", { valueAsNumber: true })}
                          disabled={isPending}
                          className={cn(errors.sellingPrice && "border-destructive focus-visible:ring-destructive")}
                        />
                        {errors.sellingPrice && (
                          <span className="text-[10px] text-destructive block">{errors.sellingPrice.message}</span>
                        )}
                      </div>
                    </div>

                    {/* Margin Indicator */}
                    {formPurchasePrice !== undefined && formSellingPrice !== undefined && !isNaN(formPurchasePrice) && !isNaN(formSellingPrice) && (
                      <div className="flex items-center justify-between p-2.5 rounded-lg border border-border/50 bg-secondary/15 text-xs font-mono">
                        <span className="text-muted-foreground">Estimated Margin:</span>
                        <span className={cn(
                          "font-bold flex items-center gap-1.5",
                          formSellingPrice < formPurchasePrice ? "text-destructive" : "text-emerald-500"
                        )}>
                          {formSellingPrice < formPurchasePrice ? (
                            <>
                              <AlertTriangle className="w-3.5 h-3.5" />
                              {(formSellingPrice - formPurchasePrice).toFixed(2)} (Selling at a loss!)
                            </>
                          ) : (
                            <>
                              +{(formSellingPrice - formPurchasePrice).toFixed(2)} ({formPurchasePrice > 0 ? (((formSellingPrice - formPurchasePrice) / formPurchasePrice) * 100).toFixed(1) : "100"}%)
                            </>
                          )}
                        </span>
                      </div>
                    )}

                    {!product && formEnableStock && (
                      <div className="grid grid-cols-2 gap-4">
                        {/* Opening Stock Quantity */}
                        <div className="space-y-1.5 col-span-1">
                          <label className="text-xs font-bold text-muted-foreground uppercase">
                            Opening Stock Qty
                          </label>
                          <Input
                            type="number"
                            placeholder="0"
                            {...register("openingStock", { valueAsNumber: true })}
                            disabled={isPending}
                          />
                          {errors.openingStock && (
                            <span className="text-[10px] text-destructive block">{errors.openingStock.message}</span>
                          )}
                        </div>

                        {/* Opening Stock Branch */}
                        <div className="space-y-1.5 col-span-1">
                          <label className="text-xs font-bold text-muted-foreground uppercase">
                            Opening Stock Branch
                          </label>
                          <Select
                            value={formOpeningStockBranchId}
                            onValueChange={(val) => setValue("openingStockBranchId", val, { shouldValidate: true })}
                            disabled={isPending}
                            className={cn("w-full", errors.openingStockBranchId && "border-destructive")}
                          >
                            <option value="none">Select Branch...</option>
                            {branchesList.map((branch: any) => (
                              <option key={branch.id} value={branch.id}>
                                {branch.name}
                              </option>
                            ))}
                          </Select>
                          {errors.openingStockBranchId && (
                            <span className="text-[10px] text-destructive block">{errors.openingStockBranchId.message}</span>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Selling Price Groups */}
                    {spgList.length > 0 && (
                      <div className="space-y-3 p-4 rounded-lg bg-primary/5 border border-primary/10">
                        <h4 className="text-xs font-bold text-primary flex items-center gap-1">
                          <Coins className="h-4 w-4" /> Selling Price Groups (Optional)
                        </h4>
                        <div className="grid grid-cols-2 gap-3">
                           {spgList.map((spg: any) => (
                            <div key={spg.id} className="space-y-1">
                              <label className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                                <Coins className="h-3 w-3" /> {spg.name} Price
                              </label>
                              <Input
                                type="number"
                                step="any"
                                placeholder="0.00"
                                value={singleGroupPrices[spg.id] || ""}
                                onChange={(e) =>
                                  setSingleGroupPrices({
                                    ...singleGroupPrices,
                                    [spg.id]: e.target.value
                                  })
                                }
                                disabled={isPending}
                                className="h-8 text-xs"
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="p-4 rounded-lg bg-secondary/30 border border-border/30 space-y-3">
                      <h4 className="text-xs font-bold text-foreground flex items-center gap-1">
                        <Sliders className="h-4 w-4 text-primary" /> Select Variation Attributes
                      </h4>
                      
                      {/* Attributes Selector */}
                      <div className="flex flex-wrap gap-2">
                        {variations.map((v: any) => {
                          const isChecked = selectedVariationIds.includes(v.id);
                          return (
                            <button
                              type="button"
                              key={v.id}
                              onClick={() => handleToggleVariationSelector(v.id)}
                              className={cn(
                                "flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition border",
                                isChecked
                                  ? "bg-primary/15 border-primary/40 text-primary"
                                  : "bg-background border-border/50 text-muted-foreground hover:text-foreground"
                              )}
                            >
                              {isChecked && <Check className="h-3 w-3" />}
                              {v.name}
                            </button>
                          );
                        })}
                      </div>

                      {/* Attribute Values Selector */}
                      {selectedVariationIds.map((varId) => {
                        const variationObj = variations.find((v: any) => v.id === varId);
                        if (!variationObj) return null;
                        const activeVals = selectedVariationValues[varId] || [];

                        return (
                          <div key={varId} className="p-3 bg-background border border-border/40 rounded-lg space-y-1.5">
                            <span className="text-[10px] font-bold text-muted-foreground uppercase block">
                              {variationObj.name} Values:
                            </span>
                            <div className="flex flex-wrap gap-1.5">
                              {variationObj.values.map((val: any) => {
                                const isValChecked = activeVals.includes(val.id);
                                return (
                                  <button
                                    type="button"
                                    key={val.id}
                                    onClick={() => handleToggleVariationValueSelector(varId, val.id)}
                                    className={cn(
                                      "px-2 py-0.5 rounded text-xs font-semibold border transition",
                                      isValChecked
                                        ? "bg-secondary text-secondary-foreground border-secondary-foreground/20"
                                        : "bg-transparent text-muted-foreground border-border/40 hover:bg-secondary/20"
                                    )}
                                  >
                                    {val.value}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        );
                      })}

                      <Button
                        type="button"
                        onClick={handleGenerateVariants}
                        className="h-8 text-xs font-bold flex items-center gap-1.5"
                      >
                        Generate Combinations
                      </Button>
                    </div>

                    {/* Variants List Table */}
                    {generatedVariants.length > 0 && (
                      <div className="space-y-3">
                        <h4 className="text-xs font-bold text-foreground">Configure Variant Prices & SKUs</h4>
                        <div className="space-y-4 max-h-60 overflow-y-auto border border-border/50 rounded-lg p-3 bg-background/50">
                          {generatedVariants.map((v, idx) => (
                            <div key={idx} className="p-3 border border-border/50 rounded-lg bg-card space-y-3">
                              <div className="flex items-center justify-between border-b border-border/40 pb-1.5">
                                <span className="text-xs font-extrabold text-foreground">{v.name}</span>
                              </div>

                              <div className="grid grid-cols-4 gap-2">
                                <div className="col-span-2 space-y-1">
                                  <label className="text-[9px] font-bold text-muted-foreground uppercase">SKU</label>
                                  <Input
                                    value={v.sku}
                                    onChange={(e) => handleUpdateGeneratedVariant(idx, "sku", e.target.value)}
                                    required
                                    className="h-8 text-xs uppercase"
                                  />
                                </div>
                                <div className="col-span-1 space-y-1">
                                  <label className="text-[9px] font-bold text-muted-foreground uppercase">Cost</label>
                                  <Input
                                    type="number"
                                    value={v.purchasePrice}
                                    onChange={(e) => handleUpdateGeneratedVariant(idx, "purchasePrice", e.target.value)}
                                    required
                                    className="h-8 text-xs"
                                  />
                                </div>
                                <div className="col-span-1 space-y-1">
                                  <label className="text-[9px] font-bold text-muted-foreground uppercase">Sell</label>
                                  <Input
                                    type="number"
                                    value={v.sellingPrice}
                                    onChange={(e) => handleUpdateGeneratedVariant(idx, "sellingPrice", e.target.value)}
                                    required
                                    className="h-8 text-xs"
                                  />
                                </div>
                              </div>

                              {!product && formEnableStock && (
                                <div className="grid grid-cols-2 gap-2 mt-1 p-2 bg-secondary/15 rounded-md border border-dashed border-border/30">
                                  {/* Variant Opening Stock Qty */}
                                  <div className="space-y-1">
                                    <label className="text-[9px] font-bold text-muted-foreground uppercase">
                                      Opening Stock Qty
                                    </label>
                                    <Input
                                      type="number"
                                      placeholder="0"
                                      value={v.openingStock || ""}
                                      onChange={(e) => handleUpdateGeneratedVariant(idx, "openingStock", parseFloat(e.target.value) || 0)}
                                      className="h-8 text-xs"
                                    />
                                  </div>

                                  {/* Variant Opening Stock Branch */}
                                  <div className="space-y-1">
                                    <label className="text-[9px] font-bold text-muted-foreground uppercase">
                                      Opening Stock Branch
                                    </label>
                                    <Select
                                      value={v.openingStockBranchId || "none"}
                                      onValueChange={(val) => handleUpdateGeneratedVariant(idx, "openingStockBranchId", val)}
                                      className="h-8 text-xs w-full"
                                    >
                                      <option value="none">Select Branch...</option>
                                      {branchesList.map((branch: any) => (
                                        <option key={branch.id} value={branch.id}>
                                          {branch.name}
                                        </option>
                                      ))}
                                    </Select>
                                  </div>
                                </div>
                              )}

                              {/* Nested Group Prices for Variant */}
                              {spgList.length > 0 && (
                                <div className="pl-2 border-l-2 border-primary/20 space-y-1.5">
                                  <span className="text-[9px] font-bold text-primary uppercase block">Group Prices:</span>
                                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                                    {spgList.map((spg: any) => {
                                      const matchingGp = v.groupPrices?.find((gp) => gp.sellingPriceGroupId === spg.id);
                                      return (
                                        <div key={spg.id} className="flex items-center gap-1.5">
                                          <span className="text-[8px] font-bold text-muted-foreground uppercase truncate max-w-[80px]">
                                            {spg.name}:
                                          </span>
                                          <Input
                                            type="number"
                                            placeholder="0.00"
                                            value={matchingGp ? String(matchingGp.price) : ""}
                                            onChange={(e) =>
                                              handleUpdateGeneratedVariantGroupPrice(idx, spg.id, e.target.value)
                                            }
                                            className="h-7 text-[10px] w-20"
                                          />
                                        </div>
                                      );
                                    })}
                                  </div>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
          </div>

          {/* Form Buttons */}
          <div className="flex items-center justify-between pt-3 border-t border-border/50 shrink-0">
            <div>
              {activeTab === "pricing" && (
                <Button
                  key="btn-back"
                  type="button"
                  variant="outline"
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setActiveTab("general");
                  }}
                  className="h-9 px-4 text-xs"
                >
                  Back
                </Button>
              )}
            </div>
            <div className="flex items-center space-x-3">
              <Button
                key="btn-cancel"
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isPending}
                className="h-9 px-4 text-xs"
              >
                Cancel
              </Button>
              
              {activeTab === "general" ? (
                <Button
                  key="btn-next"
                  type="button"
                  onClick={handleNext}
                  className="h-9 px-4 text-xs font-semibold"
                >
                  Next
                </Button>
              ) : (
                <Button
                  key="btn-submit"
                  type="submit"
                  disabled={isPending}
                  className="h-9 px-4 text-xs font-semibold flex items-center gap-1.5"
                >
                  {isPending && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                  {!product ? "Create Product" : "Save Changes"}
                </Button>
              )}
            </div>
          </div>
        </form>
    </Dialog>
  );
}
