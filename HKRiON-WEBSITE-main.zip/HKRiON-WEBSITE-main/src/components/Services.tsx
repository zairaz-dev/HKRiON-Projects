'use client';

import { useState } from 'react';
import { 
  Building2, 
  Cpu, 
  Code2, 
  Smartphone, 
  TrendingUp, 
  Briefcase,
  Users,
  UserCheck,
  Package,
  Radio,
  Activity,
  Zap,
  Globe,
  Layers,
  Server,
  Layout,
  Search,
  Target,
  Megaphone,
  Cloud,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  X,
  ArrowRight,
  Clock,
  Award,
  Send
} from 'lucide-react';

interface ServiceItem {
  id: string;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  color: string;
  timeline: string;
  sla: string;
  tags: { name: string; icon: React.ComponentType<{ className?: string }> }[];
  features: string[];
  techStack: string[];
}

const services: ServiceItem[] = [
  {
    id: 'erp-hrm',
    icon: Building2,
    title: 'Enterprise ERP & HRM Systems',
    description: 'Custom ERP and HRM platforms tailored for inventory management, HR payroll, attendance tracking, and finance with real-time analytics.',
    color: 'from-[#1ABE56] to-emerald-800',
    timeline: '2 - 4 Weeks',
    sla: '99.9% System Uptime SLA',
    tags: [
      { name: 'Custom ERP', icon: Building2 },
      { name: 'HRM & Payroll', icon: Users },
      { name: 'Attendance', icon: UserCheck },
      { name: 'Inventory', icon: Package }
    ],
    features: [
      'Custom Inventory & Multi-Warehouse Stock Engine',
      'Automated HR Payroll, EPF/ETF & Tax Deductions',
      'Biometric & Geofenced Mobile Attendance Tracking',
      'Real-Time Executive Dashboard & Financial Reports',
      'Role-Based Granular Access Control & Security Audits'
    ],
    techStack: ['MySQL Enterprise', 'Next.js 16', 'Node.js API', 'TypeScript']
  },
  {
    id: 'iot-automation',
    icon: Cpu,
    title: 'IoT & Smart Automation Systems',
    description: 'Smart sensors integration, hardware telemetry, industrial automation, and real-time remote monitoring solutions for businesses.',
    color: 'from-emerald-500 to-green-800',
    timeline: '3 - 6 Weeks',
    sla: '24/7 Real-Time Telemetry Stream',
    tags: [
      { name: 'Industrial IoT', icon: Cpu },
      { name: 'Smart Sensors', icon: Radio },
      { name: 'Telemetry', icon: Activity },
      { name: 'Hardware API', icon: Zap }
    ],
    features: [
      'Industrial Smart Sensor & Gateway Micro-Controllers',
      'Asynchronous Low-Latency Telemetry Data Vault',
      'Real-Time Threshold Alerting via SMS/WhatsApp/Email',
      'Remote Hardware Relay Controls & Scheduling Engine',
      'Custom IoT Telemetry Dashboard & Predictive Analytics'
    ],
    techStack: ['MQTT / WebSockets', 'Node.js Runtime', 'MongoDB Store', 'Flutter / React']
  },
  {
    id: 'web-dev',
    icon: Code2,
    title: 'Custom Web Development',
    description: 'Scalable, modern web applications built using Next.js, React, and Node.js with high-performance responsive UI/UX designs.',
    color: 'from-green-600 to-emerald-900',
    timeline: '1 - 3 Weeks',
    sla: 'Global CDN & Sub-Second Load',
    tags: [
      { name: 'Next.js 16', icon: Globe },
      { name: 'React 19', icon: Code2 },
      { name: 'Full-Stack Apps', icon: Layers },
      { name: 'REST/GraphQL', icon: Server }
    ],
    features: [
      'Next.js 16 App Router & Server-Side Rendering (SSR)',
      'Bespoke Fluid Glassmorphic UI/UX Design System',
      'Technical SEO Optimization & Structured Data Schema',
      'Secure Payment Gateway Integration (Stripe, PayHere)',
      'Headless CMS & High-Speed Database API Connectors'
    ],
    techStack: ['Next.js 16', 'TypeScript', 'Tailwind CSS', 'MySQL / PostgreSQL']
  },
  {
    id: 'mobile-apps',
    icon: Smartphone,
    title: 'Mobile App Development',
    description: 'Native & Cross-platform mobile applications for iOS and Android built with React Native & Flutter for intuitive mobile experiences.',
    color: 'from-[#1ABE56] to-green-700',
    timeline: '2 - 5 Weeks',
    sla: 'App Store & Play Store Ready',
    tags: [
      { name: 'iOS & Android', icon: Smartphone },
      { name: 'React Native', icon: Code2 },
      { name: 'Flutter', icon: Zap },
      { name: 'Mobile UI', icon: Layout }
    ],
    features: [
      'Single Codebase 60 FPS Native Performance',
      'Offline Local Caching & Background Data Synchronization',
      'Instant Push Notifications & In-App Customer Messaging',
      'Biometric Fingerprint/FaceID Security Hardening',
      'Intuitive Mobile UX with Haptic Responsive Feedback'
    ],
    techStack: ['Flutter Engine', 'React Native', 'Firebase Cloud', 'RESTful API']
  },
  {
    id: 'digital-marketing',
    icon: TrendingUp,
    title: 'Digital Marketing & Growth',
    description: 'Data-driven SEO strategies, social media marketing, targeted performance advertising, content branding, and high-converting lead generation.',
    color: 'from-emerald-600 to-green-950',
    timeline: 'Ongoing Sprints',
    sla: 'High ROI Lead Funnel Conversion',
    tags: [
      { name: 'SEO Optimization', icon: Search },
      { name: 'Lead Gen', icon: Target },
      { name: 'Social Ads', icon: Megaphone },
      { name: 'Brand Growth', icon: TrendingUp }
    ],
    features: [
      'Technical & Content SEO Keyword Ranking Strategy',
      'Targeted Performance Advertising (Meta & Google Ads)',
      'High-Converting Landing Page & Lead Funnel Engineering',
      'Brand Identity, Social Media Assets & Content Strategy',
      'Weekly ROI Conversion Reports & Analytics Audits'
    ],
    techStack: ['Google Analytics 4', 'Meta Pixel', 'Lead Funnel Tech', 'SEO Tools']
  },
  {
    id: 'it-consultancy',
    icon: Briefcase,
    title: 'Business Consultancy & IT Solutions',
    description: 'Strategic IT advisory, digital transformation roadmaps, cloud setup (AWS/Docker), database optimization, and custom software architecture.',
    color: 'from-green-500 to-emerald-950',
    timeline: '1 - 2 Weeks Audit',
    sla: 'Bank-Grade Architecture SLA',
    tags: [
      { name: 'IT Consulting', icon: Briefcase },
      { name: 'Cloud Architecture', icon: Cloud },
      { name: 'Digital Transformation', icon: Sparkles },
      { name: 'Security', icon: ShieldCheck }
    ],
    features: [
      'Legacy Code Base Modernization & Cloud Migration Plan',
      'AWS & Docker Microservices Container Architecture',
      'MySQL / PostgreSQL Database Optimization & Indexing',
      'Cybersecurity Penetration Hardening & SSL Audits',
      '24/7 Dedicated SLA Technical Support Contracts'
    ],
    techStack: ['AWS Cloud', 'Docker Container', 'Nginx Web Server', 'MySQL Hardening']
  }
];

export default function Services() {
  const [activeModal, setActiveModal] = useState<ServiceItem | null>(null);

  const handleRequestQuote = (_serviceTitle?: string) => {
    setActiveModal(null);
    const contactSection = document.getElementById('contact');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="services" className="py-24 relative overflow-hidden bg-black border-b border-[#1ABE56]/30">
      
      {/* Background ambient glow */}
      <div className="absolute top-1/3 left-10 w-96 h-96 bg-[#1ABE56]/10 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <span className="text-xs font-mono font-bold uppercase tracking-widest text-[#1ABE56] bg-[#1ABE56]/10 px-4 py-1.5 rounded-full border border-[#1ABE56]/30 inline-block animate-pulse">
            CORE SERVICES & SOLUTIONS
          </span>
          <h2 className="text-3xl sm:text-5xl font-semibold text-white tracking-tight">
            End-to-End <span className="gradient-text">Technology & Business Solutions</span>
          </h2>
          <p className="text-neutral-400 text-base sm:text-lg">
            We engineer custom software, smart IoT hardware integrations, mobile apps, and digital growth strategies to accelerate your business.
          </p>
        </div>

        {/* Services 3-Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => {
            const MainIcon = service.icon;
            return (
              <div
                key={service.id}
                className="glass-card p-8 rounded-3xl border border-[#1ABE56]/30 hover:border-[#1ABE56] transition-all duration-300 group hover:-translate-y-1.5 flex flex-col justify-between bg-black/85 hover:shadow-2xl hover:shadow-[#1ABE56]/20 relative overflow-hidden"
              >
                <div>
                  {/* Icon & SLA Badge */}
                  <div className="flex items-start justify-between mb-6">
                    <div className={`w-14 h-14 rounded-2xl bg-linear-to-br ${service.color} p-0.5 shadow-lg shadow-[#1ABE56]/20 group-hover:scale-110 transition-transform`}>
                      <div className="w-full h-full bg-black rounded-[14px] flex items-center justify-center">
                        <MainIcon className="w-7 h-7 text-[#1ABE56] group-hover:text-white transition-colors" />
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-[#1ABE56] bg-[#1ABE56]/10 px-2.5 py-1 rounded-full border border-[#1ABE56]/25 font-semibold">
                      {service.timeline}
                    </span>
                  </div>

                  {/* Title & Description */}
                  <h3 className="text-xl font-bold text-white mb-3 group-hover:text-[#1ABE56] transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-neutral-400 text-sm leading-relaxed mb-6">
                    {service.description}
                  </p>
                </div>

                <div className="space-y-4">
                  {/* Tags with Icons */}
                  <div className="flex flex-wrap gap-2 pt-4 border-t border-white/10">
                    {service.tags.map((tagObj, tIdx) => {
                      const TagIcon = tagObj.icon;
                      return (
                        <span
                          key={tIdx}
                          className="inline-flex items-center gap-1.5 text-[11px] font-mono font-medium px-2.5 py-1 rounded-xl bg-neutral-900/90 text-[#1ABE56] border border-[#1ABE56]/30 hover:border-[#1ABE56] hover:scale-105 transition-all cursor-default"
                        >
                          <TagIcon className="w-3.5 h-3.5 text-[#1ABE56] shrink-0" />
                          <span>{tagObj.name}</span>
                        </span>
                      );
                    })}
                  </div>

                  {/* Interactive Action Buttons */}
                  <div className="grid grid-cols-2 gap-2 pt-2">
                    <button
                      onClick={() => setActiveModal(service)}
                      className="w-full text-xs font-mono font-semibold py-2.5 px-3 rounded-xl bg-neutral-900 text-neutral-300 hover:text-white hover:bg-neutral-800 border border-neutral-750 hover:border-[#1ABE56]/50 transition-all cursor-pointer flex items-center justify-center gap-1"
                    >
                      Explore Details
                    </button>

                    <button
                      onClick={() => handleRequestQuote(service.title)}
                      className="w-full text-xs font-mono font-bold py-2.5 px-3 rounded-xl bg-[#1ABE56]/15 hover:bg-[#1ABE56] text-[#1ABE56] hover:text-black border border-[#1ABE56]/40 transition-all cursor-pointer flex items-center justify-center gap-1 group/btn shadow-md"
                    >
                      Get Quote <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

      </div>

      {/* Interactive Solution Spotlight Modal / Drawer */}
      {activeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl animate-fade-in">
          <div className="relative w-full max-w-3xl glass-card rounded-3xl border border-[#1ABE56] bg-neutral-950 p-6 sm:p-8 shadow-2xl shadow-[#1ABE56]/30 max-h-[90vh] overflow-y-auto space-y-6">
            
            {/* Close Button */}
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-6 right-6 p-2 rounded-full bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800 border border-neutral-800 transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Header */}
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-[#1ABE56]/15 border border-[#1ABE56]/40 flex items-center justify-center shrink-0">
                {(() => {
                  const IconComp = activeModal.icon;
                  return <IconComp className="w-7 h-7 text-[#1ABE56]" />;
                })()}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono text-[#1ABE56] bg-[#1ABE56]/15 px-2.5 py-0.5 rounded-full border border-[#1ABE56]/30 font-semibold">
                    SOLUTION DETAILS
                  </span>
                  <span className="text-[10px] font-mono text-neutral-400 bg-neutral-900 px-2.5 py-0.5 rounded-full border border-white/10">
                    SLA: {activeModal.sla}
                  </span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
                  {activeModal.title}
                </h3>
              </div>
            </div>

            <p className="text-neutral-300 text-sm sm:text-base leading-relaxed border-b border-white/10 pb-4">
              {activeModal.description}
            </p>

            {/* Features Breakdown */}
            <div className="space-y-3">
              <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-[#1ABE56] flex items-center gap-2">
                <Award className="w-4 h-4 text-[#1ABE56]" />
                Key Features & Enterprise Deliverables
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {activeModal.features.map((feat, fIdx) => (
                  <div key={fIdx} className="p-3 rounded-xl bg-neutral-900/90 border border-[#1ABE56]/20 flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-[#1ABE56] shrink-0 mt-0.5" />
                    <span className="text-xs font-mono text-neutral-200">{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Tech Stack & Implementation SLA */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-white/10">
              <div className="p-4 rounded-xl bg-neutral-900/90 border border-white/5 space-y-2">
                <span className="text-xs font-mono text-neutral-400 block">Technology Stack Powering This Solution</span>
                <div className="flex flex-wrap gap-1.5">
                  {activeModal.techStack.map((tech, tIdx) => (
                    <span key={tIdx} className="text-xs font-mono text-white bg-black px-2.5 py-1 rounded-lg border border-[#1ABE56]/30 font-semibold">
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-neutral-900/90 border border-white/5 space-y-1">
                <span className="text-xs font-mono text-neutral-400 block">Estimated Timeline</span>
                <p className="text-lg font-extrabold text-[#1ABE56] font-mono flex items-center gap-2">
                  <Clock className="w-4 h-4 text-[#1ABE56]" />
                  {activeModal.timeline}
                </p>
                <p className="text-[11px] text-neutral-400 font-mono">Includes development, QA testing & deployment.</p>
              </div>
            </div>

            {/* CTA Action Bar */}
            <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
              <span className="text-xs font-mono text-neutral-400">
                Ready to build your solution with HKRION?
              </span>

              <button
                onClick={() => handleRequestQuote(activeModal.title)}
                className="w-full sm:w-auto glow-btn font-bold text-black bg-[#1ABE56] px-6 py-3 rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#1ABE56]/30 hover:scale-105 transition-all"
              >
                <Send className="w-4 h-4 text-black" />
                Request Custom Proposal for {activeModal.title.split(' ')[0]}
              </button>
            </div>

          </div>
        </div>
      )}

    </section>
  );
}

