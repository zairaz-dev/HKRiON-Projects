"use client";

import React, { useEffect, useState, useRef, useMemo, Suspense } from "react";
import { useRouter } from "next/navigation";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  FileText,
  Barcode,
  Calendar,
  Building2,
  User as UserIcon,
  Coins,
  Loader2,
  CheckCircle,
  AlertCircle,
  Plus,
  X,
  Search,
  CreditCard,
  Package,
  Smartphone
} from "lucide-react";
import { getFullAssetUrl, cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Dialog } from "@/components/ui/dialog";
import { Sidebar } from "@/components/layout/sidebar";
import { Navbar } from "@/components/layout/navbar";
import { authService } from "@/services/auth-service";
import { User } from "@hkr/types";

import {
  purchaseFormSchema,
  PurchaseFormValues,
  useCreatePurchaseMutation
} from "@/features/purchases";
import { useProductsQuery } from "@/features/products/hooks/use-products";
import { useSuppliersQuery, useBranchesQuery } from "@/features/suppliers/hooks/use-suppliers";
import { SupplierDialog } from "@/features/suppliers/components/supplier-dialog";
import { ProductDialog } from "@/features/products/components/product-dialog";
import { usePaymentMethodsQuery } from "@/features/payment-methods/hooks/use-payment-methods";
import { useCurrency } from "@/hooks/use-currency";

function CreatePurchasePageContent() {
  const router = useRouter();
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    if (typeof window !== "undefined") return authService.getCurrentUser();
    return null;
  });
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(() => {
    if (typeof window !== "undefined") return authService.isAuthenticated();
    return null;
  });

  // Quick Add Dialog Modals
  const [isSupplierDialogOpen, setIsSupplierDialogOpen] = useState<boolean>(false);
  const [isProductDialogOpen, setIsProductDialogOpen] = useState<boolean>(false);

  // IMEI Management Modal State
  const [activeImeiLineIndex, setActiveImeiLineIndex] = useState<number | null>(null);
  const [imeiInputText, setImeiInputText] = useState("");

  // Status Alerts
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Product Autocomplete Search State
  const [productSearchQuery, setProductSearchQuery] = useState("");
  const [showSearchResults, setShowSearchResults] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Close search results on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setShowSearchResults(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Sync auth state
  useEffect(() => {
    const user = authService.getCurrentUser();
    const authed = authService.isAuthenticated();
    setCurrentUser(user);
    setIsAuthenticated(authed);

    if (!authed) {
      setTimeout(() => {
        window.location.href = "/login";
      }, 2000);
    }
  }, []);

  const businessId = currentUser?.businessId || "";
  const userId = currentUser?.id || "";
  const { symbol, format } = useCurrency(businessId);

  // Data Queries
  const { data: productsList = [], refetch: refetchProducts } = useProductsQuery(businessId);
  const { data: suppliers = [], refetch: refetchSuppliers } = useSuppliersQuery(businessId);
  const { data: branches = [] } = useBranchesQuery(businessId, userId);
  const { data: paymentMethods = [] } = usePaymentMethodsQuery(businessId, undefined, true);

  // Mutation
  const createMutation = useCreatePurchaseMutation();

  // Flatten variants for item search & selection
  const allVariants = useMemo(() => {
    const list: {
      id: string;
      name: string;
      sku: string;
      purchasePrice: number;
      sellingPrice: number;
      currentStock: number;
      imageUrl?: string | null;
      isImei: boolean;
    }[] = [];
    productsList.forEach((p) => {
      const isSerialized = !!(p.isImei || (p as any).enableImei);
      p.variants.forEach((v) => {
        const totalStock = v.purchaseLines?.reduce((sum: number, line: any) => sum + (parseFloat(String(line.quantityRemaining)) || 0), 0) || 0;
        list.push({
          id: v.id!,
          name: p.type === "SINGLE" ? p.name : `${p.name} - ${v.name}`,
          sku: v.sku,
          purchasePrice: v.purchasePrice || 0,
          sellingPrice: v.sellingPrice || 0,
          currentStock: totalStock,
          imageUrl: p.imageUrl || null,
          isImei: isSerialized
        });
      });
    });
    return list;
  }, [productsList]);

  // Filter products by user's search query
  const filteredProductResults = useMemo(() => {
    if (!productSearchQuery.trim()) return [];
    const query = productSearchQuery.toLowerCase();
    return allVariants.filter(
      (v) => v.name.toLowerCase().includes(query) || v.sku.toLowerCase().includes(query)
    );
  }, [productSearchQuery, allVariants]);

  const handleSelectSearchedProduct = (variant: {
    id: string;
    name: string;
    sku: string;
    purchasePrice: number;
    sellingPrice: number;
    isImei?: boolean;
  }) => {
    append({
      variantId: variant.id,
      quantityPurchased: 1,
      purchasePrice: variant.purchasePrice,
      sellingPrice: variant.sellingPrice,
      batchNumber: "",
      expiryDate: "",
      imeis: []
    });
    setProductSearchQuery("");
    setShowSearchResults(false);
    if (variant.isImei) {
      setActiveImeiLineIndex(fields.length);
    }
  };

  // React Hook Form
  const {
    register,
    control,
    handleSubmit,
    setValue,
    watch,
    formState: { errors }
  } = useForm<PurchaseFormValues>({
    resolver: zodResolver(purchaseFormSchema) as any,
    defaultValues: {
      purchaseNumber: `PUR-${new Date().toISOString().slice(2, 10).replace(/-/g, "")}-${Math.floor(1000 + Math.random() * 9000)}`,
      purchaseDate: new Date().toISOString().split("T")[0],
      supplierId: "",
      branchId: "",
      discountType: "FIXED",
      discountAmount: 0,
      shippingAmount: 0,
      taxAmount: 0,
      notes: "",
      paymentAmount: 0,
      paymentMethodId: "",
      paymentTransactionNo: "",
      paymentNotes: "",
      purchaseLines: []
    }
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: "purchaseLines"
  });

  const watchPurchaseLines = watch("purchaseLines") || [];
  const watchSupplierId = watch("supplierId") || "";
  const watchBranchId = watch("branchId") || "";
  const watchDiscountType = watch("discountType") || "FIXED";
  const watchDiscountAmount = Number(watch("discountAmount") || 0);
  const watchShippingAmount = Number(watch("shippingAmount") || 0);
  const watchTaxAmount = Number(watch("taxAmount") || 0);

  const watchPaymentAmount = Number(watch("paymentAmount") || 0);
  const watchPaymentMethodId = watch("paymentMethodId") || "";

  // Auto-select first branch when branches load
  useEffect(() => {
    if (branches.length > 0 && !watchBranchId) {
      setValue("branchId", branches[0].id, { shouldValidate: true });
    }
  }, [branches, watchBranchId, setValue]);

  // Set default payment method to Cash / first method
  useEffect(() => {
    if (paymentMethods.length > 0 && !watchPaymentMethodId) {
      setValue("paymentMethodId", paymentMethods[0].id);
    }
  }, [paymentMethods, watchPaymentMethodId, setValue]);

  // Financial calculations
  const itemsSubtotal = watchPurchaseLines.reduce((acc, line) => {
    const qty = parseFloat(String(line.quantityPurchased)) || 0;
    const price = parseFloat(String(line.purchasePrice)) || 0;
    return acc + qty * price;
  }, 0);

  const calculatedDiscount = watchDiscountType === "PERCENTAGE"
    ? (itemsSubtotal * watchDiscountAmount) / 100
    : watchDiscountAmount;

  const grandTotal = Math.max(0, (itemsSubtotal - calculatedDiscount) + watchShippingAmount + watchTaxAmount);
  const remainingDue = Math.max(0, grandTotal - watchPaymentAmount);

  const livePaymentStatus = useMemo(() => {
    if (watchPaymentAmount <= 0) return "DUE";
    if (watchPaymentAmount >= grandTotal && grandTotal > 0) return "PAID";
    return "PARTIAL";
  }, [watchPaymentAmount, grandTotal]);

  const onSubmit = async (data: PurchaseFormValues) => {
    if (data.purchaseLines.length === 0) {
      setError("Please add at least one line item.");
      return;
    }

    // 1. Financial adjustments & payment validations
    if (watchDiscountAmount < 0 || watchShippingAmount < 0 || watchTaxAmount < 0) {
      setError("Discount, shipping, and tax amounts cannot be negative.");
      return;
    }
    if (calculatedDiscount > itemsSubtotal) {
      setError("Discount amount cannot exceed items subtotal.");
      return;
    }
    if (data.paymentAmount && data.paymentAmount > grandTotal + 0.01) {
      setError(`Payment amount (${format(data.paymentAmount)}) cannot exceed grand total (${format(grandTotal)}).`);
      return;
    }
    if (data.paymentAmount && data.paymentAmount > 0 && !data.paymentMethodId) {
      setError("Please select a Payment Method for the paid amount.");
      return;
    }

    // 2. Item Quantities, Prices & IMEI Validations
    for (let i = 0; i < data.purchaseLines.length; i++) {
      const line = data.purchaseLines[i];
      const matched = allVariants.find((v) => v.id === line.variantId);
      const lineQty = parseFloat(String(line.quantityPurchased)) || 0;
      const cost = parseFloat(String(line.purchasePrice)) || 0;
      const sell = parseFloat(String(line.sellingPrice)) || 0;

      if (lineQty <= 0) {
        setError(`Quantity for "${matched?.name || `Item #${i + 1}`}" must be greater than 0.`);
        return;
      }
      if (cost < 0 || sell < 0) {
        setError(`Prices for "${matched?.name || `Item #${i + 1}`}" cannot be negative.`);
        return;
      }

      if (matched?.isImei) {
        const count = line.imeis?.length || 0;
        if (count !== lineQty) {
          setError(`Item "${matched.name}" requires exactly ${lineQty} IMEI/Serial number(s), but ${count} were entered. Please click the IMEI button to enter them.`);
          return;
        }
      }
    }

    // 3. Duplicate IMEI check across all lines
    const allEnteredImeis = new Set<string>();
    for (const line of data.purchaseLines) {
      for (const imei of line.imeis || []) {
        const trimmed = imei.trim();
        if (allEnteredImeis.has(trimmed)) {
          setError(`Duplicate IMEI "${trimmed}" found in purchase items. Each IMEI must be unique.`);
          return;
        }
        allEnteredImeis.add(trimmed);
      }
    }

    const payload = {
      purchaseNumber: data.purchaseNumber.trim(),
      purchaseDate: data.purchaseDate ? new Date(data.purchaseDate).toISOString() : undefined,
      supplierId: data.supplierId,
      branchId: data.branchId,
      businessId,
      purchaseLines: data.purchaseLines.map((line) => ({
        variantId: line.variantId,
        quantityPurchased: parseFloat(String(line.quantityPurchased)),
        purchasePrice: parseFloat(String(line.purchasePrice)),
        sellingPrice: parseFloat(String(line.sellingPrice)),
        batchNumber: line.batchNumber || undefined,
        expiryDate: line.expiryDate ? new Date(line.expiryDate).toISOString() : undefined,
        imeis: line.imeis && line.imeis.length > 0 ? line.imeis : undefined,
      })),
      discountType: data.discountType || "FIXED",
      discountAmount: Number(data.discountAmount || 0),
      shippingAmount: Number(data.shippingAmount || 0),
      taxAmount: Number(data.taxAmount || 0),
      grandTotal,
      notes: data.notes?.trim() || undefined,
      paymentDetails: (data.paymentAmount && data.paymentAmount > 0) ? {
        amount: Number(data.paymentAmount),
        paymentMethodId: data.paymentMethodId!,
        transactionNumber: data.paymentTransactionNo?.trim() || undefined,
        notes: data.paymentNotes?.trim() || undefined
      } : undefined
    };

    try {
      await createMutation.mutateAsync(payload);
      setSuccessMessage("Purchase invoice recorded successfully! Redirecting...");
      setTimeout(() => {
        router.push("/purchases");
      }, 1500);
    } catch (err: any) {
      setError(err.message || "Failed to record purchase.");
    }
  };

  if (isAuthenticated === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center space-y-3 p-6 max-w-sm border border-border/40 rounded-sm bg-card/60 backdrop-blur-sm">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <h2 className="text-lg font-bold">Unauthorized Access</h2>
          <p className="text-sm text-muted-foreground">Redirecting to login...</p>
          <Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar activePath="/purchases" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar title="Record Purchase Invoice" />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">

          {/* Header */}
          <div className="flex items-center gap-3">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight flex items-center gap-2">
                <FileText className="h-7 w-7 text-primary" /> Record Stock Purchase
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Enter invoice details, supplier, destination branch, and individual product batch prices.
              </p>
            </div>
          </div>

          {/* Success / Error Alerts */}
          {successMessage && (
            <div className="flex items-center gap-3 p-4 rounded-sm bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400">
              <CheckCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 p-4 rounded-sm bg-destructive/10 border border-destructive/25 text-destructive animate-in fade-in slide-in-from-top-4 duration-300">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          {/* Main Form Layout */}
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            
            {/* Section 1: Invoice Header Info */}
            <Card className="border-border/60 bg-card/40 backdrop-blur-sm shadow-xl relative z-30">
              <CardContent className="p-6 space-y-6">
                
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  
                  {/* Purchase/Invoice Number */}
                  <div className="space-y-1.5">
                    <div className="h-5 flex items-center">
                      <label className="text-xs font-bold text-muted-foreground uppercase">
                        Invoice / Purchase # <span className="text-destructive">*</span>
                      </label>
                    </div>
                    <Input
                      placeholder="e.g. PUR-0001"
                      icon={<Barcode className="h-4 w-4" />}
                      {...register("purchaseNumber")}
                      required
                      disabled={createMutation.isPending}
                    />
                    {errors.purchaseNumber && (
                      <span className="text-[10px] text-destructive">{errors.purchaseNumber.message}</span>
                    )}
                  </div>

                  {/* Purchase Date */}
                  <div className="space-y-1.5">
                    <div className="h-5 flex items-center">
                      <label className="text-xs font-bold text-muted-foreground uppercase">
                        Purchase Date <span className="text-destructive">*</span>
                      </label>
                    </div>
                    <Input
                      type="date"
                      icon={<Calendar className="h-4 w-4" />}
                      {...register("purchaseDate")}
                      required
                      disabled={createMutation.isPending}
                      className="h-10 text-xs font-semibold cursor-pointer"
                    />
                  </div>

                  {/* Supplier Selection with Clean New Button in Header */}
                  <div className="space-y-1.5">
                    <div className="h-5 flex items-center justify-between">
                      <label className="text-xs font-bold text-muted-foreground uppercase">
                        Supplier <span className="text-destructive">*</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => setIsSupplierDialogOpen(true)}
                        className="text-[11px] font-bold text-primary hover:underline flex items-center gap-0.5"
                      >
                        <Plus className="h-3 w-3" /> New
                      </button>
                    </div>
                    <Select
                      showSearch={true}
                      value={watchSupplierId}
                      onValueChange={(val) => setValue("supplierId", val, { shouldValidate: true })}
                      disabled={createMutation.isPending}
                      icon={<UserIcon className="h-4 w-4" />}
                      className="h-10 w-full"
                    >
                      <option value="" disabled>Select Supplier</option>
                      {suppliers.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name.replace(/,\s*$/, "")} {s.businessName ? `(${s.businessName})` : ""}
                        </option>
                      ))}
                    </Select>
                    {errors.supplierId && (
                      <span className="text-[10px] text-destructive">{errors.supplierId.message}</span>
                    )}
                  </div>

                  {/* Branch Selection */}
                  <div className="space-y-1.5">
                    <div className="h-5 flex items-center">
                      <label className="text-xs font-bold text-muted-foreground uppercase">
                        Destination Branch <span className="text-destructive">*</span>
                      </label>
                    </div>
                    <Select
                      showSearch={true}
                      value={watchBranchId}
                      onValueChange={(val) => setValue("branchId", val, { shouldValidate: true })}
                      disabled={createMutation.isPending}
                      icon={<Building2 className="h-4 w-4" />}
                      className="h-10 w-full"
                    >
                      <option value="" disabled>Select Branch</option>
                      {branches.map((b) => (
                        <option key={b.id} value={b.id}>{b.name}</option>
                      ))}
                    </Select>
                    {errors.branchId && (
                      <span className="text-[10px] text-destructive">{errors.branchId.message}</span>
                    )}
                  </div>

                </div>
              </CardContent>
            </Card>

            {/* Purchase Items & Description Card */}
            <Card className="border border-border/60 bg-card/40 backdrop-blur-sm shadow-xl relative z-20">
              <CardContent className="p-6 space-y-6">
                
                {/* Product Search Bar with Quick Add Product Button */}
                <div className="flex gap-2 items-center relative z-30">
                  <div className="relative flex-1" ref={searchContainerRef}>
                    <Input
                      placeholder="Enter Product name / SKU / Scan bar code..."
                      value={productSearchQuery}
                      onChange={(e) => {
                        setProductSearchQuery(e.target.value);
                        setShowSearchResults(true);
                      }}
                      onFocus={() => setShowSearchResults(true)}
                      icon={<Search className="h-4 w-4 text-muted-foreground/60" />}
                      className="h-10 w-full"
                    />

                    {/* Search Results Dropdown */}
                    {showSearchResults && productSearchQuery.trim() !== "" && (
                      <div className="absolute z-50 mt-1.5 w-full rounded-sm border border-border bg-card p-1.5 shadow-2xl max-h-60 overflow-y-auto animate-in fade-in slide-in-from-top-1 duration-150">
                        {filteredProductResults.length > 0 ? (
                          <div className="space-y-1">
                            {filteredProductResults.map((v) => (
                              <div
                                key={v.id}
                                onClick={() => handleSelectSearchedProduct(v)}
                                className="flex items-center justify-between cursor-pointer select-none rounded-sm px-3 py-2 text-sm hover:bg-accent hover:text-foreground transition-colors group"
                              >
                                <div className="flex items-center gap-2.5">
                                  {/* Product Thumbnail */}
                                  <div className="h-8 w-8 rounded-sm border border-border/80 bg-muted/30 overflow-hidden flex items-center justify-center shrink-0">
                                    {v.imageUrl ? (
                                      <img
                                        src={getFullAssetUrl(v.imageUrl) || ""}
                                        alt={v.name}
                                        className="h-full w-full object-cover"
                                      />
                                    ) : (
                                      <Package className="h-4 w-4 text-muted-foreground/60" />
                                    )}
                                  </div>

                                  <div className="flex flex-col">
                                    <span className="font-semibold text-foreground group-hover:text-primary transition-colors">
                                      {v.name}
                                    </span>
                                    <span className="text-xs text-muted-foreground font-mono">
                                      SKU: {v.sku}
                                    </span>
                                  </div>
                                </div>
                                <div className="text-xs text-right">
                                  <div className="text-muted-foreground font-medium">Cost: {format(v.purchasePrice)}</div>
                                  <div className="text-emerald-500 font-bold">Sell: {format(v.sellingPrice)}</div>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="p-3 text-center text-xs text-muted-foreground">
                            No matching products found.
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsProductDialogOpen(true)}
                    className="h-10 px-3 text-xs font-bold gap-1.5 shrink-0 border-border/80 hover:bg-accent rounded-sm"
                    title="Add New Product"
                  >
                    <Plus className="h-4 w-4 text-primary" /> New Product
                  </Button>
                </div>

                {/* Section 2: Items Table card */}
                <div className="border border-border/80 rounded-sm p-4 bg-secondary/5 space-y-4">
                  {fields.length === 0 ? (
                    <div className="text-center py-10 text-xs text-muted-foreground">
                      No items added yet. Search and select products above to add them.
                    </div>
                  ) : (
                    <div className="overflow-x-auto w-full">
                      <table className="w-full border-collapse">
                        <thead>
                          <tr className="border-b border-border/40 text-[10px] font-bold text-muted-foreground uppercase tracking-wider text-left">
                            <th className="pb-3 text-center w-[4%]">#</th>
                            <th className="pb-3 pr-4 w-[34%]">Product Name / Details</th>
                            <th className="pb-3 pr-4 w-[10%]">Purchase Quantity</th>
                            <th className="pb-3 pr-4 w-[12%]">Cost ({symbol})</th>
                            <th className="pb-3 pr-4 w-[12%]">Line Total ({symbol})</th>
                            <th className="pb-3 pr-4 w-[13%] text-emerald-500">Unit Selling Price ({symbol})</th>
                            <th className="pb-3 pr-4 w-[10%]">Batch #</th>
                            <th className="pb-3 pr-4 w-[10%]">Expiry</th>
                            <th className="pb-3 text-center w-[5%]"></th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-border/30">
                          {fields.map((field, idx) => {
                            const matchedVar = allVariants.find((v) => v.id === watchPurchaseLines[idx]?.variantId);
                            const qty = parseFloat(String(watchPurchaseLines[idx]?.quantityPurchased)) || 0;
                            const costPrice = parseFloat(String(watchPurchaseLines[idx]?.purchasePrice)) || 0;
                            const lineTotal = qty * costPrice;

                            return (
                              <tr key={field.id} className="group hover:bg-muted/5 transition-colors">
                                
                                {/* Row Number */}
                                <td className="py-3 text-center align-middle font-mono text-xs text-muted-foreground">
                                  {idx + 1}
                                </td>

                                {/* Product Description with Thumbnail */}
                                <td className="py-3 pr-4 align-middle">
                                  <div className="flex items-center gap-3">
                                    {/* Product Thumbnail */}
                                    <div className="h-10 w-10 rounded-sm border border-border/80 bg-muted/30 overflow-hidden flex items-center justify-center shrink-0">
                                      {matchedVar?.imageUrl ? (
                                        <img
                                          src={getFullAssetUrl(matchedVar.imageUrl) || ""}
                                          alt={matchedVar?.name || "Product"}
                                          className="h-full w-full object-cover"
                                        />
                                      ) : (
                                        <Package className="h-5 w-5 text-muted-foreground/60" />
                                      )}
                                    </div>

                                    <div className="flex flex-col">
                                      <span className="font-semibold text-sm text-foreground">{matchedVar?.name || "Unknown Product"}</span>
                                      <span className="text-[10px] text-muted-foreground font-mono">SKU: {matchedVar?.sku || "N/A"}</span>
                                      <span className="text-[10px] text-emerald-500/80 font-medium">
                                        Current stock: {matchedVar?.currentStock !== undefined ? `${matchedVar.currentStock.toFixed(2)} Pc(s)` : "0.00 Pc(s)"}
                                      </span>
                                      {matchedVar?.isImei && (
                                        <div className="mt-1.5 flex items-center gap-1.5">
                                          <Button
                                            type="button"
                                            size="sm"
                                            variant="outline"
                                            onClick={() => {
                                              setActiveImeiLineIndex(idx);
                                              setImeiInputText("");
                                            }}
                                            className={cn(
                                              "h-6 px-2 text-[10px] font-mono gap-1 rounded-sm border transition-colors",
                                              (watchPurchaseLines[idx]?.imeis?.length || 0) === qty && qty > 0
                                                ? "border-emerald-500/50 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20"
                                                : "border-amber-500/50 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20"
                                            )}
                                          >
                                            <Barcode className="h-3 w-3" />
                                            IMEIs ({watchPurchaseLines[idx]?.imeis?.length || 0}/{qty})
                                          </Button>
                                          {(watchPurchaseLines[idx]?.imeis?.length || 0) !== qty && (
                                            <span className="text-[10px] text-amber-400 font-medium">
                                              Required
                                            </span>
                                          )}
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </td>

                                {/* Quantity Input */}
                                <td className="py-3 pr-4 align-middle">
                                  <Input
                                    type="number"
                                    step="any"
                                    required
                                    placeholder="1.00"
                                    {...register(`purchaseLines.${idx}.quantityPurchased` as const, { valueAsNumber: true })}
                                    disabled={createMutation.isPending}
                                    className="h-9 text-xs"
                                  />
                                </td>

                                {/* Purchase Cost Input */}
                                <td className="py-3 pr-4 align-middle">
                                  <Input
                                    type="number"
                                    step="any"
                                    required
                                    placeholder="0.00"
                                    {...register(`purchaseLines.${idx}.purchasePrice` as const, { valueAsNumber: true })}
                                    disabled={createMutation.isPending}
                                    className="h-9 text-xs"
                                  />
                                </td>

                                {/* Line Total (Display Only) */}
                                <td className="py-3 pr-4 align-middle font-mono text-xs font-bold text-foreground">
                                  {format(lineTotal)}
                                </td>

                                {/* Unit Selling Price Input */}
                                <td className="py-3 pr-4 align-middle">
                                  <Input
                                    type="number"
                                    step="any"
                                    required
                                    placeholder="0.00"
                                    {...register(`purchaseLines.${idx}.sellingPrice` as const, { valueAsNumber: true })}
                                    disabled={createMutation.isPending}
                                    className="h-9 text-xs text-emerald-500 font-semibold"
                                  />
                                  {(() => {
                                    const sell = parseFloat(String(watchPurchaseLines[idx]?.sellingPrice)) || 0;
                                    if (costPrice > 0 && sell > 0 && sell < costPrice) {
                                      return (
                                        <span className="text-[10px] text-amber-500 font-medium block mt-0.5" title="Selling price is lower than cost price">
                                          Below cost!
                                        </span>
                                      );
                                    }
                                    return null;
                                  })()}
                                </td>

                                {/* Batch Number Input */}
                                <td className="py-3 pr-4 align-middle">
                                  <Input
                                    placeholder="Optional"
                                    {...register(`purchaseLines.${idx}.batchNumber` as const)}
                                    disabled={createMutation.isPending}
                                    className="h-9 text-xs"
                                  />
                                </td>

                                {/* Expiry Date Input */}
                                <td className="py-3 pr-4 align-middle">
                                  <Input
                                    type="date"
                                    {...register(`purchaseLines.${idx}.expiryDate` as const)}
                                    disabled={createMutation.isPending}
                                    className="h-9 text-xs"
                                  />
                                </td>

                                {/* Delete Action Button */}
                                <td className="py-3 text-center align-middle">
                                  <Button
                                    type="button"
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => remove(idx)}
                                    className="h-8 w-8 text-destructive hover:bg-destructive/10 hover:text-destructive rounded-sm transition"
                                  >
                                    <X className="h-4 w-4" />
                                  </Button>
                                </td>

                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                {/* Section 3: Financial Adjustments (Discount, Shipping, Tax) & Notes */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 pt-1">
                  {/* Notes */}
                  <div className="lg:col-span-7 flex flex-col justify-between space-y-1.5">
                    <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1.5">
                      <FileText className="h-3.5 w-3.5" /> Purchase Notes / Remarks
                    </label>
                    <textarea
                      placeholder="Details about payment terms, vehicle number, delivery details, etc."
                      {...register("notes")}
                      disabled={createMutation.isPending}
                      rows={4}
                      className="w-full flex-1 min-h-[90px] rounded-sm border border-border/80 bg-background/50 px-3 py-2 text-xs shadow-xs focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-primary resize-none placeholder:text-muted-foreground/60"
                    />
                  </div>

                  {/* Bill Financial Adjustments - Compact Inline Table */}
                  <div className="lg:col-span-5 rounded-sm border border-border/80 bg-card/60 p-3.5 space-y-2 shadow-xs">
                    <div className="flex items-center justify-between border-b border-border/60 pb-1.5">
                      <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                        Bill Summary
                      </span>
                      <span className="text-[11px] text-muted-foreground font-mono font-medium">
                        {watchPurchaseLines.length} Item{watchPurchaseLines.length === 1 ? "" : "s"}
                      </span>
                    </div>

                    {/* Items Subtotal */}
                    <div className="flex items-center justify-between text-xs py-0.5">
                      <span className="text-muted-foreground font-medium">Items Subtotal:</span>
                      <span className="font-bold text-foreground font-mono">{format(itemsSubtotal)}</span>
                    </div>

                    {/* Discount Input with Fixed/Percentage Toggle - Compact Inline */}
                    <div className="flex items-center justify-between text-xs gap-2 py-0.5">
                      <div className="flex items-center gap-1.5">
                        <span className="text-muted-foreground font-medium">Discount:</span>
                        <div className="inline-flex rounded-sm border border-border/80 p-0.5 bg-background">
                          <button
                            type="button"
                            onClick={() => setValue("discountType", "FIXED")}
                            className={`px-1.5 py-0.5 rounded-sm text-[10px] font-bold transition-all ${watchDiscountType === "FIXED" ? "bg-primary text-black" : "text-muted-foreground hover:text-foreground"}`}
                          >
                            {symbol} Fixed
                          </button>
                          <button
                            type="button"
                            onClick={() => setValue("discountType", "PERCENTAGE")}
                            className={`px-1.5 py-0.5 rounded-sm text-[10px] font-bold transition-all ${watchDiscountType === "PERCENTAGE" ? "bg-primary text-black" : "text-muted-foreground hover:text-foreground"}`}
                          >
                            %
                          </button>
                        </div>
                        {watchDiscountType === "PERCENTAGE" && calculatedDiscount > 0 && (
                          <span className="text-[10px] text-rose-500 font-mono font-bold">
                            (-{format(calculatedDiscount)})
                          </span>
                        )}
                      </div>
                      <Input
                        type="number"
                        step="any"
                        min={0}
                        placeholder="0.00"
                        {...register("discountAmount", { valueAsNumber: true })}
                        className="h-7 w-28 text-right text-xs font-bold font-mono"
                      />
                    </div>

                    {/* Shipping / Freight Charges - Compact Inline */}
                    <div className="flex items-center justify-between text-xs gap-2 py-0.5">
                      <span className="text-muted-foreground font-medium">Shipping / Freight ({symbol}):</span>
                      <Input
                        type="number"
                        step="any"
                        min={0}
                        placeholder="0.00"
                        {...register("shippingAmount", { valueAsNumber: true })}
                        className="h-7 w-28 text-right text-xs font-mono"
                      />
                    </div>

                    {/* Tax Amount - Compact Inline */}
                    <div className="flex items-center justify-between text-xs gap-2 py-0.5">
                      <span className="text-muted-foreground font-medium">Tax Amount ({symbol}):</span>
                      <Input
                        type="number"
                        step="any"
                        min={0}
                        placeholder="0.00"
                        {...register("taxAmount", { valueAsNumber: true })}
                        className="h-7 w-28 text-right text-xs font-mono"
                      />
                    </div>

                    {/* Final Grand Total - Compact Highlighted */}
                    <div className="flex items-center justify-between pt-2 border-t border-border/60">
                      <span className="font-black text-xs uppercase tracking-wider text-foreground">Grand Total:</span>
                      <span className="font-black text-lg text-primary font-mono">{format(grandTotal)}</span>
                    </div>
                  </div>
                </div>

                {/* Section 4: Payment Details (Optionally Record Payment on Creation) */}
                <div className="border-t border-border/60 pt-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CreditCard className="h-4 w-4 text-primary" />
                      <span className="text-xs font-bold uppercase tracking-wider text-foreground">
                        Payment Details
                      </span>
                    </div>
                    {/* Live Status Badge */}
                    <span
                      className={`text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-sm border ${
                        livePaymentStatus === "PAID"
                          ? "bg-emerald-500/10 text-emerald-600 border-emerald-500/30"
                          : livePaymentStatus === "PARTIAL"
                          ? "bg-amber-500/10 text-amber-600 border-amber-500/30"
                          : "bg-rose-500/10 text-rose-600 border-rose-500/30"
                      }`}
                    >
                      Status: {livePaymentStatus}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                    {/* Amount Paid */}
                    <div className="space-y-1.5">
                      <div className="h-5 flex items-center justify-between">
                        <label className="text-xs font-bold text-muted-foreground uppercase">
                          Paid Amount ({symbol})
                        </label>
                        {grandTotal > 0 && (
                          <button
                            type="button"
                            onClick={() => setValue("paymentAmount", grandTotal, { shouldValidate: true })}
                            className="text-[10px] font-bold text-primary hover:underline"
                          >
                            Pay Full
                          </button>
                        )}
                      </div>
                      <Input
                        type="number"
                        step="any"
                        min={0}
                        placeholder="0.00"
                        {...register("paymentAmount", { valueAsNumber: true })}
                        disabled={createMutation.isPending}
                        className="h-10 text-xs font-bold"
                      />
                    </div>

                    {/* Payment Method */}
                    <div className="space-y-1.5">
                      <div className="h-5 flex items-center">
                        <label className="text-xs font-bold text-muted-foreground uppercase">
                          Payment Method {watchPaymentAmount > 0 && <span className="text-destructive">*</span>}
                        </label>
                      </div>
                      <Select
                        showSearch={true}
                        value={watchPaymentMethodId}
                        onValueChange={(val) => setValue("paymentMethodId", val, { shouldValidate: true })}
                        disabled={createMutation.isPending}
                        className="h-10 w-full"
                      >
                        <option value="">Select Payment Method</option>
                        {paymentMethods.map((pm) => (
                          <option key={pm.id} value={pm.id}>
                            {pm.name}
                          </option>
                        ))}
                      </Select>
                    </div>

                    {/* Transaction / Cheque No */}
                    <div className="space-y-1.5">
                      <div className="h-5 flex items-center">
                        <label className="text-xs font-bold text-muted-foreground uppercase">
                          Transaction / Cheque #
                        </label>
                      </div>
                      <Input
                        placeholder="Ref / Cheque #"
                        {...register("paymentTransactionNo")}
                        disabled={createMutation.isPending}
                        className="h-10 text-xs"
                      />
                    </div>

                    {/* Payment Remarks */}
                    <div className="space-y-1.5">
                      <div className="h-5 flex items-center">
                        <label className="text-xs font-bold text-muted-foreground uppercase">
                          Payment Remarks
                        </label>
                      </div>
                      <Input
                        placeholder="e.g. Paid on delivery"
                        {...register("paymentNotes")}
                        disabled={createMutation.isPending}
                        className="h-10 text-xs"
                      />
                    </div>
                  </div>

                  {/* Summary Strip */}
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-3 rounded-sm bg-card/60 border border-border/40 text-xs gap-2">
                    <span className="text-muted-foreground">
                      {watchPaymentAmount > 0
                        ? `Paid on delivery: ${format(watchPaymentAmount)} via ${paymentMethods.find(m => m.id === watchPaymentMethodId)?.name || 'selected method'}.`
                        : "No initial payment entered. This bill will be recorded as Credit / Due."}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground font-semibold">Remaining Due:</span>
                      <span className={`font-black text-sm ${remainingDue > 0 ? "text-rose-500" : "text-emerald-500"}`}>
                        {format(remainingDue)}
                      </span>
                    </div>
                  </div>
                </div>

              </CardContent>
            </Card>

            {/* Bottom Actions Bar */}
            <div className="flex items-center justify-between p-4 rounded-sm border border-border/60 bg-card/60 backdrop-blur-sm shadow-lg relative z-0">
              <div className="flex items-center gap-8">
                <div className="flex flex-col">
                  <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Total Items</span>
                  <span className="text-lg font-extrabold text-foreground">
                    {watchPurchaseLines.length}.00
                  </span>
                </div>
                <div className="w-px h-8 bg-border/60" />
                <div className="flex flex-col">
                  <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Net Total Amount</span>
                  <span className="text-2xl font-black text-foreground flex items-center gap-1.5">
                    <Coins className="h-6 w-6 text-amber-500" /> {format(grandTotal)}
                  </span>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => router.push("/purchases")}
                  disabled={createMutation.isPending}
                  className="h-10 px-5 text-xs font-bold rounded-sm"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending}
                  className="h-10 px-5 text-xs font-bold rounded-sm flex items-center gap-1.5"
                >
                  {createMutation.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
                  Save Stock Purchase
                </Button>
              </div>
            </div>

          </form>

        </main>
      </div>

      {/* Quick Add Supplier Dialog Modal */}
      {currentUser && isSupplierDialogOpen && (
        <SupplierDialog
          isOpen={isSupplierDialogOpen}
          onClose={() => setIsSupplierDialogOpen(false)}
          branches={branches}
          currentUser={currentUser}
          onSuccess={(msg) => {
            setSuccessMessage(msg);
            refetchSuppliers();
            setIsSupplierDialogOpen(false);
          }}
          onError={setError}
        />
      )}

      {/* Quick Add Product Dialog Modal */}
      {currentUser && isProductDialogOpen && (
        <ProductDialog
          isOpen={isProductDialogOpen}
          onClose={() => setIsProductDialogOpen(false)}
          product={null}
          businessId={businessId}
          userId={userId}
          onSuccessMessage={(msg) => {
            setSuccessMessage(msg);
            refetchProducts();
            setIsProductDialogOpen(false);
          }}
          onErrorMessage={setError}
        />
      )}

      {/* IMEI / Serial Numbers Entry Modal */}
      {activeImeiLineIndex !== null && (() => {
        const activeLine = watchPurchaseLines[activeImeiLineIndex];
        const activeVar = activeLine ? allVariants.find((v) => v.id === activeLine.variantId) : null;
        const currentImeis: string[] = activeLine?.imeis || [];
        const requiredQty = parseFloat(String(activeLine?.quantityPurchased)) || 0;

        const handleAddImeis = (text: string) => {
          if (!text.trim()) return;
          const tokens = text
            .split(/[\n,\s]+/)
            .map((s) => s.trim())
            .filter((s) => s.length > 0);
          if (tokens.length === 0) return;

          // Check if already used in other purchase lines
          const otherLinesImeis = new Set<string>();
          watchPurchaseLines.forEach((l, lIdx) => {
            if (lIdx !== activeImeiLineIndex) {
              (l.imeis || []).forEach((im) => otherLinesImeis.add(im.trim()));
            }
          });

          const next = [...currentImeis];
          for (const token of tokens) {
            if (otherLinesImeis.has(token)) {
              setError(`IMEI "${token}" is already entered in another item in this purchase.`);
              return;
            }
            if (!next.includes(token)) {
              next.push(token);
            }
          }
          setValue(`purchaseLines.${activeImeiLineIndex}.imeis`, next, { shouldDirty: true });
          setImeiInputText("");
        };

        const handleRemoveImei = (i: number) => {
          const next = currentImeis.filter((_, index) => index !== i);
          setValue(`purchaseLines.${activeImeiLineIndex}.imeis`, next, { shouldDirty: true });
        };

        const handleSyncQty = () => {
          if (currentImeis.length > 0) {
            setValue(`purchaseLines.${activeImeiLineIndex}.quantityPurchased`, currentImeis.length, { shouldDirty: true });
          }
        };

        return (
          <Dialog
            isOpen={activeImeiLineIndex !== null}
            onClose={() => setActiveImeiLineIndex(null)}
            title={
              <div className="flex items-center gap-2">
                <Smartphone className="h-5 w-5 text-primary" />
                <span>Enter IMEIs / Serial Numbers</span>
              </div>
            }
            size="lg"
          >
            <div className="space-y-4 p-1">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-muted/40 p-3 rounded-sm border border-border/70 gap-2">
                <div>
                  <h4 className="font-bold text-sm text-foreground">{activeVar?.name}</h4>
                  <p className="text-xs text-muted-foreground font-mono">SKU: {activeVar?.sku || "N/A"}</p>
                </div>
                <div className="flex items-center gap-2">
                  <div className={cn(
                    "text-xs px-2.5 py-1 rounded font-semibold font-mono",
                    currentImeis.length === requiredQty && requiredQty > 0
                      ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40"
                      : "bg-amber-500/20 text-amber-400 border border-amber-500/40"
                  )}>
                    {currentImeis.length} / {requiredQty} IMEIs
                  </div>
                  {currentImeis.length > 0 && currentImeis.length !== requiredQty && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={handleSyncQty}
                      className="h-7 text-xs border-dashed border-primary/50 text-primary hover:bg-primary/10"
                      title="Update purchase quantity to match number of IMEIs entered"
                    >
                      Sync Qty ({currentImeis.length})
                    </Button>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-semibold text-foreground flex items-center justify-between">
                  <span>Scan or Paste IMEI / Serial Numbers</span>
                  <span className="text-[11px] text-muted-foreground font-normal">
                    (Press Enter or separate by newline/comma)
                  </span>
                </label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Scan barcode or type IMEI..."
                    value={imeiInputText}
                    onChange={(e) => setImeiInputText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        handleAddImeis(imeiInputText);
                      }
                    }}
                    className="font-mono text-xs"
                    autoFocus
                  />
                  <Button
                    type="button"
                    onClick={() => handleAddImeis(imeiInputText)}
                    disabled={!imeiInputText.trim()}
                    className="shrink-0 text-xs px-4"
                  >
                    Add
                  </Button>
                </div>
              </div>

              {/* IMEIs list */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs text-muted-foreground font-medium">
                  <span>Entered IMEIs ({currentImeis.length})</span>
                  {currentImeis.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setValue(`purchaseLines.${activeImeiLineIndex}.imeis`, [], { shouldDirty: true })}
                      className="text-destructive hover:underline text-[11px]"
                    >
                      Clear All
                    </button>
                  )}
                </div>
                <div className="min-h-[120px] max-h-[220px] overflow-y-auto p-2 border border-border/80 rounded-sm bg-background/50 flex flex-wrap gap-1.5 content-start">
                  {currentImeis.length === 0 ? (
                    <div className="w-full h-full flex items-center justify-center text-xs text-muted-foreground/60 italic py-8">
                      No IMEIs entered yet. Scan or type above.
                    </div>
                  ) : (
                    currentImeis.map((imei, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-secondary/80 text-foreground font-mono text-xs border border-border group"
                      >
                        <span className="text-[10px] text-muted-foreground font-sans">#{idx + 1}</span>
                        {imei}
                        <button
                          type="button"
                          onClick={() => handleRemoveImei(idx)}
                          className="text-muted-foreground hover:text-destructive transition ml-0.5"
                          title="Remove"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </span>
                    ))
                  )}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-border/50">
                <Button
                  type="button"
                  onClick={() => setActiveImeiLineIndex(null)}
                  className="px-5 text-xs"
                >
                  Done
                </Button>
              </div>
            </div>
          </Dialog>
        );
      })()}
    </div>
  );
}

export default function CreatePurchasePage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen w-screen items-center justify-center bg-[#121216]">
        <div className="flex flex-col items-center gap-2">
          <div className="w-8 h-8 border-4 border-zinc-700 border-t-emerald-500 rounded-full animate-spin" />
          <p className="text-sm text-zinc-400">Loading...</p>
        </div>
      </div>
    }>
      <CreatePurchasePageContent />
    </Suspense>
  );
}
